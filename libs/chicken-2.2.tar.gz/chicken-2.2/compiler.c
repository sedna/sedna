/* Generated from compiler.scm by the Chicken compiler
   2005-09-24 22:27
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file compiler.c -explicit-use
   unit: compiler
*/

#include "chicken.h"

#ifdef C_USE_C_DEFAULTS
# include "c_defaults.h"
#else
# define C_INSTALL_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif
#define C_METHOD_CACHE_SIZE 8


static C_TLS C_word lf[852];


C_externexport void C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1913(C_word c,C_word t0,C_word t1) C_noret;
static void f_1917(C_word c,C_word t0,C_word t1) C_noret;
static void f_1921(C_word c,C_word t0,C_word t1) C_noret;
static void f_1925(C_word c,C_word t0,C_word t1) C_noret;
static void f_1929(C_word c,C_word t0,C_word t1) C_noret;
static void f_1933(C_word c,C_word t0,C_word t1) C_noret;
static void f_1976(C_word c,C_word t0,C_word t1) C_noret;
static void f_11493(C_word c,C_word t0,C_word t1) C_noret;
static void f_11759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_11769(C_word t0,C_word t1) C_noret;
static void f_11785(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11730(C_word t0,C_word t1) C_noret;
static void f_11653(C_word c,C_word t0,C_word t1) C_noret;
static void f_11710(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11686(C_word t0,C_word t1) C_noret;
static void f_11690(C_word c,C_word t0,C_word t1) C_noret;
static void f_11665(C_word c,C_word t0,C_word t1) C_noret;
static void f_11744(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11495(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_11609(C_word c,C_word t0,C_word t1) C_noret;
static void f_11568(C_word c,C_word t0,C_word t1) C_noret;
static void f_11527(C_word c,C_word t0,C_word t1) C_noret;
static void f_11534(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_11436(C_word c,C_word t0,C_word t1) C_noret;
static void f_11404(C_word c,C_word t0,C_word t1) C_noret;
static void f_11417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_11407(C_word c,C_word t0,C_word t1) C_noret;
static void f_11411(C_word c,C_word t0,C_word t1) C_noret;
static void f_11386(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11458(C_word t0,C_word t1,C_word t2) C_noret;
static void f_11463(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11472(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_11329(C_word t0,C_word t1,C_word t2) C_noret;
static void f_11353(C_word c,C_word t0,C_word t1) C_noret;
static void f_11490(C_word c,C_word t0,C_word t1) C_noret;
static void f_9882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_11281(C_word c,C_word t0,C_word t1) C_noret;
static void f_11284(C_word c,C_word t0,C_word t1) C_noret;
static void f_11290(C_word c,C_word t0,C_word t1) C_noret;
static void f_11309(C_word c,C_word t0,C_word t1) C_noret;
static void f_11293(C_word c,C_word t0,C_word t1) C_noret;
static void f_11296(C_word c,C_word t0,C_word t1) C_noret;
static void f_11299(C_word c,C_word t0,C_word t1) C_noret;
static void f_11302(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10888(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10916(C_word c,C_word t0,C_word t1) C_noret;
static void f_10919(C_word c,C_word t0,C_word t1) C_noret;
static void f_11266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_11278(C_word c,C_word t0,C_word t1) C_noret;
static void f_11274(C_word c,C_word t0,C_word t1) C_noret;
static void f_10922(C_word c,C_word t0,C_word t1) C_noret;
static void f_11205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_11211(C_word t0,C_word t1,C_word t2) C_noret;
static void f_11264(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_11231(C_word t0,C_word t1) C_noret;
static void f_11254(C_word c,C_word t0,C_word t1) C_noret;
static void f_11236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_11240(C_word c,C_word t0,C_word t1) C_noret;
static void f_11250(C_word c,C_word t0,C_word t1) C_noret;
static void f_11215(C_word c,C_word t0,C_word t1) C_noret;
static void f_10925(C_word c,C_word t0,C_word t1) C_noret;
static void f_10928(C_word c,C_word t0,C_word t1) C_noret;
static void f_11203(C_word c,C_word t0,C_word t1) C_noret;
static void f_10969(C_word c,C_word t0,C_word t1) C_noret;
static void f_10973(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_11171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_11165(C_word c,C_word t0,C_word t1) C_noret;
static void f_11105(C_word c,C_word t0,C_word t1) C_noret;
static void f_11163(C_word c,C_word t0,C_word t1) C_noret;
static void f_11108(C_word c,C_word t0,C_word t1) C_noret;
static void f_11111(C_word c,C_word t0,C_word t1) C_noret;
static void f_11114(C_word c,C_word t0,C_word t1) C_noret;
static void f_11155(C_word c,C_word t0,C_word t1) C_noret;
static void f_11117(C_word c,C_word t0,C_word t1) C_noret;
static void f_11120(C_word c,C_word t0,C_word t1) C_noret;
static void f_11135(C_word c,C_word t0,C_word t1) C_noret;
static void f_11127(C_word c,C_word t0,C_word t1) C_noret;
static void f_11131(C_word c,C_word t0,C_word t1) C_noret;
static void f_11094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_11088(C_word c,C_word t0,C_word t1) C_noret;
static void f_11048(C_word c,C_word t0,C_word t1) C_noret;
static void f_11086(C_word c,C_word t0,C_word t1) C_noret;
static void f_11051(C_word c,C_word t0,C_word t1) C_noret;
static void f_11054(C_word c,C_word t0,C_word t1) C_noret;
static void f_11057(C_word c,C_word t0,C_word t1) C_noret;
static void f_11082(C_word c,C_word t0,C_word t1) C_noret;
static void f_11060(C_word c,C_word t0,C_word t1) C_noret;
static void f_11063(C_word c,C_word t0,C_word t1) C_noret;
static void f_11074(C_word c,C_word t0,C_word t1) C_noret;
static void f_10999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_11003(C_word c,C_word t0,C_word t1) C_noret;
static void f_11018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_11026(C_word c,C_word t0,C_word t1) C_noret;
static void f_11006(C_word c,C_word t0,C_word t1) C_noret;
static void f_10993(C_word c,C_word t0,C_word t1) C_noret;
static void f_10983(C_word c,C_word t0,C_word t1) C_noret;
static void f_10933(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10905(C_word c,C_word t0,C_word t1) C_noret;
static void f_10913(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_10725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_10708(C_word c,C_word t0,C_word t1) C_noret;
static void f_10692(C_word c,C_word t0,C_word t1) C_noret;
static void f_10705(C_word c,C_word t0,C_word t1) C_noret;
static void f_10686(C_word c,C_word t0,C_word t1) C_noret;
static void f_10662(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10610(C_word t0,C_word t1) C_noret;
static void f_10613(C_word c,C_word t0,C_word t1) C_noret;
static void f_10567(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10579(C_word t0,C_word t1) C_noret;
static void C_fcall f_10570(C_word t0,C_word t1) C_noret;
static void f_10573(C_word c,C_word t0,C_word t1) C_noret;
static void f_10447(C_word c,C_word t0,C_word t1) C_noret;
static void f_10548(C_word c,C_word t0,C_word t1) C_noret;
static void f_10536(C_word c,C_word t0,C_word t1) C_noret;
static void f_10475(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10481(C_word t0,C_word t1) C_noret;
static void f_10505(C_word c,C_word t0,C_word t1) C_noret;
static void f_10497(C_word c,C_word t0,C_word t1) C_noret;
static void f_10463(C_word c,C_word t0,C_word t1) C_noret;
static void f_10406(C_word c,C_word t0,C_word t1) C_noret;
static void f_10418(C_word c,C_word t0,C_word t1) C_noret;
static void f_10422(C_word c,C_word t0,C_word t1) C_noret;
static void f_10410(C_word c,C_word t0,C_word t1) C_noret;
static void f_10222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_10343(C_word c,C_word t0,C_word t1) C_noret;
static void f_10349(C_word c,C_word t0,C_word t1) C_noret;
static void f_10374(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10355(C_word t0,C_word t1) C_noret;
static void f_10229(C_word c,C_word t0,C_word t1) C_noret;
static void f_10334(C_word c,C_word t0,C_word t1) C_noret;
static void f_10232(C_word c,C_word t0,C_word t1) C_noret;
static void f_10235(C_word c,C_word t0,C_word t1) C_noret;
static void f_10238(C_word c,C_word t0,C_word t1) C_noret;
static void f_10276(C_word c,C_word t0,C_word t1) C_noret;
static void f_10302(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10283(C_word t0,C_word t1) C_noret;
static void f_10287(C_word c,C_word t0,C_word t1) C_noret;
static void f_10260(C_word c,C_word t0,C_word t1) C_noret;
static void f_10166(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10175(C_word t0,C_word t1) C_noret;
static void C_fcall f_10169(C_word t0,C_word t1) C_noret;
static void f_10150(C_word c,C_word t0,C_word t1) C_noret;
static void f_10123(C_word c,C_word t0,C_word t1) C_noret;
static void f_10106(C_word c,C_word t0,C_word t1) C_noret;
static void f_10102(C_word c,C_word t0,C_word t1) C_noret;
static void f_10095(C_word c,C_word t0,C_word t1) C_noret;
static void f_10078(C_word c,C_word t0,C_word t1) C_noret;
static void f_10074(C_word c,C_word t0,C_word t1) C_noret;
static void f_10050(C_word c,C_word t0,C_word t1) C_noret;
static void f_10030(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_9889(C_word c,C_word t0,C_word t1) C_noret;
static void f_9904(C_word c,C_word t0,C_word t1) C_noret;
static void f_9914(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9964(C_word c,C_word t0,C_word t1) C_noret;
static void f_9923(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9929(C_word t0,C_word t1) C_noret;
static void f_9939(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10731(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10738(C_word c,C_word t0,C_word t1) C_noret;
static void f_10776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10744(C_word c,C_word t0,C_word t1) C_noret;
static void f_10753(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10808(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10831(C_word c,C_word t0,C_word t1) C_noret;
static void f_10838(C_word c,C_word t0,C_word t1) C_noret;
static void f_10812(C_word c,C_word t0,C_word t1) C_noret;
static void f_10822(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10794(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10802(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10840(C_word t0,C_word t1) C_noret;
static void f_10844(C_word c,C_word t0,C_word t1) C_noret;
static void f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16,C_word t17) C_noret;
static void f_8352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9549(C_word c,C_word t0,C_word t1) C_noret;
static void f_9552(C_word c,C_word t0,C_word t1) C_noret;
static void f_9555(C_word c,C_word t0,C_word t1) C_noret;
static void f_9558(C_word c,C_word t0,C_word t1) C_noret;
static void f_9561(C_word c,C_word t0,C_word t1) C_noret;
static void f_9576(C_word c,C_word t0,C_word t1) C_noret;
static void f_9574(C_word c,C_word t0,C_word t1) C_noret;
static void f_9564(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_9407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_8731(C_word t0,C_word t1) C_noret;
static void C_fcall f_8764(C_word t0,C_word t1) C_noret;
static void f_9291(C_word c,C_word t0,C_word t1) C_noret;
static void f_9287(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9280(C_word t0,C_word t1) C_noret;
static void f_9131(C_word c,C_word t0,C_word t1) C_noret;
static void f_9137(C_word c,C_word t0,C_word t1) C_noret;
static void f_9207(C_word c,C_word t0,C_word t1) C_noret;
static void f_9237(C_word c,C_word t0,C_word t1) C_noret;
static void f_9220(C_word c,C_word t0,C_word t1) C_noret;
static void f_9224(C_word c,C_word t0,C_word t1) C_noret;
static void f_9146(C_word c,C_word t0,C_word t1) C_noret;
static void f_9193(C_word c,C_word t0,C_word t1) C_noret;
static void f_9197(C_word c,C_word t0,C_word t1) C_noret;
static void f_9173(C_word c,C_word t0,C_word t1) C_noret;
static void f_9169(C_word c,C_word t0,C_word t1) C_noret;
static void f_8860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_9109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8864(C_word c,C_word t0,C_word t1) C_noret;
static void f_9107(C_word c,C_word t0,C_word t1) C_noret;
static void f_8867(C_word c,C_word t0,C_word t1) C_noret;
static void f_8870(C_word c,C_word t0,C_word t1) C_noret;
static void f_8876(C_word c,C_word t0,C_word t1) C_noret;
static void f_8882(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8888(C_word t0,C_word t1) C_noret;
static void f_9074(C_word c,C_word t0,C_word t1) C_noret;
static void f_9077(C_word c,C_word t0,C_word t1) C_noret;
static void f_8891(C_word c,C_word t0,C_word t1) C_noret;
static void f_9050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9035(C_word c,C_word t0,C_word t1) C_noret;
static void f_9031(C_word c,C_word t0,C_word t1) C_noret;
static void f_8965(C_word c,C_word t0,C_word t1) C_noret;
static void f_8990(C_word c,C_word t0,C_word t1) C_noret;
static void f_8996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9007(C_word c,C_word t0,C_word t1) C_noret;
static void f_8994(C_word c,C_word t0,C_word t1) C_noret;
static void f_8976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8968(C_word c,C_word t0,C_word t1) C_noret;
static void f_8953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8961(C_word c,C_word t0,C_word t1) C_noret;
static void f_8914(C_word c,C_word t0,C_word t1) C_noret;
static void f_8944(C_word c,C_word t0,C_word t1) C_noret;
static void f_8936(C_word c,C_word t0,C_word t1) C_noret;
static void f_8932(C_word c,C_word t0,C_word t1) C_noret;
static void f_8928(C_word c,C_word t0,C_word t1) C_noret;
static void f_8917(C_word c,C_word t0,C_word t1) C_noret;
static void f_8785(C_word c,C_word t0,C_word t1) C_noret;
static void f_8788(C_word c,C_word t0,C_word t1) C_noret;
static void f_8840(C_word c,C_word t0,C_word t1) C_noret;
static void f_8804(C_word c,C_word t0,C_word t1) C_noret;
static void f_8833(C_word c,C_word t0,C_word t1) C_noret;
static void f_8825(C_word c,C_word t0,C_word t1) C_noret;
static void f_8770(C_word c,C_word t0,C_word t1) C_noret;
static void f_8743(C_word c,C_word t0,C_word t1) C_noret;
static void f_8749(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9420(C_word c,C_word t0,C_word t1) C_noret;
static void f_9436(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8382(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_8401(C_word t0,C_word t1) C_noret;
static void f_8676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_9452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9490(C_word t0,C_word t1) C_noret;
static void f_9516(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9502(C_word t0,C_word t1) C_noret;
static void f_9481(C_word c,C_word t0,C_word t1) C_noret;
static void f_9450(C_word c,C_word t0,C_word t1) C_noret;
static void f_8650(C_word c,C_word t0,C_word t1) C_noret;
static void f_8653(C_word c,C_word t0,C_word t1) C_noret;
static void f_8664(C_word c,C_word t0,C_word t1) C_noret;
static void f_8601(C_word c,C_word t0,C_word t1) C_noret;
static void f_8497(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8503(C_word t0,C_word t1) C_noret;
static void f_8515(C_word c,C_word t0,C_word t1) C_noret;
static void f_8518(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8521(C_word t0,C_word t1) C_noret;
static void C_fcall f_8539(C_word t0,C_word t1) C_noret;
static void f_8524(C_word c,C_word t0,C_word t1) C_noret;
static void f_8527(C_word c,C_word t0,C_word t1) C_noret;
static void f_8530(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8491(C_word t0,C_word t1) C_noret;
static void C_fcall f_8481(C_word t0,C_word t1) C_noret;
static void f_8464(C_word c,C_word t0,C_word t1) C_noret;
static void f_8469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8426(C_word c,C_word t0,C_word t1) C_noret;
static void f_8437(C_word c,C_word t0,C_word t1) C_noret;
static void f_8412(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8371(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8380(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8361(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8366(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8355(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6839(C_word c,C_word t0,C_word t1) C_noret;
static void f_7592(C_word c,C_word t0,C_word t1) C_noret;
static void f_7595(C_word c,C_word t0,C_word t1) C_noret;
static void f_7599(C_word c,C_word t0,C_word t1) C_noret;
static void f_7602(C_word c,C_word t0,C_word t1) C_noret;
static void f_7615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7619(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8204(C_word t0,C_word t1) C_noret;
static void f_7626(C_word c,C_word t0,C_word t1) C_noret;
static void f_8173(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8179(C_word t0,C_word t1) C_noret;
static void f_7629(C_word c,C_word t0,C_word t1) C_noret;
static void f_7632(C_word c,C_word t0,C_word t1) C_noret;
static void f_8153(C_word c,C_word t0,C_word t1) C_noret;
static void f_8145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8113(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8119(C_word t0,C_word t1) C_noret;
static void f_7635(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8075(C_word t0,C_word t1) C_noret;
static void f_8084(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8087(C_word t0,C_word t1) C_noret;
static void f_7638(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7970(C_word t0,C_word t1) C_noret;
static void f_7988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8059(C_word c,C_word t0,C_word t1) C_noret;
static void f_8055(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8041(C_word t0,C_word t1) C_noret;
static void f_8044(C_word c,C_word t0,C_word t1) C_noret;
static void f_7992(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7998(C_word t0,C_word t1) C_noret;
static void f_7641(C_word c,C_word t0,C_word t1) C_noret;
static void f_7948(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7934(C_word t0,C_word t1) C_noret;
static void f_7941(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7922(C_word t0,C_word t1) C_noret;
static void C_fcall f_7907(C_word t0,C_word t1) C_noret;
static void f_7644(C_word c,C_word t0,C_word t1) C_noret;
static void f_7819(C_word c,C_word t0,C_word t1) C_noret;
static void f_7893(C_word c,C_word t0,C_word t1) C_noret;
static void f_7825(C_word c,C_word t0,C_word t1) C_noret;
static void f_7883(C_word c,C_word t0,C_word t1) C_noret;
static void f_7875(C_word c,C_word t0,C_word t1) C_noret;
static void f_7871(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7828(C_word t0,C_word t1) C_noret;
static void f_7831(C_word c,C_word t0,C_word t1) C_noret;
static void f_7647(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7678(C_word t0,C_word t1) C_noret;
static void C_fcall f_7699(C_word t0,C_word t1) C_noret;
static void C_fcall f_7720(C_word t0,C_word t1) C_noret;
static void f_7726(C_word c,C_word t0,C_word t1) C_noret;
static void f_7650(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7656(C_word t0,C_word t1) C_noret;
static void f_7660(C_word c,C_word t0,C_word t1) C_noret;
static void f_7605(C_word c,C_word t0,C_word t1) C_noret;
static void f_7609(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7612(C_word t0,C_word t1) C_noret;
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7577(C_word c,C_word t0,C_word t1) C_noret;
static void f_7585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7561(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_7435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_6870(C_word t0,C_word t1) C_noret;
static void f_7391(C_word c,C_word t0,C_word t1) C_noret;
static void f_7385(C_word c,C_word t0,C_word t1) C_noret;
static void f_7358(C_word c,C_word t0,C_word t1) C_noret;
static void f_7367(C_word c,C_word t0,C_word t1) C_noret;
static void f_7352(C_word c,C_word t0,C_word t1) C_noret;
static void f_7277(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7306(C_word t0,C_word t1) C_noret;
static void C_fcall f_7321(C_word t0,C_word t1) C_noret;
static void f_7325(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7312(C_word t0,C_word t1) C_noret;
static void f_7280(C_word c,C_word t0,C_word t1) C_noret;
static void f_7303(C_word c,C_word t0,C_word t1) C_noret;
static void f_7283(C_word c,C_word t0,C_word t1) C_noret;
static void f_7286(C_word c,C_word t0,C_word t1) C_noret;
static void f_7289(C_word c,C_word t0,C_word t1) C_noret;
static void f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7259(C_word c,C_word t0,C_word t1) C_noret;
static void f_7174(C_word c,C_word t0,C_word t1) C_noret;
static void f_7249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7253(C_word c,C_word t0,C_word t1) C_noret;
static void f_7177(C_word c,C_word t0,C_word t1) C_noret;
static void f_7180(C_word c,C_word t0,C_word t1) C_noret;
static void f_7234(C_word c,C_word t0,C_word t1) C_noret;
static void f_7183(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7186(C_word t0,C_word t1) C_noret;
static void C_fcall f_7219(C_word t0,C_word t1) C_noret;
static void C_fcall f_7189(C_word t0,C_word t1) C_noret;
static void f_7216(C_word c,C_word t0,C_word t1) C_noret;
static void f_7192(C_word c,C_word t0,C_word t1) C_noret;
static void f_7123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7127(C_word c,C_word t0,C_word t1) C_noret;
static void f_7140(C_word c,C_word t0,C_word t1) C_noret;
static void f_7131(C_word c,C_word t0,C_word t1) C_noret;
static void f_7056(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7061(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7088(C_word c,C_word t0,C_word t1) C_noret;
static void f_7091(C_word c,C_word t0,C_word t1) C_noret;
static void f_7094(C_word c,C_word t0,C_word t1) C_noret;
static void f_7079(C_word c,C_word t0,C_word t1) C_noret;
static void f_6984(C_word c,C_word t0,C_word t1) C_noret;
static void f_7032(C_word c,C_word t0,C_word t1) C_noret;
static void f_6995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7014(C_word c,C_word t0,C_word t1) C_noret;
static void f_6961(C_word c,C_word t0,C_word t1) C_noret;
static void f_6964(C_word c,C_word t0,C_word t1) C_noret;
static void f_6925(C_word c,C_word t0,C_word t1) C_noret;
static void f_6882(C_word c,C_word t0,C_word t1) C_noret;
static void f_6913(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7441(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_7454(C_word t0,C_word t1) C_noret;
static void f_7514(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7463(C_word t0,C_word t1) C_noret;
static void f_7466(C_word c,C_word t0,C_word t1) C_noret;
static void f_7469(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7547(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_6841(C_word t0);
static void f_6826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_6058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6620(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6646(C_word c,C_word t0,C_word t1) C_noret;
static void f_6664(C_word c,C_word t0,C_word t1) C_noret;
static void f_6673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6699(C_word c,C_word t0,C_word t1) C_noret;
static void f_6687(C_word c,C_word t0,C_word t1) C_noret;
static void f_6640(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_6610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_6483(C_word c,C_word t0,C_word t1) C_noret;
static void f_6486(C_word c,C_word t0,C_word t1) C_noret;
static void f_6540(C_word c,C_word t0,C_word t1) C_noret;
static void f_6536(C_word c,C_word t0,C_word t1) C_noret;
static void f_6532(C_word c,C_word t0,C_word t1) C_noret;
static void f_6511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6528(C_word c,C_word t0,C_word t1) C_noret;
static void f_6521(C_word c,C_word t0,C_word t1) C_noret;
static void f_6509(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6127(C_word t0,C_word t1) C_noret;
static void C_fcall f_6393(C_word t0,C_word t1) C_noret;
static void f_6550(C_word c,C_word t0,C_word t1) C_noret;
static void f_6553(C_word c,C_word t0,C_word t1) C_noret;
static void f_6598(C_word c,C_word t0,C_word t1) C_noret;
static void f_6594(C_word c,C_word t0,C_word t1) C_noret;
static void f_6590(C_word c,C_word t0,C_word t1) C_noret;
static void f_6586(C_word c,C_word t0,C_word t1) C_noret;
static void f_6358(C_word c,C_word t0,C_word t1) C_noret;
static void f_6384(C_word c,C_word t0,C_word t1) C_noret;
static void f_6308(C_word c,C_word t0,C_word t1) C_noret;
static void f_6317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6345(C_word c,C_word t0,C_word t1) C_noret;
static void f_6341(C_word c,C_word t0,C_word t1) C_noret;
static void f_6295(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6233(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6270(C_word c,C_word t0,C_word t1) C_noret;
static void f_6139(C_word c,C_word t0,C_word t1) C_noret;
static void f_6142(C_word c,C_word t0,C_word t1) C_noret;
static void f_6218(C_word c,C_word t0,C_word t1) C_noret;
static void f_6214(C_word c,C_word t0,C_word t1) C_noret;
static void f_6210(C_word c,C_word t0,C_word t1) C_noret;
static void f_6183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6194(C_word c,C_word t0,C_word t1) C_noret;
static void f_6198(C_word c,C_word t0,C_word t1) C_noret;
static void f_6177(C_word c,C_word t0,C_word t1) C_noret;
static void f_6143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6154(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6061(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_6065(C_word c,C_word t0,C_word t1) C_noret;
static void f_6088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6099(C_word c,C_word t0,C_word t1) C_noret;
static void f_6082(C_word c,C_word t0,C_word t1) C_noret;
static void f_5968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6000(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6019(C_word c,C_word t0,C_word t1) C_noret;
static void f_6042(C_word c,C_word t0,C_word t1) C_noret;
static void f_6025(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5987(C_word c,C_word t0,C_word t1) C_noret;
static void f_5884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5888(C_word t0,C_word t1) C_noret;
static void C_fcall f_5891(C_word t0,C_word t1) C_noret;
static void C_fcall f_5894(C_word t0,C_word t1) C_noret;
static void f_5913(C_word c,C_word t0,C_word t1) C_noret;
static void f_5897(C_word c,C_word t0,C_word t1) C_noret;
static void f_5900(C_word c,C_word t0,C_word t1) C_noret;
static void f_5903(C_word c,C_word t0,C_word t1) C_noret;
static void f_5906(C_word c,C_word t0,C_word t1) C_noret;
static void f_5844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5870(C_word c,C_word t0,C_word t1) C_noret;
static void f_5854(C_word c,C_word t0,C_word t1) C_noret;
static void f_5857(C_word c,C_word t0,C_word t1) C_noret;
static void f_5860(C_word c,C_word t0,C_word t1) C_noret;
static void f_5863(C_word c,C_word t0,C_word t1) C_noret;
static void f_5804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5830(C_word c,C_word t0,C_word t1) C_noret;
static void f_5814(C_word c,C_word t0,C_word t1) C_noret;
static void f_5817(C_word c,C_word t0,C_word t1) C_noret;
static void f_5820(C_word c,C_word t0,C_word t1) C_noret;
static void f_5823(C_word c,C_word t0,C_word t1) C_noret;
static void f_5759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5766(C_word c,C_word t0,C_word t1) C_noret;
static void f_5772(C_word c,C_word t0,C_word t1) C_noret;
static void f_5714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5721(C_word c,C_word t0,C_word t1) C_noret;
static void f_5727(C_word c,C_word t0,C_word t1) C_noret;
static void f_5560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_5708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5564(C_word c,C_word t0,C_word t1) C_noret;
static void f_5567(C_word c,C_word t0,C_word t1) C_noret;
static void f_5570(C_word c,C_word t0,C_word t1) C_noret;
static void f_5573(C_word c,C_word t0,C_word t1) C_noret;
static void f_5576(C_word c,C_word t0,C_word t1) C_noret;
static void f_5702(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5586(C_word t0,C_word t1) C_noret;
static void f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5685(C_word c,C_word t0,C_word t1) C_noret;
static void f_5589(C_word c,C_word t0,C_word t1) C_noret;
static void f_5629(C_word c,C_word t0,C_word t1) C_noret;
static void f_5632(C_word c,C_word t0,C_word t1) C_noret;
static void f_5651(C_word c,C_word t0,C_word t1) C_noret;
static void f_5647(C_word c,C_word t0,C_word t1) C_noret;
static void f_5643(C_word c,C_word t0,C_word t1) C_noret;
static void f_5622(C_word c,C_word t0,C_word t1) C_noret;
static void f_5612(C_word c,C_word t0,C_word t1) C_noret;
static void f_5600(C_word c,C_word t0,C_word t1) C_noret;
static void f_5596(C_word c,C_word t0,C_word t1) C_noret;
static void f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
static void f_4459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4517(C_word c,C_word t0,C_word t1) C_noret;
static void f_5348(C_word c,C_word t0,C_word t1) C_noret;
static void f_5360(C_word c,C_word t0,C_word t1) C_noret;
static void f_5377(C_word c,C_word t0,C_word t1) C_noret;
static void f_5373(C_word c,C_word t0,C_word t1) C_noret;
static void f_5326(C_word c,C_word t0,C_word t1) C_noret;
static void f_5333(C_word c,C_word t0,C_word t1) C_noret;
static void f_5309(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5229(C_word t0,C_word t1) C_noret;
static void C_fcall f_5238(C_word t0,C_word t1) C_noret;
static void f_5211(C_word c,C_word t0,C_word t1) C_noret;
static void f_5215(C_word c,C_word t0,C_word t1) C_noret;
static void f_5198(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5190(C_word t0,C_word t1) C_noret;
static void f_5194(C_word c,C_word t0,C_word t1) C_noret;
static void f_5028(C_word c,C_word t0,C_word t1) C_noret;
static void f_5138(C_word c,C_word t0,C_word t1) C_noret;
static void f_5127(C_word c,C_word t0,C_word t1) C_noret;
static void f_5131(C_word c,C_word t0,C_word t1) C_noret;
static void f_5098(C_word c,C_word t0,C_word t1) C_noret;
static void f_5073(C_word c,C_word t0,C_word t1) C_noret;
static void f_5048(C_word c,C_word t0,C_word t1) C_noret;
static void f_4981(C_word c,C_word t0,C_word t1) C_noret;
static void f_4990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4988(C_word c,C_word t0,C_word t1) C_noret;
static void f_4984(C_word c,C_word t0,C_word t1) C_noret;
static void f_4964(C_word c,C_word t0,C_word t1) C_noret;
static void f_4947(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4891(C_word t0,C_word t1) C_noret;
static void f_4854(C_word c,C_word t0,C_word t1) C_noret;
static void f_4873(C_word c,C_word t0,C_word t1) C_noret;
static void f_4869(C_word c,C_word t0,C_word t1) C_noret;
static void f_4865(C_word c,C_word t0,C_word t1) C_noret;
static void f_4861(C_word c,C_word t0,C_word t1) C_noret;
static void f_4832(C_word c,C_word t0,C_word t1) C_noret;
static void f_4836(C_word c,C_word t0,C_word t1) C_noret;
static void f_4822(C_word c,C_word t0,C_word t1) C_noret;
static void f_4829(C_word c,C_word t0,C_word t1) C_noret;
static void f_4798(C_word c,C_word t0,C_word t1) C_noret;
static void f_4802(C_word c,C_word t0,C_word t1) C_noret;
static void f_4777(C_word c,C_word t0,C_word t1) C_noret;
static void f_4694(C_word c,C_word t0,C_word t1) C_noret;
static void f_4677(C_word c,C_word t0,C_word t1) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1) C_noret;
static void f_4648(C_word c,C_word t0,C_word t1) C_noret;
static void f_4623(C_word c,C_word t0,C_word t1) C_noret;
static void f_4576(C_word c,C_word t0,C_word t1) C_noret;
static void f_4606(C_word c,C_word t0,C_word t1) C_noret;
static void f_4582(C_word c,C_word t0,C_word t1) C_noret;
static void f_4585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4592(C_word t0,C_word t1) C_noret;
static void f_4588(C_word c,C_word t0,C_word t1) C_noret;
static void f_4532(C_word c,C_word t0,C_word t1) C_noret;
static void f_4566(C_word c,C_word t0,C_word t1) C_noret;
static void f_4560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4541(C_word c,C_word t0,C_word t1) C_noret;
static void f_4550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4558(C_word c,C_word t0,C_word t1) C_noret;
static void f_4544(C_word c,C_word t0,C_word t1) C_noret;
static void f_4548(C_word c,C_word t0,C_word t1) C_noret;
static void f_4523(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4485(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4475(C_word t0,C_word t1) C_noret;
static void f_2074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4454(C_word c,C_word t0,C_word t1) C_noret;
static void f_4420(C_word c,C_word t0,C_word t1) C_noret;
static void f_4435(C_word c,C_word t0,C_word t1) C_noret;
static void f_4444(C_word c,C_word t0,C_word t1) C_noret;
static void f_4448(C_word c,C_word t0,C_word t1) C_noret;
static void f_4431(C_word c,C_word t0,C_word t1) C_noret;
static void f_4427(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4407(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2273(C_word c,C_word t0,C_word t1) C_noret;
static void f_4277(C_word c,C_word t0,C_word t1) C_noret;
static void f_4383(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4289(C_word t0,C_word t1) C_noret;
static void f_4298(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4307(C_word t0,C_word t1) C_noret;
static void f_4329(C_word c,C_word t0,C_word t1) C_noret;
static void f_4344(C_word c,C_word t0,C_word t1) C_noret;
static void f_4322(C_word c,C_word t0,C_word t1) C_noret;
static void f_4318(C_word c,C_word t0,C_word t1) C_noret;
static void f_4314(C_word c,C_word t0,C_word t1) C_noret;
static void f_4280(C_word c,C_word t0,C_word t1) C_noret;
static void f_2300(C_word c,C_word t0,C_word t1) C_noret;
static void f_2306(C_word c,C_word t0,C_word t1) C_noret;
static void f_2313(C_word c,C_word t0,C_word t1) C_noret;
static void f_2322(C_word c,C_word t0,C_word t1) C_noret;
static void f_2331(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2492(C_word t0,C_word t1) C_noret;
static void f_4121(C_word c,C_word t0,C_word t1) C_noret;
static void f_4181(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4081(C_word t0,C_word t1) C_noret;
static void f_4085(C_word c,C_word t0,C_word t1) C_noret;
static void f_4091(C_word c,C_word t0,C_word t1) C_noret;
static void f_4105(C_word c,C_word t0,C_word t1) C_noret;
static void f_4094(C_word c,C_word t0,C_word t1) C_noret;
static void f_3906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4065(C_word c,C_word t0,C_word t1) C_noret;
static void f_3928(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4030(C_word t0,C_word t1) C_noret;
static void f_3931(C_word c,C_word t0,C_word t1) C_noret;
static void f_3942(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4024(C_word c,C_word t0,C_word t1) C_noret;
static void f_4020(C_word c,C_word t0,C_word t1) C_noret;
static void f_4016(C_word c,C_word t0,C_word t1) C_noret;
static void f_4004(C_word c,C_word t0,C_word t1) C_noret;
static void f_3962(C_word c,C_word t0,C_word t1) C_noret;
static void f_3974(C_word c,C_word t0,C_word t1) C_noret;
static void f_3970(C_word c,C_word t0,C_word t1) C_noret;
static void f_3966(C_word c,C_word t0,C_word t1) C_noret;
static void f_3950(C_word c,C_word t0,C_word t1) C_noret;
static void f_3938(C_word c,C_word t0,C_word t1) C_noret;
static void f_3896(C_word c,C_word t0,C_word t1) C_noret;
static void f_3873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3871(C_word c,C_word t0,C_word t1) C_noret;
static void f_3867(C_word c,C_word t0,C_word t1) C_noret;
static void f_3800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3818(C_word c,C_word t0,C_word t1) C_noret;
static void f_3840(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3840r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_3846(C_word c,C_word t0,C_word t1) C_noret;
static void f_3824(C_word c,C_word t0,C_word t1) C_noret;
static void f_3831(C_word c,C_word t0,C_word t1) C_noret;
static void f_3806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3812(C_word c,C_word t0,C_word t1) C_noret;
static void f_3798(C_word c,C_word t0,C_word t1) C_noret;
static void f_3736(C_word c,C_word t0,C_word t1) C_noret;
static void f_3747(C_word c,C_word t0,C_word t1) C_noret;
static void f_3757(C_word c,C_word t0,C_word t1) C_noret;
static void f_3760(C_word c,C_word t0,C_word t1) C_noret;
static void f_3764(C_word c,C_word t0,C_word t1) C_noret;
static void f_3750(C_word c,C_word t0,C_word t1) C_noret;
static void f_3675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3679(C_word c,C_word t0,C_word t1) C_noret;
static void f_3717(C_word c,C_word t0,C_word t1) C_noret;
static void f_3683(C_word c,C_word t0,C_word t1) C_noret;
static void f_3697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3695(C_word c,C_word t0,C_word t1) C_noret;
static void f_3691(C_word c,C_word t0,C_word t1) C_noret;
static void f_3657(C_word c,C_word t0,C_word t1) C_noret;
static void f_3665(C_word c,C_word t0,C_word t1) C_noret;
static void f_3530(C_word c,C_word t0,C_word t1) C_noret;
static void f_3533(C_word c,C_word t0,C_word t1) C_noret;
static void f_3539(C_word c,C_word t0,C_word t1) C_noret;
static void f_3618(C_word c,C_word t0,C_word t1) C_noret;
static void f_3595(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3570(C_word t0,C_word t1) C_noret;
static void f_3578(C_word c,C_word t0,C_word t1) C_noret;
static void f_3566(C_word c,C_word t0,C_word t1) C_noret;
static void f_3558(C_word c,C_word t0,C_word t1) C_noret;
static void f_3562(C_word c,C_word t0,C_word t1) C_noret;
static void f_3554(C_word c,C_word t0,C_word t1) C_noret;
static void f_3455(C_word c,C_word t0,C_word t1) C_noret;
static void f_3464(C_word c,C_word t0,C_word t1) C_noret;
static void f_3503(C_word c,C_word t0,C_word t1) C_noret;
static void f_3495(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3467(C_word t0,C_word t1) C_noret;
static void f_3487(C_word c,C_word t0,C_word t1) C_noret;
static void f_3479(C_word c,C_word t0,C_word t1) C_noret;
static void f_3435(C_word c,C_word t0,C_word t1) C_noret;
static void f_3381(C_word c,C_word t0,C_word t1) C_noret;
static void f_3384(C_word c,C_word t0,C_word t1) C_noret;
static void f_3387(C_word c,C_word t0,C_word t1) C_noret;
static void f_3391(C_word c,C_word t0,C_word t1) C_noret;
static void f_3395(C_word c,C_word t0,C_word t1) C_noret;
static void f_3311(C_word c,C_word t0,C_word t1) C_noret;
static void f_3314(C_word c,C_word t0,C_word t1) C_noret;
static void f_3326(C_word c,C_word t0,C_word t1) C_noret;
static void f_3296(C_word c,C_word t0,C_word t1) C_noret;
static void f_3283(C_word c,C_word t0,C_word t1) C_noret;
static void f_3270(C_word c,C_word t0,C_word t1) C_noret;
static void f_3257(C_word c,C_word t0,C_word t1) C_noret;
static void f_3244(C_word c,C_word t0,C_word t1) C_noret;
static void f_3177(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3223(C_word c,C_word t0,C_word t1) C_noret;
static void f_3227(C_word c,C_word t0,C_word t1) C_noret;
static void f_3216(C_word c,C_word t0,C_word t1) C_noret;
static void f_3190(C_word c,C_word t0,C_word t1) C_noret;
static void f_3164(C_word c,C_word t0,C_word t1) C_noret;
static void f_3149(C_word c,C_word t0,C_word t1) C_noret;
static void f_3122(C_word c,C_word t0,C_word t1) C_noret;
static void f_3126(C_word c,C_word t0,C_word t1) C_noret;
static void f_3101(C_word c,C_word t0,C_word t1) C_noret;
static void f_3072(C_word c,C_word t0,C_word t1) C_noret;
static void f_3076(C_word c,C_word t0,C_word t1) C_noret;
static void f_3068(C_word c,C_word t0,C_word t1) C_noret;
static void f_3043(C_word c,C_word t0,C_word t1) C_noret;
static void f_3047(C_word c,C_word t0,C_word t1) C_noret;
static void f_3039(C_word c,C_word t0,C_word t1) C_noret;
static void f_2873(C_word c,C_word t0,C_word t1) C_noret;
static void f_2882(C_word c,C_word t0,C_word t1) C_noret;
static void f_2885(C_word c,C_word t0,C_word t1) C_noret;
static void f_3015(C_word c,C_word t0,C_word t1) C_noret;
static void f_3019(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2888(C_word t0,C_word t1) C_noret;
static void f_2998(C_word c,C_word t0,C_word t1) C_noret;
static void f_3005(C_word c,C_word t0,C_word t1) C_noret;
static void f_2891(C_word c,C_word t0,C_word t1) C_noret;
static void f_2986(C_word c,C_word t0,C_word t1) C_noret;
static void f_2894(C_word c,C_word t0,C_word t1) C_noret;
static void f_2949(C_word c,C_word t0,C_word t1) C_noret;
static void f_2980(C_word c,C_word t0,C_word t1) C_noret;
static void f_2972(C_word c,C_word t0,C_word t1) C_noret;
static void f_2906(C_word c,C_word t0,C_word t1) C_noret;
static void f_2937(C_word c,C_word t0,C_word t1) C_noret;
static void f_2925(C_word c,C_word t0,C_word t1) C_noret;
static void f_2835(C_word c,C_word t0,C_word t1) C_noret;
static void f_2861(C_word c,C_word t0,C_word t1) C_noret;
static void f_2838(C_word c,C_word t0,C_word t1) C_noret;
static void f_2853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2851(C_word c,C_word t0,C_word t1) C_noret;
static void f_2841(C_word c,C_word t0,C_word t1) C_noret;
static void f_2844(C_word c,C_word t0,C_word t1) C_noret;
static void f_2812(C_word c,C_word t0,C_word t1) C_noret;
static void f_2709(C_word c,C_word t0,C_word t1) C_noret;
static void f_2785(C_word c,C_word t0,C_word t1) C_noret;
static void f_2796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2790(C_word c,C_word t0,C_word t1) C_noret;
static void f_2718(C_word c,C_word t0,C_word t1) C_noret;
static void f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2727(C_word c,C_word t0,C_word t1) C_noret;
static void f_2782(C_word c,C_word t0,C_word t1) C_noret;
static void f_2730(C_word c,C_word t0,C_word t1) C_noret;
static void f_2774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2772(C_word c,C_word t0,C_word t1) C_noret;
static void f_2733(C_word c,C_word t0,C_word t1) C_noret;
static void f_2768(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2761(C_word t0,C_word t1) C_noret;
static void f_2736(C_word c,C_word t0,C_word t1) C_noret;
static void f_2739(C_word c,C_word t0,C_word t1) C_noret;
static void f_2635(C_word c,C_word t0,C_word t1) C_noret;
static void f_2641(C_word c,C_word t0,C_word t1) C_noret;
static void f_2644(C_word c,C_word t0,C_word t1) C_noret;
static void f_2697(C_word c,C_word t0,C_word t1) C_noret;
static void f_2647(C_word c,C_word t0,C_word t1) C_noret;
static void f_2650(C_word c,C_word t0,C_word t1) C_noret;
static void f_2677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2685(C_word c,C_word t0,C_word t1) C_noret;
static void f_2657(C_word c,C_word t0,C_word t1) C_noret;
static void f_2671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2665(C_word c,C_word t0,C_word t1) C_noret;
static void f_2661(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2587(C_word c,C_word t0,C_word t1) C_noret;
static void f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2626(C_word c,C_word t0,C_word t1) C_noret;
static void f_2616(C_word c,C_word t0,C_word t1) C_noret;
static void f_2602(C_word c,C_word t0,C_word t1) C_noret;
static void f_2609(C_word c,C_word t0,C_word t1) C_noret;
static void f_2592(C_word c,C_word t0,C_word t1) C_noret;
static void f_2571(C_word c,C_word t0,C_word t1) C_noret;
static void f_2501(C_word c,C_word t0,C_word t1) C_noret;
static void f_2504(C_word c,C_word t0,C_word t1) C_noret;
static void f_2553(C_word c,C_word t0,C_word t1) C_noret;
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2507(C_word c,C_word t0,C_word t1) C_noret;
static void f_2510(C_word c,C_word t0,C_word t1) C_noret;
static void f_2544(C_word c,C_word t0,C_word t1) C_noret;
static void f_2538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2513(C_word c,C_word t0,C_word t1) C_noret;
static void f_2532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2530(C_word c,C_word t0,C_word t1) C_noret;
static void f_2520(C_word c,C_word t0,C_word t1) C_noret;
static void f_2459(C_word c,C_word t0,C_word t1) C_noret;
static void f_2471(C_word c,C_word t0,C_word t1) C_noret;
static void f_2475(C_word c,C_word t0,C_word t1) C_noret;
static void f_2400(C_word c,C_word t0,C_word t1) C_noret;
static void f_2406(C_word c,C_word t0,C_word t1) C_noret;
static void f_2412(C_word c,C_word t0,C_word t1) C_noret;
static void f_2415(C_word c,C_word t0,C_word t1) C_noret;
static void f_2105(C_word c,C_word t0,C_word t1) C_noret;
static void f_2108(C_word c,C_word t0,C_word t1) C_noret;
static void f_2431(C_word c,C_word t0,C_word t1) C_noret;
static void f_2419(C_word c,C_word t0,C_word t1) C_noret;
static void f_2354(C_word c,C_word t0,C_word t1) C_noret;
static void f_2361(C_word c,C_word t0,C_word t1) C_noret;
static void f_2365(C_word c,C_word t0,C_word t1) C_noret;
static void f_2369(C_word c,C_word t0,C_word t1) C_noret;
static void f_2182(C_word c,C_word t0,C_word t1) C_noret;
static void f_2195(C_word c,C_word t0,C_word t1) C_noret;
static void f_2243(C_word c,C_word t0,C_word t1) C_noret;
static void f_2253(C_word c,C_word t0,C_word t1) C_noret;
static void f_2213(C_word c,C_word t0,C_word t1) C_noret;
static void f_2223(C_word c,C_word t0,C_word t1) C_noret;
static void f_2175(C_word c,C_word t0,C_word t1) C_noret;
static void f_2113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2120(C_word t0,C_word t1) C_noret;
static void C_fcall f_2089(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_2077(C_word t0,C_word t1);
static void f_2019(C_word c,C_word t0,C_word t1) C_noret;
static void f_2072(C_word c,C_word t0,C_word t1) C_noret;
static void f_2023(C_word c,C_word t0,C_word t1) C_noret;
static void f_2065(C_word c,C_word t0,C_word t1) C_noret;
static void f_2026(C_word c,C_word t0,C_word t1) C_noret;
static void f_2058(C_word c,C_word t0,C_word t1) C_noret;
static void f_2029(C_word c,C_word t0,C_word t1) C_noret;
static void f_2033(C_word c,C_word t0,C_word t1) C_noret;
static void f_2037(C_word c,C_word t0,C_word t1) C_noret;
static void f_2041(C_word c,C_word t0,C_word t1) C_noret;
static void f_2051(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_11769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11769(t0,t1);}

static void C_fcall trf_11730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11730(t0,t1);}

static void C_fcall trf_11686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11686(t0,t1);}

static void C_fcall trf_11495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11495(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11495(t0,t1,t2,t3,t4);}

static void C_fcall trf_11365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11365(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11365(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_11458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11458(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11458(t0,t1,t2);}

static void C_fcall trf_11472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11472(t0,t1,t2);}

static void C_fcall trf_11329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11329(t0,t1,t2);}

static void C_fcall trf_10888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10888(t0,t1,t2);}

static void C_fcall trf_11211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11211(t0,t1,t2);}

static void C_fcall trf_11231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11231(t0,t1);}

static void C_fcall trf_10975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10975(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10975(t0,t1,t2,t3);}

static void C_fcall trf_10891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10891(t0,t1,t2);}

static void C_fcall trf_10719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10719(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10719(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_9972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9972(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_9972(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_10610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10610(t0,t1);}

static void C_fcall trf_10579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10579(t0,t1);}

static void C_fcall trf_10570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10570(t0,t1);}

static void C_fcall trf_10481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10481(t0,t1);}

static void C_fcall trf_10355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10355(t0,t1);}

static void C_fcall trf_10283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10283(t0,t1);}

static void C_fcall trf_10175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10175(t0,t1);}

static void C_fcall trf_10169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10169(t0,t1);}

static void C_fcall trf_9885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9885(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9885(t0,t1,t2,t3,t4);}

static void C_fcall trf_9919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9919(t0,t1,t2,t3);}

static void C_fcall trf_9929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9929(t0,t1);}

static void C_fcall trf_10731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10731(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10731(t0,t1,t2);}

static void C_fcall trf_10808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10808(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10808(t0,t1,t2);}

static void C_fcall trf_10794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10794(t0,t1,t2);}

static void C_fcall trf_10840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10840(t0,t1);}

static void C_fcall trf_9401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9401(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9401(t0,t1,t2,t3,t4);}

static void C_fcall trf_8712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8712(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8712(t0,t1,t2,t3,t4);}

static void C_fcall trf_8731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8731(t0,t1);}

static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8764(t0,t1);}

static void C_fcall trf_9280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9280(t0,t1);}

static void C_fcall trf_8888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8888(t0,t1);}

static void C_fcall trf_9413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9413(t0,t1,t2,t3);}

static void C_fcall trf_8382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8382(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8382(t0,t1,t2,t3,t4);}

static void C_fcall trf_8401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8401(t0,t1);}

static void C_fcall trf_9490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9490(t0,t1);}

static void C_fcall trf_9502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9502(t0,t1);}

static void C_fcall trf_8503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8503(t0,t1);}

static void C_fcall trf_8521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8521(t0,t1);}

static void C_fcall trf_8539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8539(t0,t1);}

static void C_fcall trf_8491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8491(t0,t1);}

static void C_fcall trf_8481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8481(t0,t1);}

static void C_fcall trf_8371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8371(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8371(t0,t1,t2);}

static void C_fcall trf_8361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8361(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8361(t0,t1,t2,t3);}

static void C_fcall trf_8355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8355(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8355(t0,t1,t2,t3);}

static void C_fcall trf_8204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8204(t0,t1);}

static void C_fcall trf_8179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8179(t0,t1);}

static void C_fcall trf_8119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8119(t0,t1);}

static void C_fcall trf_8075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8075(t0,t1);}

static void C_fcall trf_8087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8087(t0,t1);}

static void C_fcall trf_7970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7970(t0,t1);}

static void C_fcall trf_8041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8041(t0,t1);}

static void C_fcall trf_7998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7998(t0,t1);}

static void C_fcall trf_7934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7934(t0,t1);}

static void C_fcall trf_7922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7922(t0,t1);}

static void C_fcall trf_7907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7907(t0,t1);}

static void C_fcall trf_7828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7828(t0,t1);}

static void C_fcall trf_7678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7678(t0,t1);}

static void C_fcall trf_7699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7699(t0,t1);}

static void C_fcall trf_7720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7720(t0,t1);}

static void C_fcall trf_7656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7656(t0,t1);}

static void C_fcall trf_7612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7612(t0,t1);}

static void C_fcall trf_7567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7567(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7567(t0,t1,t2,t3);}

static void C_fcall trf_7553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7553(t0,t1,t2,t3);}

static void C_fcall trf_7429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7429(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7429(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6848(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6848(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6870(t0,t1);}

static void C_fcall trf_7306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7306(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7306(t0,t1);}

static void C_fcall trf_7321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7321(t0,t1);}

static void C_fcall trf_7312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7312(t0,t1);}

static void C_fcall trf_7186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7186(t0,t1);}

static void C_fcall trf_7219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7219(t0,t1);}

static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7189(t0,t1);}

static void C_fcall trf_7061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7061(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7061(t0,t1,t2,t3);}

static void C_fcall trf_7441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7441(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7441(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_7454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7454(t0,t1);}

static void C_fcall trf_7463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7463(t0,t1);}

static void C_fcall trf_7547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7547(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7547(t0,t1,t2,t3);}

static void C_fcall trf_6620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6620(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6620(t0,t1,t2,t3);}

static void C_fcall trf_6626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6626(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6626(t0,t1,t2,t3);}

static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6604(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6479(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6479(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6105(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6105(t0,t1,t2,t3);}

static void C_fcall trf_6127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6127(t0,t1);}

static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6393(t0,t1);}

static void C_fcall trf_6233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6233(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6233(t0,t1,t2,t3);}

static void C_fcall trf_6061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6061(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6061(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6000(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6000(t0,t1,t2);}

static void C_fcall trf_5971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5971(t0,t1,t2);}

static void C_fcall trf_5977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5977(t0,t1,t2);}

static void C_fcall trf_5888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5888(t0,t1);}

static void C_fcall trf_5891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5891(t0,t1);}

static void C_fcall trf_5894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5894(t0,t1);}

static void C_fcall trf_5586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5586(t0,t1);}

static void C_fcall trf_5229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5229(t0,t1);}

static void C_fcall trf_5238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5238(t0,t1);}

static void C_fcall trf_5190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5190(t0,t1);}

static void C_fcall trf_4891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4891(t0,t1);}

static void C_fcall trf_4592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4592(t0,t1);}

static void C_fcall trf_4462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4462(t0,t1,t2,t3);}

static void C_fcall trf_4475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4475(t0,t1);}

static void C_fcall trf_4407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4407(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4407(t0,t1,t2,t3,t4);}

static void C_fcall trf_2155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2155(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2155(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4289(t0,t1);}

static void C_fcall trf_4307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4307(t0,t1);}

static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2492(t0,t1);}

static void C_fcall trf_4081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4081(t0,t1);}

static void C_fcall trf_4030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4030(t0,t1);}

static void C_fcall trf_3980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3980(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3980(t0,t1,t2,t3);}

static void C_fcall trf_3570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3570(t0,t1);}

static void C_fcall trf_3467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3467(t0,t1);}

static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3196(t0,t1,t2);}

static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2888(t0,t1);}

static void C_fcall trf_2761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2761(t0,t1);}

static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2577(t0,t1,t2);}

static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2120(t0,t1);}

static void C_fcall trf_2089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2089(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2089(t0,t1,t2);}

static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr18(C_proc18 k) C_regparm C_noret;
C_regparm static void C_fcall tr18(C_proc18 k){
C_word t17=C_pick(0);
C_word t16=C_pick(1);
C_word t15=C_pick(2);
C_word t14=C_pick(3);
C_word t13=C_pick(4);
C_word t12=C_pick(5);
C_word t11=C_pick(6);
C_word t10=C_pick(7);
C_word t9=C_pick(8);
C_word t8=C_pick(9);
C_word t7=C_pick(10);
C_word t6=C_pick(11);
C_word t5=C_pick(12);
C_word t4=C_pick(13);
C_word t3=C_pick(14);
C_word t2=C_pick(15);
C_word t1=C_pick(16);
C_word t0=C_pick(17);
C_adjust_stack(-18);
(k)(18,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5420)){
C_save(t1);
C_rereclaim2(5420*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,852);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[11]=C_h_pair(C_restore,tmp);
lf[13]=C_static_string(C_heaptop,6,".dylib");
lf[15]=C_static_string(C_heaptop,4,".dll");
lf[17]=C_static_string(C_heaptop,3,".sl");
lf[19]=C_static_string(C_heaptop,3,".so");
lf[21]=C_static_string(C_heaptop,4,".scm");
lf[23]=C_static_string(C_heaptop,6,".setup");
lf[25]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[27]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[29]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[31]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[33]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[35]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[37]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[39]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[41]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[42]=C_h_intern(&lf[42],17,"user-options-pass");
lf[43]=C_h_intern(&lf[43],14,"user-read-pass");
lf[44]=C_h_intern(&lf[44],22,"user-preprocessor-pass");
lf[45]=C_h_intern(&lf[45],9,"user-pass");
lf[46]=C_h_intern(&lf[46],11,"user-pass-2");
lf[47]=C_h_intern(&lf[47],23,"user-post-analysis-pass");
lf[48]=C_h_intern(&lf[48],18,"\010compilerunit-name");
lf[49]=C_h_intern(&lf[49],11,"number-type");
lf[50]=C_h_intern(&lf[50],7,"generic");
lf[51]=C_h_intern(&lf[51],17,"standard-bindings");
lf[52]=C_h_intern(&lf[52],17,"extended-bindings");
lf[53]=C_h_intern(&lf[53],28,"\010compilerinsert-timer-checks");
lf[54]=C_h_intern(&lf[54],19,"\010compilerused-units");
lf[55]=C_h_intern(&lf[55],6,"unsafe");
lf[56]=C_h_intern(&lf[56],12,"always-bound");
lf[57]=C_h_intern(&lf[57],34,"\010compileralways-bound-to-procedure");
lf[58]=C_h_intern(&lf[58],29,"\010compilerforeign-declarations");
lf[59]=C_h_intern(&lf[59],24,"\010compileremit-trace-info");
lf[60]=C_h_intern(&lf[60],26,"\010compilerblock-compilation");
lf[61]=C_h_intern(&lf[61],34,"\010compilerline-number-database-size");
lf[62]=C_h_intern(&lf[62],25,"\010compilertarget-heap-size");
lf[63]=C_h_intern(&lf[63],33,"\010compilertarget-initial-heap-size");
lf[64]=C_h_intern(&lf[64],26,"\010compilertarget-stack-size");
lf[65]=C_h_intern(&lf[65],19,"\010compilertry-harder");
lf[66]=C_h_intern(&lf[66],22,"optimize-leaf-routines");
lf[67]=C_h_intern(&lf[67],21,"\010compileremit-profile");
lf[68]=C_h_intern(&lf[68],15,"no-bound-checks");
lf[69]=C_h_intern(&lf[69],14,"no-argc-checks");
lf[70]=C_h_intern(&lf[70],19,"no-procedure-checks");
lf[71]=C_h_intern(&lf[71],22,"\010compilerblock-globals");
lf[72]=C_h_intern(&lf[72],24,"\010compilersource-filename");
lf[73]=C_h_intern(&lf[73],20,"\010compilerexport-list");
lf[74]=C_h_intern(&lf[74],28,"\010compilercompressed-literals");
lf[75]=C_h_intern(&lf[75],38,"\010compilerliteral-compression-threshold");
lf[76]=C_h_intern(&lf[76],40,"\010compilercompressed-literals-initializer");
lf[77]=C_h_intern(&lf[77],26,"\010compilersafe-globals-flag");
lf[78]=C_h_intern(&lf[78],26,"\010compilerexplicit-use-flag");
lf[79]=C_h_intern(&lf[79],40,"\010compilerdisable-stack-overflow-checking");
lf[80]=C_h_intern(&lf[80],24,"\010compilernamespace-table");
lf[81]=C_h_intern(&lf[81],29,"\010compilerrequire-imports-flag");
lf[82]=C_h_intern(&lf[82],27,"\010compilerno-c-syntax-checks");
lf[83]=C_h_intern(&lf[83],27,"\010compileremit-unsafe-marker");
lf[84]=C_h_intern(&lf[84],30,"\010compilerexternal-protos-first");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdo-lambda-lifting");
lf[86]=C_h_intern(&lf[86],24,"\010compilerinline-max-size");
lf[87]=C_h_intern(&lf[87],26,"\010compileremit-closure-info");
lf[88]=C_h_intern(&lf[88],34,"\010compilerdefault-installation-home");
lf[89]=C_h_intern(&lf[89],41,"\010compilerdefault-default-target-heap-size");
lf[90]=C_h_intern(&lf[90],42,"\010compilerdefault-default-target-stack-size");
lf[91]=C_h_intern(&lf[91],21,"\010compilerverbose-mode");
lf[92]=C_h_intern(&lf[92],30,"\010compileroriginal-program-size");
lf[93]=C_h_intern(&lf[93],29,"\010compilercurrent-program-size");
lf[94]=C_h_intern(&lf[94],31,"\010compilerline-number-database-2");
lf[95]=C_h_intern(&lf[95],28,"\010compilerimmutable-constants");
lf[96]=C_h_intern(&lf[96],43,"\010compilerrest-parameters-promoted-to-vector");
lf[97]=C_h_intern(&lf[97],21,"\010compilerinline-table");
lf[98]=C_h_intern(&lf[98],26,"\010compilerinline-table-used");
lf[99]=C_h_intern(&lf[99],23,"\010compilerconstant-table");
lf[100]=C_h_intern(&lf[100],23,"\010compilerconstants-used");
lf[101]=C_h_intern(&lf[101],26,"\010compilermutable-constants");
lf[102]=C_h_intern(&lf[102],30,"\010compilerbroken-constant-nodes");
lf[103]=C_h_intern(&lf[103],37,"\010compilerinline-substitutions-enabled");
lf[104]=C_h_intern(&lf[104],24,"\010compilerdirect-call-ids");
lf[105]=C_h_intern(&lf[105],23,"\010compilerfirst-analysis");
lf[106]=C_h_intern(&lf[106],27,"\010compilerforeign-type-table");
lf[107]=C_h_intern(&lf[107],26,"\010compilerforeign-variables");
lf[108]=C_h_intern(&lf[108],29,"\010compilerforeign-lambda-stubs");
lf[109]=C_h_intern(&lf[109],22,"foreign-callback-stubs");
lf[110]=C_h_intern(&lf[110],27,"\010compilerexternal-variables");
lf[111]=C_h_intern(&lf[111],26,"\010compilerloop-lambda-names");
lf[112]=C_h_intern(&lf[112],28,"\010compilerprofile-lambda-list");
lf[113]=C_h_intern(&lf[113],29,"\010compilerprofile-lambda-index");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],28,"\010compilerexternal-to-pointer");
lf[116]=C_h_intern(&lf[116],34,"\010compilererror-is-extended-binding");
lf[117]=C_h_intern(&lf[117],24,"\010compilerreal-name-table");
lf[118]=C_h_intern(&lf[118],29,"\010compilerlocation-pointer-map");
lf[119]=C_h_intern(&lf[119],34,"\010compilerpending-canonicalizations");
lf[120]=C_h_intern(&lf[120],29,"\010compilerdefconstant-bindings");
lf[121]=C_h_intern(&lf[121],23,"\010compilercallback-names");
lf[122]=C_h_intern(&lf[122],23,"\010compilertoplevel-scope");
lf[123]=C_h_intern(&lf[123],27,"\010compilertoplevel-lambda-id");
lf[124]=C_h_intern(&lf[124],29,"\010compilercustom-declare-alist");
lf[125]=C_h_intern(&lf[125],25,"\010compilercsc-control-file");
lf[126]=C_h_intern(&lf[126],26,"\010compilerdata-declarations");
lf[127]=C_h_intern(&lf[127],20,"\010compilerinline-list");
lf[128]=C_h_intern(&lf[128],24,"\010compilernot-inline-list");
lf[129]=C_h_intern(&lf[129],26,"\010compilerfile-requirements");
lf[130]=C_h_intern(&lf[130],28,"\010compilerinitialize-compiler");
lf[131]=C_h_intern(&lf[131],12,"vector-fill!");
lf[132]=C_h_intern(&lf[132],11,"make-vector");
lf[133]=C_h_intern(&lf[133],15,"make-hash-table");
lf[134]=C_h_intern(&lf[134],3,"eq\077");
lf[135]=C_h_intern(&lf[135],25,"\010compilermake-random-name");
lf[136]=C_h_intern(&lf[136],12,"profile-info");
lf[137]=C_static_lambda_info(C_heaptop,32,"(##compiler#initialize-compiler)");
lf[138]=C_h_intern(&lf[138],32,"\010compilercanonicalize-expression");
lf[139]=C_static_lambda_info(C_heaptop,14,"(resolve ae62)");
lf[140]=C_h_intern(&lf[140],23,"\010compilerset-real-name!");
lf[141]=C_static_lambda_info(C_heaptop,15,"(a2094 a67 n68)");
lf[142]=C_h_intern(&lf[142],8,"for-each");
lf[143]=C_static_lambda_info(C_heaptop,27,"(set-real-names! as65 ns66)");
lf[144]=C_h_intern(&lf[144],5,"quote");
lf[145]=C_static_lambda_info(C_heaptop,17,"(unquotify g7273)");
lf[146]=C_h_intern(&lf[146],23,"\003sysmacroexpand-1-local");
lf[147]=C_h_intern(&lf[147],15,"\004coreinline_ref");
lf[148]=C_h_intern(&lf[148],36,"\010compilerforeign-type-convert-result");
lf[149]=C_h_intern(&lf[149],30,"\010compilerfinish-foreign-result");
lf[150]=C_h_intern(&lf[150],27,"\010compilerfinal-foreign-type");
lf[151]=C_h_intern(&lf[151],19,"\004coreinline_loc_ref");
lf[152]=C_h_intern(&lf[152],18,"\003syshash-table-ref");
lf[153]=C_h_intern(&lf[153],4,"quit");
lf[154]=C_static_string(C_heaptop,39,"syntax error - illegal atomic form `~s\047");
lf[155]=C_h_intern(&lf[155],24,"\003syssyntax-error-culprit");
lf[156]=C_h_intern(&lf[156],2,"if");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[157]=C_h_pair(C_restore,tmp);
lf[158]=C_h_intern(&lf[158],16,"\003syscheck-syntax");
tmp=C_intern(C_heaptop,2,"if");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
lf[159]=C_h_pair(C_restore,tmp);
lf[160]=C_h_intern(&lf[160],10,"alist-cons");
lf[161]=C_h_intern(&lf[161],17,"get-output-string");
lf[162]=C_h_intern(&lf[162],5,"write");
lf[163]=C_h_intern(&lf[163],18,"open-output-string");
lf[164]=C_h_intern(&lf[164],18,"\010compilerdebugging");
lf[165]=C_h_intern(&lf[165],1,"o");
lf[166]=C_static_string(C_heaptop,27,"compressing literal of size");
lf[167]=C_h_intern(&lf[167],6,"gensym");
lf[168]=C_h_intern(&lf[168],2,"lf");
lf[169]=C_h_intern(&lf[169],29,"\010compilercompressable-literal");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[170]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[171]=C_h_intern(&lf[171],10,"\004corecheck");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
lf[172]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[173]=C_h_intern(&lf[173],14,"\004coreimmutable");
lf[174]=C_h_intern(&lf[174],1,"c");
lf[175]=C_h_intern(&lf[175],6,"cadadr");
lf[176]=C_h_intern(&lf[176],14,"\004coreundefined");
lf[177]=C_h_intern(&lf[177],23,"\004corerequire-for-syntax");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[178]=C_h_pair(C_restore,tmp);
lf[179]=C_h_intern(&lf[179],8,"\003syscons");
lf[180]=C_h_intern(&lf[180],11,"\003sysrequire");
lf[181]=C_static_lambda_info(C_heaptop,12,"(a2531 x147)");
lf[182]=C_h_intern(&lf[182],7,"\003sysmap");
lf[183]=C_h_intern(&lf[183],10,"lset-union");
lf[184]=C_static_lambda_info(C_heaptop,15,"(a2537 g145146)");
lf[185]=C_static_lambda_info(C_heaptop,7,"(a2543)");
lf[186]=C_h_intern(&lf[186],18,"hash-table-update!");
lf[187]=C_h_intern(&lf[187],20,"runtime-requirements");
lf[188]=C_h_intern(&lf[188],31,"\003syslookup-runtime-requirements");
lf[189]=C_static_lambda_info(C_heaptop,15,"(a2546 g142143)");
lf[190]=C_static_lambda_info(C_heaptop,7,"(a2552)");
lf[191]=C_h_intern(&lf[191],19,"syntax-requirements");
lf[192]=C_h_intern(&lf[192],4,"eval");
lf[193]=C_h_intern(&lf[193],22,"\004corerequire-extension");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[194]=C_h_pair(C_restore,tmp);
lf[195]=C_h_intern(&lf[195],22,"\003sysdo-the-right-thing");
lf[196]=C_static_lambda_info(C_heaptop,7,"(a2591)");
lf[197]=C_h_intern(&lf[197],5,"begin");
lf[198]=C_h_intern(&lf[198],7,"warning");
lf[199]=C_static_string(C_heaptop,41,"extension `~A\047 is currently not installed");
lf[200]=C_h_intern(&lf[200],18,"\003sysfind-extension");
lf[201]=C_h_intern(&lf[201],31,"\003syscanonicalize-extension-path");
lf[202]=C_h_intern(&lf[202],17,"require-extension");
lf[203]=C_static_lambda_info(C_heaptop,25,"(a2597 exp154156 f155157)");
lf[204]=C_h_intern(&lf[204],5,"cadar");
lf[205]=C_static_lambda_info(C_heaptop,13,"(loop ids152)");
lf[206]=C_h_intern(&lf[206],3,"let");
lf[207]=C_static_lambda_info(C_heaptop,15,"(a2670 g170171)");
lf[208]=C_h_intern(&lf[208],21,"\003syscanonicalize-body");
lf[209]=C_static_lambda_info(C_heaptop,21,"(a2676 alias168 b169)");
lf[210]=C_h_intern(&lf[210],3,"map");
lf[211]=C_h_intern(&lf[211],6,"append");
lf[212]=C_h_intern(&lf[212],4,"cons");
lf[213]=C_h_intern(&lf[213],6,"unzip1");
tmp=C_intern(C_heaptop,3,"let");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[214]=C_h_pair(C_restore,tmp);
lf[215]=C_h_intern(&lf[215],6,"lambda");
lf[216]=C_h_intern(&lf[216],20,"\004coreinternal-lambda");
lf[217]=C_h_intern(&lf[217],30,"\010compilerexpand-profile-lambda");
lf[218]=C_h_intern(&lf[218],26,"\010compilerbuild-lambda-list");
lf[219]=C_h_intern(&lf[219],13,"\010compilerposq");
lf[220]=C_static_lambda_info(C_heaptop,15,"(a2773 g189190)");
lf[221]=C_static_lambda_info(C_heaptop,31,"(a2722 vars183 argc184 rest185)");
lf[222]=C_h_intern(&lf[222],30,"\010compilerdecompose-lambda-list");
lf[223]=C_h_intern(&lf[223],31,"\003sysexpand-extended-lambda-list");
lf[224]=C_h_intern(&lf[224],9,"\003syserror");
lf[225]=C_static_lambda_info(C_heaptop,7,"(a2789)");
lf[226]=C_static_lambda_info(C_heaptop,31,"(a2795 llist178180 obody179181)");
lf[227]=C_h_intern(&lf[227],25,"\003sysextended-lambda-list\077");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[228]=C_h_pair(C_restore,tmp);
lf[229]=C_h_intern(&lf[229],17,"\004corenamed-lambda");
lf[230]=C_h_intern(&lf[230],16,"\004coreloop-lambda");
lf[231]=C_static_lambda_info(C_heaptop,15,"(a2852 g200201)");
lf[232]=C_h_intern(&lf[232],4,"set!");
lf[233]=C_h_intern(&lf[233],9,"\004coreset!");
lf[234]=C_h_intern(&lf[234],18,"\004coreinline_update");
lf[235]=C_h_intern(&lf[235],27,"\010compilerforeign-type-check");
lf[236]=C_h_intern(&lf[236],38,"\010compilerforeign-type-convert-argument");
lf[237]=C_h_intern(&lf[237],22,"\004coreinline_loc_update");
lf[238]=C_static_string(C_heaptop,26,"assignment to keyword `~S\047");
lf[239]=C_h_intern(&lf[239],8,"keyword\077");
lf[240]=C_static_string(C_heaptop,43,"assigned global variable `~S\047 is a macro ~A");
lf[241]=C_h_intern(&lf[241],7,"sprintf");
lf[242]=C_static_string(C_heaptop,10,"in line ~S");
lf[243]=C_static_string(C_heaptop,0,"");
lf[244]=C_h_intern(&lf[244],6,"macro\077");
lf[245]=C_h_intern(&lf[245],11,"lset-adjoin");
lf[246]=C_h_intern(&lf[246],17,"\010compilerget-line");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[247]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[248]=C_h_intern(&lf[248],11,"\004coreinline");
lf[249]=C_h_intern(&lf[249],20,"\004coreinline_allocate");
lf[250]=C_h_intern(&lf[250],19,"\004corecompiletimetoo");
lf[251]=C_h_intern(&lf[251],23,"\004coreelaborationtimetoo");
lf[252]=C_h_intern(&lf[252],20,"\004corecompiletimeonly");
lf[253]=C_h_intern(&lf[253],24,"\004coreelaborationtimeonly");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[254]=C_h_pair(C_restore,tmp);
lf[255]=C_h_intern(&lf[255],32,"\010compilercanonicalize-begin-body");
lf[256]=C_static_lambda_info(C_heaptop,12,"(fold xs232)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[257]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[258]=C_h_pair(C_restore,tmp);
lf[259]=C_h_intern(&lf[259],19,"\004coreforeign-lambda");
lf[260]=C_h_intern(&lf[260],30,"\010compilerexpand-foreign-lambda");
lf[261]=C_h_intern(&lf[261],28,"\004coreforeign-callback-lambda");
lf[262]=C_h_intern(&lf[262],39,"\010compilerexpand-foreign-callback-lambda");
lf[263]=C_h_intern(&lf[263],20,"\004coreforeign-lambda*");
lf[264]=C_h_intern(&lf[264],31,"\010compilerexpand-foreign-lambda*");
lf[265]=C_h_intern(&lf[265],29,"\004coreforeign-callback-lambda*");
lf[266]=C_h_intern(&lf[266],40,"\010compilerexpand-foreign-callback-lambda*");
lf[267]=C_h_intern(&lf[267],22,"\004coreforeign-primitive");
lf[268]=C_h_intern(&lf[268],33,"\010compilerexpand-foreign-primitive");
lf[269]=C_h_intern(&lf[269],28,"\004coredefine-foreign-variable");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[270]=C_h_pair(C_restore,tmp);
lf[271]=C_h_intern(&lf[271],14,"symbol->string");
lf[272]=C_h_intern(&lf[272],23,"\010compilercheck-c-syntax");
lf[273]=C_h_intern(&lf[273],23,"define-foreign-variable");
lf[274]=C_h_intern(&lf[274],24,"\004coredefine-foreign-type");
lf[275]=C_h_intern(&lf[275],10,"\003sysvalues");
lf[276]=C_h_intern(&lf[276],5,"cons*");
lf[277]=C_h_intern(&lf[277],19,"\003syshash-table-set!");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[278]=C_h_pair(C_restore,tmp);
lf[279]=C_h_intern(&lf[279],29,"\004coredefine-external-variable");
lf[280]=C_h_intern(&lf[280],9,"c-pointer");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[281]=C_h_pair(C_restore,tmp);
lf[282]=C_h_intern(&lf[282],13,"string-append");
lf[283]=C_static_string(C_heaptop,1,"&");
lf[284]=C_h_intern(&lf[284],5,"fifth");
lf[285]=C_h_intern(&lf[285],17,"\004corelet-location");
lf[286]=C_static_string(C_heaptop,16,"C_a_i_bytevector");
lf[287]=C_h_intern(&lf[287],10,"\003sysappend");
lf[288]=C_h_intern(&lf[288],14,"\010compilerwords");
lf[289]=C_h_intern(&lf[289],46,"\010compilerestimate-foreign-result-location-size");
lf[290]=C_h_intern(&lf[290],18,"\004coredefine-inline");
lf[291]=C_h_intern(&lf[291],34,"\010compilerextract-mutable-constants");
lf[292]=C_static_lambda_info(C_heaptop,7,"(a3656)");
lf[293]=C_static_lambda_info(C_heaptop,12,"(a3696 m272)");
lf[294]=C_static_lambda_info(C_heaptop,24,"(a3674 val2270 mlist271)");
lf[295]=C_h_intern(&lf[295],20,"\004coredefine-constant");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[296]=C_h_pair(C_restore,tmp);
lf[297]=C_h_intern(&lf[297],29,"\010compilercollapsable-literal\077");
lf[298]=C_static_string(C_heaptop,56,"error in constant evaluation of ~S for named constant ~S");
lf[299]=C_static_lambda_info(C_heaptop,7,"(a3811)");
lf[300]=C_static_lambda_info(C_heaptop,13,"(a3805 ex282)");
lf[301]=C_static_lambda_info(C_heaptop,7,"(a3823)");
lf[302]=C_static_lambda_info(C_heaptop,7,"(a3845)");
lf[303]=C_static_lambda_info(C_heaptop,17,"(a3839 . g280283)");
lf[304]=C_static_lambda_info(C_heaptop,7,"(a3817)");
lf[305]=C_h_intern(&lf[305],22,"with-exception-handler");
lf[306]=C_static_lambda_info(C_heaptop,15,"(a3799 g279281)");
lf[307]=C_h_intern(&lf[307],30,"call-with-current-continuation");
lf[308]=C_h_intern(&lf[308],12,"\004coredeclare");
lf[309]=C_h_intern(&lf[309],28,"\010compilerprocess-declaration");
lf[310]=C_static_lambda_info(C_heaptop,12,"(a3872 d292)");
lf[311]=C_h_intern(&lf[311],29,"\004coreforeign-callback-wrapper");
lf[312]=C_h_intern(&lf[312],8,"split-at");
lf[313]=C_static_lambda_info(C_heaptop,7,"(a3895)");
lf[314]=C_static_lambda_info(C_heaptop,23,"(loop vars310 types311)");
lf[315]=C_h_intern(&lf[315],21,"\003syssyntax-error-hook");
lf[316]=C_static_string(C_heaptop,65,"non-matching or invalid argument list to foreign callback-wrapper");
lf[317]=C_static_string(C_heaptop,60,"name `~S\047 of external definition is not a valid C identifier");
lf[318]=C_h_intern(&lf[318],28,"\010compilervalid-c-identifier\077");
lf[319]=C_static_lambda_info(C_heaptop,28,"(a3905 args293295 lam294296)");
lf[320]=C_static_lambda_info(C_heaptop,13,"(handle-call)");
lf[321]=C_h_intern(&lf[321],8,"location");
lf[322]=C_h_intern(&lf[322],17,"\003sysmake-locative");
tmp=C_intern(C_heaptop,8,"location");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[323]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[324]=C_h_intern(&lf[324],13,"\004corecallunit");
lf[325]=C_h_intern(&lf[325],14,"\004coreprimitive");
lf[326]=C_h_intern(&lf[326],37,"\010compilerupdate-line-number-database!");
lf[327]=C_static_string(C_heaptop,51,"syntax error in line ~s - malformed expression `~s\047");
lf[328]=C_static_string(C_heaptop,40,"syntax error - malformed expression `~s\047");
lf[329]=C_static_string(C_heaptop,32,"literal in operator position: ~S");
lf[330]=C_h_intern(&lf[330],4,"list");
lf[331]=C_h_intern(&lf[331],1,"t");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[332]=C_h_pair(C_restore,tmp);
lf[333]=C_h_intern(&lf[333],4,"caar");
lf[334]=C_h_intern(&lf[334],18,"\010compilerconstant\077");
lf[335]=C_static_string(C_heaptop,40,"syntax error - malformed expression `~s\047");
lf[336]=C_static_lambda_info(C_heaptop,27,"(walk x80 ae81 me82 dest83)");
lf[337]=C_static_lambda_info(C_heaptop,12,"(a4412 x341)");
lf[338]=C_static_lambda_info(C_heaptop,27,"(mapwalk xs338 ae339 me340)");
lf[339]=C_h_intern(&lf[339],26,"\010compilerinternal-bindings");
lf[340]=C_h_intern(&lf[340],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[341]=C_h_intern(&lf[341],7,"reverse");
lf[342]=C_h_intern(&lf[342],26,"\010compilerdebugging-chicken");
lf[343]=C_h_intern(&lf[343],12,"pretty-print");
lf[344]=C_h_intern(&lf[344],7,"newline");
lf[345]=C_static_lambda_info(C_heaptop,42,"(##compiler#canonicalize-expression exp54)");
lf[346]=C_static_string(C_heaptop,33,"syntax error in declaration: `~s\047");
lf[347]=C_static_lambda_info(C_heaptop,40,"(check-decl spec356 minlen357 maxlen358)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[348]=C_h_pair(C_restore,tmp);
lf[349]=C_h_intern(&lf[349],4,"uses");
lf[350]=C_h_intern(&lf[350],29,"\010compilerstring->c-identifier");
lf[351]=C_h_intern(&lf[351],18,"\010compilerstringify");
lf[352]=C_static_lambda_info(C_heaptop,12,"(a4549 u372)");
lf[353]=C_static_lambda_info(C_heaptop,15,"(a4559 g369370)");
lf[354]=C_static_lambda_info(C_heaptop,7,"(a4565)");
lf[355]=C_h_intern(&lf[355],17,"register-feature!");
lf[356]=C_h_intern(&lf[356],4,"unit");
lf[357]=C_static_string(C_heaptop,51,"unit was already given a name (new name is ignored)");
lf[358]=C_h_intern(&lf[358],15,"hash-table-set!");
lf[359]=C_h_intern(&lf[359],34,"\010compilerdefault-standard-bindings");
lf[360]=C_h_intern(&lf[360],34,"\010compilerdefault-extended-bindings");
lf[361]=C_h_intern(&lf[361],18,"usual-integrations");
lf[362]=C_h_intern(&lf[362],17,"lset-intersection");
lf[363]=C_h_intern(&lf[363],6,"fixnum");
lf[364]=C_h_intern(&lf[364],17,"fixnum-arithmetic");
lf[365]=C_h_intern(&lf[365],23,"\005matchset-error-control");
lf[366]=C_h_intern(&lf[366],12,"\000unspecified");
lf[367]=C_h_intern(&lf[367],4,"safe");
lf[368]=C_h_intern(&lf[368],18,"interrupts-enabled");
lf[369]=C_h_intern(&lf[369],18,"disable-interrupts");
lf[370]=C_h_intern(&lf[370],12,"safe-globals");
lf[371]=C_h_intern(&lf[371],18,"bound-to-procedure");
lf[372]=C_h_intern(&lf[372],15,"foreign-declare");
lf[373]=C_static_string(C_heaptop,33,"syntax error in declaration: `~S\047");
lf[374]=C_h_intern(&lf[374],5,"every");
lf[375]=C_h_intern(&lf[375],7,"string\077");
lf[376]=C_h_intern(&lf[376],13,"foreign-parse");
lf[377]=C_h_intern(&lf[377],23,"\010compilerparse-easy-ffi");
lf[378]=C_h_intern(&lf[378],18,"string-intersperse");
lf[379]=C_static_string(C_heaptop,0,"");
lf[380]=C_static_string(C_heaptop,33,"syntax error in declaration: `~S\047");
lf[381]=C_h_intern(&lf[381],14,"custom-declare");
lf[382]=C_static_string(C_heaptop,33,"syntax error in declaration: `~S\047");
lf[383]=C_h_intern(&lf[383],35,"\010compilerprocess-custom-declaration");
lf[384]=C_h_intern(&lf[384],9,"c-options");
lf[385]=C_h_intern(&lf[385],31,"\010compileremit-control-file-item");
lf[386]=C_h_intern(&lf[386],12,"link-options");
lf[387]=C_h_intern(&lf[387],12,"post-process");
lf[388]=C_h_intern(&lf[388],17,"string-substitute");
lf[389]=C_static_string(C_heaptop,3,"\134$@");
lf[390]=C_static_lambda_info(C_heaptop,15,"(a4989 g396397)");
lf[391]=C_h_intern(&lf[391],24,"pathname-strip-extension");
lf[392]=C_h_intern(&lf[392],5,"block");
lf[393]=C_h_intern(&lf[393],8,"separate");
lf[394]=C_h_intern(&lf[394],3,"not");
lf[395]=C_h_intern(&lf[395],15,"lset-difference");
lf[396]=C_h_intern(&lf[396],6,"inline");
lf[397]=C_static_string(C_heaptop,34,"illegal declaration specifier `~s\047");
lf[398]=C_h_intern(&lf[398],15,"run-time-macros");
lf[399]=C_h_intern(&lf[399],25,"\003sysenable-runtime-macros");
lf[400]=C_h_intern(&lf[400],12,"block-global");
lf[401]=C_h_intern(&lf[401],4,"hide");
lf[402]=C_h_intern(&lf[402],6,"export");
lf[403]=C_h_intern(&lf[403],17,"compress-literals");
lf[404]=C_h_intern(&lf[404],30,"emit-external-prototypes-first");
lf[405]=C_h_intern(&lf[405],11,"lambda-lift");
lf[406]=C_h_intern(&lf[406],12,"inline-limit");
lf[407]=C_static_string(C_heaptop,46,"invalid argument to `inline-limit\047 declaration");
lf[408]=C_h_intern(&lf[408],9,"namespace");
lf[409]=C_h_intern(&lf[409],13,"alist-update!");
lf[410]=C_static_string(C_heaptop,48,"invalid arguments to `namespace\047 declaration: ~S");
lf[411]=C_h_intern(&lf[411],7,"symbol\077");
lf[412]=C_static_string(C_heaptop,34,"illegal declaration specifier `~s\047");
lf[413]=C_static_string(C_heaptop,32,"invalid specification syntax: ~S");
lf[414]=C_static_lambda_info(C_heaptop,17,"(a4512 return365)");
lf[415]=C_static_lambda_info(C_heaptop,40,"(##compiler#process-declaration spec354)");
lf[416]=C_h_intern(&lf[416],17,"make-foreign-stub");
lf[417]=C_h_intern(&lf[417],12,"foreign-stub");
lf[418]=C_static_lambda_info(C_heaptop,111,"(make-foreign-stub id431 return-type432 name433 argument-types434 argument-names"
"435 body436 cps437 callback438)");
lf[419]=C_h_intern(&lf[419],13,"foreign-stub\077");
lf[420]=C_static_lambda_info(C_heaptop,20,"(foreign-stub\077 x439)");
lf[421]=C_h_intern(&lf[421],15,"foreign-stub-id");
lf[422]=C_static_lambda_info(C_heaptop,22,"(foreign-stub-id x440)");
lf[423]=C_h_intern(&lf[423],20,"foreign-stub-id-set!");
lf[424]=C_h_intern(&lf[424],14,"\003sysblock-set!");
lf[425]=C_static_lambda_info(C_heaptop,34,"(foreign-stub-id-set! x442 val443)");
lf[426]=C_h_intern(&lf[426],24,"foreign-stub-return-type");
lf[427]=C_static_lambda_info(C_heaptop,31,"(foreign-stub-return-type x446)");
lf[428]=C_h_intern(&lf[428],29,"foreign-stub-return-type-set!");
lf[429]=C_static_lambda_info(C_heaptop,43,"(foreign-stub-return-type-set! x448 val449)");
lf[430]=C_h_intern(&lf[430],17,"foreign-stub-name");
lf[431]=C_static_lambda_info(C_heaptop,24,"(foreign-stub-name x452)");
lf[432]=C_h_intern(&lf[432],22,"foreign-stub-name-set!");
lf[433]=C_static_lambda_info(C_heaptop,36,"(foreign-stub-name-set! x454 val455)");
lf[434]=C_h_intern(&lf[434],27,"foreign-stub-argument-types");
lf[435]=C_static_lambda_info(C_heaptop,34,"(foreign-stub-argument-types x458)");
lf[436]=C_h_intern(&lf[436],32,"foreign-stub-argument-types-set!");
lf[437]=C_static_lambda_info(C_heaptop,46,"(foreign-stub-argument-types-set! x460 val461)");
lf[438]=C_h_intern(&lf[438],27,"foreign-stub-argument-names");
lf[439]=C_static_lambda_info(C_heaptop,34,"(foreign-stub-argument-names x464)");
lf[440]=C_h_intern(&lf[440],32,"foreign-stub-argument-names-set!");
lf[441]=C_static_lambda_info(C_heaptop,46,"(foreign-stub-argument-names-set! x466 val467)");
lf[442]=C_h_intern(&lf[442],17,"foreign-stub-body");
lf[443]=C_static_lambda_info(C_heaptop,24,"(foreign-stub-body x470)");
lf[444]=C_h_intern(&lf[444],22,"foreign-stub-body-set!");
lf[445]=C_static_lambda_info(C_heaptop,36,"(foreign-stub-body-set! x472 val473)");
lf[446]=C_h_intern(&lf[446],16,"foreign-stub-cps");
lf[447]=C_static_lambda_info(C_heaptop,23,"(foreign-stub-cps x476)");
lf[448]=C_h_intern(&lf[448],21,"foreign-stub-cps-set!");
lf[449]=C_static_lambda_info(C_heaptop,35,"(foreign-stub-cps-set! x478 val479)");
lf[450]=C_h_intern(&lf[450],21,"foreign-stub-callback");
lf[451]=C_static_lambda_info(C_heaptop,28,"(foreign-stub-callback x482)");
lf[452]=C_h_intern(&lf[452],26,"foreign-stub-callback-set!");
lf[453]=C_static_lambda_info(C_heaptop,40,"(foreign-stub-callback-set! x484 val485)");
lf[454]=C_h_intern(&lf[454],28,"\010compilercreate-foreign-stub");
tmp=C_intern(C_heaptop,6,"\003sysgc");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[455]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[456]=C_h_pair(C_restore,tmp);
lf[457]=C_static_string(C_heaptop,16,"C_a_i_bytevector");
lf[458]=C_static_lambda_info(C_heaptop,17,"(a5676 p512 t513)");
lf[459]=C_h_intern(&lf[459],37,"\010compilerestimate-foreign-result-size");
lf[460]=C_h_intern(&lf[460],4,"stub");
lf[461]=C_h_intern(&lf[461],1,"a");
lf[462]=C_static_lambda_info(C_heaptop,12,"(a5707 x505)");
lf[463]=C_h_intern(&lf[463],13,"list-tabulate");
lf[464]=C_static_lambda_info(C_heaptop,101,"(##compiler#create-foreign-stub rtype497 sname498 argtypes499 argnames500 body50"
"1 callback502 cps503)");
lf[465]=C_h_intern(&lf[465],6,"second");
lf[466]=C_static_string(C_heaptop,45,"name `~s\047 of foreign procedure has wrong type");
lf[467]=C_static_lambda_info(C_heaptop,41,"(##compiler#expand-foreign-lambda exp518)");
lf[468]=C_static_string(C_heaptop,45,"name `~s\047 of foreign procedure has wrong type");
lf[469]=C_static_lambda_info(C_heaptop,50,"(##compiler#expand-foreign-callback-lambda exp523)");
lf[470]=C_h_intern(&lf[470],15,"foreign-lambda*");
lf[471]=C_h_intern(&lf[471],4,"cadr");
lf[472]=C_h_intern(&lf[472],3,"car");
lf[473]=C_static_lambda_info(C_heaptop,42,"(##compiler#expand-foreign-lambda* exp528)");
lf[474]=C_h_intern(&lf[474],24,"foreign-callback-lambda*");
lf[475]=C_static_lambda_info(C_heaptop,51,"(##compiler#expand-foreign-callback-lambda* exp535)");
lf[476]=C_h_intern(&lf[476],17,"foreign-primitive");
lf[477]=C_h_intern(&lf[477],4,"void");
lf[478]=C_static_lambda_info(C_heaptop,44,"(##compiler#expand-foreign-primitive exp542)");
lf[479]=C_static_lambda_info(C_heaptop,12,"(loop xs556)");
lf[480]=C_static_lambda_info(C_heaptop,17,"(mapupdate xs554)");
lf[481]=C_h_intern(&lf[481],24,"\003sysline-number-database");
lf[482]=C_static_lambda_info(C_heaptop,11,"(walk x559)");
lf[483]=C_static_lambda_info(C_heaptop,54,"(##compiler#update-line-number-database! exp550 ln551)");
lf[484]=C_h_intern(&lf[484],31,"\010compilerperform-cps-conversion");
lf[485]=C_h_intern(&lf[485],4,"node");
lf[486]=C_h_intern(&lf[486],11,"\004corelambda");
lf[487]=C_h_intern(&lf[487],9,"\004corecall");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[488]=C_h_pair(C_restore,tmp);
lf[489]=C_h_intern(&lf[489],16,"\010compilervarnode");
lf[490]=C_static_lambda_info(C_heaptop,12,"(a6087 r585)");
lf[491]=C_h_intern(&lf[491],1,"k");
lf[492]=C_static_lambda_info(C_heaptop,40,"(cps-lambda id577 llist578 subs579 k580)");
lf[493]=C_h_intern(&lf[493],13,"\004corevariable");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[494]=C_h_pair(C_restore,tmp);
lf[495]=C_static_lambda_info(C_heaptop,9,"(k1 r611)");
lf[496]=C_static_lambda_info(C_heaptop,12,"(a6182 v621)");
lf[497]=C_h_intern(&lf[497],2,"f_");
lf[498]=C_h_intern(&lf[498],1,"r");
lf[499]=C_static_lambda_info(C_heaptop,12,"(a6255 r628)");
lf[500]=C_static_lambda_info(C_heaptop,22,"(loop vars626 vals627)");
lf[501]=C_static_lambda_info(C_heaptop,12,"(a6316 r634)");
lf[502]=C_h_intern(&lf[502],26,"make-foreign-callback-stub");
lf[503]=C_h_intern(&lf[503],13,"\010compilerbomb");
lf[504]=C_static_string(C_heaptop,14,"bad node (cps)");
lf[505]=C_h_intern(&lf[505],15,"\004coreglobal-ref");
lf[506]=C_static_lambda_info(C_heaptop,16,"(walk n589 k590)");
lf[507]=C_static_lambda_info(C_heaptop,12,"(a6516 r669)");
lf[508]=C_static_lambda_info(C_heaptop,15,"(a6510 vars668)");
lf[509]=C_static_lambda_info(C_heaptop,40,"(walk-call fn656 args657 params658 k659)");
lf[510]=C_static_lambda_info(C_heaptop,15,"(a6609 vars690)");
lf[511]=C_static_lambda_info(C_heaptop,46,"(walk-inline-call class686 op687 args688 k689)");
lf[512]=C_static_lambda_info(C_heaptop,12,"(a6672 r700)");
lf[513]=C_static_lambda_info(C_heaptop,22,"(loop args697 vars698)");
lf[514]=C_static_lambda_info(C_heaptop,30,"(walk-arguments args694 wk695)");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"\004corevariable");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"\004coreglobal-ref");
C_save(tmp);
lf[515]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[516]=C_static_lambda_info(C_heaptop,14,"(atomic\077 n705)");
lf[517]=C_h_intern(&lf[517],6,"values");
lf[518]=C_static_lambda_info(C_heaptop,43,"(##compiler#perform-cps-conversion node569)");
lf[519]=C_h_intern(&lf[519],21,"foreign-callback-stub");
lf[520]=C_static_lambda_info(C_heaptop,89,"(make-foreign-callback-stub id718 name719 qualifiers720 return-type721 argument-"
"types722)");
lf[521]=C_h_intern(&lf[521],22,"foreign-callback-stub\077");
lf[522]=C_static_lambda_info(C_heaptop,29,"(foreign-callback-stub\077 x723)");
lf[523]=C_h_intern(&lf[523],24,"foreign-callback-stub-id");
lf[524]=C_static_lambda_info(C_heaptop,31,"(foreign-callback-stub-id x724)");
lf[525]=C_h_intern(&lf[525],29,"foreign-callback-stub-id-set!");
lf[526]=C_static_lambda_info(C_heaptop,43,"(foreign-callback-stub-id-set! x726 val727)");
lf[527]=C_h_intern(&lf[527],26,"foreign-callback-stub-name");
lf[528]=C_static_lambda_info(C_heaptop,33,"(foreign-callback-stub-name x730)");
lf[529]=C_h_intern(&lf[529],31,"foreign-callback-stub-name-set!");
lf[530]=C_static_lambda_info(C_heaptop,45,"(foreign-callback-stub-name-set! x732 val733)");
lf[531]=C_h_intern(&lf[531],32,"foreign-callback-stub-qualifiers");
lf[532]=C_static_lambda_info(C_heaptop,39,"(foreign-callback-stub-qualifiers x736)");
lf[533]=C_h_intern(&lf[533],37,"foreign-callback-stub-qualifiers-set!");
lf[534]=C_static_lambda_info(C_heaptop,51,"(foreign-callback-stub-qualifiers-set! x738 val739)");
lf[535]=C_h_intern(&lf[535],33,"foreign-callback-stub-return-type");
lf[536]=C_static_lambda_info(C_heaptop,40,"(foreign-callback-stub-return-type x742)");
lf[537]=C_h_intern(&lf[537],38,"foreign-callback-stub-return-type-set!");
lf[538]=C_static_lambda_info(C_heaptop,52,"(foreign-callback-stub-return-type-set! x744 val745)");
lf[539]=C_h_intern(&lf[539],36,"foreign-callback-stub-argument-types");
lf[540]=C_static_lambda_info(C_heaptop,43,"(foreign-callback-stub-argument-types x748)");
lf[541]=C_h_intern(&lf[541],41,"foreign-callback-stub-argument-types-set!");
lf[542]=C_static_lambda_info(C_heaptop,55,"(foreign-callback-stub-argument-types-set! x750 val751)");
lf[543]=C_h_intern(&lf[543],27,"\010compileranalyze-expression");
lf[544]=C_static_lambda_info(C_heaptop,6,"(grow)");
lf[545]=C_h_intern(&lf[545],17,"\010compilercollect!");
lf[546]=C_h_intern(&lf[546],10,"references");
lf[547]=C_static_lambda_info(C_heaptop,20,"(ref var891 node892)");
lf[548]=C_h_intern(&lf[548],13,"\010compilerput!");
lf[549]=C_h_intern(&lf[549],9,"undefined");
lf[550]=C_h_intern(&lf[550],7,"unknown");
lf[551]=C_h_intern(&lf[551],5,"value");
lf[552]=C_h_intern(&lf[552],12,"\010compilerget");
lf[553]=C_h_intern(&lf[553],4,"home");
lf[554]=C_h_intern(&lf[554],16,"\010compilerget-all");
lf[555]=C_h_intern(&lf[555],8,"constant");
lf[556]=C_static_lambda_info(C_heaptop,37,"(assign var872 val873 env874 here875)");
lf[557]=C_h_intern(&lf[557],8,"captured");
lf[558]=C_h_intern(&lf[558],6,"global");
lf[559]=C_h_intern(&lf[559],12,"\004corerecurse");
lf[560]=C_h_intern(&lf[560],44,"\010compileroptimizable-rest-argument-operators");
lf[561]=C_h_intern(&lf[561],15,"\010compilercount!");
lf[562]=C_h_intern(&lf[562],16,"o-r/access-count");
lf[563]=C_h_intern(&lf[563],14,"rest-parameter");
lf[564]=C_static_lambda_info(C_heaptop,14,"(a6994 arg801)");
lf[565]=C_h_intern(&lf[565],12,"\003sysfor-each");
lf[566]=C_h_intern(&lf[566],16,"standard-binding");
lf[567]=C_h_intern(&lf[567],10,"call-sites");
lf[568]=C_static_lambda_info(C_heaptop,22,"(loop vars811 vals812)");
lf[569]=C_static_lambda_info(C_heaptop,14,"(a7141 var822)");
lf[570]=C_static_lambda_info(C_heaptop,31,"(a7122 vars819 argc820 rest821)");
lf[571]=C_h_intern(&lf[571],18,"\004coredirect_lambda");
lf[572]=C_h_intern(&lf[572],6,"simple");
lf[573]=C_h_intern(&lf[573],28,"\010compilersimple-lambda-node\077");
lf[574]=C_h_intern(&lf[574],6,"vector");
lf[575]=C_static_lambda_info(C_heaptop,14,"(a7248 var836)");
lf[576]=C_h_intern(&lf[576],12,"contained-in");
lf[577]=C_h_intern(&lf[577],8,"contains");
lf[578]=C_static_lambda_info(C_heaptop,31,"(a7166 vars830 argc831 rest832)");
lf[579]=C_h_intern(&lf[579],8,"assigned");
lf[580]=C_h_intern(&lf[580],16,"assigned-locally");
lf[581]=C_h_intern(&lf[581],15,"potential-value");
lf[582]=C_static_string(C_heaptop,37,"redefinition of standard binding `~S\047");
lf[583]=C_static_string(C_heaptop,37,"redefinition of extended binding `~S\047");
lf[584]=C_h_intern(&lf[584],16,"extended-binding");
lf[585]=C_h_intern(&lf[585],9,"\004coreproc");
lf[586]=C_static_lambda_info(C_heaptop,38,"(walk n771 env772 localenv773 here774)");
lf[587]=C_static_lambda_info(C_heaptop,12,"(a7434 x871)");
lf[588]=C_static_lambda_info(C_heaptop,39,"(walkeach xs866 env867 lenv868 here869)");
lf[589]=C_static_lambda_info(C_heaptop,36,"(quick-put! plist893 prop894 val895)");
lf[590]=C_static_lambda_info(C_heaptop,14,"(a7584 id2901)");
lf[591]=C_h_intern(&lf[591],3,"any");
lf[592]=C_static_lambda_info(C_heaptop,30,"(contains\077 id896 other-ids897)");
lf[593]=C_h_intern(&lf[593],9,"replacing");
lf[594]=C_h_intern(&lf[594],10,"replacable");
lf[595]=C_h_intern(&lf[595],9,"removable");
lf[596]=C_h_intern(&lf[596],37,"\010compilerexpression-has-side-effects\077");
lf[597]=C_h_intern(&lf[597],21,"has-unused-parameters");
lf[598]=C_h_intern(&lf[598],13,"explicit-rest");
lf[599]=C_h_intern(&lf[599],6,"unused");
lf[600]=C_static_lambda_info(C_heaptop,14,"(a8033 var951)");
lf[601]=C_static_lambda_info(C_heaptop,31,"(a7987 vars948 argc949 rest950)");
lf[602]=C_h_intern(&lf[602],11,"collapsable");
lf[603]=C_h_intern(&lf[603],12,"contractable");
lf[604]=C_h_intern(&lf[604],9,"inlinable");
lf[605]=C_static_lambda_info(C_heaptop,12,"(a8144 v938)");
lf[606]=C_h_intern(&lf[606],28,"\010compilerscan-free-variables");
lf[607]=C_h_intern(&lf[607],5,"boxed");
lf[608]=C_static_string(C_heaptop,34,"global variable `~S\047 is never used");
lf[609]=C_static_string(C_heaptop,58,"local assignment to unused variable `~S\047 may be unintended");
lf[610]=C_static_lambda_info(C_heaptop,15,"(a8238 prop918)");
lf[611]=C_static_lambda_info(C_heaptop,23,"(a7614 sym902 plist903)");
lf[612]=C_h_intern(&lf[612],23,"\003syshash-table-for-each");
lf[613]=C_h_intern(&lf[613],1,"p");
lf[614]=C_static_string(C_heaptop,27,"analysis gathering phase...");
lf[615]=C_static_string(C_heaptop,27,"analysis traversal phase...");
lf[616]=C_h_intern(&lf[616],37,"\010compilerinitialize-analysis-database");
lf[617]=C_static_lambda_info(C_heaptop,39,"(##compiler#analyze-expression node760)");
lf[618]=C_h_intern(&lf[618],35,"\010compilerperform-closure-conversion");
lf[619]=C_static_lambda_info(C_heaptop,23,"(test sym1027 item1028)");
lf[620]=C_h_intern(&lf[620],12,"customizable");
lf[621]=C_static_lambda_info(C_heaptop,39,"(register-customizable! var1029 id1030)");
lf[622]=C_static_lambda_info(C_heaptop,30,"(register-direct-call! id1032)");
lf[623]=C_static_lambda_info(C_heaptop,7,"(a8411)");
lf[624]=C_static_lambda_info(C_heaptop,13,"(a8438 n1056)");
lf[625]=C_static_lambda_info(C_heaptop,25,"(a8421 vals1054 body1055)");
lf[626]=C_static_lambda_info(C_heaptop,13,"(a8468 n1079)");
lf[627]=C_h_intern(&lf[627],20,"node-parameters-set!");
lf[628]=C_static_string(C_heaptop,59,"known procedure called with wrong number of arguments: `~A\047");
lf[629]=C_h_intern(&lf[629],8,"toplevel");
lf[630]=C_h_intern(&lf[630],18,"captured-variables");
lf[631]=C_h_intern(&lf[631],12,"closure-size");
lf[632]=C_static_lambda_info(C_heaptop,12,"(walk n1256)");
lf[633]=C_static_lambda_info(C_heaptop,34,"(a8636 vars1083 argc1084 rest1085)");
lf[634]=C_static_lambda_info(C_heaptop,13,"(a8675 n1091)");
lf[635]=C_static_lambda_info(C_heaptop,31,"(gather n1034 here1035 env1036)");
lf[636]=C_h_intern(&lf[636],8,"\004coreref");
lf[637]=C_static_lambda_info(C_heaptop,36,"(ref-var n1241 here1242 closure1243)");
lf[638]=C_h_intern(&lf[638],10,"\004coreunbox");
lf[639]=C_h_intern(&lf[639],8,"\004corebox");
lf[640]=C_h_intern(&lf[640],12,"\004coreclosure");
lf[641]=C_h_intern(&lf[641],14,"\010compilerqnode");
lf[642]=C_h_intern(&lf[642],20,"\003sysmake-lambda-info");
lf[643]=C_h_intern(&lf[643],1,"\077");
lf[644]=C_h_intern(&lf[644],8,"->string");
lf[645]=C_h_intern(&lf[645],18,"\010compilerreal-name");
lf[646]=C_static_lambda_info(C_heaptop,13,"(a8952 v1201)");
lf[647]=C_static_lambda_info(C_heaptop,34,"(a8975 alias1190 val1191 body1192)");
lf[648]=C_h_intern(&lf[648],10,"fold-right");
lf[649]=C_static_lambda_info(C_heaptop,13,"(a8995 a1196)");
lf[650]=C_static_lambda_info(C_heaptop,13,"(a9049 v1184)");
lf[651]=C_h_intern(&lf[651],10,"boxed-rest");
lf[652]=C_static_lambda_info(C_heaptop,13,"(a9108 v1166)");
lf[653]=C_h_intern(&lf[653],6,"filter");
lf[654]=C_static_lambda_info(C_heaptop,34,"(a8859 vars1162 argc1163 rest1164)");
lf[655]=C_h_intern(&lf[655],16,"\004coreupdatebox_i");
lf[656]=C_h_intern(&lf[656],14,"\004coreupdatebox");
lf[657]=C_h_intern(&lf[657],13,"\004coreupdate_i");
lf[658]=C_h_intern(&lf[658],11,"\004coreupdate");
lf[659]=C_h_intern(&lf[659],19,"\010compilerimmediate\077");
lf[660]=C_static_string(C_heaptop,19,"bad node (closure2)");
lf[661]=C_h_intern(&lf[661],11,"\004coreswitch");
lf[662]=C_h_intern(&lf[662],9,"\004corecond");
lf[663]=C_h_intern(&lf[663],16,"\004coredirect_call");
lf[664]=C_h_intern(&lf[664],11,"\004corereturn");
lf[665]=C_static_lambda_info(C_heaptop,38,"(transform n1092 here1093 closure1094)");
lf[666]=C_static_lambda_info(C_heaptop,13,"(a9406 x1240)");
lf[667]=C_static_lambda_info(C_heaptop,42,"(maptransform xs1237 here1238 closure1239)");
lf[668]=C_static_string(C_heaptop,22,"calls to known targets");
lf[669]=C_static_lambda_info(C_heaptop,7,"(a9575)");
lf[670]=C_h_intern(&lf[670],16,"\003sysmake-promise");
lf[671]=C_static_string(C_heaptop,42,"closure conversion transformation phase...");
lf[672]=C_static_string(C_heaptop,23,"customizable procedures");
lf[673]=C_static_string(C_heaptop,37,"closure conversion gathering phase...");
lf[674]=C_static_lambda_info(C_heaptop,55,"(##compiler#perform-closure-conversion node1015 db1016)");
lf[675]=C_h_intern(&lf[675],19,"make-lambda-literal");
lf[676]=C_h_intern(&lf[676],14,"lambda-literal");
lf[677]=C_static_lambda_info(C_heaptop,267,"(make-lambda-literal id1293 external1294 arguments1295 argument-count1296 rest-a"
"rgument1297 temporaries1298 callee-signatures1299 allocated1300 directly-called1"
"301 closure-size1302 looping1303 customizable1304 rest-argument-mode1305 body130"
"6 direct1307 partition1308)");
lf[678]=C_h_intern(&lf[678],15,"lambda-literal\077");
lf[679]=C_static_lambda_info(C_heaptop,23,"(lambda-literal\077 x1309)");
lf[680]=C_h_intern(&lf[680],17,"lambda-literal-id");
lf[681]=C_static_lambda_info(C_heaptop,25,"(lambda-literal-id x1310)");
lf[682]=C_h_intern(&lf[682],22,"lambda-literal-id-set!");
lf[683]=C_static_lambda_info(C_heaptop,38,"(lambda-literal-id-set! x1312 val1313)");
lf[684]=C_h_intern(&lf[684],23,"lambda-literal-external");
lf[685]=C_static_lambda_info(C_heaptop,31,"(lambda-literal-external x1316)");
lf[686]=C_h_intern(&lf[686],28,"lambda-literal-external-set!");
lf[687]=C_static_lambda_info(C_heaptop,44,"(lambda-literal-external-set! x1318 val1319)");
lf[688]=C_h_intern(&lf[688],24,"lambda-literal-arguments");
lf[689]=C_static_lambda_info(C_heaptop,32,"(lambda-literal-arguments x1322)");
lf[690]=C_h_intern(&lf[690],29,"lambda-literal-arguments-set!");
lf[691]=C_static_lambda_info(C_heaptop,45,"(lambda-literal-arguments-set! x1324 val1325)");
lf[692]=C_h_intern(&lf[692],29,"lambda-literal-argument-count");
lf[693]=C_static_lambda_info(C_heaptop,37,"(lambda-literal-argument-count x1328)");
lf[694]=C_h_intern(&lf[694],34,"lambda-literal-argument-count-set!");
lf[695]=C_static_lambda_info(C_heaptop,50,"(lambda-literal-argument-count-set! x1330 val1331)");
lf[696]=C_h_intern(&lf[696],28,"lambda-literal-rest-argument");
lf[697]=C_static_lambda_info(C_heaptop,36,"(lambda-literal-rest-argument x1334)");
lf[698]=C_h_intern(&lf[698],33,"lambda-literal-rest-argument-set!");
lf[699]=C_static_lambda_info(C_heaptop,49,"(lambda-literal-rest-argument-set! x1336 val1337)");
lf[700]=C_h_intern(&lf[700],26,"lambda-literal-temporaries");
lf[701]=C_static_lambda_info(C_heaptop,34,"(lambda-literal-temporaries x1340)");
lf[702]=C_h_intern(&lf[702],31,"lambda-literal-temporaries-set!");
lf[703]=C_static_lambda_info(C_heaptop,47,"(lambda-literal-temporaries-set! x1342 val1343)");
lf[704]=C_h_intern(&lf[704],32,"lambda-literal-callee-signatures");
lf[705]=C_static_lambda_info(C_heaptop,40,"(lambda-literal-callee-signatures x1346)");
lf[706]=C_h_intern(&lf[706],37,"lambda-literal-callee-signatures-set!");
lf[707]=C_static_lambda_info(C_heaptop,53,"(lambda-literal-callee-signatures-set! x1348 val1349)");
lf[708]=C_h_intern(&lf[708],24,"lambda-literal-allocated");
lf[709]=C_static_lambda_info(C_heaptop,32,"(lambda-literal-allocated x1352)");
lf[710]=C_h_intern(&lf[710],29,"lambda-literal-allocated-set!");
lf[711]=C_static_lambda_info(C_heaptop,45,"(lambda-literal-allocated-set! x1354 val1355)");
lf[712]=C_h_intern(&lf[712],30,"lambda-literal-directly-called");
lf[713]=C_static_lambda_info(C_heaptop,38,"(lambda-literal-directly-called x1358)");
lf[714]=C_h_intern(&lf[714],35,"lambda-literal-directly-called-set!");
lf[715]=C_static_lambda_info(C_heaptop,51,"(lambda-literal-directly-called-set! x1360 val1361)");
lf[716]=C_h_intern(&lf[716],27,"lambda-literal-closure-size");
lf[717]=C_static_lambda_info(C_heaptop,35,"(lambda-literal-closure-size x1364)");
lf[718]=C_h_intern(&lf[718],32,"lambda-literal-closure-size-set!");
lf[719]=C_static_lambda_info(C_heaptop,48,"(lambda-literal-closure-size-set! x1366 val1367)");
lf[720]=C_h_intern(&lf[720],22,"lambda-literal-looping");
lf[721]=C_static_lambda_info(C_heaptop,30,"(lambda-literal-looping x1370)");
lf[722]=C_h_intern(&lf[722],27,"lambda-literal-looping-set!");
lf[723]=C_static_lambda_info(C_heaptop,43,"(lambda-literal-looping-set! x1372 val1373)");
lf[724]=C_h_intern(&lf[724],27,"lambda-literal-customizable");
lf[725]=C_static_lambda_info(C_heaptop,35,"(lambda-literal-customizable x1376)");
lf[726]=C_h_intern(&lf[726],32,"lambda-literal-customizable-set!");
lf[727]=C_static_lambda_info(C_heaptop,48,"(lambda-literal-customizable-set! x1378 val1379)");
lf[728]=C_h_intern(&lf[728],33,"lambda-literal-rest-argument-mode");
lf[729]=C_static_lambda_info(C_heaptop,41,"(lambda-literal-rest-argument-mode x1382)");
lf[730]=C_h_intern(&lf[730],38,"lambda-literal-rest-argument-mode-set!");
lf[731]=C_static_lambda_info(C_heaptop,54,"(lambda-literal-rest-argument-mode-set! x1384 val1385)");
lf[732]=C_h_intern(&lf[732],19,"lambda-literal-body");
lf[733]=C_static_lambda_info(C_heaptop,27,"(lambda-literal-body x1388)");
lf[734]=C_h_intern(&lf[734],24,"lambda-literal-body-set!");
lf[735]=C_static_lambda_info(C_heaptop,40,"(lambda-literal-body-set! x1390 val1391)");
lf[736]=C_h_intern(&lf[736],21,"lambda-literal-direct");
lf[737]=C_static_lambda_info(C_heaptop,29,"(lambda-literal-direct x1394)");
lf[738]=C_h_intern(&lf[738],26,"lambda-literal-direct-set!");
lf[739]=C_static_lambda_info(C_heaptop,42,"(lambda-literal-direct-set! x1396 val1397)");
lf[740]=C_h_intern(&lf[740],24,"lambda-literal-partition");
lf[741]=C_static_lambda_info(C_heaptop,32,"(lambda-literal-partition x1400)");
lf[742]=C_h_intern(&lf[742],29,"lambda-literal-partition-set!");
lf[743]=C_static_lambda_info(C_heaptop,45,"(lambda-literal-partition-set! x1402 val1403)");
lf[744]=C_h_intern(&lf[744],36,"\010compilerprepare-for-code-generation");
lf[745]=C_h_intern(&lf[745],14,"\004coreimmediate");
lf[746]=C_h_intern(&lf[746],3,"fix");
lf[747]=C_h_intern(&lf[747],4,"bool");
lf[748]=C_h_intern(&lf[748],4,"char");
tmp=C_intern(C_heaptop,3,"nil");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[749]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"eof");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[750]=C_h_pair(C_restore,tmp);
lf[751]=C_static_string(C_heaptop,23,"bad immediate (prepare)");
lf[752]=C_static_lambda_info(C_heaptop,25,"(immediate-literal x1634)");
lf[753]=C_static_lambda_info(C_heaptop,19,"(new-literal x1627)");
lf[754]=C_h_intern(&lf[754],36,"\010compilermake-block-variable-literal");
lf[755]=C_h_intern(&lf[755],36,"\010compilerblock-variable-literal-name");
lf[756]=C_h_intern(&lf[756],32,"\010compilerblock-variable-literal\077");
lf[757]=C_static_lambda_info(C_heaptop,16,"(a10823 lit1633)");
lf[758]=C_h_intern(&lf[758],10,"list-index");
lf[759]=C_static_lambda_info(C_heaptop,26,"(blockvar-literal var1630)");
lf[760]=C_static_lambda_info(C_heaptop,14,"(a10775 y1625)");
lf[761]=C_static_lambda_info(C_heaptop,15,"(literal x1621)");
lf[762]=C_h_intern(&lf[762],11,"\004coreglobal");
lf[763]=C_static_lambda_info(C_heaptop,28,"(walk-global var1456 sf1457)");
lf[764]=C_h_intern(&lf[764],10,"\004corelocal");
lf[765]=C_h_intern(&lf[765],12,"\004coreliteral");
lf[766]=C_static_lambda_info(C_heaptop,31,"(walk-var var1444 e1445 sf1446)");
lf[767]=C_static_string(C_heaptop,33,"identified direct recursive calls");
lf[768]=C_static_string(C_heaptop,17,"bad direct lambda");
lf[769]=C_h_intern(&lf[769],4,"none");
lf[770]=C_static_string(C_heaptop,20,"unused rest argument");
lf[771]=C_static_string(C_heaptop,32,"rest argument accessed as vector");
lf[772]=C_h_intern(&lf[772],7,"butlast");
lf[773]=C_static_lambda_info(C_heaptop,35,"(a10221 vars1527 argc1528 rest1529)");
lf[774]=C_h_intern(&lf[774],9,"\004corebind");
lf[775]=C_h_intern(&lf[775],13,"\004coresetlocal");
lf[776]=C_h_intern(&lf[776],16,"\004coresetglobal_i");
lf[777]=C_h_intern(&lf[777],14,"\004coresetglobal");
lf[778]=C_h_intern(&lf[778],1,"=");
lf[779]=C_static_string(C_heaptop,48,"coerced inexact literal number `~S\047 to fixnum ~S");
lf[780]=C_static_string(C_heaptop,45,"can not coerce inexact literal `~S\047 to fixnum");
lf[781]=C_static_lambda_info(C_heaptop,37,"(walk n1474 e1475 here1476 boxes1477)");
lf[782]=C_static_lambda_info(C_heaptop,14,"(a10724 x1620)");
lf[783]=C_static_lambda_info(C_heaptop,41,"(mapwalk xs1616 e1617 here1618 boxes1619)");
lf[784]=C_h_intern(&lf[784],31,"graph-cell-info$$-inregion-set!");
lf[785]=C_h_intern(&lf[785],15,"graph*partition");
lf[786]=C_h_intern(&lf[786],17,"graph-cell$$-info");
lf[787]=C_static_lambda_info(C_heaptop,14,"(a10896 c1642)");
lf[788]=C_static_lambda_info(C_heaptop,39,"(set-inregion! cells1640 partition1641)");
lf[789]=C_h_intern(&lf[789],9,"randomize");
lf[790]=C_static_lambda_info(C_heaptop,21,"(a11017 x1661 ei1662)");
lf[791]=C_h_intern(&lf[791],6,"member");
lf[792]=C_h_intern(&lf[792],8,"graph*id");
lf[793]=C_static_lambda_info(C_heaptop,17,"(a10998 cell1658)");
lf[794]=C_h_intern(&lf[794],8,"compress");
lf[795]=C_h_intern(&lf[795],10,"complement");
lf[796]=C_h_intern(&lf[796],10,"graph*cost");
lf[797]=C_static_lambda_info(C_heaptop,8,"(a11087)");
lf[798]=C_h_intern(&lf[798],13,"graph*balance");
lf[799]=C_static_lambda_info(C_heaptop,30,"(a11093 w1664 n#f1665 n#t1666)");
lf[800]=C_h_intern(&lf[800],21,"\010compilerpartition-fm");
lf[801]=C_h_intern(&lf[801],11,"graph*color");
lf[802]=C_h_intern(&lf[802],16,"graph*color-set!");
lf[803]=C_h_intern(&lf[803],21,"graph*partition-move!");
lf[804]=C_h_intern(&lf[804],16,"graph*neighbours");
lf[805]=C_h_intern(&lf[805],10,"graph*gain");
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
lf[806]=C_h_pair(C_restore,tmp);
lf[807]=C_h_intern(&lf[807],15,"\010compilerfactor");
lf[808]=C_static_lambda_info(C_heaptop,8,"(a11164)");
lf[809]=C_static_lambda_info(C_heaptop,30,"(a11170 w1673 n#f1674 n#t1675)");
lf[810]=C_static_lambda_info(C_heaptop,28,"(pway factors1656 cells1657)");
lf[811]=C_h_intern(&lf[811],12,"graph$->list");
lf[812]=C_h_intern(&lf[812],4,"sort");
lf[813]=C_h_intern(&lf[813],1,"<");
lf[814]=C_h_intern(&lf[814],32,"graph-cell$-add-undirected-edge!");
lf[815]=C_h_intern(&lf[815],10,"graph$-get");
lf[816]=C_static_lambda_info(C_heaptop,14,"(a11235 o1649)");
lf[817]=C_h_intern(&lf[817],4,"cdar");
lf[818]=C_static_lambda_info(C_heaptop,13,"(loop es1648)");
lf[819]=C_static_lambda_info(C_heaptop,26,"(a11204 sym1645 plist1646)");
lf[820]=C_h_intern(&lf[820],16,"graph$-add-cell!");
lf[821]=C_h_intern(&lf[821],16,"make-graph-cell$");
lf[822]=C_static_lambda_info(C_heaptop,14,"(a11265 l1644)");
lf[823]=C_static_string(C_heaptop,21,"partitioning phase...");
lf[824]=C_h_intern(&lf[824],11,"make-graph$");
lf[825]=C_static_lambda_info(C_heaptop,33,"(partition-phase! partitions1638)");
lf[826]=C_static_string(C_heaptop,23,"fast global assignments");
lf[827]=C_static_string(C_heaptop,22,"fast global references");
lf[828]=C_static_string(C_heaptop,24,"fast box initializations");
lf[829]=C_h_intern(&lf[829],1,"b");
lf[830]=C_static_string(C_heaptop,37,"  time needed for partitioning: ~A ms");
lf[831]=C_static_string(C_heaptop,20,"preparation phase...");
lf[832]=C_static_lambda_info(C_heaptop,71,"(##compiler#prepare-for-code-generation node1423 db1424 partitions1425)");
tmp=C_fix(105);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[835]=C_h_pair(C_restore,tmp);
lf[837]=C_h_intern(&lf[837],7,"\003sysgcd");
lf[838]=C_static_lambda_info(C_heaptop,14,"(mapf lst1718)");
lf[839]=C_static_lambda_info(C_heaptop,17,"(do1735 nexp1737)");
lf[840]=C_static_lambda_info(C_heaptop,31,"(next-prime nexp1733 comps1734)");
lf[841]=C_static_lambda_info(C_heaptop,18,"(a11416 prime1729)");
lf[842]=C_static_lambda_info(C_heaptop,43,"(lp comp1724 comps1725 primes1726 nexp1727)");
lf[844]=C_static_lambda_info(C_heaptop,33,"(prime:f u1742 v1743 b1744 n1745)");
lf[846]=C_static_lambda_info(C_heaptop,16,"(prime:fe m1763)");
lf[847]=C_static_lambda_info(C_heaptop,25,"(##compiler#factor k1764)");
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
lf[848]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[849]=C_h_intern(&lf[849],17,"\003syspeek-c-string");
lf[850]=C_h_intern(&lf[850],14,"make-parameter");
lf[851]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,852);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate(&lf[40],lf[41]);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t24=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,C_SCHEME_FALSE);}

/* k1911 */
static void f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1915 in k1911 */
static void f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1919 in k1915 in k1911 */
static void f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1923 in k1919 in k1915 in k1911 */
static void f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 317  make-parameter */
t4=C_retrieve(lf[850]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=C_set_block_item(lf[48],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[49]+1,lf[50]);
t5=C_set_block_item(lf[51],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[52],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[53],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[55],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[56],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[57],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[58],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[60],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[61],0,C_fix(997));
t16=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[63],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[64],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[66],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[67],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[68],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[69],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[70],0,C_SCHEME_FALSE);
t25=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t26=C_set_block_item(lf[72],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t29=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[77],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[78],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[79],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t35=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[83],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t40=C_set_block_item(lf[86],0,C_fix(-1));
t41=C_set_block_item(lf[87],0,C_SCHEME_TRUE);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t43=*((C_word*)lf[849]+1);
((C_proc4)(void*)(*((C_word*)t43+1)))(4,t43,t42,C_mpointer(&a,(void*)C_INSTALL_HOME),C_fix(0));}

/* k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=C_mutate((C_word*)lf[89]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t4=C_mutate((C_word*)lf[90]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t5=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t6=C_set_block_item(lf[92],0,C_SCHEME_FALSE);
t7=C_set_block_item(lf[93],0,C_fix(0));
t8=C_set_block_item(lf[94],0,C_SCHEME_FALSE);
t9=C_set_block_item(lf[95],0,C_SCHEME_END_OF_LIST);
t10=C_set_block_item(lf[96],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[97],0,C_SCHEME_FALSE);
t12=C_set_block_item(lf[98],0,C_SCHEME_FALSE);
t13=C_set_block_item(lf[99],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[100],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[101],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(lf[102],0,C_SCHEME_END_OF_LIST);
t17=C_set_block_item(lf[103],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[104],0,C_SCHEME_END_OF_LIST);
t19=C_set_block_item(lf[105],0,C_SCHEME_TRUE);
t20=C_set_block_item(lf[106],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[107],0,C_SCHEME_END_OF_LIST);
t22=C_set_block_item(lf[108],0,C_SCHEME_END_OF_LIST);
t23=C_set_block_item(lf[109],0,C_SCHEME_END_OF_LIST);
t24=C_set_block_item(lf[110],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[111],0,C_SCHEME_END_OF_LIST);
t26=C_set_block_item(lf[112],0,C_SCHEME_END_OF_LIST);
t27=C_set_block_item(lf[113],0,C_fix(0));
t28=C_set_block_item(lf[114],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[115],0,C_SCHEME_END_OF_LIST);
t30=C_set_block_item(lf[116],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[117],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[118],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(lf[119],0,C_SCHEME_END_OF_LIST);
t34=C_set_block_item(lf[120],0,C_SCHEME_END_OF_LIST);
t35=C_set_block_item(lf[121],0,C_SCHEME_END_OF_LIST);
t36=C_set_block_item(lf[122],0,C_SCHEME_TRUE);
t37=C_set_block_item(lf[123],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[124],0,C_SCHEME_END_OF_LIST);
t39=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t40=C_set_block_item(lf[126],0,C_SCHEME_END_OF_LIST);
t41=C_set_block_item(lf[127],0,C_SCHEME_END_OF_LIST);
t42=C_set_block_item(lf[128],0,C_SCHEME_END_OF_LIST);
t43=C_set_block_item(lf[129],0,C_SCHEME_FALSE);
t44=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=lf[137],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2074,a[2]=lf[345],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=lf[415],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5404,a[2]=lf[418],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=lf[420],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5416,a[2]=lf[422],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=lf[425],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[426]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5434,a[2]=lf[427],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[428]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=lf[429],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[430]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=lf[431],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[432]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5461,a[2]=lf[433],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[434]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5470,a[2]=lf[435],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[436]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5479,a[2]=lf[437],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5488,a[2]=lf[439],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=lf[441],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[442]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5506,a[2]=lf[443],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[444]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5515,a[2]=lf[445],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[446]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5524,a[2]=lf[447],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[448]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5533,a[2]=lf[449],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[450]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5542,a[2]=lf[451],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[452]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5551,a[2]=lf[453],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[454]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=lf[464],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5714,a[2]=lf[467],tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5759,a[2]=lf[469],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5804,a[2]=lf[473],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[266]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5844,a[2]=lf[475],tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5884,a[2]=lf[478],tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=lf[483],tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[484]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6058,a[2]=lf[518],tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[502]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6733,a[2]=lf[520],tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6739,a[2]=lf[522],tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6745,a[2]=lf[524],tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6754,a[2]=lf[526],tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6763,a[2]=lf[528],tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6772,a[2]=lf[530],tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6781,a[2]=lf[532],tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6790,a[2]=lf[534],tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6799,a[2]=lf[536],tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6808,a[2]=lf[538],tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6817,a[2]=lf[540],tmp=(C_word)a,a+=3,tmp));
t84=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6826,a[2]=lf[542],tmp=(C_word)a,a+=3,tmp));
t85=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6835,a[2]=lf[617],tmp=(C_word)a,a+=3,tmp));
t86=C_mutate((C_word*)lf[618]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=lf[674],tmp=(C_word)a,a+=3,tmp));
t87=C_mutate((C_word*)lf[675]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9582,a[2]=lf[677],tmp=(C_word)a,a+=3,tmp));
t88=C_mutate((C_word*)lf[678]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9588,a[2]=lf[679],tmp=(C_word)a,a+=3,tmp));
t89=C_mutate((C_word*)lf[680]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9594,a[2]=lf[681],tmp=(C_word)a,a+=3,tmp));
t90=C_mutate((C_word*)lf[682]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9603,a[2]=lf[683],tmp=(C_word)a,a+=3,tmp));
t91=C_mutate((C_word*)lf[684]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9612,a[2]=lf[685],tmp=(C_word)a,a+=3,tmp));
t92=C_mutate((C_word*)lf[686]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9621,a[2]=lf[687],tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[688]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9630,a[2]=lf[689],tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[690]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9639,a[2]=lf[691],tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[692]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9648,a[2]=lf[693],tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[694]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9657,a[2]=lf[695],tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[696]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9666,a[2]=lf[697],tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[698]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9675,a[2]=lf[699],tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[700]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9684,a[2]=lf[701],tmp=(C_word)a,a+=3,tmp));
t100=C_mutate((C_word*)lf[702]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9693,a[2]=lf[703],tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[704]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9702,a[2]=lf[705],tmp=(C_word)a,a+=3,tmp));
t102=C_mutate((C_word*)lf[706]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9711,a[2]=lf[707],tmp=(C_word)a,a+=3,tmp));
t103=C_mutate((C_word*)lf[708]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9720,a[2]=lf[709],tmp=(C_word)a,a+=3,tmp));
t104=C_mutate((C_word*)lf[710]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9729,a[2]=lf[711],tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[712]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9738,a[2]=lf[713],tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[714]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9747,a[2]=lf[715],tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[716]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9756,a[2]=lf[717],tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[718]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9765,a[2]=lf[719],tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[720]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9774,a[2]=lf[721],tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[722]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=lf[723],tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[724]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9792,a[2]=lf[725],tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[726]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9801,a[2]=lf[727],tmp=(C_word)a,a+=3,tmp));
t113=C_mutate((C_word*)lf[728]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9810,a[2]=lf[729],tmp=(C_word)a,a+=3,tmp));
t114=C_mutate((C_word*)lf[730]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9819,a[2]=lf[731],tmp=(C_word)a,a+=3,tmp));
t115=C_mutate((C_word*)lf[732]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9828,a[2]=lf[733],tmp=(C_word)a,a+=3,tmp));
t116=C_mutate((C_word*)lf[734]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9837,a[2]=lf[735],tmp=(C_word)a,a+=3,tmp));
t117=C_mutate((C_word*)lf[736]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9846,a[2]=lf[737],tmp=(C_word)a,a+=3,tmp));
t118=C_mutate((C_word*)lf[738]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9855,a[2]=lf[739],tmp=(C_word)a,a+=3,tmp));
t119=C_mutate((C_word*)lf[740]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9864,a[2]=lf[741],tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[742]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9873,a[2]=lf[743],tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[744]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9882,a[2]=lf[832],tmp=(C_word)a,a+=3,tmp));
t122=lf[833]=C_fix(121);;
t123=C_mutate(&lf[834],lf[835]);
t124=(C_word)C_a_i_vector(&a,11,C_fix(0),C_fix(0),C_fix(1),C_fix(1),C_fix(0),C_fix(1),C_fix(0),C_fix(1),C_fix(0),C_fix(0),C_fix(0));
t125=C_mutate(&lf[836],t124);
t126=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11458,a[2]=lf[840],tmp=(C_word)a,a+=3,tmp);
t127=C_SCHEME_UNDEFINED;
t128=(*a=C_VECTOR_TYPE|1,a[1]=t127,tmp=(C_word)a,a+=2,tmp);
t129=C_set_block_item(t128,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11365,a[2]=t126,a[3]=t128,a[4]=lf[842],tmp=(C_word)a,a+=5,tmp));
t130=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2409 lp */
t131=((C_word*)t128)[1];
f_11365(t131,t130,C_fix(3),C_SCHEME_END_OF_LIST,lf[848],C_fix(5));}

/* k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11493,2,t0,t1);}
t2=C_mutate(&lf[843],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11495,a[2]=lf[844],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[845],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11730,a[2]=lf[846],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[807]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11759,a[2]=lf[847],tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#factor in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11759,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11769,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_11769(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_fix(0));
t7=t5;
f_11769(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(1))));}}

/* k11767 in ##compiler#factor in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11769,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[2],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11785,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_negate(((C_word*)t0)[2]);
/* compiler.scm: 2493 prime:fe */
f_11730(t2,t3);}
else{
/* compiler.scm: 2494 prime:fe */
f_11730(((C_word*)t0)[3],((C_word*)t0)[2]);}}}

/* k11783 in k11767 in ##compiler#factor in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11785,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_fix(-1),t1));}

/* prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11730(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11730,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_fixnumevenp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(1));
/* compiler.scm: 2480 prime:fe */
t11=t3;
t12=t4;
t1=t11;
t2=t12;
goto loop;}
else{
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=t1;
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11653,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(C_retrieve2(lf[834],"prime:products"));
/* gcd */
t8=*((C_word*)lf[837]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t5,t7);}}}

/* k11651 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11653,2,t0,t1);}
t2=(C_word)C_fixnum_divide(((C_word*)t0)[3],t1);
t3=t1;
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_fixnum_shift_right(t6,C_fix(1));
/* compiler.scm: 2472 prime:f */
f_11495(t5,C_fix(1),C_fix(1),C_fix(2),t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11686,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t6)){
t7=t5;
f_11686(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11710,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_fixnum_difference(t2,C_fix(1));
t9=(C_word)C_fixnum_shift_right(t8,C_fix(1));
/* compiler.scm: 2475 prime:f */
f_11495(t7,C_fix(1),C_fix(1),C_fix(2),t9);}}}

/* k11708 in k11651 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11710,2,t0,t1);}
t2=((C_word*)t0)[3];
f_11686(t2,(C_truep(t1)?t1:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2])));}

/* k11684 in k11651 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11686,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11690,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_fixnum_shift_right(t3,C_fix(1));
/* compiler.scm: 2476 prime:f */
f_11495(t2,C_fix(1),C_fix(1),C_fix(2),t4);}

/* k11688 in k11684 in k11651 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11690,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));
/* compiler.scm: 2473 append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11663 in k11651 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11665,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2])));}

/* k11742 in prime:fe in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11744,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_fix(2),t1));}

/* prime:f in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11495(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11495,NULL,5,t1,t2,t3,t4,t5);}
t6=t5;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,C_fix(0)))){
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_eqp(t7,C_fix(1));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=t3;
t10=(C_word)C_eqp(t9,C_fix(1));
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11527,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_fixnum_difference(t2,C_fix(1));
t13=(C_word)C_fixnum_shift_right(t12,C_fix(1));
/* compiler.scm: 2458 prime:f */
t23=t11;
t24=C_fix(1);
t25=C_fix(1);
t26=C_fix(2);
t27=t13;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
t5=t27;
goto loop;}}}}
else{
if(C_truep((C_word)C_i_fixnumevenp(t5))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11568,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_fixnum_plus(t4,t4);
t9=(C_word)C_fixnum_shift_right(t5,C_fix(1));
/* compiler.scm: 2463 prime:f */
t23=t7;
t24=t2;
t25=t3;
t26=t8;
t27=t9;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
t5=t27;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11609,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_fixnum_plus(t2,t4);
t9=(C_word)C_fixnum_plus(t4,t4);
t10=(C_word)C_fixnum_difference(t5,t3);
t11=(C_word)C_fixnum_shift_right(t10,C_fix(1));
/* compiler.scm: 2465 prime:f */
t23=t7;
t24=t8;
t25=t3;
t26=t9;
t27=t11;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
t5=t27;
goto loop;}}}

/* k11607 in prime:f in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=(C_word)C_fixnum_shift_right(t4,C_fix(1));
/* compiler.scm: 2466 prime:f */
f_11495(((C_word*)t0)[6],((C_word*)t0)[2],t2,t3,t5);}}

/* k11566 in prime:f in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[3]),((C_word*)t0)[4]);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t5);
t7=(C_word)C_fixnum_shift_right(t6,C_fix(1));
/* compiler.scm: 2464 prime:f */
f_11495(((C_word*)t0)[6],t2,t3,t4,t7);}}

/* k11525 in prime:f in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11527,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11534,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_fixnum_shift_right(t4,C_fix(1));
/* compiler.scm: 2460 prime:f */
f_11495(t3,C_fix(1),C_fix(1),C_fix(2),t5);}

/* k11532 in k11525 in prime:f in k11491 in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11534,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));
/* compiler.scm: 2458 append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11365,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fudge(C_fix(21));
t7=(C_word)C_fixnum_divide(t6,t5);
t8=t2;
if(C_truep((C_word)C_fixnum_lessp(t8,t7))){
t9=(C_word)C_fixnum_times(t5,t2);
t10=(C_word)C_a_i_cons(&a,2,t5,t4);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11386,a[2]=t10,a[3]=t3,a[4]=t9,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_a_i_cons(&a,2,t9,t3);
/* compiler.scm: 2393 next-prime */
f_11458(t11,t5,t12);}
else{
t9=(C_word)C_fixnum_divide(t2,t5);
t10=(C_word)C_fixnum_times(t5,t5);
if(C_truep((C_word)C_fixnum_lessp(t9,t10))){
t11=(C_word)C_fixnum_times(t5,t5);
t12=C_mutate(&lf[833],t11);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11404,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2396 make-vector */
t14=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,t5,C_fix(0));}
else{
t11=(C_word)C_a_i_cons(&a,2,t2,t3);
t12=(C_word)C_a_i_cons(&a,2,t5,t4);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11436,a[2]=t12,a[3]=t11,a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 2404 next-prime */
f_11458(t13,t5,t14);}}}

/* k11434 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2402 lp */
t2=((C_word*)((C_word*)t0)[6])[1];
f_11365(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11402 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11404,2,t0,t1);}
t2=C_mutate(&lf[836],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11417,a[2]=lf[841],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a11416 in k11402 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11417,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_set(C_retrieve2(lf[836],"prime:sieve"),t2,C_fix(1)));}

/* k11405 in k11402 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11411,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* compiler.scm: 2400 reverse */
t4=*((C_word*)lf[341]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k11409 in k11405 in k11402 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[834],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k11384 in lp in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2391 lp */
t2=((C_word*)((C_word*)t0)[6])[1];
f_11365(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11458(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11458,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11463,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2406 reverse */
t6=*((C_word*)lf[341]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t4)[1]);}

/* k11461 in next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11463,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(C_fix(2),((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11472,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=lf[839],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11472(t7,((C_word*)t0)[2],t3);}

/* do1735 in k11461 in next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11472,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11490,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=((C_word*)((C_word*)t0)[2])[1];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11329,a[2]=t4,a[3]=t7,a[4]=lf[838],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_11329(t9,t3,t5);}

/* mapf in do1735 in k11461 in next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11329,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11353,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* gcd */
t6=*((C_word*)lf[837]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k11351 in mapf in do1735 in k11461 in next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(1),t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 2384 mapf */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11329(t4,((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11488 in do1735 in k11461 in next-prime in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_11472(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[91],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9882,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_END_OF_LIST;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_fix(0);
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_fix(0);
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_fix(0);
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10840,a[2]=lf[752],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10794,a[2]=t6,a[3]=lf[753],tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10808,a[2]=t6,a[3]=t24,a[4]=lf[759],tmp=(C_word)a,a+=5,tmp);
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10731,a[2]=t6,a[3]=t24,a[4]=t23,a[5]=lf[761],tmp=(C_word)a,a+=6,tmp);
t27=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9919,a[2]=t3,a[3]=t20,a[4]=t26,a[5]=t25,a[6]=lf[763],tmp=(C_word)a,a+=7,tmp);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9885,a[2]=t27,a[3]=t26,a[4]=lf[766],tmp=(C_word)a,a+=5,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9972,a[2]=t23,a[3]=t22,a[4]=t26,a[5]=t25,a[6]=t3,a[7]=t8,a[8]=t14,a[9]=t16,a[10]=t10,a[11]=t18,a[12]=t30,a[13]=t32,a[14]=t12,a[15]=t27,a[16]=t28,a[17]=lf[781],tmp=(C_word)a,a+=18,tmp));
t34=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10719,a[2]=t30,a[3]=lf[783],tmp=(C_word)a,a+=4,tmp));
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10888,a[2]=t3,a[3]=t8,a[4]=lf[825],tmp=(C_word)a,a+=5,tmp);
t36=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11281,a[2]=t2,a[3]=t30,a[4]=t4,a[5]=t35,a[6]=t18,a[7]=t20,a[8]=t22,a[9]=t8,a[10]=t6,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2341 ##compiler#debugging */
t37=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[613],lf[831]);}

/* k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 2342 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9972(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11284,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11290,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 2344 partition-phase! */
t4=((C_word*)t0)[3];
f_10888(t4,t3,((C_word*)t0)[2]);}

/* k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
/* compiler.scm: 2345 sprintf */
t6=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,lf[830],t5);}

/* k11307 in k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2345 ##compiler#debugging */
t2=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[829],t1);}

/* k11291 in k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2346 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[165],lf[828],((C_word*)((C_word*)t0)[2])[1]);}

/* k11294 in k11291 in k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2347 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[165],lf[827],((C_word*)((C_word*)t0)[2])[1]);}

/* k11297 in k11294 in k11291 in k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2348 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[165],lf[826],((C_word*)((C_word*)t0)[2])[1]);}

/* k11300 in k11297 in k11294 in k11291 in k11288 in k11282 in k11279 in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2349 values */
C_values(5,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10888,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10891,a[2]=lf[788],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10916,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2221 make-graph$ */
t5=C_retrieve(lf[824]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,*((C_word*)lf[134]+1));}

/* k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2222 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[613],lf[823]);}

/* k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11266,a[2]=((C_word*)t0)[4],a[3]=lf[822],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[6])[1]);}

/* a11265 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11274,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11278,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2226 lambda-literal-id */
t5=C_retrieve(lf[680]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k11276 in a11265 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2226 make-graph-cell$ */
t2=C_retrieve(lf[821]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k11272 in a11265 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2226 graph$-add-cell! */
t2=C_retrieve(lf[820]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11205,a[2]=((C_word*)t0)[4],a[3]=lf[819],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2228 ##sys#hash-table-for-each */
t4=C_retrieve(lf[612]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11205,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11211,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[818],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_11211(t7,t1,t3);}

/* loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11211,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11215,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11231,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11264,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2232 caar */
t6=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_11231(t5,C_SCHEME_FALSE);}}

/* k11262 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11231(t2,(C_word)C_eqp(t1,lf[577]));}

/* k11229 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_11231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11231,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11236,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[816],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11254,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2240 cdar */
t4=*((C_word*)lf[817]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11215(2,t2,C_SCHEME_UNDEFINED);}}

/* k11252 in k11229 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11235 in k11229 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11240,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2235 graph$-get */
t4=C_retrieve(lf[815]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11238 in a11235 in k11229 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11240,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11250,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2239 graph$-get */
t3=C_retrieve(lf[815]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11248 in k11238 in a11235 in k11229 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2237 graph-cell$-add-undirected-edge! */
t2=C_retrieve(lf[814]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11213 in loop in a11204 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 2241 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11211(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2246 randomize */
t3=C_retrieve(lf[789]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(20040619));}

/* k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10928,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10933,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10969,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11203,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2249 ##compiler#factor */
t9=C_retrieve(lf[807]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[2]);}

/* k11201 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2249 sort */
t2=C_retrieve(lf[812]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[813]+1));}

/* k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10973,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2250 graph$->list */
t3=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10973,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10975,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=lf[810],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10975(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
loop:
a=C_alloc(46);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10975,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[7])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[7])+1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10983,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10993,a[2]=t6,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10999,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=lf[793],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t9=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,C_fix(1));
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
/* compiler.scm: 2273 pway */
t24=t6;
t25=t9;
t26=t3;
t1=t24;
t2=t25;
t3=t26;
goto loop;}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,C_fix(2));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11048,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11088,a[2]=((C_word*)t0)[2],a[3]=lf[797],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11094,a[2]=t3,a[3]=lf[799],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2276 ##compiler#partition-fm */
t14=C_retrieve(lf[800]);
((C_proc14)C_retrieve_proc(t14))(14,t14,t11,t3,C_retrieve(lf[792]),C_retrieve(lf[801]),C_retrieve(lf[802]),C_retrieve(lf[785]),C_retrieve(lf[803]),C_retrieve(lf[804]),C_retrieve(lf[805]),t12,t13,lf[806],C_fix(10));}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11105,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t6,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=((C_word*)t0)[2],a[3]=lf[808],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11171,a[2]=t3,a[3]=lf[809],tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t2);
t15=(C_word)C_fixnum_decrease(t14);
t16=(C_word)C_a_i_cons(&a,2,C_fix(1),t15);
/* compiler.scm: 2302 ##compiler#partition-fm */
t17=C_retrieve(lf[800]);
((C_proc14)C_retrieve_proc(t17))(14,t17,t11,t3,C_retrieve(lf[792]),C_retrieve(lf[801]),C_retrieve(lf[802]),C_retrieve(lf[785]),C_retrieve(lf[803]),C_retrieve(lf[804]),C_retrieve(lf[805]),t12,t13,t16,C_fix(10));}}}}

/* a11170 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11171,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(((C_word*)t0)[2]);
/* compiler.scm: 2309 graph*balance */
t6=C_retrieve(lf[798]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t1,((C_word*)t0)[2],t5,t2,t3,t4);}

/* a11164 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11165,2,t0,t1);}
/* compiler.scm: 2307 graph*cost */
t2=C_retrieve(lf[796]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11163,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2315 complement */
t4=C_retrieve(lf[795]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[785]));}

/* k11161 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11111,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[785]),((C_word*)t0)[4]);}

/* k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2319 set-inregion! */
f_10891(t2,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11155,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2321 compress */
t6=C_retrieve(lf[794]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k11153 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2320 pway */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10975(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11115 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2323 set-inregion! */
f_10891(t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k11118 in k11115 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11135,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_decrease(t4);
/* compiler.scm: 2324 ##compiler#factor */
t6=C_retrieve(lf[807]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,t5);}

/* k11133 in k11118 in k11115 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 2324 append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11125 in k11118 in k11115 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11131,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2325 compress */
t3=C_retrieve(lf[794]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11129 in k11125 in k11118 in k11115 in k11112 in k11109 in k11106 in k11103 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2324 pway */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10975(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11093 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11094,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(((C_word*)t0)[2]);
/* compiler.scm: 2283 graph*balance */
t6=C_retrieve(lf[798]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t1,((C_word*)t0)[2],t5,t2,t3,t4);}

/* a11087 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11088,2,t0,t1);}
/* compiler.scm: 2281 graph*cost */
t2=C_retrieve(lf[796]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11086,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2290 complement */
t4=C_retrieve(lf[795]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[785]));}

/* k11084 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11054,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[785]),((C_word*)t0)[3]);}

/* k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2294 set-inregion! */
f_10891(t2,((C_word*)t0)[4],C_SCHEME_FALSE);}

/* k11055 in k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11082,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2295 compress */
t5=C_retrieve(lf[794]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k11080 in k11055 in k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2295 pway */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10975(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11058 in k11055 in k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2297 set-inregion! */
f_10891(t2,((C_word*)t0)[3],C_SCHEME_TRUE);}

/* k11061 in k11058 in k11055 in k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11063,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11074,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2298 compress */
t4=C_retrieve(lf[794]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11072 in k11061 in k11058 in k11055 in k11052 in k11049 in k11046 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2298 pway */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10975(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10998 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10999,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2261 graph*id */
t4=C_retrieve(lf[792]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11001 in a10998 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11018,a[2]=lf[790],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2262 member */
t4=*((C_word*)lf[791]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t1,((C_word*)((C_word*)t0)[2])[1],t3);}

/* a11017 in k11001 in a10998 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11018,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11026,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2264 lambda-literal-id */
t5=C_retrieve(lf[680]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k11024 in a11017 in k11001 in a10998 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11004 in k11001 in a10998 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 2266 lambda-literal-partition-set! */
t3=C_retrieve(lf[742]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10991 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10983(2,t4,t3);}

/* k10981 in pway in k10971 in k10967 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k10931 in k10926 in k10923 in k10920 in k10917 in k10914 in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2338 randomize */
t2=C_retrieve(lf[789]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* set-inregion! in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10891(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10891,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10897,a[2]=t3,a[3]=lf[787],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10896 in set-inregion! in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10897,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10905,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2218 graph-cell$$-info */
t4=C_retrieve(lf[786]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10903 in a10896 in set-inregion! in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10913,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2219 graph*partition */
t3=C_retrieve(lf[785]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10911 in k10903 in a10896 in set-inregion! in partition-phase! in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[4]);
/* compiler.scm: 2217 graph-cell-info$$-inregion-set! */
t3=C_retrieve(lf[784]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10719,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10725,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[782],tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a10724 in mapwalk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10725,3,t0,t1,t2);}
/* compiler.scm: 2180 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9972(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word *a;
loop:
a=C_alloc(137);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9972,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[176]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[585]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[493]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2015 walk-var */
t16=((C_word*)t0)[16];
f_9885(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[505]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2018 walk-global */
t17=((C_word*)t0)[15];
f_9919(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[663]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10030,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2022 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_10719(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[249]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10050,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2026 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_10719(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[147]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10074,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10078,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2029 ##compiler#estimate-foreign-result-size */
t22=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[151]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10102,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10106,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2033 ##compiler#estimate-foreign-result-size */
t23=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[640]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10123,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2038 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10719(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[639]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10150,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2042 walk */
t93=t24;
t94=t25;
t95=t3;
t96=t4;
t97=t5;
t1=t93;
t2=t94;
t3=t95;
t4=t96;
t5=t97;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[656]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10166,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2046 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10719(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[486]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[571]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[571]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10222,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,a[16]=lf[773],tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2066 ##compiler#decompose-lambda-list */
t36=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[206]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[639],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10406,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2124 walk */
t93=t34;
t94=t27;
t95=t3;
t96=t4;
t97=t5;
t1=t93;
t2=t94;
t3=t95;
t4=t96;
t5=t97;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[232]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2130 ##compiler#posq */
t30=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[487]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10567,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2154 lset-adjoin */
t31=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[778]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[559]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10610,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10610(t32,t31);}
else{
t30=t29;
f_10610(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[144]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
if(C_truep((C_word)C_fixnump(t30))){
/* compiler.scm: 2166 immediate-literal */
f_10840(t1,t30);}
else{
if(C_truep((C_word)C_i_numberp(t30))){
t31=(C_word)C_eqp(lf[363],C_retrieve(lf[49]));
if(C_truep(t31)){
if(C_truep((C_word)C_i_integerp(t30))){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10662,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t30,tmp=(C_word)a,a+=5,tmp);
t33=(C_word)C_i_inexact_to_exact(t30);
/* compiler.scm: 2170 warning */
t34=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t34))(5,t34,t32,lf[779],t30,t33);}
else{
/* compiler.scm: 2172 quit */
t32=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t32))(4,t32,t1,lf[780],t30);}}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10686,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2173 literal */
t33=((C_word*)t0)[4];
f_10731(t33,t32,t30);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10692,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2174 ##compiler#immediate? */
t32=C_retrieve(lf[659]);
((C_proc3)C_retrieve_proc(t32))(3,t32,t31,t30);}}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10708,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2177 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_10719(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10706 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10708,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10690 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10692,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2174 immediate-literal */
f_10840(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10705,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2175 literal */
t3=((C_word*)t0)[2];
f_10731(t3,t2,((C_word*)t0)[3]);}}

/* k10703 in k10690 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10705,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[765],t2,C_SCHEME_END_OF_LIST));}

/* k10684 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10686,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[765],t2,C_SCHEME_END_OF_LIST));}

/* k10660 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2171 immediate-literal */
f_10840(((C_word*)t0)[2],t2);}

/* k10608 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10610,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10613,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2161 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10719(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10611 in k10608 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10613,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10565 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10567,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10579,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10579(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10579(t6,C_SCHEME_FALSE);}}

/* k10577 in k10565 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10570(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10570(t2,C_SCHEME_UNDEFINED);}}

/* k10568 in k10565 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10570,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10573,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2157 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10719(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10571 in k10568 in k10565 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10573,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10447,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10463,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2132 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_9972(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[68]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10536,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10536(2,t5,t3);}
else{
t5=C_retrieve(lf[55]);
if(C_truep(t5)){
t6=t4;
f_10536(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[56]));
if(C_truep(t6)){
t7=t4;
f_10536(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10548,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2138 ##compiler#get */
t8=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[566]);}}}}}

/* k10546 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10536(2,t2,t1);}
else{
/* compiler.scm: 2139 ##compiler#get */
t2=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[584]);}}

/* k10534 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10536,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[71]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[144]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2141 ##compiler#immediate? */
t8=C_retrieve(lf[659]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10475(2,t6,C_SCHEME_FALSE);}}

/* k10473 in k10534 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10475,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[176],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10481(t6,t5);}
else{
t4=t3;
f_10481(t4,C_SCHEME_UNDEFINED);}}

/* k10479 in k10473 in k10534 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10481,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[776]:lf[777]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10505,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2147 blockvar-literal */
t4=((C_word*)t0)[4];
f_10808(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2148 literal */
t4=((C_word*)t0)[2];
f_10731(t4,t3,((C_word*)t0)[3]);}}

/* k10503 in k10479 in k10473 in k10534 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10505,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10497,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2150 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9972(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10495 in k10503 in k10479 in k10473 in k10534 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10497,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10461 in k10445 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10463,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[775],((C_word*)t0)[2],t2));}

/* k10404 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10410,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2125 append */
t5=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10416 in k10404 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10422,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2125 append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10420 in k10416 in k10404 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2125 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_9972(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10408 in k10404 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10410,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[774],((C_word*)t0)[2],t2));}

/* a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10222,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10343,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2072 ##compiler#get */
t8=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[546]);}
else{
t7=t6;
f_10229(2,t7,C_SCHEME_FALSE);}}

/* k10341 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10349,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2073 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[579]);}

/* k10347 in k10341 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10349,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10229(2,t2,lf[330]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10374,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2074 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[651]);}}

/* k10372 in k10347 in k10341 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10355(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10355(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10353 in k10347 in k10341 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10229(2,t2,lf[769]);}
else{
/* compiler.scm: 2075 ##compiler#get */
t2=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[563]);}}

/* k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10232,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10334,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[769],t1);
if(C_truep(t5)){
/* compiler.scm: 2079 butlast */
t6=C_retrieve(lf[772]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10334(2,t6,((C_word*)t0)[7]);}}

/* k10332 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2076 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9972(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10235,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[769]);
if(C_truep(t3)){
/* compiler.scm: 2084 ##compiler#debugging */
t4=C_retrieve(lf[164]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[165],lf[770],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[574]);
if(C_truep(t4)){
/* compiler.scm: 2085 ##compiler#debugging */
t5=C_retrieve(lf[164]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[165],lf[771],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10235(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2087 ##compiler#bomb */
t4=C_retrieve(lf[503]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[768],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10238(2,t4,C_SCHEME_UNDEFINED);}}

/* k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10260,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[104])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10276,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2099 ##compiler#get */
t7=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[631]);}

/* k10274 in k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10276,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10283(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10302,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2103 ##compiler#debugging */
t7=C_retrieve(lf[164]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[165],lf[767],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10283(t6,C_SCHEME_FALSE);}}}

/* k10300 in k10274 in k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10283(t2,C_SCHEME_TRUE);}

/* k10281 in k10274 in k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10283,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10287(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2105 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[620]);}}

/* k10285 in k10281 in k10274 in k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2089 make-lambda-literal */
t2=C_retrieve(lf[675]);
((C_proc18)C_retrieve_proc(t2))(18,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k10258 in k10236 in k10233 in k10230 in k10227 in a10221 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[485],lf[585],t9,C_SCHEME_END_OF_LIST));}

/* k10164 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10169,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10175,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[493],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10175(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10175(t6,C_SCHEME_FALSE);}}

/* k10173 in k10164 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10169(t4,lf[655]);}
else{
t2=((C_word*)t0)[3];
f_10169(t2,((C_word*)t0)[2]);}}

/* k10167 in k10164 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10169,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10148 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10150,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[639],((C_word*)t0)[2],t2));}

/* k10121 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10123,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],lf[640],((C_word*)t0)[2],t1));}

/* k10104 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2033 ##compiler#words */
t2=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10100 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10102,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10095,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2034 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_10719(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10093 in k10100 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10095,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10076 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2029 ##compiler#words */
t2=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10072 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10074,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10048 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10050,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10028 in walk in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10030,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9885,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9889,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1983 ##compiler#posq */
t6=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k9887 in walk-var in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9889,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[764],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1984 keyword? */
t3=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k9902 in k9887 in walk-var in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9904,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9914,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1984 literal */
t3=((C_word*)t0)[5];
f_10731(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 1985 walk-global */
t2=((C_word*)t0)[3];
f_9919(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k9912 in k9902 in k9887 in walk-var in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9914,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[765],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9919,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9923(2,t5,t3);}
else{
t5=C_retrieve(lf[68]);
if(C_truep(t5)){
t6=t4;
f_9923(2,t6,t5);}
else{
t6=C_retrieve(lf[55]);
if(C_truep(t6)){
t7=t4;
f_9923(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[56]));
if(C_truep(t7)){
t8=t4;
f_9923(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9964,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1992 ##compiler#get */
t9=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[566]);}}}}}

/* k9962 in walk-global in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9923(2,t2,t1);}
else{
/* compiler.scm: 1993 ##compiler#get */
t2=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[584]);}}

/* k9921 in walk-global in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9923,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[71]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_9929(t6,t5);}
else{
t4=t3;
f_9929(t4,C_SCHEME_UNDEFINED);}}

/* k9927 in k9921 in walk-global in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9929,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 1999 blockvar-literal */
t3=((C_word*)t0)[3];
f_10808(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2000 literal */
t3=((C_word*)t0)[2];
f_10731(t3,t2,((C_word*)t0)[5]);}}

/* k9937 in k9927 in k9921 in walk-global in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9939,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[762],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10731,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2183 ##compiler#immediate? */
t4=C_retrieve(lf[659]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10736 in literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10738,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2183 immediate-literal */
f_10840(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10776,a[2]=((C_word*)t0)[4],a[3]=lf[760],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2185 list-index */
t4=C_retrieve(lf[758]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_10744(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10744(2,t3,C_SCHEME_FALSE);}}}

/* a10775 in k10736 in literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10776,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10742 in k10736 in literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10744,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2187 ##compiler#posq */
t3=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k10751 in k10742 in k10736 in literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2188 new-literal */
t2=((C_word*)t0)[3];
f_10794(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10808,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10812,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10824,a[2]=t2,a[3]=lf[757],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2196 list-index */
t5=C_retrieve(lf[758]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a10823 in blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10824,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10831,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2198 ##compiler#block-variable-literal? */
t4=C_retrieve(lf[756]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10829 in a10823 in blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10831,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2199 ##compiler#block-variable-literal-name */
t3=C_retrieve(lf[755]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10836 in k10829 in a10823 in blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k10810 in blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10812,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2201 ##compiler#make-block-variable-literal */
t3=C_retrieve(lf[754]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k10820 in k10810 in blockvar-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2201 new-literal */
t2=((C_word*)t0)[3];
f_10794(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10794,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10802,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2192 append */
t6=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k10800 in new-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_10840(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10840,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10844,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_10844(2,t4,(C_word)C_a_i_list(&a,2,lf[746],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t4=t3;
f_10844(2,t4,(C_word)C_a_i_list(&a,2,lf[747],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t3;
f_10844(2,t4,(C_word)C_a_i_list(&a,2,lf[748],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10844(2,t4,lf[749]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t3;
f_10844(2,t4,lf[750]);}
else{
/* compiler.scm: 2210 ##compiler#bomb */
t4=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[751]);}}}}}}

/* k10842 in immediate-literal in ##compiler#prepare-for-code-generation in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_10844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10844,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],lf[745],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-partition-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9873,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(16),t3);}

/* lambda-literal-partition in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9864,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(16)));}

/* lambda-literal-direct-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9855,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-direct in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9846,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-body-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9837,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-body in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9828,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-rest-argument-mode-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9819,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-rest-argument-mode in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9810,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-customizable-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9801,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-customizable in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9792,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-looping-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9783,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-looping in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9774,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-closure-size-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9765,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-closure-size in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9756,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-directly-called-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9747,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-directly-called in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9738,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-allocated-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9729,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-allocated in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9720,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-callee-signatures-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9711,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-callee-signatures in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9702,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-temporaries-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9693,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-temporaries in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9684,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-rest-argument-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9675,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-rest-argument in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9666,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-argument-count-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9657,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-argument-count in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9648,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-arguments-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9639,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-arguments in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9630,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-external-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9621,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-external in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9612,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-id-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9603,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[676]);
/* compiler.scm: 1953 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal-id in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9594,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[676]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal? in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9588,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[676]));}

/* make-lambda-literal in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16,C_word t17){
C_word tmp;
C_word t18;
C_word ab[18],*a=ab;
if(c!=18) C_bad_argc(c,18);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr18,(void*)f_9582,18,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17);}
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_record(&a,17,lf[676],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17));}

/* ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[54],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8352,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8355,a[2]=t3,a[3]=lf[619],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8361,a[2]=t3,a[3]=t7,a[4]=lf[621],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8371,a[2]=t5,a[3]=lf[622],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8382,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,a[7]=lf[635],tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9413,a[2]=lf[637],tmp=(C_word)a,a+=3,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8712,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,a[7]=lf[665],tmp=(C_word)a,a+=8,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9401,a[2]=t16,a[3]=lf[667],tmp=(C_word)a,a+=4,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9549,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1941 ##compiler#debugging */
t22=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[613],lf[673]);}

/* k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1942 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8382(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1943 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[165],lf[672],((C_word*)((C_word*)t0)[2])[1]);}

/* k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1944 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[613],lf[671]);}

/* k9556 in k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9561,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1945 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8712(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9559 in k9556 in k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9564,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9564(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9574,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9576,a[2]=lf[669],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1947 ##sys#make-promise */
t6=*((C_word*)lf[670]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9575 in k9559 in k9556 in k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9576,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[104])));}

/* k9572 in k9559 in k9556 in k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1947 ##compiler#debugging */
t2=C_retrieve(lf[164]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[165],lf[668],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9562 in k9559 in k9556 in k9553 in k9550 in k9547 in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9401,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9407,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[666],tmp=(C_word)a,a+=6,tmp);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9406 in maptransform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9407,3,t0,t1,t2);}
/* compiler.scm: 1913 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8712(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8712,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[144]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8731(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[176]);
if(C_truep(t13)){
t14=t12;
f_8731(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[585]);
t15=t12;
f_8731(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[505])));}}}

/* k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8731,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[493]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8743,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1788 ref-var */
f_9413(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[156]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_8764(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[487]);
if(C_truep(t5)){
t6=t4;
f_8764(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[248]);
if(C_truep(t6)){
t7=t4;
f_8764(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[249]);
if(C_truep(t7)){
t8=t4;
f_8764(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[324]);
if(C_truep(t8)){
t9=t4;
f_8764(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[147]);
if(C_truep(t9)){
t10=t4;
f_8764(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t10)){
t11=t4;
f_8764(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[661]);
if(C_truep(t11)){
t12=t4;
f_8764(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[662]);
if(C_truep(t12)){
t13=t4;
f_8764(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[663]);
if(C_truep(t13)){
t14=t4;
f_8764(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[559]);
if(C_truep(t14)){
t15=t4;
f_8764(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[664]);
if(C_truep(t15)){
t16=t4;
f_8764(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[151]);
t17=t4;
f_8764(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[237])));}}}}}}}}}}}}}}}

/* k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1796 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9401(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[206]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8785,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1800 test */
t5=((C_word*)t0)[4];
f_8355(t5,t4,t3,lf[607]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[486]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[571]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],a[12]=lf[654],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1816 ##compiler#decompose-lambda-list */
t7=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[232]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9131,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[144],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1876 ##compiler#immediate? */
t13=C_retrieve(lf[659]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9131(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[325]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[87]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[485],lf[585],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9280,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[87]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9287,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9291,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1907 ##sys#make-lambda-info */
t16=C_retrieve(lf[642]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9280(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 1910 ##compiler#bomb */
t7=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[660]);}}}}}}

/* k9289 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1907 ##compiler#qnode */
t2=C_retrieve(lf[641]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9285 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9287,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9280(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9278 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9280,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[640],((C_word*)t0)[2],t2));}

/* k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9131,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[176],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1878 ##compiler#posq */
t4=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9137,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1880 test */
t3=((C_word*)t0)[3];
f_8355(t3,t2,((C_word*)t0)[2],lf[607]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1892 test */
t3=((C_word*)t0)[3];
f_8355(t3,t2,((C_word*)t0)[2],lf[607]);}}

/* k9205 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9207,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[655]:lf[656]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1896 ##compiler#varnode */
t4=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9237,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1900 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8712(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9235 in k9205 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9237,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[232],((C_word*)t0)[2],t2));}

/* k9218 in k9205 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9224,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1897 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8712(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9222 in k9218 in k9205 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9224,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9144 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9146,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[655]:lf[656]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1884 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[657]:lf[658]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1890 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9191 in k9144 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9197,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1891 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8712(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9195 in k9191 in k9144 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9197,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9171 in k9144 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9173,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[636],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1885 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8712(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9167 in k9171 in k9144 in k9135 in k9129 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8860,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9109,a[2]=((C_word*)t0)[2],a[3]=lf[652],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1819 filter */
t7=C_retrieve(lf[653]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9108 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9109,3,t0,t1,t2);}
/* compiler.scm: 1819 test */
t3=((C_word*)t0)[2];
f_8355(t3,t1,t2,lf[607]);}

/* k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9107,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[167]),t1);}

/* k9105 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1820 map */
t2=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1821 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[174]);}

/* k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8870,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[629]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_8876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1823 test */
t4=((C_word*)t0)[2];
f_8355(t4,t3,t2,lf[630]);}

/* k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8876,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1824 test */
t4=((C_word*)t0)[2];
f_8355(t4,t3,((C_word*)t0)[17],lf[631]);}

/* k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8882,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[87]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_8888(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_8888(t4,C_SCHEME_FALSE);}}

/* k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8888,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1830 test */
t4=((C_word*)t0)[2];
f_8355(t4,t3,((C_word*)t0)[6],lf[607]);}
else{
t3=t2;
f_8891(2,t3,C_SCHEME_FALSE);}}

/* k9072 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1831 test */
t3=((C_word*)t0)[2];
f_8355(t3,t2,((C_word*)t0)[6],lf[563]);}
else{
t2=((C_word*)t0)[4];
f_8891(2,t2,C_SCHEME_FALSE);}}

/* k9075 in k9072 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1832 ##compiler#put! */
t4=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[651],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_8891(2,t2,C_SCHEME_FALSE);}}

/* k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8891,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9035,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9050,a[2]=((C_word*)t0)[7],a[3]=lf[650],tmp=(C_word)a,a+=4,tmp);
/* map */
t9=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9049 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9050,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9033 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1842 ##compiler#build-lambda-list */
t4=C_retrieve(lf[218]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1851 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8712(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8976,a[2]=lf[647],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8990,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1856 unzip1 */
t5=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_8968(2,t3,t1);}}

/* k8988 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8994,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8996,a[2]=lf[649],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8995 in k8988 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9007,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1857 ##compiler#varnode */
t5=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9005 in a8995 in k8988 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9007,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[639],C_SCHEME_END_OF_LIST,t2));}

/* k8992 in k8988 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1853 fold-right */
t2=C_retrieve(lf[648]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8975 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8976,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[485],lf[206],t5,t6));}

/* k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8968,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8914,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[646],tmp=(C_word)a,a+=6,tmp);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a8952 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8953,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1860 ##compiler#varnode */
t4=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k8959 in a8952 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1860 ref-var */
f_9413(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8928,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8932,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8936,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1868 ##compiler#real-name */
t7=C_retrieve(lf[645]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_8917(2,t3,t1);}}

/* k8942 in k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8944,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[643]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1868 ->string */
t5=C_retrieve(lf[644]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k8934 in k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1867 ##sys#make-lambda-info */
t2=C_retrieve(lf[642]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8930 in k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1866 ##compiler#qnode */
t2=C_retrieve(lf[641]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8926 in k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8928,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1863 append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8915 in k8912 in k8966 in k8963 in k9029 in k8889 in k8886 in k8880 in k8874 in k8868 in k8865 in k8862 in a8859 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[640],((C_word*)t0)[2],t2));}

/* k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1801 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k8786 in k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8788,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8804,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1805 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8712(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1812 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9401(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k8838 in k8786 in k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8840,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t1));}

/* k8802 in k8786 in k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1808 ##compiler#varnode */
t4=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8831 in k8802 in k8786 in k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8833,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[639],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1809 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8712(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8823 in k8831 in k8802 in k8786 in k8783 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8825,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t4));}

/* k8768 in k8762 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8770,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k8741 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1789 test */
t3=((C_word*)t0)[3];
f_8355(t3,t2,((C_word*)t0)[2],lf[607]);}

/* k8747 in k8741 in k8729 in transform in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8749,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[638],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9413(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9413,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9420,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1917 ##compiler#posq */
t9=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9418 in ref-var in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9420,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9436,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1920 ##compiler#varnode */
t5=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9434 in k9418 in ref-var in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9436,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[636],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8382(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8382,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[144]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8401(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[493]);
if(C_truep(t13)){
t14=t12;
f_8401(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[176]);
if(C_truep(t14)){
t15=t12;
f_8401(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[585]);
if(C_truep(t15)){
t16=t12;
f_8401(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[325]);
t17=t12;
f_8401(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[505])));}}}}}

/* k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8401,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[206]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8412,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=lf[623],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8422,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=lf[625],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1727 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[487]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[493],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8481,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8491,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8601,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1743 test */
t19=((C_word*)t0)[3];
f_8355(t19,t18,t16,lf[550]);}
else{
t15=t14;
f_8491(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8481(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[486]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[571]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],a[8]=lf[633],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1765 ##compiler#decompose-lambda-list */
t8=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8676,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=lf[634],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8675 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8676,3,t0,t1,t2);}
/* compiler.scm: 1775 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8382(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8637,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[629]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9452,a[2]=t12,a[3]=t9,a[4]=t7,a[5]=lf[632],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9452(3,t14,t10,t6);}

/* walk in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9452,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[493]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9481,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1932 lset-adjoin */
t12=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[134]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[144]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9490(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[176]);
if(C_truep(t12)){
t13=t11;
f_9490(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[325]);
if(C_truep(t13)){
t14=t11;
f_9490(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[585]);
if(C_truep(t14)){
t15=t11;
f_9490(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[147]);
t16=t11;
f_9490(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[505])));}}}}}}

/* k9488 in walk in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9490,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[232]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9516,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1936 lset-adjoin */
t6=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[134]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9502(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9514 in k9488 in walk in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9502(t3,t2);}

/* k9500 in k9488 in walk in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_9502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 1937 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9452(3,t3,((C_word*)t0)[2],t2);}

/* k9479 in walk in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9448 in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8650,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1771 ##compiler#put! */
t5=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[631],t3);}

/* k8648 in k9448 in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8653,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1772 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[630],((C_word*)t0)[2]);}

/* k8651 in k8648 in k9448 in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8653,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1773 append */
t4=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8662 in k8651 in k8648 in k9448 in a8636 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1773 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8382(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8599 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8497(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1743 test */
t2=((C_word*)t0)[3];
f_8355(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[551]);}}

/* k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8503(t4,(C_word)C_eqp(lf[486],t3));}
else{
t3=t2;
f_8503(t3,C_SCHEME_FALSE);}}

/* k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8503,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1748 test */
t6=((C_word*)t0)[2];
f_8355(t6,t5,((C_word*)t0)[6],lf[546]);}
else{
t2=((C_word*)t0)[8];
f_8491(t2,C_SCHEME_END_OF_LIST);}}

/* k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8518,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1749 test */
t3=((C_word*)t0)[2];
f_8355(t3,t2,((C_word*)t0)[7],lf[567]);}

/* k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8521(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8521(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8521(t3,C_SCHEME_FALSE);}}

/* k8519 in k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8524,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8539(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8539(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8539(t4,C_SCHEME_FALSE);}}

/* k8537 in k8519 in k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1755 warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[628],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8524(2,t2,C_SCHEME_UNDEFINED);}}

/* k8522 in k8519 in k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1756 register-direct-call! */
t3=((C_word*)t0)[2];
f_8371(t3,t2,((C_word*)t0)[6]);}

/* k8525 in k8522 in k8519 in k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8530,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1757 register-customizable! */
t3=((C_word*)t0)[3];
f_8361(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8530(2,t3,C_SCHEME_UNDEFINED);}}

/* k8528 in k8525 in k8522 in k8519 in k8516 in k8513 in k8501 in k8495 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8530,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8491(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8489 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8491,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8481(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8479 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8481,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1736 node-parameters-set! */
t3=C_retrieve(lf[627]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8462 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=lf[626],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t3=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8468 in k8462 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8469,3,t0,t1,t2);}
/* compiler.scm: 1762 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8382(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8421 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8422,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[624],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8438 in a8421 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8439,3,t0,t1,t2);}
/* compiler.scm: 1728 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8382(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8424 in a8421 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8426,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8437,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1729 append */
t4=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8435 in k8424 in a8421 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1729 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8382(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8411 in k8399 in gather in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8412,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1727 split-at */
t3=C_retrieve(lf[312]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8371,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1714 lset-adjoin */
t6=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[134]+1),C_retrieve(lf[104]),t2);}

/* k8378 in register-direct-call! in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8361(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8361,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8366,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1709 lset-adjoin */
t5=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[134]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8364 in register-customizable! in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1710 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[620],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8355(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8355,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1706 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6835,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6839,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1329 make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6841,a[2]=lf[544],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7547,a[2]=t1,a[3]=lf[547],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7441,a[2]=t1,a[3]=lf[556],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6848,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,a[8]=lf[586],tmp=(C_word)a,a+=9,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7429,a[2]=t8,a[3]=lf[588],tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7553,a[2]=lf[589],tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7567,a[2]=t1,a[3]=t15,a[4]=lf[592],tmp=(C_word)a,a+=5,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7592,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1500 ##compiler#initialize-analysis-database */
t18=C_retrieve(lf[616]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1503 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[613],lf[615]);}

/* k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7595,2,t0,t1);}
t2=C_set_block_item(lf[93],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1505 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6848(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1508 ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[613],lf[614]);}

/* k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=lf[611],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1509 ##sys#hash-table-for-each */
t4=C_retrieve(lf[612]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7615,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7619,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8239,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,a[16]=lf[610],tmp=(C_word)a,a+=17,tmp);
/* for-each */
t34=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8238 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8239,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[550]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[546]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[557]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[581]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[567]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[579]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[580]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[549]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[558]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[551]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[562]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[563]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7619,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[105]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8204(t10,(C_word)C_eqp(lf[486],t9));}
else{
t7=t6;
f_8204(t7,C_SCHEME_FALSE);}}

/* k8202 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1555 ##compiler#set-real-name! */
t6=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7626(2,t2,C_SCHEME_UNDEFINED);}}

/* k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[105]))?(C_truep(((C_word*)((C_word*)t0)[8])[1])?(C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8173,a[2]=((C_word*)t0)[16],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1561 warning */
t5=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[609],((C_word*)t0)[16]);}
else{
t5=t4;
f_8173(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7629(2,t4,C_SCHEME_UNDEFINED);}}

/* k8171 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8173,2,t0,t1);}
t2=C_retrieve(lf[60]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_8179(t4,t2);}
else{
if(C_truep(C_retrieve(lf[73]))){
t4=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[73]));
t5=t3;
f_8179(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8179(t4,C_SCHEME_FALSE);}}}

/* k8177 in k8171 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1564 warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[608],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7629(2,t2,C_SCHEME_UNDEFINED);}}

/* k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1568 quick-put! */
f_7553(t2,((C_word*)t0)[8],lf[607],C_SCHEME_TRUE);}
else{
t4=t2;
f_7632(2,t4,C_SCHEME_UNDEFINED);}}

/* k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[486],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8113(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[15],a[3]=lf[605],tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8153,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1577 ##compiler#scan-free-variables */
t13=C_retrieve(lf[606]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8113(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7635(2,t3,C_SCHEME_UNDEFINED);}}

/* k8151 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1577 every */
t2=C_retrieve(lf[374]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8144 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8145,3,t0,t1,t2);}
/* compiler.scm: 1577 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[558]);}

/* k8111 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8113,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8119,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8119(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8119(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7635(2,t2,C_SCHEME_UNDEFINED);}}

/* k8117 in k8111 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1579 quick-put! */
f_7553(((C_word*)t0)[3],((C_word*)t0)[2],lf[603],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1580 quick-put! */
f_7553(((C_word*)t0)[3],((C_word*)t0)[2],lf[604],C_SCHEME_TRUE);}}

/* k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8075,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8075(t6,(C_word)C_eqp(lf[144],t5));}
else{
t4=t3;
f_8075(t4,C_SCHEME_FALSE);}}

/* k8073 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8075,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1588 ##compiler#collapsable-literal? */
t6=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7638(2,t2,C_SCHEME_UNDEFINED);}}

/* k8082 in k8073 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8087(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8087(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8085 in k8082 in k8073 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1590 quick-put! */
f_7553(((C_word*)t0)[3],((C_word*)t0)[2],lf[602],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7638(2,t2,C_SCHEME_UNDEFINED);}}

/* k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7970,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[486],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_7970(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_7970(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7641(2,t3,C_SCHEME_UNDEFINED);}}

/* k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7970,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_cadr(t3);
t5=(C_truep(t4)?C_retrieve(lf[65]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=lf[601],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1604 ##compiler#decompose-lambda-list */
t8=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[2],t6,t7);}
else{
t6=((C_word*)t0)[2];
f_7641(2,t6,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7641(2,t2,C_SCHEME_UNDEFINED);}}

/* a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7988,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_7992(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=lf[600],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8033 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8034,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8041,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8059,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1610 ##compiler#get */
t5=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[546]);}

/* k8057 in a8033 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8059,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8041(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8055,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1611 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[579]);}}

/* k8053 in k8057 in a8033 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8041(t2,(C_word)C_i_not(t1));}

/* k8039 in a8033 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_8041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8041,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1612 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[599],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8042 in k8039 in a8033 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_8044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k7990 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7998,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[121]));
t4=t2;
f_7998(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_7998(t3,C_SCHEME_FALSE);}}

/* k7996 in k7990 in a7987 in k7968 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1618 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[597],C_SCHEME_TRUE);}
else{
t2=(C_truep(C_retrieve(lf[65]))?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1621 ##compiler#put! */
t6=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t6))(6,t6,((C_word*)t0)[5],((C_word*)t0)[4],t5,lf[598],C_SCHEME_TRUE);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_7907(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[493],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7934,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7934(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7948,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1629 ##compiler#get */
t15=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[558]);}}
else{
t6=t5;
f_7922(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_7907(t5,C_SCHEME_FALSE);}}}

/* k7946 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7934(t2,(C_word)C_i_not(t1));}

/* k7932 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7941,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1630 ##compiler#expression-has-side-effects? */
t3=C_retrieve(lf[596]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7922(t2,C_SCHEME_FALSE);}}

/* k7939 in k7932 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7922(t2,(C_word)C_i_not(t1));}

/* k7920 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7907(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k7905 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1632 quick-put! */
f_7553(((C_word*)t0)[3],((C_word*)t0)[2],lf[595],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7644(2,t2,C_SCHEME_UNDEFINED);}}

/* k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[493],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7819,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1644 ##compiler#get */
t11=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[546]);}
else{
t7=t2;
f_7647(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7647(2,t4,C_SCHEME_UNDEFINED);}}

/* k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7825,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1645 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[550]);}

/* k7891 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7825(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1645 ##compiler#get */
t2=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[551]);}}

/* k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_7828(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7883,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1646 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[557]);}}

/* k7881 in k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7883,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_7828(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_7828(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1650 ##compiler#get */
t6=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[579]);}}
else{
t4=((C_word*)t0)[6];
f_7828(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_7828(t2,C_SCHEME_FALSE);}}}

/* k7873 in k7881 in k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7828(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[60]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_7828(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1651 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[558]);}}}

/* k7869 in k7873 in k7881 in k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7828(t2,(C_word)C_i_not(t1));}

/* k7826 in k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7828,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1652 quick-put! */
f_7553(t2,((C_word*)t0)[2],lf[594],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7647(2,t2,C_SCHEME_UNDEFINED);}}

/* k7829 in k7826 in k7823 in k7817 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1653 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[593],C_SCHEME_TRUE);}

/* k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7678(t6,(C_word)C_eqp(lf[486],t5));}
else{
t4=t3;
f_7678(t4,C_SCHEME_FALSE);}}

/* k7676 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7650(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7699,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7699(t11,(C_word)C_eqp(lf[487],t10));}
else{
t10=t8;
f_7699(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7699(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7650(2,t2,C_SCHEME_UNDEFINED);}}

/* k7697 in k7676 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7699,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[493],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[493],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7720(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7720(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7720(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7650(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7650(2,t2,C_SCHEME_UNDEFINED);}}

/* k7718 in k7697 in k7676 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7720,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7726,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1673 quick-put! */
f_7553(t4,((C_word*)t0)[2],lf[594],t3);}
else{
t2=((C_word*)t0)[5];
f_7650(2,t2,C_SCHEME_UNDEFINED);}}

/* k7724 in k7718 in k7697 in k7676 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1674 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[593],C_SCHEME_TRUE);}

/* k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7656(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7656(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7656(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7656(t3,C_SCHEME_FALSE);}}

/* k7654 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7656,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1685 lset-adjoin */
t3=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[134]+1),C_retrieve(lf[96]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7658 in k7654 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7617 in a7614 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[96]+1,t1);
/* compiler.scm: 1686 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[563],lf[574]);}

/* k7603 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1692 lset-difference */
t3=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[134]+1),C_retrieve(lf[96]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7607 in k7603 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7609,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[92]))){
t4=t3;
f_7612(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[92]+1,C_retrieve(lf[93]));
t5=t3;
f_7612(t5,t4);}}

/* k7610 in k7607 in k7603 in k7600 in k7597 in k7593 in k7590 in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7567,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1495 ##compiler#get */
t6=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[577]);}}

/* k7575 in contains? in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[590],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1497 any */
t3=C_retrieve(lf[591]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7584 in k7575 in contains? in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7585,3,t0,t1,t2);}
/* compiler.scm: 1497 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7567(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7553(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7553,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7561,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1490 alist-cons */
t7=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7559 in quick-put! in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7429,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7435,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[587],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t7=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7434 in walkeach in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7435,3,t0,t1,t2);}
/* compiler.scm: 1463 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6848(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6848,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_6841(C_fix(1));
t13=(C_word)C_eqp(t11,lf[144]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_6870(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[176]);
t16=t14;
f_6870(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[585])));}}

/* k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[99],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[493]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6882,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1345 ref */
t5=((C_word*)t0)[8];
f_7547(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[505]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6925,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1353 ref */
t6=((C_word*)t0)[8];
f_7547(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[324]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[559]));
if(C_truep(t5)){
t6=f_6841(C_fix(1));
/* compiler.scm: 1359 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7429(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[487]);
if(C_truep(t6)){
t7=f_6841(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[493],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6984,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1366 ##compiler#collect! */
t16=C_retrieve(lf[545]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[567],t15);}
else{
t12=t9;
f_6961(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[206]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7056,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1380 append */
t9=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[215]);
if(C_truep(t8)){
t9=f_6841(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=lf[570],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1393 ##compiler#decompose-lambda-list */
t12=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[486]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[571]));
if(C_truep(t10)){
t11=f_6841(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],a[10]=lf[578],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1406 ##compiler#decompose-lambda-list */
t14=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[232]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7277,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[105]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7352,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7358,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1437 ##compiler#get */
t17=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[566]);}
else{
t15=t14;
f_7277(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[325]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[248]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7391,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[105]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1456 ##sys#hash-table-ref */
t17=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[117]),t14);}
else{
t17=t16;
f_7391(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7391(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7391(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1460 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7429(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7389 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1457 ##compiler#set-real-name! */
t2=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7385(2,t2,C_SCHEME_UNDEFINED);}}

/* k7383 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1458 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7429(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7356 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7358,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1438 warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[582],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1439 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[584]);}}

/* k7365 in k7356 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1440 warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[583],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7352(2,t2,C_SCHEME_UNDEFINED);}}

/* k7350 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1441 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[581],((C_word*)t0)[2]);}

/* k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7306,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7306(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7306(t5,(C_word)C_i_not(t4));}}

/* k7304 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7306,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_6841(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[105]))){
t4=C_retrieve(lf[60]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7321,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7321(t6,t4);}
else{
if(C_truep(C_retrieve(lf[73]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[73]));
t7=t5;
f_7321(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7321(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7312(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7280(2,t2,C_SCHEME_UNDEFINED);}}

/* k7319 in k7304 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7321,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7325,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1447 lset-adjoin */
t3=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[134]+1),C_retrieve(lf[71]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7312(t2,C_SCHEME_UNDEFINED);}}

/* k7323 in k7319 in k7304 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=((C_word*)t0)[2];
f_7312(t3,t2);}

/* k7310 in k7304 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1448 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[558],C_SCHEME_TRUE);}

/* k7278 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1449 append */
t4=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7301 in k7278 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1449 assign */
t2=((C_word*)t0)[6];
f_7441(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7281 in k7278 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[122]))){
t3=t2;
f_7286(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1450 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[580],C_SCHEME_TRUE);}}

/* k7284 in k7281 in k7278 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7289,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1451 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[579],C_SCHEME_TRUE);}

/* k7287 in k7284 in k7281 in k7278 in k7275 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1452 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_6848(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7167,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[93]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7174,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7259,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1412 ##compiler#collect! */
t9=C_retrieve(lf[545]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[577],t5);}
else{
t8=t7;
f_7174(2,t8,C_SCHEME_UNDEFINED);}}

/* k7257 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1413 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[576],((C_word*)t0)[2]);}

/* k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=lf[575],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7248 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7249,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1416 ##compiler#put! */
t4=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[553],((C_word*)t0)[2]);}

/* k7251 in a7248 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1417 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[550],C_SCHEME_TRUE);}

/* k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[96]));
t4=(C_truep(t3)?lf[574]:lf[330]);
/* compiler.scm: 1420 ##compiler#put! */
t5=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[563],t4);}
else{
t3=t2;
f_7180(2,t3,C_SCHEME_UNDEFINED);}}

/* k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7234,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1424 ##compiler#simple-lambda-node? */
t4=C_retrieve(lf[573]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7232 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1424 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[572],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7183(2,t2,C_SCHEME_UNDEFINED);}}

/* k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=C_retrieve(lf[122]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[123]))){
t4=t3;
f_7186(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[123]+1,((C_word*)t0)[5]);
t5=t3;
f_7186(t5,t4);}}

/* k7184 in k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7186,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7219,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[123]),((C_word*)t0)[5]);
t5=t3;
f_7219(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7219(t4,C_SCHEME_FALSE);}}

/* k7217 in k7184 in k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[122],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7189(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7189(t2,C_SCHEME_UNDEFINED);}}

/* k7187 in k7184 in k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7192,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1429 append */
t5=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7214 in k7187 in k7184 in k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1429 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6848(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7190 in k7187 in k7184 in k7181 in k7178 in k7175 in k7172 in a7166 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[122]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[93]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7122 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7123,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[2],a[3]=lf[569],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7141 in a7122 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7142,3,t0,t1,t2);}
/* compiler.scm: 1397 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[550],C_SCHEME_TRUE);}

/* k7125 in a7122 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7127,2,t0,t1);}
t2=C_retrieve(lf[122]);
t3=C_set_block_item(lf[122],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7131,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1401 append */
t7=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7138 in k7125 in a7122 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1401 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6848(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7129 in k7125 in a7122 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[122]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7056,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=lf[568],tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_7061(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7061(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7061,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1383 append */
t6=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1386 ##compiler#put! */
t7=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[553],((C_word*)t0)[8]);}}

/* k7086 in loop in k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1387 assign */
t3=((C_word*)t0)[4];
f_7441(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7089 in k7086 in loop in k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1388 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_6848(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7092 in k7089 in k7086 in loop in k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1389 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7061(t4,((C_word*)t0)[2],t2,t3);}

/* k7077 in loop in k7054 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1383 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6848(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6982 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1368 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[566]);}

/* k7030 in k6982 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7032,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[560])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[4],a[3]=lf[564],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[565]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_6961(2,t3,C_SCHEME_UNDEFINED);}}

/* a6994 in k7030 in k6982 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6995,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[493],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7014,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1374 ##compiler#get */
t10=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[563]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7012 in a6994 in k7030 in k6982 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1374 ##compiler#count! */
t2=C_retrieve(lf[561]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[562]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k6959 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1376 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6848(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k6962 in k6959 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1377 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7429(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6923 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_6841(C_fix(1));
/* compiler.scm: 1355 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[558],C_SCHEME_TRUE);}

/* k6880 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6882,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_6841(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1348 ##compiler#put! */
t3=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[557],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1349 ##compiler#get */
t4=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[558]);}}}

/* k6911 in k6880 in k6868 in walk in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1349 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[558],C_SCHEME_TRUE);}}

/* assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7441(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7441,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[176],t7);
if(C_truep(t8)){
/* compiler.scm: 1467 ##compiler#put! */
t9=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[549],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7454,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[493],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7454(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7454(t13,C_SCHEME_FALSE);}}}

/* k7452 in assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7454,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[60]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7463(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7463(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1472 ##compiler#get */
t6=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[555]);}}}}

/* k7512 in k7452 in assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7463(t2,(C_truep(t1)?t1:(C_truep(C_retrieve(lf[65]))?(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[71])):C_SCHEME_FALSE)));}

/* k7461 in k7452 in assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7463,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1476 ##compiler#get-all */
t3=C_retrieve(lf[554]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[550],lf[551]);}
else{
/* compiler.scm: 1484 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[550],C_SCHEME_TRUE);}}

/* k7464 in k7461 in k7452 in assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1477 ##compiler#get */
t3=C_retrieve(lf[552]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[553]);}

/* k7467 in k7464 in k7461 in k7452 in assign in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[550],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[551],((C_word*)t0)[7]))){
/* compiler.scm: 1480 ##compiler#put! */
t2=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[550],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1482 ##compiler#put! */
t4=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[551],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1483 ##compiler#put! */
t4=C_retrieve(lf[548]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[550],C_SCHEME_TRUE);}}}}

/* ref in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_7547(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7547,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1487 ##compiler#collect! */
t4=C_retrieve(lf[545]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[546],t3);}

/* grow in k6837 in ##compiler#analyze-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static C_word C_fcall f_6841(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[93]),t1);
t3=C_mutate((C_word*)lf[93]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6826,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[519]);
/* compiler.scm: 1318 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-argument-types in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6817,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[519]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-return-type-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6808,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[519]);
/* compiler.scm: 1318 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-return-type in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6799,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[519]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-qualifiers-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6790,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[519]);
/* compiler.scm: 1318 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-qualifiers in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6781,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[519]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-name-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6772,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[519]);
/* compiler.scm: 1318 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-name in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6763,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[519]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-id-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6754,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[519]);
/* compiler.scm: 1318 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub-id in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6745,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[519]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub? in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6739,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[519]));}

/* make-foreign-callback-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc(c,7);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6733,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[519],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6058,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6061,a[2]=t6,a[3]=lf[492],tmp=(C_word)a,a+=4,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6105,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,a[6]=lf[506],tmp=(C_word)a,a+=7,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6479,a[2]=t12,a[3]=t6,a[4]=lf[509],tmp=(C_word)a,a+=5,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=t12,a[3]=lf[511],tmp=(C_word)a,a+=4,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6620,a[2]=t14,a[3]=t6,a[4]=lf[514],tmp=(C_word)a,a+=5,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6705,a[2]=t14,a[3]=lf[516],tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1313 walk */
t21=((C_word*)t6)[1];
f_6105(t21,t1,t2,*((C_word*)lf[517]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6705,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[515]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[248]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[249]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[147]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[234]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[151]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[237]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1311 every */
t8=C_retrieve(lf[374]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6620(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6620,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=lf[513],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6626(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6626,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1294 reverse */
t5=*((C_word*)lf[341]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6646,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1295 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6705(3,t6,t4,t5);}}

/* k6644 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6646,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1296 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6626(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1298 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}}

/* k6662 in k6644 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6664,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=lf[512],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1299 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6105(t4,((C_word*)t0)[2],t2,t3);}

/* a6672 in k6662 in k6644 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6673,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6687,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6699,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1304 ##compiler#varnode */
t7=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6697 in a6672 in k6662 in k6644 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1303 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6626(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6685 in a6672 in k6662 in k6644 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t2));}

/* k6638 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1294 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6610,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=lf[510],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1287 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6620(t7,t1,t4,t6);}

/* a6609 in walk-inline-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6610,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[485],t3,t4,t2);
/* compiler.scm: 1290 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6479,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6483,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1263 gensym */
t7=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[491]);}

/* k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1264 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[498]);}

/* k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[497]);}

/* k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6540,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6536,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1268 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6534 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1268 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6532,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[486],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[508],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1269 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6620(t6,t4,((C_word*)t0)[2],t5);}

/* a6510 in k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=lf[507],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1272 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6105(t4,t1,((C_word*)t0)[2],t3);}

/* a6516 in a6510 in k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6517,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6521,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1274 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6526 in a6516 in a6510 in k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1274 cons* */
t2=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6519 in a6516 in a6510 in k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[485],lf[487],((C_word*)t0)[2],t1));}

/* k6507 in k6530 in k6538 in k6484 in k6481 in walk-call in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6509,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6105,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[493]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6127,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6127(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[144]);
if(C_truep(t14)){
t15=t13;
f_6127(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[176]);
if(C_truep(t15)){
t16=t13;
f_6127(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[325]);
t17=t13;
f_6127(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[505])));}}}}

/* k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6127,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1220 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[156]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1221 gensym */
t4=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[491]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[206]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6233,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=lf[500],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6233(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[215]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[497]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[232]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1243 gensym */
t7=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[331]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[311]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[497]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[248]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6393(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[249]);
if(C_truep(t9)){
t10=t8;
f_6393(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[147]);
if(C_truep(t10)){
t11=t8;
f_6393(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[234]);
if(C_truep(t11)){
t12=t8;
f_6393(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[151]);
t13=t8;
f_6393(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[237])));}}}}}}}}}}}

/* k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6393,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1257 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6604(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[487]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1258 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6479(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[324]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1277 gensym */
t8=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[491]);}
else{
/* compiler.scm: 1260 ##compiler#bomb */
t4=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[504]);}}}}

/* k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1278 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[498]);}

/* k6551 in k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[497]);}

/* k6596 in k6551 in k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6598,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6594,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1282 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6592 in k6596 in k6551 in k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1282 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6588 in k6596 in k6551 in k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6590,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[486],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1284 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6584 in k6588 in k6596 in k6551 in k6548 in k6391 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[324],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t4));}

/* k6356 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6358,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[502]),t1,((C_word*)t0)[2]);}

/* k6382 in k6356 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[109]));
t3=C_mutate((C_word*)lf[109]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1254 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6061(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6306 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6308,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=lf[501],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1244 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6105(t4,((C_word*)t0)[2],t2,t3);}

/* a6316 in k6306 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6317,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[485],lf[232],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6341,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6345,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1248 ##compiler#varnode */
t10=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6343 in a6316 in k6306 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1248 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6339 in a6316 in k6306 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t2));}

/* k6293 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1242 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6061(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6233(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6233,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1236 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6105(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6256,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=lf[499],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1237 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6105(t6,t1,t4,t5);}}

/* a6255 in loop in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6256,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6270,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1241 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6233(t8,t5,t6,t7);}

/* k6268 in a6255 in loop in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6270,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t2));}

/* k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1222 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[498]);}

/* k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[6],a[3]=lf[495],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[497]);}

/* k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6218,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6214,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1227 ##compiler#varnode */
t6=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6212 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1227 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6208 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[486],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[496],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1228 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6105(t7,t4,t5,t6);}

/* a6182 in k6208 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1232 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6105(t5,t3,t4,((C_word*)t0)[2]);}

/* k6192 in a6182 in k6208 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1233 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6105(t4,t2,t3,((C_word*)t0)[2]);}

/* k6196 in k6192 in a6182 in k6208 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[156],C_SCHEME_END_OF_LIST,t2));}

/* k6175 in k6208 in k6216 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[206],((C_word*)t0)[2],t2));}

/* k1 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6154,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1223 ##compiler#varnode */
t4=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6152 in k1 in k6140 in k6137 in k6125 in walk in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6154,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[487],lf[494],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6061(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6061,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1208 gensym */
t7=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[491]);}

/* k6063 in cps-lambda in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6088,a[2]=t1,a[3]=lf[490],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1211 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6105(t7,t4,t5,t6);}

/* a6087 in k6063 in cps-lambda in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6088,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1213 ##compiler#varnode */
t4=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6097 in a6087 in k6063 in cps-lambda in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[485],lf[487],lf[488],t2));}

/* k6080 in k6063 in cps-lambda in ##compiler#perform-cps-conversion in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[485],lf[486],((C_word*)t0)[4],t2);
/* compiler.scm: 1209 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5968,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5971,a[2]=t7,a[3]=lf[480],tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6000,a[2]=t3,a[3]=t5,a[4]=lf[482],tmp=(C_word)a,a+=5,tmp));
/* compiler.scm: 1200 walk */
t10=((C_word*)t7)[1];
f_6000(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_6000(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6000,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1194 ##sys#hash-table-ref */
t7=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[481]),t5);}
else{
/* compiler.scm: 1198 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5971(t5,t1,t2);}}}

/* k6017 in walk in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6025(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6042,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1196 alist-cons */
t5=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6040 in k6017 in walk in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1196 ##sys#hash-table-set! */
t2=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[481]),((C_word*)t0)[2],t1);}

/* k6023 in k6017 in walk in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1197 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5971(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5971,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[479],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5977(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5977,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5987,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1187 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6000(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5985 in loop in mapupdate in ##compiler#update-line-number-database! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1188 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5977(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5884,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5888,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_5888(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_5888(t5,C_SCHEME_FALSE);}}

/* k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5888,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_5891(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_5891(t3,lf[477]);}}

/* k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_5894(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_5894(t4,(C_word)C_i_cadr(t3));}}

/* k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5894,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5897,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[471]+1),t4);}

/* k5911 in k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[282]+1),t1);}

/* k5895 in k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[472]+1),((C_word*)t0)[2]);}

/* k5898 in k5895 in k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[471]+1),((C_word*)t0)[2]);}

/* k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5906,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1175 ##compiler#check-c-syntax */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[476]);}

/* k5904 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in ##compiler#expand-foreign-primitive in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1176 ##compiler#create-foreign-stub */
t2=C_retrieve(lf[454]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5844,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5854,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5870,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[471]+1),t9);}

/* k5868 in ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[282]+1),t1);}

/* k5852 in ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[472]+1),((C_word*)t0)[2]);}

/* k5855 in k5852 in ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[471]+1),((C_word*)t0)[2]);}

/* k5858 in k5855 in k5852 in ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1165 ##compiler#check-c-syntax */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[474]);}

/* k5861 in k5858 in k5855 in k5852 in ##compiler#expand-foreign-callback-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1166 ##compiler#create-foreign-stub */
t2=C_retrieve(lf[454]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5804,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5830,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[471]+1),t9);}

/* k5828 in ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[282]+1),t1);}

/* k5812 in ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[472]+1),((C_word*)t0)[2]);}

/* k5815 in k5812 in ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[471]+1),((C_word*)t0)[2]);}

/* k5818 in k5815 in k5812 in ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1156 ##compiler#check-c-syntax */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[470]);}

/* k5821 in k5818 in k5815 in k5812 in ##compiler#expand-foreign-lambda* in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1157 ##compiler#create-foreign-stub */
t2=C_retrieve(lf[454]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5759,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5766,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1143 symbol->string */
t6=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5766(2,t6,t4);}
else{
/* compiler.scm: 1145 quit */
t6=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[468],t4);}}}

/* k5764 in ##compiler#expand-foreign-callback-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5772,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[465]+1),t5);}

/* k5770 in k5764 in ##compiler#expand-foreign-callback-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1148 ##compiler#create-foreign-stub */
t2=C_retrieve(lf[454]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5714,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5721,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1134 symbol->string */
t6=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5721(2,t6,t4);}
else{
/* compiler.scm: 1136 quit */
t6=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[466],t4);}}}

/* k5719 in ##compiler#expand-foreign-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5721,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5727,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[465]+1),t5);}

/* k5725 in k5719 in ##compiler#expand-foreign-lambda in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1139 ##compiler#create-foreign-stub */
t2=C_retrieve(lf[454]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5560,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5564,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5708,a[2]=lf[462],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1107 list-tabulate */
t12=C_retrieve(lf[463]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5707 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5708,3,t0,t1,t2);}
/* compiler.scm: 1107 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[461]);}

/* k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1108 gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[460]);}

/* k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1109 gensym */
t3=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1110 ##compiler#estimate-foreign-result-size */
t3=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1111 ##compiler#set-real-name! */
t3=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1113 make-foreign-stub */
t3=C_retrieve(lf[416]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[108]));
t3=C_mutate((C_word*)lf[108]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[325],((C_word*)t0)[2]);
t7=t5;
f_5586(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5586(t6,(C_word)C_a_i_list(&a,2,lf[248],((C_word*)t0)[2]));}}

/* k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5677,a[2]=lf[458],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1119 map */
t4=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* a5676 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5677,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5685,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1119 ##compiler#foreign-type-convert-argument */
t5=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5683 in a5676 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1119 ##compiler#foreign-type-check */
t2=C_retrieve(lf[235]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5600,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[6])?lf[455]:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5622,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[456],t1);
/* compiler.scm: 1124 append */
t9=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[3],t8);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1125 ##compiler#final-foreign-type */
t8=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[4]);}}

/* k5627 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1126 ##compiler#words */
t3=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5630 in k5627 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[457],t2);
t4=(C_word)C_a_i_list(&a,2,lf[144],t1);
t5=(C_word)C_a_i_list(&a,3,lf[249],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5643,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5647,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1129 append */
t12=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5649 in k5630 in k5627 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1129 ##compiler#finish-foreign-result */
t2=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5645 in k5630 in k5627 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1128 ##compiler#foreign-type-convert-result */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5641 in k5630 in k5627 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5612(2,t2,(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[2],t1));}

/* k5620 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1124 ##compiler#foreign-type-convert-result */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5610 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5612,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5598 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5594 in k5587 in k5584 in k5700 in k5574 in k5571 in k5568 in k5565 in k5562 in ##compiler#create-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[215],t1);}

/* foreign-stub-callback-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5551,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-callback in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5542,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-cps-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5533,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-cps in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5524,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-body-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5515,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-body in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5506,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-argument-names-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5497,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-names in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5488,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-types-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5479,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-argument-types in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5470,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-name-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5461,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-name in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5452,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-return-type-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5443,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-return-type in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5434,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-id-set! in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5425,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[417]);
/* compiler.scm: 1096 ##sys#block-set! */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub-id in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5416,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[417]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub? in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5410,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[417]));}

/* make-foreign-stub in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc(c,10);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5404,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[417],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4459,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=lf[347],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4513,a[2]=t3,a[3]=t2,a[4]=lf[414],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 935  call-with-current-continuation */
t5=*((C_word*)lf[307]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4517,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=t3;
f_4517(2,t4,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 938  quit */
t4=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[413],((C_word*)t0)[3]);}}

/* k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word ab[101],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[355]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[356]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 948  check-decl */
f_4462(t6,((C_word*)t0)[5],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[359]));
t9=t3;
f_4523(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 958  append */
t10=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[51]));}}
else{
t7=(C_word)C_eqp(t2,lf[52]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[360]));
t10=t3;
f_4523(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 962  append */
t11=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[52]));}}
else{
t8=(C_word)C_eqp(t2,lf[361]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[359]));
t11=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[360]));
t12=t3;
f_4523(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4677,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 969  lset-intersection */
t12=C_retrieve(lf[362]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[134]+1),t10,C_retrieve(lf[359]));}}
else{
t9=(C_word)C_eqp(t2,lf[49]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4694,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 972  check-decl */
f_4462(t10,((C_word*)t0)[5],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[363]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[364]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[49]+1,lf[363]);
t13=t3;
f_4523(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[50]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[49]+1,lf[50]);
t14=t3;
f_4523(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[55]);
if(C_truep(t13)){
t14=C_set_block_item(lf[55],0,C_SCHEME_TRUE);
/* compiler.scm: 978  ##match#set-error-control */
t15=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[366]);}
else{
t14=(C_word)C_eqp(t2,lf[367]);
if(C_truep(t14)){
t15=C_set_block_item(lf[55],0,C_SCHEME_FALSE);
t16=t3;
f_4523(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[68]);
if(C_truep(t15)){
t16=C_set_block_item(lf[68],0,C_SCHEME_TRUE);
t17=t3;
f_4523(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[69]);
if(C_truep(t16)){
t17=C_set_block_item(lf[69],0,C_SCHEME_TRUE);
t18=t3;
f_4523(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[70]);
if(C_truep(t17)){
t18=C_set_block_item(lf[70],0,C_SCHEME_TRUE);
t19=t3;
f_4523(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[368]);
if(C_truep(t18)){
t19=C_set_block_item(lf[53],0,C_SCHEME_TRUE);
t20=t3;
f_4523(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[369]);
if(C_truep(t19)){
t20=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t21=t3;
f_4523(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[56]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 985  append */
t23=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[56]));}
else{
t21=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t21)){
t22=C_set_block_item(lf[77],0,C_SCHEME_TRUE);
t23=t3;
f_4523(2,t23,t22);}
else{
t22=(C_word)C_eqp(t2,lf[371]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 988  append */
t25=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t25))(4,t25,t23,t24,C_retrieve(lf[57]));}
else{
t23=(C_word)C_eqp(t2,lf[372]);
if(C_truep(t23)){
t24=(C_word)C_i_cdr(((C_word*)t0)[5]);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=t24,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[5],a[3]=t24,a[4]=t25,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 992  every */
t27=C_retrieve(lf[374]);
((C_proc4)C_retrieve_proc(t27))(4,t27,t26,*((C_word*)lf[375]+1),t24);}
else{
t24=(C_word)C_eqp(t2,lf[376]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[5]);
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[5],a[3]=t25,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 998  every */
t27=C_retrieve(lf[374]);
((C_proc4)C_retrieve_proc(t27))(4,t27,t26,*((C_word*)lf[375]+1),t25);}
else{
t25=(C_word)C_eqp(t2,lf[381]);
if(C_truep(t25)){
t26=(C_word)C_i_listp(((C_word*)t0)[5]);
t27=(C_word)C_i_not(t26);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t27)){
t29=t28;
f_4891(t29,t27);}
else{
t29=(C_word)C_i_cadr(((C_word*)t0)[5]);
t30=(C_word)C_i_listp(t29);
t31=(C_word)C_i_not(t30);
if(C_truep(t31)){
t32=t28;
f_4891(t32,t31);}
else{
t32=(C_word)C_i_cadr(((C_word*)t0)[5]);
t33=(C_word)C_i_length(t32);
t34=t28;
f_4891(t34,(C_word)C_fixnum_lessp(t33,C_fix(3)));}}}
else{
t26=(C_word)C_eqp(t2,lf[384]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4947,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 930  ##sys#cons */
t29=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t29+1)))(4,t29,t27,lf[384],t28);}
else{
t27=(C_word)C_eqp(t2,lf[386]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 930  ##sys#cons */
t30=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t30+1)))(4,t30,t28,lf[386],t29);}
else{
t28=(C_word)C_eqp(t2,lf[387]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1013 pathname-strip-extension */
t30=C_retrieve(lf[391]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t29,C_retrieve(lf[72]));}
else{
t29=(C_word)C_eqp(t2,lf[392]);
if(C_truep(t29)){
t30=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t31=t3;
f_4523(2,t31,t30);}
else{
t30=(C_word)C_eqp(t2,lf[393]);
if(C_truep(t30)){
t31=C_set_block_item(lf[60],0,C_SCHEME_FALSE);
t32=t3;
f_4523(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[272]);
if(C_truep(t31)){
t32=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t33=t3;
f_4523(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[394]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1019 check-decl */
f_4462(t33,((C_word*)t0)[5],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t33=(C_word)C_eqp(t2,lf[398]);
if(C_truep(t33)){
t34=C_set_block_item(lf[399],0,C_SCHEME_TRUE);
t35=t3;
f_4523(2,t35,t34);}
else{
t34=(C_word)C_eqp(t2,lf[400]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t2,lf[401]));
if(C_truep(t35)){
t36=(C_word)C_i_cdr(((C_word*)t0)[5]);
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5190,a[2]=t36,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[73]))){
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1054 lset-difference */
t39=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t39))(5,t39,t38,*((C_word*)lf[134]+1),C_retrieve(lf[73]),t36);}
else{
t38=t37;
f_5190(t38,C_SCHEME_UNDEFINED);}}
else{
t36=(C_word)C_eqp(t2,lf[402]);
if(C_truep(t36)){
t37=(C_word)C_i_cdr(((C_word*)t0)[5]);
t38=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5211,a[2]=t37,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1058 lset-difference */
t39=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t39))(5,t39,t38,*((C_word*)lf[134]+1),C_retrieve(lf[71]),t37);}
else{
t37=(C_word)C_eqp(t2,lf[403]);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5229,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t39=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t39))){
t40=(C_word)C_i_cadr(((C_word*)t0)[5]);
t41=(C_word)C_i_numberp(t40);
t42=t38;
f_5229(t42,(C_truep(t41)?(C_word)C_i_cadr(((C_word*)t0)[5]):C_SCHEME_FALSE));}
else{
t40=t38;
f_5229(t40,C_SCHEME_FALSE);}}
else{
t38=(C_word)C_eqp(t2,lf[404]);
if(C_truep(t38)){
t39=C_set_block_item(lf[84],0,C_SCHEME_TRUE);
t40=t3;
f_4523(2,t40,t39);}
else{
t39=(C_word)C_eqp(t2,lf[405]);
if(C_truep(t39)){
t40=C_set_block_item(lf[85],0,C_SCHEME_TRUE);
t41=t3;
f_4523(2,t41,t40);}
else{
t40=(C_word)C_eqp(t2,lf[396]);
if(C_truep(t40)){
t41=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t41))){
t42=C_retrieve(lf[86]);
if(C_truep((C_word)C_fixnum_greaterp(t42,C_fix(-1)))){
t43=t3;
f_4523(2,t43,C_SCHEME_UNDEFINED);}
else{
t43=C_set_block_item(lf[86],0,C_fix(10));
t44=t3;
f_4523(2,t44,t43);}}
else{
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t43=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1073 lset-union */
t44=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t42,*((C_word*)lf[134]+1),C_retrieve(lf[127]),t43);}}
else{
t41=(C_word)C_eqp(t2,lf[406]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5326,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1075 check-decl */
f_4462(t42,((C_word*)t0)[5],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t42=(C_word)C_eqp(t2,lf[408]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5348,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1082 check-decl */
f_4462(t43,((C_word*)t0)[5],C_fix(2),C_SCHEME_END_OF_LIST);}
else{
/* compiler.scm: 1090 warning */
t43=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t3,lf[412],((C_word*)t0)[5]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k5346 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1085 every */
t5=C_retrieve(lf[374]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,*((C_word*)lf[411]+1),t2);}

/* k5358 in k5346 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[80]));
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1088 lset-union */
t8=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[134]+1),t4,t7);}
else{
/* compiler.scm: 1089 quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[410],((C_word*)t0)[2]);}}

/* k5375 in k5358 in k5346 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1088 alist-update! */
t2=C_retrieve(lf[409]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_retrieve(lf[80]),*((C_word*)lf[134]+1));}

/* k5371 in k5358 in k5346 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[80]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5324 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5333(2,t4,t2);}
else{
/* compiler.scm: 1080 quit */
t4=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[407],((C_word*)t0)[3]);}}

/* k5331 in k5324 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5307 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[127]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5227 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5229,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(50));
t3=C_mutate((C_word*)lf[75]+1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5238(t6,(C_word)C_eqp(C_fix(3),t5));}
else{
t5=t4;
f_5238(t5,C_SCHEME_FALSE);}}

/* k5236 in k5227 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[76]+1,t2);
t4=((C_word*)t0)[2];
f_4523(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
f_4523(2,t2,C_SCHEME_UNDEFINED);}}

/* k5209 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[73]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1059 lset-union */
t6=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[134]+1),((C_word*)t0)[2],t5);}

/* k5213 in k5209 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5196 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=((C_word*)t0)[2];
f_5190(t3,t2);}

/* k5188 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_5190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5190,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1055 lset-union */
t3=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[134]+1),((C_word*)t0)[2],C_retrieve(lf[71]));}

/* k5192 in k5188 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[51],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4523(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1024 lset-difference */
t7=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[134]+1),C_retrieve(lf[359]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[52]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[52],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4523(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1028 lset-difference */
t8=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[134]+1),C_retrieve(lf[360]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[396]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[86],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4523(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1032 lset-union */
t9=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[134]+1),C_retrieve(lf[128]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[361]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[51],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[52],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4523(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1039 lset-difference */
t10=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[134]+1),C_retrieve(lf[359]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1042 check-decl */
f_4462(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5136 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[368]);
if(C_truep(t3)){
t4=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4523(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[272]);
if(C_truep(t4)){
t5=C_set_block_item(lf[82],0,C_SCHEME_TRUE);
t6=((C_word*)t0)[2];
f_4523(2,t6,t5);}
else{
t5=(C_word)C_eqp(t2,lf[367]);
if(C_truep(t5)){
t6=C_set_block_item(lf[55],0,C_SCHEME_TRUE);
/* compiler.scm: 1048 ##match#set-error-control */
t7=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],lf[366]);}
else{
/* compiler.scm: 1049 warning */
t6=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],lf[397],((C_word*)t0)[3]);}}}}

/* k5125 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5131,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1040 lset-difference */
t4=C_retrieve(lf[395]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[134]+1),C_retrieve(lf[360]),((C_word*)t0)[2]);}

/* k5129 in k5125 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5096 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5071 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k5046 in k5026 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4979 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=t1,a[3]=lf[390],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a4989 in k4979 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4990,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[388]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[389],((C_word*)t0)[2],t2);}

/* k4986 in k4979 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[387],t1);}

/* k4982 in k4979 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1012 ##compiler#emit-control-file-item */
t2=C_retrieve(lf[385]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4962 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1010 ##compiler#emit-control-file-item */
t2=C_retrieve(lf[385]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4945 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1008 ##compiler#emit-control-file-item */
t2=C_retrieve(lf[385]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4889 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1005 quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[382],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1006 ##compiler#process-custom-declaration */
t4=C_retrieve(lf[383]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k4852 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4865,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4869,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4873,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1001 string-intersperse */
t6=C_retrieve(lf[378]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],lf[379]);}
else{
/* compiler.scm: 1002 quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[380],((C_word*)t0)[2]);}}

/* k4871 in k4852 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1001 ##compiler#parse-easy-ffi */
t2=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4867 in k4852 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 930  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[197],t1);}

/* k4863 in k4852 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1000 ##sys#compiler-toplevel-macroexpand-hook */
t2=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4859 in k4852 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 999  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4830 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 993  append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 994  quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[373],((C_word*)t0)[2]);}}

/* k4834 in k4830 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_4822(2,t3,t2);}

/* k4820 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t2,*((C_word*)lf[282]+1),((C_word*)t0)[2]);}

/* k4827 in k4820 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 995  ##compiler#check-c-syntax */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[372]);}

/* k4796 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 989  append */
t5=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[56]));}

/* k4800 in k4796 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4775 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4692 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[49]+1,t2);
t4=((C_word*)t0)[2];
f_4523(2,t4,t3);}

/* k4675 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 970  lset-intersection */
t4=C_retrieve(lf[362]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[134]+1),((C_word*)t0)[2],C_retrieve(lf[360]));}

/* k4679 in k4675 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4646 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4621 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4606,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 950  ##compiler#stringify */
t5=C_retrieve(lf[351]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4604 in k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 950  ##compiler#string->c-identifier */
t2=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4580 in k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 951  hash-table-set! */
t3=C_retrieve(lf[358]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[129]),lf[356],((C_word*)t0)[2]);}

/* k4583 in k4580 in k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[48]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[48]),((C_word*)t0)[3]);
t5=t3;
f_4592(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4592(t4,C_SCHEME_FALSE);}}

/* k4590 in k4583 in k4580 in k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 953  warning */
t2=C_retrieve(lf[198]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[357]);}
else{
t2=((C_word*)t0)[2];
f_4588(2,t2,C_SCHEME_UNDEFINED);}}

/* k4586 in k4583 in k4580 in k4574 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[48]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[3],a[3]=lf[353],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[3],a[3]=lf[354],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 944  hash-table-update! */
t5=C_retrieve(lf[186]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[129]),lf[349],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4523(2,t2,C_SCHEME_UNDEFINED);}}

/* a4565 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4559 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4560,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[134]+1),((C_word*)t0)[2],t2);}

/* k4539 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=lf[352],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4549 in k4539 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4558,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 945  ##compiler#stringify */
t4=C_retrieve(lf[351]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4556 in a4549 in k4539 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 945  ##compiler#string->c-identifier */
t2=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4542 in k4539 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 946  append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[54]),t1);}

/* k4546 in k4542 in k4539 in k4530 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=((C_word*)t0)[2];
f_4523(2,t3,t2);}

/* k4521 in k4515 in a4512 in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[348]);}

/* check-decl in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4462(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4462,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4475(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4485(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4485(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 933  ##sys#error */
t11=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4483 in check-decl in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4475(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4473 in check-decl in ##compiler#process-declaration in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 934  quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[346],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2074,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=lf[139],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2089,a[2]=lf[143],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=lf[145],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2155,a[2]=t5,a[3]=t9,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=lf[336],tmp=(C_word)a,a+=8,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4407,a[2]=t7,a[3]=lf[338],tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4420,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[174],C_retrieve(lf[342])))){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4454,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 917  newline */
t14=*((C_word*)lf[344]+1);
((C_proc2)C_retrieve_proc(t14))(2,t14,t13);}
else{
t13=t12;
f_4420(2,t13,C_SCHEME_UNDEFINED);}}

/* k4452 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 917  pretty-print */
t2=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 921  reverse */
t5=*((C_word*)lf[341]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[119]));}

/* k4433 in k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=C_set_block_item(lf[119],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4444,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 924  ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4442 in k4433 in k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 925  append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[339]),C_retrieve(lf[52]));}

/* k4446 in k4442 in k4433 in k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 435  ##sys#append */
t4=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4429 in k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[197],t1);}

/* k4425 in k4418 in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 919  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2155(t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4407(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4407,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4413,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[337],tmp=(C_word)a,a+=6,tmp);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4412 in mapwalk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4413,3,t0,t1,t2);}
/* compiler.scm: 915  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2155(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2155,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2175,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_cdr(t6);
/* compiler.scm: 458  ##sys#macroexpand-1-local */
t9=C_retrieve(lf[146]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,t8,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2182,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[100]))){
/* compiler.scm: 459  ##sys#hash-table-ref */
t8=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[99]),t2);}
else{
t8=t7;
f_2182(2,t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 480  ##compiler#constant? */
t7=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2273(2,t7,C_SCHEME_FALSE);}}}

/* k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[144],((C_word*)t0)[10]));}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 481  quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[154],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 485  ##compiler#get-line */
t6=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 895  ##compiler#constant? */
t5=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 893  quit */
t3=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[335],((C_word*)t0)[10]);}}}}}

/* k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 896  warning */
t3=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[329],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 899  caar */
t5=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4289(t4,C_SCHEME_FALSE);}}}

/* k4381 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4289(t2,(C_word)C_eqp(lf[215],t1));}

/* k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4289,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 902  ##sys#check-syntax */
t5=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[215],t2,lf[332]);}
else{
/* compiler.scm: 912  mapwalk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4407(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4307(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4307(t4,C_SCHEME_FALSE);}}

/* k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4307,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 905  map */
t5=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[330]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 906  gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[331]);}}

/* k4327 in k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 435  ##sys#cons */
t7=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t1,t6);}

/* k4342 in k4327 in k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[7],t1);
/* compiler.scm: 907  walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2155(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4320 in k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* compiler.scm: 435  ##sys#cons */
t3=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k4316 in k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[206],t1);}

/* k4312 in k4305 in k4296 in k4287 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 905  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4278 in k4275 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 897  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4407(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=f_2077(((C_word*)t0)[12],((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2306,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t2,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t4=t3;
f_2306(2,t4,C_SCHEME_UNDEFINED);}
else{
if(C_truep(t1)){
/* compiler.scm: 489  quit */
t4=C_retrieve(lf[153]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[327],t1,((C_word*)t0)[10]);}
else{
/* compiler.scm: 490  quit */
t4=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[328],((C_word*)t0)[10]);}}}

/* k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=C_mutate((C_word*)lf[155]+1,((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 493  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[146]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[8]);}

/* k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[14],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[98]))){
/* compiler.scm: 497  ##sys#hash-table-ref */
t4=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[97]),((C_word*)t0)[7]);}
else{
t4=t3;
f_2331(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t1,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 495  ##compiler#update-line-number-database! */
t4=C_retrieve(lf[326]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2322(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2320 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 496  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2155(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[13]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 498  walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_2155(t4,((C_word*)t0)[11],t3,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[156]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 503  ##sys#check-syntax */
t4=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[156],((C_word*)t0)[13],lf[159]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[144]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 511  ##sys#check-syntax */
t5=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[144],((C_word*)t0)[13],lf[170]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[171]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[55]))){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[172]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* compiler.scm: 528  walk */
t6=((C_word*)((C_word*)t0)[12])[1];
f_2155(t6,((C_word*)t0)[11],t5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 531  cadadr */
t7=*((C_word*)lf[175]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2492(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[324]);
if(C_truep(t8)){
t9=t7;
f_2492(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[325]);
if(C_truep(t9)){
t10=t7;
f_2492(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[147]);
t11=t7;
f_2492(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[7],lf[151])));}}}}}}}}}

/* k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[251],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[192]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[193]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=t7,a[3]=lf[205],tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2577(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 571  ##sys#check-syntax */
t6=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[206],((C_word*)t0)[12],lf[214]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[215]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[216]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 585  ##sys#check-syntax */
t8=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[215],((C_word*)t0)[12],lf[228]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[229]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[12]);
/* compiler.scm: 435  ##sys#cons */
t10=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[215],t9);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[230]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[9],a[3]=t10,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* map */
t12=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[167]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[233]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 630  ##sys#check-syntax */
t12=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[232],((C_word*)t0)[12],lf[247]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[248]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=t12,tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 665  unquotify */
t15=((C_word*)t0)[3];
f_2113(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[249]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t16=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,((C_word*)t0)[3],t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 673  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2155(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[237]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 678  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2155(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[250]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[251]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 683  eval */
t19=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[252]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[253]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 687  eval */
t21=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[197]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 691  ##sys#check-syntax */
t21=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[197],((C_word*)t0)[12],lf[258]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[259]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 703  ##compiler#expand-foreign-lambda */
t22=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[261]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 706  ##compiler#expand-foreign-callback-lambda */
t23=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[263]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 709  ##compiler#expand-foreign-lambda* */
t24=C_retrieve(lf[264]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[265]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 712  ##compiler#expand-foreign-callback-lambda* */
t25=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[267]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 715  ##compiler#expand-foreign-primitive */
t26=C_retrieve(lf[268]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[269]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3311(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 722  symbol->string */
t32=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[274]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3381,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 734  gensym */
t33=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 745  ##sys#hash-table-set! */
t33=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[106]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[279]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 750  symbol->string */
t31=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[285]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 765  gensym */
t34=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[290]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3657,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,a[7]=lf[292],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3675,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=lf[294],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[295]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3736,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3800,a[2]=t32,a[3]=t33,a[4]=lf[306],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 799  call-with-current-continuation */
t37=*((C_word*)lf[307]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[308]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3871,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=lf[310],tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t36=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t36+1)))(4,t36,t33,t34,t35);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[311]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[12],a[3]=lf[313],tmp=(C_word)a,a+=4,tmp);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=lf[319],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 825  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4081,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],a[8]=lf[320],tmp=(C_word)a,a+=9,tmp);
t34=(C_word)C_eqp(lf[321],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 874  ##sys#check-syntax */
t36=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[321],((C_word*)t0)[12],lf[323]);}
else{
/* compiler.scm: 890  handle-call */
t35=t33;
f_4081(t35,((C_word*)t0)[13]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4119 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4121,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_2077(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[118]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[144],lf[321]);
t7=(C_word)C_a_i_list(&a,5,lf[322],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 879  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2155(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[115]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 883  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2155(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[121])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4181,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 885  symbol->string */
t7=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[144],lf[321]);
t7=(C_word)C_a_i_list(&a,5,lf[322],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 887  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2155(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[144],lf[321]);
t4=(C_word)C_a_i_list(&a,5,lf[322],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 888  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2155(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4179 in k4119 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4181,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[280]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[147],t2));}

/* handle-call in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4081,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 863  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4407(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4083 in handle-call in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4091,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 865  ##sys#hash-table-ref */
t4=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[94]),t2);}

/* k4089 in k4083 in handle-call in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 870  alist-cons */
t5=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4094(2,t3,C_SCHEME_UNDEFINED);}}

/* k4103 in k4089 in k4083 in handle-call in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 867  ##sys#hash-table-set! */
t3=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[94]),((C_word*)t0)[2],t2);}

/* k4092 in k4089 in k4083 in handle-call in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3906,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3928,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t10,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 832  ##compiler#valid-c-identifier? */
t14=C_retrieve(lf[318]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4063 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[121]));
t3=C_mutate((C_word*)lf[121]+1,t2);
t4=((C_word*)t0)[2];
f_3928(2,t4,t3);}
else{
/* compiler.scm: 834  quit */
t2=C_retrieve(lf[153]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[317],((C_word*)t0)[3]);}}

/* k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[10]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4030(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4030(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[10]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4030(t11,(C_word)C_i_not(t10));}}}

/* k4028 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_4030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 838  ##sys#syntax-error-hook */
t2=C_retrieve(lf[315]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[316],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3931(2,t2,C_SCHEME_UNDEFINED);}}

/* k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 842  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4407(t4,t3,((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[7]);}

/* k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3950,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3980,a[2]=t5,a[3]=lf[314],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3980(t7,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* loop in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3980,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 854  ##compiler#final-foreign-type */
t9=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4022 in loop in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 854  ##compiler#finish-foreign-result */
t2=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4018 in loop in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 853  ##compiler#foreign-type-convert-result */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4014 in loop in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4004,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 856  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3980(t6,t3,t4,t5);}

/* k4002 in k4014 in loop in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3960 in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3974,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 435  ##sys#cons */
t6=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_SCHEME_END_OF_LIST,t5);}

/* k3972 in k3960 in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[206],t1);}

/* k3968 in k3960 in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 857  ##compiler#foreign-type-convert-argument */
t2=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3964 in k3960 in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[216],((C_word*)t0)[6],t2);
/* compiler.scm: 843  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2155(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3948 in k3940 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 435  ##sys#append */
t3=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3936 in k3929 in k3926 in a3905 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[311],t1);}

/* a3895 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 825  split-at */
t3=C_retrieve(lf[312]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3872 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3873,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 820  ##compiler#process-declaration */
t4=C_retrieve(lf[309]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3869 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[197],t1);}

/* k3865 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 818  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2155(t2,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3806,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[300],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3818,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=lf[304],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 799  with-exception-handler */
t5=C_retrieve(lf[305]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3817 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[3],a[3]=lf[301],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=lf[303],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 799  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3839 in a3817 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3840(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3840r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3840r(t0,t1,t2);}}

static void f_3840r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3846,a[2]=t2,a[3]=lf[302],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 799  g279 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3845 in a3839 in a3817 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3823 in a3817 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 801  ##compiler#collapsable-literal? */
t3=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3829 in a3823 in a3817 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[206],C_retrieve(lf[120]),((C_word*)t0)[2]);
/* compiler.scm: 803  eval */
t3=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3805 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3806,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[299],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 799  g279 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3811 in a3805 in a3799 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3812,2,t0,t1);}
/* compiler.scm: 800  quit */
t2=C_retrieve(lf[153]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[298],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3796 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3736,2,t0,t1);}
t2=C_set_block_item(lf[100],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[144],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[120]));
t6=C_mutate((C_word*)lf[120]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 806  ##compiler#collapsable-literal? */
t8=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3745 in k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 807  ##sys#hash-table-set! */
t4=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[99]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 810  gensym */
t3=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3755 in k3745 in k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 811  ##sys#hash-table-set! */
t4=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[99]),((C_word*)t0)[2],t3);}

/* k3758 in k3755 in k3745 in k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 812  alist-cons */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[101]));}

/* k3762 in k3758 in k3755 in k3745 in k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[71]));
t4=C_mutate((C_word*)lf[71]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[56]));
t6=C_mutate((C_word*)lf[56]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[144],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[233],((C_word*)t0)[7],t7);
/* compiler.scm: 815  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2155(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3748 in k3745 in k3734 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[296]);}

/* a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3675,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3679,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 789  ##sys#hash-table-set! */
t5=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[97]),((C_word*)t0)[2],t2);}

/* k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3717,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 790  unzip1 */
t4=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3715 in k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 790  append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[56]));}

/* k3681 in k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=C_set_block_item(lf[98],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3695,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=lf[293],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a3696 in k3681 in k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3697,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[144],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[233],t3,t5));}

/* k3693 in k3681 in k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[197],t1);}

/* k3689 in k3681 in k3677 in a3674 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 792  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2155(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3656 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[216],t3);
/* compiler.scm: 788  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2155(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3663 in a3656 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 787  ##compiler#extract-mutable-constants */
t2=C_retrieve(lf[291]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 766  gensym */
t3=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 768  ##compiler#set-real-name! */
t6=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[118]));
t4=C_mutate((C_word*)lf[118]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 771  ##compiler#estimate-foreign-result-location-size */
t7=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3616 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 771  ##compiler#words */
t2=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[286],t2);
t4=(C_word)C_a_i_list(&a,2,lf[144],t1);
t5=(C_word)C_a_i_list(&a,3,lf[249],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3554,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t10,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t12=(C_word)C_a_i_list(&a,3,lf[233],((C_word*)t0)[5],((C_word*)t0)[3]);
t13=t11;
f_3570(t13,(C_word)C_a_i_list(&a,1,t12));}
else{
t12=t11;
f_3570(t12,C_SCHEME_END_OF_LIST);}}

/* k3568 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_3570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3570,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3578,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 779  fifth */
t3=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3578(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3576 in k3568 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 435  ##sys#append */
t3=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3564 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[197],t1);}

/* k3556 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 780  alist-cons */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3560 in k3556 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 774  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3552 in k3593 in k3537 in k3531 in k3528 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[2],t1));}

/* k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 753  ##compiler#make-random-name */
t9=C_retrieve(lf[135]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3467(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 754  fifth */
t5=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3501 in k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 754  symbol->string */
t3=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3493 in k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3467(t3,t2);}

/* k3465 in k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_3467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3467,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[110]));
t4=C_mutate((C_word*)lf[110]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 757  string-append */
t6=*((C_word*)lf[282]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[283],((C_word*)((C_word*)t0)[7])[1]);}

/* k3485 in k3465 in k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[280],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[107]));
t4=C_mutate((C_word*)lf[107]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 759  alist-cons */
t6=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[115]));}

/* k3477 in k3485 in k3465 in k3462 in k3453 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[281]);}

/* k3433 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[278]);}

/* k3379 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 735  gensym */
t3=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3382 in k3379 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 736  ##sys#hash-table-set! */
t4=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[106]),((C_word*)t0)[2],t3);}

/* k3385 in k3382 in k3379 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 737  cons* */
t3=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[56]));}

/* k3389 in k3385 in k3382 in k3379 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 738  cons* */
t4=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[71]));}

/* k3393 in k3389 in k3385 in k3382 in k3379 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[233],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[275]);
t8=(C_word)C_a_i_list(&a,3,lf[233],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[197],t4,t8);
/* compiler.scm: 739  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2155(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3309 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3314,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 723  ##compiler#check-c-syntax */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[273]);}

/* k3312 in k3309 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t3=t2;
f_3326(2,t3,((C_word*)t0)[2]);}
else{
/* compiler.scm: 725  symbol->string */
t3=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3324 in k3312 in k3309 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[107]));
t4=C_mutate((C_word*)lf[107]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[270]);}

/* k3294 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 715  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3281 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 712  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3268 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 709  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3255 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 706  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3242 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 703  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3196,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[256],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_3196(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[257]);}}

/* fold in k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 698  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2155(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3223,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 699  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2155(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3221 in fold in k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 699  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3196(t3,t2,((C_word*)t0)[2]);}

/* k3225 in k3221 in fold in k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3214 in fold in k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3188 in k3175 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 693  ##compiler#canonicalize-begin-body */
t2=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3162 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[254]);}

/* k3147 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 684  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2155(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3120 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3126,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 679  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2155(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3124 in k3120 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[237],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3099 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[234],((C_word*)t0)[2],t1));}

/* k3070 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3076,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 670  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4407(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3074 in k3070 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3066 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[249],t1);}

/* k3041 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3047,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 665  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4407(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3045 in k3041 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3037 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[248],t1);}

/* k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2873,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_2077(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 633  ##compiler#get-line */
t5=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}

/* k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2885,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 634  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2155(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(C_retrieve(lf[77]))?(C_word)C_eqp(((C_word*)t0)[5],((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 636  lset-adjoin */
t5=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[134]+1),C_retrieve(lf[57]),((C_word*)t0)[5]);}
else{
t4=t2;
f_2888(t4,C_SCHEME_UNDEFINED);}}

/* k3013 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 637  lset-adjoin */
t4=C_retrieve(lf[245]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[134]+1),C_retrieve(lf[56]),((C_word*)t0)[2]);}

/* k3017 in k3013 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_2888(t3,t2);}

/* k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2888,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 639  macro? */
t5=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_2891(2,t4,C_SCHEME_UNDEFINED);}}

/* k2996 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 642  sprintf */
t3=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[242],((C_word*)t0)[2]);}
else{
t3=t2;
f_3005(2,t3,lf[243]);}}
else{
t2=((C_word*)t0)[4];
f_2891(2,t2,C_SCHEME_UNDEFINED);}}

/* k3003 in k2996 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 640  warning */
t2=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2],t1);}

/* k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 643  keyword? */
t4=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2984 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 644  warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[238],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2894(2,t2,C_SCHEME_UNDEFINED);}}

/* k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[107]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 648  gensym */
t5=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[118]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 656  gensym */
t6=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[232],((C_word*)t0)[4],((C_word*)t0)[2]));}}}

/* k2947 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 657  ##compiler#foreign-type-convert-argument */
t3=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2978 in k2947 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2972,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 661  ##compiler#foreign-type-check */
t7=C_retrieve(lf[235]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2970 in k2978 in k2947 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[237],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[2],t2));}

/* k2904 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 649  ##compiler#foreign-type-convert-argument */
t3=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2935 in k2904 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2925,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 652  ##compiler#foreign-type-check */
t7=C_retrieve(lf[235]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2923 in k2935 in k2904 in k2892 in k2889 in k2886 in k2883 in k2880 in k2871 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[234],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[2],t2));}

/* k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 620  map */
t4=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[212]+1),((C_word*)t0)[6],t1);}

/* k2859 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 620  append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2836 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2853,a[2]=t1,a[3]=lf[231],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 623  ##sys#canonicalize-body */
t5=C_retrieve(lf[208]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)t0)[3]);}

/* a2852 in k2836 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2853,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2849 in k2836 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 622  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2155(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2839 in k2836 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2844,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 626  set-real-names! */
f_2089(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2842 in k2839 in k2836 in k2833 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2844,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[215],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2810 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* compiler.scm: 614  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2155(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2718,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 588  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2783 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[225],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[226],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 589  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2718(2,t2,C_SCHEME_UNDEFINED);}}

/* a2795 in k2783 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2796,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2789 in k2783 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
/* compiler.scm: 591  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[223]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[224]+1));}

/* k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=lf[221],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 594  ##compiler#decompose-lambda-list */
t3=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2723,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[167]),t2);}

/* k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 598  map */
t4=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[212]+1),((C_word*)t0)[8],t1);}

/* k2780 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 598  append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t1,a[3]=lf[220],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 601  ##sys#canonicalize-body */
t5=C_retrieve(lf[208]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4,((C_word*)t0)[3]);}

/* a2773 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2774,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2770 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 600  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2155(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2731 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 607  ##compiler#posq */
t5=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2761(t4,C_SCHEME_FALSE);}}

/* k2766 in k2731 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2761(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2759 in k2731 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 605  ##compiler#build-lambda-list */
t2=C_retrieve(lf[218]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2734 in k2731 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 608  set-real-names! */
f_2089(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2716 in k2707 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2739,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_truep(C_retrieve(lf[67]))?(C_word)C_eqp(lf[215],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 610  ##compiler#expand-profile-lambda */
t3=C_retrieve(lf[217]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[215],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 573  unzip1 */
t4=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2644,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[167]),t1);}

/* k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 575  map */
t4=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k2695 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 575  append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 576  set-real-names! */
f_2089(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=lf[209],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 577  map */
t4=*((C_word*)lf[210]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2676 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2677,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2685,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 578  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2155(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2683 in a2676 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2685,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2655 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2661,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[5],a[3]=lf[207],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 580  ##sys#canonicalize-body */
t6=C_retrieve(lf[208]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,t4,t5,((C_word*)t0)[4]);}

/* a2670 in k2655 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2671,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2663 in k2655 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 580  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2659 in k2655 in k2648 in k2645 in k2642 in k2639 in k2633 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[206],((C_word*)t0)[2],t1));}

/* loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[194]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 563  cadar */
t4=*((C_word*)lf[204]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t1,a[3]=lf[196],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2598,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[203],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2597 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2598,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2616(2,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2626,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 565  ##sys#canonicalize-extension-path */
t7=C_retrieve(lf[201]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],lf[202]);}}

/* k2624 in a2597 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 565  ##sys#find-extension */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2614 in a2597 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2602(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 566  warning */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[199],((C_word*)t0)[2]);}}

/* k2600 in a2597 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 567  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2577(t4,t2,t3);}

/* k2607 in k2600 in a2597 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[197],((C_word*)t0)[2],t1));}

/* a2591 in k2585 in loop in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2592,2,t0,t1);}
/* compiler.scm: 564  ##sys#do-the-right-thing */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2569 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 559  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2504,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,C_retrieve(lf[180]),t1);}

/* k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=lf[189],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=lf[190],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 545  hash-table-update! */
t5=C_retrieve(lf[186]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[129]),lf[191],t3,t4);}

/* a2552 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2546 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2547,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[134]+1),t2,((C_word*)t0)[2]);}

/* k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 548  ##sys#lookup-runtime-requirements */
t3=C_retrieve(lf[188]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2513,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2538,a[2]=t1,a[3]=lf[184],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2544,a[2]=t1,a[3]=lf[185],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 549  hash-table-update! */
t5=C_retrieve(lf[186]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[129]),lf[187],t3,t4);}

/* a2543 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2537 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2538,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[134]+1),t2,((C_word*)t0)[2]);}

/* k2511 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t3=t2;
f_2520(2,t3,lf[178]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=lf[181],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a2531 in k2511 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2532,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[144],t2));}

/* k2528 in k2511 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 435  ##sys#cons */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[180],t1);}

/* k2518 in k2511 in k2508 in k2505 in k2502 in k2499 in k2490 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 552  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2457 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[95]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 534  gensym */
t4=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[174]);}}

/* k2469 in k2457 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 535  alist-cons */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[95]));}

/* k2473 in k2469 in k2457 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[56]));
t4=C_mutate((C_word*)lf[56]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[71]));
t6=C_mutate((C_word*)lf[71]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[75]))){
/* compiler.scm: 514  ##compiler#compressable-literal */
t4=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve(lf[75]));}
else{
t4=t3;
f_2406(2,t4,C_SCHEME_FALSE);}}

/* k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2412,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 516  gensym */
t3=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 517  ##compiler#debugging */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[165],lf[166],((C_word*)t0)[2]);}

/* k2413 in k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 445  open-output-string */
t5=C_retrieve(lf[163]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2103 in k2413 in k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2108,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 446  write */
t3=*((C_word*)lf[162]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2106 in k2103 in k2413 in k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 447  get-output-string */
t2=C_retrieve(lf[161]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2429 in k2413 in k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 519  alist-cons */
t2=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_retrieve(lf[74]));}

/* k2417 in k2413 in k2410 in k2404 in k2398 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[56]));
t4=C_mutate((C_word*)lf[56]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[71]));
t6=C_mutate((C_word*)lf[71]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2352 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 504  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2155(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2359 in k2352 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 505  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2155(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2363 in k2359 in k2352 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2369,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2369(2,t4,lf[157]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 508  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2155(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2367 in k2363 in k2359 in k2352 in k2329 in k2311 in k2304 in k2298 in k2271 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[156],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 460  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2155(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[98]))){
/* compiler.scm: 461  ##sys#hash-table-ref */
t3=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[97]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2195(2,t3,C_SCHEME_FALSE);}}}

/* k2193 in k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 462  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2155(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[107]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 466  ##compiler#final-foreign-type */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[118]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 474  ##compiler#final-foreign-type */
t6=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}}}

/* k2241 in k2193 in k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[151],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 477  ##compiler#finish-foreign-result */
t6=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2251 in k2241 in k2193 in k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 476  ##compiler#foreign-type-convert-result */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2211 in k2193 in k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[147],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 469  ##compiler#finish-foreign-result */
t6=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2221 in k2211 in k2193 in k2180 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 468  ##compiler#foreign-type-convert-result */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2173 in walk in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 458  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2155(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2113,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2120,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[144]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2120(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2120(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2120(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2120(t4,C_SCHEME_FALSE);}}

/* k2118 in unquotify in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void C_fcall f_2089(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2089,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=lf[141],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 442  for-each */
t5=*((C_word*)lf[142]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a2094 in set-real-names! in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2095,4,t0,t1,t2,t3);}
/* compiler.scm: 442  ##compiler#set-real-name! */
t4=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static C_word C_fcall f_2077(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[94]))){
/* compiler.scm: 417  vector-fill! */
t3=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[94]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 418  make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[61]),C_SCHEME_END_OF_LIST);}}

/* k2070 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[94]+1,t1);
t3=((C_word*)t0)[2];
f_2023(2,t3,t2);}

/* k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[97]))){
/* compiler.scm: 420  vector-fill! */
t3=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[97]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2065,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 421  make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k2063 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[97]+1,t1);
t3=((C_word*)t0)[2];
f_2026(2,t3,t2);}

/* k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[99]))){
/* compiler.scm: 423  vector-fill! */
t3=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[99]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 424  make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k2056 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[99]+1,t1);
t3=((C_word*)t0)[2];
f_2029(2,t3,t2);}

/* k2027 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 425  ##compiler#make-random-name */
t3=C_retrieve(lf[135]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[136]);}

/* k2031 in k2027 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 426  make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k2035 in k2031 in k2027 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 427  make-hash-table */
t4=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[134]+1));}

/* k2039 in k2035 in k2031 in k2027 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1,t1);
if(C_truep(C_retrieve(lf[106]))){
/* compiler.scm: 429  vector-fill! */
t3=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve(lf[106]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 430  make-vector */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k2049 in k2039 in k2035 in k2031 in k2027 in k2024 in k2021 in ##compiler#initialize-compiler in k1974 in k1931 in k1927 in k1923 in k1919 in k1915 in k1911 */
static void f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
/* end of file */
