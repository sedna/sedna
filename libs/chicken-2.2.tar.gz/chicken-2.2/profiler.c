/* Generated from profiler.scm by the Chicken compiler
   2005-09-10 23:08
   Version 2, Build 111 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: profiler.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file profiler.c -explicit-use
   unit: profiler
*/

#include "chicken.h"

#define C_METHOD_CACHE_SIZE 8


static C_TLS C_word lf[65];


C_externexport void C_profiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_279(C_word c,C_word t0,C_word t1) C_noret;
static void f_285(C_word c,C_word t0,C_word t1) C_noret;
static void f_291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_300(C_word t0,C_word t1,C_word t2) C_noret;
static void f_310(C_word c,C_word t0,C_word t1) C_noret;
static void f_313(C_word c,C_word t0,C_word t1) C_noret;
static void f_316(C_word c,C_word t0,C_word t1) C_noret;
static void f_319(C_word c,C_word t0,C_word t1) C_noret;
static void f_322(C_word c,C_word t0,C_word t1) C_noret;
static void f_325(C_word c,C_word t0,C_word t1) C_noret;
static void f_328(C_word c,C_word t0,C_word t1) C_noret;
static void f_331(C_word c,C_word t0,C_word t1) C_noret;
static void f_222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_195(C_word t0,C_word t1) C_noret;
static void f_125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_144(C_word c,C_word t0,C_word t1) C_noret;
static void f_147(C_word c,C_word t0,C_word t1) C_noret;
static void f_164(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_164r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_168(C_word c,C_word t0,C_word t1) C_noret;
static void f_150(C_word c,C_word t0,C_word t1) C_noret;
static void f_155(C_word c,C_word t0,C_word t1) C_noret;
static void f_159(C_word c,C_word t0,C_word t1) C_noret;
static void f_129(C_word c,C_word t0,C_word t1) C_noret;
static void f_132(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_300(t0,t1,t2);}

static void C_fcall trf_195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_195(t0,t1);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_profiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_profiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("profiler_toplevel"));
C_check_nursery_minimum(16);
if(!C_demand(16)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(522)){
C_save(t1);
C_rereclaim2(522*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(16);
C_initialize_lf(lf,65);
lf[1]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[3]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
lf[11]=C_static_string(C_heaptop,6,".dylib");
lf[13]=C_static_string(C_heaptop,4,".dll");
lf[15]=C_static_string(C_heaptop,3,".sl");
lf[17]=C_static_string(C_heaptop,3,".so");
lf[19]=C_static_string(C_heaptop,4,".scm");
lf[21]=C_static_string(C_heaptop,6,".setup");
lf[23]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[25]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[27]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[29]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[31]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[33]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[35]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[37]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[39]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[42]=C_h_intern(&lf[42],23,"\003sysprofile-append-mode");
lf[43]=C_h_intern(&lf[43],11,"make-vector");
lf[44]=C_h_intern(&lf[44],25,"\003sysregister-profile-info");
lf[45]=C_h_intern(&lf[45],18,"\003sysfinish-profile");
lf[46]=C_static_lambda_info(C_heaptop,6,"(a154)");
lf[47]=C_h_intern(&lf[47],25,"\003sysimplicit-exit-handler");
lf[48]=C_static_lambda_info(C_heaptop,15,"(a163 . args47)");
lf[49]=C_h_intern(&lf[49],16,"\003sysexit-handler");
lf[50]=C_static_lambda_info(C_heaptop,47,"(##sys#register-profile-info size43 filename44)");
lf[51]=C_h_intern(&lf[51],17,"\003sysprofile-entry");
lf[52]=C_static_lambda_info(C_heaptop,35,"(##sys#profile-entry index55 vec56)");
lf[53]=C_h_intern(&lf[53],16,"\003sysprofile-exit");
lf[54]=C_static_lambda_info(C_heaptop,34,"(##sys#profile-exit index64 vec65)");
lf[55]=C_h_intern(&lf[55],19,"with-output-to-file");
lf[56]=C_h_intern(&lf[56],10,"write-char");
lf[57]=C_h_intern(&lf[57],5,"write");
lf[58]=C_static_lambda_info(C_heaptop,10,"(do78 i80)");
lf[59]=C_static_lambda_info(C_heaptop,12,"(a290 vec76)");
lf[60]=C_h_intern(&lf[60],12,"\003sysfor-each");
lf[61]=C_static_lambda_info(C_heaptop,6,"(a284)");
tmp=C_intern(C_heaptop,7,"\000append");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[62]=C_h_pair(C_restore,tmp);
lf[63]=C_static_lambda_info(C_heaptop,22,"(##sys#finish-profile)");
lf[64]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,65);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=lf[40]=C_SCHEME_END_OF_LIST;;
t23=lf[41]=C_SCHEME_FALSE;;
t24=C_set_block_item(lf[42],0,C_SCHEME_FALSE);
t25=*((C_word*)lf[43]+1);
t26=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_125,a[2]=t25,a[3]=lf[50],tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_173,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp));
t29=*((C_word*)lf[55]+1);
t30=*((C_word*)lf[56]+1);
t31=*((C_word*)lf[57]+1);
t32=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_279,a[2]=t29,a[3]=t31,a[4]=t30,a[5]=lf[63],tmp=(C_word)a,a+=6,tmp));
t33=t1;
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,C_SCHEME_UNDEFINED);}

/* ##sys#finish-profile */
static void f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[61],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(*((C_word*)lf[42]+1))?lf[62]:C_SCHEME_END_OF_LIST);
C_apply(6,0,t1,((C_word*)t0)[2],lf[41],t2,t3);}

/* a284 in ##sys#finish-profile */
static void f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[59],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[40]);}

/* a290 in a284 in ##sys#finish-profile */
static void f_291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_291,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t3,a[7]=lf[58],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_300(t7,t1,C_fix(0));}

/* do78 in a290 in a284 in ##sys#finish-profile */
static void C_fcall f_300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_300,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_make_character(40));}}

/* k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[7]);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k317 in k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k320 in k317 in k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k323 in k320 in k317 in k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}

/* k326 in k323 in k320 in k317 in k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(10));}

/* k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in do78 in a290 in a284 in ##sys#finish-profile */
static void f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(5));
t3=((C_word*)((C_word*)t0)[3])[1];
f_300(t3,((C_word*)t0)[2],t2);}

/* ##sys#profile-exit */
static void f_222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_222,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_plus(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t4,C_fix(3));
t7=(C_word)C_fixnum_plus(t4,C_fix(4));
t8=(C_word)C_slot(t3,t7);
t9=(C_word)C_fixnum_decrease(t8);
t10=(C_word)C_i_set_i_slot(t3,t7,t9);
t11=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t11)){
t12=(C_word)C_slot(t3,t6);
t13=(C_word)C_fudge(C_fix(6));
t14=(C_word)C_slot(t3,t5);
t15=(C_word)C_fixnum_difference(t13,t14);
t16=(C_word)C_fixnum_plus(t12,t15);
t17=(C_word)C_i_set_i_slot(t3,t6,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_i_set_i_slot(t3,t5,C_fix(0)));}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}}

/* ##sys#profile-entry */
static void f_173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_173,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_increase(t4);
t6=(C_word)C_fixnum_plus(t4,C_fix(2));
t7=(C_word)C_fixnum_plus(t4,C_fix(4));
t8=(C_word)C_slot(t3,t7);
t9=(C_word)C_slot(t3,t5);
t10=(C_word)C_fixnum_increase(t9);
t11=(C_word)C_i_set_i_slot(t3,t5,t10);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_195,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t13)){
t14=(C_word)C_fudge(C_fix(6));
t15=t12;
f_195(t15,(C_word)C_i_set_i_slot(t3,t6,t14));}
else{
t14=t12;
f_195(t14,C_SCHEME_UNDEFINED);}}

/* k193 in ##sys#profile-entry */
static void C_fcall f_195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* ##sys#register-profile-info */
static void f_125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_125,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=C_mutate(&lf[41],t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_144,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[49]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t5=t4;
f_129(2,t5,C_SCHEME_UNDEFINED);}}

/* k142 in ##sys#register-profile-info */
static void f_144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_147,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[47]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k145 in k142 in ##sys#register-profile-info */
static void f_147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_150,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_164,a[2]=((C_word*)t0)[2],a[3]=lf[48],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a163 in k145 in k142 in ##sys#register-profile-info */
static void f_164(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_164r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_164r(t0,t1,t2);}}

static void f_164r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_168,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[45]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k166 in a163 in k145 in k142 in ##sys#register-profile-info */
static void f_168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k148 in k145 in k142 in ##sys#register-profile-info */
static void f_150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_155,a[2]=((C_word*)t0)[3],a[3]=lf[46],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a154 in k148 in k145 in k142 in ##sys#register-profile-info */
static void f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_159,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[45]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k157 in a154 in k148 in k145 in k142 in ##sys#register-profile-info */
static void f_159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k127 in ##sys#register-profile-info */
static void f_129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_132,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_times(((C_word*)t0)[3],C_fix(5));
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_fix(0));}

/* k130 in k127 in ##sys#register-profile-info */
static void f_132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,lf[40]);
t3=C_mutate(&lf[40],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
/* end of file */
