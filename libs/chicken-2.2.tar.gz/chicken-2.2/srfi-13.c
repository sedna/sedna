/* Generated from srfi-13.scm by the Chicken compiler
   2005-09-10 23:52
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-13.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file srfi-13.c -explicit-use
   unit: srfi_13
*/

#include "chicken.h"

C_externimport void C_srfi_14_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[539];


C_externexport void C_srfi_13_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1437(C_word c,C_word t0,C_word t1) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1) C_noret;
static void f_7418(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7418r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7530(C_word c,C_word t0,C_word t1) C_noret;
static void f_7500(C_word c,C_word t0,C_word t1) C_noret;
static void f_7483(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7438(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7444(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7466(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void f_7416(C_word c,C_word t0,C_word t1) C_noret;
static void f_7358(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7401(C_word c,C_word t0,C_word t1) C_noret;
static void f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_7205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_7258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7271(C_word c,C_word t0,C_word t1) C_noret;
static void f_7331(C_word c,C_word t0,C_word t1) C_noret;
static void f_7335(C_word c,C_word t0,C_word t1) C_noret;
static void f_7324(C_word c,C_word t0,C_word t1) C_noret;
static void f_7320(C_word c,C_word t0,C_word t1) C_noret;
static void f_7214(C_word c,C_word t0,C_word t1) C_noret;
static void f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7226(C_word c,C_word t0,C_word t1) C_noret;
static void f_7067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_7067r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_7120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7190(C_word c,C_word t0,C_word t1) C_noret;
static void f_7194(C_word c,C_word t0,C_word t1) C_noret;
static void f_7183(C_word c,C_word t0,C_word t1) C_noret;
static void f_7186(C_word c,C_word t0,C_word t1) C_noret;
static void f_7180(C_word c,C_word t0,C_word t1) C_noret;
static void f_7176(C_word c,C_word t0,C_word t1) C_noret;
static void f_7076(C_word c,C_word t0,C_word t1) C_noret;
static void f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7088(C_word c,C_word t0,C_word t1) C_noret;
static void f_6985(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6985r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7013(C_word c,C_word t0,C_word t1) C_noret;
static void f_7022(C_word c,C_word t0,C_word t1) C_noret;
static void f_7047(C_word c,C_word t0,C_word t1) C_noret;
static void f_7036(C_word c,C_word t0,C_word t1) C_noret;
static void f_6997(C_word c,C_word t0,C_word t1) C_noret;
static void f_6934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_6934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_6938(C_word c,C_word t0,C_word t1) C_noret;
static void f_6949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6962(C_word c,C_word t0,C_word t1) C_noret;
static void f_6965(C_word c,C_word t0,C_word t1) C_noret;
static void f_6968(C_word c,C_word t0,C_word t1) C_noret;
static void f_6971(C_word c,C_word t0,C_word t1) C_noret;
static void f_6943(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6891(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6895(C_word c,C_word t0,C_word t1) C_noret;
static void f_6898(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6925(C_word c,C_word t0,C_word t1) C_noret;
static void f_6901(C_word c,C_word t0,C_word t1) C_noret;
static void f_6762(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6762r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_6789(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_6839(C_word t0,C_word t1) C_noret;
static void f_6674(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6674r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static C_word C_fcall f_6704(C_word t0,C_word t1);
static void f_6601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6608(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6613(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6629(C_word c,C_word t0,C_word t1) C_noret;
static void f_6611(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_6642(C_word t0,C_word t1);
static void f_6499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6559(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6564(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6580(C_word c,C_word t0,C_word t1) C_noret;
static void f_6562(C_word c,C_word t0,C_word t1) C_noret;
static void f_6493(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6493r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6447(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6447r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6453(C_word c,C_word t0,C_word t1) C_noret;
static void f_6392(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6392r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_6414(C_word t0,C_word t1,C_word t2);
static void f_6398(C_word c,C_word t0,C_word t1) C_noret;
static void f_6337(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6337r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6356(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_6365(C_word t0,C_word t1,C_word t2);
static void f_6343(C_word c,C_word t0,C_word t1) C_noret;
static void f_6334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_6213r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_6237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_6246(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6278(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6285(C_word c,C_word t0,C_word t1) C_noret;
static void f_6276(C_word c,C_word t0,C_word t1) C_noret;
static void f_6231(C_word c,C_word t0,C_word t1) C_noret;
static void f_6175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void C_fcall f_6181(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6188(C_word c,C_word t0,C_word t1) C_noret;
static void f_6040(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6040r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6065(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6130(C_word c,C_word t0,C_word t1) C_noret;
static void f_6124(C_word c,C_word t0,C_word t1) C_noret;
static void f_6068(C_word c,C_word t0,C_word t1) C_noret;
static void f_6052(C_word c,C_word t0,C_word t1) C_noret;
static void f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_5949(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_5980(C_word c,C_word t0,C_word t1) C_noret;
static void f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5880r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5916(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5929(C_word c,C_word t0,C_word t1) C_noret;
static void f_5898(C_word c,C_word t0,C_word t1) C_noret;
static void f_5886(C_word c,C_word t0,C_word t1) C_noret;
static void f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5818r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5854(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5867(C_word c,C_word t0,C_word t1) C_noret;
static void f_5836(C_word c,C_word t0,C_word t1) C_noret;
static void f_5824(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5737(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static C_word C_fcall f_5787(C_word t0,C_word t1,C_word t2);
static C_word C_fcall f_5749(C_word t0,C_word t1,C_word t2);
static void f_5705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_5705r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_5717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5724(C_word c,C_word t0,C_word t1) C_noret;
static void f_5711(C_word c,C_word t0,C_word t1) C_noret;
static void f_5664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5664r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_5686(C_word t0,C_word t1);
static void f_5670(C_word c,C_word t0,C_word t1) C_noret;
static void f_5529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5529r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5587(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5631(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5652(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5613(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5553(C_word t0,C_word t1,C_word t2);
static void f_5535(C_word c,C_word t0,C_word t1) C_noret;
static void f_5394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5452(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5513(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5461(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5474(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5422(C_word t0,C_word t1);
static void f_5400(C_word c,C_word t0,C_word t1) C_noret;
static void f_5271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5271r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5325(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5378(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5343(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5295(C_word t0,C_word t1);
static void f_5277(C_word c,C_word t0,C_word t1) C_noret;
static void f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5136r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5194(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5255(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5203(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5216(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5164(C_word t0,C_word t1);
static void f_5142(C_word c,C_word t0,C_word t1) C_noret;
static void f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5013r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5067(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5107(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5120(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5072(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5085(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5037(C_word t0,C_word t1);
static void f_5019(C_word c,C_word t0,C_word t1) C_noret;
static void f_4905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4999(C_word c,C_word t0,C_word t1) C_noret;
static void f_4960(C_word c,C_word t0,C_word t1) C_noret;
static void f_4986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4993(C_word c,C_word t0,C_word t1) C_noret;
static void f_4963(C_word c,C_word t0,C_word t1) C_noret;
static void f_4966(C_word c,C_word t0,C_word t1) C_noret;
static void f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4978(C_word c,C_word t0,C_word t1) C_noret;
static void f_4969(C_word c,C_word t0,C_word t1) C_noret;
static void f_4930(C_word c,C_word t0,C_word t1) C_noret;
static void f_4944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4951(C_word c,C_word t0,C_word t1) C_noret;
static void f_4933(C_word c,C_word t0,C_word t1) C_noret;
static void f_4911(C_word c,C_word t0,C_word t1) C_noret;
static void f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4797r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4891(C_word c,C_word t0,C_word t1) C_noret;
static void f_4852(C_word c,C_word t0,C_word t1) C_noret;
static void f_4878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4885(C_word c,C_word t0,C_word t1) C_noret;
static void f_4855(C_word c,C_word t0,C_word t1) C_noret;
static void f_4858(C_word c,C_word t0,C_word t1) C_noret;
static void f_4863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4870(C_word c,C_word t0,C_word t1) C_noret;
static void f_4861(C_word c,C_word t0,C_word t1) C_noret;
static void f_4822(C_word c,C_word t0,C_word t1) C_noret;
static void f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4843(C_word c,C_word t0,C_word t1) C_noret;
static void f_4825(C_word c,C_word t0,C_word t1) C_noret;
static void f_4803(C_word c,C_word t0,C_word t1) C_noret;
static void f_4735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4776(C_word c,C_word t0,C_word t1) C_noret;
static void f_4779(C_word c,C_word t0,C_word t1) C_noret;
static void f_4750(C_word c,C_word t0,C_word t1) C_noret;
static void f_4677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4718(C_word c,C_word t0,C_word t1) C_noret;
static void f_4721(C_word c,C_word t0,C_word t1) C_noret;
static void f_4692(C_word c,C_word t0,C_word t1) C_noret;
static void f_4627(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4627r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4649(C_word c,C_word t0,C_word t1) C_noret;
static void f_4663(C_word c,C_word t0,C_word t1) C_noret;
static void f_4639(C_word c,C_word t0,C_word t1) C_noret;
static void f_4581(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4581r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4603(C_word c,C_word t0,C_word t1) C_noret;
static void f_4593(C_word c,C_word t0,C_word t1) C_noret;
static void f_4539(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4539r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4561(C_word c,C_word t0,C_word t1) C_noret;
static void f_4551(C_word c,C_word t0,C_word t1) C_noret;
static void f_4523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4461(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4461r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4477(C_word c,C_word t0,C_word t1) C_noret;
static void f_4480(C_word c,C_word t0,C_word t1) C_noret;
static void f_4467(C_word c,C_word t0,C_word t1) C_noret;
static void f_4443(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4443r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4449(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4390(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4394(C_word c,C_word t0,C_word t1) C_noret;
static void f_4424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4406(C_word c,C_word t0,C_word t1) C_noret;
static void f_4412(C_word c,C_word t0,C_word t1) C_noret;
static void f_4366(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4366r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4372(C_word c,C_word t0,C_word t1) C_noret;
static void f_4348(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4348r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4354(C_word c,C_word t0,C_word t1) C_noret;
static void f_4330(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4330r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4336(C_word c,C_word t0,C_word t1) C_noret;
static void f_4312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4318(C_word c,C_word t0,C_word t1) C_noret;
static void f_4256(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4256r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4266(C_word t0,C_word t1) C_noret;
static void f_4280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4274(C_word c,C_word t0,C_word t1) C_noret;
static void f_4210(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4210r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4220(C_word t0,C_word t1) C_noret;
static void f_4234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4228(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4189(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_4191(C_word t0,C_word t1);
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4090r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4121(C_word t0,C_word t1) C_noret;
static void f_4129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4108(C_word c,C_word t0,C_word t1) C_noret;
static void f_4096(C_word c,C_word t0,C_word t1) C_noret;
static void f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4073(C_word t0,C_word t1) C_noret;
static void f_4081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4060(C_word c,C_word t0,C_word t1) C_noret;
static void f_4048(C_word c,C_word t0,C_word t1) C_noret;
static void f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3991r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4022(C_word t0,C_word t1) C_noret;
static void f_4033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4009(C_word c,C_word t0,C_word t1) C_noret;
static void f_3997(C_word c,C_word t0,C_word t1) C_noret;
static void f_3940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3971(C_word t0,C_word t1) C_noret;
static void f_3982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3958(C_word c,C_word t0,C_word t1) C_noret;
static void f_3946(C_word c,C_word t0,C_word t1) C_noret;
static void f_3873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3873r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3920(C_word t0,C_word t1) C_noret;
static void f_3915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3891(C_word c,C_word t0,C_word t1) C_noret;
static void f_3879(C_word c,C_word t0,C_word t1) C_noret;
static void f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3811r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3845(C_word t0,C_word t1) C_noret;
static void f_3856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3829(C_word c,C_word t0,C_word t1) C_noret;
static void f_3817(C_word c,C_word t0,C_word t1) C_noret;
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3763r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3794(C_word t0,C_word t1) C_noret;
static void f_3802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3781(C_word c,C_word t0,C_word t1) C_noret;
static void f_3769(C_word c,C_word t0,C_word t1) C_noret;
static void f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3746(C_word t0,C_word t1) C_noret;
static void f_3754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3733(C_word c,C_word t0,C_word t1) C_noret;
static void f_3721(C_word c,C_word t0,C_word t1) C_noret;
static void f_3664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3664r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3695(C_word t0,C_word t1) C_noret;
static void f_3706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3682(C_word c,C_word t0,C_word t1) C_noret;
static void f_3670(C_word c,C_word t0,C_word t1) C_noret;
static void f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3644(C_word t0,C_word t1) C_noret;
static void f_3655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3631(C_word c,C_word t0,C_word t1) C_noret;
static void f_3619(C_word c,C_word t0,C_word t1) C_noret;
static void f_3546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3546r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3593(C_word t0,C_word t1) C_noret;
static void f_3588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3564(C_word c,C_word t0,C_word t1) C_noret;
static void f_3552(C_word c,C_word t0,C_word t1) C_noret;
static void f_3484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3484r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3518(C_word t0,C_word t1) C_noret;
static void f_3529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3502(C_word c,C_word t0,C_word t1) C_noret;
static void f_3490(C_word c,C_word t0,C_word t1) C_noret;
static void f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
static void f_3454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
static void f_3466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3472(C_word c,C_word t0,C_word t1) C_noret;
static void f_3460(C_word c,C_word t0,C_word t1) C_noret;
static void f_3424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
static void f_3424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
static void f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3442(C_word c,C_word t0,C_word t1) C_noret;
static void f_3430(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
static void f_3372(C_word c,C_word t0,C_word t1) C_noret;
static void f_3406(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3397(C_word t0,C_word t1) C_noret;
static void C_fcall f_3300(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
static void f_3310(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3335(C_word t0,C_word t1) C_noret;
static void f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3294(C_word c,C_word t0,C_word t1) C_noret;
static void f_3196(C_word c,C_word t0,C_word t1) C_noret;
static void f_3184(C_word c,C_word t0,C_word t1) C_noret;
static void f_3148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3271(C_word c,C_word t0,C_word t1) C_noret;
static void f_3166(C_word c,C_word t0,C_word t1) C_noret;
static void f_3154(C_word c,C_word t0,C_word t1) C_noret;
static void f_3118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3118r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3248(C_word c,C_word t0,C_word t1) C_noret;
static void f_3136(C_word c,C_word t0,C_word t1) C_noret;
static void f_3124(C_word c,C_word t0,C_word t1) C_noret;
static void f_3088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3225(C_word c,C_word t0,C_word t1) C_noret;
static void f_3106(C_word c,C_word t0,C_word t1) C_noret;
static void f_3094(C_word c,C_word t0,C_word t1) C_noret;
static void f_3058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3076(C_word c,C_word t0,C_word t1) C_noret;
static void f_3064(C_word c,C_word t0,C_word t1) C_noret;
static void f_3028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3046(C_word c,C_word t0,C_word t1) C_noret;
static void f_3034(C_word c,C_word t0,C_word t1) C_noret;
static void f_2998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2998r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3016(C_word c,C_word t0,C_word t1) C_noret;
static void f_3004(C_word c,C_word t0,C_word t1) C_noret;
static void f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2986(C_word c,C_word t0,C_word t1) C_noret;
static void f_2974(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2883(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2887(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2896(C_word t0,C_word t1) C_noret;
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2944(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2919(C_word t0,C_word t1) C_noret;
static void C_fcall f_2810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2814(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2823(C_word t0,C_word t1) C_noret;
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2859(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2838(C_word t0,C_word t1) C_noret;
static void C_fcall f_2725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2729(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2738(C_word t0,C_word t1) C_noret;
static void C_fcall f_2751(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2761(C_word t0,C_word t1) C_noret;
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2656(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2680(C_word t0,C_word t1) C_noret;
static void f_2613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2620(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2629(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2650(C_word c,C_word t0,C_word t1) C_noret;
static void f_2623(C_word c,C_word t0,C_word t1) C_noret;
static void f_2483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2483r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2537(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2583(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2602(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2552(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2507(C_word t0,C_word t1);
static void f_2489(C_word c,C_word t0,C_word t1) C_noret;
static void f_2353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2407(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2453(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2475(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2425(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2377(C_word t0,C_word t1);
static void f_2359(C_word c,C_word t0,C_word t1) C_noret;
static void f_2316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2316r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2344(C_word c,C_word t0,C_word t1) C_noret;
static void f_2322(C_word c,C_word t0,C_word t1) C_noret;
static void f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2275r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2303(C_word c,C_word t0,C_word t1) C_noret;
static void f_2281(C_word c,C_word t0,C_word t1) C_noret;
static void f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_2086r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_2112(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2244(C_word c,C_word t0,C_word t1) C_noret;
static void f_2130(C_word c,C_word t0,C_word t1) C_noret;
static void f_2133(C_word c,C_word t0,C_word t1) C_noret;
static void f_2154(C_word c,C_word t0,C_word t1) C_noret;
static void f_2157(C_word c,C_word t0,C_word t1) C_noret;
static void f_2177(C_word c,C_word t0,C_word t1) C_noret;
static void f_2192(C_word c,C_word t0,C_word t1) C_noret;
static void f_2195(C_word c,C_word t0,C_word t1) C_noret;
static void f_2198(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2226(C_word c,C_word t0,C_word t1) C_noret;
static void f_2201(C_word c,C_word t0,C_word t1) C_noret;
static void f_2257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_1904r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_1930(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void C_fcall f_1938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2055(C_word c,C_word t0,C_word t1) C_noret;
static void f_1948(C_word c,C_word t0,C_word t1) C_noret;
static void f_1951(C_word c,C_word t0,C_word t1) C_noret;
static void f_1973(C_word c,C_word t0,C_word t1) C_noret;
static void f_1976(C_word c,C_word t0,C_word t1) C_noret;
static void f_1993(C_word c,C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void f_2008(C_word c,C_word t0,C_word t1) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2022(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2044(C_word c,C_word t0,C_word t1) C_noret;
static void f_2017(C_word c,C_word t0,C_word t1) C_noret;
static void f_2020(C_word c,C_word t0,C_word t1) C_noret;
static void f_2068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_1858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1894(C_word c,C_word t0,C_word t1) C_noret;
static void f_1864(C_word c,C_word t0,C_word t1) C_noret;
static void f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_1816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_1828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1848(C_word c,C_word t0,C_word t1) C_noret;
static void f_1822(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1810(C_word c,C_word t0,C_word t1) C_noret;
static void f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1767(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1717(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1755(C_word c,C_word t0,C_word t1) C_noret;
static void f_1720(C_word c,C_word t0,C_word t1) C_noret;
static void f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1698(C_word c,C_word t0,C_word t1) C_noret;
static void f_1674(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1674r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1680(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1659(C_word t0,C_word t1) C_noret;
static void f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1618r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1625(C_word c,C_word t0,C_word t1) C_noret;
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1616(C_word c,C_word t0,C_word t1) C_noret;
static void f_1562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1541(C_word c,C_word t0,C_word t1) C_noret;
static void f_1442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1472(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_7438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7438(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7438(t0,t1,t2,t3);}

static void C_fcall trf_7444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7444(t0,t1,t2);}

static void C_fcall trf_7345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7345(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7345(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_7376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7376(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7376(t0,t1,t2,t3);}

static void C_fcall trf_7009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7009(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7009(t0,t1,t2,t3);}

static void C_fcall trf_6891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6891(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6891(t0,t1,t2,t3,t4);}

static void C_fcall trf_6903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6903(t0,t1,t2,t3);}

static void C_fcall trf_6789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6789(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6789(t0,t1,t2,t3,t4);}

static void C_fcall trf_6839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6839(t0,t1);}

static void C_fcall trf_6613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6613(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6613(t0,t1,t2,t3);}

static void C_fcall trf_6505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6505(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6505(t0,t1,t2,t3,t4);}

static void C_fcall trf_6564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6564(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6564(t0,t1,t2,t3);}

static void C_fcall trf_6469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6469(t0,t1,t2,t3);}

static void C_fcall trf_6246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6246(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6246(t0,t1,t2,t3);}

static void C_fcall trf_6278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6278(t0,t1,t2);}

static void C_fcall trf_6181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6181(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6181(t0,t1,t2);}

static void C_fcall trf_6082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6082(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6082(t0,t1,t2,t3,t4);}

static void C_fcall trf_6097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6097(t0,t1,t2);}

static void C_fcall trf_5958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5958(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5958(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5916(t0,t1,t2);}

static void C_fcall trf_5854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5854(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5854(t0,t1,t2);}

static void C_fcall trf_5737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5737(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5737(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5631(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5631(t0,t1,t2,t3);}

static void C_fcall trf_5592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5592(t0,t1,t2,t3);}

static void C_fcall trf_5500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5500(t0,t1,t2);}

static void C_fcall trf_5461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5461(t0,t1,t2);}

static void C_fcall trf_5365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5365(t0,t1,t2);}

static void C_fcall trf_5330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5330(t0,t1,t2);}

static void C_fcall trf_5242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5242(t0,t1,t2);}

static void C_fcall trf_5203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5203(t0,t1,t2);}

static void C_fcall trf_5107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5107(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5107(t0,t1,t2);}

static void C_fcall trf_5072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5072(t0,t1,t2);}

static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4384(t0,t1,t2,t3);}

static void C_fcall trf_4390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4390(t0,t1,t2);}

static void C_fcall trf_4266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4266(t0,t1);}

static void C_fcall trf_4220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4220(t0,t1);}

static void C_fcall trf_4138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4138(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4138(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4156(t0,t1,t2,t3);}

static void C_fcall trf_4140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4140(t0,t1,t2,t3);}

static void C_fcall trf_4121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4121(t0,t1);}

static void C_fcall trf_4073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4073(t0,t1);}

static void C_fcall trf_4022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4022(t0,t1);}

static void C_fcall trf_3971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3971(t0,t1);}

static void C_fcall trf_3920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3920(t0,t1);}

static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3845(t0,t1);}

static void C_fcall trf_3794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3794(t0,t1);}

static void C_fcall trf_3746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3746(t0,t1);}

static void C_fcall trf_3695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3695(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3695(t0,t1);}

static void C_fcall trf_3644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3644(t0,t1);}

static void C_fcall trf_3593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3593(t0,t1);}

static void C_fcall trf_3518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3518(t0,t1);}

static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3362(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

static void C_fcall trf_3397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3397(t0,t1);}

static void C_fcall trf_3300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3300(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3300(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

static void C_fcall trf_3335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3335(t0,t1);}

static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2883(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2896(t0,t1);}

static void C_fcall trf_2909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2909(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2909(t0,t1,t2,t3);}

static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2919(t0,t1);}

static void C_fcall trf_2810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2810(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2810(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2823(t0,t1);}

static void C_fcall trf_2828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2828(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2828(t0,t1,t2,t3);}

static void C_fcall trf_2838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2838(t0,t1);}

static void C_fcall trf_2725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2725(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2725(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2738(t0,t1);}

static void C_fcall trf_2751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2751(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2751(t0,t1,t2,t3);}

static void C_fcall trf_2761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2761(t0,t1);}

static void C_fcall trf_2652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2652(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2652(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2665(t0,t1);}

static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2670(t0,t1,t2,t3);}

static void C_fcall trf_2680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2680(t0,t1);}

static void C_fcall trf_2629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2629(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2629(t0,t1,t2);}

static void C_fcall trf_2583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2583(t0,t1,t2);}

static void C_fcall trf_2542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2542(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2542(t0,t1,t2);}

static void C_fcall trf_2453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2453(t0,t1,t2);}

static void C_fcall trf_2412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2412(t0,t1,t2);}

static void C_fcall trf_2334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2334(t0,t1,t2);}

static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2293(t0,t1,t2);}

static void C_fcall trf_2114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2114(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_2114(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2120(t0,t1,t2,t3);}

static void C_fcall trf_2207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2207(t0,t1,t2,t3);}

static void C_fcall trf_1932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1932(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_1932(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1938(t0,t1,t2,t3);}

static void C_fcall trf_2022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2022(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2022(t0,t1,t2,t3);}

static void C_fcall trf_1880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1880(t0,t1,t2,t3);}

static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1834(t0,t1,t2,t3);}

static void C_fcall trf_1779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1779(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1779(t0,t1,t2,t3,t4);}

static void C_fcall trf_1789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1789(t0,t1,t2);}

static void C_fcall trf_1710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1710(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1710(t0,t1,t2,t3,t4);}

static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1730(t0,t1,t2,t3);}

static void C_fcall trf_1652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1652(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1652(t0,t1,t2,t3);}

static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1659(t0,t1);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_13_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_13_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(981)){
C_save(t1);
C_rereclaim2(981*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,539);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],22,"string-parse-start+end");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,26,"Illegal substring END spec");
lf[5]=C_static_lambda_info(C_heaptop,7,"(a1471)");
lf[6]=C_static_string(C_heaptop,32,"Illegal substring START/END spec");
lf[7]=C_static_lambda_info(C_heaptop,20,"(a1507 end12 args13)");
lf[8]=C_static_string(C_heaptop,28,"Illegal substring START spec");
lf[9]=C_static_lambda_info(C_heaptop,39,"(string-parse-start+end proc4 s5 args6)");
lf[10]=C_h_intern(&lf[10],28,"string-parse-final-start+end");
lf[11]=C_static_lambda_info(C_heaptop,7,"(a1540)");
lf[12]=C_static_string(C_heaptop,28,"Extra arguments to procedure");
lf[13]=C_static_lambda_info(C_heaptop,28,"(a1546 rest18 start19 end20)");
lf[14]=C_static_lambda_info(C_heaptop,48,"(string-parse-final-start+end proc15 s16 args17)");
lf[15]=C_h_intern(&lf[15],18,"substring-spec-ok\077");
lf[16]=C_static_lambda_info(C_heaptop,38,"(substring-spec-ok\077 s21 start22 end23)");
lf[17]=C_h_intern(&lf[17],20,"check-substring-spec");
lf[18]=C_static_string(C_heaptop,23,"Illegal substring spec.");
lf[19]=C_static_lambda_info(C_heaptop,47,"(check-substring-spec proc24 s25 start26 end27)");
lf[20]=C_h_intern(&lf[20],16,"substring/shared");
lf[22]=C_static_lambda_info(C_heaptop,44,"(substring/shared s28 start29 . maybe-end30)");
lf[23]=C_h_intern(&lf[23],13,"\003syssubstring");
lf[24]=C_static_lambda_info(C_heaptop,37,"(%substring/shared s37 start38 end39)");
lf[25]=C_h_intern(&lf[25],11,"string-copy");
lf[26]=C_static_lambda_info(C_heaptop,7,"(a1679)");
lf[27]=C_static_lambda_info(C_heaptop,21,"(a1685 start42 end43)");
lf[28]=C_static_lambda_info(C_heaptop,37,"(string-copy s40 . maybe-start+end41)");
lf[29]=C_h_intern(&lf[29],10,"string-map");
lf[30]=C_static_lambda_info(C_heaptop,7,"(a1697)");
lf[32]=C_static_lambda_info(C_heaptop,21,"(a1703 start47 end48)");
lf[33]=C_static_lambda_info(C_heaptop,43,"(string-map proc44 s45 . maybe-start+end46)");
lf[34]=C_static_lambda_info(C_heaptop,14,"(do55 i57 j58)");
lf[35]=C_h_intern(&lf[35],11,"make-string");
lf[36]=C_static_lambda_info(C_heaptop,38,"(%string-map proc49 s50 start51 end52)");
lf[37]=C_h_intern(&lf[37],11,"string-map!");
lf[38]=C_static_lambda_info(C_heaptop,7,"(a1766)");
lf[40]=C_static_lambda_info(C_heaptop,21,"(a1772 start65 end66)");
lf[41]=C_static_lambda_info(C_heaptop,44,"(string-map! proc62 s63 . maybe-start+end64)");
lf[42]=C_static_lambda_info(C_heaptop,10,"(do71 i73)");
lf[43]=C_static_lambda_info(C_heaptop,39,"(%string-map! proc67 s68 start69 end70)");
lf[44]=C_h_intern(&lf[44],11,"string-fold");
lf[45]=C_static_lambda_info(C_heaptop,7,"(a1821)");
lf[46]=C_static_lambda_info(C_heaptop,12,"(lp v83 i84)");
lf[47]=C_static_lambda_info(C_heaptop,21,"(a1827 start80 end81)");
lf[48]=C_static_lambda_info(C_heaptop,51,"(string-fold kons76 knil77 s78 . maybe-start+end79)");
lf[49]=C_h_intern(&lf[49],17,"string-fold-right");
lf[50]=C_static_lambda_info(C_heaptop,7,"(a1863)");
lf[51]=C_static_lambda_info(C_heaptop,12,"(lp v93 i94)");
lf[52]=C_static_lambda_info(C_heaptop,21,"(a1869 start90 end91)");
lf[53]=C_static_lambda_info(C_heaptop,57,"(string-fold-right kons86 knil87 s88 . maybe-start+end89)");
lf[54]=C_h_intern(&lf[54],13,"string-unfold");
lf[55]=C_static_string(C_heaptop,0,"");
lf[56]=C_static_string(C_heaptop,0,"");
lf[57]=C_static_lambda_info(C_heaptop,13,"(f_2068 x109)");
lf[59]=C_static_lambda_info(C_heaptop,19,"(lp j134 chunks135)");
lf[60]=C_h_intern(&lf[60],3,"min");
lf[61]=C_static_lambda_info(C_heaptop,18,"(lp2 i118 seed119)");
lf[62]=C_static_lambda_info(C_heaptop,59,"(lp chunks111 nchars112 chunk113 chunk-len114 i115 seed116)");
lf[63]=C_static_lambda_info(C_heaptop,55,"(string-unfold p96 f97 g98 seed99 . base+make-final100)");
lf[64]=C_h_intern(&lf[64],19,"string-unfold-right");
lf[65]=C_static_string(C_heaptop,0,"");
lf[66]=C_static_string(C_heaptop,0,"");
lf[67]=C_static_lambda_info(C_heaptop,13,"(f_2257 x161)");
lf[68]=C_static_lambda_info(C_heaptop,19,"(lp j188 chunks189)");
lf[69]=C_static_lambda_info(C_heaptop,18,"(lp2 i170 seed171)");
lf[70]=C_static_lambda_info(C_heaptop,59,"(lp chunks163 nchars164 chunk165 chunk-len166 i167 seed168)");
lf[71]=C_static_lambda_info(C_heaptop,65,"(string-unfold-right p148 f149 g150 seed151 . base+make-final152)");
lf[72]=C_h_intern(&lf[72],15,"string-for-each");
lf[73]=C_static_lambda_info(C_heaptop,7,"(a2280)");
lf[74]=C_static_lambda_info(C_heaptop,9,"(lp i206)");
lf[75]=C_static_lambda_info(C_heaptop,23,"(a2286 start203 end204)");
lf[76]=C_static_lambda_info(C_heaptop,51,"(string-for-each proc200 s201 . maybe-start+end202)");
lf[77]=C_h_intern(&lf[77],21,"string-for-each-index");
lf[78]=C_static_lambda_info(C_heaptop,7,"(a2321)");
lf[79]=C_static_lambda_info(C_heaptop,9,"(lp i215)");
lf[80]=C_static_lambda_info(C_heaptop,23,"(a2327 start212 end213)");
lf[81]=C_static_lambda_info(C_heaptop,57,"(string-for-each-index proc209 s210 . maybe-start+end211)");
lf[82]=C_h_intern(&lf[82],12,"string-every");
lf[83]=C_static_lambda_info(C_heaptop,7,"(a2358)");
lf[84]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[85]=C_h_intern(&lf[85],18,"char-set-contains\077");
lf[86]=C_static_lambda_info(C_heaptop,9,"(lp i229)");
lf[87]=C_static_lambda_info(C_heaptop,9,"(lp i236)");
lf[88]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[89]=C_h_intern(&lf[89],9,"char-set\077");
lf[90]=C_static_lambda_info(C_heaptop,23,"(a2364 start221 end222)");
lf[91]=C_static_lambda_info(C_heaptop,52,"(string-every criteria218 s219 . maybe-start+end220)");
lf[92]=C_h_intern(&lf[92],10,"string-any");
lf[93]=C_static_lambda_info(C_heaptop,7,"(a2488)");
lf[94]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[95]=C_static_lambda_info(C_heaptop,9,"(lp i251)");
lf[96]=C_static_lambda_info(C_heaptop,9,"(lp i256)");
lf[97]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[98]=C_static_lambda_info(C_heaptop,23,"(a2494 start243 end244)");
lf[99]=C_static_lambda_info(C_heaptop,50,"(string-any criteria240 s241 . maybe-start+end242)");
lf[100]=C_h_intern(&lf[100],15,"string-tabulate");
lf[101]=C_static_lambda_info(C_heaptop,12,"(do265 i267)");
lf[102]=C_static_lambda_info(C_heaptop,32,"(string-tabulate proc262 len263)");
lf[104]=C_static_lambda_info(C_heaptop,14,"(lp i281 j282)");
lf[105]=C_static_lambda_info(C_heaptop,71,"(%string-prefix-length s1272 start1273 end1274 s2275 start2276 end2277)");
lf[107]=C_static_lambda_info(C_heaptop,14,"(lp i295 j296)");
lf[108]=C_static_lambda_info(C_heaptop,71,"(%string-suffix-length s1286 start1287 end1288 s2289 start2290 end2291)");
lf[110]=C_h_intern(&lf[110],9,"char-ci=\077");
lf[111]=C_static_lambda_info(C_heaptop,14,"(lp i309 j310)");
lf[112]=C_static_lambda_info(C_heaptop,74,"(%string-prefix-length-ci s1300 start1301 end1302 s2303 start2304 end2305)");
lf[114]=C_static_lambda_info(C_heaptop,14,"(lp i323 j324)");
lf[115]=C_static_lambda_info(C_heaptop,74,"(%string-suffix-length-ci s1314 start1315 end1316 s2317 start2318 end2319)");
lf[116]=C_h_intern(&lf[116],20,"string-prefix-length");
lf[117]=C_static_lambda_info(C_heaptop,7,"(a2973)");
lf[118]=C_static_lambda_info(C_heaptop,7,"(a2985)");
lf[119]=C_static_lambda_info(C_heaptop,25,"(a2991 start2337 end2338)");
lf[120]=C_static_lambda_info(C_heaptop,33,"(a2979 g332334 start1335 end1336)");
lf[121]=C_static_lambda_info(C_heaptop,57,"(string-prefix-length s1328 s2329 . maybe-starts+ends330)");
lf[122]=C_h_intern(&lf[122],20,"string-suffix-length");
lf[123]=C_static_lambda_info(C_heaptop,7,"(a3003)");
lf[124]=C_static_lambda_info(C_heaptop,7,"(a3015)");
lf[125]=C_static_lambda_info(C_heaptop,25,"(a3021 start2348 end2349)");
lf[126]=C_static_lambda_info(C_heaptop,33,"(a3009 g343345 start1346 end1347)");
lf[127]=C_static_lambda_info(C_heaptop,57,"(string-suffix-length s1339 s2340 . maybe-starts+ends341)");
lf[128]=C_h_intern(&lf[128],23,"string-prefix-length-ci");
lf[129]=C_static_lambda_info(C_heaptop,7,"(a3033)");
lf[130]=C_static_lambda_info(C_heaptop,7,"(a3045)");
lf[131]=C_static_lambda_info(C_heaptop,25,"(a3051 start2359 end2360)");
lf[132]=C_static_lambda_info(C_heaptop,33,"(a3039 g354356 start1357 end1358)");
lf[133]=C_static_lambda_info(C_heaptop,60,"(string-prefix-length-ci s1350 s2351 . maybe-starts+ends352)");
lf[134]=C_h_intern(&lf[134],23,"string-suffix-length-ci");
lf[135]=C_static_lambda_info(C_heaptop,7,"(a3063)");
lf[136]=C_static_lambda_info(C_heaptop,7,"(a3075)");
lf[137]=C_static_lambda_info(C_heaptop,25,"(a3081 start2370 end2371)");
lf[138]=C_static_lambda_info(C_heaptop,33,"(a3069 g365367 start1368 end1369)");
lf[139]=C_static_lambda_info(C_heaptop,60,"(string-suffix-length-ci s1361 s2362 . maybe-starts+ends363)");
lf[140]=C_h_intern(&lf[140],14,"string-prefix\077");
lf[141]=C_static_lambda_info(C_heaptop,7,"(a3093)");
lf[142]=C_static_lambda_info(C_heaptop,7,"(a3105)");
lf[143]=C_static_lambda_info(C_heaptop,25,"(a3111 start2381 end2382)");
lf[144]=C_static_lambda_info(C_heaptop,33,"(a3099 g376378 start1379 end1380)");
lf[145]=C_static_lambda_info(C_heaptop,51,"(string-prefix\077 s1372 s2373 . maybe-starts+ends374)");
lf[146]=C_h_intern(&lf[146],14,"string-suffix\077");
lf[147]=C_static_lambda_info(C_heaptop,7,"(a3123)");
lf[148]=C_static_lambda_info(C_heaptop,7,"(a3135)");
lf[149]=C_static_lambda_info(C_heaptop,25,"(a3141 start2392 end2393)");
lf[150]=C_static_lambda_info(C_heaptop,33,"(a3129 g387389 start1390 end1391)");
lf[151]=C_static_lambda_info(C_heaptop,51,"(string-suffix\077 s1383 s2384 . maybe-starts+ends385)");
lf[152]=C_h_intern(&lf[152],17,"string-prefix-ci\077");
lf[153]=C_static_lambda_info(C_heaptop,7,"(a3153)");
lf[154]=C_static_lambda_info(C_heaptop,7,"(a3165)");
lf[155]=C_static_lambda_info(C_heaptop,25,"(a3171 start2403 end2404)");
lf[156]=C_static_lambda_info(C_heaptop,33,"(a3159 g398400 start1401 end1402)");
lf[157]=C_static_lambda_info(C_heaptop,54,"(string-prefix-ci\077 s1394 s2395 . maybe-starts+ends396)");
lf[158]=C_h_intern(&lf[158],17,"string-suffix-ci\077");
lf[159]=C_static_lambda_info(C_heaptop,7,"(a3183)");
lf[160]=C_static_lambda_info(C_heaptop,7,"(a3195)");
lf[161]=C_static_lambda_info(C_heaptop,25,"(a3201 start2414 end2415)");
lf[162]=C_static_lambda_info(C_heaptop,33,"(a3189 g409411 start1412 end1413)");
lf[163]=C_static_lambda_info(C_heaptop,54,"(string-suffix-ci\077 s1405 s2406 . maybe-starts+ends407)");
lf[165]=C_static_lambda_info(C_heaptop,92,"(%string-compare s1444 start1445 end1446 s2447 start2448 end2449 proc<450 proc=4"
"51 proc>452)");
lf[167]=C_h_intern(&lf[167],9,"char-ci<\077");
lf[168]=C_static_lambda_info(C_heaptop,95,"(%string-compare-ci s1456 start1457 end1458 s2459 start2460 end2461 proc<462 pro"
"c=463 proc>464)");
lf[169]=C_h_intern(&lf[169],14,"string-compare");
lf[170]=C_static_lambda_info(C_heaptop,7,"(a3429)");
lf[171]=C_static_lambda_info(C_heaptop,7,"(a3441)");
lf[172]=C_static_lambda_info(C_heaptop,25,"(a3447 start2480 end2481)");
lf[173]=C_static_lambda_info(C_heaptop,33,"(a3435 g475477 start1478 end1479)");
lf[174]=C_static_lambda_info(C_heaptop,78,"(string-compare s1468 s2469 proc<470 proc=471 proc>472 . maybe-starts+ends473)");
lf[175]=C_h_intern(&lf[175],17,"string-compare-ci");
lf[176]=C_static_lambda_info(C_heaptop,7,"(a3459)");
lf[177]=C_static_lambda_info(C_heaptop,7,"(a3471)");
lf[178]=C_static_lambda_info(C_heaptop,25,"(a3477 start2494 end2495)");
lf[179]=C_static_lambda_info(C_heaptop,33,"(a3465 g489491 start1492 end1493)");
lf[180]=C_static_lambda_info(C_heaptop,81,"(string-compare-ci s1482 s2483 proc<484 proc=485 proc>486 . maybe-starts+ends487"
")");
lf[181]=C_h_intern(&lf[181],7,"string=");
lf[182]=C_static_lambda_info(C_heaptop,7,"(a3489)");
lf[183]=C_static_lambda_info(C_heaptop,7,"(a3501)");
lf[184]=C_static_lambda_info(C_heaptop,12,"(a3525 i509)");
lf[185]=C_static_lambda_info(C_heaptop,12,"(a3528 i510)");
lf[186]=C_h_intern(&lf[186],6,"values");
lf[187]=C_static_lambda_info(C_heaptop,25,"(a3507 start2505 end2506)");
lf[188]=C_static_lambda_info(C_heaptop,33,"(a3495 g500502 start1503 end1504)");
lf[189]=C_static_lambda_info(C_heaptop,44,"(string= s1496 s2497 . maybe-starts+ends498)");
lf[190]=C_h_intern(&lf[190],8,"string<>");
lf[191]=C_static_lambda_info(C_heaptop,7,"(a3551)");
lf[192]=C_static_lambda_info(C_heaptop,7,"(a3563)");
lf[193]=C_static_lambda_info(C_heaptop,12,"(a3587 i524)");
lf[194]=C_static_lambda_info(C_heaptop,25,"(a3569 start2520 end2521)");
lf[195]=C_static_lambda_info(C_heaptop,33,"(a3557 g515517 start1518 end1519)");
lf[196]=C_static_lambda_info(C_heaptop,45,"(string<> s1511 s2512 . maybe-starts+ends513)");
lf[197]=C_h_intern(&lf[197],7,"string<");
lf[198]=C_static_lambda_info(C_heaptop,7,"(a3618)");
lf[199]=C_static_lambda_info(C_heaptop,7,"(a3630)");
lf[200]=C_static_lambda_info(C_heaptop,12,"(a3651 i536)");
lf[201]=C_static_lambda_info(C_heaptop,12,"(a3654 i537)");
lf[202]=C_static_lambda_info(C_heaptop,25,"(a3636 start2534 end2535)");
lf[203]=C_static_lambda_info(C_heaptop,33,"(a3624 g529531 start1532 end1533)");
lf[204]=C_static_lambda_info(C_heaptop,44,"(string< s1525 s2526 . maybe-starts+ends527)");
lf[205]=C_h_intern(&lf[205],7,"string>");
lf[206]=C_static_lambda_info(C_heaptop,7,"(a3669)");
lf[207]=C_static_lambda_info(C_heaptop,7,"(a3681)");
lf[208]=C_static_lambda_info(C_heaptop,12,"(a3702 i549)");
lf[209]=C_static_lambda_info(C_heaptop,12,"(a3705 i550)");
lf[210]=C_static_lambda_info(C_heaptop,25,"(a3687 start2547 end2548)");
lf[211]=C_static_lambda_info(C_heaptop,33,"(a3675 g542544 start1545 end1546)");
lf[212]=C_static_lambda_info(C_heaptop,44,"(string> s1538 s2539 . maybe-starts+ends540)");
lf[213]=C_h_intern(&lf[213],8,"string<=");
lf[214]=C_static_lambda_info(C_heaptop,7,"(a3720)");
lf[215]=C_static_lambda_info(C_heaptop,7,"(a3732)");
lf[216]=C_static_lambda_info(C_heaptop,12,"(a3753 i562)");
lf[217]=C_static_lambda_info(C_heaptop,25,"(a3738 start2560 end2561)");
lf[218]=C_static_lambda_info(C_heaptop,33,"(a3726 g555557 start1558 end1559)");
lf[219]=C_static_lambda_info(C_heaptop,45,"(string<= s1551 s2552 . maybe-starts+ends553)");
lf[220]=C_h_intern(&lf[220],8,"string>=");
lf[221]=C_static_lambda_info(C_heaptop,7,"(a3768)");
lf[222]=C_static_lambda_info(C_heaptop,7,"(a3780)");
lf[223]=C_static_lambda_info(C_heaptop,12,"(a3801 i574)");
lf[224]=C_static_lambda_info(C_heaptop,25,"(a3786 start2572 end2573)");
lf[225]=C_static_lambda_info(C_heaptop,33,"(a3774 g567569 start1570 end1571)");
lf[226]=C_static_lambda_info(C_heaptop,45,"(string>= s1563 s2564 . maybe-starts+ends565)");
lf[227]=C_h_intern(&lf[227],10,"string-ci=");
lf[228]=C_static_lambda_info(C_heaptop,7,"(a3816)");
lf[229]=C_static_lambda_info(C_heaptop,7,"(a3828)");
lf[230]=C_static_lambda_info(C_heaptop,12,"(a3852 i588)");
lf[231]=C_static_lambda_info(C_heaptop,12,"(a3855 i589)");
lf[232]=C_static_lambda_info(C_heaptop,25,"(a3834 start2584 end2585)");
lf[233]=C_static_lambda_info(C_heaptop,33,"(a3822 g579581 start1582 end1583)");
lf[234]=C_static_lambda_info(C_heaptop,47,"(string-ci= s1575 s2576 . maybe-starts+ends577)");
lf[235]=C_h_intern(&lf[235],11,"string-ci<>");
lf[236]=C_static_lambda_info(C_heaptop,7,"(a3878)");
lf[237]=C_static_lambda_info(C_heaptop,7,"(a3890)");
lf[238]=C_static_lambda_info(C_heaptop,12,"(a3914 i603)");
lf[239]=C_static_lambda_info(C_heaptop,25,"(a3896 start2599 end2600)");
lf[240]=C_static_lambda_info(C_heaptop,33,"(a3884 g594596 start1597 end1598)");
lf[241]=C_static_lambda_info(C_heaptop,48,"(string-ci<> s1590 s2591 . maybe-starts+ends592)");
lf[242]=C_h_intern(&lf[242],10,"string-ci<");
lf[243]=C_static_lambda_info(C_heaptop,7,"(a3945)");
lf[244]=C_static_lambda_info(C_heaptop,7,"(a3957)");
lf[245]=C_static_lambda_info(C_heaptop,12,"(a3978 i615)");
lf[246]=C_static_lambda_info(C_heaptop,12,"(a3981 i616)");
lf[247]=C_static_lambda_info(C_heaptop,25,"(a3963 start2613 end2614)");
lf[248]=C_static_lambda_info(C_heaptop,33,"(a3951 g608610 start1611 end1612)");
lf[249]=C_static_lambda_info(C_heaptop,47,"(string-ci< s1604 s2605 . maybe-starts+ends606)");
lf[250]=C_h_intern(&lf[250],10,"string-ci>");
lf[251]=C_static_lambda_info(C_heaptop,7,"(a3996)");
lf[252]=C_static_lambda_info(C_heaptop,7,"(a4008)");
lf[253]=C_static_lambda_info(C_heaptop,12,"(a4029 i628)");
lf[254]=C_static_lambda_info(C_heaptop,12,"(a4032 i629)");
lf[255]=C_static_lambda_info(C_heaptop,25,"(a4014 start2626 end2627)");
lf[256]=C_static_lambda_info(C_heaptop,33,"(a4002 g621623 start1624 end1625)");
lf[257]=C_static_lambda_info(C_heaptop,47,"(string-ci> s1617 s2618 . maybe-starts+ends619)");
lf[258]=C_h_intern(&lf[258],11,"string-ci<=");
lf[259]=C_static_lambda_info(C_heaptop,7,"(a4047)");
lf[260]=C_static_lambda_info(C_heaptop,7,"(a4059)");
lf[261]=C_static_lambda_info(C_heaptop,12,"(a4080 i641)");
lf[262]=C_static_lambda_info(C_heaptop,25,"(a4065 start2639 end2640)");
lf[263]=C_static_lambda_info(C_heaptop,33,"(a4053 g634636 start1637 end1638)");
lf[264]=C_static_lambda_info(C_heaptop,48,"(string-ci<= s1630 s2631 . maybe-starts+ends632)");
lf[265]=C_h_intern(&lf[265],11,"string-ci>=");
lf[266]=C_static_lambda_info(C_heaptop,7,"(a4095)");
lf[267]=C_static_lambda_info(C_heaptop,7,"(a4107)");
lf[268]=C_static_lambda_info(C_heaptop,12,"(a4128 i653)");
lf[269]=C_static_lambda_info(C_heaptop,25,"(a4113 start2651 end2652)");
lf[270]=C_static_lambda_info(C_heaptop,33,"(a4101 g646648 start1649 end1650)");
lf[271]=C_static_lambda_info(C_heaptop,48,"(string-ci>= s1642 s2643 . maybe-starts+ends644)");
lf[273]=C_static_lambda_info(C_heaptop,16,"(iref s661 i662)");
lf[274]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[275]=C_h_intern(&lf[275],6,"modulo");
lf[276]=C_static_lambda_info(C_heaptop,16,"(lp i667 ans668)");
lf[277]=C_static_lambda_info(C_heaptop,57,"(%string-hash s654 char->int655 bound656 start657 end658)");
lf[278]=C_h_intern(&lf[278],11,"string-hash");
lf[279]=C_static_lambda_info(C_heaptop,7,"(a4227)");
lf[280]=C_h_intern(&lf[280],13,"char->integer");
lf[281]=C_static_lambda_info(C_heaptop,23,"(a4233 start678 end679)");
lf[282]=C_static_lambda_info(C_heaptop,45,"(string-hash s670 . maybe-bound+start+end671)");
lf[283]=C_h_intern(&lf[283],14,"string-hash-ci");
lf[284]=C_static_lambda_info(C_heaptop,7,"(a4273)");
lf[285]=C_static_lambda_info(C_heaptop,12,"(a4285 c692)");
lf[286]=C_static_lambda_info(C_heaptop,23,"(a4279 start690 end691)");
lf[287]=C_static_lambda_info(C_heaptop,48,"(string-hash-ci s682 . maybe-bound+start+end683)");
lf[288]=C_h_intern(&lf[288],13,"string-upcase");
lf[289]=C_static_lambda_info(C_heaptop,7,"(a4317)");
lf[290]=C_h_intern(&lf[290],11,"char-upcase");
lf[291]=C_static_lambda_info(C_heaptop,23,"(a4323 start697 end698)");
lf[292]=C_static_lambda_info(C_heaptop,41,"(string-upcase s695 . maybe-start+end696)");
lf[293]=C_h_intern(&lf[293],14,"string-upcase!");
lf[294]=C_static_lambda_info(C_heaptop,7,"(a4335)");
lf[295]=C_static_lambda_info(C_heaptop,23,"(a4341 start701 end702)");
lf[296]=C_static_lambda_info(C_heaptop,42,"(string-upcase! s699 . maybe-start+end700)");
lf[297]=C_h_intern(&lf[297],15,"string-downcase");
lf[298]=C_static_lambda_info(C_heaptop,7,"(a4353)");
lf[299]=C_h_intern(&lf[299],13,"char-downcase");
lf[300]=C_static_lambda_info(C_heaptop,23,"(a4359 start705 end706)");
lf[301]=C_static_lambda_info(C_heaptop,43,"(string-downcase s703 . maybe-start+end704)");
lf[302]=C_h_intern(&lf[302],16,"string-downcase!");
lf[303]=C_static_lambda_info(C_heaptop,7,"(a4371)");
lf[304]=C_static_lambda_info(C_heaptop,23,"(a4377 start709 end710)");
lf[305]=C_static_lambda_info(C_heaptop,44,"(string-downcase! s707 . maybe-start+end708)");
lf[307]=C_static_lambda_info(C_heaptop,13,"(a4423 c2724)");
lf[308]=C_h_intern(&lf[308],11,"string-skip");
lf[309]=C_static_lambda_info(C_heaptop,13,"(a4436 c2718)");
lf[310]=C_h_intern(&lf[310],12,"string-index");
lf[311]=C_static_lambda_info(C_heaptop,9,"(lp i715)");
lf[312]=C_static_lambda_info(C_heaptop,41,"(%string-titlecase! s711 start712 end713)");
lf[313]=C_h_intern(&lf[313],17,"string-titlecase!");
lf[314]=C_static_lambda_info(C_heaptop,7,"(a4448)");
lf[315]=C_static_lambda_info(C_heaptop,23,"(a4454 start731 end732)");
lf[316]=C_static_lambda_info(C_heaptop,45,"(string-titlecase! s729 . maybe-start+end730)");
lf[317]=C_h_intern(&lf[317],16,"string-titlecase");
lf[318]=C_static_lambda_info(C_heaptop,7,"(a4466)");
lf[319]=C_static_lambda_info(C_heaptop,23,"(a4472 start735 end736)");
lf[320]=C_static_lambda_info(C_heaptop,44,"(string-titlecase s733 . maybe-start+end734)");
lf[321]=C_h_intern(&lf[321],11,"string-take");
lf[322]=C_static_lambda_info(C_heaptop,23,"(string-take s739 n740)");
lf[323]=C_h_intern(&lf[323],17,"string-take-right");
lf[324]=C_static_lambda_info(C_heaptop,29,"(string-take-right s742 n743)");
lf[325]=C_h_intern(&lf[325],11,"string-drop");
lf[326]=C_static_lambda_info(C_heaptop,23,"(string-drop s746 n747)");
lf[327]=C_h_intern(&lf[327],17,"string-drop-right");
lf[328]=C_static_lambda_info(C_heaptop,29,"(string-drop-right s750 n751)");
lf[329]=C_h_intern(&lf[329],11,"string-trim");
lf[330]=C_h_intern(&lf[330],19,"char-set:whitespace");
lf[331]=C_static_lambda_info(C_heaptop,7,"(a4550)");
lf[332]=C_static_string(C_heaptop,0,"");
lf[333]=C_static_lambda_info(C_heaptop,23,"(a4556 start762 end763)");
lf[334]=C_static_lambda_info(C_heaptop,42,"(string-trim s754 . criteria+start+end755)");
lf[335]=C_h_intern(&lf[335],17,"string-trim-right");
lf[336]=C_static_lambda_info(C_heaptop,7,"(a4592)");
lf[337]=C_static_string(C_heaptop,0,"");
lf[338]=C_h_intern(&lf[338],17,"string-skip-right");
lf[339]=C_static_lambda_info(C_heaptop,23,"(a4598 start775 end776)");
lf[340]=C_static_lambda_info(C_heaptop,48,"(string-trim-right s767 . criteria+start+end768)");
lf[341]=C_h_intern(&lf[341],16,"string-trim-both");
lf[342]=C_static_lambda_info(C_heaptop,7,"(a4638)");
lf[343]=C_static_string(C_heaptop,0,"");
lf[344]=C_static_lambda_info(C_heaptop,23,"(a4644 start788 end789)");
lf[345]=C_static_lambda_info(C_heaptop,47,"(string-trim-both s780 . criteria+start+end781)");
lf[346]=C_h_intern(&lf[346],16,"string-pad-right");
lf[347]=C_static_lambda_info(C_heaptop,7,"(a4691)");
lf[348]=C_static_lambda_info(C_heaptop,23,"(a4697 start802 end803)");
lf[349]=C_static_lambda_info(C_heaptop,48,"(string-pad-right s793 n794 . char+start+end795)");
lf[350]=C_h_intern(&lf[350],10,"string-pad");
lf[351]=C_static_lambda_info(C_heaptop,7,"(a4749)");
lf[352]=C_static_lambda_info(C_heaptop,23,"(a4755 start817 end818)");
lf[353]=C_static_lambda_info(C_heaptop,42,"(string-pad s808 n809 . char+start+end810)");
lf[354]=C_h_intern(&lf[354],13,"string-delete");
lf[355]=C_static_lambda_info(C_heaptop,7,"(a4802)");
lf[356]=C_static_lambda_info(C_heaptop,17,"(a4835 c831 i832)");
lf[357]=C_static_lambda_info(C_heaptop,17,"(a4862 c839 i840)");
lf[358]=C_static_lambda_info(C_heaptop,17,"(a4877 c836 i837)");
lf[359]=C_h_intern(&lf[359],8,"char-set");
lf[360]=C_static_string(C_heaptop,54,"string-delete criteria not predicate, char or char-set");
lf[361]=C_static_lambda_info(C_heaptop,23,"(a4808 start826 end827)");
lf[362]=C_static_lambda_info(C_heaptop,53,"(string-delete criteria823 s824 . maybe-start+end825)");
lf[363]=C_h_intern(&lf[363],13,"string-filter");
lf[364]=C_static_lambda_info(C_heaptop,7,"(a4910)");
lf[365]=C_static_lambda_info(C_heaptop,17,"(a4943 c851 i852)");
lf[366]=C_static_lambda_info(C_heaptop,17,"(a4970 c859 i860)");
lf[367]=C_static_lambda_info(C_heaptop,17,"(a4985 c856 i857)");
lf[368]=C_static_string(C_heaptop,54,"string-delete criteria not predicate, char or char-set");
lf[369]=C_static_lambda_info(C_heaptop,23,"(a4916 start846 end847)");
lf[370]=C_static_lambda_info(C_heaptop,53,"(string-filter criteria843 s844 . maybe-start+end845)");
lf[371]=C_static_lambda_info(C_heaptop,7,"(a5018)");
lf[372]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[373]=C_static_lambda_info(C_heaptop,9,"(lp i872)");
lf[374]=C_static_lambda_info(C_heaptop,9,"(lp i875)");
lf[375]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[376]=C_static_lambda_info(C_heaptop,23,"(a5024 start866 end867)");
lf[377]=C_static_lambda_info(C_heaptop,54,"(string-index str863 criteria864 . maybe-start+end865)");
lf[378]=C_h_intern(&lf[378],18,"string-index-right");
lf[379]=C_static_lambda_info(C_heaptop,7,"(a5141)");
lf[380]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[381]=C_static_lambda_info(C_heaptop,9,"(lp i886)");
lf[382]=C_static_lambda_info(C_heaptop,9,"(lp i889)");
lf[383]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[384]=C_static_lambda_info(C_heaptop,23,"(a5147 start880 end881)");
lf[385]=C_static_lambda_info(C_heaptop,60,"(string-index-right str877 criteria878 . maybe-start+end879)");
lf[386]=C_static_lambda_info(C_heaptop,7,"(a5276)");
lf[387]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[388]=C_static_lambda_info(C_heaptop,9,"(lp i900)");
lf[389]=C_static_lambda_info(C_heaptop,9,"(lp i903)");
lf[390]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[391]=C_static_lambda_info(C_heaptop,23,"(a5282 start894 end895)");
lf[392]=C_static_lambda_info(C_heaptop,53,"(string-skip str891 criteria892 . maybe-start+end893)");
lf[393]=C_static_lambda_info(C_heaptop,7,"(a5399)");
lf[394]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[395]=C_static_lambda_info(C_heaptop,9,"(lp i914)");
lf[396]=C_static_lambda_info(C_heaptop,9,"(lp i917)");
lf[397]=C_static_string(C_heaptop,43,"CRITERIA param is neither char-set or char.");
lf[398]=C_static_lambda_info(C_heaptop,23,"(a5405 start908 end909)");
lf[399]=C_static_lambda_info(C_heaptop,59,"(string-skip-right str905 criteria906 . maybe-start+end907)");
lf[400]=C_h_intern(&lf[400],12,"string-count");
lf[401]=C_static_lambda_info(C_heaptop,7,"(a5534)");
lf[402]=C_static_lambda_info(C_heaptop,16,"(do924 count927)");
lf[403]=C_static_lambda_info(C_heaptop,21,"(do929 i931 count932)");
lf[404]=C_static_lambda_info(C_heaptop,21,"(do934 i936 count937)");
lf[405]=C_static_string(C_heaptop,43,"CRITERIA param is neither char-set or char.");
lf[406]=C_static_lambda_info(C_heaptop,23,"(a5540 start922 end923)");
lf[407]=C_static_lambda_info(C_heaptop,52,"(string-count s919 criteria920 . maybe-start+end921)");
lf[408]=C_h_intern(&lf[408],12,"string-fill!");
lf[409]=C_static_lambda_info(C_heaptop,7,"(a5669)");
lf[410]=C_static_lambda_info(C_heaptop,7,"(do944)");
lf[411]=C_static_lambda_info(C_heaptop,23,"(a5675 start942 end943)");
lf[412]=C_static_lambda_info(C_heaptop,48,"(string-fill! s939 char940 . maybe-start+end941)");
lf[413]=C_h_intern(&lf[413],12,"string-copy!");
lf[414]=C_static_lambda_info(C_heaptop,7,"(a5710)");
lf[415]=C_static_lambda_info(C_heaptop,25,"(a5716 fstart953 fend954)");
lf[416]=C_static_lambda_info(C_heaptop,61,"(string-copy! to949 tstart950 from951 . maybe-fstart+fend952)");
lf[417]=C_static_lambda_info(C_heaptop,12,"(do962 j965)");
lf[418]=C_static_lambda_info(C_heaptop,12,"(do968 j971)");
lf[419]=C_static_lambda_info(C_heaptop,57,"(%string-copy! to957 tstart958 from959 fstart960 fend961)");
lf[420]=C_h_intern(&lf[420],15,"string-contains");
lf[421]=C_static_lambda_info(C_heaptop,7,"(a5823)");
lf[422]=C_static_lambda_info(C_heaptop,7,"(a5835)");
lf[423]=C_static_lambda_info(C_heaptop,9,"(lp i988)");
lf[424]=C_static_lambda_info(C_heaptop,25,"(a5841 start2983 end2984)");
lf[425]=C_static_lambda_info(C_heaptop,33,"(a5829 g978980 start1981 end1982)");
lf[426]=C_static_lambda_info(C_heaptop,63,"(string-contains string974 substring975 . maybe-starts+ends976)");
lf[427]=C_h_intern(&lf[427],18,"string-contains-ci");
lf[428]=C_static_lambda_info(C_heaptop,7,"(a5885)");
lf[429]=C_static_lambda_info(C_heaptop,7,"(a5897)");
lf[430]=C_static_lambda_info(C_heaptop,10,"(lp i1004)");
lf[431]=C_static_lambda_info(C_heaptop,26,"(a5903 start2999 end21000)");
lf[432]=C_static_lambda_info(C_heaptop,33,"(a5891 g994996 start1997 end1998)");
lf[433]=C_static_lambda_info(C_heaptop,66,"(string-contains-ci string990 substring991 . maybe-starts+ends992)");
lf[435]=C_static_lambda_info(C_heaptop,32,"(lp ti1016 pi1017 tj1018 pj1019)");
lf[436]=C_h_intern(&lf[436],23,"make-kmp-restart-vector");
lf[437]=C_static_lambda_info(C_heaptop,85,"(%kmp-search pattern1006 text1007 c=1008 p-start1009 p-end1010 t-start1011 t-end"
"1012)");
lf[438]=C_h_intern(&lf[438],6,"char=\077");
lf[439]=C_static_lambda_info(C_heaptop,7,"(a6051)");
lf[440]=C_static_lambda_info(C_heaptop,11,"(lp2 j1043)");
lf[441]=C_static_lambda_info(C_heaptop,23,"(lp1 i1038 j1039 k1040)");
lf[442]=C_h_intern(&lf[442],11,"make-vector");
lf[443]=C_static_lambda_info(C_heaptop,35,"(a6057 rest21030 start1031 end1032)");
lf[444]=C_static_lambda_info(C_heaptop,62,"(make-kmp-restart-vector pattern1022 . maybe-c=+start+end1023)");
lf[445]=C_h_intern(&lf[445],8,"kmp-step");
lf[446]=C_static_lambda_info(C_heaptop,10,"(lp i1059)");
lf[447]=C_static_lambda_info(C_heaptop,56,"(kmp-step pat1052 rv1053 c1054 i1055 c=1056 p-start1057)");
lf[448]=C_h_intern(&lf[448],25,"string-kmp-partial-search");
lf[449]=C_static_lambda_info(C_heaptop,7,"(a6230)");
lf[450]=C_static_lambda_info(C_heaptop,12,"(lp2 vi1085)");
lf[451]=C_static_lambda_info(C_heaptop,18,"(lp si1081 vi1082)");
lf[452]=C_static_lambda_info(C_heaptop,39,"(a6236 rest21076 s-start1077 s-end1078)");
lf[453]=C_static_lambda_info(C_heaptop,85,"(string-kmp-partial-search pat1062 rv1063 s1064 i1065 . c=+p-start+s-start+s-end"
"1066)");
lf[454]=C_h_intern(&lf[454],12,"string-null\077");
lf[455]=C_static_lambda_info(C_heaptop,20,"(string-null\077 s1089)");
lf[456]=C_h_intern(&lf[456],14,"string-reverse");
lf[457]=C_static_lambda_info(C_heaptop,7,"(a6342)");
lf[458]=C_static_lambda_info(C_heaptop,14,"(do1096 j1099)");
lf[459]=C_static_lambda_info(C_heaptop,25,"(a6348 start1092 end1093)");
lf[460]=C_static_lambda_info(C_heaptop,44,"(string-reverse s1090 . maybe-start+end1091)");
lf[461]=C_h_intern(&lf[461],15,"string-reverse!");
lf[462]=C_static_lambda_info(C_heaptop,7,"(a6397)");
lf[463]=C_static_lambda_info(C_heaptop,14,"(do1107 j1110)");
lf[464]=C_static_lambda_info(C_heaptop,25,"(a6403 start1105 end1106)");
lf[465]=C_static_lambda_info(C_heaptop,45,"(string-reverse! s1103 . maybe-start+end1104)");
lf[466]=C_h_intern(&lf[466],12,"string->list");
lf[467]=C_static_lambda_info(C_heaptop,7,"(a6452)");
lf[468]=C_static_lambda_info(C_heaptop,22,"(do1119 i1121 ans1122)");
lf[469]=C_static_lambda_info(C_heaptop,25,"(a6458 start1117 end1118)");
lf[470]=C_static_lambda_info(C_heaptop,42,"(string->list s1115 . maybe-start+end1116)");
lf[471]=C_h_intern(&lf[471],20,"string-append/shared");
lf[472]=C_h_intern(&lf[472],25,"string-concatenate/shared");
lf[473]=C_static_lambda_info(C_heaptop,36,"(string-append/shared . strings1124)");
lf[474]=C_static_string(C_heaptop,0,"");
lf[475]=C_static_lambda_info(C_heaptop,22,"(lp strings1137 i1138)");
lf[476]=C_static_lambda_info(C_heaptop,37,"(lp strings1127 nchars1128 first1129)");
lf[477]=C_static_lambda_info(C_heaptop,39,"(string-concatenate/shared strings1125)");
lf[478]=C_h_intern(&lf[478],18,"string-concatenate");
lf[479]=C_static_lambda_info(C_heaptop,14,"(do1147 i1150)");
lf[480]=C_static_lambda_info(C_heaptop,22,"(lp i1154 strings1155)");
lf[481]=C_static_lambda_info(C_heaptop,32,"(string-concatenate strings1145)");
lf[482]=C_h_intern(&lf[482],26,"string-concatenate-reverse");
lf[483]=C_static_string(C_heaptop,0,"");
lf[484]=C_static_lambda_info(C_heaptop,12,"(lp lis1174)");
lf[486]=C_static_lambda_info(C_heaptop,66,"(string-concatenate-reverse string-list1161 . maybe-final+end1162)");
lf[487]=C_h_intern(&lf[487],33,"string-concatenate-reverse/shared");
lf[488]=C_static_string(C_heaptop,0,"");
lf[489]=C_static_lambda_info(C_heaptop,31,"(lp len1188 nzlist1189 lis1190)");
lf[490]=C_static_lambda_info(C_heaptop,73,"(string-concatenate-reverse/shared string-list1177 . maybe-final+end1178)");
lf[491]=C_static_lambda_info(C_heaptop,18,"(lp i1202 lis1203)");
lf[492]=C_static_lambda_info(C_heaptop,78,"(%finish-string-concatenate-reverse len1196 string-list1197 final1198 end1199)");
lf[493]=C_h_intern(&lf[493],14,"string-replace");
lf[494]=C_static_lambda_info(C_heaptop,7,"(a6942)");
lf[495]=C_static_lambda_info(C_heaptop,27,"(a6948 start21217 end21218)");
lf[496]=C_static_lambda_info(C_heaptop,72,"(string-replace s11212 s21213 start11214 end11215 . maybe-start+end1216)");
lf[497]=C_h_intern(&lf[497],15,"string-tokenize");
lf[498]=C_h_intern(&lf[498],16,"char-set:graphic");
lf[499]=C_static_lambda_info(C_heaptop,7,"(a6996)");
lf[500]=C_static_lambda_info(C_heaptop,18,"(lp i1238 ans1239)");
lf[501]=C_static_lambda_info(C_heaptop,25,"(a7002 start1235 end1236)");
lf[502]=C_static_lambda_info(C_heaptop,51,"(string-tokenize s1227 . token-chars+start+end1228)");
lf[503]=C_h_intern(&lf[503],10,"xsubstring");
lf[504]=C_static_lambda_info(C_heaptop,7,"(a7087)");
lf[505]=C_static_lambda_info(C_heaptop,25,"(a7097 start1251 end1252)");
lf[506]=C_static_lambda_info(C_heaptop,7,"(a7075)");
lf[507]=C_static_string(C_heaptop,0,"");
lf[508]=C_static_string(C_heaptop,34,"Cannot replicate empty (sub)string");
lf[510]=C_h_intern(&lf[510],5,"floor");
lf[511]=C_static_lambda_info(C_heaptop,32,"(a7119 to1256 start1257 end1258)");
lf[512]=C_static_lambda_info(C_heaptop,52,"(xsubstring s1248 from1249 . maybe-to+start+end1250)");
lf[514]=C_h_intern(&lf[514],13,"string-xcopy!");
lf[515]=C_static_lambda_info(C_heaptop,7,"(a7225)");
lf[516]=C_static_lambda_info(C_heaptop,25,"(a7235 start1269 end1270)");
lf[517]=C_static_lambda_info(C_heaptop,7,"(a7213)");
lf[518]=C_static_string(C_heaptop,34,"Cannot replicate empty (sub)string");
lf[519]=C_static_lambda_info(C_heaptop,33,"(a7257 sto1274 start1275 end1276)");
lf[520]=C_static_lambda_info(C_heaptop,79,"(string-xcopy! target1264 tstart1265 s1266 sfrom1267 . maybe-sto+start+end1268)");
lf[521]=C_static_lambda_info(C_heaptop,25,"(do1297 i1299 nspans1300)");
lf[522]=C_static_lambda_info(C_heaptop,85,"(%multispan-repcopy! target1284 tstart1285 s1286 sfrom1287 sto1288 start1289 end"
"1290)");
lf[523]=C_h_intern(&lf[523],11,"string-join");
lf[524]=C_static_string(C_heaptop,1," ");
lf[525]=C_h_intern(&lf[525],5,"infix");
lf[526]=C_static_lambda_info(C_heaptop,15,"(recur lis1318)");
lf[527]=C_static_lambda_info(C_heaptop,27,"(buildit lis1315 final1316)");
lf[528]=C_h_intern(&lf[528],12,"strict-infix");
lf[529]=C_h_intern(&lf[529],6,"prefix");
lf[530]=C_h_intern(&lf[530],6,"suffix");
lf[531]=C_static_string(C_heaptop,20,"Illegal join grammar");
lf[532]=C_static_string(C_heaptop,54,"Empty list cannot be joined with STRICT-INFIX grammar.");
lf[533]=C_static_string(C_heaptop,0,"");
lf[534]=C_static_string(C_heaptop,27,"STRINGS parameter not list.");
lf[535]=C_static_lambda_info(C_heaptop,45,"(string-join strings1304 . delim+grammar1305)");
lf[536]=C_h_intern(&lf[536],17,"register-feature!");
lf[537]=C_h_intern(&lf[537],7,"srfi-13");
lf[538]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,539);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1435 */
static void f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 55   register-feature! */
t3=*((C_word*)lf[536]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[537]);}

/* k1438 in k1435 */
static void f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word ab[297],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=lf[9],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=lf[14],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1562,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=lf[22],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=lf[24],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=lf[28],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=lf[33],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[31],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=lf[36],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[39],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1816,a[2]=lf[48],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=lf[63],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=lf[76],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2316,a[2]=lf[81],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=lf[91],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate(&lf[103],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate(&lf[106],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate(&lf[113],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=lf[115],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=lf[121],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=lf[133],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=lf[139],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=lf[145],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=lf[151],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[164],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3300,a[2]=lf[165],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate(&lf[166],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=lf[168],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=lf[174],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=lf[180],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=lf[189],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=lf[196],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=lf[204],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=lf[212],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=lf[219],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=lf[226],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=lf[234],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3940,a[2]=lf[249],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3991,a[2]=lf[257],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=lf[264],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=lf[271],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate(&lf[272],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4138,a[2]=lf[277],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=lf[282],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=lf[287],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=lf[292],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=lf[296],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4348,a[2]=lf[301],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4366,a[2]=lf[305],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[306],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4384,a[2]=lf[312],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4443,a[2]=lf[316],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=lf[320],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=lf[322],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4495,a[2]=lf[324],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4511,a[2]=lf[326],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=lf[328],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=lf[334],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4581,a[2]=lf[340],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4627,a[2]=lf[345],tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4677,a[2]=lf[349],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[350]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4735,a[2]=lf[353],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=lf[362],tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4905,a[2]=lf[370],tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5013,a[2]=lf[377],tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=lf[385],tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5271,a[2]=lf[392],tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=lf[399],tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[400]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5529,a[2]=lf[407],tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[408]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5664,a[2]=lf[412],tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=lf[416],tmp=(C_word)a,a+=3,tmp));
t78=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5737,a[2]=lf[419],tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=lf[426],tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[427]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5880,a[2]=lf[433],tmp=(C_word)a,a+=3,tmp));
t81=C_mutate(&lf[434],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5942,a[2]=lf[437],tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[436]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6040,a[2]=lf[444],tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[445]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6175,a[2]=lf[447],tmp=(C_word)a,a+=3,tmp));
t84=C_mutate((C_word*)lf[448]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6213,a[2]=lf[453],tmp=(C_word)a,a+=3,tmp));
t85=C_mutate((C_word*)lf[454]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6334,a[2]=lf[455],tmp=(C_word)a,a+=3,tmp));
t86=C_mutate((C_word*)lf[456]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6337,a[2]=lf[460],tmp=(C_word)a,a+=3,tmp));
t87=C_mutate((C_word*)lf[461]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6392,a[2]=lf[465],tmp=(C_word)a,a+=3,tmp));
t88=C_mutate((C_word*)lf[466]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=lf[470],tmp=(C_word)a,a+=3,tmp));
t89=C_mutate((C_word*)lf[471]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6493,a[2]=lf[473],tmp=(C_word)a,a+=3,tmp));
t90=C_mutate((C_word*)lf[472]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=lf[477],tmp=(C_word)a,a+=3,tmp));
t91=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6601,a[2]=lf[481],tmp=(C_word)a,a+=3,tmp));
t92=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6674,a[2]=lf[486],tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[487]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=lf[490],tmp=(C_word)a,a+=3,tmp));
t94=C_mutate(&lf[485],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6891,a[2]=lf[492],tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[493]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6934,a[2]=lf[496],tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[497]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6985,a[2]=lf[502],tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[503]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=lf[512],tmp=(C_word)a,a+=3,tmp));
t98=C_mutate(&lf[513],*((C_word*)lf[408]+1));
t99=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=lf[520],tmp=(C_word)a,a+=3,tmp));
t100=C_mutate(&lf[509],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7345,a[2]=lf[522],tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7418,a[2]=lf[535],tmp=(C_word)a,a+=3,tmp));
t102=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t102+1)))(2,t102,C_SCHEME_UNDEFINED);}

/* string-join in k1438 in k1435 */
static void f_7418(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7418r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7418r(t0,t1,t2,t3);}}

static void f_7418r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(18);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[524]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?lf[525]:(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7438,a[2]=t5,a[3]=lf[527],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7483,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t9,lf[525]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[528]));
if(C_truep(t15)){
t16=(C_word)C_i_car(t2);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7500,a[2]=t16,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_i_cdr(t2);
/* srfi-13.scm: 1924 buildit */
t19=t12;
f_7438(t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t9,lf[529]);
if(C_truep(t16)){
/* srfi-13.scm: 1926 buildit */
t17=t12;
f_7438(t17,t13,t2,C_SCHEME_END_OF_LIST);}
else{
t17=(C_word)C_eqp(t9,lf[530]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t2);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t2);
t21=(C_word)C_a_i_list(&a,1,t5);
/* srfi-13.scm: 1929 buildit */
t22=t12;
f_7438(t22,t19,t20,t21);}
else{
/* srfi-13.scm: 1931 ##sys#error */
t18=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t13,lf[523],lf[531],t9,*((C_word*)lf[523]+1));}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t13=(C_word)C_eqp(t9,lf[528]);
if(C_truep(t13)){
/* srfi-13.scm: 1940 ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[523],lf[532],*((C_word*)lf[523]+1));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[533]);}}
else{
/* srfi-13.scm: 1935 ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t1,lf[523],lf[534],t2,*((C_word*)lf[523]+1));}}}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* k7528 in string-join in k1438 in k1435 */
static void f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7483(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7498 in string-join in k1438 in k1435 */
static void f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7500,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7483(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7481 in string-join in k1438 in k1435 */
static void f_7483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1920 string-concatenate */
t2=*((C_word*)lf[478]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* buildit in string-join in k1438 in k1435 */
static void C_fcall f_7438(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7438,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7444,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=lf[526],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7444(t7,t1,t2);}

/* recur in buildit in string-join in k1438 in k1435 */
static void C_fcall f_7444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7444,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(t2);
/* srfi-13.scm: 1916 recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k7464 in recur in buildit in string-join in k1438 in k1435 */
static void f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* %multispan-repcopy! in k1438 in k1435 */
static void C_fcall f_7345(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7345,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_fixnum_difference(t8,t7);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7416,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,a[6]=t9,a[7]=t8,a[8]=t5,a[9]=t6,a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1875 modulo */
t11=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t9);}

/* k7414 in %multispan-repcopy! in k1438 in k1435 */
static void f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7416,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1879 %string-copy! */
f_5737(t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t2,((C_word*)t0)[7]);}

/* k7356 in k7414 in %multispan-repcopy! in k1438 in k1435 */
static void f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7358,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
t4=(C_word)C_fixnum_divide(t3,((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7376,a[2]=((C_word*)t0)[10],a[3]=t7,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=lf[521],tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_7376(t9,((C_word*)t0)[2],t5,t4);}

/* do1297 in k7356 in k7414 in %multispan-repcopy! in k1438 in k1435 */
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7376,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_fixnum_difference(t2,((C_word*)t0)[9]);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[8],t5);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[7],t6);
/* srfi-13.scm: 1890 %string-copy! */
f_5737(t1,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[7],t7);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7401,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1892 %string-copy! */
f_5737(t5,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k7399 in do1297 in k7356 in k7414 in %multispan-repcopy! in k1438 in k1435 */
static void f_7401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7376(t4,((C_word*)t0)[2],t2,t3);}

/* string-xcopy! in k1438 in k1435 */
static void f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr6r,(void*)f_7205r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_7205r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_7205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t7=(C_word)C_i_check_exact_2(t5,lf[514]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7214,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=lf[517],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7258,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t5,a[6]=lf[519],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1839 ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a7257 in string-xcopy! in k1438 in k1435 */
static void f_7258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7258,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t2,((C_word*)t0)[5]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[4],t5);
t7=(C_word)C_fixnum_difference(t4,t3);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7271,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[3],a[10]=t7,a[11]=t1,a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 1853 check-substring-spec */
t9=*((C_word*)lf[17]+1);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,*((C_word*)lf[514]+1),((C_word*)t0)[3],((C_word*)t0)[4],t6);}

/* k7269 in a7257 in string-xcopy! in k1438 in k1435 */
static void f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7271,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[12],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
/* srfi-13.scm: 1855 ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc12)(void*)(*((C_word*)t4+1)))(12,t4,((C_word*)t0)[11],lf[514],lf[518],*((C_word*)lf[514]+1),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(C_fix(1),((C_word*)t0)[10]);
if(C_truep(t4)){
t5=(C_word)C_i_string_ref(((C_word*)t0)[7],((C_word*)t0)[4]);
/* srfi-13.scm: 1860 ##srfi13#string-fill! */
t6=lf[513];
((C_proc6)C_retrieve_proc(t6))(6,t6,((C_word*)t0)[11],((C_word*)t0)[9],t5,((C_word*)t0)[8],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[10]);
/* srfi-13.scm: 1863 floor */
t7=*((C_word*)lf[510]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}}}

/* k7329 in k7269 in a7257 in string-xcopy! in k1438 in k1435 */
static void f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_fixnum_divide(((C_word*)t0)[5],((C_word*)t0)[4]);
/* srfi-13.scm: 1863 floor */
t4=*((C_word*)lf[510]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k7333 in k7329 in k7269 in a7257 in string-xcopy! in k1438 in k1435 */
static void f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7335,2,t0,t1);}
t2=((C_word*)t0)[11];
t3=(C_word)C_eqp(t2,t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1865 modulo */
t5=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 1869 %multispan-repcopy! */
f_7345(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[2]);}}

/* k7322 in k7333 in k7329 in k7269 in a7257 in string-xcopy! in k1438 in k1435 */
static void f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7320,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1866 modulo */
t4=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7318 in k7322 in k7333 in k7329 in k7269 in a7257 in string-xcopy! in k1438 in k1435 */
static void f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
/* srfi-13.scm: 1864 %string-copy! */
f_5737(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7213 in string-xcopy! in k1438 in k1435 */
static void f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[515],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7236,a[2]=((C_word*)t0)[4],a[3]=lf[516],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1841 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1848 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7235 in a7213 in string-xcopy! in k1438 in k1435 */
static void f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7236,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[514]);
/* srfi-13.scm: 1846 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7225 in a7213 in string-xcopy! in k1438 in k1435 */
static void f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7226,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* srfi-13.scm: 1841 string-parse-final-start+end */
t3=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[514]+1),((C_word*)t0)[2],t2);}

/* xsubstring in k1438 in k1435 */
static void f_7067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_7067r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7067r(t0,t1,t2,t3,t4);}}

static void f_7067r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[503]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7076,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[506],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7120,a[2]=t2,a[3]=t3,a[4]=lf[511],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1793 ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a7119 in xsubstring in k1438 in k1435 */
static void f_7120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7120,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(C_word)C_fixnum_difference(t2,((C_word*)t0)[3]);
t7=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[507]);}
else{
t8=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1809 ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc10)(void*)(*((C_word*)t9+1)))(10,t9,t1,lf[503],lf[508],*((C_word*)lf[503]+1),((C_word*)t0)[2],((C_word*)t0)[3],t2,t3,t4);}
else{
t9=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t9)){
t10=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 1813 make-string */
t11=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t1,t6,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7190,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[2],a[8]=t1,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
t11=(C_word)C_fixnum_divide(((C_word*)t0)[3],t5);
/* srfi-13.scm: 1816 floor */
t12=*((C_word*)lf[510]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}}}

/* k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1816 floor */
t4=*((C_word*)lf[510]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k7192 in k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7194,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_eqp(t2,t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1817 modulo */
t5=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1821 make-string */
t5=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k7181 in k7192 in k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7186,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1822 %multispan-repcopy! */
f_7345(t2,t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7184 in k7181 in k7192 in k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7178 in k7192 in k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7176,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1818 modulo */
t4=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7174 in k7178 in k7192 in k7188 in a7119 in xsubstring in k1438 in k1435 */
static void f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-13.scm: 1817 ##sys#substring */
t3=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7075 in xsubstring in k1438 in k1435 */
static void f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[504],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[4],a[3]=lf[505],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1795 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1805 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7097 in a7075 in xsubstring in k1438 in k1435 */
static void f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7098,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[503]);
/* srfi-13.scm: 1802 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7087 in a7075 in xsubstring in k1438 in k1435 */
static void f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* srfi-13.scm: 1795 string-parse-final-start+end */
t3=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[503]+1),((C_word*)t0)[2],t2);}

/* string-tokenize in k1438 in k1435 */
static void f_6985(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6985r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6985r(t0,t1,t2,t3);}}

static void f_6985r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[498]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6997,a[2]=t7,a[3]=t2,a[4]=lf[499],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7003,a[2]=t5,a[3]=t2,a[4]=lf[501],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a7002 in string-tokenize in k1438 in k1435 */
static void f_7003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7003,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=lf[500],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7009(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in a7002 in string-tokenize in k1438 in k1435 */
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7009,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
t6=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
/* srfi-13.scm: 1750 string-index-right */
t7=*((C_word*)lf[378]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
t7=t4;
f_7013(2,t7,C_SCHEME_FALSE);}}

/* k7011 in lp in a7002 in string-tokenize in k1438 in k1435 */
static void f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1753 string-skip-right */
t4=*((C_word*)lf[338]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}

/* k7020 in k7011 in lp in a7002 in string-tokenize in k1438 in k1435 */
static void f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7036,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1756 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1758 ##sys#substring */
t3=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7045 in k7020 in k7011 in lp in a7002 in string-tokenize in k1438 in k1435 */
static void f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7034 in k7020 in k7011 in lp in a7002 in string-tokenize in k1438 in k1435 */
static void f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-13.scm: 1755 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7009(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6996 in string-tokenize in k1438 in k1435 */
static void f_6997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6997,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[497]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-replace in k1438 in k1435 */
static void f_6934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6r,(void*)f_6934r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6934r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_6934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6938,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t2,a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1727 check-substring-spec */
t8=*((C_word*)lf[17]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t7,*((C_word*)lf[493]+1),t2,t4,t5);}

/* k6936 in string-replace in k1438 in k1435 */
static void f_6938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=lf[494],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[495],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1728 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6948 in k6936 in string-replace in k1438 in k1435 */
static void f_6949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6949,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[4],((C_word*)t0)[3]);
t7=(C_word)C_fixnum_difference(t4,t6);
t8=(C_word)C_fixnum_plus(t7,t5);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6962,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1732 make-string */
t10=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t8);}

/* k6960 in a6948 in k6936 in string-replace in k1438 in k1435 */
static void f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 1733 %string-copy! */
f_5737(t2,t1,C_fix(0),((C_word*)t0)[7],C_fix(0),((C_word*)t0)[9]);}

/* k6963 in k6960 in a6948 in k6936 in string-replace in k1438 in k1435 */
static void f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1734 %string-copy! */
f_5737(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6966 in k6963 in k6960 in a6948 in k6936 in string-replace in k1438 in k1435 */
static void f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1735 %string-copy! */
f_5737(t2,((C_word*)t0)[7],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6969 in k6966 in k6963 in k6960 in a6948 in k6936 in string-replace in k1438 in k1435 */
static void f_6971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6942 in k6936 in string-replace in k1438 in k1435 */
static void f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
/* srfi-13.scm: 1728 string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[493]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %finish-string-concatenate-reverse in k1438 in k1435 */
static void C_fcall f_6891(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6891,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6895,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_fixnum_plus(t5,t2);
/* srfi-13.scm: 1707 make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* k6893 in %finish-string-concatenate-reverse in k1438 in k1435 */
static void f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1708 %string-copy! */
f_5737(t2,t1,((C_word*)t0)[5],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k6896 in k6893 in %finish-string-concatenate-reverse in k1438 in k1435 */
static void f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=lf[491],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6903(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k6896 in k6893 in %finish-string-concatenate-reverse in k1438 in k1435 */
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6903,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(C_word)C_fixnum_difference(t2,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6925,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1715 %string-copy! */
f_5737(t8,((C_word*)t0)[2],t7,t4,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6923 in lp in k6896 in k6893 in %finish-string-concatenate-reverse in k1438 in k1435 */
static void f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1716 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6903(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6899 in k6896 in k6893 in %finish-string-concatenate-reverse in k1438 in k1435 */
static void f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-concatenate-reverse/shared in k1438 in k1435 */
static void f_6762(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6762r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6762r(t0,t1,t2,t3);}}

static void f_6762r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[488]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_i_string_length(t5):(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_check_exact_2(t9,lf[487]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6789,a[2]=t9,a[3]=t5,a[4]=t14,a[5]=lf[489],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_6789(t16,t1,C_fix(0),C_SCHEME_FALSE,t2);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* lp in string-concatenate-reverse/shared in k1438 in k1435 */
static void C_fcall f_6789(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6789,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t4);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_fixnum_plus(t2,t6);
t8=t3;
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,C_fix(0)));
t10=(C_truep(t9)?t3:t4);
t11=(C_word)C_i_cdr(t4);
/* srfi-13.scm: 1693 lp */
t19=t1;
t20=t7;
t21=t10;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
/* srfi-13.scm: 1697 substring/shared */
t6=*((C_word*)lf[20]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_string_length(t8);
t10=t2;
t11=t6;
f_6839(t11,(C_word)C_eqp(t10,t9));}
else{
t8=t6;
f_6839(t8,C_SCHEME_FALSE);}}}}

/* k6837 in lp in string-concatenate-reverse/shared in k1438 in k1435 */
static void C_fcall f_6839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[5]));}
else{
/* srfi-13.scm: 1704 %finish-string-concatenate-reverse */
f_6891(((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* string-concatenate-reverse in k1438 in k1435 */
static void f_6674(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6674r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6674r(t0,t1,t2,t3);}}

static void f_6674r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(3);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[483]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_i_string_length(t5):(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_check_exact_2(t9,lf[482]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6704,a[2]=lf[484],tmp=(C_word)a,a+=3,tmp);
t14=f_6704(C_fix(0),t2);
/* srfi-13.scm: 1678 %finish-string-concatenate-reverse */
f_6891(t1,t14,t2,t5,t9);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* lp in string-concatenate-reverse in k1438 in k1435 */
static C_word C_fcall f_6704(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_plus(t1,t4);
t6=(C_word)C_i_cdr(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t1);}}

/* string-concatenate in k1438 in k1435 */
static void f_6601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6601,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6642,a[2]=lf[479],tmp=(C_word)a,a+=3,tmp);
t4=f_6642(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6608,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1645 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k6606 in string-concatenate in k1438 in k1435 */
static void f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6611,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6613,a[2]=t1,a[3]=t4,a[4]=lf[480],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6613(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* lp in k6606 in string-concatenate in k1438 in k1435 */
static void C_fcall f_6613(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6613,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6629,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1650 %string-copy! */
f_5737(t6,((C_word*)t0)[2],t2,t4,C_fix(0),t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6627 in lp in k6606 in string-concatenate in k1438 in k1435 */
static void f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-13.scm: 1651 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6613(t4,((C_word*)t0)[2],t2,t3);}

/* k6609 in k6606 in string-concatenate in k1438 in k1435 */
static void f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* do1147 in string-concatenate in k1438 in k1435 */
static C_word C_fcall f_6642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_car(t1);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_fixnum_plus(t2,t5);
t8=t3;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t2);}}

/* string-concatenate/shared in k1438 in k1435 */
static void f_6499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6499,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6505,a[2]=t4,a[3]=lf[476],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6505(t6,t1,t2,C_fix(0),C_SCHEME_FALSE);}

/* lp in string-concatenate/shared in k1438 in k1435 */
static void C_fcall f_6505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6505,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_string_length(t5);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1618 lp */
t19=t1;
t20=t6;
t21=t3;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t9=(C_word)C_fixnum_plus(t3,t7);
t10=t4;
t11=(C_truep(t10)?t10:t2);
/* srfi-13.scm: 1619 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[474]);}
else{
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_string_length(t6);
t8=t3;
t9=(C_word)C_eqp(t8,t7);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_car(t4));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6559,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1626 make-string */
t11=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t3);}}}}

/* k6557 in lp in string-concatenate/shared in k1438 in k1435 */
static void f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6562,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6564,a[2]=t1,a[3]=t4,a[4]=lf[475],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6564(t6,t2,((C_word*)t0)[2],C_fix(0));}

/* lp in k6557 in lp in string-concatenate/shared in k1438 in k1435 */
static void C_fcall f_6564(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6564,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6580,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1631 %string-copy! */
f_5737(t6,((C_word*)t0)[2],t3,t4,C_fix(0),t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6578 in lp in k6557 in lp in string-concatenate/shared in k1438 in k1435 */
static void f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* srfi-13.scm: 1632 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6564(t4,((C_word*)t0)[2],t2,t3);}

/* k6560 in k6557 in lp in string-concatenate/shared in k1438 in k1435 */
static void f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-append/shared in k1438 in k1435 */
static void f_6493(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6493r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6493r(t0,t1,t2);}}

static void f_6493r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-13.scm: 1609 string-concatenate/shared */
t3=*((C_word*)lf[472]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* string->list in k1438 in k1435 */
static void f_6447(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6447r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6447r(t0,t1,t2,t3);}}

static void f_6447r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6453,a[2]=t3,a[3]=t2,a[4]=lf[467],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6459,a[2]=t2,a[3]=lf[469],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6458 in string->list in k1438 in k1435 */
static void f_6459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6459,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6469,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[468],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6469(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* do1119 in a6458 in string->list in k1438 in k1435 */
static void C_fcall f_6469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6469,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t10=t1;
t11=t6;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* a6452 in string->list in k1438 in k1435 */
static void f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6453,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[466]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse! in k1438 in k1435 */
static void f_6392(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6392r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6392r(t0,t1,t2,t3);}}

static void f_6392r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6398,a[2]=t3,a[3]=t2,a[4]=lf[462],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6404,a[2]=t2,a[3]=lf[464],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6403 in string-reverse! in k1438 in k1435 */
static void f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6404,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],a[3]=lf[463],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6414(t5,t4,t2));}

/* do1107 in a6403 in string-reverse! in k1438 in k1435 */
static C_word C_fcall f_6414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
C_stack_check;
t3=t1;
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t7=(C_word)C_i_string_set(((C_word*)t0)[2],t1,t6);
t8=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t9=(C_word)C_fixnum_difference(t1,C_fix(1));
t10=(C_word)C_fixnum_plus(t2,C_fix(1));
t12=t9;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* a6397 in string-reverse! in k1438 in k1435 */
static void f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[461]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse in k1438 in k1435 */
static void f_6337(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6337r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6337r(t0,t1,t2,t3);}}

static void f_6337r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6343,a[2]=t3,a[3]=t2,a[4]=lf[457],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6349,a[2]=t2,a[3]=lf[459],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6348 in string-reverse in k1438 in k1435 */
static void f_6349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6349,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6356,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1551 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k6354 in a6348 in string-reverse in k1438 in k1435 */
static void f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6356,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6365,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[458],tmp=(C_word)a,a+=5,tmp);
t4=f_6365(t3,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* do1096 in k6354 in a6348 in string-reverse in k1438 in k1435 */
static C_word C_fcall f_6365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_fixnum_difference(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* a6342 in string-reverse in k1438 in k1435 */
static void f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[456]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-null? in k1438 in k1435 */
static void f_6334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6334,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(t2));}

/* string-kmp-partial-search in k1438 in k1435 */
static void f_6213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr6r,(void*)f_6213r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6213r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_6213r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(14);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[438]+1):(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6231,a[2]=t14,a[3]=t4,a[4]=lf[449],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6237,a[2]=t5,a[3]=t8,a[4]=t2,a[5]=t12,a[6]=t4,a[7]=t3,a[8]=lf[452],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t15,t16);}

/* a6236 in string-kmp-partial-search in k1438 in k1435 */
static void f_6237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6237,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_vector_length(((C_word*)t0)[7]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,a[10]=lf[451],tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_6246(t9,t1,t3,((C_word*)t0)[2]);}

/* lp in a6236 in string-kmp-partial-search in k1438 in k1435 */
static void C_fcall f_6246(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6246,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_eqp(t4,((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_negate(t2));}
else{
t6=t2;
t7=((C_word*)t0)[8];
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t9=(C_word)C_i_string_ref(((C_word*)t0)[7],t2);
t10=(C_word)C_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6276,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6278,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t13,a[7]=((C_word*)t0)[5],a[8]=lf[450],tmp=(C_word)a,a+=9,tmp));
t15=((C_word*)t13)[1];
f_6278(t15,t11,t3);}}}

/* lp2 in lp in a6236 in string-kmp-partial-search in k1438 in k1435 */
static void C_fcall f_6278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6278,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_i_string_ref(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1531 c= */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6283 in lp2 in lp in a6236 in string-kmp-partial-search in k1438 in k1435 */
static void f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1535 lp2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6278(t4,((C_word*)t0)[5],t2);}}}

/* k6274 in lp in a6236 in string-kmp-partial-search in k1438 in k1435 */
static void f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1529 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6246(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6230 in string-kmp-partial-search in k1438 in k1435 */
static void f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
/* srfi-13.scm: 1520 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[448]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* kmp-step in k1438 in k1435 */
static void f_6175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=8) C_bad_argc(c,8);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_6175,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6181,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t3,a[8]=lf[446],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6181(t11,t1,t5);}

/* lp in kmp-step in k1438 in k1435 */
static void C_fcall f_6181(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6181,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_i_string_ref(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1498 c= */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6186 in lp in kmp-step in k1438 in k1435 */
static void f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1502 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6181(t4,((C_word*)t0)[5],t2);}}}

/* make-kmp-restart-vector in k1438 in k1435 */
static void f_6040(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6040r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6040r(t0,t1,t2,t3);}}

static void f_6040r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[438]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6052,a[2]=t7,a[3]=t2,a[4]=lf[439],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6058,a[2]=t5,a[3]=t2,a[4]=lf[443],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6058,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1452 make-vector */
t7=*((C_word*)lf[442]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t5,C_fix(-1));}

/* k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6068,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[5],C_fix(0)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6082,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=lf[441],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_6082(t8,t2,C_fix(0),C_fix(-1),((C_word*)t0)[3]);}
else{
t3=t2;
f_6068(2,t3,C_SCHEME_UNDEFINED);}}

/* lp1 in k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void C_fcall f_6082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6082,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[8]))){
t6=(C_word)C_i_string_ref(((C_word*)t0)[7],t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=((C_word*)t0)[6],a[11]=t2,a[12]=lf[440],tmp=(C_word)a,a+=13,tmp));
t10=((C_word*)t8)[1];
f_6097(t10,t1,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* lp2 in lp1 in k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6097,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[11],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6124,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t5,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1470 c= */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6130,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_fixnum_plus(t2,((C_word*)t0)[3]);
t7=(C_word)C_i_string_ref(((C_word*)t0)[2],t6);
/* srfi-13.scm: 1474 c= */
t8=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,((C_word*)t0)[6],t7);}}

/* k6128 in lp2 in lp1 in k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t3=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[7]);
t4=(C_word)C_i_vector_set(((C_word*)t0)[6],t2,t3);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-13.scm: 1478 lp1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6082(t6,((C_word*)t0)[3],t2,t3,t5);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[6],((C_word*)t0)[7]);
/* srfi-13.scm: 1480 lp2 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6097(t3,((C_word*)t0)[3],t2);}}

/* k6122 in lp2 in lp1 in k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_truep(t1)?C_fix(-1):C_fix(0));
t3=(C_word)C_i_vector_set(((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1471 lp1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6082(t5,((C_word*)t0)[2],((C_word*)t0)[5],C_fix(0),t4);}

/* k6066 in k6063 in a6057 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6051 in make-kmp-restart-vector in k1438 in k1435 */
static void f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
/* srfi-13.scm: 1450 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[436]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %kmp-search in k1438 in k1435 */
static void f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5942,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_fixnum_difference(t6,t5);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5949,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,a[6]=t3,a[7]=t9,a[8]=t7,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 1399 make-kmp-restart-vector */
t11=*((C_word*)lf[436]+1);
((C_proc6)C_retrieve_proc(t11))(6,t11,t10,t2,t4,t5,t6);}

/* k5947 in %kmp-search in k1438 in k1435 */
static void f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=lf[435],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_5958(t6,((C_word*)t0)[2],((C_word*)t0)[8],C_fix(0),t2,((C_word*)t0)[7]);}

/* lp in k5947 in %kmp-search in k1438 in k1435 */
static void C_fcall f_5958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5958,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_eqp(t6,((C_word*)t0)[8]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_difference(t2,((C_word*)t0)[8]));}
else{
t8=t5;
t9=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t11=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t12=(C_word)C_fixnum_plus(((C_word*)t0)[4],t3);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
/* srfi-13.scm: 1410 c= */
t14=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,t11,t13);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}

/* k5978 in lp in k5947 in %kmp-search in k1438 in k1435 */
static void f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[9]);
t3=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* srfi-13.scm: 1412 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5958(t6,((C_word*)t0)[4],t2,t3,t4,t5);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[7],C_fix(1));
/* srfi-13.scm: 1416 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5958(t6,((C_word*)t0)[4],t4,C_fix(0),t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1417 lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5958(t5,((C_word*)t0)[4],((C_word*)t0)[9],t2,((C_word*)t0)[7],t4);}}}

/* string-contains-ci in k1438 in k1435 */
static void f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_5880r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5880r(t0,t1,t2,t3,t4);}}

static void f_5880r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[420]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5886,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[428],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5892,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[432],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5891 in string-contains-ci in k1438 in k1435 */
static void f_5892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5892,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5898,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[429],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5904,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[431],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5903 in a5891 in string-contains-ci in k1438 in k1435 */
static void f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5904,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5916,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,a[9]=lf[430],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5916(t9,t1,((C_word*)t0)[2]);}

/* lp in a5903 in a5891 in string-contains-ci in k1438 in k1435 */
static void C_fcall f_5916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5916,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1369 string-ci= */
t5=*((C_word*)lf[227]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5927 in lp in a5903 in a5891 in string-contains-ci in k1438 in k1435 */
static void f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1371 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5916(t3,((C_word*)t0)[4],t2);}}

/* a5897 in a5891 in string-contains-ci in k1438 in k1435 */
static void f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5885 in string-contains-ci in k1438 in k1435 */
static void f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains in k1438 in k1435 */
static void f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_5818r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5818r(t0,t1,t2,t3,t4);}}

static void f_5818r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[420]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5824,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[421],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5830,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[425],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5829 in string-contains in k1438 in k1435 */
static void f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5830,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5836,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[422],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5842,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[424],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5841 in a5829 in string-contains in k1438 in k1435 */
static void f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5842,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5854,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,a[9]=lf[423],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5854(t9,t1,((C_word*)t0)[2]);}

/* lp in a5841 in a5829 in string-contains in k1438 in k1435 */
static void C_fcall f_5854(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5854,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1358 string= */
t5=*((C_word*)lf[181]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5865 in lp in a5841 in a5829 in string-contains in k1438 in k1435 */
static void f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1360 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5854(t3,((C_word*)t0)[4],t2);}}

/* a5835 in a5829 in string-contains in k1438 in k1435 */
static void f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5823 in string-contains in k1438 in k1435 */
static void f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-copy! in k1438 in k1435 */
static void C_fcall f_5737(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5737,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=t5;
t8=t3;
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5749,a[2]=t2,a[3]=t4,a[4]=t6,a[5]=lf[417],tmp=(C_word)a,a+=6,tmp);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,f_5749(t9,t5,t3));}
else{
t9=(C_word)C_fixnum_difference(t6,C_fix(1));
t10=(C_word)C_fixnum_difference(t6,t5);
t11=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(-1),t3),t10);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5787,a[2]=t2,a[3]=t4,a[4]=t5,a[5]=lf[418],tmp=(C_word)a,a+=6,tmp);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,f_5787(t12,t9,t11));}}

/* do968 in %string-copy! in k1438 in k1435 */
static C_word C_fcall f_5787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t8=(C_word)C_fixnum_difference(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* do962 in %string-copy! in k1438 in k1435 */
static C_word C_fcall f_5749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t7=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* string-copy! in k1438 in k1435 */
static void f_5705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_5705r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5705r(t0,t1,t2,t3,t4,t5);}}

static void f_5705r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5711,a[2]=t5,a[3]=t4,a[4]=lf[414],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5717,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=lf[415],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5716 in string-copy! in k1438 in k1435 */
static void f_5717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5717,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[413]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5724,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fixnum_difference(t3,t2);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[4],t6);
/* srfi-13.scm: 1328 check-substring-spec */
t8=*((C_word*)lf[17]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,*((C_word*)lf[413]+1),((C_word*)t0)[3],((C_word*)t0)[4],t7);}

/* k5722 in a5716 in string-copy! in k1438 in k1435 */
static void f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1329 %string-copy! */
f_5737(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5710 in string-copy! in k1438 in k1435 */
static void f_5711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5711,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[413]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fill! in k1438 in k1435 */
static void f_5664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5664r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5664r(t0,t1,t2,t3,t4);}}

static void f_5664r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5670,a[2]=t4,a[3]=t2,a[4]=lf[409],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5676,a[2]=t3,a[3]=t2,a[4]=lf[411],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5675 in string-fill! in k1438 in k1435 */
static void f_5676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5676,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=lf[410],tmp=(C_word)a,a+=6,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5686(t5,t4));}

/* do944 in a5675 in string-fill! in k1438 in k1435 */
static C_word C_fcall f_5686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_string_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}

/* a5669 in string-fill! in k1438 in k1435 */
static void f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[408]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-count in k1438 in k1435 */
static void f_5529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5529r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5529r(t0,t1,t2,t3,t4);}}

static void f_5529r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=t4,a[3]=t2,a[4]=lf[401],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5541,a[2]=t2,a[3]=t3,a[4]=lf[406],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5540 in string-count in k1438 in k1435 */
static void f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5541,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[402],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5553(t4,t2,C_fix(0)));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5587,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1294 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5585 in a5540 in string-count in k1438 in k1435 */
static void f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5587,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[403],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5592(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[404],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5631(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
/* srfi-13.scm: 1306 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[400],lf[405],*((C_word*)lf[400]+1),((C_word*)t0)[4]);}}}

/* do934 in k5585 in a5540 in string-count in k1438 in k1435 */
static void C_fcall f_5631(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5631,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1303 criteria */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}}

/* k5650 in do934 in k5585 in a5540 in string-count in k1438 in k1435 */
static void f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5631(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do929 in k5585 in a5540 in string-count in k1438 in k1435 */
static void C_fcall f_5592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5592,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5613,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1296 char-set-contains? */
t9=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k5611 in do929 in k5585 in a5540 in string-count in k1438 in k1435 */
static void f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5592(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do924 in a5540 in string-count in k1438 in k1435 */
static C_word C_fcall f_5553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(t2);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
t8=(C_truep(t7)?(C_word)C_fixnum_plus(t2,C_fix(1)):t2);
t10=t5;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* a5534 in string-count in k1438 in k1435 */
static void f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[400]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip-right in k1438 in k1435 */
static void f_5394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5394r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5394r(t0,t1,t2,t3,t4);}}

static void f_5394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5400,a[2]=t4,a[3]=t2,a[4]=lf[393],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5406,a[2]=t2,a[3]=t3,a[4]=lf[398],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5405 in string-skip-right in k1438 in k1435 */
static void f_5406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5406,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[394],tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5422(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5452,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1268 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5450 in a5405 in string-skip-right in k1438 in k1435 */
static void f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[395],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5461(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[396],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5500(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1279 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[338],lf[397],*((C_word*)lf[338]+1),((C_word*)t0)[3]);}}}

/* lp in k5450 in a5405 in string-skip-right in k1438 in k1435 */
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5500,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5513,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1277 criteria */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5511 in lp in k5450 in a5405 in string-skip-right in k1438 in k1435 */
static void f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1277 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5500(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5450 in a5405 in string-skip-right in k1438 in k1435 */
static void C_fcall f_5461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5461,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5474,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1271 char-set-contains? */
t6=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5472 in lp in k5450 in a5405 in string-skip-right in k1438 in k1435 */
static void f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1272 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5461(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5405 in string-skip-right in k1438 in k1435 */
static C_word C_fcall f_5422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5399 in string-skip-right in k1438 in k1435 */
static void f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[338]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip in k1438 in k1435 */
static void f_5271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5271r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5271r(t0,t1,t2,t3,t4);}}

static void f_5271r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5277,a[2]=t4,a[3]=t2,a[4]=lf[386],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5283,a[2]=t2,a[3]=t3,a[4]=lf[391],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5282 in string-skip in k1438 in k1435 */
static void f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5283,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[387],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5295(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5325,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1246 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5323 in a5282 in string-skip in k1438 in k1435 */
static void f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[388],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5330(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[389],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5365(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1257 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[308],lf[390],*((C_word*)lf[308]+1),((C_word*)t0)[4]);}}}

/* lp in k5323 in a5282 in string-skip in k1438 in k1435 */
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5365,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5378,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1255 criteria */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5376 in lp in k5323 in a5282 in string-skip in k1438 in k1435 */
static void f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1255 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5365(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5323 in a5282 in string-skip in k1438 in k1435 */
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5330,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5343,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1249 char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5341 in lp in k5323 in a5282 in string-skip in k1438 in k1435 */
static void f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1250 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5330(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5282 in string-skip in k1438 in k1435 */
static C_word C_fcall f_5295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5276 in string-skip in k1438 in k1435 */
static void f_5277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5277,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index-right in k1438 in k1435 */
static void f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5136r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5136r(t0,t1,t2,t3,t4);}}

static void f_5136r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5142,a[2]=t4,a[3]=t2,a[4]=lf[379],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5148,a[2]=t2,a[3]=t3,a[4]=lf[384],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5147 in string-index-right in k1438 in k1435 */
static void f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5148,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[380],tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5164(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5194,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1225 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5192 in a5147 in string-index-right in k1438 in k1435 */
static void f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5194,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[381],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5203(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[382],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5242(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1235 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[378],lf[383],*((C_word*)lf[378]+1),((C_word*)t0)[3]);}}}

/* lp in k5192 in a5147 in string-index-right in k1438 in k1435 */
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5242,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1233 criteria */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5253 in lp in k5192 in a5147 in string-index-right in k1438 in k1435 */
static void f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1234 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5242(t3,((C_word*)t0)[4],t2);}}

/* lp in k5192 in a5147 in string-index-right in k1438 in k1435 */
static void C_fcall f_5203(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5203,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1228 char-set-contains? */
t6=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5214 in lp in k5192 in a5147 in string-index-right in k1438 in k1435 */
static void f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1229 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5203(t3,((C_word*)t0)[4],t2);}}

/* lp in a5147 in string-index-right in k1438 in k1435 */
static C_word C_fcall f_5164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5141 in string-index-right in k1438 in k1435 */
static void f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5142,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[378]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index in k1438 in k1435 */
static void f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5013r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5013r(t0,t1,t2,t3,t4);}}

static void f_5013r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=t4,a[3]=t2,a[4]=lf[371],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=t2,a[3]=t3,a[4]=lf[376],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5024 in string-index in k1438 in k1435 */
static void f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5025,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[372],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5037(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5067,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1205 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5065 in a5024 in string-index in k1438 in k1435 */
static void f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[373],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5072(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[374],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5107(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1215 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[310],lf[375],*((C_word*)lf[310]+1),((C_word*)t0)[4]);}}}

/* lp in k5065 in a5024 in string-index in k1438 in k1435 */
static void C_fcall f_5107(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5107,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1213 criteria */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5118 in lp in k5065 in a5024 in string-index in k1438 in k1435 */
static void f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1214 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5107(t3,((C_word*)t0)[4],t2);}}

/* lp in k5065 in a5024 in string-index in k1438 in k1435 */
static void C_fcall f_5072(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5072,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1208 char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5083 in lp in k5065 in a5024 in string-index in k1438 in k1435 */
static void f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1209 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5072(t3,((C_word*)t0)[4],t2);}}

/* lp in a5024 in string-index in k1438 in k1435 */
static C_word C_fcall f_5037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5018 in string-index in k1438 in k1435 */
static void f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-filter in k1438 in k1435 */
static void f_4905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4905r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4905r(t0,t1,t2,t3,t4);}}

static void f_4905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=t4,a[3]=t3,a[4]=lf[364],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4917,a[2]=t3,a[3]=t2,a[4]=lf[369],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4916 in string-filter in k1438 in k1435 */
static void f_4917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4917,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4930,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1161 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4960,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1170 char-set? */
t6=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k4997 in a4916 in string-filter in k1438 in k1435 */
static void f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4960(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1171 char-set */
t2=*((C_word*)lf[359]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1172 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[363],lf[368],((C_word*)t0)[2]);}}}

/* k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=t1,a[3]=lf[367],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1174 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4985 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4986,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4993,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1174 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4991 in a4985 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)):((C_word*)t0)[2]));}

/* k4961 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1178 make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4964 in k4961 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[366],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1179 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4970 in k4964 in k4961 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4971,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4978,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1179 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4976 in a4970 in k4964 in k4961 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4967 in k4964 in k4961 in k4958 in a4916 in string-filter in k1438 in k1435 */
static void f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4928 in a4916 in string-filter in k1438 in k1435 */
static void f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4933,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[365],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1162 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4943 in k4928 in a4916 in string-filter in k1438 in k1435 */
static void f_4944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4944,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4951,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1163 criteria */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4949 in a4943 in k4928 in a4916 in string-filter in k1438 in k1435 */
static void f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4931 in k4928 in a4916 in string-filter in k1438 in k1435 */
static void f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1168 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4910 in string-filter in k1438 in k1435 */
static void f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[363]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-delete in k1438 in k1435 */
static void f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4797r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4797r(t0,t1,t2,t3,t4);}}

static void f_4797r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4803,a[2]=t4,a[3]=t3,a[4]=lf[355],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4809,a[2]=t3,a[3]=t2,a[4]=lf[361],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4808 in string-delete in k1438 in k1435 */
static void f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4809,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4822,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1134 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4852,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1142 char-set? */
t6=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k4889 in a4808 in string-delete in k1438 in k1435 */
static void f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4852(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1143 char-set */
t2=*((C_word*)lf[359]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1144 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[354],lf[360],((C_word*)t0)[2]);}}}

/* k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4878,a[2]=t1,a[3]=lf[358],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1145 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4877 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4878,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1145 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4883 in a4877 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1))));}

/* k4853 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1149 make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4856 in k4853 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[357],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1150 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4862 in k4856 in k4853 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4863,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4870,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1150 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4868 in a4862 in k4856 in k4853 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4859 in k4856 in k4853 in k4850 in a4808 in string-delete in k1438 in k1435 */
static void f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4820 in a4808 in string-delete in k1438 in k1435 */
static void f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[356],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1135 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4835 in k4820 in a4808 in string-delete in k1438 in k1435 */
static void f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4836,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4843,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1136 criteria */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4841 in a4835 in k4820 in a4808 in string-delete in k1438 in k1435 */
static void f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4823 in k4820 in a4808 in string-delete in k1438 in k1435 */
static void f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1140 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4802 in string-delete in k1438 in k1435 */
static void f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[354]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad in k1438 in k1435 */
static void f_4735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_4735r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4735r(t0,t1,t2,t3,t4);}}

static void f_4735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[350]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4750,a[2]=t9,a[3]=t2,a[4]=lf[351],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4756,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[352],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}

/* a4755 in string-pad in k1438 in k1435 */
static void f_4756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4756,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_fixnum_difference(t3,((C_word*)t0)[4]);
/* srfi-13.scm: 1109 %substring/shared */
f_1652(t1,((C_word*)t0)[3],t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4776,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1110 make-string */
t7=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4774 in a4755 in string-pad in k1438 in k1435 */
static void f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4779,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1111 %string-copy! */
f_5737(t2,t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4777 in k4774 in a4755 in string-pad in k1438 in k1435 */
static void f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4749 in string-pad in k1438 in k1435 */
static void f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[350]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad-right in k1438 in k1435 */
static void f_4677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_4677r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4677r(t0,t1,t2,t3,t4);}}

static void f_4677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[346]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4692,a[2]=t9,a[3]=t2,a[4]=lf[347],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4698,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[348],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}

/* a4697 in string-pad-right in k1438 in k1435 */
static void f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4698,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_fixnum_plus(t2,((C_word*)t0)[4]);
/* srfi-13.scm: 1098 %substring/shared */
f_1652(t1,((C_word*)t0)[3],t2,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4718,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1099 make-string */
t7=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4716 in a4697 in string-pad-right in k1438 in k1435 */
static void f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4721,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1100 %string-copy! */
f_5737(t2,t1,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4719 in k4716 in a4697 in string-pad-right in k1438 in k1435 */
static void f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4691 in string-pad-right in k1438 in k1435 */
static void f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4692,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[346]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-both in k1438 in k1435 */
static void f_4627(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4627r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4627r(t0,t1,t2,t3);}}

static void f_4627r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[330]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4639,a[2]=t7,a[3]=t2,a[4]=lf[342],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=t5,a[3]=t2,a[4]=lf[344],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4644 in string-trim-both in k1438 in k1435 */
static void f_4645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4645,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4649,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1086 string-skip */
t5=*((C_word*)lf[308]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4647 in a4644 in string-trim-both in k1438 in k1435 */
static void f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1088 string-skip-right */
t3=*((C_word*)lf[338]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[343]);}}

/* k4661 in k4647 in a4644 in string-trim-both in k1438 in k1435 */
static void f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1088 %substring/shared */
f_1652(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4638 in string-trim-both in k1438 in k1435 */
static void f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4639,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[341]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-right in k1438 in k1435 */
static void f_4581(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4581r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4581r(t0,t1,t2,t3);}}

static void f_4581r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[330]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4593,a[2]=t7,a[3]=t2,a[4]=lf[336],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4599,a[2]=t5,a[3]=t2,a[4]=lf[339],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4598 in string-trim-right in k1438 in k1435 */
static void f_4599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4599,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1079 string-skip-right */
t5=*((C_word*)lf[338]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4601 in a4598 in string-trim-right in k1438 in k1435 */
static void f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1080 %substring/shared */
f_1652(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[337]);}}

/* a4592 in string-trim-right in k1438 in k1435 */
static void f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[335]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim in k1438 in k1435 */
static void f_4539(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4539r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4539r(t0,t1,t2,t3);}}

static void f_4539r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[330]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4551,a[2]=t7,a[3]=t2,a[4]=lf[331],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4557,a[2]=t5,a[3]=t2,a[4]=lf[333],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4556 in string-trim in k1438 in k1435 */
static void f_4557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4557,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4561,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1072 string-skip */
t5=*((C_word*)lf[308]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4559 in a4556 in string-trim in k1438 in k1435 */
static void f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 1073 %substring/shared */
f_1652(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[332]);}}

/* a4550 in string-trim in k1438 in k1435 */
static void f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[329]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-drop-right in k1438 in k1435 */
static void f_4523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4523,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_i_check_exact_2(t3,lf[327]);
t6=(C_word)C_fixnum_difference(t4,t3);
/* srfi-13.scm: 1066 %substring/shared */
f_1652(t1,t2,C_fix(0),t6);}

/* string-drop in k1438 in k1435 */
static void f_4511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4511,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_i_check_exact_2(t3,lf[325]);
/* srfi-13.scm: 1058 %substring/shared */
f_1652(t1,t2,t3,t4);}

/* string-take-right in k1438 in k1435 */
static void f_4495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4495,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_i_check_exact_2(t3,lf[323]);
t6=(C_word)C_fixnum_difference(t4,t3);
/* srfi-13.scm: 1050 %substring/shared */
f_1652(t1,t2,t6,t4);}

/* string-take in k1438 in k1435 */
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4486,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[321]);
/* srfi-13.scm: 1042 %substring/shared */
f_1652(t1,t2,C_fix(0),t3);}

/* string-titlecase in k1438 in k1435 */
static void f_4461(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4461r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4461r(t0,t1,t2,t3);}}

static void f_4461r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4467,a[2]=t3,a[3]=t2,a[4]=lf[318],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=t2,a[3]=lf[319],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4472 in string-titlecase in k1438 in k1435 */
static void f_4473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4473,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4477,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1013 ##sys#substring */
t5=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,t3);}

/* k4475 in a4472 in string-titlecase in k1438 in k1435 */
static void f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4480,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-13.scm: 1014 %string-titlecase! */
f_4384(t2,t1,C_fix(0),t3);}

/* k4478 in k4475 in a4472 in string-titlecase in k1438 in k1435 */
static void f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4466 in string-titlecase in k1438 in k1435 */
static void f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4467,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-titlecase! in k1438 in k1435 */
static void f_4443(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4443r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4443r(t0,t1,t2,t3);}}

static void f_4443r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=t3,a[3]=t2,a[4]=lf[314],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4455,a[2]=t2,a[3]=lf[315],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4454 in string-titlecase! in k1438 in k1435 */
static void f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4455,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1009 %string-titlecase! */
f_4384(t1,((C_word*)t0)[2],t2,t3);}

/* a4448 in string-titlecase! in k1438 in k1435 */
static void f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-titlecase! in k1438 in k1435 */
static void C_fcall f_4384(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4390,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=lf[311],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4390(t8,t1,t3);}

/* lp in %string-titlecase! in k1438 in k1435 */
static void C_fcall f_4390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4390,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4437,a[2]=lf[309],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 997  string-index */
t5=*((C_word*)lf[310]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[4],t4,t2,((C_word*)t0)[2]);}

/* a4436 in lp in %string-titlecase! in k1438 in k1435 */
static void f_4437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4392 in lp in %string-titlecase! in k1438 in k1435 */
static void f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[5],t1);
t3=(C_word)C_u_i_char_upcase(t2);
t4=(C_word)C_i_string_set(((C_word*)t0)[5],t1,t3);
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=lf[307],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1001 string-skip */
t8=*((C_word*)lf[308]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t6,((C_word*)t0)[5],t7,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a4423 in k4392 in lp in %string-titlecase! in k1438 in k1435 */
static void f_4424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4424,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4404 in k4392 in lp in %string-titlecase! in k1438 in k1435 */
static void f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1003 string-downcase! */
t3=*((C_word*)lf[302]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1);}
else{
/* srfi-13.scm: 1005 string-downcase! */
t2=*((C_word*)lf[302]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4410 in k4404 in k4392 in lp in %string-titlecase! in k1438 in k1435 */
static void f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1004 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4390(t3,((C_word*)t0)[2],t2);}

/* string-downcase! in k1438 in k1435 */
static void f_4366(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4366r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4366r(t0,t1,t2,t3);}}

static void f_4366r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4372,a[2]=t3,a[3]=t2,a[4]=lf[303],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4378,a[2]=t2,a[3]=lf[304],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4377 in string-downcase! in k1438 in k1435 */
static void f_4378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4378,4,t0,t1,t2,t3);}
/* srfi-13.scm: 993  %string-map! */
f_1779(t1,*((C_word*)lf[299]+1),((C_word*)t0)[2],t2,t3);}

/* a4371 in string-downcase! in k1438 in k1435 */
static void f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[302]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-downcase in k1438 in k1435 */
static void f_4348(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4348r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4348r(t0,t1,t2,t3);}}

static void f_4348r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=t3,a[3]=t2,a[4]=lf[298],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=t2,a[3]=lf[300],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4359 in string-downcase in k1438 in k1435 */
static void f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4360,4,t0,t1,t2,t3);}
/* srfi-13.scm: 989  %string-map */
f_1710(t1,*((C_word*)lf[299]+1),((C_word*)t0)[2],t2,t3);}

/* a4353 in string-downcase in k1438 in k1435 */
static void f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[297]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase! in k1438 in k1435 */
static void f_4330(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4330r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4330r(t0,t1,t2,t3);}}

static void f_4330r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4336,a[2]=t3,a[3]=t2,a[4]=lf[294],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=t2,a[3]=lf[295],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4341 in string-upcase! in k1438 in k1435 */
static void f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4342,4,t0,t1,t2,t3);}
/* srfi-13.scm: 985  %string-map! */
f_1779(t1,*((C_word*)lf[290]+1),((C_word*)t0)[2],t2,t3);}

/* a4335 in string-upcase! in k1438 in k1435 */
static void f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[293]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase in k1438 in k1435 */
static void f_4312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4312r(t0,t1,t2,t3);}}

static void f_4312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4318,a[2]=t3,a[3]=t2,a[4]=lf[289],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4324,a[2]=t2,a[3]=lf[291],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4323 in string-upcase in k1438 in k1435 */
static void f_4324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4324,4,t0,t1,t2,t3);}
/* srfi-13.scm: 981  %string-map */
f_1710(t1,*((C_word*)lf[290]+1),((C_word*)t0)[2],t2,t3);}

/* a4317 in string-upcase in k1438 in k1435 */
static void f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash-ci in k1438 in k1435 */
static void f_4256(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4256r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4256r(t0,t1,t2,t3);}}

static void f_4256r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4266,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4266(t13,t12);}
else{
t12=t10;
f_4266(t12,C_SCHEME_UNDEFINED);}}

/* k4264 in string-hash-ci in k1438 in k1435 */
static void C_fcall f_4266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4266,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[283]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[284],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=lf[286],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 963  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4279 in k4264 in string-hash-ci in k1438 in k1435 */
static void f_4280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4280,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=lf[285],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 964  %string-hash */
f_4138(t1,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4285 in a4279 in k4264 in string-hash-ci in k1438 in k1435 */
static void f_4286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4286,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_downcase(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t3)));}

/* a4273 in k4264 in string-hash-ci in k1438 in k1435 */
static void f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
/* srfi-13.scm: 963  string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[283]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash in k1438 in k1435 */
static void f_4210(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4210r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4210r(t0,t1,t2,t3);}}

static void f_4210r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4220,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4220(t13,t12);}
else{
t12=t10;
f_4220(t12,C_SCHEME_UNDEFINED);}}

/* k4218 in string-hash in k1438 in k1435 */
static void C_fcall f_4220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4220,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[278]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[279],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=lf[281],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 953  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4233 in k4218 in string-hash in k1438 in k1435 */
static void f_4234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4234,4,t0,t1,t2,t3);}
/* srfi-13.scm: 954  %string-hash */
f_4138(t1,((C_word*)t0)[3],*((C_word*)lf[280]+1),((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4227 in k4218 in string-hash in k1438 in k1435 */
static void f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
/* srfi-13.scm: 953  string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[278]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-hash in k1438 in k1435 */
static void C_fcall f_4138(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4138,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=t3,a[3]=lf[273],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4191,a[2]=t4,a[3]=lf[274],tmp=(C_word)a,a+=4,tmp);
t9=f_4191(t8,C_fix(65536));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4156,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t4,a[7]=t6,a[8]=lf[276],tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_4156(t13,t1,t5,C_fix(0));}

/* lp in %string-hash in k1438 in k1435 */
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4156,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[7];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* srfi-13.scm: 943  modulo */
t6=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t3,((C_word*)t0)[6]);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_fixnum_times(C_fix(37),t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4189,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 944  iref */
t9=((C_word*)t0)[3];
f_4140(t9,t8,((C_word*)t0)[2],t2);}}

/* k4187 in lp in %string-hash in k1438 in k1435 */
static void f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_and(((C_word*)t0)[5],t2);
/* srfi-13.scm: 944  lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4156(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* lp in %string-hash in k1438 in k1435 */
static C_word C_fcall f_4191(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* iref in %string-hash in k1438 in k1435 */
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4140,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-13.scm: 938  char->int */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* string-ci>= in k1438 in k1435 */
static void f_4090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_4090r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4090r(t0,t1,t2,t3,t4);}}

static void f_4090r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[265]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4096,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[266],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4102,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[270],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a4101 in string-ci>= in k1438 in k1435 */
static void f_4102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4102,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4108,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[267],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[269],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4113 in a4101 in string-ci>= in k1438 in k1435 */
static void f_4114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4114,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4121,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4121(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4121(t6,C_SCHEME_FALSE);}}

/* k4119 in a4113 in a4101 in string-ci>= in k1438 in k1435 */
static void C_fcall f_4121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4121,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4129,a[2]=lf[268],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 918  %string-compare-ci */
f_3362(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[186]+1),*((C_word*)lf[186]+1));}}

/* a4128 in k4119 in a4113 in a4101 in string-ci>= in k1438 in k1435 */
static void f_4129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4129,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4107 in a4101 in string-ci>= in k1438 in k1435 */
static void f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4095 in string-ci>= in k1438 in k1435 */
static void f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<= in k1438 in k1435 */
static void f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_4042r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4042r(t0,t1,t2,t3,t4);}}

static void f_4042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[258]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4048,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[259],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4054,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[263],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a4053 in string-ci<= in k1438 in k1435 */
static void f_4054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4054,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4060,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[260],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[262],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4065 in a4053 in string-ci<= in k1438 in k1435 */
static void f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4066,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4073,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4073(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4073(t6,C_SCHEME_FALSE);}}

/* k4071 in a4065 in a4053 in string-ci<= in k1438 in k1435 */
static void C_fcall f_4073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4073,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=lf[261],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 907  %string-compare-ci */
f_3362(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),*((C_word*)lf[186]+1),t2);}}

/* a4080 in k4071 in a4065 in a4053 in string-ci<= in k1438 in k1435 */
static void f_4081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4081,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4059 in a4053 in string-ci<= in k1438 in k1435 */
static void f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4047 in string-ci<= in k1438 in k1435 */
static void f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci> in k1438 in k1435 */
static void f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3991r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3991r(t0,t1,t2,t3,t4);}}

static void f_3991r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[250]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3997,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[251],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4003,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[256],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a4002 in string-ci> in k1438 in k1435 */
static void f_4003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4003,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4009,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[252],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[255],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4014 in a4002 in string-ci> in k1438 in k1435 */
static void f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4015,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4022,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4022(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4022(t6,C_SCHEME_FALSE);}}

/* k4020 in a4014 in a4002 in string-ci> in k1438 in k1435 */
static void C_fcall f_4022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4033,a[2]=lf[254],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 896  %string-compare-ci */
f_3362(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[186]+1));}}

/* a4032 in k4020 in a4014 in a4002 in string-ci> in k1438 in k1435 */
static void f_4033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4033,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4029 in k4020 in a4014 in a4002 in string-ci> in k1438 in k1435 */
static void f_4030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4030,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4008 in a4002 in string-ci> in k1438 in k1435 */
static void f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3996 in string-ci> in k1438 in k1435 */
static void f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci< in k1438 in k1435 */
static void f_3940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3940r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3940r(t0,t1,t2,t3,t4);}}

static void f_3940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[242]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3946,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[243],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3952,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[248],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3951 in string-ci< in k1438 in k1435 */
static void f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3952,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3958,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[244],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[247],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3963 in a3951 in string-ci< in k1438 in k1435 */
static void f_3964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3964,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3971,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3971(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3971(t6,C_SCHEME_FALSE);}}

/* k3969 in a3963 in a3951 in string-ci< in k1438 in k1435 */
static void C_fcall f_3971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3979,a[2]=lf[245],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3982,a[2]=lf[246],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 885  %string-compare-ci */
f_3362(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),t2,t3);}}

/* a3981 in k3969 in a3963 in a3951 in string-ci< in k1438 in k1435 */
static void f_3982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3982,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3978 in k3969 in a3963 in a3951 in string-ci< in k1438 in k1435 */
static void f_3979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3979,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3957 in a3951 in string-ci< in k1438 in k1435 */
static void f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3945 in string-ci< in k1438 in k1435 */
static void f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<> in k1438 in k1435 */
static void f_3873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3873r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3873r(t0,t1,t2,t3,t4);}}

static void f_3873r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[235]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3879,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[236],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3885,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[240],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3884 in string-ci<> in k1438 in k1435 */
static void f_3885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3885,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3891,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[237],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[239],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3896 in a3884 in string-ci<> in k1438 in k1435 */
static void f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3897,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3920,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3920(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3920(t10,C_SCHEME_FALSE);}}}

/* k3918 in a3896 in a3884 in string-ci<> in k1438 in k1435 */
static void C_fcall f_3920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 874  %string-compare-ci */
f_3362(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[186]+1),t2,*((C_word*)lf[186]+1));}}

/* a3914 in k3918 in a3896 in a3884 in string-ci<> in k1438 in k1435 */
static void f_3915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3915,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3890 in a3884 in string-ci<> in k1438 in k1435 */
static void f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3878 in string-ci<> in k1438 in k1435 */
static void f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci= in k1438 in k1435 */
static void f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3811r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3811r(t0,t1,t2,t3,t4);}}

static void f_3811r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[227]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[228],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3823,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[233],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3822 in string-ci= in k1438 in k1435 */
static void f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3823,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3829,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[229],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[232],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3834 in a3822 in string-ci= in k1438 in k1435 */
static void f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3835,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3845,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3845(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3845(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3843 in a3834 in a3822 in string-ci= in k1438 in k1435 */
static void C_fcall f_3845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=lf[230],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 864  %string-compare-ci */
f_3362(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[186]+1),t3);}}

/* a3855 in k3843 in a3834 in a3822 in string-ci= in k1438 in k1435 */
static void f_3856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3856,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3852 in k3843 in a3834 in a3822 in string-ci= in k1438 in k1435 */
static void f_3853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3853,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3828 in a3822 in string-ci= in k1438 in k1435 */
static void f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3816 in string-ci= in k1438 in k1435 */
static void f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string>= in k1438 in k1435 */
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3763r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3763r(t0,t1,t2,t3,t4);}}

static void f_3763r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[220]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3769,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[221],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3775,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[225],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3774 in string>= in k1438 in k1435 */
static void f_3775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3775,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3781,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[222],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[224],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3786 in a3774 in string>= in k1438 in k1435 */
static void f_3787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3787,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3794,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3794(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3794(t6,C_SCHEME_FALSE);}}

/* k3792 in a3786 in a3774 in string>= in k1438 in k1435 */
static void C_fcall f_3794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3794,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=lf[223],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 854  %string-compare */
f_3300(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[186]+1),*((C_word*)lf[186]+1));}}

/* a3801 in k3792 in a3786 in a3774 in string>= in k1438 in k1435 */
static void f_3802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3802,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3780 in a3774 in string>= in k1438 in k1435 */
static void f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3781,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3768 in string>= in k1438 in k1435 */
static void f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<= in k1438 in k1435 */
static void f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3715r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3715r(t0,t1,t2,t3,t4);}}

static void f_3715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[213]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3721,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[214],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[218],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3726 in string<= in k1438 in k1435 */
static void f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3727,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3733,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[215],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[217],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3738 in a3726 in string<= in k1438 in k1435 */
static void f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3739,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3746,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3746(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3746(t6,C_SCHEME_FALSE);}}

/* k3744 in a3738 in a3726 in string<= in k1438 in k1435 */
static void C_fcall f_3746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3746,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3754,a[2]=lf[216],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 843  %string-compare */
f_3300(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),*((C_word*)lf[186]+1),t2);}}

/* a3753 in k3744 in a3738 in a3726 in string<= in k1438 in k1435 */
static void f_3754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3754,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3732 in a3726 in string<= in k1438 in k1435 */
static void f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3720 in string<= in k1438 in k1435 */
static void f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string> in k1438 in k1435 */
static void f_3664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3664r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3664r(t0,t1,t2,t3,t4);}}

static void f_3664r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[205]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3670,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[206],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[211],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3675 in string> in k1438 in k1435 */
static void f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3676,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3682,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[207],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[210],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3687 in a3675 in string> in k1438 in k1435 */
static void f_3688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3688,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3695,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3695(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3695(t6,C_SCHEME_FALSE);}}

/* k3693 in a3687 in a3675 in string> in k1438 in k1435 */
static void C_fcall f_3695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3695,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=lf[208],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 832  %string-compare */
f_3300(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[186]+1));}}

/* a3705 in k3693 in a3687 in a3675 in string> in k1438 in k1435 */
static void f_3706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3706,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3702 in k3693 in a3687 in a3675 in string> in k1438 in k1435 */
static void f_3703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3703,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3681 in a3675 in string> in k1438 in k1435 */
static void f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3669 in string> in k1438 in k1435 */
static void f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string< in k1438 in k1435 */
static void f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3613r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3613r(t0,t1,t2,t3,t4);}}

static void f_3613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[197]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3619,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[198],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[203],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3624 in string< in k1438 in k1435 */
static void f_3625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3625,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[199],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[202],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3636 in a3624 in string< in k1438 in k1435 */
static void f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3644,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3644(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3644(t6,C_SCHEME_FALSE);}}

/* k3642 in a3636 in a3624 in string< in k1438 in k1435 */
static void C_fcall f_3644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3644,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3652,a[2]=lf[200],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=lf[201],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 821  %string-compare */
f_3300(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),t2,t3);}}

/* a3654 in k3642 in a3636 in a3624 in string< in k1438 in k1435 */
static void f_3655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3655,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3651 in k3642 in a3636 in a3624 in string< in k1438 in k1435 */
static void f_3652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3630 in a3624 in string< in k1438 in k1435 */
static void f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3618 in string< in k1438 in k1435 */
static void f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<> in k1438 in k1435 */
static void f_3546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3546r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3546r(t0,t1,t2,t3,t4);}}

static void f_3546r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[190]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3552,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[191],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3558,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[195],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3557 in string<> in k1438 in k1435 */
static void f_3558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3558,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3564,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[192],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[194],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3569 in a3557 in string<> in k1438 in k1435 */
static void f_3570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3570,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3593,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3593(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3593(t10,C_SCHEME_FALSE);}}}

/* k3591 in a3569 in a3557 in string<> in k1438 in k1435 */
static void C_fcall f_3593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3593,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 810  %string-compare */
f_3300(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[186]+1),t2,*((C_word*)lf[186]+1));}}

/* a3587 in k3591 in a3569 in a3557 in string<> in k1438 in k1435 */
static void f_3588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3588,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3563 in a3557 in string<> in k1438 in k1435 */
static void f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3551 in string<> in k1438 in k1435 */
static void f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string= in k1438 in k1435 */
static void f_3484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3484r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3484r(t0,t1,t2,t3,t4);}}

static void f_3484r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[181]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3490,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[182],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[188],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3495 in string= in k1438 in k1435 */
static void f_3496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3496,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3502,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[183],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[187],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3507 in a3495 in string= in k1438 in k1435 */
static void f_3508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3508,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3518,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3518(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3518(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3516 in a3507 in a3495 in string= in k1438 in k1435 */
static void C_fcall f_3518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3518,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3526,a[2]=lf[184],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=lf[185],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 800  %string-compare */
f_3300(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[186]+1),t3);}}

/* a3528 in k3516 in a3507 in a3495 in string= in k1438 in k1435 */
static void f_3529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3529,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3525 in k3516 in a3507 in a3495 in string= in k1438 in k1435 */
static void f_3526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3526,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3501 in a3495 in string= in k1438 in k1435 */
static void f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3502,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3489 in string= in k1438 in k1435 */
static void f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare-ci in k1438 in k1435 */
static void f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc(c,7);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr7r,(void*)f_3454r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3454r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void f_3454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t8=*((C_word*)lf[175]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3460,a[2]=t7,a[3]=t2,a[4]=t8,a[5]=lf[176],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3466,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,a[8]=lf[179],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a3465 in string-compare-ci in k1438 in k1435 */
static void f_3466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3466,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[177],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=lf[178],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3477 in a3465 in string-compare-ci in k1438 in k1435 */
static void f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3478,4,t0,t1,t2,t3);}
/* srfi-13.scm: 784  %string-compare-ci */
f_3362(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3471 in a3465 in string-compare-ci in k1438 in k1435 */
static void f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3459 in string-compare-ci in k1438 in k1435 */
static void f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare in k1438 in k1435 */
static void f_3424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc(c,7);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr7r,(void*)f_3424r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3424r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void f_3424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t8=*((C_word*)lf[169]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=t7,a[3]=t2,a[4]=t8,a[5]=lf[170],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3436,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,a[8]=lf[173],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a3435 in string-compare in k1438 in k1435 */
static void f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3436,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3442,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[171],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=lf[172],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3447 in a3435 in string-compare in k1438 in k1435 */
static void f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3448,4,t0,t1,t2,t3);}
/* srfi-13.scm: 776  %string-compare */
f_3300(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3441 in a3435 in string-compare in k1438 in k1435 */
static void f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3429 in string-compare in k1438 in k1435 */
static void f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare-ci in k1438 in k1435 */
static void C_fcall f_3362(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_fixnum_difference(t4,t3);
t12=(C_word)C_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3372,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 761  %string-prefix-length-ci */
f_2810(t13,t2,t3,t4,t5,t6,t7);}

/* k3370 in %string-compare-ci in k1438 in k1435 */
static void f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3397,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3397(t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t10=(C_word)C_i_string_ref(((C_word*)t0)[4],t9);
t11=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t12=(C_word)C_i_string_ref(((C_word*)t0)[2],t11);
/* srfi-13.scm: 765  char-ci<? */
t13=*((C_word*)lf[167]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t10,t12);}}}

/* k3404 in k3370 in %string-compare-ci in k1438 in k1435 */
static void f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_3397(t2,(C_truep(t1)?((C_word*)t0)[3]:((C_word*)t0)[2]));}

/* k3395 in k3370 in %string-compare-ci in k1438 in k1435 */
static void C_fcall f_3397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare in k1438 in k1435 */
static void C_fcall f_3300(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3300,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_fixnum_difference(t4,t3);
t12=(C_word)C_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3310,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 747  %string-prefix-length */
f_2652(t13,t2,t3,t4,t5,t6,t7);}

/* k3308 in %string-compare in k1438 in k1435 */
static void f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3335,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3335(t8,((C_word*)t0)[5]);}
else{
t8=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t9=(C_word)C_i_string_ref(((C_word*)t0)[4],t8);
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t11=(C_word)C_i_string_ref(((C_word*)t0)[2],t10);
t12=(C_word)C_fixnum_lessp(t9,t11);
t13=t5;
f_3335(t13,(C_truep(t12)?((C_word*)t0)[9]:((C_word*)t0)[5]));}}}

/* k3333 in k3308 in %string-compare in k1438 in k1435 */
static void C_fcall f_3335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-ci? in k1438 in k1435 */
static void f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3178r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3178r(t0,t1,t2,t3,t4);}}

static void f_3178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[158]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[159],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[162],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3189 in string-suffix-ci? in k1438 in k1435 */
static void f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3190,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3196,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[160],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[161],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3201 in a3189 in string-suffix-ci? in k1438 in k1435 */
static void f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3202,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 731  %string-suffix-length-ci */
f_2883(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3292 in a3201 in a3189 in string-suffix-ci? in k1438 in k1435 */
static void f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3195 in a3189 in string-suffix-ci? in k1438 in k1435 */
static void f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3183 in string-suffix-ci? in k1438 in k1435 */
static void f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-ci? in k1438 in k1435 */
static void f_3148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3148r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3148r(t0,t1,t2,t3,t4);}}

static void f_3148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[152]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3154,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[153],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3160,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[156],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3159 in string-prefix-ci? in k1438 in k1435 */
static void f_3160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3160,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3166,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[154],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[155],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3171 in a3159 in string-prefix-ci? in k1438 in k1435 */
static void f_3172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3172,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 725  %string-prefix-length-ci */
f_2810(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3269 in a3171 in a3159 in string-prefix-ci? in k1438 in k1435 */
static void f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3165 in a3159 in string-prefix-ci? in k1438 in k1435 */
static void f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3153 in string-prefix-ci? in k1438 in k1435 */
static void f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix? in k1438 in k1435 */
static void f_3118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3118r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3118r(t0,t1,t2,t3,t4);}}

static void f_3118r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3124,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[147],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3130,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[150],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3129 in string-suffix? in k1438 in k1435 */
static void f_3130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3130,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3136,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[148],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[149],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3141 in a3129 in string-suffix? in k1438 in k1435 */
static void f_3142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3142,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 719  %string-suffix-length */
f_2725(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3246 in a3141 in a3129 in string-suffix? in k1438 in k1435 */
static void f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3135 in a3129 in string-suffix? in k1438 in k1435 */
static void f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3123 in string-suffix? in k1438 in k1435 */
static void f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix? in k1438 in k1435 */
static void f_3088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3088r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3088r(t0,t1,t2,t3,t4);}}

static void f_3088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[140]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[141],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3100,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[144],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3099 in string-prefix? in k1438 in k1435 */
static void f_3100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3100,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3106,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[142],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[143],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3111 in a3099 in string-prefix? in k1438 in k1435 */
static void f_3112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3112,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 712  %string-prefix-length */
f_2652(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3223 in a3111 in a3099 in string-prefix? in k1438 in k1435 */
static void f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(t1,((C_word*)t0)[2]));}

/* a3105 in a3099 in string-prefix? in k1438 in k1435 */
static void f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3093 in string-prefix? in k1438 in k1435 */
static void f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length-ci in k1438 in k1435 */
static void f_3058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3058r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3058r(t0,t1,t2,t3,t4);}}

static void f_3058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[134]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3064,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[135],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3070,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[138],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3069 in string-suffix-length-ci in k1438 in k1435 */
static void f_3070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3070,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3076,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[136],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[137],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3081 in a3069 in string-suffix-length-ci in k1438 in k1435 */
static void f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3082,4,t0,t1,t2,t3);}
/* srfi-13.scm: 676  %string-suffix-length-ci */
f_2883(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3075 in a3069 in string-suffix-length-ci in k1438 in k1435 */
static void f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3063 in string-suffix-length-ci in k1438 in k1435 */
static void f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length-ci in k1438 in k1435 */
static void f_3028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3028r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3028r(t0,t1,t2,t3,t4);}}

static void f_3028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[128]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[129],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3040,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[132],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3039 in string-prefix-length-ci in k1438 in k1435 */
static void f_3040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3040,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[130],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[131],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3051 in a3039 in string-prefix-length-ci in k1438 in k1435 */
static void f_3052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3052,4,t0,t1,t2,t3);}
/* srfi-13.scm: 671  %string-prefix-length-ci */
f_2810(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3045 in a3039 in string-prefix-length-ci in k1438 in k1435 */
static void f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3033 in string-prefix-length-ci in k1438 in k1435 */
static void f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length in k1438 in k1435 */
static void f_2998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2998r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2998r(t0,t1,t2,t3,t4);}}

static void f_2998r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[122]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[123],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3010,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[126],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3009 in string-suffix-length in k1438 in k1435 */
static void f_3010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3010,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3016,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[124],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[125],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3021 in a3009 in string-suffix-length in k1438 in k1435 */
static void f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3022,4,t0,t1,t2,t3);}
/* srfi-13.scm: 666  %string-suffix-length */
f_2725(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3015 in a3009 in string-suffix-length in k1438 in k1435 */
static void f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3003 in string-suffix-length in k1438 in k1435 */
static void f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length in k1438 in k1435 */
static void f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2968r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2968r(t0,t1,t2,t3,t4);}}

static void f_2968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[116]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2974,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[117],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2980,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[120],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a2979 in string-prefix-length in k1438 in k1435 */
static void f_2980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2980,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2986,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[118],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[119],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2991 in a2979 in string-prefix-length in k1438 in k1435 */
static void f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2992,4,t0,t1,t2,t3);}
/* srfi-13.scm: 661  %string-prefix-length */
f_2652(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2985 in a2979 in string-prefix-length in k1438 in k1435 */
static void f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2973 in string-prefix-length in k1438 in k1435 */
static void f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-suffix-length-ci in k1438 in k1435 */
static void C_fcall f_2883(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2887,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 644  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}

/* k2885 in %string-suffix-length-ci in k1438 in k1435 */
static void f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2896(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2896(t5,C_SCHEME_FALSE);}}

/* k2894 in k2885 in %string-suffix-length-ci in k1438 in k1435 */
static void C_fcall f_2896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2896,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=lf[114],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2909(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2894 in k2885 in %string-suffix-length-ci in k1438 in k1435 */
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2909,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2919(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t9=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 652  char-ci=? */
t10=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}}

/* k2942 in lp in k2894 in k2885 in %string-suffix-length-ci in k1438 in k1435 */
static void f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2919(t2,(C_word)C_i_not(t1));}

/* k2917 in lp in k2894 in k2885 in %string-suffix-length-ci in k1438 in k1435 */
static void C_fcall f_2919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 655  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2909(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length-ci in k1438 in k1435 */
static void C_fcall f_2810(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2810,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2814,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 630  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}

/* k2812 in %string-prefix-length-ci in k1438 in k1435 */
static void f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2823(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2823(t5,C_SCHEME_FALSE);}}

/* k2821 in k2812 in %string-prefix-length-ci in k1438 in k1435 */
static void C_fcall f_2823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2823,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[111],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2828(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2821 in k2812 in %string-prefix-length-ci in k1438 in k1435 */
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2828,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2838(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2859,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t9=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 638  char-ci=? */
t10=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}}

/* k2857 in lp in k2821 in k2812 in %string-prefix-length-ci in k1438 in k1435 */
static void f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2838(t2,(C_word)C_i_not(t1));}

/* k2836 in lp in k2821 in k2812 in %string-prefix-length-ci in k1438 in k1435 */
static void C_fcall f_2838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 641  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2828(t4,((C_word*)t0)[6],t2,t3);}}

/* %string-suffix-length in k1438 in k1435 */
static void C_fcall f_2725(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2725,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2729,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 616  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}

/* k2727 in %string-suffix-length in k1438 in k1435 */
static void f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2738(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2738(t5,C_SCHEME_FALSE);}}

/* k2736 in k2727 in %string-suffix-length in k1438 in k1435 */
static void C_fcall f_2738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2738,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=lf[107],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2751(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2736 in k2727 in %string-suffix-length in k1438 in k1435 */
static void C_fcall f_2751(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2751,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2761(t7,t5);}
else{
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2761(t10,(C_word)C_i_not(t9));}}

/* k2759 in lp in k2736 in k2727 in %string-suffix-length in k1438 in k1435 */
static void C_fcall f_2761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 627  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2751(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length in k1438 in k1435 */
static void C_fcall f_2652(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2652,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2656,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 602  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}

/* k2654 in %string-prefix-length in k1438 in k1435 */
static void f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2665(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2665(t5,C_SCHEME_FALSE);}}

/* k2663 in k2654 in %string-prefix-length in k1438 in k1435 */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2665,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[104],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2670(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2663 in k2654 in %string-prefix-length in k1438 in k1435 */
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2670,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2680(t7,t5);}
else{
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2680(t10,(C_word)C_i_not(t9));}}

/* k2678 in lp in k2663 in k2654 in %string-prefix-length in k1438 in k1435 */
static void C_fcall f_2680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 613  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2670(t4,((C_word*)t0)[6],t2,t3);}}

/* string-tabulate in k1438 in k1435 */
static void f_2613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2613,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[100]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2620,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 584  make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k2618 in string-tabulate in k1438 in k1435 */
static void f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=lf[101],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2629(t7,t2,t3);}

/* do265 in k2618 in string-tabulate in k1438 in k1435 */
static void C_fcall f_2629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2629,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2650,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 587  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2648 in do265 in k2618 in string-tabulate in k1438 in k1435 */
static void f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2629(t4,((C_word*)t0)[2],t3);}

/* k2621 in k2618 in string-tabulate in k1438 in k1435 */
static void f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-any in k1438 in k1435 */
static void f_2483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2483r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2483r(t0,t1,t2,t3,t4);}}

static void f_2483r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2489,a[2]=t4,a[3]=t3,a[4]=lf[93],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=t3,a[3]=t2,a[4]=lf[98],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2494 in string-any in k1438 in k1435 */
static void f_2495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2495,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[94],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2507(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2537,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 561  char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2535 in a2494 in string-any in k1438 in k1435 */
static void f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[95],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2542(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2583,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=lf[96],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2583(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
/* srfi-13.scm: 575  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[92],lf[97],*((C_word*)lf[92]+1),((C_word*)t0)[4]);}}}

/* lp in k2535 in a2494 in string-any in k1438 in k1435 */
static void C_fcall f_2583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2583,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 572  criteria */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 573  criteria */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2600 in lp in k2535 in a2494 in string-any in k1438 in k1435 */
static void f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-13.scm: 573  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2583(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* lp in k2535 in a2494 in string-any in k1438 in k1435 */
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2542,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 564  char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k2550 in lp in k2535 in a2494 in string-any in k1438 in k1435 */
static void f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 565  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2542(t3,((C_word*)t0)[4],t2);}}

/* lp in a2494 in string-any in k1438 in k1435 */
static C_word C_fcall f_2507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a2488 in string-any in k1438 in k1435 */
static void f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-every in k1438 in k1435 */
static void f_2353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2353r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2353r(t0,t1,t2,t3,t4);}}

static void f_2353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2359,a[2]=t4,a[3]=t3,a[4]=lf[83],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2365,a[2]=t3,a[3]=t2,a[4]=lf[90],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2364 in string-every in k1438 in k1435 */
static void f_2365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2365,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[84],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2377(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2407,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 535  char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2405 in a2364 in string-every in k1438 in k1435 */
static void f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[86],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2412(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2453,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=lf[87],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2453(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 549  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[82],lf[88],*((C_word*)lf[82]+1),((C_word*)t0)[4]);}}}

/* lp in k2405 in a2364 in string-every in k1438 in k1435 */
static void C_fcall f_2453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2453,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 546  criteria */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2475,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 547  criteria */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2473 in lp in k2405 in a2364 in string-every in k1438 in k1435 */
static void f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 547  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2453(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in k2405 in a2364 in string-every in k1438 in k1435 */
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2412,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
t5=(C_word)C_fixnum_greater_or_equal_p(t3,t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2425,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 538  char-set-contains? */
t8=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2423 in lp in k2405 in a2364 in string-every in k1438 in k1435 */
static void f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 539  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2412(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in a2364 in string-every in k1438 in k1435 */
static C_word C_fcall f_2377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_greater_or_equal_p(t2,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a2358 in string-every in k1438 in k1435 */
static void f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each-index in k1438 in k1435 */
static void f_2316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_2316r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2316r(t0,t1,t2,t3,t4);}}

static void f_2316r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2322,a[2]=t4,a[3]=t3,a[4]=lf[78],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=t2,a[3]=lf[80],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2327 in string-for-each-index in k1438 in k1435 */
static void f_2328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2328,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=lf[79],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2334(t7,t1,t2);}

/* lp in a2327 in string-for-each-index in k1438 in k1435 */
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2334,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 525  proc */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2342 in lp in a2327 in string-for-each-index in k1438 in k1435 */
static void f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 525  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2334(t3,((C_word*)t0)[2],t2);}

/* a2321 in string-for-each-index in k1438 in k1435 */
static void f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each in k1438 in k1435 */
static void f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2275r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2275r(t0,t1,t2,t3,t4);}}

static void f_2275r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2281,a[2]=t4,a[3]=t3,a[4]=lf[73],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2287,a[2]=t2,a[3]=t3,a[4]=lf[75],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2286 in string-for-each in k1438 in k1435 */
static void f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2287,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=lf[74],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2293(t7,t1,t2);}

/* lp in a2286 in string-for-each in k1438 in k1435 */
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2303,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 518  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2301 in lp in a2286 in string-for-each in k1438 in k1435 */
static void f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 519  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2293(t3,((C_word*)t0)[2],t2);}

/* a2280 in string-for-each in k1438 in k1435 */
static void f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-unfold-right in k1438 in k1435 */
static void f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_2086r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2086r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_2086r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[65]:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2112,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 471  make-string */
t16=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_fix(40));}
else{
/* ##sys#error */
t15=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k2110 in string-unfold-right in k1438 in k1435 */
static void f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=lf[70],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2114(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(40),((C_word*)t0)[2]);}

/* lp in k2110 in string-unfold-right in k1438 in k1435 */
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2114,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t2,a[10]=t3,a[11]=t5,a[12]=((C_word*)t0)[7],a[13]=lf[69],tmp=(C_word)a,a+=14,tmp));
t11=((C_word*)t9)[1];
f_2120(t11,t1,t6,t7);}

/* lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 476  p */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 493  make-final */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 477  f */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k2128 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 478  g */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2131 in k2128 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=((C_word*)t0)[10];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_i_string_set(((C_word*)t0)[9],t3,((C_word*)t0)[8]);
/* srfi-13.scm: 482  lp2 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2120(t5,((C_word*)t0)[6],t3,t1);}
else{
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2154,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 485  min */
t5=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(4096),t3);}}

/* k2152 in k2131 in k2128 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 486  make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2155 in k2152 in k2131 in k2128 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2157,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_i_string_set(t1,t2,((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 489  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2114(t6,((C_word*)t0)[3],t4,t5,t1,((C_word*)t0)[10],t2,((C_word*)t0)[2]);}

/* k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_i_string_length(((C_word*)t0)[8]);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(t3,((C_word*)t0)[5]),t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2192,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_fixnum_plus(t5,t2);
/* srfi-13.scm: 498  make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 499  %string-copy! */
f_5737(t2,t1,C_fix(0),((C_word*)t0)[2],C_fix(0),((C_word*)t0)[10]);}

/* k2193 in k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 500  %string-copy! */
f_5737(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2196 in k2193 in k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=lf[68],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2207(t7,t2,t3,((C_word*)t0)[2]);}

/* lp in k2196 in k2193 in k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2207,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2226,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 507  %string-copy! */
f_5737(t7,((C_word*)t0)[4],t2,t4,C_fix(0),t6);}
else{
/* srfi-13.scm: 509  %string-copy! */
f_5737(t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}}

/* k2224 in lp in k2196 in k2193 in k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 508  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2207(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2199 in k2196 in k2193 in k2190 in k2175 in k2242 in lp2 in lp in k2110 in string-unfold-right in k1438 in k1435 */
static void f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2257 in string-unfold-right in k1438 in k1435 */
static void f_2257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2257,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[66]);}

/* string-unfold in k1438 in k1435 */
static void f_1904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_1904r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1904r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_1904r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[55]:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1930,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 426  make-string */
t16=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_fix(40));}
else{
/* ##sys#error */
t15=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k1928 in string-unfold in k1438 in k1435 */
static void f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=lf[62],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1932(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(0),((C_word*)t0)[2]);}

/* lp in k1928 in string-unfold in k1438 in k1435 */
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1932,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t2,a[11]=t3,a[12]=((C_word*)t0)[7],a[13]=lf[61],tmp=(C_word)a,a+=14,tmp));
t11=((C_word*)t9)[1];
f_1938(t11,t1,t6,t7);}

/* lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void C_fcall f_1938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1938,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 431  p */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 446  make-final */
t3=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 432  f */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k1946 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 433  g */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1949 in k1946 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_set(((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* srfi-13.scm: 436  lp2 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_1938(t6,((C_word*)t0)[5],t5,t1);}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1973,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 439  min */
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(4096),t4);}}

/* k1971 in k1949 in k1946 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 440  make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1974 in k1971 in k1949 in k1946 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(C_word)C_i_string_set(t1,C_fix(0),((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],((C_word*)t0)[6]);
/* srfi-13.scm: 442  lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1932(t5,((C_word*)t0)[4],t3,t4,t1,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_i_string_length(((C_word*)t0)[7]);
t4=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(t3,((C_word*)t0)[6]),((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2005,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_fixnum_plus(t4,t2);
/* srfi-13.scm: 450  make-string */
t7=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 451  %string-copy! */
f_5737(t2,t1,((C_word*)t0)[10],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 453  %string-copy! */
f_5737(t3,((C_word*)t0)[6],t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[8]);}

/* k2012 in k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=lf[59],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2022(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k2012 in k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void C_fcall f_2022(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2022,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(C_word)C_fixnum_difference(t2,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2044,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 460  %string-copy! */
f_5737(t8,((C_word*)t0)[2],t7,t4,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2042 in lp in k2012 in k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 461  lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2022(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2015 in k2012 in k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 462  %string-copy! */
f_5737(t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k2018 in k2015 in k2012 in k2006 in k2003 in k1991 in k2053 in lp2 in lp in k1928 in string-unfold in k1438 in k1435 */
static void f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2068 in string-unfold in k1438 in k1435 */
static void f_2068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[56]);}

/* string-fold-right in k1438 in k1435 */
static void f_1858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_1858r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1858r(t0,t1,t2,t3,t4,t5);}}

static void f_1858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1864,a[2]=t5,a[3]=t4,a[4]=lf[50],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1870,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[52],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a1869 in string-fold-right in k1438 in k1435 */
static void f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1870,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t2,a[6]=lf[51],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1880(t8,t1,((C_word*)t0)[2],t4);}

/* lp in a1869 in string-fold-right in k1438 in k1435 */
static void C_fcall f_1880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1880,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
/* srfi-13.scm: 351  kons */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1892 in lp in a1869 in string-fold-right in k1438 in k1435 */
static void f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 351  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1880(t3,((C_word*)t0)[2],t1,t2);}

/* a1863 in string-fold-right in k1438 in k1435 */
static void f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[49]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fold in k1438 in k1435 */
static void f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_1816r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1816r(t0,t1,t2,t3,t4,t5);}}

static void f_1816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1822,a[2]=t5,a[3]=t4,a[4]=lf[45],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1828,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[47],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a1827 in string-fold in k1438 in k1435 */
static void f_1828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1828,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,a[6]=lf[46],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1834(t7,t1,((C_word*)t0)[2],t2);}

/* lp in a1827 in string-fold in k1438 in k1435 */
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1848,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
/* srfi-13.scm: 344  kons */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1846 in lp in a1827 in string-fold in k1438 in k1435 */
static void f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 344  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1834(t3,((C_word*)t0)[2],t1,t2);}

/* a1821 in string-fold in k1438 in k1435 */
static void f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[44]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map! in k1438 in k1435 */
static void C_fcall f_1779(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1779,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_fixnum_difference(t5,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1789,a[2]=t2,a[3]=t8,a[4]=t3,a[5]=t4,a[6]=lf[42],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1789(t10,t1,t6);}

/* do71 in %string-map! in k1438 in k1435 */
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1789,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1810,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
/* srfi-13.scm: 338  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k1808 in do71 in %string-map! in k1438 in k1435 */
static void f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1789(t4,((C_word*)t0)[2],t3);}

/* string-map! in k1438 in k1435 */
static void f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1761r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1761r(t0,t1,t2,t3,t4);}}

static void f_1761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1767,a[2]=t4,a[3]=t3,a[4]=lf[38],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1773,a[2]=t3,a[3]=t2,a[4]=lf[40],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1772 in string-map! in k1438 in k1435 */
static void f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1773,4,t0,t1,t2,t3);}
/* srfi-13.scm: 333  %string-map! */
f_1779(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1766 in string-map! in k1438 in k1435 */
static void f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map in k1438 in k1435 */
static void C_fcall f_1710(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1710,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_fixnum_difference(t5,t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 323  make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}

/* k1715 in %string-map in k1438 in k1435 */
static void f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1720,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,a[6]=lf[34],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1730(t8,t2,t3,t4);}

/* do55 in k1715 in %string-map in k1438 in k1435 */
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1755,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 327  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k1753 in do55 in k1715 in %string-map in k1438 in k1435 */
static void f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_1730(t5,((C_word*)t0)[2],t3,t4);}

/* k1718 in k1715 in %string-map in k1438 in k1435 */
static void f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-map in k1438 in k1435 */
static void f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1692r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1692r(t0,t1,t2,t3,t4);}}

static void f_1692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1698,a[2]=t4,a[3]=t3,a[4]=lf[30],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1704,a[2]=t3,a[3]=t2,a[4]=lf[32],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1703 in string-map in k1438 in k1435 */
static void f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1704,4,t0,t1,t2,t3);}
/* srfi-13.scm: 319  %string-map */
f_1710(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1697 in string-map in k1438 in k1435 */
static void f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy in k1438 in k1435 */
static void f_1674(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_1674r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1674r(t0,t1,t2,t3);}}

static void f_1674r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1680,a[2]=t3,a[3]=t2,a[4]=lf[26],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=t2,a[3]=lf[27],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1685 in string-copy in k1438 in k1435 */
static void f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1686,4,t0,t1,t2,t3);}
/* srfi-13.scm: 286  ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a1679 in string-copy in k1438 in k1435 */
static void f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %substring/shared in k1438 in k1435 */
static void C_fcall f_1652(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1652,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1659,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_i_string_length(t2);
t8=t4;
t9=t5;
f_1659(t9,(C_word)C_eqp(t8,t7));}
else{
t7=t5;
f_1659(t7,C_SCHEME_FALSE);}}

/* k1657 in %substring/shared in k1438 in k1435 */
static void C_fcall f_1659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 282  ##sys#substring */
t2=*((C_word*)lf[23]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring/shared in k1438 in k1435 */
static void f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1618r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1618r(t0,t1,t2,t3,t4);}}

static void f_1618r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_string_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1625,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_1625(2,t7,t5);}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1625(2,t8,(C_word)C_i_car(t4));}
else{
/* srfi-13.scm: 266  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1623 in substring/shared in k1438 in k1435 */
static void f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(t1,lf[20]);
/* srfi-13.scm: 268  %substring/shared */
f_1652(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* check-substring-spec in k1438 in k1435 */
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1602,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1616,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 236  substring-spec-ok? */
t7=*((C_word*)lf[15]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,t5);}

/* k1614 in check-substring-spec in k1438 in k1435 */
static void f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* srfi-13.scm: 237  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[6],lf[17],lf[18],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring-spec-ok? in k1438 in k1435 */
static void f_1562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1562,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_stringp(t2))){
if(C_truep((C_word)C_fixnump(t3))){
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t5))){
t6=t3;
t7=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=(C_word)C_i_string_length(t2);
t9=t4;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_fixnum_less_or_equal_p(t9,t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* string-parse-final-start+end in k1438 in k1435 */
static void f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1535,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1541,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=lf[11],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1547,a[2]=t2,a[3]=lf[13],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1546 in string-parse-final-start+end in k1438 in k1435 */
static void f_1547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1547,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
/* srfi-13.scm: 220  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[10],lf[12],((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 221  values */
C_values(4,0,t1,t3,t4);}}

/* a1540 in string-parse-final-start+end in k1438 in k1435 */
static void f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1541,2,t0,t1);}
/* srfi-13.scm: 219  string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-parse-start+end in k1438 in k1435 */
static void f_1442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1442,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,lf[2]);
t6=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=(C_word)C_i_cdr(t4);
t9=(C_truep((C_word)C_fixnump(t7))?(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1472,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t8,a[6]=lf[5],tmp=(C_word)a,a+=7,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1508,a[2]=t3,a[3]=t2,a[4]=t7,a[5]=lf[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 202  ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}
else{
/* srfi-13.scm: 214  ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t1,lf[2],lf[8],t2,t7,t3);}}
else{
/* srfi-13.scm: 216  values */
C_values(5,0,t1,C_SCHEME_END_OF_LIST,C_fix(0),t6);}}

/* a1507 in string-parse-start+end in k1438 in k1435 */
static void f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1508,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t4))){
/* srfi-13.scm: 211  values */
C_values(5,0,t1,t3,((C_word*)t0)[4],t2);}
else{
/* srfi-13.scm: 212  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t1,lf[2],lf[6],((C_word*)t0)[3],((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* a1471 in string-parse-start+end in k1438 in k1435 */
static void f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_truep((C_word)C_fixnump(t2))?(C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-13.scm: 208  values */
C_values(4,0,t1,t2,t3);}
else{
/* srfi-13.scm: 209  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[2],lf[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 210  values */
C_values(4,0,t1,((C_word*)t0)[4],((C_word*)t0)[5]);}}
/* end of file */
