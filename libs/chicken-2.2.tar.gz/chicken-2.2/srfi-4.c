/* Generated from srfi-4.scm by the Chicken compiler
   2005-08-24 19:37
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-4.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file srfi-4.c -explicit-use
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)


static C_TLS C_word lf[265];


/* from ext-free in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub160(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub160(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_return:
#undef return

return C_r;}

/* from k1035 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_return:
#undef return

return C_r;}

C_externexport void C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_795(C_word c,C_word t0,C_word t1) C_noret;
static void f_799(C_word c,C_word t0,C_word t1) C_noret;
static void f_803(C_word c,C_word t0,C_word t1) C_noret;
static void f_807(C_word c,C_word t0,C_word t1) C_noret;
static void f_811(C_word c,C_word t0,C_word t1) C_noret;
static void f_815(C_word c,C_word t0,C_word t1) C_noret;
static void f_819(C_word c,C_word t0,C_word t1) C_noret;
static void f_823(C_word c,C_word t0,C_word t1) C_noret;
static void f_971(C_word c,C_word t0,C_word t1) C_noret;
static void f_975(C_word c,C_word t0,C_word t1) C_noret;
static void f_979(C_word c,C_word t0,C_word t1) C_noret;
static void f_983(C_word c,C_word t0,C_word t1) C_noret;
static void f_987(C_word c,C_word t0,C_word t1) C_noret;
static void f_991(C_word c,C_word t0,C_word t1) C_noret;
static void f_995(C_word c,C_word t0,C_word t1) C_noret;
static void f_999(C_word c,C_word t0,C_word t1) C_noret;
static void f_1003(C_word c,C_word t0,C_word t1) C_noret;
static void f_1007(C_word c,C_word t0,C_word t1) C_noret;
static void f_1011(C_word c,C_word t0,C_word t1) C_noret;
static void f_1015(C_word c,C_word t0,C_word t1) C_noret;
static void f_1027(C_word c,C_word t0,C_word t1) C_noret;
static void f_1031(C_word c,C_word t0,C_word t1) C_noret;
static void f_2097(C_word c,C_word t0,C_word t1) C_noret;
static void f_2101(C_word c,C_word t0,C_word t1) C_noret;
static void f_2105(C_word c,C_word t0,C_word t1) C_noret;
static void f_2109(C_word c,C_word t0,C_word t1) C_noret;
static void f_2113(C_word c,C_word t0,C_word t1) C_noret;
static void f_2117(C_word c,C_word t0,C_word t1) C_noret;
static void f_2121(C_word c,C_word t0,C_word t1) C_noret;
static void f_2125(C_word c,C_word t0,C_word t1) C_noret;
static void f_2212(C_word c,C_word t0,C_word t1) C_noret;
static void f_2216(C_word c,C_word t0,C_word t1) C_noret;
static void f_2220(C_word c,C_word t0,C_word t1) C_noret;
static void f_2224(C_word c,C_word t0,C_word t1) C_noret;
static void f_2228(C_word c,C_word t0,C_word t1) C_noret;
static void f_2232(C_word c,C_word t0,C_word t1) C_noret;
static void f_2236(C_word c,C_word t0,C_word t1) C_noret;
static void f_2240(C_word c,C_word t0,C_word t1) C_noret;
static void f_2327(C_word c,C_word t0,C_word t1) C_noret;
static void f_2331(C_word c,C_word t0,C_word t1) C_noret;
static void f_2335(C_word c,C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1) C_noret;
static void f_2343(C_word c,C_word t0,C_word t1) C_noret;
static void f_2347(C_word c,C_word t0,C_word t1) C_noret;
static void f_2351(C_word c,C_word t0,C_word t1) C_noret;
static void f_2355(C_word c,C_word t0,C_word t1) C_noret;
static void f_2359(C_word c,C_word t0,C_word t1) C_noret;
static void f_2363(C_word c,C_word t0,C_word t1) C_noret;
static void f_2367(C_word c,C_word t0,C_word t1) C_noret;
static void f_2371(C_word c,C_word t0,C_word t1) C_noret;
static void f_2375(C_word c,C_word t0,C_word t1) C_noret;
static void f_2379(C_word c,C_word t0,C_word t1) C_noret;
static void f_2383(C_word c,C_word t0,C_word t1) C_noret;
static void f_2387(C_word c,C_word t0,C_word t1) C_noret;
static void f_2600(C_word c,C_word t0,C_word t1) C_noret;
static void f_2593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2529(C_word c,C_word t0,C_word t1) C_noret;
static void f_2532(C_word c,C_word t0,C_word t1) C_noret;
static void f_2538(C_word c,C_word t0,C_word t1) C_noret;
static void f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2458(C_word c,C_word t0,C_word t1) C_noret;
static void f_2461(C_word c,C_word t0,C_word t1) C_noret;
static void f_2468(C_word c,C_word t0,C_word t1) C_noret;
static void f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2402(C_word c,C_word t0,C_word t1) C_noret;
static void f_2427(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2298(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2323(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2313(C_word t0,C_word t1) C_noret;
static void C_fcall f_2290(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2175(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2181(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2186(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2200(C_word c,C_word t0,C_word t1) C_noret;
static void f_2204(C_word c,C_word t0,C_word t1) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2169r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2163(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2163r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2157(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2157r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2151(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2151r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2145r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2139(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2139r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2133(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2133r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2127(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2127r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2069(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2081(C_word c,C_word t0,C_word t1) C_noret;
static void f_1930(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1930r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1994(C_word t0,C_word t1) C_noret;
static void C_fcall f_1989(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1984(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1983(C_word c,C_word t0,C_word t1) C_noret;
static void f_1942(C_word c,C_word t0,C_word t1) C_noret;
static void f_1973(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1954(C_word t0,C_word t1) C_noret;
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1) C_noret;
static void f_1803(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1803r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1867(C_word t0,C_word t1) C_noret;
static void C_fcall f_1862(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1856(C_word c,C_word t0,C_word t1) C_noret;
static void f_1815(C_word c,C_word t0,C_word t1) C_noret;
static void f_1846(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1827(C_word t0,C_word t1) C_noret;
static void C_fcall f_1832(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1839(C_word c,C_word t0,C_word t1) C_noret;
static void f_1683(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1683r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1740(C_word t0,C_word t1) C_noret;
static void C_fcall f_1735(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1729(C_word c,C_word t0,C_word t1) C_noret;
static void f_1695(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1709(C_word t0,C_word t1);
static void f_1563(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1563r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1620(C_word t0,C_word t1) C_noret;
static void C_fcall f_1615(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1610(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1565(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1609(C_word c,C_word t0,C_word t1) C_noret;
static void f_1575(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1589(C_word t0,C_word t1);
static void f_1443(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1443r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1500(C_word t0,C_word t1) C_noret;
static void C_fcall f_1495(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1490(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1489(C_word c,C_word t0,C_word t1) C_noret;
static void f_1455(C_word c,C_word t0,C_word t1) C_noret;
static void f_1464(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1469(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1476(C_word c,C_word t0,C_word t1) C_noret;
static void f_1323(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1323r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1380(C_word t0,C_word t1) C_noret;
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1369(C_word c,C_word t0,C_word t1) C_noret;
static void f_1335(C_word c,C_word t0,C_word t1) C_noret;
static void f_1344(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1356(C_word c,C_word t0,C_word t1) C_noret;
static void f_1203(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1203r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1260(C_word t0,C_word t1) C_noret;
static void C_fcall f_1255(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1249(C_word c,C_word t0,C_word t1) C_noret;
static void f_1215(C_word c,C_word t0,C_word t1) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1229(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1236(C_word c,C_word t0,C_word t1) C_noret;
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1083r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1140(C_word t0,C_word t1) C_noret;
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1130(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1085(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1129(C_word c,C_word t0,C_word t1) C_noret;
static void f_1095(C_word c,C_word t0,C_word t1) C_noret;
static void f_1104(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1109(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1116(C_word c,C_word t0,C_word t1) C_noret;
static void f_1058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1065(C_word t0,C_word t1) C_noret;
static void C_fcall f_1040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1056(C_word c,C_word t0,C_word t1) C_noret;
static void f_1038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_888(C_word c,C_word t0,C_word t1) C_noret;
static void f_891(C_word c,C_word t0,C_word t1) C_noret;
static void f_894(C_word c,C_word t0,C_word t1) C_noret;
static void f_911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_915(C_word c,C_word t0,C_word t1) C_noret;
static void f_918(C_word c,C_word t0,C_word t1) C_noret;
static void f_921(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_945(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_951(C_word c,C_word t0,C_word t1) C_noret;
static void f_957(C_word c,C_word t0,C_word t1) C_noret;
static void f_964(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_862(C_word c,C_word t0,C_word t1) C_noret;
static void f_868(C_word c,C_word t0,C_word t1) C_noret;
static void f_871(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_845(C_word c,C_word t0,C_word t1) C_noret;
static void f_851(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_831(C_word c,C_word t0,C_word t1) C_noret;
static void f_834(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_782(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static C_word C_fcall f_773(C_word t0,C_word t1,C_word t2);
static C_word C_fcall f_770(C_word t0,C_word t1,C_word t2);
static void f_767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

static void C_fcall trf_2516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2516(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2516(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2298(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2298(t0,t1,t2,t3);}

static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2313(t0,t1);}

static void C_fcall trf_2290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2290(t0,t1,t2);}

static void C_fcall trf_2175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2175(t0,t1,t2);}

static void C_fcall trf_2186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2186(t0,t1,t2);}

static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2057(t0,t1,t2,t3);}

static void C_fcall trf_2074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2074(t0,t1,t2,t3);}

static void C_fcall trf_1994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1994(t0,t1);}

static void C_fcall trf_1989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1989(t0,t1,t2);}

static void C_fcall trf_1984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1984(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1984(t0,t1,t2,t3);}

static void C_fcall trf_1932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1932(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1932(t0,t1,t2,t3);}

static void C_fcall trf_1954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1954(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1954(t0,t1);}

static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1959(t0,t1,t2);}

static void C_fcall trf_1867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1867(t0,t1);}

static void C_fcall trf_1862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1862(t0,t1,t2);}

static void C_fcall trf_1857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1857(t0,t1,t2,t3);}

static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1805(t0,t1,t2,t3);}

static void C_fcall trf_1827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1827(t0,t1);}

static void C_fcall trf_1832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1832(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1832(t0,t1,t2);}

static void C_fcall trf_1740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1740(t0,t1);}

static void C_fcall trf_1735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1735(t0,t1,t2);}

static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1730(t0,t1,t2,t3);}

static void C_fcall trf_1685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1685(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1685(t0,t1,t2,t3);}

static void C_fcall trf_1620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1620(t0,t1);}

static void C_fcall trf_1615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1615(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1615(t0,t1,t2);}

static void C_fcall trf_1610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1610(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1610(t0,t1,t2,t3);}

static void C_fcall trf_1565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1565(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1565(t0,t1,t2,t3);}

static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1500(t0,t1);}

static void C_fcall trf_1495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1495(t0,t1,t2);}

static void C_fcall trf_1490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1490(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1490(t0,t1,t2,t3);}

static void C_fcall trf_1445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1445(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1445(t0,t1,t2,t3);}

static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1469(t0,t1,t2);}

static void C_fcall trf_1380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1380(t0,t1);}

static void C_fcall trf_1375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1375(t0,t1,t2);}

static void C_fcall trf_1370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1370(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1370(t0,t1,t2,t3);}

static void C_fcall trf_1325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1325(t0,t1,t2,t3);}

static void C_fcall trf_1349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1349(t0,t1,t2);}

static void C_fcall trf_1260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1260(t0,t1);}

static void C_fcall trf_1255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1255(t0,t1,t2);}

static void C_fcall trf_1250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1250(t0,t1,t2,t3);}

static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1205(t0,t1,t2,t3);}

static void C_fcall trf_1229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1229(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1229(t0,t1,t2);}

static void C_fcall trf_1140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1140(t0,t1);}

static void C_fcall trf_1135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1135(t0,t1,t2);}

static void C_fcall trf_1130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1130(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1130(t0,t1,t2,t3);}

static void C_fcall trf_1085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1085(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1085(t0,t1,t2,t3,t4);}

static void C_fcall trf_1109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1109(t0,t1,t2);}

static void C_fcall trf_1065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1065(t0,t1);}

static void C_fcall trf_1040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1040(t0,t1,t2,t3);}

static void C_fcall trf_945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_945(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_945(t0,t1,t2,t3);}

static void C_fcall trf_856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_856(t0,t1,t2,t3);}

static void C_fcall trf_839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_839(t0,t1,t2,t3);}

static void C_fcall trf_825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_825(t0,t1,t2,t3);}

static void C_fcall trf_782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_782(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_782(t0,t1,t2,t3);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(61);
if(!C_demand(61)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1140)){
C_save(t1);
C_rereclaim2(1140*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(61);
C_initialize_lf(lf,265);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,38,"numeric value is not in expected range");
lf[5]=C_static_lambda_info(C_heaptop,46,"(##sys#check-exact-interval n2 from3 to4 loc5)");
lf[6]=C_h_intern(&lf[6],26,"\003syscheck-inexact-interval");
lf[7]=C_static_string(C_heaptop,38,"numeric value is not in expected range");
lf[8]=C_static_lambda_info(C_heaptop,51,"(##sys#check-inexact-interval n9 from10 to11 loc12)");
lf[10]=C_static_lambda_info(C_heaptop,28,"(##sys#u8vector-ref v16 i17)");
lf[12]=C_static_lambda_info(C_heaptop,28,"(##sys#s8vector-ref v18 i19)");
lf[14]=C_static_lambda_info(C_heaptop,29,"(##sys#u16vector-ref v20 i21)");
lf[16]=C_static_lambda_info(C_heaptop,29,"(##sys#s16vector-ref v22 i23)");
lf[18]=C_static_lambda_info(C_heaptop,29,"(##sys#u32vector-ref v24 i25)");
lf[20]=C_static_lambda_info(C_heaptop,29,"(##sys#s32vector-ref v26 i27)");
lf[22]=C_h_intern(&lf[22],15,"\003syscons-flonum");
lf[23]=C_static_lambda_info(C_heaptop,29,"(##sys#f32vector-ref v28 i29)");
lf[25]=C_static_lambda_info(C_heaptop,29,"(##sys#f64vector-ref v31 i32)");
lf[27]=C_static_lambda_info(C_heaptop,33,"(##sys#u8vector-set! v34 i35 x36)");
lf[29]=C_static_lambda_info(C_heaptop,33,"(##sys#s8vector-set! v37 i38 x39)");
lf[31]=C_static_lambda_info(C_heaptop,34,"(##sys#u16vector-set! v40 i41 x42)");
lf[33]=C_static_lambda_info(C_heaptop,34,"(##sys#s16vector-set! v43 i44 x45)");
lf[35]=C_static_lambda_info(C_heaptop,30,"(##sys#u32vector-set! i47 x48)");
lf[37]=C_static_lambda_info(C_heaptop,30,"(##sys#s32vector-set! i50 x51)");
lf[39]=C_static_lambda_info(C_heaptop,34,"(##sys#f32vector-set! v52 i53 x54)");
lf[41]=C_static_lambda_info(C_heaptop,34,"(##sys#f64vector-set! v55 i56 x57)");
lf[42]=C_static_lambda_info(C_heaptop,11,"(f_784 v62)");
lf[43]=C_static_lambda_info(C_heaptop,25,"(len tag59 shift60 loc61)");
lf[44]=C_h_intern(&lf[44],15,"u8vector-length");
lf[45]=C_h_intern(&lf[45],15,"s8vector-length");
lf[46]=C_h_intern(&lf[46],16,"u16vector-length");
lf[47]=C_h_intern(&lf[47],16,"s16vector-length");
lf[48]=C_h_intern(&lf[48],16,"u32vector-length");
lf[49]=C_h_intern(&lf[49],16,"s32vector-length");
lf[50]=C_h_intern(&lf[50],16,"f32vector-length");
lf[51]=C_h_intern(&lf[51],16,"f64vector-length");
lf[52]=C_h_intern(&lf[52],15,"\003syscheck-range");
lf[53]=C_static_lambda_info(C_heaptop,15,"(f_827 v82 i83)");
lf[54]=C_static_lambda_info(C_heaptop,26,"(get length79 acc80 loc81)");
lf[55]=C_static_lambda_info(C_heaptop,19,"(f_841 v89 i90 x91)");
lf[56]=C_static_lambda_info(C_heaptop,26,"(set length86 upd87 loc88)");
lf[57]=C_static_string(C_heaptop,28,"argument may not be negative");
lf[58]=C_static_lambda_info(C_heaptop,20,"(f_858 v98 i99 x100)");
lf[59]=C_static_lambda_info(C_heaptop,27,"(setu length95 upd96 loc97)");
lf[60]=C_static_lambda_info(C_heaptop,22,"(f_947 v126 i127 x128)");
lf[61]=C_static_lambda_info(C_heaptop,30,"(setf length123 upd124 loc125)");
lf[62]=C_h_intern(&lf[62],12,"u8vector-ref");
lf[63]=C_h_intern(&lf[63],12,"s8vector-ref");
lf[64]=C_h_intern(&lf[64],13,"u16vector-ref");
lf[65]=C_h_intern(&lf[65],13,"s16vector-ref");
lf[66]=C_h_intern(&lf[66],13,"u32vector-ref");
lf[67]=C_h_intern(&lf[67],13,"s32vector-ref");
lf[68]=C_h_intern(&lf[68],13,"f32vector-ref");
lf[69]=C_h_intern(&lf[69],13,"f64vector-ref");
lf[70]=C_h_intern(&lf[70],13,"u8vector-set!");
lf[71]=C_h_intern(&lf[71],13,"s8vector-set!");
lf[72]=C_h_intern(&lf[72],14,"u16vector-set!");
lf[73]=C_h_intern(&lf[73],14,"s16vector-set!");
lf[74]=C_h_intern(&lf[74],14,"u32vector-set!");
lf[75]=C_static_string(C_heaptop,28,"argument may not be negative");
lf[76]=C_static_string(C_heaptop,30,"argument exceeds integer range");
lf[77]=C_static_lambda_info(C_heaptop,22,"(f_911 v117 i118 x119)");
lf[78]=C_h_intern(&lf[78],14,"s32vector-set!");
lf[79]=C_static_string(C_heaptop,30,"argument exceeds integer range");
lf[80]=C_static_lambda_info(C_heaptop,22,"(f_884 v108 i109 x110)");
lf[81]=C_h_intern(&lf[81],14,"f32vector-set!");
lf[82]=C_h_intern(&lf[82],14,"f64vector-set!");
lf[83]=C_static_lambda_info(C_heaptop,18,"(ext-free a159162)");
lf[84]=C_h_intern(&lf[84],14,"set-finalizer!");
lf[85]=C_static_string(C_heaptop,59,"not enough memory - can not allocate external number vector");
lf[86]=C_h_intern(&lf[86],19,"\003sysallocate-vector");
lf[87]=C_static_lambda_info(C_heaptop,29,"(alloc loc165 len166 ext\077167)");
lf[88]=C_h_intern(&lf[88],21,"release-number-vector");
lf[89]=C_static_string(C_heaptop,39,"bad argument type - not a number vector");
tmp=C_intern(C_heaptop,8,"u8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"s8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f64vector");
C_save(tmp);
lf[90]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[91]=C_static_lambda_info(C_heaptop,28,"(release-number-vector v173)");
lf[92]=C_h_intern(&lf[92],13,"make-u8vector");
lf[93]=C_h_intern(&lf[93],8,"u8vector");
lf[94]=C_static_lambda_info(C_heaptop,12,"(do191 i193)");
lf[95]=C_static_lambda_info(C_heaptop,33,"(body180 init187 ext\077188 fin\077189)");
lf[96]=C_static_lambda_info(C_heaptop,37,"(def-fin\077184 %init177200 %ext\077178201)");
lf[97]=C_static_lambda_info(C_heaptop,25,"(def-ext\077183 %init177203)");
lf[98]=C_static_lambda_info(C_heaptop,13,"(def-init182)");
lf[99]=C_static_lambda_info(C_heaptop,32,"(make-u8vector len175 . g174176)");
lf[100]=C_h_intern(&lf[100],13,"make-s8vector");
lf[101]=C_h_intern(&lf[101],8,"s8vector");
lf[102]=C_static_lambda_info(C_heaptop,12,"(do229 i231)");
lf[103]=C_h_intern(&lf[103],4,"fin\077");
lf[104]=C_static_lambda_info(C_heaptop,25,"(body218 init225 ext\077226)");
lf[105]=C_static_lambda_info(C_heaptop,36,"(def-fin222 %init215238 %ext\077216239)");
lf[106]=C_static_lambda_info(C_heaptop,25,"(def-ext\077221 %init215241)");
lf[107]=C_static_lambda_info(C_heaptop,13,"(def-init220)");
lf[108]=C_static_lambda_info(C_heaptop,32,"(make-s8vector len213 . g212214)");
lf[109]=C_h_intern(&lf[109],14,"make-u16vector");
lf[110]=C_h_intern(&lf[110],9,"u16vector");
lf[111]=C_static_lambda_info(C_heaptop,12,"(do266 i268)");
lf[112]=C_static_lambda_info(C_heaptop,25,"(body255 init262 ext\077263)");
lf[113]=C_static_lambda_info(C_heaptop,36,"(def-fin259 %init252275 %ext\077253276)");
lf[114]=C_static_lambda_info(C_heaptop,25,"(def-ext\077258 %init252278)");
lf[115]=C_static_lambda_info(C_heaptop,13,"(def-init257)");
lf[116]=C_static_lambda_info(C_heaptop,33,"(make-u16vector len250 . g249251)");
lf[117]=C_h_intern(&lf[117],14,"make-s16vector");
lf[118]=C_h_intern(&lf[118],9,"s16vector");
lf[119]=C_static_lambda_info(C_heaptop,12,"(do303 i305)");
lf[120]=C_static_lambda_info(C_heaptop,25,"(body292 init299 ext\077300)");
lf[121]=C_static_lambda_info(C_heaptop,36,"(def-fin296 %init289312 %ext\077290313)");
lf[122]=C_static_lambda_info(C_heaptop,25,"(def-ext\077295 %init289315)");
lf[123]=C_static_lambda_info(C_heaptop,13,"(def-init294)");
lf[124]=C_static_lambda_info(C_heaptop,33,"(make-s16vector len287 . g286288)");
lf[125]=C_h_intern(&lf[125],14,"make-u32vector");
lf[126]=C_h_intern(&lf[126],9,"u32vector");
lf[127]=C_static_lambda_info(C_heaptop,7,"(do340)");
lf[128]=C_static_lambda_info(C_heaptop,25,"(body329 init336 ext\077337)");
lf[129]=C_static_lambda_info(C_heaptop,36,"(def-fin333 %init326349 %ext\077327350)");
lf[130]=C_static_lambda_info(C_heaptop,25,"(def-ext\077332 %init326352)");
lf[131]=C_static_lambda_info(C_heaptop,13,"(def-init331)");
lf[132]=C_static_lambda_info(C_heaptop,33,"(make-u32vector len324 . g323325)");
lf[133]=C_h_intern(&lf[133],14,"make-s32vector");
lf[134]=C_h_intern(&lf[134],9,"s32vector");
lf[135]=C_static_lambda_info(C_heaptop,7,"(do377)");
lf[136]=C_static_lambda_info(C_heaptop,25,"(body366 init373 ext\077374)");
lf[137]=C_static_lambda_info(C_heaptop,36,"(def-fin370 %init363386 %ext\077364387)");
lf[138]=C_static_lambda_info(C_heaptop,25,"(def-ext\077369 %init363389)");
lf[139]=C_static_lambda_info(C_heaptop,13,"(def-init368)");
lf[140]=C_static_lambda_info(C_heaptop,33,"(make-s32vector len361 . g360362)");
lf[141]=C_h_intern(&lf[141],14,"make-f32vector");
lf[142]=C_h_intern(&lf[142],9,"f32vector");
lf[143]=C_static_lambda_info(C_heaptop,12,"(do414 i416)");
lf[144]=C_static_lambda_info(C_heaptop,25,"(body403 init410 ext\077411)");
lf[145]=C_static_lambda_info(C_heaptop,36,"(def-fin407 %init400424 %ext\077401425)");
lf[146]=C_static_lambda_info(C_heaptop,25,"(def-ext\077406 %init400427)");
lf[147]=C_static_lambda_info(C_heaptop,13,"(def-init405)");
lf[148]=C_static_lambda_info(C_heaptop,33,"(make-f32vector len398 . g397399)");
lf[149]=C_h_intern(&lf[149],14,"make-f64vector");
lf[150]=C_h_intern(&lf[150],9,"f64vector");
lf[151]=C_static_lambda_info(C_heaptop,12,"(do452 i454)");
lf[152]=C_static_lambda_info(C_heaptop,25,"(body441 init448 ext\077449)");
lf[153]=C_static_lambda_info(C_heaptop,36,"(def-fin445 %init438462 %ext\077439463)");
lf[154]=C_static_lambda_info(C_heaptop,25,"(def-ext\077444 %init438465)");
lf[155]=C_static_lambda_info(C_heaptop,13,"(def-init443)");
lf[156]=C_static_lambda_info(C_heaptop,33,"(make-f64vector len436 . g435437)");
lf[157]=C_h_intern(&lf[157],27,"\003sysnot-a-proper-list-error");
lf[158]=C_static_lambda_info(C_heaptop,17,"(do488 p490 i491)");
lf[159]=C_static_lambda_info(C_heaptop,15,"(f_2059 lst485)");
lf[160]=C_static_lambda_info(C_heaptop,28,"(init make482 set483 loc484)");
lf[161]=C_h_intern(&lf[161],14,"list->u8vector");
lf[162]=C_h_intern(&lf[162],14,"list->s8vector");
lf[163]=C_h_intern(&lf[163],15,"list->u16vector");
lf[164]=C_h_intern(&lf[164],15,"list->s16vector");
lf[165]=C_h_intern(&lf[165],15,"list->u32vector");
lf[166]=C_h_intern(&lf[166],15,"list->s32vector");
lf[167]=C_h_intern(&lf[167],15,"list->f32vector");
lf[168]=C_h_intern(&lf[168],15,"list->f64vector");
lf[169]=C_static_lambda_info(C_heaptop,18,"(u8vector . xs504)");
lf[170]=C_static_lambda_info(C_heaptop,18,"(s8vector . xs506)");
lf[171]=C_static_lambda_info(C_heaptop,19,"(u16vector . xs508)");
lf[172]=C_static_lambda_info(C_heaptop,19,"(s16vector . xs510)");
lf[173]=C_static_lambda_info(C_heaptop,19,"(u32vector . xs512)");
lf[174]=C_static_lambda_info(C_heaptop,19,"(s32vector . xs514)");
lf[175]=C_static_lambda_info(C_heaptop,19,"(f32vector . xs516)");
lf[176]=C_static_lambda_info(C_heaptop,19,"(f64vector . xs518)");
lf[177]=C_static_lambda_info(C_heaptop,11,"(loop i526)");
lf[178]=C_static_lambda_info(C_heaptop,13,"(f_2177 v523)");
lf[179]=C_static_lambda_info(C_heaptop,23,"(init length521 ref522)");
lf[180]=C_h_intern(&lf[180],14,"u8vector->list");
lf[181]=C_h_intern(&lf[181],14,"s8vector->list");
lf[182]=C_h_intern(&lf[182],15,"u16vector->list");
lf[183]=C_h_intern(&lf[183],15,"s16vector->list");
lf[184]=C_h_intern(&lf[184],15,"u32vector->list");
lf[185]=C_h_intern(&lf[185],15,"s32vector->list");
lf[186]=C_h_intern(&lf[186],15,"f32vector->list");
lf[187]=C_h_intern(&lf[187],15,"f64vector->list");
lf[188]=C_h_intern(&lf[188],9,"u8vector\077");
lf[189]=C_static_lambda_info(C_heaptop,16,"(u8vector\077 x536)");
lf[190]=C_h_intern(&lf[190],9,"s8vector\077");
lf[191]=C_static_lambda_info(C_heaptop,16,"(s8vector\077 x537)");
lf[192]=C_h_intern(&lf[192],10,"u16vector\077");
lf[193]=C_static_lambda_info(C_heaptop,17,"(u16vector\077 x538)");
lf[194]=C_h_intern(&lf[194],10,"s16vector\077");
lf[195]=C_static_lambda_info(C_heaptop,17,"(s16vector\077 x539)");
lf[196]=C_h_intern(&lf[196],10,"u32vector\077");
lf[197]=C_static_lambda_info(C_heaptop,17,"(u32vector\077 x540)");
lf[198]=C_h_intern(&lf[198],10,"s32vector\077");
lf[199]=C_static_lambda_info(C_heaptop,17,"(s32vector\077 x541)");
lf[200]=C_h_intern(&lf[200],10,"f32vector\077");
lf[201]=C_static_lambda_info(C_heaptop,17,"(f32vector\077 x542)");
lf[202]=C_h_intern(&lf[202],10,"f64vector\077");
lf[203]=C_static_lambda_info(C_heaptop,17,"(f64vector\077 x543)");
lf[204]=C_static_lambda_info(C_heaptop,13,"(f_2292 v548)");
lf[205]=C_static_lambda_info(C_heaptop,20,"(pack tag546 loc547)");
lf[206]=C_static_string(C_heaptop,49,"bytevector does not have correct size for packing");
lf[207]=C_h_intern(&lf[207],5,"fxmod");
lf[208]=C_static_lambda_info(C_heaptop,15,"(f_2300 str553)");
lf[209]=C_static_lambda_info(C_heaptop,28,"(unpack tag550 sz551 loc552)");
lf[210]=C_h_intern(&lf[210],21,"u8vector->byte-vector");
lf[211]=C_h_intern(&lf[211],21,"s8vector->byte-vector");
lf[212]=C_h_intern(&lf[212],22,"u16vector->byte-vector");
lf[213]=C_h_intern(&lf[213],22,"s16vector->byte-vector");
lf[214]=C_h_intern(&lf[214],22,"u32vector->byte-vector");
lf[215]=C_h_intern(&lf[215],22,"s32vector->byte-vector");
lf[216]=C_h_intern(&lf[216],22,"f32vector->byte-vector");
lf[217]=C_h_intern(&lf[217],22,"f64vector->byte-vector");
lf[218]=C_h_intern(&lf[218],21,"byte-vector->u8vector");
lf[219]=C_h_intern(&lf[219],21,"byte-vector->s8vector");
lf[220]=C_h_intern(&lf[220],22,"byte-vector->u16vector");
lf[221]=C_h_intern(&lf[221],22,"byte-vector->s16vector");
lf[222]=C_h_intern(&lf[222],22,"byte-vector->u32vector");
lf[223]=C_h_intern(&lf[223],22,"byte-vector->s32vector");
lf[224]=C_h_intern(&lf[224],22,"byte-vector->f32vector");
lf[225]=C_h_intern(&lf[225],22,"byte-vector->f64vector");
lf[226]=C_h_intern(&lf[226],18,"\003sysuser-read-hook");
lf[227]=C_h_intern(&lf[227],4,"read");
lf[228]=C_h_intern(&lf[228],2,"u8");
lf[229]=C_h_intern(&lf[229],2,"s8");
lf[230]=C_h_intern(&lf[230],3,"u16");
lf[231]=C_h_intern(&lf[231],3,"s16");
lf[232]=C_h_intern(&lf[232],3,"u32");
lf[233]=C_h_intern(&lf[233],3,"s32");
lf[234]=C_h_intern(&lf[234],3,"f32");
lf[235]=C_h_intern(&lf[235],3,"f64");
lf[236]=C_h_intern(&lf[236],1,"f");
lf[237]=C_h_intern(&lf[237],1,"F");
lf[238]=C_static_string(C_heaptop,25,"illegal bytevector syntax");
lf[239]=C_static_lambda_info(C_heaptop,38,"(##sys#user-read-hook char578 port579)");
lf[240]=C_h_intern(&lf[240],19,"\003sysuser-print-hook");
lf[241]=C_h_intern(&lf[241],9,"\003sysprint");
lf[242]=C_static_lambda_info(C_heaptop,48,"(##sys#user-print-hook x588 readable589 port590)");
lf[244]=C_h_intern(&lf[244],3,"fx/");
lf[245]=C_static_lambda_info(C_heaptop,48,"(subvector v594 t595 es596 from597 to598 loc599)");
lf[246]=C_h_intern(&lf[246],11,"subu8vector");
lf[247]=C_static_lambda_info(C_heaptop,32,"(subu8vector v610 from611 to612)");
lf[248]=C_h_intern(&lf[248],12,"subu16vector");
lf[249]=C_static_lambda_info(C_heaptop,33,"(subu16vector v613 from614 to615)");
lf[250]=C_h_intern(&lf[250],12,"subu32vector");
lf[251]=C_static_lambda_info(C_heaptop,33,"(subu32vector v616 from617 to618)");
lf[252]=C_h_intern(&lf[252],11,"subs8vector");
lf[253]=C_static_lambda_info(C_heaptop,32,"(subs8vector v619 from620 to621)");
lf[254]=C_h_intern(&lf[254],12,"subs16vector");
lf[255]=C_static_lambda_info(C_heaptop,33,"(subs16vector v622 from623 to624)");
lf[256]=C_h_intern(&lf[256],12,"subs32vector");
lf[257]=C_static_lambda_info(C_heaptop,33,"(subs32vector v625 from626 to627)");
lf[258]=C_h_intern(&lf[258],12,"subf32vector");
lf[259]=C_static_lambda_info(C_heaptop,33,"(subf32vector v628 from629 to630)");
lf[260]=C_h_intern(&lf[260],12,"subf64vector");
lf[261]=C_static_lambda_info(C_heaptop,33,"(subf64vector v631 from632 to633)");
lf[262]=C_h_intern(&lf[262],17,"register-feature!");
lf[263]=C_h_intern(&lf[263],6,"srfi-4");
lf[264]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,265);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_707,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=lf[10],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=lf[14],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=lf[18],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_743,a[2]=lf[20],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=lf[23],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[24],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[26],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=lf[27],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[28],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[30],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=lf[31],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[32],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=lf[33],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[34],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_770,a[2]=lf[35],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[36],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_773,a[2]=lf[37],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[38],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_776,a[2]=lf[39],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[40],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_795,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_782(t22,lf[93],C_SCHEME_FALSE,lf[44]);}

/* k793 */
static void f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_795,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[101],C_SCHEME_FALSE,lf[45]);}

/* k797 in k793 */
static void f_799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_799,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[110],C_fix(1),lf[46]);}

/* k801 in k797 in k793 */
static void f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[118],C_fix(1),lf[47]);}

/* k805 in k801 in k797 in k793 */
static void f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[126],C_fix(2),lf[48]);}

/* k809 in k805 in k801 in k797 in k793 */
static void f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[134],C_fix(2),lf[49]);}

/* k813 in k809 in k805 in k801 in k797 in k793 */
static void f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_782(t3,lf[142],C_fix(2),lf[50]);}

/* k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_782(t3,lf[150],C_fix(3),lf[51]);}

/* k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_823,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_825,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_856,a[2]=lf[59],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=lf[61],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_971,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
f_825(t7,*((C_word*)lf[44]+1),lf[9],lf[62]);}

/* k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[45]+1),lf[11],lf[63]);}

/* k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[46]+1),lf[13],lf[64]);}

/* k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[47]+1),lf[15],lf[65]);}

/* k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[48]+1),lf[17],lf[66]);}

/* k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[49]+1),lf[19],lf[67]);}

/* k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_825(t3,*((C_word*)lf[50]+1),lf[21],lf[68]);}

/* k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
f_825(t3,*((C_word*)lf[51]+1),lf[24],lf[69]);}

/* k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
f_856(t3,*((C_word*)lf[44]+1),lf[26],lf[70]);}

/* k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
f_839(t3,*((C_word*)lf[45]+1),lf[28],lf[71]);}

/* k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
f_856(t3,*((C_word*)lf[46]+1),lf[30],lf[72]);}

/* k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_839(t3,*((C_word*)lf[47]+1),lf[32],lf[73]);}

/* k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=*((C_word*)lf[48]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_911,a[2]=t3,a[3]=lf[77],tmp=(C_word)a,a+=4,tmp);
t5=C_mutate((C_word*)lf[74]+1,t4);
t6=*((C_word*)lf[49]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=t6,a[3]=lf[80],tmp=(C_word)a,a+=4,tmp);
t8=C_mutate((C_word*)lf[78]+1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_945(t9,*((C_word*)lf[50]+1),lf[38],lf[81]);}

/* k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_945(t3,*((C_word*)lf[51]+1),lf[40],lf[82]);}

/* k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=lf[83],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[84]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=lf[87],tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1058,a[2]=t3,a[3]=lf[91],tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1083,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[99],tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1203,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[108],tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1323,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[116],tmp=(C_word)a,a+=6,tmp));
t10=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1443,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[124],tmp=(C_word)a,a+=6,tmp));
t11=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1563,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[132],tmp=(C_word)a,a+=6,tmp));
t12=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1683,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[140],tmp=(C_word)a,a+=6,tmp));
t13=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1803,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[148],tmp=(C_word)a,a+=6,tmp));
t14=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1930,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=lf[156],tmp=(C_word)a,a+=6,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=lf[160],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_2057(t16,*((C_word*)lf[92]+1),*((C_word*)lf[70]+1),lf[161]);}

/* k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[100]+1),*((C_word*)lf[71]+1),lf[162]);}

/* k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=C_mutate((C_word*)lf[162]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[109]+1),*((C_word*)lf[72]+1),lf[163]);}

/* k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[117]+1),*((C_word*)lf[73]+1),lf[164]);}

/* k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=C_mutate((C_word*)lf[164]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[125]+1),*((C_word*)lf[74]+1),lf[165]);}

/* k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=C_mutate((C_word*)lf[165]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[133]+1),*((C_word*)lf[78]+1),lf[166]);}

/* k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=C_mutate((C_word*)lf[166]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2057(t3,*((C_word*)lf[141]+1),*((C_word*)lf[81]+1),lf[167]);}

/* k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=C_mutate((C_word*)lf[167]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_2057(t3,*((C_word*)lf[149]+1),*((C_word*)lf[82]+1),lf[168]);}

/* k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1,t1);
t3=*((C_word*)lf[161]+1);
t4=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t3,a[3]=lf[169],tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[162]+1);
t6=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2133,a[2]=t5,a[3]=lf[170],tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[163]+1);
t8=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t7,a[3]=lf[171],tmp=(C_word)a,a+=4,tmp));
t9=*((C_word*)lf[164]+1);
t10=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t9,a[3]=lf[172],tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[165]+1);
t12=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=t11,a[3]=lf[173],tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[166]+1);
t14=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2157,a[2]=t13,a[3]=lf[174],tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[167]+1);
t16=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t15,a[3]=lf[175],tmp=(C_word)a,a+=4,tmp));
t17=*((C_word*)lf[168]+1);
t18=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2169,a[2]=t17,a[3]=lf[176],tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=lf[179],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2212,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_2175(t20,*((C_word*)lf[44]+1),lf[9]);}

/* k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=C_mutate((C_word*)lf[180]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[45]+1),lf[11]);}

/* k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=C_mutate((C_word*)lf[181]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[46]+1),lf[13]);}

/* k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=C_mutate((C_word*)lf[182]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[47]+1),lf[15]);}

/* k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=C_mutate((C_word*)lf[183]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[48]+1),lf[17]);}

/* k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=C_mutate((C_word*)lf[184]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[49]+1),lf[19]);}

/* k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=C_mutate((C_word*)lf[185]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2175(t3,*((C_word*)lf[50]+1),lf[21]);}

/* k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=C_mutate((C_word*)lf[186]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_2175(t3,*((C_word*)lf[51]+1),lf[24]);}

/* k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=C_mutate((C_word*)lf[187]+1,t1);
t3=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=lf[189],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=lf[191],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=lf[195],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=lf[197],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=lf[199],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=lf[201],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=lf[203],tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=lf[205],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2327,a[2]=t11,a[3]=t12,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
f_2290(t13,lf[93],lf[210]);}

/* k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2327,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[101],lf[211]);}

/* k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
t2=C_mutate((C_word*)lf[211]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[110],lf[212]);}

/* k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=C_mutate((C_word*)lf[212]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[118],lf[213]);}

/* k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[126],lf[214]);}

/* k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[134],lf[215]);}

/* k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=C_mutate((C_word*)lf[215]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2290(t3,lf[142],lf[216]);}

/* k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=C_mutate((C_word*)lf[216]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_2290(t3,lf[150],lf[217]);}

/* k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[93],C_SCHEME_TRUE,lf[218]);}

/* k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=C_mutate((C_word*)lf[218]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[101],C_SCHEME_TRUE,lf[219]);}

/* k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=C_mutate((C_word*)lf[219]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[110],C_fix(2),lf[220]);}

/* k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=C_mutate((C_word*)lf[220]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[118],C_fix(2),lf[221]);}

/* k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=C_mutate((C_word*)lf[221]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[126],C_fix(4),lf[222]);}

/* k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=C_mutate((C_word*)lf[222]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[134],C_fix(4),lf[223]);}

/* k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=C_mutate((C_word*)lf[223]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2298(t3,lf[142],C_fix(4),lf[224]);}

/* k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=C_mutate((C_word*)lf[224]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_2298(t3,lf[150],C_fix(8),lf[225]);}

/* k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=C_mutate((C_word*)lf[225]+1,t1);
t3=*((C_word*)lf[226]+1);
t4=*((C_word*)lf[227]+1);
t5=(C_word)C_a_i_list(&a,16,lf[228],*((C_word*)lf[161]+1),lf[229],*((C_word*)lf[162]+1),lf[230],*((C_word*)lf[163]+1),lf[231],*((C_word*)lf[164]+1),lf[232],*((C_word*)lf[165]+1),lf[233],*((C_word*)lf[166]+1),lf[234],*((C_word*)lf[167]+1),lf[235],*((C_word*)lf[168]+1));
t6=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2392,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=lf[239],tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[240]+1);
t8=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=t7,a[3]=lf[242],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[243],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=lf[245],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2551,a[2]=lf[247],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[248]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=lf[249],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=lf[251],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[252]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2575,a[2]=lf[255],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2581,a[2]=lf[257],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2587,a[2]=lf[259],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=lf[261],tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[263]);}

/* k2598 in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* subf64vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2593,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[150],C_fix(8),t3,t4,lf[260]);}

/* subf32vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2587,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[142],C_fix(4),t3,t4,lf[258]);}

/* subs32vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2581,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[134],C_fix(4),t3,t4,lf[256]);}

/* subs16vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2575,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[118],C_fix(2),t3,t4,lf[254]);}

/* subs8vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2569,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[101],C_fix(1),t3,t4,lf[252]);}

/* subu32vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2563,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[126],C_fix(4),t3,t4,lf[250]);}

/* subu16vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2557,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[110],C_fix(2),t3,t4,lf[248]);}

/* subu8vector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2551,5,t0,t1,t2,t3,t4);}
f_2516(t1,t2,lf[93],C_fix(1),t3,t4,lf[246]);}

/* subvector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_2516(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2516,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2529,a[2]=t7,a[3]=t1,a[4]=t9,a[5]=t3,a[6]=t4,a[7]=t5,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
t12=*((C_word*)lf[244]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,t10,t4);}

/* k2527 in subvector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),t1,((C_word*)t0)[2]);}

/* k2530 in k2527 in subvector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2536 in k2530 in k2527 in subvector in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2448,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,3,lf[93],lf[228],*((C_word*)lf[180]+1));
t6=(C_word)C_a_i_list(&a,3,lf[101],lf[229],*((C_word*)lf[181]+1));
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[230],*((C_word*)lf[182]+1));
t8=(C_word)C_a_i_list(&a,3,lf[118],lf[231],*((C_word*)lf[183]+1));
t9=(C_word)C_a_i_list(&a,3,lf[126],lf[232],*((C_word*)lf[184]+1));
t10=(C_word)C_a_i_list(&a,3,lf[134],lf[233],*((C_word*)lf[185]+1));
t11=(C_word)C_a_i_list(&a,3,lf[142],lf[234],*((C_word*)lf[186]+1));
t12=(C_word)C_a_i_list(&a,3,lf[150],lf[235],*((C_word*)lf[187]+1));
t13=(C_word)C_a_i_list(&a,8,t5,t6,t7,t8,t9,t10,t11,t12);
t14=(C_word)C_i_assq((C_word)C_slot(t2,C_fix(0)),t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2458,a[2]=t2,a[3]=t14,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t16=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
t15=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t15))(5,t15,t1,t2,t3,t4);}}

/* k2456 in ##sys#user-print-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2459 in k2456 in ##sys#user-print-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,((C_word*)t0)[2]);}

/* k2466 in k2459 in k2456 in ##sys#user-print-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2392,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2402,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2400 in ##sys#user-read-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[236]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[237]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[5],lf[238],t3);}}}

/* k2425 in k2400 in ##sys#user-read-hook in k2385 in k2381 in k2377 in k2373 in k2369 in k2365 in k2361 in k2357 in k2353 in k2349 in k2345 in k2341 in k2337 in k2333 in k2329 in k2325 in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t1);}

/* unpack in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_2298(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2298,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2300,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[208],tmp=(C_word)a,a+=6,tmp));}

/* f_2300 in unpack in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2300,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2313(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[207]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t4,((C_word*)t0)[3]);}}

/* k2321 */
static void f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2313(t2,(C_word)C_eqp(C_fix(0),t1));}

/* k2311 */
static void C_fcall f_2313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]));}
else{
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[7],((C_word*)t0)[4],lf[206],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* pack in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_2290(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2290,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2292,a[2]=t3,a[3]=t2,a[4]=lf[204],tmp=(C_word)a,a+=5,tmp));}

/* f_2292 in pack in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2292,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2284,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[150]));}

/* f32vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2278,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[142]));}

/* s32vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2272,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[134]));}

/* u32vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2266,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[126]));}

/* s16vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2260,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[118]));}

/* u16vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2254,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[110]));}

/* s8vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2248,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[101]));}

/* u8vector? in k2238 in k2234 in k2230 in k2226 in k2222 in k2218 in k2214 in k2210 in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2242,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[93]));}

/* init in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_2175(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2175,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2177,a[2]=t2,a[3]=t3,a[4]=lf[178],tmp=(C_word)a,a+=5,tmp));}

/* f_2177 in init in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2177,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2181,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2179 */
static void f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=lf[177],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2186(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2179 */
static void C_fcall f_2186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2186,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2198 in loop in k2179 */
static void f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2204,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_2186(t4,t2,t3);}

/* k2202 in k2198 in loop in k2179 */
static void f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2169(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2169r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2169r(t0,t1,t2);}}

static void f_2169r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* f32vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2163(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2163r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2163r(t0,t1,t2);}}

static void f_2163r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s32vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2157(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2157r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2157r(t0,t1,t2);}}

static void f_2157r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u32vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2151(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2151r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2151r(t0,t1,t2);}}

static void f_2151r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s16vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2145(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2145r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2145r(t0,t1,t2);}}

static void f_2145r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u16vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2139(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2139r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2139r(t0,t1,t2);}}

static void f_2139r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s8vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2133(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2133r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2133r(t0,t1,t2);}}

static void f_2133r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u8vector in k2123 in k2119 in k2115 in k2111 in k2107 in k2103 in k2099 in k2095 in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2127(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2127r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2127r(t0,t1,t2);}}

static void f_2127r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* init in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_2057(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2059,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[159],tmp=(C_word)a,a+=6,tmp));}

/* f_2059 in init in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_2059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2059,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2067 */
static void f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=lf[158],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2074(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do488 in k2067 */
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2074,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2081,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
t6=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2079 in do488 in k2067 */
static void f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2074(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1930(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1930r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1930r(t0,t1,t2,t3);}}

static void f_1930r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[152],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t4,a[3]=lf[153],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=t5,a[3]=lf[154],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=t6,a[3]=lf[155],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1994(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1989(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1984(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1932(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init443 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1994,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1989(t2,t1,C_SCHEME_FALSE);}

/* def-ext?444 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1989,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1984(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin445 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1984(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1984,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1932(t4,t1,t2,t3);}

/* body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1932,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[149]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
f_1040(t6,lf[149],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[150],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1942(2,t5,C_SCHEME_UNDEFINED);}}

/* k1940 in k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[149]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_1954(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1971 in k1940 in k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1954(t3,t2);}

/* k1952 in k1940 in k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1954(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1954,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[151],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1959(t5,((C_word*)t0)[2],C_fix(0));}

/* do452 in k1952 in k1940 in k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1959,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[40];
f_779(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1964 in do452 in k1952 in k1940 in k1981 in body441 in make-f64vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1959(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1803(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1803r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1803r(t0,t1,t2,t3);}}

static void f_1803r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[144],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1857,a[2]=t4,a[3]=lf[145],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=t5,a[3]=lf[146],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=t6,a[3]=lf[147],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1867(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1862(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1857(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1805(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init405 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1867,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1862(t2,t1,C_SCHEME_FALSE);}

/* def-ext?406 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1862,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1857(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin407 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1857(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1857,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1805(t4,t1,t2,t3);}

/* body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1805,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[141]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
f_1040(t6,lf[141],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[142],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1815(2,t5,C_SCHEME_UNDEFINED);}}

/* k1813 in k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[141]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_1827(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1844 in k1813 in k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1827(t3,t2);}

/* k1825 in k1813 in k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1827,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[143],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1832(t5,((C_word*)t0)[2],C_fix(0));}

/* do414 in k1825 in k1813 in k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1832(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1832,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1839,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[38];
f_776(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1837 in do414 in k1825 in k1813 in k1854 in body403 in make-f32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1832(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1683(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1683r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1683r(t0,t1,t2,t3);}}

static void f_1683r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[136],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=t4,a[3]=lf[137],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=t5,a[3]=lf[138],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1740,a[2]=t6,a[3]=lf[139],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1740(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1735(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1730(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1685(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init368 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1740,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1735(t2,t1,C_SCHEME_FALSE);}

/* def-ext?369 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1735,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1730(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin370 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1685(t4,t1,t2,t3);}

/* body366 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1685,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[133]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_1040(t5,lf[133],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1727 in body366 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[134],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1695(2,t5,C_SCHEME_UNDEFINED);}}

/* k1693 in k1727 in body366 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[133]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[135],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1709(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do377 in k1693 in k1727 in body366 in make-s32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static C_word C_fcall f_1709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_773(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1563(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1563r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1563r(t0,t1,t2,t3);}}

static void f_1563r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[128],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=t4,a[3]=lf[129],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1615,a[2]=t5,a[3]=lf[130],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1620,a[2]=t6,a[3]=lf[131],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1620(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1615(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1610(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1565(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init331 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1620,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1615(t2,t1,C_SCHEME_FALSE);}

/* def-ext?332 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1615(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1615,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1610(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin333 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1610(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1610,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1565(t4,t1,t2,t3);}

/* body329 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1565(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1565,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[125]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_1040(t5,lf[125],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1607 in body329 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[126],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1575(2,t5,C_SCHEME_UNDEFINED);}}

/* k1573 in k1607 in body329 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[125]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[127],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1589(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do340 in k1573 in k1607 in body329 in make-u32vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static C_word C_fcall f_1589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_770(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1443(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1443r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1443r(t0,t1,t2,t3);}}

static void f_1443r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[120],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1490,a[2]=t4,a[3]=lf[121],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=t5,a[3]=lf[122],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t6,a[3]=lf[123],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1500(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1495(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1490(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1445(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init294 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1495(t2,t1,C_SCHEME_FALSE);}

/* def-ext?295 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1495,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1490(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin296 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1490(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1490,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1445(t4,t1,t2,t3);}

/* body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1445,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[117]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_1040(t5,lf[117],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1487 in body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[118],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1455(2,t5,C_SCHEME_UNDEFINED);}}

/* k1453 in k1487 in body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[117]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1462 in k1453 in k1487 in body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[119],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1469(t5,((C_word*)t0)[2],C_fix(0));}

/* do303 in k1462 in k1453 in k1487 in body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1469(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1476,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[32];
f_767(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1474 in do303 in k1462 in k1453 in k1487 in body292 in make-s16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1469(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1323(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1323r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1323r(t0,t1,t2,t3);}}

static void f_1323r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[112],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t4,a[3]=lf[113],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=t5,a[3]=lf[114],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=t6,a[3]=lf[115],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1380(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1375(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1370(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1325(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init257 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1380,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1375(t2,t1,C_SCHEME_FALSE);}

/* def-ext?258 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1375,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1370(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin259 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1370,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1325(t4,t1,t2,t3);}

/* body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1325(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1325,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[109]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_1040(t5,lf[109],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1367 in body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[110],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1335(2,t5,C_SCHEME_UNDEFINED);}}

/* k1333 in k1367 in body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[109]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1342 in k1333 in k1367 in body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[111],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1349(t5,((C_word*)t0)[2],C_fix(0));}

/* do266 in k1342 in k1333 in k1367 in body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1349,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1356,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[30];
f_764(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1354 in do266 in k1342 in k1333 in k1367 in body255 in make-u16vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1349(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1203(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1203r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1203r(t0,t1,t2,t3);}}

static void f_1203r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[104],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1250,a[2]=t4,a[3]=lf[105],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1255,a[2]=t5,a[3]=lf[106],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1260,a[2]=t6,a[3]=lf[107],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1260(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1255(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1250(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1205(t14,t1,t8,t10);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init220 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1260,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1255(t2,t1,C_SCHEME_FALSE);}

/* def-ext?221 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1255,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1250(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin222 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1250,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1205(t4,t1,t2,t3);}

/* body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[100]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_1040(t5,lf[100],((C_word*)t0)[5],t3);}

/* k1247 in body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[101],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[103]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1215(2,t5,C_SCHEME_UNDEFINED);}}

/* k1213 in k1247 in body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[100]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1222 in k1213 in k1247 in body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[102],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1229(t5,((C_word*)t0)[2],C_fix(0));}

/* do229 in k1222 in k1213 in k1247 in body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1229(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1229,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1236,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[28];
f_761(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1234 in do229 in k1222 in k1213 in k1247 in body218 in make-s8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1229(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1083r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1083r(t0,t1,t2,t3);}}

static void f_1083r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[95],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1130,a[2]=t4,a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=t5,a[3]=lf[97],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1140,a[2]=t6,a[3]=lf[98],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1140(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1135(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1130(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
t14=t4;
f_1085(t14,t1,t8,t10,t12);}
else{
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init182 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1140,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1135(t2,t1,C_SCHEME_FALSE);}

/* def-ext?183 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1135,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1130(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?184 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1130(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1130,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1085(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1085(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1085,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[92]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
f_1040(t6,lf[92],((C_word*)t0)[5],t3);}

/* k1127 in body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[93],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1095(2,t5,C_SCHEME_UNDEFINED);}}

/* k1093 in k1127 in body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[92]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1102 in k1093 in k1127 in body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[94],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1109(t5,((C_word*)t0)[2],C_fix(0));}

/* do191 in k1102 in k1093 in k1127 in body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1109,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1116,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[26];
f_758(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1114 in do191 in k1102 in k1093 in k1127 in body180 in make-u8vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1109(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1065,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1065(t5,(C_word)C_i_memq(t4,lf[90]));}
else{
t4=t3;
f_1065(t4,C_SCHEME_FALSE);}}

/* k1063 in release-number-vector in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1038(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[88],lf[89],((C_word*)t0)[2]);}}

/* alloc in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_1040(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1040,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub155(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[85],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1056,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1054 in alloc in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1029 in k1025 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_1038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1038,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub160(C_SCHEME_UNDEFINED,t2));}

/* f_884 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_884,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_888,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k886 */
static void f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_891,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_891(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[78],lf[79],((C_word*)t0)[2]);}}

/* k889 in k886 */
static void f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[78]);}

/* k892 in k889 in k886 */
static void f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_773(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_911 in k1013 in k1009 in k1005 in k1001 in k997 in k993 in k989 in k985 in k981 in k977 in k973 in k969 in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_911,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_915,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k913 */
static void f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_918,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[74],lf[75],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_918(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[74],lf[76],((C_word*)t0)[2]);}}}

/* k916 in k913 */
static void f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[74]);}

/* k919 in k916 in k913 */
static void f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_770(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_945(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_945,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_947,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[60],tmp=(C_word)a,a+=6,tmp));}

/* f_947 in setf in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_947,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_951,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k949 */
static void f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k955 in k949 */
static void f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_964(2,t3,((C_word*)t0)[2]);}
else{
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k962 in k955 in k949 */
static void f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_856(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_856,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_858,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[58],tmp=(C_word)a,a+=6,tmp));}

/* f_858 in setu in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_858,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_862,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k860 */
static void f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_868,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[57],((C_word*)t0)[7]);}
else{
t4=t3;
f_868(2,t4,C_SCHEME_UNDEFINED);}}

/* k866 in k860 */
static void f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k869 in k866 in k860 */
static void f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_839(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_839,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_841,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[55],tmp=(C_word)a,a+=6,tmp));}

/* f_841 in set in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_841,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_845,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k843 */
static void f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_851,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k849 in k843 */
static void f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void C_fcall f_825(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_825,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_827,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=lf[53],tmp=(C_word)a,a+=6,tmp));}

/* f_827 in get in k821 in k817 in k813 in k809 in k805 in k801 in k797 in k793 */
static void f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_827,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k829 */
static void f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k832 in k829 */
static void f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_782(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_782,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_784,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=lf[42],tmp=(C_word)a,a+=6,tmp));}

/* f_784 in len */
static void f_784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_784,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void f_779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_779,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void f_776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_776,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_773(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_770(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void f_767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_767,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void f_764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_764,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void f_761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_761,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void f_758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_758,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void f_752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_752,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
t5=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void f_746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_746,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
t5=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_743,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void f_740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_740,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_737,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void f_734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_734,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_731,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void f_728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_728,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_707,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[7],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_692,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}
/* end of file */
