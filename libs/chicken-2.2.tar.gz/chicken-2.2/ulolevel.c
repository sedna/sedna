/* Generated from lolevel.scm by the Chicken compiler
   2005-09-24 22:21
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: lolevel.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file ulolevel.c -explicit-use
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif
#if defined(__i386__) && !defined(C_NONUNIX) && !defined(__CYGWIN__)
# define C_valloc(n)               valloc(n)
#elif defined(__i386__) || defined(_M_IX86)
# define C_valloc(n)               malloc(n)
#else
# define C_valloc(n)               NULL
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[135];


/* from k2109 */
static C_word C_fcall stub432(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub432(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from f_2031 in object-evict in k642 in k639 */
static C_word C_fcall stub406(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub406(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from malloc in k642 in k639 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub347(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub347(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int size=(int )C_unfix(C_a0);
char *bv;
           if((bv = (char *)malloc(size + 3 + sizeof(C_header))) == NULL) return(C_SCHEME_FALSE);
           bv = (char *)C_align((C_word)bv);
           ((C_SCHEME_BLOCK *)bv)->header = C_BYTEVECTOR_TYPE | size;
           return((C_word)bv);
C_return:
#undef return

return C_r;}

/* from k1262 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_return:
#undef return

return C_r;}

/* from k1252 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub246(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub246(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_return:
#undef return

return C_r;}

/* from k1242 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_return:
#undef return

return C_r;}

/* from k1232 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub232(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub232(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_return:
#undef return

return C_r;}

/* from k1222 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub226(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub226(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_return:
#undef return

return C_r;}

/* from k1212 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub220(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub220(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_return:
#undef return

return C_r;}

/* from k1202 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub214(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub214(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_return:
#undef return

return C_r;}

/* from k1192 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub208(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub208(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_return:
#undef return

return C_r;}

/* from k1182 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub201(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub201(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1172 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub193(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub193(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1162 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1152 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1142 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub169(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub169(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1132 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1122 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1112 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub145(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub145(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1102 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub136(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub136(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_return:
#undef return

return C_r;}

/* from align in k642 in k639 */
static C_word C_fcall stub129(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub129(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1058 */
static C_word C_fcall stub122(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from allocate in k642 in k639 */
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1043 in object->pointer in k642 in k639 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub109(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub109(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_return:
#undef return

return C_r;}

/* from k695 */
static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k682 */
static C_word C_fcall stub34(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub34(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k669 */
static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k653 */
static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

C_externexport void C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_641(C_word c,C_word t0,C_word t1) C_noret;
static void f_644(C_word c,C_word t0,C_word t1) C_noret;
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2556(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2556r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2561(C_word t0,C_word t1) C_noret;
static void f_2537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2541(C_word c,C_word t0,C_word t1) C_noret;
static void f_2544(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2544r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2497(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2497r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2505(C_word t0,C_word t1) C_noret;
static void f_2471(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2471r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2479(C_word t0,C_word t1) C_noret;
static void f_2338(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2338r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2342(C_word t0,C_word t1) C_noret;
static void f_2351(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2372(C_word c,C_word t0,C_word t1) C_noret;
static void f_2415(C_word c,C_word t0,C_word t1) C_noret;
static void f_2418(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2448(C_word c,C_word t0,C_word t1) C_noret;
static void f_2421(C_word c,C_word t0,C_word t1) C_noret;
static void f_2401(C_word c,C_word t0,C_word t1) C_noret;
static void f_2404(C_word c,C_word t0,C_word t1) C_noret;
static void f_2385(C_word c,C_word t0,C_word t1) C_noret;
static void f_2388(C_word c,C_word t0,C_word t1) C_noret;
static void f_2254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2258(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2263(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2276(C_word c,C_word t0,C_word t1) C_noret;
static void f_2333(C_word c,C_word t0,C_word t1) C_noret;
static void f_2285(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2297(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2319(C_word c,C_word t0,C_word t1) C_noret;
static void f_2288(C_word c,C_word t0,C_word t1) C_noret;
static void f_2116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2116r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2246(C_word c,C_word t0,C_word t1) C_noret;
static void f_2123(C_word c,C_word t0,C_word t1) C_noret;
static void f_2126(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2144(C_word c,C_word t0,C_word t1) C_noret;
static void f_2239(C_word c,C_word t0,C_word t1) C_noret;
static void f_2156(C_word c,C_word t0,C_word t1) C_noret;
static void f_2216(C_word c,C_word t0,C_word t1) C_noret;
static void f_2162(C_word c,C_word t0,C_word t1) C_noret;
static void f_2165(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2198(C_word c,C_word t0,C_word t1) C_noret;
static void f_2168(C_word c,C_word t0,C_word t1) C_noret;
static void f_2129(C_word c,C_word t0,C_word t1) C_noret;
static void f_2034(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2034r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2043(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2088(C_word c,C_word t0,C_word t1) C_noret;
static void f_2062(C_word c,C_word t0,C_word t1) C_noret;
static void f_2069(C_word c,C_word t0,C_word t1) C_noret;
static void f_2106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1927(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1927r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1934(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1939(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1949(C_word c,C_word t0,C_word t1) C_noret;
static void f_1958(C_word c,C_word t0,C_word t1) C_noret;
static void f_1962(C_word c,C_word t0,C_word t1) C_noret;
static void f_1968(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1980(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2001(C_word c,C_word t0,C_word t1) C_noret;
static void f_1971(C_word c,C_word t0,C_word t1) C_noret;
static void f_2031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1849(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1879(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1) C_noret;
static void f_1882(C_word c,C_word t0,C_word t1) C_noret;
static void f_1789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1802(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1807(C_word t0,C_word t1);
static void f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1777(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1777r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1747(C_word t0,C_word t1) C_noret;
static void f_1738(C_word c,C_word t0,C_word t1) C_noret;
static void f_1720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1727(C_word c,C_word t0,C_word t1) C_noret;
static void f_1714(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1714r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1693(C_word c,C_word t0,C_word t1) C_noret;
static void f_1699(C_word c,C_word t0,C_word t1) C_noret;
static void f_1677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1670(C_word c,C_word t0,C_word t1) C_noret;
static void f_1654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1661(C_word c,C_word t0,C_word t1) C_noret;
static void f_1607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1614(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1619(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1629(C_word c,C_word t0,C_word t1) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1583(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1601(C_word c,C_word t0,C_word t1) C_noret;
static void f_1550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1487(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1487r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1494(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1499(C_word t0,C_word t1,C_word t2);
static void f_1468(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1468r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1472(C_word c,C_word t0,C_word t1) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1449(C_word t0,C_word t1);
static void f_1434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1423(C_word c,C_word t0,C_word t1) C_noret;
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1395(C_word c,C_word t0,C_word t1) C_noret;
static void f_1354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1367(C_word c,C_word t0,C_word t1) C_noret;
static void f_1322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1273(C_word c,C_word t0,C_word t1) C_noret;
static void f_1276(C_word c,C_word t0,C_word t1) C_noret;
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1094(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1065(C_word *a,C_word t0);
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1033(C_word c,C_word t0,C_word t1) C_noret;
static void f_1019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_992(C_word t0,C_word t1) C_noret;
static void f_698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_796(C_word c,C_word t0,C_word t1) C_noret;
static void f_889(C_word c,C_word t0,C_word t1) C_noret;
static void f_934(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_948(C_word t0,C_word t1) C_noret;
static void C_fcall f_912(C_word t0,C_word t1) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void f_837(C_word c,C_word t0,C_word t1) C_noret;
static void f_851(C_word c,C_word t0,C_word t1) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_713(C_word t0);
static void C_fcall f_707(C_word t0,C_word t1) C_noret;
static void C_fcall f_701(C_word t0,C_word t1) C_noret;

static void C_fcall trf_2561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2561(t0,t1);}

static void C_fcall trf_2505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2505(t0,t1);}

static void C_fcall trf_2479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2479(t0,t1);}

static void C_fcall trf_2342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2342(t0,t1);}

static void C_fcall trf_2356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2356(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2356(t0,t1,t2);}

static void C_fcall trf_2427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2427(t0,t1,t2);}

static void C_fcall trf_2263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2263(t0,t1,t2);}

static void C_fcall trf_2297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2297(t0,t1,t2);}

static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2134(t0,t1,t2);}

static void C_fcall trf_2177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2177(t0,t1,t2);}

static void C_fcall trf_2043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2043(t0,t1,t2);}

static void C_fcall trf_2078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2078(t0,t1,t2);}

static void C_fcall trf_1939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1939(t0,t1,t2);}

static void C_fcall trf_1980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1980(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1980(t0,t1,t2);}

static void C_fcall trf_1849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1849(t0,t1,t2);}

static void C_fcall trf_1894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1894(t0,t1,t2);}

static void C_fcall trf_1747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1747(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1747(t0,t1);}

static void C_fcall trf_1680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1680(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1680(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1619(t0,t1,t2,t3);}

static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1583(t0,t1,t2);}

static void C_fcall trf_992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_992(t0,t1);}

static void C_fcall trf_734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_734(t0,t1,t2,t3);}

static void C_fcall trf_948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_948(t0,t1);}

static void C_fcall trf_912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_912(t0,t1);}

static void C_fcall trf_707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_707(t0,t1);}

static void C_fcall trf_701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_701(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1143)){
C_save(t1);
C_rereclaim2(1143*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,135);
tmp=C_intern(C_heaptop,4,"mmap");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"u8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"s8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f64vector");
C_save(tmp);
lf[0]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
lf[1]=C_h_intern(&lf[1],12,"move-memory!");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_static_string(C_heaptop,28,"need number of bytes to move");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_h_intern(&lf[5],11,"\000type-error");
lf[6]=C_static_string(C_heaptop,21,"invalid argument type");
lf[7]=C_h_intern(&lf[7],15,"\003sysbytevector\077");
lf[8]=C_h_intern(&lf[8],13,"\003syslocative\077");
lf[9]=C_h_intern(&lf[9],17,"\003syscheck-pointer");
lf[10]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[11]=C_h_intern(&lf[11],12,"null-pointer");
lf[12]=C_h_intern(&lf[12],16,"\003sysnull-pointer");
lf[13]=C_h_intern(&lf[13],8,"pointer\077");
lf[14]=C_h_intern(&lf[14],16,"address->pointer");
lf[15]=C_h_intern(&lf[15],20,"\003sysaddress->pointer");
lf[16]=C_h_intern(&lf[16],16,"pointer->address");
lf[17]=C_h_intern(&lf[17],20,"\003syspointer->address");
lf[18]=C_h_intern(&lf[18],13,"null-pointer\077");
lf[19]=C_h_intern(&lf[19],15,"object->pointer");
lf[20]=C_h_intern(&lf[20],15,"pointer->object");
lf[21]=C_h_intern(&lf[21],9,"pointer=\077");
lf[22]=C_h_intern(&lf[22],8,"allocate");
lf[23]=C_h_intern(&lf[23],4,"free");
lf[24]=C_h_intern(&lf[24],13,"align-to-word");
lf[25]=C_static_string(C_heaptop,43,"bad argument type - not a pointer or fixnum");
lf[26]=C_h_intern(&lf[26],14,"pointer-offset");
lf[27]=C_h_intern(&lf[27],15,"pointer-u8-set!");
lf[28]=C_h_intern(&lf[28],15,"pointer-s8-set!");
lf[29]=C_h_intern(&lf[29],16,"pointer-u16-set!");
lf[30]=C_h_intern(&lf[30],16,"pointer-s16-set!");
lf[31]=C_h_intern(&lf[31],16,"pointer-u32-set!");
lf[32]=C_h_intern(&lf[32],16,"pointer-s32-set!");
lf[33]=C_h_intern(&lf[33],16,"pointer-f32-set!");
lf[34]=C_h_intern(&lf[34],16,"pointer-f64-set!");
lf[35]=C_h_intern(&lf[35],14,"pointer-u8-ref");
lf[36]=C_h_intern(&lf[36],14,"pointer-s8-ref");
lf[37]=C_h_intern(&lf[37],15,"pointer-u16-ref");
lf[38]=C_h_intern(&lf[38],15,"pointer-s16-ref");
lf[39]=C_h_intern(&lf[39],15,"pointer-u32-ref");
lf[40]=C_h_intern(&lf[40],15,"pointer-s32-ref");
lf[41]=C_h_intern(&lf[41],15,"pointer-f32-ref");
lf[42]=C_h_intern(&lf[42],15,"pointer-f64-ref");
lf[43]=C_h_intern(&lf[43],11,"tag-pointer");
lf[44]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[45]=C_h_intern(&lf[45],23,"\003sysmake-tagged-pointer");
lf[46]=C_h_intern(&lf[46],15,"tagged-pointer\077");
lf[47]=C_h_intern(&lf[47],11,"pointer-tag");
lf[48]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[49]=C_h_intern(&lf[49],8,"extended");
lf[51]=C_h_intern(&lf[51],16,"extend-procedure");
lf[52]=C_h_intern(&lf[52],19,"\003sysdecorate-lambda");
lf[53]=C_h_intern(&lf[53],19,"extended-procedure\077");
lf[54]=C_h_intern(&lf[54],21,"\003syslambda-decoration");
lf[55]=C_h_intern(&lf[55],14,"procedure-data");
lf[56]=C_h_intern(&lf[56],19,"set-procedure-data!");
lf[57]=C_static_string(C_heaptop,45,"bad argument type - not an extended procedure");
lf[58]=C_h_intern(&lf[58],12,"byte-vector\077");
lf[59]=C_h_intern(&lf[59],17,"byte-vector-fill!");
lf[60]=C_h_intern(&lf[60],16,"make-byte-vector");
lf[61]=C_h_intern(&lf[61],19,"\003sysallocate-vector");
lf[62]=C_h_intern(&lf[62],11,"byte-vector");
lf[63]=C_h_intern(&lf[63],15,"byte-vector-ref");
lf[64]=C_static_string(C_heaptop,12,"out of range");
lf[65]=C_h_intern(&lf[65],16,"byte-vector-set!");
lf[66]=C_static_string(C_heaptop,12,"out of range");
lf[67]=C_h_intern(&lf[67],17,"byte-vector->list");
lf[68]=C_h_intern(&lf[68],17,"list->byte-vector");
lf[69]=C_h_intern(&lf[69],27,"\003sysnot-a-proper-list-error");
lf[70]=C_h_intern(&lf[70],19,"string->byte-vector");
lf[71]=C_h_intern(&lf[71],11,"make-string");
lf[72]=C_h_intern(&lf[72],19,"byte-vector->string");
lf[73]=C_h_intern(&lf[73],18,"byte-vector-length");
lf[74]=C_h_intern(&lf[74],13,"\000bounds-error");
lf[75]=C_static_string(C_heaptop,12,"out of range");
lf[76]=C_h_intern(&lf[76],14,"\000runtime-error");
lf[77]=C_static_string(C_heaptop,48,"can not allocate statically allocated bytevector");
lf[78]=C_h_intern(&lf[78],23,"make-static-byte-vector");
lf[79]=C_h_intern(&lf[79],27,"static-byte-vector->pointer");
lf[80]=C_h_intern(&lf[80],16,"\003sysmake-pointer");
lf[81]=C_static_string(C_heaptop,36,"can not coerce non-static bytevector");
lf[82]=C_h_intern(&lf[82],9,"block-ref");
lf[83]=C_h_intern(&lf[83],13,"\003sysblock-ref");
lf[84]=C_h_intern(&lf[84],10,"block-set!");
lf[85]=C_h_intern(&lf[85],14,"\003sysblock-set!");
lf[86]=C_h_intern(&lf[86],15,"number-of-slots");
lf[87]=C_static_string(C_heaptop,20,"slots not accessible");
lf[88]=C_h_intern(&lf[88],15,"number-of-bytes");
lf[89]=C_static_string(C_heaptop,51,"can not compute number of bytes of immediate object");
lf[90]=C_h_intern(&lf[90],20,"make-record-instance");
lf[91]=C_h_intern(&lf[91],18,"\003sysmake-structure");
lf[92]=C_h_intern(&lf[92],16,"record-instance\077");
lf[93]=C_h_intern(&lf[93],14,"record->vector");
lf[94]=C_h_intern(&lf[94],15,"\003sysmake-vector");
lf[95]=C_static_string(C_heaptop,42,"bad argument type - not a record structure");
lf[96]=C_h_intern(&lf[96],11,"make-vector");
lf[97]=C_h_intern(&lf[97],11,"object-copy");
lf[98]=C_h_intern(&lf[98],15,"object-evicted\077");
lf[99]=C_h_intern(&lf[99],15,"make-hash-table");
lf[100]=C_h_intern(&lf[100],22,"hash-table-ref/default");
lf[101]=C_h_intern(&lf[101],15,"hash-table-set!");
lf[102]=C_h_intern(&lf[102],12,"object-evict");
lf[103]=C_h_intern(&lf[103],3,"eq\077");
lf[104]=C_h_intern(&lf[104],14,"object-release");
lf[105]=C_h_intern(&lf[105],24,"object-evict-to-location");
lf[106]=C_h_intern(&lf[106],24,"\003sysset-pointer-address!");
lf[107]=C_static_string(C_heaptop,37,"can not evict object - limit exceeded");
lf[108]=C_h_intern(&lf[108],11,"object-size");
lf[109]=C_h_intern(&lf[109],14,"object-unevict");
lf[110]=C_h_intern(&lf[110],15,"\003sysmake-string");
lf[111]=C_h_intern(&lf[111],14,"object-become!");
lf[112]=C_h_intern(&lf[112],11,"\003sysbecome!");
lf[113]=C_h_intern(&lf[113],13,"make-locative");
lf[114]=C_h_intern(&lf[114],17,"\003sysmake-locative");
lf[115]=C_h_intern(&lf[115],18,"make-weak-locative");
lf[116]=C_h_intern(&lf[116],12,"locative-ref");
lf[117]=C_h_intern(&lf[117],13,"locative-set!");
lf[118]=C_h_intern(&lf[118],16,"locative->object");
lf[119]=C_h_intern(&lf[119],9,"locative\077");
lf[121]=C_h_intern(&lf[121],30,"invalid-procedure-call-handler");
lf[122]=C_h_intern(&lf[122],31,"\003sysinvalid-procedure-call-hook");
lf[123]=C_h_intern(&lf[123],26,"\003syslast-invalid-procedure");
lf[124]=C_static_string(C_heaptop,35,"bad argument type - not a procedure");
lf[125]=C_h_intern(&lf[125],22,"unbound-variable-value");
lf[126]=C_h_intern(&lf[126],31,"\003sysunbound-variable-value-hook");
lf[127]=C_h_intern(&lf[127],10,"global-ref");
lf[128]=C_h_intern(&lf[128],11,"global-set!");
lf[129]=C_h_intern(&lf[129],13,"global-bound\077");
lf[130]=C_h_intern(&lf[130],32,"\003syssymbol-has-toplevel-binding\077");
lf[131]=C_h_intern(&lf[131],20,"global-make-unbound!");
lf[132]=C_h_intern(&lf[132],28,"\003sysarbitrary-unbound-symbol");
lf[133]=C_h_intern(&lf[133],17,"register-feature!");
lf[134]=C_h_intern(&lf[134],7,"lolevel");
C_register_lf(lf,135);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k639 */
static void f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 88   register-feature! */
t3=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k642 in k639 */
static void f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word ab[181],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_644,2,t0,t1);}
t2=lf[0];
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_985,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[11]+1,*((C_word*)lf[12]+1));
t6=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1004,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1013,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1019,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1025,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1035,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1046,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1049,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1052,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1055,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1065,tmp=(C_word)a,a+=2,tmp);
t16=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1099,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1109,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1119,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1129,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1139,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1149,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1159,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1169,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1179,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1189,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1199,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1209,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1219,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1229,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1239,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1249,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1259,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1269,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1284,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1300,tmp=(C_word)a,a+=2,tmp));
t37=(C_word)C_a_i_vector(&a,1,lf[49]);
t38=C_mutate(&lf[50],t37);
t39=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1322,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1354,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1385,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[51]+1);
t43=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1434,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp));
t46=*((C_word*)lf[59]+1);
t47=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t46,tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[60]+1);
t49=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1526,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1550,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1574,tmp=(C_word)a,a+=2,tmp));
t53=*((C_word*)lf[60]+1);
t54=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=t53,tmp=(C_word)a,a+=3,tmp));
t55=*((C_word*)lf[60]+1);
t56=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=t55,tmp=(C_word)a,a+=3,tmp));
t57=*((C_word*)lf[71]+1);
t58=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=t57,tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1672,tmp=(C_word)a,a+=2,tmp));
t60=*((C_word*)lf[59]+1);
t61=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1677,tmp=(C_word)a,a+=2,tmp);
t62=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=t60,tmp=(C_word)a,a+=3,tmp);
t63=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1714,a[2]=t61,a[3]=t62,tmp=(C_word)a,a+=4,tmp));
t64=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1720,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[82]+1,*((C_word*)lf[83]+1));
t66=C_mutate((C_word*)lf[84]+1,*((C_word*)lf[85]+1));
t67=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1734,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1755,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1777,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1789,tmp=(C_word)a,a+=2,tmp));
t72=*((C_word*)lf[96]+1);
t73=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=t72,tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1924,tmp=(C_word)a,a+=2,tmp));
t75=*((C_word*)lf[99]+1);
t76=*((C_word*)lf[100]+1);
t77=*((C_word*)lf[101]+1);
t78=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t75,a[3]=t76,a[4]=t77,tmp=(C_word)a,a+=5,tmp));
t79=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2034,tmp=(C_word)a,a+=2,tmp));
t80=*((C_word*)lf[99]+1);
t81=*((C_word*)lf[100]+1);
t82=*((C_word*)lf[24]+1);
t83=*((C_word*)lf[101]+1);
t84=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2116,a[2]=t80,a[3]=t81,a[4]=t82,a[5]=t83,tmp=(C_word)a,a+=6,tmp));
t85=*((C_word*)lf[99]+1);
t86=*((C_word*)lf[100]+1);
t87=*((C_word*)lf[24]+1);
t88=*((C_word*)lf[101]+1);
t89=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2254,a[2]=t85,a[3]=t86,a[4]=t87,a[5]=t88,tmp=(C_word)a,a+=6,tmp));
t90=*((C_word*)lf[96]+1);
t91=*((C_word*)lf[99]+1);
t92=*((C_word*)lf[101]+1);
t93=*((C_word*)lf[100]+1);
t94=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2338,a[2]=t91,a[3]=t93,a[4]=t90,a[5]=t92,tmp=(C_word)a,a+=6,tmp));
t95=C_mutate((C_word*)lf[111]+1,*((C_word*)lf[112]+1));
t96=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2471,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2497,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)C_locative_ref,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2524,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2527,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2530,tmp=(C_word)a,a+=2,tmp));
t102=lf[120]=C_SCHEME_FALSE;;
t103=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2537,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2556,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2573,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2576,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2582,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2588,tmp=(C_word)a,a+=2,tmp));
t109=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t109+1)))(2,t109,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k642 in k639 */
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2588,3,t0,t1,t2);}
t3=(C_word)C_slot(lf[132],C_fix(0));
t4=(C_word)C_i_setslot(t2,C_fix(0),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* global-bound? in k642 in k639 */
static void f_2582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2582,3,t0,t1,t2);}
/* lolevel.scm: 671  ##sys#symbol-has-toplevel-binding? */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* global-set! in k642 in k639 */
static void f_2576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2576,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k642 in k639 */
static void f_2573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2573,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k642 in k639 */
static void f_2556(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2556r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2556r(t0,t1,t2);}}

static void f_2556r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_2561(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_2561(t4,C_SCHEME_FALSE);}}

/* k2559 in unbound-variable-value in k642 in k639 */
static void C_fcall f_2561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* invalid-procedure-call-handler in k642 in k639 */
static void f_2537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2537,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2541,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_2541(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 647  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[5],lf[121],lf[124],t2);}}

/* k2539 in invalid-procedure-call-handler in k642 in k639 */
static void f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=C_mutate(&lf[120],((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2544,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k2539 in invalid-procedure-call-handler in k642 in k639 */
static void f_2544(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2544r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2544r(t0,t1,t2);}}

static void f_2544r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 651  ipc-hook */
t3=lf[120];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,*((C_word*)lf[123]+1),t2);}

/* locative? in k642 in k639 */
static void f_2530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2530,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k642 in k639 */
static void f_2527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2527,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k642 in k639 */
static void f_2524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2524,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k642 in k639 */
static void f_2497(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2497r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2497r(t0,t1,t2,t3);}}

static void f_2497r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2505(t5,C_fix(0));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_2505(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k2503 in make-weak-locative in k642 in k639 */
static void C_fcall f_2505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 633  ##sys#make-locative */
t2=*((C_word*)lf[114]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[115]);}

/* make-locative in k642 in k639 */
static void f_2471(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2471r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2471r(t0,t1,t2,t3);}}

static void f_2471r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2479,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2479(t5,C_fix(0));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_2479(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k2477 in make-locative in k642 in k639 */
static void C_fcall f_2479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 630  ##sys#make-locative */
t2=*((C_word*)lf[114]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[113]);}

/* object-unevict in k642 in k639 */
static void f_2338(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2338r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2338r(t0,t1,t2,t3);}}

static void f_2338r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2342(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_2342(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k2340 in object-unevict in k642 in k639 */
static void C_fcall f_2342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2342,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 580  make-hash-table */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[103]+1));}

/* k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2356(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2356,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 584  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[7]))){
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
/* lolevel.scm: 587  ##sys#make-string */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lolevel.scm: 592  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 597  make-vector */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2413 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 598  hash-table-set! */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k2416 in k2413 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2427(t7,t2,t3);}

/* do523 in k2416 in k2413 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2427,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 601  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2356(t5,t3,t4);}}

/* k2446 in do523 in k2416 in k2413 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2427(t4,((C_word*)t0)[2],t3);}

/* k2419 in k2416 in k2413 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2399 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 593  hash-table-set! */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2402 in k2399 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2383 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 588  hash-table-set! */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* k2386 in k2383 in k2370 in copy in k2349 in k2340 in object-unevict in k642 in k639 */
static void f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k642 in k639 */
static void f_2254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2254,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2258,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 553  make-hash-table */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[103]+1));}

/* k2256 in object-size in k642 in k639 */
static void f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2263(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2256 in object-size in k642 in k639 */
static void C_fcall f_2263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2263,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 556  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2274 in evict in k2256 in object-size in k642 in k639 */
static void f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 560  align-to-word */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2333(2,t4,(C_word)C_bytes(t2));}}}

/* k2331 in k2274 in evict in k2256 in object-size in k642 in k639 */
static void f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 562  hash-table-set! */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],C_SCHEME_TRUE);}

/* k2283 in k2331 in k2274 in evict in k2256 in object-size in k642 in k639 */
static void f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2288(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2297(t9,t2,t5);}}

/* do490 in k2283 in k2331 in k2274 in evict in k2256 in object-size in k642 in k639 */
static void C_fcall f_2297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2297,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 569  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2263(t5,t3,t4);}}

/* k2317 in do490 in k2283 in k2331 in k2274 in evict in k2256 in object-size in k642 in k639 */
static void f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2297(t5,((C_word*)t0)[2],t4);}

/* k2286 in k2283 in k2331 in k2274 in evict in k2256 in object-size in k642 in k639 */
static void f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k642 in k639 */
static void f_2116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2116r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2116r(t0,t1,t2,t3,t4);}}

static void f_2116r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(14);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 519  ##sys#pointer->address */
t11=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}

/* k2244 in object-evict-to-location in k642 in k639 */
static void f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 519  ##sys#address->pointer */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2121 in object-evict-to-location in k642 in k639 */
static void f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 520  make-hash-table */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[103]+1));}

/* k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2134(t6,t2,((C_word*)t0)[2]);}

/* evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2134,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 524  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[8]))){
/* lolevel.scm: 528  align-to-word */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2239(2,t4,(C_word)C_bytes(t2));}}}

/* k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2156,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* lolevel.scm: 532  ##sys#error */
t6=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[105],lf[107],((C_word*)t0)[9]);}
else{
t6=t3;
f_2156(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2156(2,t4,C_SCHEME_UNDEFINED);}}

/* k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[9]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 535  ##sys#pointer->address */
t7=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[8]);}

/* k2214 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 535  ##sys#set-pointer-address! */
t3=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2160 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 536  hash-table-set! */
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k2163 in k2160 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2168(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2177(t9,t2,t5);}}

/* do467 in k2163 in k2160 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2177,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2198,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 543  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2134(t5,t3,t4);}}

/* k2196 in do467 in k2163 in k2160 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2177(t4,((C_word*)t0)[2],t3);}

/* k2166 in k2163 in k2160 in k2154 in k2237 in k2142 in evict in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2127 in k2124 in k2121 in object-evict-to-location in k642 in k639 */
static void f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 545  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k642 in k639 */
static void f_2034(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2034r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2034r(t0,t1,t2,t3);}}

static void f_2034r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2106,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2043,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2043(t9,t1,t2);}

/* release in object-release in k642 in k639 */
static void C_fcall f_2043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2043,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t5=t4;
f_2062(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t7,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2078(t9,t4,t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* do440 in release in object-release in k642 in k639 */
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2078,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 499  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2043(t5,t3,t4);}}

/* k2086 in do440 in release in object-release in k642 in k639 */
static void f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2078(t3,((C_word*)t0)[2],t2);}

/* k2060 in release in object-release in k642 in k639 */
static void f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 500  ##sys#address->pointer */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2067 in k2060 in release in object-release in k642 in k639 */
static void f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 500  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2106 in object-release in k642 in k639 */
static void f_2106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2106,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub432(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k642 in k639 */
static void f_1927(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1927r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1927r(t0,t1,t2,t3);}}

static void f_1927r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2031,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1934,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 469  make-hash-table */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[103]+1));}

/* k1932 in object-evict in k642 in k639 */
static void f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1939(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k1932 in object-evict in k642 in k639 */
static void C_fcall f_1939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1939,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 472  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 475  align-to-word */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_1958(2,t4,(C_word)C_bytes(t2));}}}

/* k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 476  allocator */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k1960 in k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[7],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[7]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 478  hash-table-set! */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k1966 in k1960 in k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_1971(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_1980(t9,t2,t5);}}

/* do417 in k1966 in k1960 in k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void C_fcall f_1980(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1980,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2001,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 483  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1939(t5,t3,t4);}}

/* k1999 in do417 in k1966 in k1960 in k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1980(t4,((C_word*)t0)[2],t3);}

/* k1969 in k1966 in k1960 in k1956 in k1947 in evict in k1932 in object-evict in k642 in k639 */
static void f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2031 in object-evict in k642 in k639 */
static void f_2031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2031,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub406(t3,t2));}

/* object-evicted? in k642 in k639 */
static void f_1924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1924,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k642 in k639 */
static void f_1843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1843,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1849(t6,t1,t2);}

/* copy in object-copy in k642 in k639 */
static void C_fcall f_1849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1849,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 444  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 448  make-vector */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1877 in copy in object-copy in k642 in k639 */
static void f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_1882(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_1894(t10,t3,t6);}}

/* do390 in k1877 in copy in object-copy in k642 in k639 */
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1894,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1915,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 452  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1849(t5,t3,t4);}}

/* k1913 in do390 in k1877 in copy in object-copy in k642 in k639 */
static void f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1894(t4,((C_word*)t0)[2],t3);}

/* k1880 in k1877 in copy in object-copy in k642 in k639 */
static void f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k642 in k639 */
static void f_1789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1789,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1802,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 430  ##sys#make-vector */
t7=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* lolevel.scm: 434  ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[5],lf[93],lf[95],t2);}}

/* k1800 in record->vector in k642 in k639 */
static void f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1807(t2,C_fix(0)));}

/* do376 in k1800 in record->vector in k642 in k639 */
static C_word C_fcall f_1807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k642 in k639 */
static void f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k642 in k639 */
static void f_1777(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1777r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1777r(t0,t1,t2,t3);}}

static void f_1777r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_apply(5,0,t1,*((C_word*)lf[91]+1),t2,t3);}

/* number-of-bytes in k642 in k639 */
static void f_1755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1755,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 412  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[5],lf[88],lf[89],t2);}}

/* number-of-slots in k642 in k639 */
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1734,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1738,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1747,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1747(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_1747(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k1745 in number-of-slots in k642 in k639 */
static void C_fcall f_1747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 407  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[5],lf[86],lf[87],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1738(2,t2,C_SCHEME_UNDEFINED);}}

/* k1736 in number-of-slots in k642 in k639 */
static void f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* static-byte-vector->pointer in k642 in k639 */
static void f_1720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1720,3,t0,t1,t2);}
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1727,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 391  ##sys#make-pointer */
t4=*((C_word*)lf[80]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* lolevel.scm: 394  ##sys#error */
t3=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[79],lf[81],t2);}}

/* k1725 in static-byte-vector->pointer in k642 in k639 */
static void f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_pointer_to_block(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* make-static-byte-vector in k642 in k639 */
static void f_1714(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1714r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1714r(t0,t1,t2,t3);}}

static void f_1714r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* lolevel.scm: 385  make */
t4=((C_word*)t0)[3];
f_1680(t4,t1,t2,t3,((C_word*)t0)[2],lf[78]);}

/* make in k642 in k639 */
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1680,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix((C_word)C_HEADER_SIZE_MASK)))){
/* lolevel.scm: 379  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t1,lf[74],t5,lf[75],t2,C_fix((C_word)C_HEADER_SIZE_MASK));}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1693,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 380  alloc */
t7=t4;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}

/* k1691 in make in k642 in k639 */
static void f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1699,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
/* lolevel.scm: 382  byte-vector-fill! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,t3);}
else{
t3=t2;
f_1699(2,t3,C_SCHEME_UNDEFINED);}}
else{
/* lolevel.scm: 384  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],lf[76],lf[77],((C_word*)t0)[2]);}}

/* k1697 in k1691 in make in k642 in k639 */
static void f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* malloc in k642 in k639 */
static void f_1677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1677,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub347(C_SCHEME_UNDEFINED,t2));}

/* byte-vector-length in k642 in k639 */
static void f_1672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1672,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}

/* byte-vector->string in k642 in k639 */
static void f_1663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1663,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1670,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 358  make-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1668 in byte-vector->string in k642 in k639 */
static void f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* string->byte-vector in k642 in k639 */
static void f_1654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1654,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1661,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 349  make-byte-vector */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1659 in string->byte-vector in k642 in k639 */
static void f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* list->byte-vector in k642 in k639 */
static void f_1607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1607,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1614,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 334  make-byte-vector */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1612 in list->byte-vector in k642 in k639 */
static void f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1619(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do326 in k1612 in list->byte-vector in k642 in k639 */
static void C_fcall f_1619(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1629,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=t5;
f_1629(2,t7,(C_word)C_setbyte(((C_word*)t0)[4],t3,t6));}
else{
/* lolevel.scm: 342  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}}

/* k1627 in do326 in k1612 in list->byte-vector in k642 in k639 */
static void f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1619(t4,((C_word*)t0)[2],t2,t3);}

/* byte-vector->list in k642 in k639 */
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1574,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1583,a[2]=t5,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1583(t7,t1,C_fix(0));}

/* loop in byte-vector->list in k642 in k639 */
static void C_fcall f_1583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1583,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_subbyte(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1601,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* lolevel.scm: 327  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k1599 in loop in byte-vector->list in k642 in k639 */
static void f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* byte-vector-set! in k642 in k639 */
static void f_1550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1550,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(C_word)C_fixnum_lessp(t3,C_fix(0));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greater_or_equal_p(t3,t5));
if(C_truep(t7)){
/* lolevel.scm: 317  ##sys#error */
t8=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[65],lf[66],t2,t3);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_setbyte(t2,t3,t4));}}

/* byte-vector-ref in k642 in k639 */
static void f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1526,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=(C_word)C_fixnum_lessp(t3,C_fix(0));
t6=(C_truep(t5)?t5:(C_word)C_fixnum_greater_or_equal_p(t3,t4));
if(C_truep(t6)){
/* lolevel.scm: 307  ##sys#error */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[63],lf[64],t2,t3);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_subbyte(t2,t3));}}

/* byte-vector in k642 in k639 */
static void f_1487(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1487r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1487r(t0,t1,t2);}}

static void f_1487r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1494,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 295  make-byte-vector */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1492 in byte-vector in k642 in k639 */
static void f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1499,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1499(t2,C_fix(0),((C_word*)t0)[2]));}

/* do300 in k1492 in byte-vector in k642 in k639 */
static C_word C_fcall f_1499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_setbyte(((C_word*)t0)[2],t1,t3);
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* make-byte-vector in k642 in k639 */
static void f_1468(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1468r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1468r(t0,t1,t2,t3);}}

static void f_1468r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 286  ##sys#allocate-vector */
t5=*((C_word*)lf[61]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k1470 in make-byte-vector in k642 in k639 */
static void f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[3]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
/* lolevel.scm: 288  byte-vector-fill! */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t1,t4);}
else{
t4=t3;
f_1475(2,t4,C_SCHEME_UNDEFINED);}}

/* k1473 in k1470 in make-byte-vector in k642 in k639 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-fill! in k642 in k639 */
static void f_1440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1440,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1449,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_1449(t5,C_fix(0)));}

/* do285 in byte-vector-fill! in k642 in k639 */
static C_word C_fcall f_1449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_setbyte(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* byte-vector? in k642 in k639 */
static void f_1434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_bytevectorp(t2):C_SCHEME_FALSE));}

/* set-procedure-data! in k642 in k639 */
static void f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1419,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 262  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k1421 in set-procedure-data! in k642 in k639 */
static void f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 265  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[5],lf[56],lf[57],((C_word*)t0)[3]);}}

/* procedure-data in k642 in k639 */
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1385,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1403,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 256  ##sys#lambda-decoration */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1402 in procedure-data in k642 in k639 */
static void f_1403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1403,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[50],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1393 in procedure-data in k642 in k639 */
static void f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k642 in k639 */
static void f_1354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1354,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1369,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 250  ##sys#lambda-decoration */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1368 in extended-procedure? in k642 in k639 */
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[50],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1365 in extended-procedure? in k642 in k639 */
static void f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k642 in k639 */
static void f_1322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1322,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1328,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 240  ##sys#decorate-lambda */
t6=*((C_word*)lf[52]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t4,t5);}

/* a1343 in extend-procedure in k642 in k639 */
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1344,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[50],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1327 in extend-procedure in k642 in k639 */
static void f_1328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1328,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[50],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k642 in k639 */
static void f_1300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1300,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 229  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[5],lf[43],lf[48],t2);}}

/* tagged-pointer? in k642 in k639 */
static void f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1284,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k642 in k639 */
static void f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1269,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1273,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 214  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1271 in tag-pointer in k642 in k639 */
static void f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1276(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 217  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[5],lf[43],lf[44],((C_word*)t0)[2]);}}

/* k1274 in k1271 in tag-pointer in k642 in k639 */
static void f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-ref in k642 in k639 */
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1259,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub253(t3,t4));}

/* pointer-f32-ref in k642 in k639 */
static void f_1249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1249,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub246(t3,t4));}

/* pointer-s32-ref in k642 in k639 */
static void f_1239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1239,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub239(t3,t4));}

/* pointer-u32-ref in k642 in k639 */
static void f_1229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1229,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub232(t3,t4));}

/* pointer-s16-ref in k642 in k639 */
static void f_1219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1219,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub226(C_SCHEME_UNDEFINED,t3));}

/* pointer-u16-ref in k642 in k639 */
static void f_1209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1209,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub220(C_SCHEME_UNDEFINED,t3));}

/* pointer-s8-ref in k642 in k639 */
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1199,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub214(C_SCHEME_UNDEFINED,t3));}

/* pointer-u8-ref in k642 in k639 */
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1189,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub208(C_SCHEME_UNDEFINED,t3));}

/* pointer-f64-set! in k642 in k639 */
static void f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1179,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub201(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-f32-set! in k642 in k639 */
static void f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1169,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub193(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s32-set! in k642 in k639 */
static void f_1159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1159,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub185(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u32-set! in k642 in k639 */
static void f_1149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1149,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub177(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s16-set! in k642 in k639 */
static void f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1139,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub169(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u16-set! in k642 in k639 */
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1129,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub161(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s8-set! in k642 in k639 */
static void f_1119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1119,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub153(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u8-set! in k642 in k639 */
static void f_1109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1109,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub145(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-offset in k642 in k639 */
static void f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1099,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub136(t4,t5,t3));}

/* align-to-word in k642 in k639 */
static void f_1067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1067,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 186  align */
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1065(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1094,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 188  ##sys#pointer->address */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 189  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[5],lf[24],lf[25],t2);}}}

/* k1092 in align-to-word in k642 in k639 */
static void f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=f_1065(C_a_i(&a,6),t1);
/* lolevel.scm: 188  ##sys#address->pointer */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k642 in k639 */
static C_word C_fcall f_1065(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
return((C_word)stub129(t2,t1));}

/* free in k642 in k639 */
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1055,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub122(C_SCHEME_UNDEFINED,t3));}

/* allocate in k642 in k639 */
static void f_1052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1052,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub117(t3,t2));}

/* pointer=? in k642 in k639 */
static void f_1049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1049,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_pointer_eqp(t2,t3));}

/* pointer->object in k642 in k639 */
static void f_1046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1046,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_pointer_to_object(t2));}

/* object->pointer in k642 in k639 */
static void f_1035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1035,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1043,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1043 in object->pointer in k642 in k639 */
static void f_1043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1043,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub109(t3,t2));}

/* null-pointer? in k642 in k639 */
static void f_1025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 163  ##sys#pointer->address */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1031 in null-pointer? in k642 in k639 */
static void f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k642 in k639 */
static void f_1019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1019,3,t0,t1,t2);}
/* lolevel.scm: 159  ##sys#pointer->address */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* address->pointer in k642 in k639 */
static void f_1013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1013,3,t0,t1,t2);}
/* lolevel.scm: 155  ##sys#address->pointer */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* pointer? in k642 in k639 */
static void f_1004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1004,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k642 in k639 */
static void f_985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_985,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_992,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_992(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_992(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_992(t5,C_SCHEME_FALSE);}}

/* k990 in ##sys#check-pointer in k642 in k639 */
static void C_fcall f_992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 140  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[5],((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* move-memory! in k642 in k639 */
static void f_698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_698r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_698r(t0,t1,t2,t3,t4);}}

static void f_698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_701,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_707,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_713,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_734,a[2]=t7,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t9,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_734(t11,t1,t2,t3);}

/* move in move-memory! in k642 in k639 */
static void C_fcall f_734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_734,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[7]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 113  move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 114  xerr */
f_707(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[7]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 117  move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 118  xerr */
f_707(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_796,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_796(2,t6,t4);}
else{
/* lolevel.scm: 119  ##sys#locative? */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k794 in move in move-memory! in k642 in k639 */
static void f_796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_796,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_805(2,t4,t2);}
else{
/* lolevel.scm: 120  ##sys#locative? */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 124  ##sys#bytevector? */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k887 in k794 in move in move-memory! in k642 in k639 */
static void f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[7]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[7]);
if(C_truep((C_word)C_pointerp(((C_word*)t0)[6]))){
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_912(t6,t3);}
else{
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_912(t8,(C_truep(t7)?(C_word)C_u_i_car(t4):C_SCHEME_TRUE));}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 127  ##sys#bytevector? */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}}
else{
/* lolevel.scm: 130  xerr */
f_707(((C_word*)t0)[3],((C_word*)t0)[7]);}}

/* k932 in k887 in k794 in move in move-memory! in k642 in k639 */
static void f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[7]));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_948(t5,((C_word*)t0)[3]);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_948(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}
else{
/* lolevel.scm: 129  xerr */
f_707(((C_word*)t0)[5],((C_word*)t0)[7]);}}

/* k946 in k932 in k887 in k794 in move in move-memory! in k642 in k639 */
static void C_fcall f_948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[2];
t6=(C_truep(t4)?t4:C_SCHEME_FALSE);
t7=(C_truep(t5)?t5:C_SCHEME_FALSE);
t8=t3;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub46(C_SCHEME_UNDEFINED,t6,t7,t1));}

/* k910 in k887 in k794 in move in move-memory! in k642 in k639 */
static void C_fcall f_912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=f_713(t1);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=(C_truep(t5)?t5:C_SCHEME_FALSE);
t8=t3;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub22(C_SCHEME_UNDEFINED,t6,t7,t2));}

/* k803 in k794 in move in move-memory! in k642 in k639 */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* lolevel.scm: 120  err */
t4=((C_word*)t0)[4];
f_701(t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_812(2,t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 121  ##sys#bytevector? */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k835 in k803 in k794 in move in move-memory! in k642 in k639 */
static void f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[8]));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* lolevel.scm: 122  err */
t5=((C_word*)t0)[3];
f_701(t5,t4);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_851(2,t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}
else{
/* lolevel.scm: 123  xerr */
f_707(((C_word*)t0)[5],((C_word*)t0)[8]);}}

/* k849 in k835 in k803 in k794 in move in move-memory! in k642 in k639 */
static void f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=f_713(t1);
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[2];
t7=(C_truep(t5)?t5:C_SCHEME_FALSE);
t8=(C_truep(t6)?(C_word)C_i_foreign_pointer_argumentp(t6):C_SCHEME_FALSE);
t9=t4;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub34(C_SCHEME_UNDEFINED,t7,t8,t3));}

/* k810 in k803 in k794 in move in move-memory! in k642 in k639 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub10(C_SCHEME_UNDEFINED,t5,t6,t1));}

/* checkn in move-memory! in k642 in k639 */
static C_word C_fcall f_713(C_word t1){
C_word tmp;
C_word t2;
return(t1);}

/* xerr in move-memory! in k642 in k639 */
static void C_fcall f_707(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_707,NULL,2,t1,t2);}
/* lolevel.scm: 101  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[5],lf[1],lf[6],t2);}

/* err in move-memory! in k642 in k639 */
static void C_fcall f_701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_701,NULL,2,t0,t1);}
/* lolevel.scm: 100  ##sys#error */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[1],lf[3],((C_word*)t0)[3],((C_word*)t0)[2]);}
/* end of file */
