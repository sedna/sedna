/* Generated from partition.scm by the Chicken compiler
   2005-09-24 22:23
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: partition.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file partition.c -explicit-use
   unit: partition
*/

#include "chicken.h"

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_tinyclos_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[165];


C_externexport void C_partition_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_452(C_word c,C_word t0,C_word t1) C_noret;
static void f_455(C_word c,C_word t0,C_word t1) C_noret;
static void f_458(C_word c,C_word t0,C_word t1) C_noret;
static void f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
static void f_1703(C_word c,C_word t0,C_word t1) C_noret;
static void f_1709(C_word c,C_word t0,C_word t1) C_noret;
static void f_1712(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2216(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2250(C_word c,C_word t0,C_word t1) C_noret;
static void f_2261(C_word c,C_word t0,C_word t1) C_noret;
static void f_2232(C_word c,C_word t0,C_word t1) C_noret;
static void f_2243(C_word c,C_word t0,C_word t1) C_noret;
static void f_1715(C_word c,C_word t0,C_word t1) C_noret;
static void f_1722(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1728(C_word c,C_word t0,C_word t1) C_noret;
static void f_921(C_word c,C_word t0,C_word t1) C_noret;
static void f_2160(C_word c,C_word t0,C_word t1) C_noret;
static void f_2204(C_word c,C_word t0,C_word t1) C_noret;
static void f_2194(C_word c,C_word t0,C_word t1) C_noret;
static void f_2163(C_word c,C_word t0,C_word t1) C_noret;
static void f_2190(C_word c,C_word t0,C_word t1) C_noret;
static void f_2186(C_word c,C_word t0,C_word t1) C_noret;
static void f_2173(C_word c,C_word t0,C_word t1) C_noret;
static void f_2166(C_word c,C_word t0,C_word t1) C_noret;
static void f_1734(C_word c,C_word t0,C_word t1) C_noret;
static void f_1738(C_word c,C_word t0,C_word t1) C_noret;
static void f_2149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2157(C_word c,C_word t0,C_word t1) C_noret;
static void f_1746(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1030(C_word c,C_word t0,C_word t1) C_noret;
static void f_1033(C_word c,C_word t0,C_word t1) C_noret;
static void f_1044(C_word c,C_word t0,C_word t1) C_noret;
static void f_590(C_word c,C_word t0,C_word t1) C_noret;
static void f_593(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1985(C_word c,C_word t0,C_word t1) C_noret;
static void f_2123(C_word c,C_word t0,C_word t1) C_noret;
static void f_2135(C_word c,C_word t0,C_word t1) C_noret;
static void f_2139(C_word c,C_word t0,C_word t1) C_noret;
static void f_2127(C_word c,C_word t0,C_word t1) C_noret;
static void f_2131(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1996(C_word t0,C_word t1) C_noret;
static void f_2120(C_word c,C_word t0,C_word t1) C_noret;
static void f_1999(C_word c,C_word t0,C_word t1) C_noret;
static void f_2112(C_word c,C_word t0,C_word t1) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1) C_noret;
static void f_2104(C_word c,C_word t0,C_word t1) C_noret;
static void f_2077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2081(C_word c,C_word t0,C_word t1) C_noret;
static void f_997(C_word c,C_word t0,C_word t1) C_noret;
static void f_1000(C_word c,C_word t0,C_word t1) C_noret;
static void f_1006(C_word c,C_word t0,C_word t1) C_noret;
static void f_1009(C_word c,C_word t0,C_word t1) C_noret;
static void f_2090(C_word c,C_word t0,C_word t1) C_noret;
static void f_2093(C_word c,C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void f_2008(C_word c,C_word t0,C_word t1) C_noret;
static void f_2059(C_word c,C_word t0,C_word t1) C_noret;
static void f_2062(C_word c,C_word t0,C_word t1) C_noret;
static void f_2065(C_word c,C_word t0,C_word t1) C_noret;
static void f_2068(C_word c,C_word t0,C_word t1) C_noret;
static void f_2075(C_word c,C_word t0,C_word t1) C_noret;
static void f_2011(C_word c,C_word t0,C_word t1) C_noret;
static void f_2033(C_word c,C_word t0,C_word t1) C_noret;
static void f_2025(C_word c,C_word t0,C_word t1) C_noret;
static void f_1750(C_word c,C_word t0,C_word t1) C_noret;
static void f_1924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1940(C_word t0,C_word t1) C_noret;
static void f_1753(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1899(C_word c,C_word t0,C_word t1) C_noret;
static void f_1756(C_word c,C_word t0,C_word t1) C_noret;
static void f_1862(C_word c,C_word t0,C_word t1) C_noret;
static void f_1880(C_word c,C_word t0,C_word t1) C_noret;
static void f_1759(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1851(C_word c,C_word t0,C_word t1) C_noret;
static void f_1826(C_word c,C_word t0,C_word t1) C_noret;
static void f_1762(C_word c,C_word t0,C_word t1) C_noret;
static void f_1771(C_word c,C_word t0,C_word t1) C_noret;
static void f_1796(C_word c,C_word t0,C_word t1) C_noret;
static void f_2206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2214(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1681(C_word t0);
static C_word C_fcall f_1645(C_word t0);
static void f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_1601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1627(C_word c,C_word t0,C_word t1) C_noret;
static void f_1610(C_word c,C_word t0,C_word t1) C_noret;
static void f_1546(C_word c,C_word t0,C_word t1) C_noret;
static void f_1561(C_word c,C_word t0,C_word t1) C_noret;
static void f_1491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1537(C_word c,C_word t0,C_word t1) C_noret;
static void f_1514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1529(C_word c,C_word t0,C_word t1) C_noret;
static void f_1512(C_word c,C_word t0,C_word t1) C_noret;
static void f_1495(C_word c,C_word t0,C_word t1) C_noret;
static void f_1449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_697(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1456(C_word c,C_word t0,C_word t1) C_noret;
static void f_1489(C_word c,C_word t0,C_word t1) C_noret;
static void f_1470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1485(C_word c,C_word t0,C_word t1) C_noret;
static void f_1462(C_word c,C_word t0,C_word t1) C_noret;
static void f_1425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_662(C_word t0,C_word t1,C_word t2) C_noret;
static void f_673(C_word c,C_word t0,C_word t1) C_noret;
static void f_677(C_word c,C_word t0,C_word t1) C_noret;
static void f_1443(C_word c,C_word t0,C_word t1) C_noret;
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1439(C_word c,C_word t0,C_word t1) C_noret;
static void f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1423(C_word c,C_word t0,C_word t1) C_noret;
static void f_1405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1413(C_word c,C_word t0,C_word t1) C_noret;
static void f_1395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1403(C_word c,C_word t0,C_word t1) C_noret;
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1393(C_word c,C_word t0,C_word t1) C_noret;
static void f_1375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1383(C_word c,C_word t0,C_word t1) C_noret;
static void f_1365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1373(C_word c,C_word t0,C_word t1) C_noret;
static void f_1351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1359(C_word c,C_word t0,C_word t1) C_noret;
static void f_1345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1310(C_word c,C_word t0,C_word t1) C_noret;
static void f_1325(C_word c,C_word t0,C_word t1) C_noret;
static void f_1296(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1296r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1304(C_word c,C_word t0,C_word t1) C_noret;
static void f_1279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1283(C_word c,C_word t0,C_word t1) C_noret;
static void f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1237(C_word t0);
static C_word C_fcall f_1219(C_word t0);
static C_word C_fcall f_1189(C_word t0);
static void f_1171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1123(C_word t0);
static C_word C_fcall f_1087(C_word t0);
static void C_fcall f_949(C_word t0,C_word t1,C_word t2) C_noret;
static void f_956(C_word c,C_word t0,C_word t1) C_noret;
static void f_959(C_word c,C_word t0,C_word t1) C_noret;
static void f_962(C_word c,C_word t0,C_word t1) C_noret;
static void f_969(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_923(C_word t0);
static C_word C_fcall f_895(C_word t0);
static C_word C_fcall f_877(C_word t0);
static C_word C_fcall f_829(C_word t0);
static C_word C_fcall f_811(C_word t0);
static void C_fcall f_714(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_724(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_742(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_601(C_word t0,C_word t1,C_word t2) C_noret;
static void f_647(C_word c,C_word t0,C_word t1) C_noret;
static void f_611(C_word c,C_word t0,C_word t1) C_noret;
static void f_614(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_562(C_word t0,C_word t1,C_word t2) C_noret;
static void f_575(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_572(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_527(C_word *a);
static void C_fcall f_518(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_509(C_word t0);
static void C_fcall f_500(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_491(C_word t0);
static C_word C_fcall f_473(C_word t0);

static void C_fcall trf_2216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2216(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2216(t0,t1,t2,t3);}

static void C_fcall trf_1724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1724(t0,t1,t2);}

static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1968(t0,t1,t2);}

static void C_fcall trf_1996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1996(t0,t1);}

static void C_fcall trf_1940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1940(t0,t1);}

static void C_fcall trf_1889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1889(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1889(t0,t1,t2,t3);}

static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1810(t0,t1,t2);}

static void C_fcall trf_697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_697(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_697(t0,t1,t2,t3);}

static void C_fcall trf_662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_662(t0,t1,t2);}

static void C_fcall trf_949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_949(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_949(t0,t1,t2);}

static void C_fcall trf_714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_714(t0,t1,t2);}

static void C_fcall trf_724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_724(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_724(t0,t1,t2,t3);}

static void C_fcall trf_601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_601(t0,t1,t2);}

static void C_fcall trf_562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_562(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_562(t0,t1,t2);}

static void C_fcall trf_572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_572(t0,t1);}

static void C_fcall trf_518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_518(t0,t1,t2);}

static void C_fcall trf_500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_500(t0,t1,t2);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_partition_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_partition_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("partition_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(513)){
C_save(t1);
C_rereclaim2(513*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,165);
lf[0]=C_h_intern(&lf[0],20,"\010compilersplit-level");
lf[2]=C_h_intern(&lf[2],11,"dlist-item$");
lf[3]=C_static_lambda_info(C_heaptop,19,"(dlist-item$-value)");
lf[5]=C_static_lambda_info(C_heaptop,18,"(dlist-item$-left)");
lf[7]=C_h_intern(&lf[7],14,"\003sysblock-set!");
lf[8]=C_static_lambda_info(C_heaptop,33,"(dlist-item$-left-set! x14 val15)");
lf[10]=C_static_lambda_info(C_heaptop,19,"(dlist-item$-right)");
lf[12]=C_static_lambda_info(C_heaptop,34,"(dlist-item$-right-set! x20 val21)");
lf[14]=C_static_lambda_info(C_heaptop,13,"(make-dlist$)");
lf[16]=C_static_lambda_info(C_heaptop,34,"(dlist$-add-tail! dlist33 value34)");
lf[18]=C_h_intern(&lf[18],7,"REMOVED");
lf[19]=C_static_lambda_info(C_heaptop,36,"(dlist$-remove! dlist45 dlistitem46)");
lf[21]=C_static_lambda_info(C_heaptop,14,"(loop n67 c68)");
lf[22]=C_static_lambda_info(C_heaptop,29,"(dlist$-count pred64 dlist65)");
lf[24]=C_h_intern(&lf[24],8,"bucket$$");
lf[25]=C_static_lambda_info(C_heaptop,13,"(bucket$$-db)");
lf[27]=C_static_lambda_info(C_heaptop,19,"(bucket$$-gainproc)");
lf[29]=C_h_intern(&lf[29],12,"bucket-item$");
lf[30]=C_static_lambda_info(C_heaptop,19,"(bucket-item$-gain)");
lf[32]=C_static_lambda_info(C_heaptop,24,"(bucket-item$-dlistitem)");
lf[34]=C_static_lambda_info(C_heaptop,14,"(bucket$-gain)");
lf[36]=C_h_intern(&lf[36],15,"hash-table-set!");
lf[37]=C_h_intern(&lf[37],22,"hash-table-ref/default");
lf[38]=C_static_lambda_info(C_heaptop,32,"(bucket$-add! bucket126 item127)");
lf[40]=C_h_intern(&lf[40],17,"graph-cell-info$$");
lf[41]=C_static_lambda_info(C_heaptop,22,"(graph-cell-info$$-id)");
lf[43]=C_static_lambda_info(C_heaptop,29,"(graph-cell-info$$-partition)");
lf[44]=C_h_intern(&lf[44],31,"graph-cell-info$$-inregion-set!");
lf[45]=C_static_lambda_info(C_heaptop,45,"(graph-cell-info$$-inregion-set! x179 val180)");
lf[46]=C_h_intern(&lf[46],17,"graph-cell$$-info");
lf[47]=C_h_intern(&lf[47],12,"graph-cell$$");
lf[48]=C_static_lambda_info(C_heaptop,24,"(graph-cell$$-info x191)");
lf[50]=C_static_lambda_info(C_heaptop,23,"(graph-cell$$-vertices)");
lf[52]=C_h_intern(&lf[52],7,"graph$$");
lf[53]=C_static_lambda_info(C_heaptop,15,"(graph$$-cells)");
lf[55]=C_static_lambda_info(C_heaptop,19,"(graph$$-num-cells)");
lf[56]=C_h_intern(&lf[56],16,"make-graph-cell$");
lf[57]=C_static_lambda_info(C_heaptop,24,"(make-graph-cell$ id224)");
lf[58]=C_h_intern(&lf[58],21,"graph-cell$-add-edge!");
lf[59]=C_static_lambda_info(C_heaptop,41,"(graph-cell$-add-edge! cell1225 cell2226)");
lf[60]=C_h_intern(&lf[60],32,"graph-cell$-add-undirected-edge!");
lf[61]=C_static_lambda_info(C_heaptop,52,"(graph-cell$-add-undirected-edge! cell1227 cell2228)");
lf[62]=C_h_intern(&lf[62],11,"make-graph$");
lf[63]=C_h_intern(&lf[63],15,"make-hash-table");
lf[64]=C_static_lambda_info(C_heaptop,23,"(make-graph$ . rest230)");
lf[65]=C_h_intern(&lf[65],16,"graph$-add-cell!");
lf[66]=C_static_lambda_info(C_heaptop,35,"(graph$-add-cell! graph231 cell232)");
lf[67]=C_h_intern(&lf[67],10,"graph$-get");
lf[68]=C_static_lambda_info(C_heaptop,27,"(graph$-get graph234 id235)");
lf[69]=C_h_intern(&lf[69],13,"graph$-length");
lf[70]=C_static_lambda_info(C_heaptop,24,"(graph$-length graph236)");
lf[71]=C_h_intern(&lf[71],12,"graph$->list");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],3,"cdr");
lf[74]=C_h_intern(&lf[74],17,"hash-table->alist");
lf[75]=C_static_lambda_info(C_heaptop,23,"(graph$->list graph237)");
lf[77]=C_h_intern(&lf[77],12,"\003sysfor-each");
lf[78]=C_static_lambda_info(C_heaptop,34,"(graph$-for-each proc238 graph239)");
lf[79]=C_h_intern(&lf[79],8,"graph*id");
lf[80]=C_static_lambda_info(C_heaptop,18,"(graph*id cell240)");
lf[81]=C_h_intern(&lf[81],11,"graph*color");
lf[82]=C_static_lambda_info(C_heaptop,21,"(graph*color cell241)");
lf[83]=C_h_intern(&lf[83],16,"graph*color-set!");
lf[84]=C_static_lambda_info(C_heaptop,35,"(graph*color-set! cell242 color243)");
lf[85]=C_h_intern(&lf[85],15,"graph*partition");
lf[86]=C_static_lambda_info(C_heaptop,25,"(graph*partition cell244)");
lf[87]=C_h_intern(&lf[87],21,"graph*partition-move!");
lf[88]=C_static_lambda_info(C_heaptop,44,"(graph*partition-move! cell245 partition246)");
lf[89]=C_h_intern(&lf[89],16,"graph*neighbours");
lf[90]=C_static_lambda_info(C_heaptop,12,"(a1430 c248)");
lf[91]=C_h_intern(&lf[91],6,"filter");
lf[92]=C_h_intern(&lf[92],8,"identity");
lf[93]=C_static_lambda_info(C_heaptop,10,"(loop n57)");
lf[94]=C_static_lambda_info(C_heaptop,26,"(graph*neighbours cell247)");
lf[95]=C_h_intern(&lf[95],10,"graph*gain");
lf[96]=C_static_lambda_info(C_heaptop,13,"(a1469 c2254)");
lf[97]=C_static_lambda_info(C_heaptop,14,"(loop n61 c62)");
lf[98]=C_static_lambda_info(C_heaptop,20,"(graph*gain cell249)");
lf[99]=C_h_intern(&lf[99],10,"graph*cost");
lf[100]=C_static_lambda_info(C_heaptop,13,"(a1513 c2262)");
lf[101]=C_static_lambda_info(C_heaptop,13,"(a1499 c1260)");
lf[102]=C_static_lambda_info(C_heaptop,21,"(graph*cost graph258)");
lf[103]=C_h_intern(&lf[103],13,"graph*balance");
lf[104]=C_h_intern(&lf[104],8,"for-each");
lf[105]=C_h_intern(&lf[105],3,"max");
lf[106]=C_static_lambda_info(C_heaptop,12,"(a1600 c272)");
lf[107]=C_static_lambda_info(C_heaptop,61,"(graph*balance graph265 num-cells266 weight267 n#f268 n#t269)");
lf[109]=C_h_intern(&lf[109],13,"partition-fmv");
lf[110]=C_static_lambda_info(C_heaptop,20,"(partition-fmv-cost)");
lf[112]=C_static_lambda_info(C_heaptop,20,"(partition-fmv-cell)");
lf[113]=C_h_intern(&lf[113],21,"\010compilerpartition-fm");
lf[114]=C_static_lambda_info(C_heaptop,15,"(a2205 cell332)");
lf[115]=C_static_lambda_info(C_heaptop,22,"(apply-moves costs371)");
lf[116]=C_h_intern(&lf[116],18,"\010compilerdebugging");
lf[117]=C_h_intern(&lf[117],1,"Q");
lf[118]=C_static_string(C_heaptop,16,"      cost,id = ");
lf[119]=C_static_string(C_heaptop,1,",");
lf[120]=C_static_string(C_heaptop,25,"      no least cost point");
lf[121]=C_static_string(C_heaptop,25,"    Pick least cost point");
lf[122]=C_static_lambda_info(C_heaptop,27,"(reset cells366 initial367)");
lf[123]=C_static_lambda_info(C_heaptop,14,"(a1923 fmv362)");
lf[124]=C_h_intern(&lf[124],1,"P");
lf[125]=C_h_intern(&lf[125],26,"\010compilerdebugging-chicken");
lf[126]=C_h_intern(&lf[126],1,"R");
lf[127]=C_static_string(C_heaptop,32,"      (balance weight n#f n#t)  ");
lf[128]=C_static_string(C_heaptop,32,"      current-cost              ");
lf[129]=C_static_string(C_heaptop,32,"      (cost)                    ");
lf[130]=C_static_string(C_heaptop,21,"    Note current cost");
lf[131]=C_static_string(C_heaptop,26,"    Update neighbour gain ");
lf[132]=C_static_string(C_heaptop,4," to ");
lf[133]=C_h_intern(&lf[133],5,"error");
lf[134]=C_static_string(C_heaptop,45,"recalc! cannot occur on a deleted bucket item");
lf[135]=C_h_intern(&lf[135],14,"hash-table-ref");
lf[136]=C_static_lambda_info(C_heaptop,12,"(a2076 c341)");
lf[137]=C_static_string(C_heaptop,11,"      id   ");
lf[138]=C_h_intern(&lf[138],4,"sub1");
lf[139]=C_h_intern(&lf[139],4,"add1");
lf[140]=C_static_string(C_heaptop,11,"      gain ");
lf[141]=C_static_string(C_heaptop,31,"    Move cell with largest gain");
lf[142]=C_static_string(C_heaptop,37,"The dlist is empty; cannot get first!");
lf[143]=C_static_string(C_heaptop,44,"No items remain in bucket to remove-largest!");
lf[144]=C_static_lambda_info(C_heaptop,24,"(a1048 gain146 dlist147)");
lf[145]=C_h_intern(&lf[145],15,"hash-table-walk");
lf[146]=C_static_lambda_info(C_heaptop,21,"(loop2 cells-free337)");
lf[147]=C_static_lambda_info(C_heaptop,12,"(a2148 c335)");
lf[148]=C_h_intern(&lf[148],5,"count");
lf[149]=C_h_intern(&lf[149],3,"not");
lf[150]=C_static_string(C_heaptop,22,"    initial-cost      ");
lf[151]=C_static_string(C_heaptop,22,"    initial-id        ");
lf[152]=C_h_intern(&lf[152],6,"append");
lf[153]=C_static_string(C_heaptop,3,"...");
lf[154]=C_h_intern(&lf[154],4,"take");
lf[155]=C_static_string(C_heaptop,22,"    initial-partition ");
lf[156]=C_static_string(C_heaptop,3,"...");
lf[157]=C_static_string(C_heaptop,25,"  Repeat until no updates");
lf[158]=C_h_intern(&lf[158],3,"eq\077");
lf[159]=C_static_lambda_info(C_heaptop,23,"(loop1 initial-cost324)");
lf[160]=C_static_lambda_info(C_heaptop,17,"(loop1 l316 n317)");
lf[161]=C_h_intern(&lf[161],7,"shuffle");
lf[162]=C_static_string(C_heaptop,34,"Fiduccia-Mattheyses bipartitioning");
lf[163]=C_static_lambda_info(C_heaptop,159,"(##compiler#partition-fm cells300 id301 color302 color-set!303 partition304 part"
"ition-move!305 neighbours306 gain307 cost308 balance309 weight310 criterion311)");
lf[164]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,165);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k450 */
static void f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k453 in k450 */
static void f_455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tinyclos_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k456 in k453 in k450 */
static void f_458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[129],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_458,2,t0,t1);}
t2=C_set_block_item(lf[0],0,C_fix(1));
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_491,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_509,a[2]=lf[10],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_527,a[2]=lf[14],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_562,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_601,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_714,a[2]=lf[22],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[23],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_811,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[26],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_829,a[2]=lf[27],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[28],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=lf[30],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[31],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=lf[32],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[33],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=lf[34],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[35],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_949,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[39],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1150,a[2]=lf[45],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=lf[48],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate(&lf[49],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate(&lf[51],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1219,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate(&lf[54],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1237,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=lf[59],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=lf[61],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=lf[66],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=lf[68],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1351,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate(&lf[76],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=lf[86],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1425,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=lf[98],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=lf[107],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate(&lf[108],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1645,a[2]=lf[110],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate(&lf[111],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp));
t46=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t46+1)))(2,t46,C_SCHEME_UNDEFINED);}

/* ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(c!=14) C_bad_argc(c,14);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_1699,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
t14=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1703,a[2]=t1,a[3]=t3,a[4]=t8,a[5]=t4,a[6]=t5,a[7]=t12,a[8]=t11,a[9]=t13,a[10]=t6,a[11]=t7,a[12]=t10,a[13]=t9,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* partition.scm: 450  ##compiler#debugging */
t15=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,lf[124],lf[162],t12);}

/* k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1703,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_cdr(((C_word*)t0)[7]);
t8=(C_word)C_a_i_plus(&a,2,t6,t7);
C_quotient(4,0,t3,t5,t8);}

/* k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1712,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* partition.scm: 454  shuffle */
t3=C_retrieve(lf[161]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}

/* k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[13],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=lf[160],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2216(t6,t2,t1,C_fix(0));}

/* loop1 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_2216(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2216,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_lessp(t3,((C_word*)t0)[4]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2232,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* partition.scm: 459  partition-move! */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2250,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* partition.scm: 462  partition-move! */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,C_SCHEME_TRUE);}}}

/* k2248 in loop1 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2261,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 463  add1 */
t4=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2259 in k2248 in loop1 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 463  loop1 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2216(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2230 in loop1 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 460  add1 */
t4=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2241 in k2230 in loop1 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 460  loop1 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2216(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* partition.scm: 466  cost */
t3=((C_word*)t0)[13];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=lf[159],tmp=(C_word)a,a+=17,tmp));
t5=((C_word*)t3)[1];
f_1724(t5,((C_word*)t0)[2],t1);}

/* loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1724,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=t2,a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[10],((C_word*)t0)[9]);}

/* k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp);
t9=((C_word*)t0)[17];
t10=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t3,a[18]=t7,a[19]=((C_word*)t0)[16],a[20]=t5,a[21]=t8,a[22]=t9,tmp=(C_word)a,a+=23,tmp);
/* partition.scm: 172  make-hash-table */
t11=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,*((C_word*)lf[158]+1));}

/* k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_921,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[24],t1,((C_word*)t0)[22],((C_word*)t0)[21]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t6,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t4,a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],a[6]=((C_word*)t0)[16],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* partition.scm: 478  ##compiler#debugging */
t9=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[124],lf[157]);}

/* k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_lessp(((C_word*)t0)[5],C_fix(10)))){
t4=t3;
f_2194(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2204,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 480  take */
t5=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_fix(10));}}
else{
t2=((C_word*)t0)[7];
f_1734(2,t2,C_SCHEME_UNDEFINED);}}

/* k2202 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 480  append */
t2=*((C_word*)lf[152]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[156]);}

/* k2192 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 479  ##compiler#debugging */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],lf[155],t1);}

/* k2161 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_lessp(((C_word*)t0)[4],C_fix(10)))){
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2188 in k2161 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 482  take */
t2=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(10));}

/* k2184 in k2161 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 482  append */
t2=*((C_word*)lf[152]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[153]);}

/* k2171 in k2161 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 481  ##compiler#debugging */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],lf[151],t1);}

/* k2164 in k2161 in k2158 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 483  ##compiler#debugging */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[124],lf[150],((C_word*)t0)[2]);}

/* k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* partition.scm: 484  count */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,*((C_word*)lf[149]+1),((C_word*)t0)[9]);}

/* k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[22])+1,t1);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[21],((C_word*)((C_word*)t0)[22])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[20])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[19])+1,((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[21],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[19],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[15],a[20]=((C_word*)t0)[16],a[21]=((C_word*)t0)[18],a[22]=((C_word*)t0)[17],tmp=(C_word)a,a+=23,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=lf[147],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[10]);}

/* a2148 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2149,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2157,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 491  bucket$-add! */
f_949(t3,((C_word*)t0)[2],t2);}

/* k2155 in a2148 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 491  color-set! */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[19],a[10]=((C_word*)t0)[20],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[22],tmp=(C_word)a,a+=13,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t4,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=lf[146],tmp=(C_word)a,a+=16,tmp));
t6=((C_word*)t4)[1];
f_1968(t6,t2,((C_word*)t0)[2]);}

/* loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=f_811(((C_word*)t0)[14]);
t8=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1030,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t2,a[16]=t1,a[17]=((C_word*)t0)[13],a[18]=t4,a[19]=t6,tmp=(C_word)a,a+=20,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1049,a[2]=t6,a[3]=lf[144],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 218  hash-table-walk */
t10=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t7,t9);}}

/* a1048 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1049,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]);
t5=(C_truep(t4)?t4:(C_word)C_i_greaterp(t2,((C_word*)((C_word*)t0)[2])[1]));
if(C_truep(t5)){
if(C_truep((C_word)C_i_car(t3))){
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[19])[1];
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep(t2)){
t4=t3;
f_1033(2,t4,t2);}
else{
/* partition.scm: 224  error */
t4=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[143]);}}

/* k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
/* partition.scm: 225  hash-table-ref */
t3=C_retrieve(lf[135]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[19])[1]);}

/* k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_590,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=t2,tmp=(C_word)a,a+=21,tmp);
if(C_truep(t2)){
t4=t3;
f_590(2,t4,t2);}
else{
/* partition.scm: 99   error */
t4=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[142]);}}

/* k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
/* partition.scm: 100  dlist$-remove! */
f_601(t2,((C_word*)t0)[2],((C_word*)t0)[20]);}

/* k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_593,2,t0,t1);}
t2=f_473(((C_word*)t0)[19]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[18])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[17])+1,t3);
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* partition.scm: 504  ##compiler#debugging */
t6=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[126],lf[141]);}

/* k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[17])[1]);
/* partition.scm: 505  ##compiler#debugging */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[126],lf[140],t3);}

/* k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[17])[1]);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[16])[1],t2);
t4=C_mutate(((C_word *)((C_word*)t0)[16])+1,t3);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[17])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[17])+1,t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2123,a[2]=t7,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 509  partition */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)((C_word*)t0)[17])[1]);}

/* k2121 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 510  add1 */
t3=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 513  add1 */
t3=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}}

/* k2133 in k2121 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 514  sub1 */
t4=*((C_word*)lf[138]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k2137 in k2133 in k2121 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1996(t3,t2);}

/* k2125 in k2121 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 511  sub1 */
t4=*((C_word*)lf[138]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k2129 in k2125 in k2121 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1996(t3,t2);}

/* k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1996,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[16],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 516  partition */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[16])[1]);}

/* k2118 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_not(t1);
/* partition.scm: 515  partition-move! */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 518  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[14])[1]);}

/* k2110 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1087(t1);
/* partition.scm: 517  ##compiler#debugging */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[126],lf[137],t2);}

/* k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[136],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 535  neighbours */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[14])[1]);}

/* k2102 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* partition.scm: 523  color */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
if(C_truep(t1)){
t2=f_923(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2090,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=t1;
t5=f_811(((C_word*)t0)[2]);
t6=f_877(t4);
t7=f_895(t4);
t8=f_473(t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_997,a[2]=t6,a[3]=t5,a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t10=f_829(((C_word*)t0)[2]);
t11=t10;
((C_proc3)C_retrieve_proc(t11))(3,t11,t9,t8);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k995 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* partition.scm: 206  hash-table-ref */
t3=C_retrieve(lf[135]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k998 in k995 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=f_895(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1006,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=f_491(t2);
t5=(C_word)C_eqp(lf[18],t4);
if(C_truep(t5)){
/* partition.scm: 209  error */
t6=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,lf[134]);}
else{
t6=t3;
f_1006(2,t6,C_SCHEME_FALSE);}}

/* k1004 in k998 in k995 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 210  dlist$-remove! */
f_601(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1007 in k1004 in k998 in k995 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 211  bucket$-add! */
f_949(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2088 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_923(t1);
/* partition.scm: 530  ##compiler#debugging */
t4=C_retrieve(lf[116]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[126],lf[131],((C_word*)t0)[2],lf[132],t3);}

/* k2091 in k2088 in k2079 in a2076 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 534  color-set! */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* partition.scm: 541  color-set! */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_FALSE);}

/* k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* partition.scm: 544  ##compiler#debugging */
t4=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[126],lf[130]);}

/* k2057 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* partition.scm: 545  cost */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[8];
f_2011(2,t2,C_SCHEME_UNDEFINED);}}

/* k2060 in k2057 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* partition.scm: 546  ##compiler#debugging */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[126],lf[129],t1);}

/* k2063 in k2060 in k2057 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* partition.scm: 547  ##compiler#debugging */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[126],lf[128],((C_word*)((C_word*)t0)[2])[1]);}

/* k2066 in k2063 in k2060 in k2057 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 548  balance */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2073 in k2066 in k2063 in k2060 in k2057 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 548  ##compiler#debugging */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[126],lf[127],t1);}

/* k2009 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(C_word)C_i_memq(lf[124],C_retrieve(lf[125]));
t3=(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* partition.scm: 556  balance */
t5=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2031 in k2009 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=((C_word*)((C_word*)t0)[5])[1];
t4=(C_word)C_a_i_record(&a,4,lf[109],t2,t1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
/* partition.scm: 559  loop2 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1968(t7,t5,t6);}

/* k2023 in k2031 in k2009 in k2006 in k2003 in k2000 in k1997 in k1994 in k1983 in k1980 in k591 in k588 in k1042 in k1031 in k1028 in loop2 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=lf[123],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)((C_word*)t0)[12])[1]);}

/* a1923 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1924,3,t0,t1,t2);}
t3=f_1645(t2);
if(C_truep((C_word)C_i_lessp(t3,((C_word*)t0)[4]))){
t4=(C_word)C_i_not(((C_word*)((C_word*)t0)[3])[1]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1940,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1940(t6,t4);}
else{
t6=f_1645(t2);
t7=f_1645(((C_word*)((C_word*)t0)[3])[1]);
t8=t5;
f_1940(t8,(C_word)C_i_lessp(t6,t7));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1938 in a1923 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_check_structure(t2,lf[109]);
t4=(C_word)C_i_block_ref(t2,C_fix(2));
if(C_truep((C_word)C_i_less_or_equalp(t4,((C_word*)t0)[4]))){
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[5]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=lf[122],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1889(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* reset in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1889,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* partition.scm: 585  partition-move! */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k1897 in reset in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* partition.scm: 586  reset */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1889(t4,((C_word*)t0)[2],t2,t3);}

/* k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 587  ##compiler#debugging */
t4=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[117],lf[121]);}

/* k1860 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=f_1645(((C_word*)((C_word*)t0)[3])[1]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1880,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=f_1681(((C_word*)((C_word*)t0)[3])[1]);
/* partition.scm: 592  graph-cell$$-info */
t5=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* partition.scm: 594  ##compiler#debugging */
t2=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[117],lf[120]);}}
else{
t2=((C_word*)t0)[2];
f_1759(2,t2,C_SCHEME_UNDEFINED);}}

/* k1878 in k1860 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1087(t1);
/* partition.scm: 590  ##compiler#debugging */
t3=C_retrieve(lf[116]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[3],lf[117],lf[118],((C_word*)t0)[2],lf[119],t2);}

/* k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=lf[115],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1810(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_1762(2,t3,C_SCHEME_FALSE);}}

/* apply-moves in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1810,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=f_1681(t3);
t5=(C_word)C_i_car(t2);
t6=f_1645(t5);
t7=(C_word)C_i_nullp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 606  partition */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}}

/* k1849 in apply-moves in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_not(t1);
/* partition.scm: 604  partition-move! */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1824 in apply-moves in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* partition.scm: 608  apply-moves */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1810(t5,((C_word*)t0)[3],t4);}}

/* k1760 in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 611  cost */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k1769 in k1760 in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=(C_word)C_i_zerop(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1796,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_quotient(4,0,t4,((C_word*)t0)[2],t1);}
else{
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[2],t1))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* partition.scm: 620  loop1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1724(t4,((C_word*)t0)[4],t1);}}}}

/* k1794 in k1769 in k1760 in k1757 in k1754 in k1751 in k1748 in k1744 in k1736 in k1732 in k919 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_greater_or_equalp(t1,C_fix(2)))){
/* partition.scm: 617  loop1 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1724(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2205 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2214,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 475  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2212 in a2205 in k1726 in loop1 in k1720 in k1713 in k1710 in k1707 in k1701 in ##compiler#partition-fm in k456 in k453 in k450 */
static void f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 475  graph-cell-info$$-id */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1087(t1));}

/* partition-fmv-cell in k456 in k453 in k450 */
static C_word C_fcall f_1681(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[109]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* partition-fmv-cost in k456 in k453 in k450 */
static C_word C_fcall f_1645(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[109]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* graph*balance in k456 in k453 in k450 */
static void f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[25],*a=ab;
if(c!=7) C_bad_argc(c,7);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1539,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=t2;
t10=(C_word)C_i_structurep(t9,lf[52]);
t11=(C_truep(t10)?lf[76]:*((C_word*)lf[104]+1));
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1546,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=(C_truep(t5)?t6:C_SCHEME_FALSE);
if(C_truep(t13)){
t14=(C_word)C_i_car(t4);
t15=(C_word)C_a_i_times(&a,2,t14,t6);
t16=(C_word)C_i_cdr(t4);
t17=(C_word)C_a_i_times(&a,2,t16,t5);
t18=(C_word)C_a_i_minus(&a,2,t15,t17);
t19=C_set_block_item(t8,0,t18);
t20=t12;
f_1546(2,t20,t19);}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=t4,a[3]=t8,a[4]=lf[106],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 353  for-each */
t15=t11;
((C_proc4)C_retrieve_proc(t15))(4,t15,t12,t14,t2);}}

/* a1600 in graph*balance in k456 in k453 in k450 */
static void f_1601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1601,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 357  graph-cell$$-info */
t5=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1625 in a1600 in graph*balance in k456 in k453 in k450 */
static void f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_1123(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1610(2,t3,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* partition.scm: 359  - */
C_minus(3,0,((C_word*)t0)[3],t3);}}

/* k1608 in a1600 in graph*balance in k456 in k453 in k450 */
static void f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1544 in graph*balance in k456 in k453 in k450 */
static void f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(C_word)C_a_i_abs(&a,1,((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1561,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* partition.scm: 362  max */
t7=*((C_word*)lf[105]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* k1559 in k1544 in graph*balance in k456 in k453 in k450 */
static void f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1561,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,t1,((C_word*)t0)[4]);
C_quotient(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* graph*cost in k456 in k453 in k450 */
static void f_1491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1491,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t4,a[3]=lf[101],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 322  graph$-for-each */
t7=lf[76];
f_1365(4,t7,t5,t6,t2);}

/* a1499 in graph*cost in k456 in k453 in k450 */
static void f_1500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1537,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 324  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1535 in a1499 in graph*cost in k456 in k453 in k450 */
static void f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=f_1123(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1514,a[2]=t2,a[3]=lf[100],tmp=(C_word)a,a+=4,tmp);
t5=f_1189(((C_word*)t0)[2]);
/* partition.scm: 325  dlist$-count */
f_714(t3,t4,t5);}

/* a1513 in k1535 in a1499 in graph*cost in k456 in k453 in k450 */
static void f_1514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1529,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 328  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1527 in a1513 in k1535 in a1499 in graph*cost in k456 in k453 in k450 */
static void f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_1123(t1);
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}

/* k1510 in k1535 in a1499 in graph*cost in k456 in k453 in k450 */
static void f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1493 in graph*cost in k456 in k453 in k450 */
static void f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_quotient(4,0,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],C_fix(2));}

/* graph*gain in k456 in k453 in k450 */
static void f_1449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1449,3,t0,t1,t2);}
t3=f_1189(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_697,a[2]=t7,a[3]=lf[97],tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_697(t9,t4,t5,C_fix(0));}

/* loop in graph*gain in k456 in k453 in k450 */
static void C_fcall f_697(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_697,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=f_509(t2);
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* partition.scm: 136  loop */
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1454 in graph*gain in k456 in k453 in k450 */
static void f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 296  graph-cell$$-info */
t3=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1487 in k1454 in graph*gain in k456 in k453 in k450 */
static void f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=f_1123(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1470,a[2]=t2,a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 298  dlist$-count */
f_714(t3,t4,((C_word*)t0)[2]);}

/* a1469 in k1487 in k1454 in graph*gain in k456 in k453 in k450 */
static void f_1470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 301  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1483 in a1469 in k1487 in k1454 in graph*gain in k456 in k453 in k450 */
static void f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_1123(t1);
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}

/* k1460 in k1487 in k1454 in graph*gain in k456 in k453 in k450 */
static void f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_minus(&a,2,t1,t2));}

/* graph*neighbours in k456 in k453 in k450 */
static void f_1425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1425,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=lf[90],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1443,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=f_1189(t2);
t6=*((C_word*)lf[92]+1);
t7=(C_word)C_i_car(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_662,a[2]=t6,a[3]=t9,a[4]=lf[93],tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_662(t11,t4,t7);}

/* loop in graph*neighbours in k456 in k453 in k450 */
static void C_fcall f_662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_662,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_673,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=f_473(t2);
/* partition.scm: 130  func */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}

/* k671 in loop in graph*neighbours in k456 in k453 in k450 */
static void f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_677,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=f_509(((C_word*)t0)[3]);
/* partition.scm: 131  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_662(t4,t2,t3);}

/* k675 in k671 in loop in graph*neighbours in k456 in k453 in k450 */
static void f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_677,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1441 in graph*neighbours in k456 in k453 in k450 */
static void f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 287  filter */
t2=C_retrieve(lf[91]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1430 in graph*neighbours in k456 in k453 in k450 */
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1431,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 289  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1437 in a1430 in graph*neighbours in k456 in k453 in k450 */
static void f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=(C_word)C_i_check_structure(t1,lf[40]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t1,C_fix(4)));}

/* graph*partition-move! in k456 in k453 in k450 */
static void f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1415,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 285  graph-cell$$-info */
t5=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1421 in graph*partition-move! in k456 in k453 in k450 */
static void f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(C_word)C_i_check_structure(t1,lf[40]);
/* partition.scm: 234  ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t1,C_fix(3),t3);}

/* graph*partition in k456 in k453 in k450 */
static void f_1405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1405,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 283  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1411 in graph*partition in k456 in k453 in k450 */
static void f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 283  graph-cell-info$$-partition */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1123(t1));}

/* graph*color-set! in k456 in k453 in k450 */
static void f_1395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1395,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 281  graph-cell$$-info */
t5=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1401 in graph*color-set! in k456 in k453 in k450 */
static void f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(C_word)C_i_check_structure(t1,lf[40]);
/* partition.scm: 234  ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t1,C_fix(2),t3);}

/* graph*color in k456 in k453 in k450 */
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1385,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 279  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1391 in graph*color in k456 in k453 in k450 */
static void f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=(C_word)C_i_check_structure(t1,lf[40]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t1,C_fix(2)));}

/* graph*id in k456 in k453 in k450 */
static void f_1375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1375,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* partition.scm: 277  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1381 in graph*id in k456 in k453 in k450 */
static void f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 277  graph-cell-info$$-id */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1087(t1));}

/* graph$-for-each in k456 in k453 in k450 */
static void f_1365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1365,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1373,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 272  graph$->list */
t5=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1371 in graph$-for-each in k456 in k453 in k450 */
static void f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* graph$->list in k456 in k453 in k450 */
static void f_1351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1351,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_1219(t2);
/* partition.scm: 268  hash-table->alist */
t5=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1357 in graph$->list in k456 in k453 in k450 */
static void f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[73]+1),t1);}

/* graph$-length in k456 in k453 in k450 */
static void f_1345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1345,3,t0,t1,t2);}
/* partition.scm: 266  graph$$-num-cells */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1237(t2));}

/* graph$-get in k456 in k453 in k450 */
static void f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1335,4,t0,t1,t2,t3);}
t4=f_1219(t2);
/* partition.scm: 262  hash-table-ref/default */
t5=C_retrieve(lf[37]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t3,C_SCHEME_FALSE);}

/* graph$-add-cell! in k456 in k453 in k450 */
static void f_1306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1306,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1310,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=f_1237(t2);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),t5);
t7=t2;
t8=(C_word)C_i_check_structure(t7,lf[52]);
/* partition.scm: 236  ##sys#block-set! */
t9=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t7,C_fix(2),t6);}

/* k1308 in graph$-add-cell! in k456 in k453 in k450 */
static void f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=f_1219(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 258  graph-cell$$-info */
t4=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1323 in k1308 in graph$-add-cell! in k456 in k453 in k450 */
static void f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1087(t1);
/* partition.scm: 257  hash-table-set! */
t3=C_retrieve(lf[36]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* make-graph$ in k456 in k453 in k450 */
static void f_1296(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1296r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1296r(t0,t1,t2);}}

static void f_1296r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,C_retrieve(lf[63]),t2);}

/* k1302 in make-graph$ in k456 in k453 in k450 */
static void f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,3,lf[52],t1,C_fix(0)));}

/* graph-cell$-add-undirected-edge! in k456 in k453 in k450 */
static void f_1279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1279,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=f_1189(t2);
/* partition.scm: 247  dlist$-add-tail! */
f_562(t4,t5,t3);}

/* k1281 in graph-cell$-add-undirected-edge! in k456 in k453 in k450 */
static void f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1189(((C_word*)t0)[4]);
/* partition.scm: 248  dlist$-add-tail! */
f_562(((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* graph-cell$-add-edge! in k456 in k453 in k450 */
static void f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1269,4,t0,t1,t2,t3);}
t4=f_1189(t2);
/* partition.scm: 243  dlist$-add-tail! */
f_562(t1,t4,t3);}

/* make-graph-cell$ in k456 in k453 in k450 */
static void f_1255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1255,3,t0,t1,t2);}
t3=(C_word)C_a_i_record(&a,5,lf[40],t2,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE);
t4=f_527(C_a_i(&a,3));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,3,lf[47],t3,t4));}

/* graph$$-num-cells in k456 in k453 in k450 */
static C_word C_fcall f_1237(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[52]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* graph$$-cells in k456 in k453 in k450 */
static C_word C_fcall f_1219(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[52]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* graph-cell$$-vertices in k456 in k453 in k450 */
static C_word C_fcall f_1189(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[47]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* graph-cell$$-info in k456 in k453 in k450 */
static void f_1171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1171,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[47]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* graph-cell-info$$-inregion-set! in k456 in k453 in k450 */
static void f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1150,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[40]);
/* partition.scm: 234  ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* graph-cell-info$$-partition in k456 in k453 in k450 */
static C_word C_fcall f_1123(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[40]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* graph-cell-info$$-id in k456 in k453 in k450 */
static C_word C_fcall f_1087(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[40]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* bucket$-add! in k456 in k453 in k450 */
static void C_fcall f_949(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_949,NULL,3,t1,t2,t3);}
t4=f_811(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_956,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=f_829(t2);
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t3);}

/* k954 in bucket$-add! in k456 in k453 in k450 */
static void f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* partition.scm: 191  hash-table-ref/default */
t3=C_retrieve(lf[37]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k957 in k954 in bucket$-add! in k456 in k453 in k450 */
static void f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t3)[1];
if(C_truep(t5)){
t6=t4;
f_962(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=f_527(C_a_i(&a,3));
t7=C_set_block_item(t3,0,t6);
/* partition.scm: 195  hash-table-set! */
t8=C_retrieve(lf[36]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t4,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t3)[1]);}}

/* k960 in k957 in k954 in bucket$-add! in k456 in k453 in k450 */
static void f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 196  dlist$-add-tail! */
f_562(t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k967 in k960 in k957 in k954 in bucket$-add! in k456 in k453 in k450 */
static void f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[29],t3,t1));}

/* bucket$-gain in k456 in k453 in k450 */
static C_word C_fcall f_923(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_877(t1));}

/* bucket-item$-dlistitem in k456 in k453 in k450 */
static C_word C_fcall f_895(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[29]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* bucket-item$-gain in k456 in k453 in k450 */
static C_word C_fcall f_877(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[29]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* bucket$$-gainproc in k456 in k453 in k450 */
static C_word C_fcall f_829(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[24]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* bucket$$-db in k456 in k453 in k450 */
static C_word C_fcall f_811(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[24]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* dlist$-count in k456 in k453 in k450 */
static void C_fcall f_714(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_714,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_724,a[2]=t2,a[3]=t6,a[4]=lf[21],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_724(t8,t1,t4,C_fix(0));}

/* loop in dlist$-count in k456 in k453 in k450 */
static void C_fcall f_724(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_724,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=f_509(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_742,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=f_473(t2);
/* partition.scm: 143  pred */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k740 in loop in dlist$-count in k456 in k453 in k450 */
static void f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* partition.scm: 141  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_724(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* dlist$-remove! in k456 in k453 in k450 */
static void C_fcall f_601(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_601,NULL,3,t1,t2,t3);}
t4=f_491(t3);
t5=f_509(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_611,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_647,a[2]=t5,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 120  dlist-item$-left-set! */
f_500(t7,t5,t4);}
else{
t7=(C_word)C_i_set_cdr(t2,t4);
/* partition.scm: 117  dlist-item$-right-set! */
f_518(t6,t4,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_set_car(t2,t5);
if(C_truep(t5)){
/* partition.scm: 111  dlist-item$-left-set! */
f_500(t6,t5,C_SCHEME_FALSE);}
else{
t8=t6;
f_611(2,t8,(C_word)C_i_set_cdr(t2,C_SCHEME_FALSE));}}}

/* k645 in dlist$-remove! in k456 in k453 in k450 */
static void f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 121  dlist-item$-right-set! */
f_518(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k609 in dlist$-remove! in k456 in k453 in k450 */
static void f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* partition.scm: 123  dlist-item$-left-set! */
f_500(t2,((C_word*)t0)[2],lf[18]);}

/* k612 in k609 in dlist$-remove! in k456 in k453 in k450 */
static void f_614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* partition.scm: 124  dlist-item$-right-set! */
f_518(((C_word*)t0)[3],((C_word*)t0)[2],lf[18]);}

/* dlist$-add-tail! in k456 in k453 in k450 */
static void C_fcall f_562(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_562,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_record(&a,4,lf[2],t3,t4,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_572,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_575,a[2]=t5,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* partition.scm: 90   dlist-item$-right-set! */
f_518(t7,t4,t5);}
else{
t7=t2;
t8=(C_word)C_i_set_car(t7,t5);
t9=t6;
f_572(t9,(C_word)C_i_set_cdr(t7,t5));}}

/* k573 in dlist$-add-tail! in k456 in k453 in k450 */
static void f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_572(t2,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k570 in dlist$-add-tail! in k456 in k453 in k450 */
static void C_fcall f_572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* make-dlist$ in k456 in k453 in k450 */
static C_word C_fcall f_527(C_word *a){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_FALSE));}

/* dlist-item$-right-set! in k456 in k453 in k450 */
static void C_fcall f_518(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_518,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[2]);
/* partition.scm: 72   ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* dlist-item$-right in k456 in k453 in k450 */
static C_word C_fcall f_509(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[2]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* dlist-item$-left-set! in k456 in k453 in k450 */
static void C_fcall f_500(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_500,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[2]);
/* partition.scm: 72   ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* dlist-item$-left in k456 in k453 in k450 */
static C_word C_fcall f_491(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[2]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* dlist-item$-value in k456 in k453 in k450 */
static C_word C_fcall f_473(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[2]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}
/* end of file */
