/* Generated from match-support.scm by the Chicken compiler
   2005-08-24 19:41
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: match-support.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file umatch-support.c -explicit-use
   unit: match_support
*/

#include "chicken.h"


static C_TLS C_word lf[121];


C_externexport void C_match_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_7257(C_word c,C_word t0,C_word t1) C_noret;
static void f_7240(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7240r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7227(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_7186(C_word t0);
static void f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_909(C_word c,C_word t0,C_word t1) C_noret;
static void f_912(C_word c,C_word t0,C_word t1) C_noret;
static void f_1079(C_word c,C_word t0,C_word t1) C_noret;
static void f_915(C_word c,C_word t0,C_word t1) C_noret;
static void f_927(C_word c,C_word t0,C_word t1) C_noret;
static void f_933(C_word c,C_word t0,C_word t1) C_noret;
static void f_1071(C_word c,C_word t0,C_word t1) C_noret;
static void f_936(C_word c,C_word t0,C_word t1) C_noret;
static void f_1059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_939(C_word c,C_word t0,C_word t1) C_noret;
static void f_942(C_word c,C_word t0,C_word t1) C_noret;
static void f_1053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_953(C_word c,C_word t0,C_word t1) C_noret;
static void f_1023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1013(C_word c,C_word t0,C_word t1) C_noret;
static void f_1009(C_word c,C_word t0,C_word t1) C_noret;
static void f_1005(C_word c,C_word t0,C_word t1) C_noret;
static void f_1001(C_word c,C_word t0,C_word t1) C_noret;
static void f_993(C_word c,C_word t0,C_word t1) C_noret;
static void f_985(C_word c,C_word t0,C_word t1) C_noret;
static void f_977(C_word c,C_word t0,C_word t1) C_noret;
static void f_969(C_word c,C_word t0,C_word t1) C_noret;
static void f_961(C_word c,C_word t0,C_word t1) C_noret;
static void f_949(C_word c,C_word t0,C_word t1) C_noret;
static void f_749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_753(C_word c,C_word t0,C_word t1) C_noret;
static void f_756(C_word c,C_word t0,C_word t1) C_noret;
static void f_903(C_word c,C_word t0,C_word t1) C_noret;
static void f_759(C_word c,C_word t0,C_word t1) C_noret;
static void f_771(C_word c,C_word t0,C_word t1) C_noret;
static void f_777(C_word c,C_word t0,C_word t1) C_noret;
static void f_895(C_word c,C_word t0,C_word t1) C_noret;
static void f_780(C_word c,C_word t0,C_word t1) C_noret;
static void f_883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_783(C_word c,C_word t0,C_word t1) C_noret;
static void f_786(C_word c,C_word t0,C_word t1) C_noret;
static void f_853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_845(C_word c,C_word t0,C_word t1) C_noret;
static void f_841(C_word c,C_word t0,C_word t1) C_noret;
static void f_837(C_word c,C_word t0,C_word t1) C_noret;
static void f_833(C_word c,C_word t0,C_word t1) C_noret;
static void f_825(C_word c,C_word t0,C_word t1) C_noret;
static void f_817(C_word c,C_word t0,C_word t1) C_noret;
static void f_809(C_word c,C_word t0,C_word t1) C_noret;
static void f_801(C_word c,C_word t0,C_word t1) C_noret;
static void f_793(C_word c,C_word t0,C_word t1) C_noret;
static void f_537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_541(C_word c,C_word t0,C_word t1) C_noret;
static void f_544(C_word c,C_word t0,C_word t1) C_noret;
static void f_605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_743(C_word c,C_word t0,C_word t1) C_noret;
static void f_609(C_word c,C_word t0,C_word t1) C_noret;
static void f_621(C_word c,C_word t0,C_word t1) C_noret;
static void f_731(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_624(C_word t0,C_word t1) C_noret;
static void f_660(C_word c,C_word t0,C_word t1) C_noret;
static void f_656(C_word c,C_word t0,C_word t1) C_noret;
static void f_652(C_word c,C_word t0,C_word t1) C_noret;
static void f_641(C_word c,C_word t0,C_word t1) C_noret;
static void f_550(C_word c,C_word t0,C_word t1) C_noret;
static void f_603(C_word c,C_word t0,C_word t1) C_noret;
static void f_553(C_word c,C_word t0,C_word t1) C_noret;
static void f_556(C_word c,C_word t0,C_word t1) C_noret;
static void f_567(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1175(C_word t0,C_word t1) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1) C_noret;
static void f_1215(C_word c,C_word t0,C_word t1) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1253(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2328(C_word c,C_word t0,C_word t1) C_noret;
static void f_2332(C_word c,C_word t0,C_word t1) C_noret;
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2264(C_word c,C_word t0,C_word t1) C_noret;
static void f_2267(C_word c,C_word t0,C_word t1) C_noret;
static void f_2277(C_word c,C_word t0,C_word t1) C_noret;
static void f_2292(C_word c,C_word t0,C_word t1) C_noret;
static void f_2274(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2130(C_word t0,C_word t1) C_noret;
static void f_2202(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2169(C_word t0,C_word t1) C_noret;
static void f_2182(C_word c,C_word t0,C_word t1) C_noret;
static void f_2155(C_word c,C_word t0,C_word t1) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2093(C_word t0,C_word t1) C_noret;
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2056(C_word c,C_word t0,C_word t1) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1348(C_word c,C_word t0,C_word t1) C_noret;
static void f_1992(C_word c,C_word t0,C_word t1) C_noret;
static void f_1995(C_word c,C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void f_2020(C_word c,C_word t0,C_word t1) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1) C_noret;
static void f_1920(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1887(C_word t0,C_word t1) C_noret;
static void f_1900(C_word c,C_word t0,C_word t1) C_noret;
static void f_1832(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1812(C_word t0,C_word t1) C_noret;
static void f_1785(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1765(C_word t0,C_word t1) C_noret;
static void C_fcall f_1701(C_word t0,C_word t1) C_noret;
static void f_1718(C_word c,C_word t0,C_word t1) C_noret;
static void f_1714(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
static void f_1664(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
static void f_1617(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1560(C_word t0,C_word t1) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1500(C_word t0,C_word t1) C_noret;
static void f_1513(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1446(C_word t0,C_word t1) C_noret;
static void f_1463(C_word c,C_word t0,C_word t1) C_noret;
static void f_1459(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1409(C_word t0,C_word t1) C_noret;
static void C_fcall f_1366(C_word t0,C_word t1) C_noret;
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1326(C_word c,C_word t0,C_word t1) C_noret;
static void f_1330(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1286(C_word t0);
static void f_1081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1105(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3242(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3113(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3067(C_word t0,C_word t1) C_noret;
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3051(C_word t0,C_word t1) C_noret;
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2390(C_word t0,C_word t1) C_noret;
static void C_fcall f_2399(C_word t0,C_word t1) C_noret;
static void C_fcall f_2491(C_word t0,C_word t1) C_noret;
static void C_fcall f_2568(C_word t0,C_word t1) C_noret;
static void C_fcall f_2591(C_word t0,C_word t1) C_noret;
static void C_fcall f_2680(C_word t0,C_word t1) C_noret;
static void f_2745(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2793(C_word t0,C_word t1) C_noret;
static void C_fcall f_2824(C_word t0,C_word t1) C_noret;
static void C_fcall f_2854(C_word t0,C_word t1) C_noret;
static void f_2924(C_word c,C_word t0,C_word t1) C_noret;
static void f_2926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2934(C_word c,C_word t0,C_word t1) C_noret;
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2814(C_word c,C_word t0,C_word t1) C_noret;
static void f_2810(C_word c,C_word t0,C_word t1) C_noret;
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2758(C_word c,C_word t0,C_word t1) C_noret;
static void f_2773(C_word c,C_word t0,C_word t1) C_noret;
static void f_2777(C_word c,C_word t0,C_word t1) C_noret;
static void f_2783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2781(C_word c,C_word t0,C_word t1) C_noret;
static void f_2697(C_word c,C_word t0,C_word t1) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2731(C_word c,C_word t0,C_word t1) C_noret;
static void f_2714(C_word c,C_word t0,C_word t1) C_noret;
static void f_2600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2674(C_word c,C_word t0,C_word t1) C_noret;
static void f_2647(C_word c,C_word t0,C_word t1) C_noret;
static void f_2656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2622(C_word c,C_word t0,C_word t1) C_noret;
static void f_2618(C_word c,C_word t0,C_word t1) C_noret;
static void f_2577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2500(C_word t0,C_word t1) C_noret;
static void f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2503(C_word c,C_word t0,C_word t1) C_noret;
static void f_2416(C_word c,C_word t0,C_word t1) C_noret;
static void f_2412(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2437(C_word t0,C_word t1) C_noret;
static void f_2440(C_word c,C_word t0,C_word t1) C_noret;
static void f_2371(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3199(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3205(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3244(C_word t0,C_word t1) C_noret;
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3267(C_word c,C_word t0,C_word t1) C_noret;
static void f_3271(C_word c,C_word t0,C_word t1) C_noret;
static void f_3536(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3558(C_word t0,C_word t1) C_noret;
static void C_fcall f_3293(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3307(C_word c,C_word t0,C_word t1) C_noret;
static void f_3311(C_word c,C_word t0,C_word t1) C_noret;
static void f_3569(C_word c,C_word t0,C_word t1) C_noret;
static void f_3524(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3431(C_word t0,C_word t1);
static C_word C_fcall f_3409(C_word t0,C_word t1);
static C_word C_fcall f_3327(C_word t0);
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_3866(C_word t0,C_word t1) C_noret;
static void C_fcall f_3879(C_word t0,C_word t1) C_noret;
static void C_fcall f_3895(C_word t0,C_word t1) C_noret;
static void C_fcall f_3916(C_word t0,C_word t1) C_noret;
static void C_fcall f_3958(C_word t0,C_word t1) C_noret;
static void C_fcall f_4001(C_word t0,C_word t1) C_noret;
static void C_fcall f_4014(C_word t0,C_word t1) C_noret;
static void C_fcall f_4076(C_word t0,C_word t1) C_noret;
static void C_fcall f_4101(C_word t0,C_word t1) C_noret;
static void f_4126(C_word c,C_word t0,C_word t1) C_noret;
static void f_4465(C_word c,C_word t0,C_word t1) C_noret;
static void f_4755(C_word c,C_word t0,C_word t1) C_noret;
static void f_4758(C_word c,C_word t0,C_word t1) C_noret;
static void f_4703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4744(C_word c,C_word t0,C_word t1) C_noret;
static void f_4715(C_word c,C_word t0,C_word t1) C_noret;
static void f_4471(C_word c,C_word t0,C_word t1) C_noret;
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4498(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4531(C_word c,C_word t0,C_word t1) C_noret;
static void f_4619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4645(C_word c,C_word t0,C_word t1) C_noret;
static void f_4635(C_word c,C_word t0,C_word t1) C_noret;
static void f_4627(C_word c,C_word t0,C_word t1) C_noret;
static void f_4556(C_word c,C_word t0,C_word t1) C_noret;
static void f_4609(C_word c,C_word t0,C_word t1) C_noret;
static void f_4560(C_word c,C_word t0,C_word t1) C_noret;
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4587(C_word c,C_word t0,C_word t1) C_noret;
static void f_4567(C_word c,C_word t0,C_word t1) C_noret;
static void f_4579(C_word c,C_word t0,C_word t1) C_noret;
static void f_4505(C_word c,C_word t0,C_word t1) C_noret;
static void f_4502(C_word c,C_word t0,C_word t1) C_noret;
static void f_4433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4445(C_word c,C_word t0,C_word t1) C_noret;
static void f_4447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4459(C_word c,C_word t0,C_word t1) C_noret;
static void f_4135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4139(C_word c,C_word t0,C_word t1) C_noret;
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4249(C_word t0,C_word t1) C_noret;
static void f_4333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4359(C_word c,C_word t0,C_word t1) C_noret;
static void f_4349(C_word c,C_word t0,C_word t1) C_noret;
static void f_4341(C_word c,C_word t0,C_word t1) C_noret;
static void f_4268(C_word c,C_word t0,C_word t1) C_noret;
static void f_4319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4317(C_word c,C_word t0,C_word t1) C_noret;
static void f_4313(C_word c,C_word t0,C_word t1) C_noret;
static void f_4272(C_word c,C_word t0,C_word t1) C_noret;
static void f_4301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4299(C_word c,C_word t0,C_word t1) C_noret;
static void f_4279(C_word c,C_word t0,C_word t1) C_noret;
static void f_4291(C_word c,C_word t0,C_word t1) C_noret;
static void f_4242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4162(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4183(C_word t0,C_word t1) C_noret;
static void C_fcall f_4165(C_word t0,C_word t1) C_noret;
static void f_4176(C_word c,C_word t0,C_word t1) C_noret;
static void f_4180(C_word c,C_word t0,C_word t1) C_noret;
static void f_4120(C_word c,C_word t0,C_word t1) C_noret;
static void f_4095(C_word c,C_word t0,C_word t1) C_noret;
static void f_4070(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4062(C_word c,C_word t0,C_word t1) C_noret;
static void f_4033(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3726(C_word c,C_word t0,C_word t1) C_noret;
static void f_3719(C_word c,C_word t0,C_word t1) C_noret;
static void f_3715(C_word c,C_word t0,C_word t1) C_noret;
static void f_3676(C_word c,C_word t0,C_word t1) C_noret;
static void f_3711(C_word c,C_word t0,C_word t1) C_noret;
static void f_3648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1107(C_word t0,C_word t1) C_noret;
static void f_1123(C_word c,C_word t0,C_word t1) C_noret;
static void f_1165(C_word c,C_word t0,C_word t1) C_noret;
static void f_1161(C_word c,C_word t0,C_word t1) C_noret;
static void f_1150(C_word c,C_word t0,C_word t1) C_noret;
static void f_1157(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4908(C_word c,C_word t0,C_word t1) C_noret;
static void f_4917(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5039(C_word t0,C_word t1) C_noret;
static void C_fcall f_4926(C_word t0,C_word t1) C_noret;
static void C_fcall f_4932(C_word t0,C_word t1) C_noret;
static void f_4961(C_word c,C_word t0,C_word t1) C_noret;
static void f_4935(C_word c,C_word t0,C_word t1) C_noret;
static void f_4953(C_word c,C_word t0,C_word t1) C_noret;
static void f_4938(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5102(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5108(C_word t0,C_word t1) C_noret;
static void f_5907(C_word c,C_word t0,C_word t1) C_noret;
static void f_5811(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5166(C_word t0,C_word t1) C_noret;
static void f_5198(C_word c,C_word t0,C_word t1) C_noret;
static void f_5129(C_word c,C_word t0,C_word t1) C_noret;
static void f_5121(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5981(C_word c,C_word t0,C_word t1) C_noret;
static void f_5984(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5989(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6056(C_word t0,C_word t1) C_noret;
static void f_6059(C_word c,C_word t0,C_word t1) C_noret;
static void f_6020(C_word c,C_word t0,C_word t1) C_noret;
static void f_6029(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6118(C_word t0,C_word t1) C_noret;
static void f_6133(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6338(C_word t0,C_word t1) C_noret;
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6272(C_word t0,C_word t1) C_noret;
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6154(C_word t0,C_word t1) C_noret;
static void f_6185(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6166(C_word t0,C_word t1) C_noret;
static void C_fcall f_6418(C_word t0,C_word t1) C_noret;
static void C_fcall f_6458(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_6504(C_word t0);
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6518(C_word t0,C_word t1) C_noret;
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6551(C_word t0,C_word t1) C_noret;
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6836(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6775(C_word t0,C_word t1) C_noret;
static void f_6801(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7055(C_word t0,C_word t1) C_noret;
static void C_fcall f_7151(C_word t0,C_word t1) C_noret;
static void f_7165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7163(C_word c,C_word t0,C_word t1) C_noret;
static void f_7159(C_word c,C_word t0,C_word t1) C_noret;
static void f_528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

static void C_fcall trf_7209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7209(t0,t1,t2);}

static void C_fcall trf_624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_624(t0,t1);}

static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1175(t0,t1);}

static void C_fcall trf_1253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1253(t0,t1,t2);}

static void C_fcall trf_1283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1283(t0,t1,t2);}

static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2308(t0,t1,t2);}

static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2130(t0,t1);}

static void C_fcall trf_2169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2169(t0,t1);}

static void C_fcall trf_2093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2093(t0,t1);}

static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2048(t0,t1,t2,t3);}

static void C_fcall trf_1887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1887(t0,t1);}

static void C_fcall trf_1812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1812(t0,t1);}

static void C_fcall trf_1765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1765(t0,t1);}

static void C_fcall trf_1701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1701(t0,t1);}

static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

static void C_fcall trf_1560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1560(t0,t1);}

static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1500(t0,t1);}

static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1446(t0,t1);}

static void C_fcall trf_1409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1409(t0,t1);}

static void C_fcall trf_1366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1366(t0,t1);}

static void C_fcall trf_1318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1318(t0,t1,t2,t3);}

static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2348(t0,t1,t2);}

static void C_fcall trf_3142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3142(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3142(t0,t1,t2,t3,t4);}

static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3049(t0,t1,t2,t3,t4);}

static void C_fcall trf_3067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3067(t0,t1);}

static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3051(t0,t1);}

static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2352(t0,t1,t2,t3,t4);}

static void C_fcall trf_2390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2390(t0,t1);}

static void C_fcall trf_2399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2399(t0,t1);}

static void C_fcall trf_2491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2491(t0,t1);}

static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2568(t0,t1);}

static void C_fcall trf_2591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2591(t0,t1);}

static void C_fcall trf_2680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2680(t0,t1);}

static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2793(t0,t1);}

static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2824(t0,t1);}

static void C_fcall trf_2854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2854(t0,t1);}

static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2624(t0,t1,t2,t3);}

static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2500(t0,t1);}

static void C_fcall trf_2437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2437(t0,t1);}

static void C_fcall trf_3181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3181(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3181(t0,t1,t2,t3);}

static void C_fcall trf_3205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3205(t0,t1,t2);}

static void C_fcall trf_3244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3244(t0,t1);}

static void C_fcall trf_3504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3504(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3504(t0,t1,t2,t3,t4);}

static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3253(t0,t1,t2);}

static void C_fcall trf_3558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3558(t0,t1);}

static void C_fcall trf_3293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3293(t0,t1,t2);}

static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3628(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_3755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3755(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3755(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_3866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3866(t0,t1);}

static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3879(t0,t1);}

static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3895(t0,t1);}

static void C_fcall trf_3916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3916(t0,t1);}

static void C_fcall trf_3958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3958(t0,t1);}

static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4001(t0,t1);}

static void C_fcall trf_4014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4014(t0,t1);}

static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4076(t0,t1);}

static void C_fcall trf_4101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4101(t0,t1);}

static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4717(t0,t1,t2);}

static void C_fcall trf_4507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4507(t0,t1,t2);}

static void C_fcall trf_4249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4249(t0,t1);}

static void C_fcall trf_4183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4183(t0,t1);}

static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4165(t0,t1);}

static void C_fcall trf_4035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4035(t0,t1,t2);}

static void C_fcall trf_3967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3967(t0,t1,t2,t3);}

static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3925(t0,t1,t2,t3);}

static void C_fcall trf_1107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1107(t0,t1);}

static void C_fcall trf_4901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4901(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4901(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5039(t0,t1);}

static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4926(t0,t1);}

static void C_fcall trf_4932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4932(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4932(t0,t1);}

static void C_fcall trf_5083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5083(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5083(t0,t1,t2,t3,t4);}

static void C_fcall trf_5108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5108(t0,t1);}

static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5166(t0,t1);}

static void C_fcall trf_5977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5977(t0,t1,t2,t3);}

static void C_fcall trf_5989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5989(t0,t1,t2);}

static void C_fcall trf_6056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6056(t0,t1);}

static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6108(t0,t1,t2,t3);}

static void C_fcall trf_6118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6118(t0,t1);}

static void C_fcall trf_6325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6325(t0,t1,t2);}

static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6338(t0,t1);}

static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6259(t0,t1,t2);}

static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6272(t0,t1);}

static void C_fcall trf_6141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6141(t0,t1,t2);}

static void C_fcall trf_6154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6154(t0,t1);}

static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6166(t0,t1);}

static void C_fcall trf_6418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6418(t0,t1);}

static void C_fcall trf_6458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6458(t0,t1);}

static void C_fcall trf_6514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6514(t0,t1,t2);}

static void C_fcall trf_6518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6518(t0,t1);}

static void C_fcall trf_6547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6547(t0,t1,t2);}

static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6551(t0,t1);}

static void C_fcall trf_6581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6581(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6581(t0,t1,t2,t3);}

static void C_fcall trf_6775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6775(t0,t1);}

static void C_fcall trf_6583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6583(t0,t1,t2);}

static void C_fcall trf_6886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6886(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6886(t0,t1,t2,t3);}

static void C_fcall trf_7055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7055(t0,t1);}

static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7151(t0,t1);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_match_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_match_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("match_support_toplevel"));
C_check_nursery_minimum(124);
if(!C_demand(124)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2838)){
C_save(t1);
C_rereclaim2(2838*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(124);
C_initialize_lf(lf,121);
lf[0]=C_h_intern(&lf[0],13,"\005matchversion");
lf[1]=C_static_string(C_heaptop,42,"Version 1.18, July 17, 1995 (Chicken port)");
lf[2]=C_h_intern(&lf[2],16,"\005matchsyntax-err");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],13,"\000syntax-error");
lf[5]=C_h_intern(&lf[5],15,"\005matchset-error");
lf[6]=C_h_intern(&lf[6],15,"\003sysmatch-error");
lf[7]=C_h_intern(&lf[7],19,"\005matcherror-control");
lf[8]=C_h_intern(&lf[8],6,"\000error");
lf[9]=C_h_intern(&lf[9],23,"\005matchset-error-control");
lf[10]=C_h_intern(&lf[10],4,"null");
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"symbol\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"boolean\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"number\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"string\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"char\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"procedure\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"vector\077");
C_save(tmp);
lf[11]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[12]=C_h_intern(&lf[12],25,"\005matchdisjoint-predicates");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],13,"string-append");
lf[15]=C_h_intern(&lf[15],14,"symbol->string");
lf[16]=C_h_intern(&lf[16],7,"\003sysmap");
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[17]=C_h_list(28,C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(28);
lf[18]=C_h_intern(&lf[18],10,"vector-ref");
lf[19]=C_h_intern(&lf[19],1,"x");
lf[20]=C_h_intern(&lf[20],6,"lambda");
lf[21]=C_h_intern(&lf[21],3,"let");
lf[22]=C_h_intern(&lf[22],5,"unbox");
lf[23]=C_h_intern(&lf[23],3,"car");
lf[24]=C_h_intern(&lf[24],3,"cdr");
lf[25]=C_h_intern(&lf[25],13,"\003sysblock-ref");
lf[26]=C_static_string(C_heaptop,21,"unnested get! pattern");
lf[27]=C_h_intern(&lf[27],4,"set-");
lf[28]=C_h_intern(&lf[28],1,"!");
lf[29]=C_h_intern(&lf[29],1,"y");
lf[30]=C_h_intern(&lf[30],11,"vector-set!");
lf[31]=C_h_intern(&lf[31],8,"set-box!");
lf[32]=C_h_intern(&lf[32],8,"set-car!");
lf[33]=C_h_intern(&lf[33],8,"set-cdr!");
lf[34]=C_h_intern(&lf[34],14,"\003sysblock-set!");
lf[35]=C_static_string(C_heaptop,21,"unnested set! pattern");
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[36]=C_h_list(14,C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(14);
lf[37]=C_h_intern(&lf[37],6,"equal\077");
lf[38]=C_h_intern(&lf[38],7,"string\077");
lf[39]=C_h_intern(&lf[39],8,"boolean\077");
lf[40]=C_h_intern(&lf[40],5,"char\077");
lf[41]=C_h_intern(&lf[41],7,"number\077");
lf[42]=C_h_intern(&lf[42],7,"symbol\077");
lf[43]=C_h_intern(&lf[43],5,"quote");
lf[44]=C_h_intern(&lf[44],3,"not");
lf[45]=C_h_intern(&lf[45],5,"list\077");
tmp=C_intern(C_heaptop,5,"list\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"null\077");
C_save(tmp);
lf[46]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[47]=C_h_intern(&lf[47],5,"null\077");
lf[48]=C_h_intern(&lf[48],5,"pair\077");
lf[49]=C_h_intern(&lf[49],4,"cond");
lf[50]=C_h_intern(&lf[50],2,"if");
lf[51]=C_h_intern(&lf[51],3,"and");
lf[52]=C_h_intern(&lf[52],8,"\003syscons");
lf[53]=C_h_intern(&lf[53],30,"call-with-current-continuation");
lf[54]=C_h_intern(&lf[54],5,"caadr");
lf[55]=C_h_intern(&lf[55],12,"\000unspecified");
lf[56]=C_h_intern(&lf[56],5,"\000fail");
lf[57]=C_h_intern(&lf[57],6,"append");
lf[58]=C_h_intern(&lf[58],3,"...");
lf[59]=C_h_intern(&lf[59],3,"___");
lf[60]=C_h_intern(&lf[60],13,"\003syssubstring");
lf[61]=C_h_intern(&lf[61],6,"andmap");
lf[62]=C_h_intern(&lf[62],13,"char-numeric\077");
lf[63]=C_h_intern(&lf[63],12,"string->list");
lf[64]=C_h_intern(&lf[64],1,"_");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
lf[65]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[66]=C_h_intern(&lf[66],1,"\077");
lf[67]=C_h_intern(&lf[67],3,"map");
lf[68]=C_h_intern(&lf[68],4,"cons");
lf[69]=C_h_intern(&lf[69],7,"reverse");
lf[70]=C_h_intern(&lf[70],7,"vector\077");
lf[71]=C_h_intern(&lf[71],13,"vector-length");
lf[72]=C_h_intern(&lf[72],2,">=");
lf[73]=C_h_intern(&lf[73],1,">");
lf[74]=C_h_intern(&lf[74],1,"-");
lf[75]=C_h_intern(&lf[75],9,"\003syserror");
lf[76]=C_static_string(C_heaptop,18,"THIS NEVER HAPPENS");
lf[77]=C_h_intern(&lf[77],7,"newline");
lf[78]=C_h_intern(&lf[78],7,"display");
lf[79]=C_static_string(C_heaptop,30,"FATAL ERROR IN PATTERN MATCHER");
lf[80]=C_h_intern(&lf[80],4,"get!");
lf[81]=C_h_intern(&lf[81],4,"set!");
lf[82]=C_h_intern(&lf[82],1,"$");
lf[83]=C_h_intern(&lf[83],2,"or");
lf[84]=C_h_intern(&lf[84],1,"=");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"match-lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-lambda*");
C_save(tmp);
lf[85]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[86]=C_static_string(C_heaptop,29,"duplicate variable in pattern");
lf[87]=C_h_intern(&lf[87],6,"gensym");
lf[88]=C_static_string(C_heaptop,33,"variables of or-pattern differ in");
lf[89]=C_static_string(C_heaptop,23,"no variables allowed in");
lf[90]=C_h_intern(&lf[90],12,"list->vector");
lf[91]=C_h_intern(&lf[91],12,"vector->list");
tmp=C_intern(C_heaptop,10,"quasiquote");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"unquote-splicing");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"$");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"=");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"and");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"or");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"not");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"set!");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"get!");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"...");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"___");
C_save(tmp);
lf[92]=C_h_list(15,C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(15);
lf[93]=C_h_intern(&lf[93],10,"quasiquote");
lf[94]=C_h_intern(&lf[94],7,"unquote");
lf[95]=C_h_intern(&lf[95],16,"unquote-splicing");
lf[96]=C_h_intern(&lf[96],6,"vector");
lf[97]=C_static_string(C_heaptop,23,"syntax error in pattern");
lf[98]=C_static_string(C_heaptop,23,"syntax error in pattern");
lf[99]=C_static_string(C_heaptop,42,"invalid use of unquote-splicing in pattern");
lf[100]=C_h_intern(&lf[100],8,"\003syswarn");
lf[101]=C_static_string(C_heaptop,29,"Warning: unreachable pattern ");
lf[102]=C_h_intern(&lf[102],2,"in");
lf[103]=C_h_intern(&lf[103],12,"\003sysfor-each");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[104]=C_h_pair(C_restore,tmp);
lf[105]=C_h_intern(&lf[105],6,"\000match");
tmp=C_intern(C_heaptop,11,"unspecified");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"error");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"fail");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
lf[106]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[107]=C_static_string(C_heaptop,57,"invalid value for ##match#error-control, legal values are");
lf[108]=C_h_intern(&lf[108],1,"n");
lf[109]=C_h_intern(&lf[109],1,"l");
lf[110]=C_h_intern(&lf[110],6,"length");
lf[111]=C_h_intern(&lf[111],2,"=>");
lf[112]=C_h_intern(&lf[112],6,"letrec");
lf[113]=C_h_intern(&lf[113],10,"\003sysappend");
lf[114]=C_h_intern(&lf[114],5,"begin");
lf[115]=C_h_intern(&lf[115],8,"\003sysvoid");
lf[116]=C_h_intern(&lf[116],6,"define");
lf[117]=C_h_intern(&lf[117],15,"\005matchexpanders");
lf[118]=C_h_intern(&lf[118],19,"match-error-control");
lf[119]=C_h_intern(&lf[119],17,"register-feature!");
lf[120]=C_h_intern(&lf[120],13,"match-support");
C_register_lf(lf,121);
t2=C_mutate((C_word*)lf[0]+1,lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_517,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_523,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1,lf[8]);
t6=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_528,tmp=(C_word)a,a+=2,tmp));
t7=(C_word)C_a_i_cons(&a,2,lf[10],lf[11]);
t8=C_mutate((C_word*)lf[12]+1,t7);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7151,tmp=(C_word)a,a+=2,tmp);
t10=lf[17];
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6886,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6581,a[2]=t10,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t13=lf[36];
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6547,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6514,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6504,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6418,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6108,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5977,a[2]=t15,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5083,a[2]=t19,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=t18,a[3]=t21,tmp=(C_word)a,a+=4,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1107,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3628,a[2]=t15,a[3]=t14,a[4]=t24,a[5]=t21,a[6]=t11,a[7]=t12,a[8]=t9,a[9]=t23,a[10]=t26,tmp=(C_word)a,a+=11,tmp));
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3244,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1283,a[2]=t24,a[3]=t30,tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1253,tmp=(C_word)a,a+=2,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1175,tmp=(C_word)a,a+=2,tmp);
t34=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_537,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,a[7]=t28,tmp=(C_word)a,a+=8,tmp);
t35=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_749,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t36=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_905,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,a[7]=t28,tmp=(C_word)a,a+=8,tmp);
t37=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7186,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7209,a[2]=t39,tmp=(C_word)a,a+=3,tmp));
t41=(C_word)C_a_i_list(&a,4,t34,t35,t36,t30);
t42=C_mutate((C_word*)lf[117]+1,t41);
t43=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7240,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t45=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t45+1)))(3,t45,t44,lf[120]);}

/* k7255 */
static void f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* match-error-control */
static void f_7240(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7240r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7240r(t0,t1,t2);}}

static void f_7240r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[7]+1));}}

/* rdc */
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7209,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7227,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* k7225 in rdc */
static void f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rac */
static C_word C_fcall f_7186(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
return((C_word)C_u_i_car(t1));}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* gendefine */
static void f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_905,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t6=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k907 in gendefine */
static void f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[7]);}

/* k910 in k907 in gendefine */
static void f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
f_1283(t4,t3,((C_word*)t0)[2]);}

/* k1077 in k910 in k907 in gendefine */
static void f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k913 in k910 in k907 in gendefine */
static void f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t1);
t4=(C_word)C_u_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t6=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k925 in k913 in k910 in k907 in gendefine */
static void f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1069 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1059,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1058 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1059,3,t0,t1,t2);}
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_949,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1053,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1052 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1053,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[116],t2,C_SCHEME_FALSE));}

/* k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[86],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_969,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,lf[108]);
t5=(C_word)C_a_i_list(&a,1,lf[109]);
t6=(C_word)C_a_i_list(&a,2,lf[110],lf[109]);
t7=(C_word)C_a_i_list(&a,3,lf[72],t6,lf[108]);
t8=(C_word)C_a_i_list(&a,3,lf[20],t5,t7);
t9=(C_word)C_a_i_list(&a,3,lf[20],t4,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t9);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_977,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t13,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[3],a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1023,tmp=(C_word)a,a+=2,tmp);
t19=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t17,t18,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a1022 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1023,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[81],t2,t3));}

/* k1011 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[115]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1007 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1003 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k999 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_993,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k991 in k999 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k983 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k975 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k967 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[21],t1,((C_word*)t0)[4]);
f_3244(((C_word*)t0)[2],t2);}

/* k959 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k947 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[114],t1);}

/* genletrec */
static void f_749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_749,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k751 in genletrec */
static void f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[7]);}

/* k754 in k751 in genletrec */
static void f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_903,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
f_1283(t4,t3,((C_word*)t0)[2]);}

/* k901 in k754 in k751 in genletrec */
static void f_903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k757 in k754 in k751 in genletrec */
static void f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t1);
t4=(C_word)C_u_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t6=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k769 in k757 in k754 in k751 in genletrec */
static void f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_771,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k893 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_883,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a882 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_883,3,t0,t1,t2);}
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_793,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[108]);
t4=(C_word)C_a_i_list(&a,1,lf[109]);
t5=(C_word)C_a_i_list(&a,2,lf[110],lf[109]);
t6=(C_word)C_a_i_list(&a,3,lf[72],t5,lf[108]);
t7=(C_word)C_a_i_list(&a,3,lf[20],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[20],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_801,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t10,tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_853,tmp=(C_word)a,a+=2,tmp);
t13=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,((C_word*)t0)[2]);}

/* a852 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_853,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE));}

/* k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_809,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_837,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_847,tmp=(C_word)a,a+=2,tmp);
t10=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t8,t9,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a846 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_847,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[81],t2,t3));}

/* k843 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k839 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k835 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k831 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_833,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_825,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k823 in k831 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k815 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k807 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k799 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k791 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[112],t1,((C_word*)t0)[2]));}

/* genmatch */
static void f_537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_537,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_541,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t6=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k539 in genmatch */
static void f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[8]);}

/* k542 in k539 in genmatch */
static void f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a604 in k542 in k539 in genmatch */
static void f_605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_609,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(t2);
t6=((C_word*)t0)[2];
f_1283(t6,t4,t5);}

/* k741 in a604 in k542 in k539 in genmatch */
static void f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k607 in a604 in k542 in k539 in genmatch */
static void f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_609,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t1);
t4=(C_word)C_u_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_621,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t6=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_731,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=t2;
f_624(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_624(t4,C_SCHEME_FALSE);}}

/* k729 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,lf[111]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_u_i_cdadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cddadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_i_pairp(t6);
t8=((C_word*)t0)[2];
f_624(t8,(C_truep(t7)?(C_word)C_u_i_cadadr(((C_word*)t0)[3]):C_SCHEME_FALSE));}
else{
t6=((C_word*)t0)[2];
f_624(t6,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[2];
f_624(t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
f_624(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
f_624(t3,C_SCHEME_FALSE);}}

/* k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void C_fcall f_624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_624,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]):((C_word*)t0)[8]);
t3=(C_truep(t1)?(C_word)C_u_i_cddr(((C_word*)t0)[7]):(C_word)C_slot(((C_word*)t0)[7],C_fix(1)));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_656,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_660,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k658 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);}

/* k650 in k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_652,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t4;
f_641(2,t5,C_SCHEME_FALSE);}}

/* k639 in k650 in k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_641,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k548 in k542 in k539 in genmatch */
static void f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_553,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_603,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k601 in k548 in k542 in k539 in genmatch */
static void f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k551 in k548 in k542 in k539 in genmatch */
static void f_553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k554 in k551 in k548 in k542 in k539 in genmatch */
static void f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[108]);
t4=(C_word)C_a_i_list(&a,1,lf[109]);
t5=(C_word)C_a_i_list(&a,2,lf[110],lf[109]);
t6=(C_word)C_a_i_list(&a,3,lf[72],t5,lf[108]);
t7=(C_word)C_a_i_list(&a,3,lf[20],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[20],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t8);
t10=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t2,t9,((C_word*)((C_word*)t0)[2])[1]);}

/* k565 in k554 in k551 in k548 in k542 in k539 in genmatch */
static void f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[21],t1,((C_word*)t0)[4]);
f_3244(((C_word*)t0)[2],t2);}

/* error-maker */
static void C_fcall f_1175(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,2,t1,t2);}
t3=(C_word)C_eqp(*((C_word*)lf[7]+1),lf[55]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1187,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4));}
else{
t4=*((C_word*)lf[7]+1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[8]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[56]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1199,tmp=(C_word)a,a+=2,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5));}
else{
t5=(C_word)C_eqp(*((C_word*)lf[7]+1),lf[105]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[106],lf[107]);}}}}

/* k1210 in error-maker */
static void f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1213 in k1210 in error-maker */
static void f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[43],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,3,lf[6],t1,t3);
t5=(C_word)C_a_i_list(&a,3,lf[20],t2,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t7,t8));}

/* a1223 in k1213 in k1210 in error-maker */
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t2));}

/* a1198 in error-maker */
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1199,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[6],t2));}

/* a1186 in error-maker */
static void f_1187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1187,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[104]);}

/* unreachable */
static void C_fcall f_1253(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1253,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1258 in unreachable */
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1259,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
if(C_truep((C_word)C_u_i_car(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_u_i_car(t2);
t5=*((C_word*)lf[100]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[101],t4,lf[102],((C_word*)t0)[2]);}}

/* validate-pattern */
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1283,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1286,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1316,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t3,a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2046,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2308,a[2]=t2,a[3]=t5,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t5)[1];
f_1316(3,t13,t1,t2);}

/* ordlist in validate-pattern */
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t3,t4);}
else{
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],lf[99]);}}}

/* k2326 in ordlist in validate-pattern */
static void f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_2308(t4,t2,t3);}

/* k2330 in k2326 in ordlist in validate-pattern */
static void f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* quasi in validate-pattern */
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=f_1286(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[43],t5));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[94]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
t10=t7;
f_2093(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_2093(t9,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_caar(t2);
t10=(C_word)C_eqp(t9,lf[95]);
if(C_truep(t10)){
t11=(C_word)C_u_i_cdar(t2);
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_u_i_cddar(t2);
t13=t7;
f_2130(t13,(C_word)C_i_nullp(t12));}
else{
t12=t7;
f_2130(t12,C_SCHEME_FALSE);}}
else{
t11=t7;
f_2130(t11,C_SCHEME_FALSE);}}
else{
t9=t7;
f_2130(t9,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t5=t2;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t5=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],lf[98]);}}}}}

/* k2262 in quasi in validate-pattern */
static void f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2265 in k2262 in quasi in validate-pattern */
static void f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t1);
f_1107(t3,t4);}

/* k2275 in k2265 in k2262 in quasi in validate-pattern */
static void f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2290 in k2275 in k2265 in k2262 in quasi in validate-pattern */
static void f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2272 in k2265 in k2262 in quasi in validate-pattern */
static void f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[96]+1),t1);}

/* k2128 in quasi in validate-pattern */
static void C_fcall f_2130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2130,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=((C_word*)((C_word*)t0)[7])[1];
f_1316(3,t4,((C_word*)t0)[6],t3);}
else{
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2155,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)((C_word*)t0)[4])[1];
f_2308(t6,t5,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2202,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
f_1107(t4,t5);}
else{
t4=t2;
f_2169(t4,C_SCHEME_FALSE);}}}

/* k2200 in k2128 in quasi in validate-pattern */
static void f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2169(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2169(t2,C_SCHEME_FALSE);}}

/* k2167 in k2128 in quasi in validate-pattern */
static void C_fcall f_2169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2169,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2182,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t5,t4,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_2048(t4,((C_word*)t0)[4],t2,t3);}}

/* k2180 in k2167 in k2128 in quasi in validate-pattern */
static void f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2153 in k2128 in quasi in validate-pattern */
static void f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t3,t2,((C_word*)t0)[2]);}

/* k2157 in k2153 in k2128 in quasi in validate-pattern */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2091 in quasi in validate-pattern */
static void C_fcall f_2093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1316(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_2048(t4,((C_word*)t0)[3],t2,t3);}}

/* g109 in quasi in validate-pattern */
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_2046(3,t5,t4,t2);}

/* k2054 in g109 in quasi in validate-pattern */
static void f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2060,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t3,t2,((C_word*)t0)[2]);}

/* k2058 in k2054 in g109 in quasi in validate-pattern */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ordinary in validate-pattern */
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1316,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=f_1286(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t2,lf[64]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[64]);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=((C_word*)t0)[4];
f_1081(3,t7,t6,t2);}}}

/* k1346 in ordinary in validate-pattern */
static void f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[80],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[9]);
t3=(C_word)C_eqp(t2,lf[93]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t7=t4;
f_1366(t7,(C_word)C_i_nullp(t6));}
else{
t6=t4;
f_1366(t6,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_u_i_car(((C_word*)t0)[9]);
t5=(C_word)C_eqp(t4,lf[43]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t9=t6;
f_1409(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_1409(t8,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_u_i_car(((C_word*)t0)[9]);
t7=(C_word)C_eqp(t6,lf[66]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t11=t8;
f_1446(t11,(C_word)C_i_listp(t10));}
else{
t10=t8;
f_1446(t10,C_SCHEME_FALSE);}}
else{
t8=(C_word)C_u_i_car(((C_word*)t0)[9]);
t9=(C_word)C_eqp(t8,lf[84]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
t14=t10;
f_1500(t14,(C_word)C_i_nullp(t13));}
else{
t13=t10;
f_1500(t13,C_SCHEME_FALSE);}}
else{
t12=t10;
f_1500(t12,C_SCHEME_FALSE);}}
else{
t10=(C_word)C_u_i_car(((C_word*)t0)[9]);
t11=(C_word)C_eqp(t10,lf[51]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_listp(t13))){
t14=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t15=t12;
f_1560(t15,(C_word)C_i_pairp(t14));}
else{
t14=t12;
f_1560(t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_u_i_car(((C_word*)t0)[9]);
t13=(C_word)C_eqp(t12,lf[83]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_listp(t15))){
t16=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t17=t14;
f_1607(t17,(C_word)C_i_pairp(t16));}
else{
t16=t14;
f_1607(t16,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_u_i_car(((C_word*)t0)[9]);
t15=(C_word)C_eqp(t14,lf[44]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_listp(t17))){
t18=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t19=t16;
f_1654(t19,(C_word)C_i_pairp(t18));}
else{
t18=t16;
f_1654(t18,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_u_i_car(((C_word*)t0)[9]);
t17=(C_word)C_eqp(t16,lf[82]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_symbolp(t20))){
t21=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t22=t18;
f_1701(t22,(C_word)C_i_listp(t21));}
else{
t21=t18;
f_1701(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_1701(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_u_i_car(((C_word*)t0)[9]);
t19=(C_word)C_eqp(t18,lf[81]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t21=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t21))){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1785,a[2]=t20,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t24=((C_word*)t0)[4];
f_1081(3,t24,t22,t23);}
else{
t22=t20;
f_1765(t22,C_SCHEME_FALSE);}}
else{
t20=(C_word)C_u_i_car(((C_word*)t0)[9]);
t21=(C_word)C_eqp(t20,lf[80]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t23=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t23))){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1832,a[2]=t22,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t26=((C_word*)t0)[4];
f_1081(3,t26,t24,t25);}
else{
t24=t22;
f_1812(t24,C_SCHEME_FALSE);}}
else{
t22=(C_word)C_u_i_car(((C_word*)t0)[9]);
t23=(C_word)C_eqp(t22,lf[94]);
if(C_truep(t23)){
t24=(C_word)C_u_i_car(((C_word*)t0)[9]);
t25=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t26=((C_word*)t0)[6];
f_1318(t26,((C_word*)t0)[8],t24,t25);}
else{
t24=(C_word)C_u_i_car(((C_word*)t0)[9]);
t25=(C_word)C_eqp(t24,lf[95]);
if(C_truep(t25)){
t26=(C_word)C_u_i_car(((C_word*)t0)[9]);
t27=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t28=((C_word*)t0)[6];
f_1318(t28,((C_word*)t0)[8],t26,t27);}
else{
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t27=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t27))){
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=t26,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
f_1107(t28,t29);}
else{
t28=t26;
f_1887(t28,C_SCHEME_FALSE);}}}}}}}}}}}}}}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],((C_word*)t0)[2],lf[97]);}}}}

/* k1990 in k1346 in ordinary in validate-pattern */
static void f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t4=t3;
f_2005(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_u_i_car(t1);
f_1107(t3,t4);}}

/* k2003 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[3])[1],t4);}
else{
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2018 in k2003 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2000 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[96]+1),t1);}

/* k1918 in k1346 in ordinary in validate-pattern */
static void f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1887(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1887(t2,C_SCHEME_FALSE);}}

/* k1885 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1887,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t4,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1898 in k1885 in k1346 in ordinary in validate-pattern */
static void f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k1830 in k1346 in ordinary in validate-pattern */
static void f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1812(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1812(t2,C_SCHEME_FALSE);}}

/* k1810 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1783 in k1346 in ordinary in validate-pattern */
static void f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1765(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1765(t2,C_SCHEME_FALSE);}}

/* k1763 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1699 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1701,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1716 in k1699 in k1346 in ordinary in validate-pattern */
static void f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1712 in k1699 in k1346 in ordinary in validate-pattern */
static void f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k1652 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1662 in k1652 in k1346 in ordinary in validate-pattern */
static void f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[44],t1);}

/* k1605 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1615 in k1605 in k1346 in ordinary in validate-pattern */
static void f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k1558 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1568 in k1558 in k1346 in ordinary in validate-pattern */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k1498 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t4,t3);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1511 in k1498 in k1346 in ordinary in validate-pattern */
static void f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[84],((C_word*)t0)[2],t1));}

/* k1444 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1461 in k1444 in k1346 in ordinary in validate-pattern */
static void f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1457 in k1444 in k1346 in ordinary in validate-pattern */
static void f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k1407 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1364 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_2046(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* g88 in ordinary in validate-pattern */
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1318,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1326,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_1316(3,t5,t4,t2);}

/* k1324 in g88 in ordinary in validate-pattern */
static void f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1330,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t3,t2,((C_word*)t0)[2]);}

/* k1328 in k1324 in g88 in ordinary in validate-pattern */
static void f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* simple? in validate-pattern */
static C_word C_fcall f_1286(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t2=(C_word)C_i_stringp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_charp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_numberp(t1);
return((C_truep(t5)?t5:(C_word)C_i_nullp(t1)));}}}}

/* pattern-var? */
static void f_1081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1081,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1105,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_1107(t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1103 in pattern-var? */
static void f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_memq(((C_word*)t0)[2],lf[92]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}}

/* bound */
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2348,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3205,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t7,a[5]=t5,a[6]=t14,a[7]=t10,a[8]=t4,a[9]=t2,tmp=(C_word)a,a+=10,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3142,a[2]=t10,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t19=((C_word*)t10)[1];
f_2352(t19,t1,t2,C_SCHEME_END_OF_LIST,t18);}

/* a3233 in bound */
static void f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3234,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3240 in a3233 in bound */
static void f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]));}

/* bound* in bound */
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3142,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t4;
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
f_2352(t7,t1,t5,t3,t6);}}

/* a3160 in bound* in bound */
static void f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3161,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
f_3142(t6,t1,t4,t3,t5);}

/* a3170 in a3160 in bound* in bound */
static void f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3171,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* boundv in bound */
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3051,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_cadr(t2);
f_1107(t8,t9);}
else{
t8=t6;
f_3067(t8,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_3051(t6,t1);}
else{
t6=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}}}

/* k3111 in boundv in bound */
static void f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3067(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_3067(t2,C_SCHEME_FALSE);}}

/* k3065 in boundv in bound */
static void C_fcall f_3067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[8])[1];
f_2352(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=((C_word*)t0)[3];
f_3051(t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3090,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[8])[1];
f_2352(t5,((C_word*)t0)[7],t2,((C_word*)t0)[5],t4);}}}

/* a3089 in k3065 in boundv in bound */
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3090,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3049(t5,t1,((C_word*)t0)[2],t3,t4);}

/* a3095 in a3089 in k3065 in boundv in bound */
static void f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3096,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* g115 in boundv in bound */
static void C_fcall f_3051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* bound in bound */
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[64],t2);
if(C_truep(t5)){
t6=t4;
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2371,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_memq(t2,t3))){
t7=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[9],lf[86]);}
else{
t7=t6;
f_2371(2,t7,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=t2,a[12]=t1,a[13]=t4,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_2390(t8,(C_word)C_eqp(lf[43],t7));}
else{
t7=t6;
f_2390(t7,C_SCHEME_FALSE);}}}}

/* k2388 in bound in bound */
static void C_fcall f_2390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2390,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[11]);
t4=t2;
f_2399(t4,(C_word)C_eqp(lf[66],t3));}
else{
t3=t2;
f_2399(t3,C_SCHEME_FALSE);}}}

/* k2397 in k2388 in bound in bound */
static void C_fcall f_2399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_i_symbolp(t3);
t5=(C_word)C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2437(t7,t5);}
else{
t7=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t8=t6;
f_2437(t8,(C_word)C_u_i_memq(t7,((C_word*)t0)[9]));}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t6=(C_word)C_a_i_list(&a,2,lf[66],t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[13]);
t8=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[13]);
t4=t2;
f_2491(t4,(C_word)C_eqp(lf[84],t3));}
else{
t3=t2;
f_2491(t3,C_SCHEME_FALSE);}}}

/* k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2491,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t3=(C_word)C_i_symbolp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_2500(t6,t4);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t7=t5;
f_2500(t7,(C_word)C_u_i_memq(t6,((C_word*)t0)[9]));}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[13]);
t4=t2;
f_2568(t4,(C_word)C_eqp(lf[51],t3));}
else{
t3=t2;
f_2568(t3,C_SCHEME_FALSE);}}}

/* k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
f_3142(t4,((C_word*)t0)[9],t2,((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[12]);
t4=t2;
f_2591(t4,(C_word)C_eqp(lf[83],t3));}
else{
t3=t2;
f_2591(t3,C_SCHEME_FALSE);}}}

/* k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
f_2352(t4,((C_word*)t0)[6],t2,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[12]);
t4=t2;
f_2680(t4,(C_word)C_eqp(lf[44],t3));}
else{
t3=t2;
f_2680(t3,C_SCHEME_FALSE);}}}

/* k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)((C_word*)t0)[7])[1];
f_2352(t5,((C_word*)t0)[6],t3,((C_word*)t0)[9],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[83],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
f_1107(t2,t4);}
else{
t4=t2;
f_2745(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2745(2,t3,C_SCHEME_FALSE);}}}

/* k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)((C_word*)t0)[5])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[9]);
t4=t2;
f_2793(t4,(C_word)C_eqp(lf[82],t3));}
else{
t3=t2;
f_2793(t3,C_SCHEME_FALSE);}}}

/* k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
f_3142(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=t2;
f_2824(t4,(C_word)C_eqp(lf[81],t3));}
else{
t3=t2;
f_2824(t3,C_SCHEME_FALSE);}}}

/* k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)t0)[6]))){
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=t2;
f_2854(t4,(C_word)C_eqp(lf[80],t3));}
else{
t3=t2;
f_2854(t3,C_SCHEME_FALSE);}}}

/* k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2854,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)t0)[6]))){
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}}}}

/* k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3049(t3,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* a2925 in k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2926,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2934,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2932 in a2925 in k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2892 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2893,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
f_2352(t6,t1,t4,t3,t5);}

/* a2902 in a2892 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2903,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2802,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2810,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2814,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* k2812 in a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2808 in a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2754,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2758,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3181(t5,t4,t3,((C_word*)t0)[2]);}

/* k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2783,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* a2782 in k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2783,3,t0,t1,t2);}
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2779 in k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2695 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[44],t1);
t3=((C_word*)((C_word*)t0)[5])[1];
f_2352(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2710,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_3205(t5,((C_word*)t0)[4],t3);}

/* k2729 in a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2714(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[89]);}}

/* k2712 in a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[44],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2600,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2624(t9,t1,t4,t5);}

/* or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2624,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[3])[1];
f_2352(t6,t1,t4,((C_word*)t0)[2],t5);}}

/* a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2647,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_3205(t5,t3,((C_word*)t0)[2]);}

/* k2672 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2647(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[88]);}}

/* k2645 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2624(t4,((C_word*)t0)[2],t2,t3);}

/* a2655 in k2645 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2656,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2610,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k2620 in a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k2616 in a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2576 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2577,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[51],t2);}

/* k2583 in a2576 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2498 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[5])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t3);}}

/* a2534 in k2498 in k2489 in k2397 in k2388 in bound in bound */
static void f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2535,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[84],t4,t2);
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t3);}

/* k2501 in k2498 in k2489 in k2397 in k2388 in bound in bound */
static void f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_list(&a,3,lf[84],t1,t6);
t8=((C_word*)((C_word*)t0)[5])[1];
f_2352(t8,((C_word*)t0)[4],t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2414 in k2397 in k2388 in bound in bound */
static void f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k2410 in k2397 in k2388 in bound in bound */
static void f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2352(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2435 in k2397 in k2388 in bound in bound */
static void C_fcall f_2437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2437,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2438 in k2435 in k2397 in k2388 in bound in bound */
static void f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[5])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[66],t1);
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k2369 in bound in bound */
static void f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* find-prefix in bound */
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3181,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k3197 in find-prefix in bound */
static void f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* permutation in bound */
static void C_fcall f_3205(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3205,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a3216 in permutation in bound */
static void f_3217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3217,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_memq(t2,((C_word*)t0)[2]));}

/* inline-let */
static void C_fcall f_3244(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3244,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3327,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3431,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_u_i_caddr(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3504,a[2]=t5,a[3]=t9,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3504(t11,t1,t6,C_SCHEME_END_OF_LIST,t7);}

/* loop in inline-let */
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3504,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3524,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}
else{
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t5);
t7=f_3409(((C_word*)t0)[4],t6);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(t2);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t10=t4;
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_3253(t14,t9,t10);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
t19=t1;
t20=t8;
t21=t10;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}}

/* loop in loop in inline-let */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3253,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_fix(1):C_fix(0)));}}

/* k3265 in loop in loop in inline-let */
static void f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_3253(t4,t2,t3);}

/* k3269 in k3265 in loop in loop in inline-let */
static void f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k3534 in loop in inline-let */
static void f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(C_fix(0),t1))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=((C_word*)((C_word*)t0)[7])[1];
f_3504(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_nequalp(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3558(t4,t2);}
else{
t4=(C_word)C_u_i_car(((C_word*)t0)[8]);
t5=(C_word)C_u_i_cadr(t4);
t6=t3;
f_3558(t6,f_3431(((C_word*)t0)[2],t5));}}}

/* k3556 in k3534 in loop in inline-let */
static void C_fcall f_3558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3558,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_u_i_cadr(t4);
t6=((C_word*)t0)[3];
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3293,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3293(t10,t3,t6);}
else{
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[6])[1];
f_3504(t5,((C_word*)t0)[5],t2,t4,((C_word*)t0)[3]);}}

/* loop in k3556 in k3534 in loop in inline-let */
static void C_fcall f_3293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3293,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t2));}}

/* k3305 in loop in k3556 in k3534 in loop in inline-let */
static void f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_3293(t4,t2,t3);}

/* k3309 in k3305 in loop in k3556 in k3534 in loop in inline-let */
static void f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3567 in k3556 in k3534 in loop in inline-let */
static void f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_3504(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3522 in loop in inline-let */
static void f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[21],t1,((C_word*)t0)[2]));}

/* small? in inline-let */
static C_word C_fcall f_3431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t2=f_3327(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_eqp(t3,lf[20]);
if(C_truep(t4)){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t1);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_caddr(t1);
t8=f_3327(t7);
if(C_truep(t8)){
t9=(C_word)C_u_i_cdddr(t1);
return((C_word)C_i_nullp(t9));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}

/* isval? in inline-let */
static C_word C_fcall f_3409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
t2=f_3327(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_u_i_car(t1);
return((C_word)C_u_i_memq(t3,lf[85]));}
else{
return(C_SCHEME_FALSE);}}}

/* const? in inline-let */
static C_word C_fcall f_3327(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t2=(C_word)C_i_symbolp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_i_stringp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_charp(t1);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_i_numberp(t1);
if(C_truep(t6)){
return(t6);}
else{
t7=(C_word)C_i_nullp(t1);
if(C_truep(t7)){
return(t7);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t8=(C_word)C_u_i_car(t1);
t9=(C_word)C_eqp(t8,lf[43]);
if(C_truep(t9)){
t10=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cadr(t1);
if(C_truep((C_word)C_i_symbolp(t11))){
t12=(C_word)C_u_i_cddr(t1);
return((C_word)C_i_nullp(t12));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}}}}}}

/* gen */
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
if(C_truep((C_word)C_i_nullp(t4))){
t8=t5;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t2);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3639,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3648,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3657,a[2]=t10,a[3]=t11,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_u_i_caar(t4);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=t10,a[7]=t7,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t15,a[13]=((C_word*)t0)[9],a[14]=t9,tmp=(C_word)a,a+=15,tmp));
t17=((C_word*)t15)[1];
f_3755(t17,t1,t13,t2,t3,t11,t12);}}

/* next in gen */
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3755,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(lf[64],t2);
if(C_truep(t7)){
t8=t6;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t4);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_a_i_cons(&a,2,t2,t3);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[14])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[14])+1,t9);
t11=t6;
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t1,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_a_i_list(&a,2,lf[47],t3);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_equalp(t2,lf[65]))){
t8=(C_word)C_a_i_list(&a,2,lf[47],t3);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[37],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[37],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[37],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[37],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t5,a[16]=t4,a[17]=t1,a[18]=((C_word*)t0)[13],a[19]=t2,a[20]=t3,tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_u_i_car(t2);
t10=t8;
f_3866(t10,(C_word)C_eqp(lf[43],t9));}
else{
t9=t8;
f_3866(t9,C_SCHEME_FALSE);}}}}}}}}}}

/* k3864 in next in gen */
static void C_fcall f_3866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3866,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,3,lf[37],((C_word*)t0)[20],((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
f_4901(t3,((C_word*)t0)[17],t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[19]);
t4=t2;
f_3879(t4,(C_word)C_eqp(lf[66],t3));}
else{
t3=t2;
f_3879(t3,C_SCHEME_FALSE);}}}

/* k3877 in k3864 in next in gen */
static void C_fcall f_3879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[19]);
t4=((C_word*)t0)[18];
f_4901(t4,((C_word*)t0)[17],t3,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[20]);
t4=t2;
f_3895(t4,(C_word)C_eqp(lf[84],t3));}
else{
t3=t2;
f_3895(t3,C_SCHEME_FALSE);}}}

/* k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_3895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3895,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caddr(((C_word*)t0)[20]);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[20]);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[19]);
t5=((C_word*)((C_word*)t0)[18])[1];
f_3755(t5,((C_word*)t0)[17],t2,t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[14],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[20]);
t4=t2;
f_3916(t4,(C_word)C_eqp(lf[51],t3));}
else{
t3=t2;
f_3916(t3,C_SCHEME_FALSE);}}}

/* k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_3916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3916,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[20],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=t4,a[6]=((C_word*)t0)[19],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3925(t6,((C_word*)t0)[15],t2,((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[13],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[20]);
t4=t2;
f_3958(t4,(C_word)C_eqp(lf[83],t3));}
else{
t3=t2;
f_3958(t3,C_SCHEME_FALSE);}}}

/* k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_3958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3958,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_word)C_slot(((C_word*)t0)[19],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[18],tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_3967(t7,((C_word*)t0)[14],t3,((C_word*)t0)[13]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[19]);
t4=t2;
f_4001(t4,(C_word)C_eqp(lf[44],t3));}
else{
t3=t2;
f_4001(t3,C_SCHEME_FALSE);}}}

/* k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[20]);
t3=((C_word*)((C_word*)t0)[19])[1];
f_3755(t3,((C_word*)t0)[18],t2,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[20]);
t4=t2;
f_4014(t4,(C_word)C_eqp(lf[82],t3));}
else{
t3=t2;
f_4014(t3,C_SCHEME_FALSE);}}}

/* k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_slot(((C_word*)t0)[20],C_fix(1));
t4=(C_word)C_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=t4,a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
f_7151(t5,(C_word)C_a_i_list(&a,2,t2,lf[66]));}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[11],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[20]);
t4=t2;
f_4076(t4,(C_word)C_eqp(lf[81],t3));}
else{
t3=t2;
f_4076(t3,C_SCHEME_FALSE);}}}

/* k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4076,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[19]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[14];
f_6581(t4,t3,((C_word*)t0)[13],((C_word*)t0)[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[19]);
t4=t2;
f_4101(t4,(C_word)C_eqp(lf[80],t3));}
else{
t3=t2;
f_4101(t3,C_SCHEME_FALSE);}}}

/* k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4101,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[18]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[13];
f_6886(t4,t3,((C_word*)t0)[12],((C_word*)t0)[18]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[18]))){
t3=(C_word)C_slot(((C_word*)t0)[18],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[18]);
f_1107(t2,t4);}
else{
t4=t2;
f_4126(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4126(2,t3,C_SCHEME_FALSE);}}}

/* k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[45],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
t4=((C_word*)t0)[8];
f_4901(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[16]))){
t2=(C_word)C_a_i_list(&a,2,lf[48],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[16],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[8];
f_4901(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[16]))){
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[16]));
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(6)))){
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[16]));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(5));
t6=(C_word)C_slot(((C_word*)t0)[16],t5);
f_1107(t2,t6);}
else{
t4=t2;
f_4465(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4465(2,t3,C_SCHEME_FALSE);}}}}

/* k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[13]));
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(C_word)C_slot(((C_word*)t0)[13],t5);
f_1107(t4,t6);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[13]))){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[13]));
t3=(C_word)C_a_i_list(&a,2,lf[70],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[5];
f_4901(t5,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[6],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}}}

/* k4753 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4756 in k4753 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,lf[76]);}

/* a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4703,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[71],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[37],t3,((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4717,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_4717(t9,t5,C_fix(0));}

/* vloop in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4717,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp));}

/* f_4719 in vloop in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4719,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[18],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4717(t7,t5,t6);}}

/* k4742 */
static void f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4713 in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
f_4901(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_list(&a,2,lf[70],((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t7=((C_word*)t0)[4];
f_4901(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[5],t6);}

/* a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4486,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[71],((C_word*)t0)[12]);
t4=(C_word)C_a_i_list(&a,3,lf[72],t3,((C_word*)t0)[11]);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t2,a[13]=t4,a[14]=t1,a[15]=((C_word*)t0)[10],tmp=(C_word)a,a+=16,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4502,a[2]=t1,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4507,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4507(t7,t3,C_fix(0));}

/* vloop in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4507,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp));}

/* f_4509 in vloop in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[61],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4509,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[13],((C_word*)t0)[12]))){
t3=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,lf[64]);
if(C_truep(t4)){
t5=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(3));
t6=(C_word)C_slot(((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(4));
t8=(C_word)C_slot(((C_word*)t0)[11],t7);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(5));
t10=(C_word)C_slot(((C_word*)t0)[11],t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t6,a[8]=t1,a[9]=t8,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[12]);
t13=(C_word)C_a_i_list(&a,3,lf[18],((C_word*)t0)[7],t8);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4619,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t15=((C_word*)((C_word*)t0)[4])[1];
f_3755(t15,t11,t12,t13,t2,((C_word*)t0)[3],t14);}}
else{
t3=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,3,lf[18],((C_word*)t0)[7],((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4531,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[13]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4507(t7,t5,t6);}}

/* k4529 */
static void f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4618 */
static void f_4619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4619,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,3,lf[74],((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4636 in a4618 */
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
f_3639(3,t5,t4,t2);}

/* k4643 in a4636 in a4618 */
static void f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[68],t1,((C_word*)t0)[2]));}

/* k4633 in a4618 */
static void f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4625 in a4618 */
static void f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4554 */
static void f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[11],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[68]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4607 in k4554 */
static void f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4558 in k4554 */
static void f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_a_i_list(&a,2,lf[71],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[74],t4,C_fix(1));
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4589,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a4588 in k4558 in k4554 */
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4589,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[43],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4585 in k4558 in k4554 */
static void f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4565 in k4558 in k4554 */
static void f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[73],((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4579,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4577 in k4565 in k4558 in k4554 */
static void f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[50],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[21],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k4503 in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4500 in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4433,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4445,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=((C_word*)t0)[2];
f_6514(t5,t4,((C_word*)t0)[3]);}

/* k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[9])[1];
f_3755(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],((C_word*)t0)[8],t2);}

/* a4446 in k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4447,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
f_6547(t5,t4,((C_word*)t0)[2]);}

/* k4457 in a4446 in k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
f_1107(t3,t4);}

/* k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_4140(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(1):
t3=(C_word)C_a_i_list(&a,2,lf[48],((C_word*)t0)[12]);
t4=((C_word*)t0)[3];
f_4901(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[10],t2);
default:
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[12]);
t5=((C_word*)t0)[3];
f_4901(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[10],t2);}}

/* ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4140,3,t0,t1,t2);}
t3=(C_word)C_u_i_list_ref(((C_word*)t0)[10],C_fix(2));
t4=(C_word)C_u_i_car(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,lf[64]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_u_i_car(((C_word*)t0)[10]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4239,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4242,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)((C_word*)t0)[4])[1];
f_3755(t10,t6,t7,((C_word*)t0)[5],t2,t8,t9);}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_u_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t7))){
t8=(C_word)C_u_i_car(((C_word*)t0)[10]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=t6;
f_4249(t10,(C_word)C_i_equalp(t9,t3));}
else{
t8=t6;
f_4249(t8,C_SCHEME_FALSE);}}}}

/* k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[11]);
t3=((C_word*)((C_word*)t0)[10])[1];
f_3755(t3,((C_word*)t0)[9],t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_u_i_list_ref(((C_word*)t0)[11],C_fix(3));
t3=(C_word)C_u_i_list_ref(((C_word*)t0)[11],C_fix(4));
t4=(C_word)C_u_i_list_ref(((C_word*)t0)[11],C_fix(5));
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[11]);
t7=(C_word)C_a_i_list(&a,2,lf[23],t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4333,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=((C_word*)((C_word*)t0)[10])[1];
f_3755(t9,t5,t6,t7,((C_word*)t0)[7],((C_word*)t0)[6],t8);}}

/* a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,2,lf[24],((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4349,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4350 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4351,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
f_3639(3,t5,t4,t2);}

/* k4357 in a4350 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[68],t1,((C_word*)t0)[2]));}

/* k4347 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4339 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4319,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a4318 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4319,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[69],t2));}

/* k4315 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[68]+1),((C_word*)t0)[2],t1);}

/* k4311 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4301,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a4300 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4301,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[43],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4297 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4277 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[47],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4291,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4289 in k4277 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[50],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[21],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a4241 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4242,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a4238 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4239,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cadr(t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
if(C_truep(t7)){
t8=(C_word)C_u_i_cddr(t1);
t9=t3;
f_4183(t9,(C_word)C_i_nullp(t8));}
else{
t8=t3;
f_4183(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4183(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4183(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4183(t4,C_SCHEME_FALSE);}}

/* k4181 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4183,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4165(t2,(C_word)C_u_i_car(((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4165(t3,(C_word)C_a_i_list(&a,3,lf[20],t2,((C_word*)t0)[3]));}}

/* k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[61],t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4174 in k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4180,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4178 in k4174 in k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4118 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4093 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4035,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4035(t7,t3,C_fix(1));}

/* rloop in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4035,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp));}

/* f_4037 in rloop in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(C_word)C_u_i_list_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[25],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4035(t7,t5,t6);}}

/* k4060 */
static void f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4031 in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
f_4901(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3967,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)((C_word*)t0)[4])[1];
f_3755(t7,t1,t5,((C_word*)t0)[3],t3,t6,((C_word*)t0)[2]);}}

/* a3986 in loop in k3956 in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_3987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3987,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_3967(t4,t1,t3,t2);}

/* loop in k3914 in k3893 in k3877 in k3864 in next in gen */
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3925,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)((C_word*)t0)[4])[1];
f_3755(t6,t1,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],t5);}}

/* a3943 in loop in k3914 in k3893 in k3877 in k3864 in next in gen */
static void f_3944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3944,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_3925(t4,t1,t3,t2);}

/* success in gen */
static void f_3657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3657,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_u_i_cddddr(t3);
t5=(C_word)C_i_set_i_slot(t4,C_fix(0),C_SCHEME_TRUE);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=(C_word)C_u_i_cadr(t6);
t8=(C_word)C_u_i_car(((C_word*)t0)[4]);
t9=(C_word)C_u_i_caddr(t8);
t10=(C_word)C_u_i_car(((C_word*)t0)[4]);
t11=(C_word)C_u_i_cadddr(t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t7,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3719,a[2]=t11,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,((C_word*)t0)[2],t9);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}}

/* k3724 in success in gen */
static void f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3717 in success in gen */
static void f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3713 in success in gen */
static void f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3674 in success in gen */
static void f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[3];
f_3648(3,t4,t3,((C_word*)t0)[2]);}

/* k3709 in k3674 in success in gen */
static void f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3711,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,3,lf[21],t5,((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,lf[53],t7));}

/* fail in gen */
static void f_3648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3648,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=((C_word*)((C_word*)t0)[6])[1];
f_3628(t4,t1,((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* val in gen */
static void f_3639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3639,3,t0,t1,t2);}
t3=(C_word)C_u_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,C_fix(1)));}

/* dot-dot-k? */
static void C_fcall f_1107(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1107,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
if(C_truep((C_truep((C_word)C_eqp(t3,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1121 in dot-dot-k? */
static void f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_less_or_equalp(C_fix(3),t2))){
t3=(C_word)C_subchar(t1,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_subchar(t1,C_fix(1));
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1150,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t1,C_fix(2),t2);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1163 in k1121 in dot-dot-k? */
static void f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1159 in k1121 in dot-dot-k? */
static void f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[62]+1),t1);}

/* k1148 in k1121 in dot-dot-k? */
static void f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1155 in k1148 in k1121 in dot-dot-k? */
static void f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* emit */
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4901,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=t3,a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=((C_word*)t0)[2];
f_6108(t7,t6,t2,t3);}

/* k4906 in emit */
static void f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[44],((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_6108(t4,t2,t3,((C_word*)t0)[6]);}}

/* k4915 in k4906 in emit */
static void f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4926,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t4,lf[37]);
if(C_truep(t5)){
t6=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[38],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[39],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_charp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[40],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[41],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t6))){
t8=(C_word)C_u_i_car(t6);
t9=t7;
f_5039(t9,(C_word)C_eqp(lf[43],t8));}
else{
t8=t7;
f_5039(t8,C_SCHEME_FALSE);}}}}}}
else{
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=(C_word)C_eqp(t6,lf[47]);
if(C_truep(t7)){
t8=(C_word)C_a_i_list(&a,2,lf[45],t2);
t9=t3;
f_4926(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t8=t3;
f_4926(t8,C_SCHEME_END_OF_LIST);}}}}

/* k5037 in k4915 in k4906 in emit */
static void C_fcall f_5039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[42],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4926(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[2];
f_4926(t2,C_SCHEME_END_OF_LIST);}}

/* k4924 in k4915 in k4906 in emit */
static void C_fcall f_4926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4926,NULL,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4932,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(t2,lf[45]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[47],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[44],t5);
t7=t3;
f_4932(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t3;
f_4932(t5,C_SCHEME_END_OF_LIST);}}

/* k4930 in k4924 in k4915 in k4906 in emit */
static void C_fcall f_4932(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4932,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4959 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4938,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[44],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4953,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4951 in k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4936 in k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* assm */
static void C_fcall f_5083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5083,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_equalp(t4,t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t4,C_SCHEME_TRUE);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[48]);
if(C_truep(t9)){
t10=*((C_word*)lf[7]+1);
if(C_truep((C_truep((C_word)C_eqp(t10,lf[55]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t10,lf[56]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t11=(C_word)C_u_i_car(t3);
if(C_truep((C_truep((C_word)C_eqp(t11,lf[49]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t11,lf[6]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t12=(C_word)C_u_i_cadr(t2);
t13=((C_word*)t0)[2];
f_5977(t13,t7,t4,t12);}
else{
t12=t7;
f_5102(2,t12,C_SCHEME_FALSE);}}
else{
t11=t7;
f_5102(2,t11,C_SCHEME_FALSE);}}
else{
t10=t7;
f_5102(2,t10,C_SCHEME_FALSE);}}}}

/* k5100 in assm */
static void f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[50]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t6=t2;
f_5108(t6,(C_word)C_i_equalp(t5,((C_word*)t0)[4]));}
else{
t5=t2;
f_5108(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5108(t3,C_SCHEME_FALSE);}}}

/* k5106 in k5100 in assm */
static void C_fcall f_5108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5108,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[51]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5129,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[3],t8);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[51],((C_word*)t0)[3],t5);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[50],t6,t7,((C_word*)t0)[4]));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[53]);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[6]);}
else{
t7=t2;
f_5166(t7,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5166(t6,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5166(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5166(t3,C_SCHEME_FALSE);}}}

/* k5905 in k5106 in k5100 in assm */
static void f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cdadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadadr(((C_word*)t0)[4]);
t6=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t9=(C_word)C_u_i_car(t8);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t11=(C_word)C_u_i_caar(t10);
t12=(C_word)C_eqp(t11,lf[21]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t14=(C_word)C_u_i_cdar(t13);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t16=(C_word)C_u_i_cadar(t15);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t18=(C_word)C_u_i_caadar(t17);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t20=(C_word)C_u_i_caadar(t19);
t21=(C_word)C_slot(t20,C_fix(1));
if(C_truep((C_word)C_i_pairp(t21))){
t22=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t23=(C_word)C_u_i_caadar(t22);
t24=(C_word)C_u_i_cadr(t23);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t26=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t27=(C_word)C_u_i_caadar(t26);
t28=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t28+1)))(3,t28,t25,t27);}
else{
t25=((C_word*)t0)[3];
f_5166(t25,C_SCHEME_FALSE);}}
else{
t22=((C_word*)t0)[3];
f_5166(t22,C_SCHEME_FALSE);}}
else{
t19=((C_word*)t0)[3];
f_5166(t19,C_SCHEME_FALSE);}}
else{
t17=((C_word*)t0)[3];
f_5166(t17,C_SCHEME_FALSE);}}
else{
t15=((C_word*)t0)[3];
f_5166(t15,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[3];
f_5166(t13,C_SCHEME_FALSE);}}
else{
t10=((C_word*)t0)[3];
f_5166(t10,C_SCHEME_FALSE);}}
else{
t8=((C_word*)t0)[3];
f_5166(t8,C_SCHEME_FALSE);}}
else{
t7=((C_word*)t0)[3];
f_5166(t7,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
f_5166(t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
f_5166(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5809 in k5905 in k5106 in k5100 in assm */
static void f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word *a;
t2=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t4=(C_word)C_u_i_caadar(t3);
t5=(C_word)C_u_i_cdadr(t4);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t7=(C_word)C_u_i_caadar(t6);
t8=(C_word)C_u_i_cadadr(t7);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t10=(C_word)C_u_i_caadar(t9);
t11=(C_word)C_u_i_cddadr(t10);
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t13=(C_word)C_u_i_caadar(t12);
t14=(C_word)C_u_i_cddadr(t13);
t15=(C_word)C_u_i_car(t14);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t17=(C_word)C_u_i_caadar(t16);
t18=(C_word)C_u_i_cddadr(t17);
t19=(C_word)C_u_i_cdar(t18);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t21=(C_word)C_u_i_caadar(t20);
t22=(C_word)C_u_i_cddadr(t21);
t23=(C_word)C_u_i_cddar(t22);
if(C_truep((C_word)C_i_nullp(t23))){
t24=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t25=(C_word)C_u_i_caadar(t24);
t26=(C_word)C_u_i_cddadr(t25);
t27=(C_word)C_slot(t26,C_fix(1));
if(C_truep((C_word)C_i_nullp(t27))){
t28=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t29=(C_word)C_u_i_caadar(t28);
t30=(C_word)C_u_i_cddr(t29);
if(C_truep((C_word)C_i_nullp(t30))){
t31=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t32=(C_word)C_u_i_cdadar(t31);
if(C_truep((C_word)C_i_nullp(t32))){
t33=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t34=(C_word)C_u_i_cddar(t33);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t36=(C_word)C_u_i_cdddar(t35);
if(C_truep((C_word)C_i_nullp(t36))){
t37=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t38=(C_word)C_slot(t37,C_fix(1));
if(C_truep((C_word)C_i_nullp(t38))){
t39=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t39))){
t40=(C_word)C_u_i_cddadr(((C_word*)t0)[4]);
t41=(C_word)C_u_i_caadar(t40);
t42=(C_word)C_u_i_cddadr(t41);
t43=(C_word)C_u_i_cadar(t42);
t44=((C_word*)t0)[3];
f_5166(t44,(C_word)C_i_equalp(((C_word*)t0)[2],t43));}
else{
t40=((C_word*)t0)[3];
f_5166(t40,C_SCHEME_FALSE);}}
else{
t39=((C_word*)t0)[3];
f_5166(t39,C_SCHEME_FALSE);}}
else{
t37=((C_word*)t0)[3];
f_5166(t37,C_SCHEME_FALSE);}}
else{
t35=((C_word*)t0)[3];
f_5166(t35,C_SCHEME_FALSE);}}
else{
t33=((C_word*)t0)[3];
f_5166(t33,C_SCHEME_FALSE);}}
else{
t31=((C_word*)t0)[3];
f_5166(t31,C_SCHEME_FALSE);}}
else{
t28=((C_word*)t0)[3];
f_5166(t28,C_SCHEME_FALSE);}}
else{
t24=((C_word*)t0)[3];
f_5166(t24,C_SCHEME_FALSE);}}
else{
t20=((C_word*)t0)[3];
f_5166(t20,C_SCHEME_FALSE);}}
else{
t16=((C_word*)t0)[3];
f_5166(t16,C_SCHEME_FALSE);}}
else{
t12=((C_word*)t0)[3];
f_5166(t12,C_SCHEME_FALSE);}}
else{
t9=((C_word*)t0)[3];
f_5166(t9,C_SCHEME_FALSE);}}
else{
t6=((C_word*)t0)[3];
f_5166(t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5164 in k5106 in k5100 in assm */
static void C_fcall f_5166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadadr(((C_word*)t0)[6]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cddadr(((C_word*)t0)[6]);
t5=(C_word)C_u_i_caadar(t4);
t6=(C_word)C_u_i_car(t5);
t7=(C_word)C_u_i_cddadr(((C_word*)t0)[6]);
t8=(C_word)C_u_i_caddar(t7);
t9=(C_word)C_a_i_list(&a,1,t3);
t10=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_list(&a,2,t6,t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[4],a[3]=t9,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_a_i_list(&a,1,t6);
t16=((C_word*)((C_word*)t0)[3])[1];
f_5083(t16,t14,((C_word*)t0)[2],t15,t8);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[50],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5]));}}

/* k5196 in k5164 in k5106 in k5100 in assm */
static void f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5198,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[53],t3));}

/* k5127 in k5106 in k5100 in assm */
static void f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k5119 in k5106 in k5100 in assm */
static void f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5121,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[50],t1,t2,((C_word*)t0)[2]));}

/* guarantees */
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5977,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5981,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
f_6514(t5,t4,t3);}

/* k5979 in guarantees */
static void f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
f_6547(t3,t2,((C_word*)t0)[2]);}

/* k5982 in k5979 in guarantees */
static void f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5989,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5989(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k5982 in k5979 in guarantees */
static void C_fcall f_5989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5989,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t3,lf[49]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[6]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_equalp(t2,((C_word*)t0)[4]);
t5=(C_truep(t4)?t4:(C_word)C_i_equalp(t2,((C_word*)t0)[3]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[50]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_i_cadr(t2);
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[20]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_u_i_car(t2);
t12=(C_word)C_eqp(t11,lf[21]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=t10;
f_6056(t14,(C_word)C_i_symbolp(t13));}
else{
t13=t10;
f_6056(t13,C_SCHEME_FALSE);}}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6054 in loop in k5982 in k5979 in guarantees */
static void C_fcall f_6056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6056,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_5989(t4,t2,t3);}}

/* k6057 in k6054 in loop in k5982 in k5979 in guarantees */
static void f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_5989(t3,((C_word*)t0)[4],t2);}}

/* k6018 in loop in k5982 in k5979 in guarantees */
static void f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_5989(t4,t2,t3);}}

/* k6027 in k6018 in loop in k5982 in k5979 in guarantees */
static void f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5989(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* in */
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6108,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_member(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6118,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[45]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[47],t8);
t10=(C_word)C_i_member(t9,t3);
if(C_truep(t10)){
t11=t5;
f_6118(t11,t10);}
else{
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[48],t11);
t13=t5;
f_6118(t13,(C_word)C_i_member(t12,t3));}}
else{
t8=t5;
f_6118(t8,C_SCHEME_FALSE);}}}

/* k6116 in in */
static void C_fcall f_6118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[44]);
if(C_truep(t3)){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
f_6418(t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k6131 in k6116 in in */
static void f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6141(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=f_6504(((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6259(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[45]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6325(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6325,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_cadr(t3);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_u_i_memq(t8,lf[46]);
t10=t4;
f_6338(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6338(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6338(t7,C_SCHEME_FALSE);}}}

/* k6336 in mem in k6131 in k6116 in in */
static void C_fcall f_6338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_6325(t3,((C_word*)t0)[4],t2);}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6259,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6272,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_cadr(t3);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_u_i_car(((C_word*)t0)[3]);
t10=(C_word)C_i_equalp(t8,t9);
t11=t4;
f_6272(t11,(C_word)C_i_not(t10));}
else{
t8=t4;
f_6272(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6272(t7,C_SCHEME_FALSE);}}}

/* k6270 in mem in k6131 in k6116 in in */
static void C_fcall f_6272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_6259(t3,((C_word*)t0)[4],t2);}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6141,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_u_i_cadr(t3);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_i_equalp(((C_word*)t0)[5],t8);
t10=t4;
f_6154(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6154(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6154(t7,C_SCHEME_FALSE);}}}

/* k6152 in mem in k6131 in k6116 in in */
static void C_fcall f_6154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6154,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,2,lf[44],t3);
t5=(C_word)C_i_equalp(((C_word*)t0)[5],t4);
if(C_truep(t5)){
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_equalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
f_6418(t9,((C_word*)t0)[5]);}
else{
t9=t6;
f_6166(t9,C_SCHEME_FALSE);}}}}

/* k6183 in k6152 in mem in k6131 in k6116 in in */
static void f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=(C_word)C_i_equalp(t2,t3);
t5=((C_word*)t0)[2];
f_6166(t5,(C_word)C_i_not(t4));}
else{
t2=((C_word*)t0)[2];
f_6166(t2,C_SCHEME_FALSE);}}

/* k6164 in k6152 in mem in k6131 in k6116 in in */
static void C_fcall f_6166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_6141(t3,((C_word*)t0)[4],t2);}}

/* equal-test? */
static void C_fcall f_6418(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6418,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[37]);
if(C_truep(t4)){
t5=(C_word)C_u_i_caddr(t2);
if(C_truep((C_word)C_i_stringp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[38]);}
else{
if(C_truep((C_word)C_booleanp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[39]);}
else{
if(C_truep((C_word)C_charp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[40]);}
else{
if(C_truep((C_word)C_i_numberp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[41]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cddr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_u_i_car(t5);
t10=(C_word)C_eqp(lf[43],t9);
if(C_truep(t10)){
t11=(C_word)C_u_i_cadr(t5);
t12=t6;
f_6458(t12,(C_word)C_i_symbolp(t11));}
else{
t11=t6;
f_6458(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6458(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_6458(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_6458(t7,C_SCHEME_FALSE);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6456 in equal-test? */
static void C_fcall f_6458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?lf[42]:C_SCHEME_FALSE));}

/* disjoint? */
static C_word C_fcall f_6504(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_car(t1);
return((C_word)C_u_i_memq(t2,*((C_word*)lf[12]+1)));}

/* add-a */
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6514,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6518,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=t3;
f_6518(t5,(C_word)C_u_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6518(t4,C_SCHEME_FALSE);}}

/* k6516 in add-a */
static void C_fcall f_6518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6518,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(t1);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[23],((C_word*)t0)[3]));}}

/* add-d */
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6547,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6551,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=t3;
f_6551(t5,(C_word)C_u_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6551(t4,C_SCHEME_FALSE);}}

/* k6549 in add-d */
static void C_fcall f_6551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cddr(t1);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[24],((C_word*)t0)[3]));}}

/* setter */
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[232],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6581,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(t2);
t8=(C_word)C_a_i_list(&a,2,lf[19],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_list(&a,1,lf[29]);
t11=(C_word)C_u_i_caddr(t2);
t12=(C_word)C_a_i_list(&a,4,lf[30],lf[19],t11,lf[29]);
t13=(C_word)C_a_i_list(&a,3,lf[20],t10,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[21],t9,t13));}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_eqp(t7,lf[22]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[19],t9);
t11=(C_word)C_a_i_list(&a,1,t10);
t12=(C_word)C_a_i_list(&a,1,lf[29]);
t13=(C_word)C_a_i_list(&a,3,lf[31],lf[19],lf[29]);
t14=(C_word)C_a_i_list(&a,3,lf[20],t12,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[21],t11,t14));}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(t9,lf[23]);
if(C_truep(t10)){
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[19],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(C_word)C_a_i_list(&a,1,lf[29]);
t15=(C_word)C_a_i_list(&a,3,lf[32],lf[19],lf[29]);
t16=(C_word)C_a_i_list(&a,3,lf[20],t14,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[21],t13,t16));}
else{
t11=(C_word)C_u_i_car(t2);
t12=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=(C_word)C_a_i_list(&a,2,lf[19],t13);
t15=(C_word)C_a_i_list(&a,1,t14);
t16=(C_word)C_a_i_list(&a,1,lf[29]);
t17=(C_word)C_a_i_list(&a,3,lf[33],lf[19],lf[29]);
t18=(C_word)C_a_i_list(&a,3,lf[20],t16,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_list(&a,3,lf[21],t15,t18));}
else{
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_eqp(t13,lf[25]);
if(C_truep(t14)){
t15=(C_word)C_u_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,lf[19],t15);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(C_word)C_a_i_list(&a,1,lf[29]);
t19=(C_word)C_u_i_caddr(t2);
t20=(C_word)C_a_i_list(&a,4,lf[34],lf[19],t19,lf[29]);
t21=(C_word)C_a_i_list(&a,3,lf[20],t18,t20);
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_word)C_a_i_list(&a,3,lf[21],t17,t21));}
else{
t15=(C_word)C_u_i_car(t2);
t16=(C_word)C_u_i_assq(t15,((C_word*)t0)[2]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6775,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t16)){
t18=(C_word)C_u_i_cadr(t16);
t19=(C_word)C_u_i_cadr(t2);
t20=(C_word)C_a_i_list(&a,2,t18,t19);
t21=(C_word)C_a_i_list(&a,2,lf[19],t20);
t22=(C_word)C_a_i_list(&a,1,t21);
t23=(C_word)C_a_i_list(&a,1,lf[29]);
t24=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6836,a[2]=t22,a[3]=t17,a[4]=t23,tmp=(C_word)a,a+=5,tmp);
t25=(C_word)C_u_i_cddr(t16);
t26=t4;
f_6583(t26,t24,t25);}
else{
t18=t17;
f_6775(t18,C_SCHEME_FALSE);}}}}}}}
else{
t5=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,lf[35]);}}

/* k6834 in setter */
static void f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[19],lf[29]);
t3=(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
f_6775(t4,(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[2],t3));}

/* k6773 in setter */
static void C_fcall f_6775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,1,lf[29]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6801,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
f_6583(t8,t6,t7);}}

/* k6799 in k6773 in setter */
static void f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[19],lf[29]);
t3=(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[2],t3));}

/* mk-setter in setter */
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6583,NULL,3,t0,t1,t2);}
f_7151(t1,(C_word)C_a_i_list(&a,3,lf[27],t2,lf[28]));}

/* getter */
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[214],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6886,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[18]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,2,lf[19],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_u_i_caddr(t2);
t10=(C_word)C_a_i_list(&a,3,lf[18],lf[19],t9);
t11=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[21],t8,t11));}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[22]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[19],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_list(&a,2,lf[22],lf[19]);
t12=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_list(&a,3,lf[21],t10,t12));}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[23]);
if(C_truep(t9)){
t10=(C_word)C_u_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,2,lf[19],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(C_word)C_a_i_list(&a,2,lf[23],lf[19]);
t14=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[21],t12,t14));}
else{
t10=(C_word)C_u_i_car(t2);
t11=(C_word)C_eqp(t10,lf[24]);
if(C_truep(t11)){
t12=(C_word)C_u_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,2,lf[19],t12);
t14=(C_word)C_a_i_list(&a,1,t13);
t15=(C_word)C_a_i_list(&a,2,lf[24],lf[19]);
t16=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[21],t14,t16));}
else{
t12=(C_word)C_u_i_car(t2);
t13=(C_word)C_eqp(t12,lf[25]);
if(C_truep(t13)){
t14=(C_word)C_u_i_cadr(t2);
t15=(C_word)C_a_i_list(&a,2,lf[19],t14);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(C_word)C_u_i_caddr(t2);
t18=(C_word)C_a_i_list(&a,3,lf[25],lf[19],t17);
t19=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t18);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[21],t16,t19));}
else{
t14=(C_word)C_u_i_car(t2);
t15=(C_word)C_u_i_assq(t14,((C_word*)t0)[2]);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t15)){
t17=(C_word)C_u_i_cadr(t15);
t18=(C_word)C_u_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,2,t17,t18);
t20=(C_word)C_a_i_list(&a,2,lf[19],t19);
t21=(C_word)C_a_i_list(&a,1,t20);
t22=(C_word)C_u_i_cddr(t15);
t23=(C_word)C_a_i_list(&a,2,t22,lf[19]);
t24=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t23);
t25=t16;
f_7055(t25,(C_word)C_a_i_list(&a,3,lf[21],t21,t24));}
else{
t17=t16;
f_7055(t17,C_SCHEME_FALSE);}}}}}}}
else{
t4=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,lf[26]);}}

/* k7053 in getter */
static void C_fcall f_7055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7055,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,2,lf[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t5,lf[19]);
t7=(C_word)C_a_i_list(&a,3,lf[20],C_SCHEME_END_OF_LIST,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[21],t4,t7));}}

/* symbol-append */
static void C_fcall f_7151(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7159,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7165,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a7164 in symbol-append */
static void f_7165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7165,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
C_number_to_string(3,0,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k7161 in symbol-append */
static void f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[14]+1),t1);}

/* k7157 in symbol-append */
static void f_7159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##match#set-error-control */
static void f_528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_528,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[7]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#set-error */
static void f_523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_523,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[6]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#syntax-err */
static void f_517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_517,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[4],t3,t2);}
/* end of file */
