/* Generated from srfi-14.scm by the Chicken compiler
   2005-08-24 19:44
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-14.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file usrfi-14.c -explicit-use
   unit: srfi_14
*/

#include "chicken.h"


static C_TLS C_word lf[107];


C_externexport void C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_622(C_word c,C_word t0,C_word t1) C_noret;
static void f_738(C_word c,C_word t0,C_word t1) C_noret;
static void f_742(C_word c,C_word t0,C_word t1) C_noret;
static void f_2608(C_word c,C_word t0,C_word t1) C_noret;
static void f_2612(C_word c,C_word t0,C_word t1) C_noret;
static void f_2616(C_word c,C_word t0,C_word t1) C_noret;
static void f_2619(C_word c,C_word t0,C_word t1) C_noret;
static void f_2622(C_word c,C_word t0,C_word t1) C_noret;
static void f_2724(C_word c,C_word t0,C_word t1) C_noret;
static void f_2625(C_word c,C_word t0,C_word t1) C_noret;
static void f_2629(C_word c,C_word t0,C_word t1) C_noret;
static void f_2720(C_word c,C_word t0,C_word t1) C_noret;
static void f_2632(C_word c,C_word t0,C_word t1) C_noret;
static void f_2637(C_word c,C_word t0,C_word t1) C_noret;
static void f_2712(C_word c,C_word t0,C_word t1) C_noret;
static void f_2716(C_word c,C_word t0,C_word t1) C_noret;
static void f_2640(C_word c,C_word t0,C_word t1) C_noret;
static void f_2644(C_word c,C_word t0,C_word t1) C_noret;
static void f_2648(C_word c,C_word t0,C_word t1) C_noret;
static void f_2652(C_word c,C_word t0,C_word t1) C_noret;
static void f_2656(C_word c,C_word t0,C_word t1) C_noret;
static void f_2659(C_word c,C_word t0,C_word t1) C_noret;
static void f_2662(C_word c,C_word t0,C_word t1) C_noret;
static void f_2666(C_word c,C_word t0,C_word t1) C_noret;
static void f_2669(C_word c,C_word t0,C_word t1) C_noret;
static void f_2672(C_word c,C_word t0,C_word t1) C_noret;
static void f_2676(C_word c,C_word t0,C_word t1) C_noret;
static void f_2708(C_word c,C_word t0,C_word t1) C_noret;
static void f_2680(C_word c,C_word t0,C_word t1) C_noret;
static void f_2684(C_word c,C_word t0,C_word t1) C_noret;
static void f_2704(C_word c,C_word t0,C_word t1) C_noret;
static void f_2688(C_word c,C_word t0,C_word t1) C_noret;
static void f_2700(C_word c,C_word t0,C_word t1) C_noret;
static void f_2692(C_word c,C_word t0,C_word t1) C_noret;
static void f_2696(C_word c,C_word t0,C_word t1) C_noret;
static void f_2579(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2579r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2604(C_word c,C_word t0,C_word t1) C_noret;
static void f_2583(C_word c,C_word t0,C_word t1) C_noret;
static void f_2586(C_word c,C_word t0,C_word t1) C_noret;
static void f_2589(C_word c,C_word t0,C_word t1) C_noret;
static void f_2596(C_word c,C_word t0,C_word t1) C_noret;
static void f_2600(C_word c,C_word t0,C_word t1) C_noret;
static void f_2528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2528r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2532(C_word c,C_word t0,C_word t1) C_noret;
static void f_2535(C_word c,C_word t0,C_word t1) C_noret;
static void f_2546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2538(C_word c,C_word t0,C_word t1) C_noret;
static void f_2541(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2475(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2526(C_word c,C_word t0,C_word t1) C_noret;
static void f_2487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2411(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2411r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2466(C_word c,C_word t0,C_word t1) C_noret;
static void f_2421(C_word c,C_word t0,C_word t1) C_noret;
static void f_2433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2450(C_word c,C_word t0,C_word t1) C_noret;
static void f_2424(C_word c,C_word t0,C_word t1) C_noret;
static void f_2370(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2370r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2378(C_word c,C_word t0,C_word t1) C_noret;
static void f_2380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2397(C_word c,C_word t0,C_word t1) C_noret;
static void f_2374(C_word c,C_word t0,C_word t1) C_noret;
static void f_2329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2365(C_word c,C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1) C_noret;
static void f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2342(C_word c,C_word t0,C_word t1) C_noret;
static void f_2303(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2303r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2311(C_word c,C_word t0,C_word t1) C_noret;
static void f_2313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2307(C_word c,C_word t0,C_word t1) C_noret;
static void f_2258(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2258r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2294(C_word c,C_word t0,C_word t1) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void f_2280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2271(C_word c,C_word t0,C_word t1) C_noret;
static void f_2236(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2236r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2244(C_word c,C_word t0,C_word t1) C_noret;
static void f_2246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2240(C_word c,C_word t0,C_word t1) C_noret;
static void f_2187(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2187r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2227(C_word c,C_word t0,C_word t1) C_noret;
static void f_2197(C_word c,C_word t0,C_word t1) C_noret;
static void f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2200(C_word c,C_word t0,C_word t1) C_noret;
static void f_2161(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2161r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1) C_noret;
static void f_2171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2165(C_word c,C_word t0,C_word t1) C_noret;
static void f_2139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2143(C_word c,C_word t0,C_word t1) C_noret;
static void f_2148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void f_2146(C_word c,C_word t0,C_word t1) C_noret;
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2115(C_word c,C_word t0,C_word t1) C_noret;
static void f_2118(C_word c,C_word t0,C_word t1) C_noret;
static void f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2137(C_word c,C_word t0,C_word t1) C_noret;
static void f_2121(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2069(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2079(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2084(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2094(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2028(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_1998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1992(C_word c,C_word t0,C_word t1) C_noret;
static void f_1996(C_word c,C_word t0,C_word t1) C_noret;
static void f_1988(C_word c,C_word t0,C_word t1) C_noret;
static void f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1972(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1975(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1921(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1954(C_word c,C_word t0,C_word t1) C_noret;
static void f_1941(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1931(C_word t0,C_word t1) C_noret;
static void f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1913(C_word c,C_word t0,C_word t1) C_noret;
static void f_1909(C_word c,C_word t0,C_word t1) C_noret;
static void f_1875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1885(C_word c,C_word t0,C_word t1) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1861(C_word t0,C_word t1) C_noret;
static void f_1828(C_word c,C_word t0,C_word t1) C_noret;
static void f_1858(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1837(C_word t0,C_word t1);
static void f_1768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1772(C_word c,C_word t0,C_word t1) C_noret;
static void f_1822(C_word c,C_word t0,C_word t1) C_noret;
static void f_1775(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1810(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1790(C_word t0,C_word t1) C_noret;
static void f_1758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1766(C_word c,C_word t0,C_word t1) C_noret;
static void f_1762(C_word c,C_word t0,C_word t1) C_noret;
static void f_1746(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1746r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1750(C_word c,C_word t0,C_word t1) C_noret;
static void f_1753(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1706(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1716(C_word t0,C_word t1);
static void f_1659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1663(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1696(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
static void f_1649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1657(C_word c,C_word t0,C_word t1) C_noret;
static void f_1653(C_word c,C_word t0,C_word t1) C_noret;
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1637r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1641(C_word c,C_word t0,C_word t1) C_noret;
static void f_1644(C_word c,C_word t0,C_word t1) C_noret;
static void f_1625(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1625r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1629(C_word c,C_word t0,C_word t1) C_noret;
static void f_1632(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1610(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_1608(C_word c,C_word t0,C_word t1) C_noret;
static void f_1604(C_word c,C_word t0,C_word t1) C_noret;
static void f_1588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_1588r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_1592(C_word c,C_word t0,C_word t1) C_noret;
static void f_1595(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1558(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1586(C_word c,C_word t0,C_word t1) C_noret;
static void f_1582(C_word c,C_word t0,C_word t1) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1) C_noret;
static void f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1503(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1508(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1538(C_word c,C_word t0,C_word t1) C_noret;
static void f_1518(C_word c,C_word t0,C_word t1) C_noret;
static void f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1454(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1459(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1489(C_word c,C_word t0,C_word t1) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void f_1403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1407(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1) C_noret;
static void f_1430(C_word c,C_word t0,C_word t1) C_noret;
static void f_1340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1344(C_word c,C_word t0,C_word t1) C_noret;
static void f_1347(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1389(C_word c,C_word t0,C_word t1) C_noret;
static void f_1385(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1365(C_word t0,C_word t1) C_noret;
static void f_1350(C_word c,C_word t0,C_word t1) C_noret;
static void f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1294(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1326(C_word c,C_word t0,C_word t1) C_noret;
static void f_1309(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1248(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1252(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1257(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1270(C_word t0,C_word t1) C_noret;
static void f_1242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1212r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1200r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1176(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1176r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1161(C_word c,C_word t0,C_word t1) C_noret;
static void f_1166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1164(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1155(C_word c,C_word t0,C_word t1) C_noret;
static void f_1135(C_word c,C_word t0,C_word t1) C_noret;
static void f_1143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1138(C_word c,C_word t0,C_word t1) C_noret;
static void f_1074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1078(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1117(C_word c,C_word t0,C_word t1) C_noret;
static void f_1104(C_word c,C_word t0,C_word t1) C_noret;
static void f_1037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1041(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1046(C_word t0,C_word t1,C_word t2);
static void f_1013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1017(C_word c,C_word t0,C_word t1) C_noret;
static void f_911(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_911r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_915(C_word t0,C_word t1) C_noret;
static void C_fcall f_918(C_word t0,C_word t1) C_noret;
static void f_921(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_929(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_950(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_974(C_word t0,C_word t1);
static void f_813(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_813r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_833(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_845(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_862(C_word t0,C_word t1,C_word t2) C_noret;
static void f_758(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_758r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_774(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_779(C_word t0,C_word t1,C_word t2) C_noret;
static void f_803(C_word c,C_word t0,C_word t1) C_noret;
static void f_744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_756(C_word c,C_word t0,C_word t1) C_noret;
static void f_752(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_711(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_717(C_word t0,C_word t1,C_word t2) C_noret;
static void f_724(C_word c,C_word t0,C_word t1) C_noret;
static void f_734(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_664(C_word t0,C_word t1,C_word t2) C_noret;
static void f_709(C_word c,C_word t0,C_word t1) C_noret;
static void f_689(C_word c,C_word t0,C_word t1) C_noret;
static void f_696(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_654(C_word t0,C_word t1) C_noret;
static void f_648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_630(C_word t0);
static void f_624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

static void C_fcall trf_2475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2475(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2475(t0,t1,t2,t3,t4);}

static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2069(t0,t1,t2,t3,t4);}

static void C_fcall trf_2084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2084(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2084(t0,t1,t2);}

static void C_fcall trf_2028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2028(t0,t1,t2);}

static void C_fcall trf_2038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2038(t0,t1,t2);}

static void C_fcall trf_1915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1915(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1915(t0,t1,t2,t3);}

static void C_fcall trf_1921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1921(t0,t1,t2);}

static void C_fcall trf_1931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1931(t0,t1);}

static void C_fcall trf_1824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1824(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1824(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1861(t0,t1);}

static void C_fcall trf_1780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1780(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1780(t0,t1,t2,t3);}

static void C_fcall trf_1790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1790(t0,t1);}

static void C_fcall trf_1706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1706(t0,t1,t2);}

static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1668(t0,t1,t2,t3);}

static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

static void C_fcall trf_1610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1610(t0,t1,t2);}

static void C_fcall trf_1552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1552(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1552(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1558(t0,t1,t2);}

static void C_fcall trf_1508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1508(t0,t1,t2);}

static void C_fcall trf_1459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1459(t0,t1,t2);}

static void C_fcall trf_1412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1412(t0,t1,t2,t3);}

static void C_fcall trf_1355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1355(t0,t1,t2);}

static void C_fcall trf_1365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1365(t0,t1);}

static void C_fcall trf_1299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1299(t0,t1,t2);}

static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1248(t0,t1,t2,t3);}

static void C_fcall trf_1257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1257(t0,t1,t2);}

static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1270(t0,t1);}

static void C_fcall trf_1157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1157(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1157(t0,t1,t2,t3,t4);}

static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1131(t0,t1,t2,t3,t4);}

static void C_fcall trf_1083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1083(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1083(t0,t1,t2,t3);}

static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_915(t0,t1);}

static void C_fcall trf_918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_918(t0,t1);}

static void C_fcall trf_929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_929(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_929(t0,t1,t2,t3);}

static void C_fcall trf_950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_950(t0,t1);}

static void C_fcall trf_835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_835(t0,t1,t2,t3);}

static void C_fcall trf_862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_862(t0,t1,t2);}

static void C_fcall trf_779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_779(t0,t1,t2);}

static void C_fcall trf_711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_711(t0,t1,t2);}

static void C_fcall trf_717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_717(t0,t1,t2);}

static void C_fcall trf_664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_664(t0,t1,t2);}

static void C_fcall trf_654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_654(t0,t1);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(786)){
C_save(t1);
C_rereclaim2(786*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,107);
lf[2]=C_h_intern(&lf[2],13,"make-char-set");
lf[3]=C_h_intern(&lf[3],8,"char-set");
lf[4]=C_h_intern(&lf[4],10,"char-set:s");
lf[5]=C_h_intern(&lf[5],9,"char-set\077");
lf[7]=C_h_intern(&lf[7],13,"\003syssubstring");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_static_string(C_heaptop,32,"BASE-CS parameter not a char-set");
lf[11]=C_static_string(C_heaptop,51,"Expected final base char set -- too many parameters");
lf[12]=C_h_intern(&lf[12],11,"make-string");
lf[14]=C_static_string(C_heaptop,14,"Not a char-set");
lf[17]=C_h_intern(&lf[17],13,"char-set-copy");
lf[18]=C_h_intern(&lf[18],9,"char-set=");
lf[19]=C_h_intern(&lf[19],10,"char-set<=");
lf[20]=C_h_intern(&lf[20],13,"char-set-hash");
lf[21]=C_h_intern(&lf[21],6,"modulo");
lf[22]=C_h_intern(&lf[22],18,"char-set-contains\077");
lf[23]=C_h_intern(&lf[23],13,"char-set-size");
lf[24]=C_h_intern(&lf[24],14,"char-set-count");
lf[26]=C_h_intern(&lf[26],12,"\003sysfor-each");
lf[28]=C_h_intern(&lf[28],15,"char-set-adjoin");
lf[29]=C_h_intern(&lf[29],16,"char-set-adjoin!");
lf[30]=C_h_intern(&lf[30],15,"char-set-delete");
lf[31]=C_h_intern(&lf[31],16,"char-set-delete!");
lf[32]=C_h_intern(&lf[32],15,"char-set-cursor");
lf[34]=C_h_intern(&lf[34],16,"end-of-char-set\077");
lf[35]=C_h_intern(&lf[35],12,"char-set-ref");
lf[36]=C_h_intern(&lf[36],20,"char-set-cursor-next");
lf[37]=C_h_intern(&lf[37],17,"char-set-for-each");
lf[38]=C_h_intern(&lf[38],12,"char-set-map");
lf[39]=C_h_intern(&lf[39],13,"char-set-fold");
lf[40]=C_h_intern(&lf[40],14,"char-set-every");
lf[41]=C_h_intern(&lf[41],12,"char-set-any");
lf[43]=C_h_intern(&lf[43],15,"char-set-unfold");
lf[44]=C_h_intern(&lf[44],16,"char-set-unfold!");
lf[46]=C_h_intern(&lf[46],14,"list->char-set");
lf[47]=C_h_intern(&lf[47],15,"list->char-set!");
lf[48]=C_h_intern(&lf[48],14,"char-set->list");
lf[50]=C_h_intern(&lf[50],16,"string->char-set");
lf[51]=C_h_intern(&lf[51],17,"string->char-set!");
lf[52]=C_h_intern(&lf[52],16,"char-set->string");
lf[54]=C_h_intern(&lf[54],3,"min");
lf[55]=C_static_string(C_heaptop,96,"Requested UCS range contains unavailable characters -- this implementation only "
"supports Latin-1");
lf[56]=C_h_intern(&lf[56],19,"ucs-range->char-set");
lf[57]=C_h_intern(&lf[57],20,"ucs-range->char-set!");
lf[59]=C_h_intern(&lf[59],15,"char-set-filter");
lf[60]=C_h_intern(&lf[60],16,"char-set-filter!");
lf[61]=C_h_intern(&lf[61],10,"->char-set");
lf[62]=C_static_string(C_heaptop,30,"Not a charset, string or char.");
lf[65]=C_h_intern(&lf[65],19,"char-set-complement");
lf[66]=C_h_intern(&lf[66],20,"char-set-complement!");
lf[67]=C_h_intern(&lf[67],15,"char-set-union!");
lf[68]=C_h_intern(&lf[68],14,"char-set-union");
lf[69]=C_h_intern(&lf[69],14,"char-set:empty");
lf[70]=C_h_intern(&lf[70],22,"char-set-intersection!");
lf[71]=C_h_intern(&lf[71],21,"char-set-intersection");
lf[72]=C_h_intern(&lf[72],13,"char-set:full");
lf[73]=C_h_intern(&lf[73],20,"char-set-difference!");
lf[74]=C_h_intern(&lf[74],19,"char-set-difference");
lf[75]=C_h_intern(&lf[75],13,"char-set-xor!");
lf[76]=C_h_intern(&lf[76],12,"char-set-xor");
lf[78]=C_h_intern(&lf[78],27,"char-set-diff+intersection!");
lf[79]=C_h_intern(&lf[79],26,"char-set-diff+intersection");
lf[80]=C_h_intern(&lf[80],11,"string-copy");
lf[81]=C_h_intern(&lf[81],19,"char-set:lower-case");
lf[82]=C_h_intern(&lf[82],19,"char-set:upper-case");
lf[83]=C_h_intern(&lf[83],19,"char-set:title-case");
lf[84]=C_h_intern(&lf[84],15,"char-set:letter");
lf[85]=C_h_intern(&lf[85],14,"char-set:digit");
lf[86]=C_h_intern(&lf[86],18,"char-set:hex-digit");
lf[87]=C_h_intern(&lf[87],21,"char-set:letter+digit");
lf[88]=C_h_intern(&lf[88],20,"char-set:punctuation");
lf[89]=C_h_intern(&lf[89],15,"char-set:symbol");
lf[90]=C_h_intern(&lf[90],16,"char-set:graphic");
lf[91]=C_h_intern(&lf[91],19,"char-set:whitespace");
lf[92]=C_h_intern(&lf[92],17,"char-set:printing");
lf[93]=C_h_intern(&lf[93],14,"char-set:blank");
lf[94]=C_h_intern(&lf[94],20,"char-set:iso-control");
lf[95]=C_h_intern(&lf[95],14,"char-set:ascii");
lf[96]=C_h_intern(&lf[96],7,"\003sysmap");
tmp=C_fix(9);
C_save(tmp);
tmp=C_fix(32);
C_save(tmp);
tmp=C_fix(160);
C_save(tmp);
lf[97]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_fix(9);
C_save(tmp);
tmp=C_fix(10);
C_save(tmp);
tmp=C_fix(11);
C_save(tmp);
tmp=C_fix(12);
C_save(tmp);
tmp=C_fix(13);
C_save(tmp);
tmp=C_fix(32);
C_save(tmp);
tmp=C_fix(160);
C_save(tmp);
lf[98]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
tmp=C_fix(162);
C_save(tmp);
tmp=C_fix(163);
C_save(tmp);
tmp=C_fix(164);
C_save(tmp);
tmp=C_fix(165);
C_save(tmp);
tmp=C_fix(166);
C_save(tmp);
tmp=C_fix(167);
C_save(tmp);
tmp=C_fix(168);
C_save(tmp);
tmp=C_fix(169);
C_save(tmp);
tmp=C_fix(172);
C_save(tmp);
tmp=C_fix(174);
C_save(tmp);
tmp=C_fix(175);
C_save(tmp);
tmp=C_fix(176);
C_save(tmp);
tmp=C_fix(177);
C_save(tmp);
tmp=C_fix(180);
C_save(tmp);
tmp=C_fix(182);
C_save(tmp);
tmp=C_fix(184);
C_save(tmp);
tmp=C_fix(215);
C_save(tmp);
tmp=C_fix(247);
C_save(tmp);
lf[99]=C_h_list(18,C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(18);
lf[100]=C_static_string(C_heaptop,9,"$+<=>^`|~");
tmp=C_fix(161);
C_save(tmp);
tmp=C_fix(171);
C_save(tmp);
tmp=C_fix(173);
C_save(tmp);
tmp=C_fix(183);
C_save(tmp);
tmp=C_fix(187);
C_save(tmp);
tmp=C_fix(191);
C_save(tmp);
lf[101]=C_h_list(6,C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(6);
lf[102]=C_static_string(C_heaptop,23,"!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[103]=C_static_string(C_heaptop,22,"0123456789abcdefABCDEF");
lf[104]=C_static_string(C_heaptop,10,"0123456789");
lf[105]=C_h_intern(&lf[105],17,"register-feature!");
lf[106]=C_h_intern(&lf[106],7,"srfi-14");
C_register_lf(lf,107);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[106]);}

/* k620 */
static void f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_622,2,t0,t1);}
t2=C_mutate(&lf[0],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_624,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_630,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_636,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_642,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_648,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_654,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_664,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_711,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=lf[0];
f_624(3,t11,t10,C_fix(0));}

/* k736 in k620 */
static void f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_738,2,t0,t1);}
t2=C_mutate(&lf[15],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=lf[0];
f_624(3,t4,t3,C_fix(1));}

/* k740 in k736 in k620 */
static void f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[117],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=C_mutate(&lf[16],t1);
t3=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_744,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_758,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_813,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_911,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1013,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1037,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1074,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[25],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1131,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[27],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1157,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1176,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1188,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1200,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1212,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1224,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1230,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1236,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1242,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[33],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1248,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1290,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1340,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1403,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1450,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1499,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1552,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1588,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1600,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[45],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1610,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1625,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1637,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1649,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1659,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[49],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1706,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1746,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1768,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[53],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1824,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1875,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1905,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1915,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1968,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1984,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1998,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[63],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2028,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate(&lf[64],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2069,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2111,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2139,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2161,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2187,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2236,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2258,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2303,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2329,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2370,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2411,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[77],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2475,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2528,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2579,tmp=(C_word)a,a+=2,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t61=*((C_word*)lf[3]+1);
((C_proc2)(void*)(*((C_word*)t61+1)))(2,t61,t60);}

/* k2606 in k740 in k736 in k620 */
static void f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[69]+1));}

/* k2610 in k2606 in k740 in k736 in k620 */
static void f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[57]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[57]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[0];
f_624(3,t4,t3,C_fix(181));}

/* k2722 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[57]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k2718 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[57]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=C_mutate((C_word*)lf[83]+1,*((C_word*)lf[69]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[82]+1),*((C_word*)lf[81]+1));}

/* k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[0];
f_624(3,t4,t3,C_fix(170));}

/* k2710 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2716,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=lf[0];
f_624(3,t3,t2,C_fix(186));}

/* k2714 in k2710 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[104]);}

/* k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[103]);}

/* k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[84]+1),*((C_word*)lf[85]+1));}

/* k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2659,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[101]);}

/* k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[100]);}

/* k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2669,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[99]);}

/* k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[87]+1),*((C_word*)lf[88]+1),*((C_word*)lf[89]+1));}

/* k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[98]);}

/* k2706 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[91]+1),*((C_word*)lf[90]+1));}

/* k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[97]);}

/* k2702 in k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2686 in k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k2698 in k2686 in k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[57]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k2690 in k2686 in k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k2694 in k2690 in k2686 in k2682 in k2678 in k2674 in k2670 in k2667 in k2664 in k2660 in k2657 in k2654 in k2650 in k2646 in k2642 in k2638 in k2635 in k2630 in k2627 in k2623 in k2620 in k2617 in k2614 in k2610 in k2606 in k740 in k736 in k620 */
static void f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[95]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k740 in k736 in k620 */
static void f_2579(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2579r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2579r(t0,t1,t2,t3);}}

static void f_2579r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_711(t5,t2,lf[79]);}

/* k2602 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2581 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k2584 in k2581 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2475(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[79]);}

/* k2587 in k2584 in k2581 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2594 in k2587 in k2584 in k2581 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2598 in k2594 in k2587 in k2584 in k2581 in char-set-diff+intersection in k740 in k736 in k620 */
static void f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2528r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2528r(t0,t1,t2,t3,t4);}}

static void f_2528r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2532,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_711(t5,t2,lf[78]);}

/* k2530 in char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
f_711(t2,((C_word*)t0)[3],lf[78]);}

/* k2533 in k2530 in char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_2028(t2,t3,((C_word*)t0)[3]);}

/* a2545 in k2533 in k2530 in char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2546,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_setsubchar(((C_word*)t0)[3],t5,lf[15]));}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_setsubchar(((C_word*)t0)[2],t9,lf[15]));}}}

/* k2536 in k2533 in k2530 in char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
f_2475(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[78]);}

/* k2539 in k2536 in k2533 in k2530 in char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k740 in k736 in k620 */
static void C_fcall f_2475(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2475,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2481,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a2480 in %char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t2,((C_word*)t0)[2]);}

/* k2524 in a2480 in %char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2028(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2486 in a2480 in %char-set-diff+intersection! in k740 in k736 in k620 */
static void f_2487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2487,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_subchar(t5,t6);
t8=f_630(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_setsubchar(t10,t11,lf[15]);
t13=((C_word*)t0)[2];
t14=t2;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_setsubchar(t13,t14,lf[16]));}}}

/* char-set-xor in k740 in k736 in k620 */
static void f_2411(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2411r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2411r(t0,t1,t2);}}

static void f_2411r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
f_711(t4,t5,lf[76]);}
else{
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[69]+1));}}

/* k2464 in char-set-xor in k740 in k736 in k620 */
static void f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k2419 in char-set-xor in k740 in k736 in k620 */
static void f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2433,tmp=(C_word)a,a+=2,tmp);
f_2069(t2,t1,t3,t4,lf[76]);}

/* a2432 in k2419 in char-set-xor in k740 in k736 in k620 */
static void f_2433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2433,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=f_630(t10);
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=lf[0];
f_624(3,t14,t13,t12);}}

/* k2448 in a2432 in k2419 in char-set-xor in k740 in k736 in k620 */
static void f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2422 in k2419 in char-set-xor in k740 in k736 in k620 */
static void f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k740 in k736 in k620 */
static void f_2370(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2370r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2370r(t0,t1,t2,t3);}}

static void f_2370r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2378,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t2,lf[75]);}

/* k2376 in char-set-xor! in k740 in k736 in k620 */
static void f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2380,tmp=(C_word)a,a+=2,tmp);
f_2069(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[75]);}

/* a2379 in k2376 in char-set-xor! in k740 in k736 in k620 */
static void f_2380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2380,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=f_630(t10);
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2397,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=lf[0];
f_624(3,t14,t13,t12);}}

/* k2395 in a2379 in k2376 in char-set-xor! in k740 in k736 in k620 */
static void f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2372 in char-set-xor! in k740 in k736 in k620 */
static void f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k740 in k736 in k620 */
static void f_2329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2329r(t0,t1,t2,t3);}}

static void f_2329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2339,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_711(t5,t2,lf[74]);}
else{
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k2363 in char-set-difference in k740 in k736 in k620 */
static void f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k2337 in char-set-difference in k740 in k736 in k620 */
static void f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2347,tmp=(C_word)a,a+=2,tmp);
f_2069(t2,t1,((C_word*)t0)[2],t3,lf[74]);}

/* a2346 in k2337 in char-set-difference in k740 in k736 in k620 */
static void f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2347,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[15])));}

/* k2340 in k2337 in char-set-difference in k740 in k736 in k620 */
static void f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k740 in k736 in k620 */
static void f_2303(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2303r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2303r(t0,t1,t2,t3);}}

static void f_2303r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2311,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t2,lf[73]);}

/* k2309 in char-set-difference! in k740 in k736 in k620 */
static void f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2313,tmp=(C_word)a,a+=2,tmp);
f_2069(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[73]);}

/* a2312 in k2309 in char-set-difference! in k740 in k736 in k620 */
static void f_2313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2313,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[15])));}

/* k2305 in char-set-difference! in k740 in k736 in k620 */
static void f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k740 in k736 in k620 */
static void f_2258(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2258r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2258r(t0,t1,t2);}}

static void f_2258r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2268,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2294,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
f_711(t4,t5,lf[71]);}
else{
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[72]+1));}}

/* k2292 in char-set-intersection in k740 in k736 in k620 */
static void f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k2266 in char-set-intersection in k740 in k736 in k620 */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2280,tmp=(C_word)a,a+=2,tmp);
f_2069(t2,t1,t3,t4,lf[71]);}

/* a2279 in k2266 in char-set-intersection in k740 in k736 in k620 */
static void f_2280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2280,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[15]):C_SCHEME_UNDEFINED));}

/* k2269 in k2266 in char-set-intersection in k740 in k736 in k620 */
static void f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k740 in k736 in k620 */
static void f_2236(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2236r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2236r(t0,t1,t2,t3);}}

static void f_2236r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t2,lf[70]);}

/* k2242 in char-set-intersection! in k740 in k736 in k620 */
static void f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2246,tmp=(C_word)a,a+=2,tmp);
f_2069(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[70]);}

/* a2245 in k2242 in char-set-intersection! in k740 in k736 in k620 */
static void f_2246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2246,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[15]):C_SCHEME_UNDEFINED));}

/* k2238 in char-set-intersection! in k740 in k736 in k620 */
static void f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k740 in k736 in k620 */
static void f_2187(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2187r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2187r(t0,t1,t2);}}

static void f_2187r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2227,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
f_711(t4,t5,lf[68]);}
else{
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[69]+1));}}

/* k2225 in char-set-union in k740 in k736 in k620 */
static void f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k2195 in char-set-union in k740 in k736 in k620 */
static void f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2209,tmp=(C_word)a,a+=2,tmp);
f_2069(t2,t1,t3,t4,lf[68]);}

/* a2208 in k2195 in char-set-union in k740 in k736 in k620 */
static void f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2209,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[16])));}

/* k2198 in k2195 in char-set-union in k740 in k736 in k620 */
static void f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k740 in k736 in k620 */
static void f_2161(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2161r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2161r(t0,t1,t2,t3);}}

static void f_2161r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2165,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2169,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t2,lf[67]);}

/* k2167 in char-set-union! in k740 in k736 in k620 */
static void f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2171,tmp=(C_word)a,a+=2,tmp);
f_2069(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[67]);}

/* a2170 in k2167 in char-set-union! in k740 in k736 in k620 */
static void f_2171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2171,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[16])));}

/* k2163 in char-set-union! in k740 in k736 in k620 */
static void f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k740 in k736 in k620 */
static void f_2139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2143,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t3,t2,lf[66]);}

/* k2141 in char-set-complement! in k740 in k736 in k620 */
static void f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_2028(t2,t3,t1);}

/* a2147 in k2141 in char-set-complement! in k740 in k736 in k620 */
static void f_2148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2148,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=lf[0];
f_624(3,t6,t5,t4);}

/* k2157 in a2147 in k2141 in char-set-complement! in k740 in k736 in k620 */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2144 in k2141 in char-set-complement! in k740 in k736 in k620 */
static void f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k740 in k736 in k620 */
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_711(t3,t2,lf[65]);}

/* k2113 in char-set-complement in k740 in k736 in k620 */
static void f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2116 in k2113 in char-set-complement in k740 in k736 in k620 */
static void f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_2028(t2,t3,((C_word*)t0)[2]);}

/* a2125 in k2116 in k2113 in char-set-complement in k740 in k736 in k620 */
static void f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2126,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2137,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=lf[0];
f_624(3,t6,t5,t4);}

/* k2135 in a2125 in k2116 in k2113 in char-set-complement in k740 in k736 in k620 */
static void f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2119 in k2116 in k2113 in char-set-complement in k740 in k736 in k620 */
static void f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k740 in k736 in k620 */
static void C_fcall f_2069(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2069,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2075,a[2]=t5,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2074 in %char-set-algebra in k740 in k736 in k620 */
static void f_2075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2075,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2079,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_711(t3,t2,((C_word*)t0)[2]);}

/* k2077 in a2074 in %char-set-algebra in k740 in k736 in k620 */
static void f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2084(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2077 in a2074 in %char-set-algebra in k740 in k736 in k620 */
static void C_fcall f_2084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2084,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2094,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_630(t6);
t8=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,((C_word*)t0)[2],t2,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2092 in lp in k2077 in a2074 in %char-set-algebra in k740 in k736 in k620 */
static void f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2084(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k740 in k736 in k620 */
static void C_fcall f_2028(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2028,NULL,3,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t2,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2038(t9,t1,t5);}

/* lp in %string-iter in k740 in k736 in k620 */
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2038,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
t6=f_630(t5);
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2046 in lp in %string-iter in k740 in k736 in k620 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2038(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k740 in k736 in k620 */
static void f_1998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1998,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2003 in ->char-set in k740 in k736 in k620 */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[61],lf[62],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k740 in k736 in k620 */
static void f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1984,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
f_711(t6,t3,lf[60]);}

/* k1990 in char-set-filter! in k740 in k736 in k620 */
static void f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1996,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_711(t2,((C_word*)t0)[2],lf[60]);}

/* k1994 in k1990 in char-set-filter! in k740 in k736 in k620 */
static void f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1915(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1986 in char-set-filter! in k740 in k736 in k620 */
static void f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k740 in k736 in k620 */
static void f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1968r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1968r(t0,t1,t2,t3,t4);}}

static void f_1968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1972,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
f_664(t5,t4,*((C_word*)lf[59]+1));}

/* k1970 in char-set-filter in k740 in k736 in k620 */
static void f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1975,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_711(t3,((C_word*)t0)[2],lf[60]);}

/* k1980 in k1970 in char-set-filter in k740 in k736 in k620 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1915(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1973 in k1970 in char-set-filter in k740 in k736 in k620 */
static void f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k740 in k736 in k620 */
static void C_fcall f_1915(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1915,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1921,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1921(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k740 in k736 in k620 */
static void C_fcall f_1921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1921,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1931,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1941,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=t2;
t8=(C_word)C_subchar(t6,t7);
t9=f_630(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t5;
f_1941(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=lf[0];
f_624(3,t12,t11,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1952 in lp in %char-set-filter! in k740 in k736 in k620 */
static void f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1939 in lp in %char-set-filter! in k740 in k736 in k620 */
static void f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_1931(t4,(C_word)C_setsubchar(t2,t3,lf[16]));}
else{
t2=((C_word*)t0)[2];
f_1931(t2,C_SCHEME_UNDEFINED);}}

/* k1929 in lp in %char-set-filter! in k740 in k736 in k620 */
static void C_fcall f_1931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1921(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k740 in k736 in k620 */
static void f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1905,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1913,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
f_711(t7,t5,lf[57]);}

/* k1911 in ucs-range->char-set! in k740 in k736 in k620 */
static void f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1824(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[56]);}

/* k1907 in ucs-range->char-set! in k740 in k736 in k620 */
static void f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k740 in k736 in k620 */
static void f_1875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1875r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1875r(t0,t1,t2,t3,t4);}}

static void f_1875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_u_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1885,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_664(t9,t8,*((C_word*)lf[56]+1));}

/* k1883 in ucs-range->char-set in k740 in k736 in k620 */
static void f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
f_1824(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[56]);}

/* k1886 in k1883 in ucs-range->char-set in k740 in k736 in k620 */
static void f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k740 in k736 in k620 */
static void C_fcall f_1824(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1824,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1828,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=t2;
t10=t3;
if(C_truep((C_word)C_fixnum_lessp(t9,t10))){
t11=t3;
t12=(C_word)C_fixnum_lessp(C_fix(256),t11);
t13=t8;
f_1861(t13,(C_truep(t12)?t4:C_SCHEME_FALSE));}
else{
t11=t8;
f_1861(t11,C_SCHEME_FALSE);}}

/* k1859 in %ucs-range->char-set! in k740 in k736 in k620 */
static void C_fcall f_1861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[55],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1828(2,t2,C_SCHEME_UNDEFINED);}}

/* k1826 in %ucs-range->char-set! in k740 in k736 in k620 */
static void f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k1856 in k1826 in %ucs-range->char-set! in k740 in k736 in k620 */
static void f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1837(t3,t2));}

/* lp in k1856 in k1826 in %ucs-range->char-set! in k740 in k736 in k620 */
static C_word C_fcall f_1837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_setsubchar(t4,t5,lf[16]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set->string in k740 in k736 in k620 */
static void f_1768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1768,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t3,t2,lf[52]);}

/* k1770 in char-set->string in k740 in k736 in k620 */
static void f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1820 in k1770 in char-set->string in k740 in k736 in k620 */
static void f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1773 in k1770 in char-set->string in k740 in k736 in k620 */
static void f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1780(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1773 in k1770 in char-set->string in k740 in k736 in k620 */
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1780,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1790,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
t8=f_630(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t5;
f_1790(t10,t3);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1810,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=lf[0];
f_624(3,t11,t10,t2);}}}

/* k1808 in lp in k1773 in k1770 in char-set->string in k740 in k736 in k620 */
static void f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_1790(t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k1788 in lp in k1773 in k1770 in char-set->string in k740 in k736 in k620 */
static void C_fcall f_1790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1780(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k740 in k736 in k620 */
static void f_1758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1758,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1762,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1766,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t3,lf[51]);}

/* k1764 in string->char-set! in k740 in k736 in k620 */
static void f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1706(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1760 in string->char-set! in k740 in k736 in k620 */
static void f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k740 in k736 in k620 */
static void f_1746(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1746r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1746r(t0,t1,t2,t3);}}

static void f_1746r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_664(t4,t3,*((C_word*)lf[50]+1));}

/* k1748 in string->char-set in k740 in k736 in k620 */
static void f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1753,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1706(t2,((C_word*)t0)[2],t1);}

/* k1751 in k1748 in string->char-set in k740 in k736 in k620 */
static void f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k740 in k736 in k620 */
static void C_fcall f_1706(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1706,NULL,3,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1716(t6,t5));}

/* do296 in %string->char-set! in k740 in k736 in k620 */
static C_word C_fcall f_1716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=f_630(t4);
t6=(C_word)C_setsubchar(t3,t5,lf[16]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}}

/* char-set->list in k740 in k736 in k620 */
static void f_1659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_711(t3,t2,lf[48]);}

/* k1661 in char-set->list in k740 in k736 in k620 */
static void f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1668,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1668(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k1661 in char-set->list in k740 in k736 in k620 */
static void C_fcall f_1668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1686,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[2],t7);
t9=f_630(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1686(t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=lf[0];
f_624(3,t12,t11,t2);}}}

/* k1694 in lp in k1661 in char-set->list in k740 in k736 in k620 */
static void f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1686(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1684 in lp in k1661 in char-set->list in k740 in k736 in k620 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1668(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k740 in k736 in k620 */
static void f_1649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1649,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t3,lf[47]);}

/* k1655 in list->char-set! in k740 in k736 in k620 */
static void f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1610(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1651 in list->char-set! in k740 in k736 in k620 */
static void f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k740 in k736 in k620 */
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1637r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1637r(t0,t1,t2,t3);}}

static void f_1637r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1641,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_664(t4,t3,*((C_word*)lf[46]+1));}

/* k1639 in list->char-set in k740 in k736 in k620 */
static void f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1610(t2,((C_word*)t0)[2],t1);}

/* k1642 in k1639 in list->char-set in k740 in k736 in k620 */
static void f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k740 in k736 in k620 */
static void f_1625(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1625r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1625r(t0,t1,t2);}}

static void f_1625r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1629,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[15]);}

/* k1627 in char-set in k740 in k736 in k620 */
static void f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1632,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1610(t2,((C_word*)t0)[2],t1);}

/* k1630 in k1627 in char-set in k740 in k736 in k620 */
static void f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k740 in k736 in k620 */
static void C_fcall f_1610(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1610,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1615 in %list->char-set! in k740 in k736 in k620 */
static void f_1616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1616,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=f_630(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_setsubchar(t3,t4,lf[16]));}

/* char-set-unfold! in k740 in k736 in k620 */
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1600,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1604,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1608,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
f_711(t8,t6,lf[44]);}

/* k1606 in char-set-unfold! in k740 in k736 in k620 */
static void f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1552(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1602 in char-set-unfold! in k740 in k736 in k620 */
static void f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k740 in k736 in k620 */
static void f_1588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_1588r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1588r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_1588r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1592,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_664(t7,t6,*((C_word*)lf[43]+1));}

/* k1590 in char-set-unfold in k740 in k736 in k620 */
static void f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1595,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
f_1552(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1593 in k1590 in char-set-unfold in k740 in k736 in k620 */
static void f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k740 in k736 in k620 */
static void C_fcall f_1552(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1552,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1558,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1558(t10,t1,t6);}

/* lp in %char-set-unfold! in k740 in k736 in k620 */
static void C_fcall f_1558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1584 in lp in %char-set-unfold! in k740 in k736 in k620 */
static void f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k1580 in k1584 in lp in %char-set-unfold! in k740 in k736 in k620 */
static void f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=f_630(t1);
t3=(C_word)C_setsubchar(((C_word*)t0)[6],t2,lf[16]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1576 in k1580 in k1584 in lp in %char-set-unfold! in k740 in k736 in k620 */
static void f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1558(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k740 in k736 in k620 */
static void f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1499,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1503,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t3,lf[41]);}

/* k1501 in char-set-any in k740 in k736 in k620 */
static void f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1508(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1501 in char-set-any in k740 in k736 in k620 */
static void C_fcall f_1508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1508,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1518(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=lf[0];
f_624(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1536 in lp in k1501 in char-set-any in k740 in k736 in k620 */
static void f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1516 in lp in k1501 in char-set-any in k740 in k736 in k620 */
static void f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_1508(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k740 in k736 in k620 */
static void f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1450,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t3,lf[40]);}

/* k1452 in char-set-every in k740 in k736 in k620 */
static void f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1459(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1452 in char-set-every in k740 in k736 in k620 */
static void C_fcall f_1459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1459,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1475,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_1475(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=lf[0];
f_624(3,t11,t10,t2);}}}

/* k1487 in lp in k1452 in char-set-every in k740 in k736 in k620 */
static void f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1473 in lp in k1452 in char-set-every in k740 in k736 in k620 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1459(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k740 in k736 in k620 */
static void f_1403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1403,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1407,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_711(t5,t4,lf[39]);}

/* k1405 in char-set-fold in k740 in k736 in k620 */
static void f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1412(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k1405 in char-set-fold in k740 in k736 in k620 */
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1412,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1430,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_630(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1430(2,t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1440,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t12=lf[0];
f_624(3,t12,t11,t2);}}}

/* k1438 in lp in k1405 in char-set-fold in k740 in k736 in k620 */
static void f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1428 in lp in k1405 in char-set-fold in k740 in k736 in k620 */
static void f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k740 in k736 in k620 */
static void f_1340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1340,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1344,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t3,lf[38]);}

/* k1342 in char-set-map in k740 in k736 in k620 */
static void f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1350,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1355(t6,t2,C_fix(255));}

/* lp in k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1355,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1365,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1365(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1389,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=lf[0];
f_624(3,t11,t10,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1387 in lp in k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1383 in lp in k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_630(t1);
t3=((C_word*)t0)[3];
f_1365(t3,(C_word)C_setsubchar(((C_word*)t0)[2],t2,lf[16]));}

/* k1363 in lp in k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void C_fcall f_1365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1355(t3,((C_word*)t0)[2],t2);}

/* k1348 in k1345 in k1342 in char-set-map in k740 in k736 in k620 */
static void f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k740 in k736 in k620 */
static void f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1290,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t3,lf[37]);}

/* k1292 in char-set-for-each in k740 in k736 in k620 */
static void f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1299(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1292 in char-set-for-each in k740 in k736 in k620 */
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1299,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1309,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1309(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1326,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=lf[0];
f_624(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1324 in lp in k1292 in char-set-for-each in k740 in k736 in k620 */
static void f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1307 in lp in k1292 in char-set-for-each in k740 in k736 in k620 */
static void f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1299(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k740 in k736 in k620 */
static void C_fcall f_1248(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1252,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t5,t2,t4);}

/* k1250 in %char-set-cursor-next in k740 in k736 in k620 */
static void f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1257(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1250 in %char-set-cursor-next in k740 in k736 in k620 */
static void C_fcall f_1257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1257,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1270(t6,t4);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[2],t3);
t7=f_630(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=t5;
f_1270(t9,(C_word)C_i_not(t8));}}

/* k1268 in lp in k1250 in %char-set-cursor-next in k740 in k736 in k620 */
static void C_fcall f_1270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
f_1257(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k740 in k736 in k620 */
static void f_1242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1242,4,t0,t1,t2,t3);}
f_1248(t1,t2,t3,lf[36]);}

/* char-set-ref in k740 in k736 in k620 */
static void f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1236,4,t0,t1,t2,t3);}
t4=lf[0];
f_624(3,t4,t1,t3);}

/* end-of-char-set? in k740 in k736 in k620 */
static void f_1230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1230,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k740 in k736 in k620 */
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
f_1248(t1,t2,C_fix(256),lf[32]);}

/* char-set-delete! in k740 in k736 in k620 */
static void f_1212(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1212r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1212r(t0,t1,t2,t3);}}

static void f_1212r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1218,tmp=(C_word)a,a+=2,tmp);
f_1157(t1,t4,lf[31],t2,t3);}

/* a1217 in char-set-delete! in k740 in k736 in k620 */
static void f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1218,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[15]));}

/* char-set-delete in k740 in k736 in k620 */
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1200r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1200r(t0,t1,t2,t3);}}

static void f_1200r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1206,tmp=(C_word)a,a+=2,tmp);
f_1131(t1,t4,lf[30],t2,t3);}

/* a1205 in char-set-delete in k740 in k736 in k620 */
static void f_1206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1206,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[15]));}

/* char-set-adjoin! in k740 in k736 in k620 */
static void f_1188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1188r(t0,t1,t2,t3);}}

static void f_1188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1194,tmp=(C_word)a,a+=2,tmp);
f_1157(t1,t4,lf[29],t2,t3);}

/* a1193 in char-set-adjoin! in k740 in k736 in k620 */
static void f_1194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1194,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[16]));}

/* char-set-adjoin in k740 in k736 in k620 */
static void f_1176(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1176r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1176r(t0,t1,t2,t3);}}

static void f_1176r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1182,tmp=(C_word)a,a+=2,tmp);
f_1131(t1,t4,lf[28],t2,t3);}

/* a1181 in char-set-adjoin in k740 in k736 in k620 */
static void f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1182,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[16]));}

/* %set-char-set! in k740 in k736 in k620 */
static void C_fcall f_1157(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1157,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1161,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_711(t6,t4,t3);}

/* k1159 in %set-char-set! in k740 in k736 in k620 */
static void f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1166,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1165 in k1159 in %set-char-set! in k740 in k736 in k620 */
static void f_1166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1166,3,t0,t1,t2);}
t3=f_630(t2);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1162 in k1159 in %set-char-set! in k740 in k736 in k620 */
static void f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k740 in k736 in k620 */
static void C_fcall f_1131(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1131,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1135,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1155,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
f_711(t7,t4,t3);}

/* k1153 in %set-char-set in k740 in k736 in k620 */
static void f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k1133 in %set-char-set in k740 in k736 in k620 */
static void f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1138,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1143,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1142 in k1133 in %set-char-set in k740 in k736 in k620 */
static void f_1143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1143,3,t0,t1,t2);}
t3=f_630(t2);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1136 in k1133 in %set-char-set in k740 in k736 in k620 */
static void f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k740 in k736 in k620 */
static void f_1074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1074,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1078,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t3,lf[24]);}

/* k1076 in char-set-count in k740 in k736 in k620 */
static void f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1083(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1076 in char-set-count in k740 in k736 in k620 */
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1083,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1104,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_630(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1104(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1117,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=lf[0];
f_624(3,t12,t11,t2);}}}

/* k1115 in lp in k1076 in char-set-count in k740 in k736 in k620 */
static void f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1102 in lp in k1076 in char-set-count in k740 in k736 in k620 */
static void f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1083(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k740 in k736 in k620 */
static void f_1037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1037,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_711(t3,t2,lf[23]);}

/* k1039 in char-set-size in k740 in k736 in k620 */
static void f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1046(t2,C_fix(255),C_fix(0)));}

/* lp in k1039 in char-set-size in k740 in k736 in k620 */
static C_word C_fcall f_1046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(t2);}
else{
t4=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t1;
t6=(C_word)C_subchar(((C_word*)t0)[2],t5);
t7=f_630(t6);
t8=(C_word)C_u_fixnum_plus(t2,t7);
t10=t4;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* char-set-contains? in k740 in k736 in k620 */
static void f_1013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1013,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1017,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
f_711(t4,t2,lf[22]);}

/* k1015 in char-set-contains? in k740 in k736 in k620 */
static void f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_630(((C_word*)t0)[3]);
t3=(C_word)C_subchar(t1,t2);
t4=f_630(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}

/* char-set-hash in k740 in k736 in k620 */
static void f_911(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_911r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_911r(t0,t1,t2,t3);}}

static void f_911r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_915,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_915(t5,C_fix(4194304));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_915(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k913 in char-set-hash in k740 in k736 in k620 */
static void C_fcall f_915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_915,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_918(t7,t6);}
else{
t6=t4;
f_918(t6,C_SCHEME_UNDEFINED);}}

/* k916 in k913 in char-set-hash in k740 in k736 in k620 */
static void C_fcall f_918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_711(t2,((C_word*)t0)[2],lf[20]);}

/* k919 in k916 in k913 in char-set-hash in k740 in k736 in k620 */
static void f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=f_974(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_929,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_929(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k919 in k916 in k913 in char-set-hash in k740 in k736 in k620 */
static void C_fcall f_929(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_929,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_950,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_630(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_950(t11,t3);}
else{
t11=(C_word)C_fixnum_times(C_fix(37),t3);
t12=(C_word)C_u_fixnum_plus(t11,t2);
t13=t6;
f_950(t13,(C_word)C_u_fixnum_and(((C_word*)t0)[2],t12));}}}

/* k948 in lp in k919 in k916 in k913 in char-set-hash in k740 in k736 in k620 */
static void C_fcall f_950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_929(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k919 in k916 in k913 in char-set-hash in k740 in k736 in k620 */
static C_word C_fcall f_974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k740 in k736 in k620 */
static void f_813(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_813r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_813r(t0,t1,t2);}}

static void f_813r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_833,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t6,t4,lf[19]);}}

/* k831 in char-set<= in k740 in k736 in k620 */
static void f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_833,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_835(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k831 in char-set<= in k740 in k736 in k620 */
static void C_fcall f_835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_835,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_845,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t3);
f_711(t6,t7,lf[19]);}}

/* k843 in lp in k831 in char-set<= in k740 in k736 in k620 */
static void f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[3])[1];
f_835(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_862,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_862(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k843 in lp in k831 in char-set<= in k740 in k736 in k620 */
static void C_fcall f_862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_862,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=((C_word*)((C_word*)t0)[6])[1];
f_835(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=(C_word)C_subchar(t4,t5);
t7=f_630(t6);
t8=t2;
t9=(C_word)C_subchar(((C_word*)t0)[5],t8);
t10=f_630(t9);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,t10))){
t11=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* char-set= in k740 in k736 in k620 */
static void f_758(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_758r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_758r(t0,t1,t2);}}

static void f_758r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_774,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_711(t6,t4,lf[18]);}}

/* k772 in char-set= in k740 in k736 in k620 */
static void f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_779(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k772 in char-set= in k740 in k736 in k620 */
static void C_fcall f_779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_779,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_803,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
f_711(t5,t6,lf[18]);}}

/* k801 in lp in k772 in char-set= in k740 in k736 in k620 */
static void f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_u_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_779(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k740 in k736 in k620 */
static void f_744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_744,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
f_711(t4,t2,lf[17]);}

/* k754 in char-set-copy in k740 in k736 in k620 */
static void f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* k750 in char-set-copy in k740 in k736 in k620 */
static void f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k620 */
static void C_fcall f_711(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_711,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_717,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_717(t7,t1,t2);}

/* lp in %char-set:s/check in k620 */
static void C_fcall f_717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_717,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k722 in lp in %char-set:s/check in k620 */
static void f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_724,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[14],((C_word*)t0)[4]);}}

/* k732 in k722 in lp in %char-set:s/check in k620 */
static void f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_717(t2,((C_word*)t0)[2],t1);}

/* %default-base in k620 */
static void C_fcall f_664(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_664,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_689,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t6=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[11],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=lf[0];
f_624(3,t5,t4,C_fix(0));}}

/* k707 in %default-base in k620 */
static void f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k687 in %default-base in k620 */
static void f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_689,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_696,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[10],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k694 in k687 in %default-base in k620 */
static void f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_654(((C_word*)t0)[2],t1);}

/* %string-copy in k620 */
static void C_fcall f_654(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_654,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k620 */
static void f_648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_648,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[3]));}

/* char-set:s in k620 */
static void f_642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_642,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k620 */
static void f_636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_636,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[3],t2));}

/* %char->latin1 in k620 */
static C_word C_fcall f_630(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k620 */
static void f_624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_624,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}
/* end of file */
