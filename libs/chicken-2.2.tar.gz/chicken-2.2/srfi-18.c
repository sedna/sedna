/* Generated from srfi-18.scm by the Chicken compiler
   2005-08-24 19:38
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-18.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file srfi-18.c -explicit-use
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[164];


C_externexport void C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_251(C_word c,C_word t0,C_word t1) C_noret;
static void f_254(C_word c,C_word t0,C_word t1) C_noret;
static void f_475(C_word c,C_word t0,C_word t1) C_noret;
static void f_1542(C_word c,C_word t0,C_word t1) C_noret;
static void f_1516(C_word c,C_word t0,C_word t1) C_noret;
static void f_1526(C_word c,C_word t0,C_word t1) C_noret;
static void f_1529(C_word c,C_word t0,C_word t1) C_noret;
static void f_1532(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1511(C_word t0,C_word t1) C_noret;
static void f_1480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1501(C_word c,C_word t0,C_word t1) C_noret;
static void f_1505(C_word c,C_word t0,C_word t1) C_noret;
static void f_1443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1450(C_word c,C_word t0,C_word t1) C_noret;
static void f_1400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1357(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1357r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1365(C_word c,C_word t0,C_word t1) C_noret;
static void f_1178(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1178r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1203(C_word c,C_word t0,C_word t1) C_noret;
static void f_1329(C_word c,C_word t0,C_word t1) C_noret;
static void f_1311(C_word c,C_word t0,C_word t1) C_noret;
static void f_1289(C_word c,C_word t0,C_word t1) C_noret;
static void f_1300(C_word c,C_word t0,C_word t1) C_noret;
static void f_1218(C_word c,C_word t0,C_word t1) C_noret;
static void f_1221(C_word c,C_word t0,C_word t1) C_noret;
static void f_1321(C_word c,C_word t0,C_word t1) C_noret;
static void f_966(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_966r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_976(C_word c,C_word t0,C_word t1) C_noret;
static void f_993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1041(C_word t0,C_word t1) C_noret;
static void f_1044(C_word c,C_word t0,C_word t1) C_noret;
static void f_1151(C_word c,C_word t0,C_word t1) C_noret;
static void f_1103(C_word c,C_word t0,C_word t1) C_noret;
static void f_1109(C_word c,C_word t0,C_word t1) C_noret;
static void f_1114(C_word c,C_word t0,C_word t1) C_noret;
static void f_1136(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1017(C_word t0,C_word t1) C_noret;
static void f_1028(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_996(C_word t0,C_word t1) C_noret;
static void f_1007(C_word c,C_word t0,C_word t1) C_noret;
static void f_942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_897(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_897r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_901(C_word c,C_word t0,C_word t1) C_noret;
static void f_891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_862(C_word c,C_word t0,C_word t1) C_noret;
static void f_867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_871(C_word c,C_word t0,C_word t1) C_noret;
static void f_877(C_word c,C_word t0,C_word t1) C_noret;
static void f_882(C_word c,C_word t0,C_word t1) C_noret;
static void f_836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_830(C_word c,C_word t0,C_word t1) C_noret;
static void f_763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_801(C_word c,C_word t0,C_word t1) C_noret;
static void f_770(C_word c,C_word t0,C_word t1) C_noret;
static void f_779(C_word c,C_word t0,C_word t1) C_noret;
static void f_644(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_644r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_651(C_word c,C_word t0,C_word t1) C_noret;
static void f_665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_669(C_word c,C_word t0,C_word t1) C_noret;
static void f_675(C_word c,C_word t0,C_word t1) C_noret;
static void f_680(C_word c,C_word t0,C_word t1) C_noret;
static void f_729(C_word c,C_word t0,C_word t1) C_noret;
static void f_710(C_word c,C_word t0,C_word t1) C_noret;
static void f_623(C_word c,C_word t0,C_word t1) C_noret;
static void f_629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_638(C_word c,C_word t0,C_word t1) C_noret;
static void f_588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_618(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_592(C_word t0,C_word t1) C_noret;
static void f_595(C_word c,C_word t0,C_word t1) C_noret;
static void f_601(C_word c,C_word t0,C_word t1) C_noret;
static void f_579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_524(C_word c,C_word t0,C_word t1) C_noret;
static void f_518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_477(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_477r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_503(C_word c,C_word t0,C_word t1) C_noret;
static void f_481(C_word c,C_word t0,C_word t1) C_noret;
static void f_486(C_word c,C_word t0,C_word t1) C_noret;
static void f_490(C_word c,C_word t0,C_word t1) C_noret;
static void f_496(C_word c,C_word t0,C_word t1) C_noret;
static void f_457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_354(C_word c,C_word t0,C_word t1) C_noret;
static void f_395(C_word c,C_word t0,C_word t1) C_noret;
static void f_391(C_word c,C_word t0,C_word t1) C_noret;
static void f_357(C_word c,C_word t0,C_word t1) C_noret;
static void f_375(C_word c,C_word t0,C_word t1) C_noret;
static void f_367(C_word c,C_word t0,C_word t1) C_noret;
static void f_326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_299(C_word c,C_word t0,C_word t1) C_noret;
static void f_311(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_256(C_word t0,C_word t1,C_word t2) C_noret;
static void f_290(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1511(t0,t1);}

static void C_fcall trf_1041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1041(t0,t1);}

static void C_fcall trf_1017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1017(t0,t1);}

static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_996(t0,t1);}

static void C_fcall trf_592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_592(t0,t1);}

static void C_fcall trf_256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_256(t0,t1,t2);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(903)){
C_save(t1);
C_rereclaim2(903*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,164);
lf[0]=C_h_intern(&lf[0],8,"truncate");
lf[2]=C_h_intern(&lf[2],4,"time");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_static_string(C_heaptop,24,"invalid timeout argument");
lf[6]=C_static_lambda_info(C_heaptop,30,"(##sys#compute-time-limit tm3)");
lf[7]=C_h_intern(&lf[7],12,"current-time");
lf[8]=C_static_lambda_info(C_heaptop,14,"(current-time)");
lf[9]=C_h_intern(&lf[9],20,"srfi-18:current-time");
lf[10]=C_h_intern(&lf[10],13,"time->seconds");
lf[11]=C_static_lambda_info(C_heaptop,19,"(time->seconds tm7)");
lf[12]=C_h_intern(&lf[12],13,"seconds->time");
lf[13]=C_h_intern(&lf[13],19,"\003sysflonum-fraction");
lf[14]=C_h_intern(&lf[14],18,"\003sysexact->inexact");
lf[15]=C_h_intern(&lf[15],3,"max");
lf[16]=C_static_lambda_info(C_heaptop,18,"(seconds->time n9)");
lf[17]=C_h_intern(&lf[17],5,"time\077");
lf[18]=C_static_lambda_info(C_heaptop,11,"(time\077 x14)");
lf[19]=C_h_intern(&lf[19],13,"srfi-18:time\077");
lf[20]=C_h_intern(&lf[20],5,"raise");
lf[21]=C_h_intern(&lf[21],10,"\003syssignal");
lf[22]=C_h_intern(&lf[22],23,"join-timeout-exception\077");
lf[23]=C_h_intern(&lf[23],9,"condition");
lf[24]=C_h_intern(&lf[24],22,"join-timeout-exception");
lf[25]=C_static_lambda_info(C_heaptop,29,"(join-timeout-exception\077 x15)");
lf[26]=C_h_intern(&lf[26],26,"abandoned-mutex-exception\077");
lf[27]=C_h_intern(&lf[27],25,"abandoned-mutex-exception");
lf[28]=C_static_lambda_info(C_heaptop,32,"(abandoned-mutex-exception\077 x16)");
lf[29]=C_h_intern(&lf[29],28,"terminated-thread-exception\077");
lf[30]=C_h_intern(&lf[30],27,"terminated-thread-exception");
lf[31]=C_static_lambda_info(C_heaptop,34,"(terminated-thread-exception\077 x17)");
lf[32]=C_h_intern(&lf[32],19,"uncaught-exception\077");
lf[33]=C_h_intern(&lf[33],18,"uncaught-exception");
lf[34]=C_static_lambda_info(C_heaptop,25,"(uncaught-exception\077 x18)");
lf[35]=C_h_intern(&lf[35],25,"uncaught-exception-reason");
lf[36]=C_h_intern(&lf[36],6,"gensym");
lf[37]=C_h_intern(&lf[37],11,"make-thread");
lf[38]=C_h_intern(&lf[38],12,"\003sysschedule");
lf[39]=C_h_intern(&lf[39],16,"\003systhread-kill!");
lf[40]=C_h_intern(&lf[40],4,"dead");
lf[41]=C_static_lambda_info(C_heaptop,6,"(a485)");
lf[42]=C_h_intern(&lf[42],18,"\003syscurrent-thread");
lf[43]=C_h_intern(&lf[43],15,"\003sysmake-thread");
lf[44]=C_h_intern(&lf[44],7,"created");
lf[45]=C_h_intern(&lf[45],6,"thread");
lf[46]=C_static_lambda_info(C_heaptop,30,"(make-thread thunk20 . name21)");
lf[47]=C_h_intern(&lf[47],7,"thread\077");
lf[48]=C_static_lambda_info(C_heaptop,13,"(thread\077 x27)");
lf[49]=C_h_intern(&lf[49],14,"current-thread");
lf[50]=C_static_lambda_info(C_heaptop,16,"(current-thread)");
lf[51]=C_h_intern(&lf[51],12,"thread-state");
lf[52]=C_static_lambda_info(C_heaptop,23,"(thread-state thread28)");
lf[53]=C_h_intern(&lf[53],15,"thread-specific");
lf[54]=C_static_lambda_info(C_heaptop,26,"(thread-specific thread30)");
lf[55]=C_h_intern(&lf[55],20,"thread-specific-set!");
lf[56]=C_static_lambda_info(C_heaptop,35,"(thread-specific-set! thread32 x33)");
lf[57]=C_h_intern(&lf[57],14,"thread-quantum");
lf[58]=C_static_lambda_info(C_heaptop,25,"(thread-quantum thread35)");
lf[59]=C_h_intern(&lf[59],19,"thread-quantum-set!");
lf[60]=C_static_lambda_info(C_heaptop,34,"(thread-quantum-set! thread37 q38)");
lf[61]=C_h_intern(&lf[61],11,"thread-name");
lf[62]=C_static_lambda_info(C_heaptop,17,"(thread-name x41)");
lf[63]=C_h_intern(&lf[63],13,"thread-start!");
lf[64]=C_h_intern(&lf[64],5,"ready");
lf[65]=C_h_intern(&lf[65],22,"\003sysadd-to-ready-queue");
lf[66]=C_h_intern(&lf[66],9,"\003syserror");
lf[67]=C_static_string(C_heaptop,39,"thread can not be started a second time");
lf[68]=C_static_lambda_info(C_heaptop,24,"(thread-start! thread44)");
lf[69]=C_h_intern(&lf[69],13,"thread-yield!");
lf[70]=C_static_lambda_info(C_heaptop,6,"(a637)");
lf[71]=C_static_lambda_info(C_heaptop,15,"(a628 return49)");
lf[72]=C_static_lambda_info(C_heaptop,15,"(thread-yield!)");
lf[73]=C_h_intern(&lf[73],12,"thread-join!");
lf[74]=C_h_intern(&lf[74],10,"terminated");
lf[75]=C_h_intern(&lf[75],6,"reason");
tmp=C_intern(C_heaptop,18,"uncaught-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[76]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,22,"join-timeout-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[77]=C_h_pair(C_restore,tmp);
lf[78]=C_static_lambda_info(C_heaptop,6,"(a679)");
lf[79]=C_h_intern(&lf[79],33,"\003systhread-block-for-termination!");
lf[80]=C_h_intern(&lf[80],29,"\003systhread-block-for-timeout!");
lf[81]=C_static_lambda_info(C_heaptop,15,"(a664 return58)");
lf[82]=C_static_lambda_info(C_heaptop,35,"(thread-join! thread52 . timeout53)");
lf[83]=C_h_intern(&lf[83],17,"thread-terminate!");
tmp=C_intern(C_heaptop,27,"terminated-thread-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[84]=C_h_pair(C_restore,tmp);
lf[85]=C_h_intern(&lf[85],21,"\003sysprimordial-thread");
lf[86]=C_h_intern(&lf[86],16,"\003sysexit-handler");
lf[87]=C_static_lambda_info(C_heaptop,28,"(thread-terminate! thread66)");
lf[88]=C_h_intern(&lf[88],15,"thread-suspend!");
lf[89]=C_h_intern(&lf[89],9,"suspended");
lf[90]=C_static_lambda_info(C_heaptop,6,"(a829)");
lf[91]=C_static_lambda_info(C_heaptop,15,"(a820 return73)");
lf[92]=C_static_lambda_info(C_heaptop,26,"(thread-suspend! thread72)");
lf[93]=C_h_intern(&lf[93],14,"thread-resume!");
lf[94]=C_static_lambda_info(C_heaptop,25,"(thread-resume! thread77)");
lf[95]=C_h_intern(&lf[95],13,"thread-sleep!");
lf[96]=C_static_lambda_info(C_heaptop,6,"(a881)");
lf[97]=C_static_lambda_info(C_heaptop,15,"(a866 return81)");
lf[98]=C_static_string(C_heaptop,24,"invalid timeout argument");
lf[99]=C_static_lambda_info(C_heaptop,20,"(thread-sleep! tm80)");
lf[100]=C_h_intern(&lf[100],6,"mutex\077");
lf[101]=C_h_intern(&lf[101],5,"mutex");
lf[102]=C_static_lambda_info(C_heaptop,12,"(mutex\077 x87)");
lf[103]=C_h_intern(&lf[103],10,"make-mutex");
lf[104]=C_h_intern(&lf[104],14,"\003sysmake-mutex");
lf[105]=C_static_lambda_info(C_heaptop,19,"(make-mutex . id89)");
lf[106]=C_h_intern(&lf[106],10,"mutex-name");
lf[107]=C_static_lambda_info(C_heaptop,16,"(mutex-name x92)");
lf[108]=C_h_intern(&lf[108],14,"mutex-specific");
lf[109]=C_static_lambda_info(C_heaptop,24,"(mutex-specific mutex94)");
lf[110]=C_h_intern(&lf[110],19,"mutex-specific-set!");
lf[111]=C_static_lambda_info(C_heaptop,33,"(mutex-specific-set! mutex96 x97)");
lf[112]=C_h_intern(&lf[112],11,"mutex-state");
lf[113]=C_h_intern(&lf[113],9,"not-owned");
lf[114]=C_h_intern(&lf[114],9,"abandoned");
lf[115]=C_h_intern(&lf[115],13,"not-abandoned");
lf[116]=C_static_lambda_info(C_heaptop,21,"(mutex-state mutex99)");
lf[117]=C_h_intern(&lf[117],11,"mutex-lock!");
lf[118]=C_h_intern(&lf[118],10,"\003sysappend");
lf[119]=C_static_lambda_info(C_heaptop,8,"(switch)");
tmp=C_intern(C_heaptop,25,"abandoned-mutex-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[120]=C_h_pair(C_restore,tmp);
lf[121]=C_static_lambda_info(C_heaptop,7,"(check)");
lf[122]=C_h_intern(&lf[122],8,"\003sysdelq");
lf[123]=C_static_lambda_info(C_heaptop,7,"(a1113)");
lf[124]=C_h_intern(&lf[124],8,"sleeping");
lf[125]=C_static_lambda_info(C_heaptop,7,"(a1150)");
lf[126]=C_static_lambda_info(C_heaptop,16,"(a992 return110)");
lf[127]=C_static_lambda_info(C_heaptop,36,"(mutex-lock! mutex103 . ms-and-t104)");
lf[128]=C_h_intern(&lf[128],13,"mutex-unlock!");
lf[129]=C_h_intern(&lf[129],18,"condition-variable");
lf[130]=C_static_lambda_info(C_heaptop,7,"(a1320)");
lf[131]=C_h_intern(&lf[131],7,"blocked");
lf[132]=C_static_lambda_info(C_heaptop,7,"(a1288)");
lf[133]=C_static_lambda_info(C_heaptop,17,"(a1195 return143)");
lf[134]=C_static_lambda_info(C_heaptop,41,"(mutex-unlock! mutex138 . cvar-and-to139)");
lf[135]=C_h_intern(&lf[135],23,"make-condition-variable");
lf[136]=C_static_lambda_info(C_heaptop,35,"(make-condition-variable . name166)");
lf[137]=C_h_intern(&lf[137],19,"condition-variable\077");
lf[138]=C_static_lambda_info(C_heaptop,26,"(condition-variable\077 x167)");
lf[139]=C_h_intern(&lf[139],27,"condition-variable-specific");
lf[140]=C_static_lambda_info(C_heaptop,35,"(condition-variable-specific cv168)");
lf[141]=C_h_intern(&lf[141],32,"condition-variable-specific-set!");
lf[142]=C_static_lambda_info(C_heaptop,45,"(condition-variable-specific-set! cv170 x171)");
lf[143]=C_h_intern(&lf[143],26,"condition-variable-signal!");
lf[144]=C_h_intern(&lf[144],25,"\003systhread-basic-unblock!");
lf[145]=C_static_lambda_info(C_heaptop,36,"(condition-variable-signal! cvar173)");
lf[146]=C_h_intern(&lf[146],29,"condition-variable-broadcast!");
lf[147]=C_static_lambda_info(C_heaptop,13,"(a1454 ti182)");
lf[148]=C_h_intern(&lf[148],12,"\003sysfor-each");
lf[149]=C_static_lambda_info(C_heaptop,39,"(condition-variable-broadcast! cvar181)");
lf[150]=C_h_intern(&lf[150],22,"thread-deliver-signal!");
lf[151]=C_static_lambda_info(C_heaptop,7,"(a1500)");
lf[152]=C_static_lambda_info(C_heaptop,41,"(thread-deliver-signal! thread188 exn189)");
lf[153]=C_h_intern(&lf[153],4,"msvc");
lf[154]=C_h_intern(&lf[154],20,"\003sysread-prompt-hook");
lf[155]=C_h_intern(&lf[155],25,"\003systhread-block-for-i/o!");
lf[156]=C_h_intern(&lf[156],13,"\003systty-port\077");
lf[157]=C_h_intern(&lf[157],18,"\003sysstandard-input");
lf[158]=C_static_lambda_info(C_heaptop,24,"(##sys#read-prompt-hook)");
lf[159]=C_h_intern(&lf[159],14,"build-platform");
lf[160]=C_h_intern(&lf[160],27,"condition-property-accessor");
lf[161]=C_h_intern(&lf[161],17,"register-feature!");
lf[162]=C_h_intern(&lf[162],7,"srfi-18");
lf[163]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,164);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_251,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k249 */
static void f_251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[162]);}

/* k252 in k249 */
static void f_254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_254,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_256,a[2]=t2,a[3]=lf[6],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_299,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[9]+1,*((C_word*)lf[7]+1));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_326,a[2]=lf[11],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=lf[18],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[19]+1,*((C_word*)lf[17]+1));
t10=C_mutate((C_word*)lf[20]+1,*((C_word*)lf[21]+1));
t11=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=lf[28],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=lf[31],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_457,a[2]=lf[34],tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[33],lf[75]);}

/* k473 in k252 in k249 */
static void f_475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_475,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1,t1);
t3=*((C_word*)lf[36]+1);
t4=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t3,a[3]=lf[46],tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=lf[48],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_524,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_527,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_536,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_545,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_554,a[2]=lf[58],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_563,a[2]=lf[60],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=lf[62],tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[37]+1);
t14=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_588,a[2]=t13,a[3]=lf[68],tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=lf[72],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_644,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_763,a[2]=lf[87],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_803,a[2]=lf[92],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_836,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_891,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t22=*((C_word*)lf[36]+1);
t23=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_897,a[2]=t22,a[3]=lf[105],tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_915,a[2]=lf[107],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_924,a[2]=lf[109],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_933,a[2]=lf[111],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=lf[116],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=lf[134],tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[36]+1);
t31=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1357,a[2]=t30,a[3]=lf[136],tmp=(C_word)a,a+=4,tmp));
t32=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=lf[138],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=lf[140],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=lf[142],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=lf[145],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=lf[149],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1480,a[2]=lf[152],tmp=(C_word)a,a+=3,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
t40=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t40))(2,t40,t39);}

/* k1540 in k473 in k252 in k249 */
static void f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_1511(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[154]+1);
t4=*((C_word*)lf[69]+1);
t5=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1516,a[2]=t3,a[3]=t4,a[4]=lf[158],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t0)[2];
f_1511(t6,t5);}}

/* ##sys#read-prompt-hook in k1540 in k473 in k252 in k249 */
static void f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_1526(2,t4,t2);}
else{
t4=*((C_word*)lf[156]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[157]+1));}}

/* k1524 in ##sys#read-prompt-hook in k1540 in k473 in k252 in k249 */
static void f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1526,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1527 in k1524 in ##sys#read-prompt-hook in k1540 in k473 in k252 in k249 */
static void f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[42]+1),C_fix(0),C_SCHEME_TRUE);}

/* k1530 in k1527 in k1524 in ##sys#read-prompt-hook in k1540 in k473 in k252 in k249 */
static void f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1509 in k473 in k252 in k249 */
static void C_fcall f_1511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* thread-deliver-signal! in k473 in k252 in k249 */
static void f_1480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1480,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[45],lf[150]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[42]+1));
if(C_truep(t5)){
t6=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=t3,a[3]=t6,a[4]=lf[151],tmp=(C_word)a,a+=5,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t2,C_fix(1),t7));}}

/* a1500 in thread-deliver-signal! in k473 in k252 in k249 */
static void f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1503 in a1500 in thread-deliver-signal! in k473 in k252 in k249 */
static void f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k473 in k252 in k249 */
static void f_1443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1443,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[129],lf[146]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=lf[147],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(2));
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a1454 in condition-variable-broadcast! in k473 in k252 in k249 */
static void f_1455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1455,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[131]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[124]));
if(C_truep(t5)){
t6=*((C_word*)lf[144]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1448 in condition-variable-broadcast! in k473 in k252 in k249 */
static void f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k473 in k252 in k249 */
static void f_1400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1400,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[129],lf[143]);
t4=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_i_setslot(t2,C_fix(2),t7);
t9=(C_word)C_eqp(t6,lf[131]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[124]));
if(C_truep(t10)){
t11=*((C_word*)lf[144]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k473 in k252 in k249 */
static void f_1391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1391,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[129],lf[141]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k473 in k252 in k249 */
static void f_1382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1382,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[129],lf[139]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k473 in k252 in k249 */
static void f_1376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1376,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[129]));}

/* make-condition-variable in k473 in k252 in k249 */
static void f_1357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1357r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1357r(t0,t1,t2);}}

static void f_1357r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1365(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[129]);}}

/* k1363 in make-condition-variable in k473 in k252 in k249 */
static void f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[129],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k473 in k252 in k249 */
static void f_1178(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1178r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1178r(t0,t1,t2,t3);}}

static void f_1178r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_structure_2(t2,lf[101],lf[128]);
t5=*((C_word*)lf[42]+1);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t3);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t11=(C_truep(t7)?(C_word)C_i_check_structure_2(t7,lf[129],lf[128]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1196,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,a[6]=lf[133],tmp=(C_word)a,a+=7,tmp);
C_call_cc(3,0,t1,t12);}

/* a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1196,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=lf[1];
f_256(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1203(2,t5,C_SCHEME_FALSE);}}

/* k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1329,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[7],a[3]=lf[130],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1311,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t9=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1218(2,t6,C_SCHEME_UNDEFINED);}}

/* k1309 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=lf[132],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
t5=*((C_word*)lf[80]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1218(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[124]));}}

/* a1288 in k1309 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1300,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1298 in a1288 in k1309 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1216 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1221(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_eqp(t4,lf[131]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[124]));
if(C_truep(t8)){
t9=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t10=(C_word)C_slot(t3,C_fix(8));
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t10);
t12=(C_word)C_i_setslot(t3,C_fix(8),t11);
t13=(C_word)C_eqp(t4,lf[124]);
if(C_truep(t13)){
t14=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t2,t3);}
else{
t14=t2;
f_1221(2,t14,C_SCHEME_UNDEFINED);}}
else{
t9=t2;
f_1221(2,t9,C_SCHEME_UNDEFINED);}}}

/* k1219 in k1216 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1320 in k1327 in k1201 in a1195 in mutex-unlock! in k473 in k252 in k249 */
static void f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k473 in k252 in k249 */
static void f_966(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_966r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_966r(t0,t1,t2,t3);}}

static void f_966r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[101],lf[117]);
t5=(C_word)C_notvemptyp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_976,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_vector_ref(t3,C_fix(0));
t8=lf[1];
f_256(t8,t6,t7);}
else{
t7=t6;
f_976(2,t7,C_SCHEME_FALSE);}}

/* k974 in mutex-lock! in k473 in k252 in k249 */
static void f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?(C_word)C_i_check_structure_2(t4,lf[45],lf[117]):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_993,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=lf[126],tmp=(C_word)a,a+=8,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_993,3,t0,t1,t2);}
t3=*((C_word*)lf[42]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_996,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[119],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1017,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=lf[121],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=t5;
f_1017(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[124]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1151,a[2]=t2,a[3]=lf[125],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=t4;
f_996(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1041,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_1041(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[74],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[40],t9));
if(C_truep(t11)){
t12=t6;
f_1041(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_1041(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k1039 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void C_fcall f_1041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1041,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
f_1017(t3,t2);}

/* k1042 in k1039 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1150 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* k1101 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[123],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[80]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k1107 in k1101 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_996(t2,((C_word*)t0)[2]);}

/* a1113 in k1101 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1136,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1134 in a1113 in k1101 in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=(C_word)C_slot(*((C_word*)lf[42]+1),C_fix(8));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_i_setslot(*((C_word*)lf[42]+1),C_fix(8),t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}

/* check in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void C_fcall f_1017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1017,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1028,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[23],lf[120],C_SCHEME_END_OF_LIST);
t4=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1026 in check in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void C_fcall f_996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1007,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1005 in switch in a992 in k974 in mutex-lock! in k473 in k252 in k249 */
static void f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k473 in k252 in k249 */
static void f_942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_942,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[101],lf[112]);
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[113]));}
else{
t4=(C_word)C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[114]:lf[115]));}}

/* mutex-specific-set! in k473 in k252 in k249 */
static void f_933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_933,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[101],lf[110]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k473 in k252 in k249 */
static void f_924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_924,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[101],lf[108]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k473 in k252 in k249 */
static void f_915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_915,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[101],lf[106]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k473 in k252 in k249 */
static void f_897(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_897r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_897r(t0,t1,t2);}}

static void f_897r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_901(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[101]);}}

/* k899 in make-mutex in k473 in k252 in k249 */
static void f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[42]+1));}

/* mutex? in k473 in k252 in k249 */
static void f_891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_891,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[101]));}

/* thread-sleep! in k473 in k252 in k249 */
static void f_858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_862,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_862(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[4],lf[95],lf[98],t2);}}

/* k860 in thread-sleep! in k473 in k252 in k249 */
static void f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[3],a[3]=lf[97],tmp=(C_word)a,a+=4,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t2);}

/* a866 in k860 in thread-sleep! in k473 in k252 in k249 */
static void f_867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_867,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_871,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[1];
f_256(t4,t3,((C_word*)t0)[2]);}

/* k869 in a866 in k860 in thread-sleep! in k473 in k252 in k249 */
static void f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=*((C_word*)lf[42]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[3],a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(t2,C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[80]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t1);}

/* k875 in k869 in a866 in k860 in thread-sleep! in k473 in k252 in k249 */
static void f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a881 in k869 in a866 in k860 in thread-sleep! in k473 in k252 in k249 */
static void f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k473 in k252 in k249 */
static void f_836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_836,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[93]);
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_eqp(t4,lf[89]);
if(C_truep(t5)){
t6=(C_word)C_i_setslot(t2,C_fix(3),lf[64]);
t7=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k473 in k252 in k249 */
static void f_803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_803,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[88]);
t4=(C_word)C_i_setslot(t2,C_fix(3),lf[89]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[42]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_821,a[2]=t2,a[3]=lf[91],tmp=(C_word)a,a+=4,tmp);
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a820 in thread-suspend! in k473 in k252 in k249 */
static void f_821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_830,a[2]=t2,a[3]=lf[90],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
t5=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a829 in a820 in thread-suspend! in k473 in k252 in k249 */
static void f_830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_830,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k473 in k252 in k249 */
static void f_763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_763,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[83]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_770,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[85]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[86]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=t4;
f_770(2,t6,C_SCHEME_UNDEFINED);}}

/* k799 in thread-terminate! in k473 in k252 in k249 */
static void f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k768 in thread-terminate! in k473 in k252 in k249 */
static void f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_UNDEFINED);
t3=(C_word)C_a_i_record(&a,3,lf[23],lf[84],C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[39]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],lf[74]);}

/* k777 in k768 in thread-terminate! in k473 in k252 in k249 */
static void f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[42]+1));
if(C_truep(t2)){
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k473 in k252 in k249 */
static void f_644(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_644r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_644r(t0,t1,t2,t3);}}

static void f_644r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[45],lf[73]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_651,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=lf[1];
f_256(t7,t5,t6);}
else{
t6=t5;
f_651(2,t6,C_SCHEME_FALSE);}}

/* k649 in thread-join! in k473 in k252 in k249 */
static void f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_665,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=lf[81],tmp=(C_word)a,a+=7,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_665,3,t0,t1,t2);}
t3=*((C_word*)lf[42]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_669,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=*((C_word*)lf[80]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_669(2,t5,C_SCHEME_UNDEFINED);}}

/* k667 in a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_680,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[78],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[79]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k673 in k667 in a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a679 in k667 in a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_680,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_eqp(t2,lf[40]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(C_word)C_eqp(t2,lf[74]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[75],t6);
t8=(C_word)C_a_i_record(&a,3,lf[23],lf[76],t7);
t9=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_729,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_729(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[23],lf[77],C_SCHEME_END_OF_LIST);
t7=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k727 in a679 in k667 in a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k708 in a679 in k667 in a664 in k649 in thread-join! in k473 in k252 in k249 */
static void f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* thread-yield! in k473 in k252 in k249 */
static void f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_629,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp);
C_call_cc(3,0,t1,t2);}

/* a628 in thread-yield! in k473 in k252 in k249 */
static void f_629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_629,3,t0,t1,t2);}
t3=*((C_word*)lf[42]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_638,a[2]=t2,a[3]=lf[70],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a637 in a628 in thread-yield! in k473 in k252 in k249 */
static void f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_638,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-start! in k473 in k252 in k249 */
static void f_588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_588,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_592,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_618,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_592(t5,(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[45],lf[63]));}}

/* k616 in thread-start! in k473 in k252 in k249 */
static void f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_592(t3,t2);}

/* k590 in thread-start! in k473 in k252 in k249 */
static void C_fcall f_592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_592,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[44],t3);
if(C_truep(t4)){
t5=t2;
f_595(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[63],lf[67],((C_word*)((C_word*)t0)[3])[1]);}}

/* k593 in k590 in thread-start! in k473 in k252 in k249 */
static void f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_595,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[64]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k599 in k593 in k590 in thread-start! in k473 in k252 in k249 */
static void f_601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k473 in k252 in k249 */
static void f_579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_579,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[61]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k473 in k252 in k249 */
static void f_563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_563,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[45],lf[59]);
t5=(C_word)C_i_check_exact_2(t3,lf[59]);
t6=(C_word)C_i_fixnum_max(t3,C_fix(10));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_i_slot(t2,C_fix(9),t6));}

/* thread-quantum in k473 in k252 in k249 */
static void f_554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_554,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[57]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k473 in k252 in k249 */
static void f_545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_545,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[45],lf[55]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k473 in k252 in k249 */
static void f_536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_536,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[53]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k473 in k252 in k249 */
static void f_527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_527,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[51]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k473 in k252 in k249 */
static void f_524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_524,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[42]+1));}

/* thread? in k473 in k252 in k249 */
static void f_518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_518,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* make-thread in k473 in k252 in k249 */
static void f_477(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_477r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_477r(t0,t1,t2,t3);}}

static void f_477r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_481,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_503(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[45]);}}

/* k501 in make-thread in k473 in k252 in k249 */
static void f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[42]+1),C_fix(9));
t3=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[44],t1,t2);}

/* k479 in make-thread in k473 in k252 in k249 */
static void f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[41],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a485 in k479 in make-thread in k473 in k252 in k249 */
static void f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_490,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k488 in a485 in k479 in make-thread in k473 in k252 in k249 */
static void f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_490,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[39]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[40]);}

/* k494 in k488 in a485 in k479 in make-thread in k473 in k252 in k249 */
static void f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k252 in k249 */
static void f_457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_457,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[23]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[33],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k252 in k249 */
static void f_441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_441,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[23]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[30],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k252 in k249 */
static void f_425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_425,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[23]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k252 in k249 */
static void f_409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_409,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[23]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[24],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k252 in k249 */
static void f_401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_401,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[2]));}

/* seconds->time in k252 in k249 */
static void f_347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_347,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[12]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
t6=*((C_word*)lf[15]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_fix(0),t5);}

/* k352 in seconds->time in k252 in k249 */
static void f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_357,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k393 in k352 in seconds->time in k252 in k249 */
static void f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k389 in k352 in seconds->time in k252 in k249 */
static void f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
t3=*((C_word*)lf[0]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k355 in k352 in seconds->time in k252 in k249 */
static void f_357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
t5=*((C_word*)lf[0]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k373 in k355 in k352 in seconds->time in k252 in k249 */
static void f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_367,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[0]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k365 in k373 in k355 in k352 in seconds->time in k252 in k249 */
static void f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_367,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],((C_word*)t0)[2],t1,t2));}

/* time->seconds in k252 in k249 */
static void f_326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_326,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[2],lf[10]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_a_i_divide(&a,2,t5,C_fix(1000));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_plus(&a,2,t4,t6));}

/* current-time in k252 in k249 */
static void f_299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_299,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
t9=*((C_word*)lf[0]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t5,t8);}

/* k309 in current-time in k252 in k249 */
static void f_311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_311,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k252 in k249 */
static void C_fcall f_256(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_256,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_290,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[4],lf[5],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k288 in ##sys#compute-time-limit in k252 in k249 */
static void f_290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}
/* end of file */
