/* Generated from extras.scm by the Chicken compiler
   2005-09-24 22:15
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: extras.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file extras.c -explicit-use
   unit: extras
*/

#include "chicken.h"

#define C_hashptr(x)   C_fix(x & C_MOST_POSITIVE_FIXNUM)
#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

#ifdef _WIN32
# define FGETS_INTO_BUFFER  0
static C_word fgets_into_buffer(C_word str, C_word port, C_word size) { return 0; }
#else
# define FGETS_INTO_BUFFER  1

static C_word fgets_into_buffer(C_word str, C_word port, C_word size)
{
  int len, n = C_unfix(size);
  char *buf = C_c_string(str);
  C_FILEPTR fp = C_port_file(port);

  if(C_fgets(buf, n, fp) == NULL) return C_fix(0);

  len = C_strlen(buf);

  if(len >= n - 1 && buf[ len - 1 ] != '\n') return C_SCHEME_FALSE;

  return C_fix(len);
}
#endif


static C_TLS C_word lf[533];


C_externexport void C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1441(C_word c,C_word t0,C_word t1) C_noret;
static void f_4737(C_word c,C_word t0,C_word t1) C_noret;
static void f_6007(C_word c,C_word t0,C_word t1) C_noret;
static void f_8079(C_word c,C_word t0,C_word t1) C_noret;
static void f_8339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8358(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8368(C_word c,C_word t0,C_word t1) C_noret;
static void f_8350(C_word c,C_word t0,C_word t1) C_noret;
static void f_8330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8304(C_word c,C_word t0,C_word t1) C_noret;
static void f_8262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8272(C_word t0,C_word t1) C_noret;
static void f_8241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8251(C_word c,C_word t0,C_word t1) C_noret;
static void f_8220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8230(C_word c,C_word t0,C_word t1) C_noret;
static void f_8207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8195(C_word c,C_word t0,C_word t1) C_noret;
static void f_8133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_8148(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8164(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8185(C_word c,C_word t0,C_word t1) C_noret;
static void f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8096(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8106(C_word c,C_word t0,C_word t1) C_noret;
static void f_8013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8028(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7925(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7925r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7929(C_word c,C_word t0,C_word t1) C_noret;
static void f_7934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7932(C_word c,C_word t0,C_word t1) C_noret;
static void f_7852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7867(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7799(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7822(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7835(C_word c,C_word t0,C_word t1) C_noret;
static void f_7809(C_word c,C_word t0,C_word t1) C_noret;
static void f_7555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7574(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7662(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7665(C_word t0,C_word t1) C_noret;
static void C_fcall f_7591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7610(C_word t0,C_word t1) C_noret;
static void f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7552(C_word c,C_word t0,C_word t1) C_noret;
static void f_7549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_7540(C_word c,C_word t0,C_word t1) C_noret;
static void f_7321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_7330(C_word t0,C_word t1) C_noret;
static void f_7346(C_word c,C_word t0,C_word t1) C_noret;
static void f_7524(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7454(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7488(C_word c,C_word t0,C_word t1) C_noret;
static void f_7495(C_word c,C_word t0,C_word t1) C_noret;
static void f_7479(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7393(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7434(C_word c,C_word t0,C_word t1) C_noret;
static void f_7418(C_word c,C_word t0,C_word t1) C_noret;
static void f_7371(C_word c,C_word t0,C_word t1) C_noret;
static void f_7358(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7714(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7753(C_word c,C_word t0,C_word t1) C_noret;
static void f_7724(C_word c,C_word t0,C_word t1) C_noret;
static void f_7361(C_word c,C_word t0,C_word t1) C_noret;
static void f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7298(C_word t0,C_word t1) C_noret;
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7286(C_word c,C_word t0,C_word t1) C_noret;
static void f_7259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7265(C_word c,C_word t0,C_word t1) C_noret;
static void f_7133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_7133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_7146(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7228(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7167(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7249(C_word c,C_word t0,C_word t1) C_noret;
static void f_7124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7095(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7095r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7099(C_word c,C_word t0,C_word t1) C_noret;
static void f_7066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7070(C_word c,C_word t0,C_word t1) C_noret;
static void f_7034(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7034r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7038(C_word c,C_word t0,C_word t1) C_noret;
static void f_6802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7032(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7002(C_word c,C_word t0,C_word t1) C_noret;
static void f_6945(C_word c,C_word t0,C_word t1) C_noret;
static void f_6932(C_word c,C_word t0,C_word t1) C_noret;
static void f_6924(C_word c,C_word t0,C_word t1) C_noret;
static void f_6903(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6815(C_word t0,C_word t1) C_noret;
static void f_6793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6702(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6770(C_word c,C_word t0,C_word t1) C_noret;
static void f_6743(C_word c,C_word t0,C_word t1) C_noret;
static void f_6602(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6602r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_6626(C_word t0,C_word t1) C_noret;
static void C_fcall f_6621(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6615(C_word c,C_word t0,C_word t1) C_noret;
static void f_6596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6590(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6513(C_word t0,C_word t1) C_noret;
static void C_fcall f_6527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6579(C_word c,C_word t0,C_word t1) C_noret;
static void f_6537(C_word c,C_word t0,C_word t1) C_noret;
static void f_6482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6507(C_word c,C_word t0,C_word t1) C_noret;
static void f_6500(C_word c,C_word t0,C_word t1) C_noret;
static void f_6496(C_word c,C_word t0,C_word t1) C_noret;
static void f_6349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6439(C_word c,C_word t0,C_word t1) C_noret;
static void f_6446(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6448(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6352(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6403(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6393(C_word t0,C_word t1) C_noret;
static void f_6362(C_word c,C_word t0,C_word t1) C_noret;
static void f_6365(C_word c,C_word t0,C_word t1) C_noret;
static void f_6371(C_word c,C_word t0,C_word t1) C_noret;
static void f_6217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6299(C_word c,C_word t0,C_word t1) C_noret;
static void f_6322(C_word c,C_word t0,C_word t1) C_noret;
static void f_6302(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6227(C_word c,C_word t0,C_word t1) C_noret;
static void f_6118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_6152(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_6159(C_word c,C_word t0,C_word t1) C_noret;
static void f_6207(C_word c,C_word t0,C_word t1) C_noret;
static void f_6179(C_word c,C_word t0,C_word t1) C_noret;
static void f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6084(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6112(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6036(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6046(C_word c,C_word t0,C_word t1) C_noret;
static void f_5993(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5993r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5997(C_word c,C_word t0,C_word t1) C_noret;
static void f_6000(C_word c,C_word t0,C_word t1) C_noret;
static void f_5983(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5983r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5991(C_word c,C_word t0,C_word t1) C_noret;
static void f_5727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_5733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5769(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_5957(C_word t0,C_word t1);
static void f_5903(C_word c,C_word t0,C_word t1) C_noret;
static void f_5906(C_word c,C_word t0,C_word t1) C_noret;
static void f_5885(C_word c,C_word t0,C_word t1) C_noret;
static void f_5881(C_word c,C_word t0,C_word t1) C_noret;
static void f_5868(C_word c,C_word t0,C_word t1) C_noret;
static void f_5864(C_word c,C_word t0,C_word t1) C_noret;
static void f_5851(C_word c,C_word t0,C_word t1) C_noret;
static void f_5847(C_word c,C_word t0,C_word t1) C_noret;
static void f_5834(C_word c,C_word t0,C_word t1) C_noret;
static void f_5821(C_word c,C_word t0,C_word t1) C_noret;
static void f_5808(C_word c,C_word t0,C_word t1) C_noret;
static void f_5779(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5746(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5742(C_word t0);
static void f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5709(C_word c,C_word t0,C_word t1) C_noret;
static void f_5713(C_word c,C_word t0,C_word t1) C_noret;
static void f_5698(C_word c,C_word t0,C_word t1) C_noret;
static void f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5651(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5625(C_word t0,C_word t1) C_noret;
static void f_5581(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5571(C_word t0,C_word t1) C_noret;
static void f_5567(C_word c,C_word t0,C_word t1) C_noret;
static void f_5339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5339r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5533(C_word c,C_word t0,C_word t1) C_noret;
static void f_5516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5376(C_word c,C_word t0,C_word t1) C_noret;
static void f_5379(C_word c,C_word t0,C_word t1) C_noret;
static void f_5391(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5396(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5415(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5342(C_word t0,C_word t1) C_noret;
static void f_5347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_5353(C_word t0,C_word t1);
static void f_5224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5228(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5252(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5257(C_word t0,C_word t1,C_word t2);
static void f_5089(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5089r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5196(C_word c,C_word t0,C_word t1) C_noret;
static void f_5140(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5125(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5117(C_word t0,C_word t1) C_noret;
static void f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_5044(C_word t0,C_word t1) C_noret;
static void f_4961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4980(C_word t0,C_word t1) C_noret;
static void f_4930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4880r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4861r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4814(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_4835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4848(C_word c,C_word t0,C_word t1) C_noret;
static void f_4804(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4804r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4812(C_word c,C_word t0,C_word t1) C_noret;
static void f_4768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4796(C_word c,C_word t0,C_word t1) C_noret;
static void f_4799(C_word c,C_word t0,C_word t1) C_noret;
static void f_4739(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4739r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4743(C_word c,C_word t0,C_word t1) C_noret;
static void f_4750(C_word c,C_word t0,C_word t1) C_noret;
static void f_4752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4756(C_word c,C_word t0,C_word t1) C_noret;
static void f_4746(C_word c,C_word t0,C_word t1) C_noret;
static void f_4658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4677(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3408(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4649(C_word c,C_word t0,C_word t1) C_noret;
static void f_4653(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4002(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4557(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4567(C_word t0,C_word t1) C_noret;
static void f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4527(C_word t0,C_word t1) C_noret;
static void f_4514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_4482(C_word c,C_word t0,C_word t1) C_noret;
static void f_4434(C_word c,C_word t0,C_word t1) C_noret;
static void f_4464(C_word c,C_word t0,C_word t1) C_noret;
static void f_4449(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4366(C_word c,C_word t0,C_word t1) C_noret;
static void f_4362(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4407(C_word c,C_word t0,C_word t1) C_noret;
static void f_4403(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_4265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4334(C_word c,C_word t0,C_word t1) C_noret;
static void f_4330(C_word c,C_word t0,C_word t1) C_noret;
static void f_4322(C_word c,C_word t0,C_word t1) C_noret;
static void f_4318(C_word c,C_word t0,C_word t1) C_noret;
static void f_4296(C_word c,C_word t0,C_word t1) C_noret;
static void f_4288(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4254(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4248(C_word c,C_word t0,C_word t1) C_noret;
static void f_4226(C_word c,C_word t0,C_word t1) C_noret;
static void f_4157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4164(C_word c,C_word t0,C_word t1) C_noret;
static void f_4191(C_word c,C_word t0,C_word t1) C_noret;
static void f_4217(C_word c,C_word t0,C_word t1) C_noret;
static void f_4175(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4070(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4083(C_word c,C_word t0,C_word t1) C_noret;
static void f_4121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4086(C_word c,C_word t0,C_word t1) C_noret;
static void f_4115(C_word c,C_word t0,C_word t1) C_noret;
static void f_4119(C_word c,C_word t0,C_word t1) C_noret;
static void f_4099(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4061(C_word c,C_word t0,C_word t1) C_noret;
static void f_4054(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4005(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4036(C_word c,C_word t0,C_word t1) C_noret;
static void f_4029(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3700(C_word c,C_word t0,C_word t1) C_noret;
static void f_3957(C_word c,C_word t0,C_word t1) C_noret;
static void f_3974(C_word c,C_word t0,C_word t1) C_noret;
static void f_3984(C_word c,C_word t0,C_word t1) C_noret;
static void f_3977(C_word c,C_word t0,C_word t1) C_noret;
static void f_3964(C_word c,C_word t0,C_word t1) C_noret;
static void f_3941(C_word c,C_word t0,C_word t1) C_noret;
static void f_3944(C_word c,C_word t0,C_word t1) C_noret;
static void f_3951(C_word c,C_word t0,C_word t1) C_noret;
static void f_3932(C_word c,C_word t0,C_word t1) C_noret;
static void f_3848(C_word c,C_word t0,C_word t1) C_noret;
static void f_3851(C_word c,C_word t0,C_word t1) C_noret;
static void f_3907(C_word c,C_word t0,C_word t1) C_noret;
static void f_3886(C_word c,C_word t0,C_word t1) C_noret;
static void f_3893(C_word c,C_word t0,C_word t1) C_noret;
static void f_3870(C_word c,C_word t0,C_word t1) C_noret;
static void f_3877(C_word c,C_word t0,C_word t1) C_noret;
static void f_3842(C_word c,C_word t0,C_word t1) C_noret;
static void f_3758(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3767(C_word t0,C_word t1) C_noret;
static void f_3819(C_word c,C_word t0,C_word t1) C_noret;
static void f_3815(C_word c,C_word t0,C_word t1) C_noret;
static void f_3798(C_word c,C_word t0,C_word t1) C_noret;
static void f_3794(C_word c,C_word t0,C_word t1) C_noret;
static void f_3790(C_word c,C_word t0,C_word t1) C_noret;
static void f_3739(C_word c,C_word t0,C_word t1) C_noret;
static void f_3716(C_word c,C_word t0,C_word t1) C_noret;
static void f_3719(C_word c,C_word t0,C_word t1) C_noret;
static void f_3726(C_word c,C_word t0,C_word t1) C_noret;
static void f_3707(C_word c,C_word t0,C_word t1) C_noret;
static void f_3677(C_word c,C_word t0,C_word t1) C_noret;
static void f_3681(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3531(C_word c,C_word t0,C_word t1) C_noret;
static void f_3542(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3634(C_word c,C_word t0,C_word t1) C_noret;
static void f_3569(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3623(C_word c,C_word t0,C_word t1) C_noret;
static void f_3619(C_word c,C_word t0,C_word t1) C_noret;
static void f_3603(C_word c,C_word t0,C_word t1) C_noret;
static void f_3595(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3512(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3469(C_word t0);
static C_word C_fcall f_3463(C_word t0);
static void C_fcall f_3411(C_word t0,C_word t1) C_noret;
static void C_fcall f_3443(C_word t0,C_word t1) C_noret;
static void f_3350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3350r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3363(C_word c,C_word t0,C_word t1) C_noret;
static void f_3393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3388(C_word c,C_word t0,C_word t1) C_noret;
static void f_3378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3376(C_word c,C_word t0,C_word t1) C_noret;
static void f_3269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_3269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_3282(C_word c,C_word t0,C_word t1) C_noret;
static void f_3338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3333(C_word c,C_word t0,C_word t1) C_noret;
static void f_3308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3324(C_word c,C_word t0,C_word t1) C_noret;
static void f_3287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3245(C_word c,C_word t0,C_word t1) C_noret;
static void f_3264(C_word c,C_word t0,C_word t1) C_noret;
static void f_3255(C_word c,C_word t0,C_word t1) C_noret;
static void f_3259(C_word c,C_word t0,C_word t1) C_noret;
static void f_3250(C_word c,C_word t0,C_word t1) C_noret;
static void f_3216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3220(C_word c,C_word t0,C_word t1) C_noret;
static void f_3236(C_word c,C_word t0,C_word t1) C_noret;
static void f_3230(C_word c,C_word t0,C_word t1) C_noret;
static void f_3225(C_word c,C_word t0,C_word t1) C_noret;
static void f_3204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3208(C_word c,C_word t0,C_word t1) C_noret;
static void f_3211(C_word c,C_word t0,C_word t1) C_noret;
static void f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3199(C_word c,C_word t0,C_word t1) C_noret;
static void f_3170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3174(C_word c,C_word t0,C_word t1) C_noret;
static void f_3190(C_word c,C_word t0,C_word t1) C_noret;
static void f_3184(C_word c,C_word t0,C_word t1) C_noret;
static void f_3179(C_word c,C_word t0,C_word t1) C_noret;
static void f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3149(C_word c,C_word t0,C_word t1) C_noret;
static void f_3165(C_word c,C_word t0,C_word t1) C_noret;
static void f_3159(C_word c,C_word t0,C_word t1) C_noret;
static void f_3154(C_word c,C_word t0,C_word t1) C_noret;
static void f_3120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3124(C_word c,C_word t0,C_word t1) C_noret;
static void f_3140(C_word c,C_word t0,C_word t1) C_noret;
static void f_3134(C_word c,C_word t0,C_word t1) C_noret;
static void f_3129(C_word c,C_word t0,C_word t1) C_noret;
static void f_3099(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3099r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3106(C_word c,C_word t0,C_word t1) C_noret;
static void f_3112(C_word c,C_word t0,C_word t1) C_noret;
static void f_3010(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3010r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_3051(C_word t0,C_word t1) C_noret;
static void C_fcall f_3046(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3019(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3032(C_word t0,C_word t1) C_noret;
static void f_3029(C_word c,C_word t0,C_word t1) C_noret;
static void f_2941(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2941r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2945(C_word c,C_word t0,C_word t1) C_noret;
static void f_2948(C_word c,C_word t0,C_word t1) C_noret;
static void f_2951(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2956(C_word t0,C_word t1) C_noret;
static void f_2960(C_word c,C_word t0,C_word t1) C_noret;
static void f_2966(C_word c,C_word t0,C_word t1) C_noret;
static void f_2976(C_word c,C_word t0,C_word t1) C_noret;
static void f_2969(C_word c,C_word t0,C_word t1) C_noret;
static void f_2826(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2826r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2893(C_word t0,C_word t1) C_noret;
static void C_fcall f_2888(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2832(C_word c,C_word t0,C_word t1) C_noret;
static void f_2835(C_word c,C_word t0,C_word t1) C_noret;
static void f_2841(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2850(C_word c,C_word t0,C_word t1) C_noret;
static void f_2856(C_word c,C_word t0,C_word t1) C_noret;
static void f_2868(C_word c,C_word t0,C_word t1) C_noret;
static void f_2734(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2734r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2803(C_word c,C_word t0,C_word t1) C_noret;
static void f_2746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2754(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2780(C_word c,C_word t0,C_word t1) C_noret;
static void f_2505(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2505r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2515(C_word t0,C_word t1) C_noret;
static void f_2518(C_word c,C_word t0,C_word t1) C_noret;
static void f_2521(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2527(C_word t0,C_word t1) C_noret;
static void f_2601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2624(C_word c,C_word t0,C_word t1) C_noret;
static void f_2706(C_word c,C_word t0,C_word t1) C_noret;
static void f_2698(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2684(C_word t0,C_word t1) C_noret;
static void f_2661(C_word c,C_word t0,C_word t1) C_noret;
static void f_2674(C_word c,C_word t0,C_word t1) C_noret;
static void f_2652(C_word c,C_word t0,C_word t1) C_noret;
static void f_2621(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2559(C_word c,C_word t0,C_word t1) C_noret;
static void f_2567(C_word c,C_word t0,C_word t1) C_noret;
static void f_2563(C_word c,C_word t0,C_word t1) C_noret;
static void f_2585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2490(C_word t0,C_word t1) C_noret;
static void f_2462(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2462r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2467(C_word t0,C_word t1) C_noret;
static void f_2450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2400r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2431(C_word c,C_word t0,C_word t1) C_noret;
static void f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2276r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2352(C_word t0,C_word t1) C_noret;
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2278(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2329(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2282(C_word t0,C_word t1) C_noret;
static void f_2285(C_word c,C_word t0,C_word t1) C_noret;
static void f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_2190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2235(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2251(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2197(C_word t0,C_word t1) C_noret;
static void f_2200(C_word c,C_word t0,C_word t1) C_noret;
static void f_2152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2188(C_word c,C_word t0,C_word t1) C_noret;
static void f_2164(C_word c,C_word t0,C_word t1) C_noret;
static void f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2160(C_word c,C_word t0,C_word t1) C_noret;
static void f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2081(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2123(C_word c,C_word t0,C_word t1) C_noret;
static void f_2013(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2013r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2025(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1935(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1978(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1874(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1874r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1922(C_word c,C_word t0,C_word t1) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1) C_noret;
static void f_1842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1851(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1872(C_word c,C_word t0,C_word t1) C_noret;
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1815(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1840(C_word c,C_word t0,C_word t1) C_noret;
static void f_1781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1793(C_word t0,C_word t1);
static void f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1772(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1740(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1759(C_word c,C_word t0,C_word t1) C_noret;
static void f_1702(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1702r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1705(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1705r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1713(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1713r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1719(C_word c,C_word t0,C_word t1) C_noret;
static void f_1727(C_word c,C_word t0,C_word t1) C_noret;
static void f_1690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1692(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1692r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1700(C_word c,C_word t0,C_word t1) C_noret;
static void f_1682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1659(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1659r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1672(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1670(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1622(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1622r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1640(C_word c,C_word t0,C_word t1) C_noret;
static void f_1589(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1589r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1597(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1610(C_word c,C_word t0,C_word t1) C_noret;
static void f_1581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1583(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1583r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1443(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1443r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1515(C_word t0,C_word t1) C_noret;
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1498(C_word c,C_word t0,C_word t1) C_noret;
static void f_1448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1456(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1458(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1478(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_8358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8358(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8358(t0,t1,t2);}

static void C_fcall trf_8272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8272(t0,t1);}

static void C_fcall trf_8148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8148(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8148(t0,t1,t2,t3);}

static void C_fcall trf_8164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8164(t0,t1,t2);}

static void C_fcall trf_8096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8096(t0,t1,t2);}

static void C_fcall trf_8028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8028(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8028(t0,t1,t2,t3);}

static void C_fcall trf_8044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8044(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8044(t0,t1,t2,t3);}

static void C_fcall trf_7963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7963(t0,t1,t2,t3);}

static void C_fcall trf_7979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7979(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7979(t0,t1,t2,t3);}

static void C_fcall trf_7867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7867(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7867(t0,t1,t2,t3);}

static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7883(t0,t1,t2,t3);}

static void C_fcall trf_7799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7799(t0,t1,t2);}

static void C_fcall trf_7822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7822(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7822(t0,t1,t2);}

static void C_fcall trf_7646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7646(t0,t1,t2,t3);}

static void C_fcall trf_7665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7665(t0,t1);}

static void C_fcall trf_7591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7591(t0,t1,t2,t3);}

static void C_fcall trf_7610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7610(t0,t1);}

static void C_fcall trf_7330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7330(t0,t1);}

static void C_fcall trf_7454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7454(t0,t1,t2);}

static void C_fcall trf_7393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7393(t0,t1,t2);}

static void C_fcall trf_7714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7714(t0,t1,t2);}

static void C_fcall trf_7737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7737(t0,t1,t2);}

static void C_fcall trf_7298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7298(t0,t1);}

static void C_fcall trf_7209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7209(t0,t1,t2);}

static void C_fcall trf_7167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7167(t0,t1,t2);}

static void C_fcall trf_6830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6830(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6830(t0,t1,t2,t3);}

static void C_fcall trf_6967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6967(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6967(t0,t1,t2,t3,t4);}

static void C_fcall trf_6805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6805(t0,t1,t2,t3);}

static void C_fcall trf_6815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6815(t0,t1);}

static void C_fcall trf_6707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6707(t0,t1,t2);}

static void C_fcall trf_6749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6749(t0,t1,t2);}

static void C_fcall trf_6626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6626(t0,t1);}

static void C_fcall trf_6621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6621(t0,t1,t2);}

static void C_fcall trf_6616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6616(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6616(t0,t1,t2,t3);}

static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6604(t0,t1,t2,t3,t4);}

static void C_fcall trf_6513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6513(t0,t1);}

static void C_fcall trf_6527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6527(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6527(t0,t1,t2,t3);}

static void C_fcall trf_6448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6448(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6448(t0,t1,t2,t3);}

static void C_fcall trf_6352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6352(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6352(t0,t1,t2);}

static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6393(t0,t1);}

static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6220(t0,t1,t2,t3,t4);}

static void C_fcall trf_6152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6152(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6152(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6084(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6084(t0,t1,t2,t3);}

static void C_fcall trf_6036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6036(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6036(t0,t1,t2);}

static void C_fcall trf_5733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5733(t0,t1,t2,t3);}

static void C_fcall trf_5769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5769(t0,t1,t2);}

static void C_fcall trf_5746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5746(t0,t1);}

static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5678(t0,t1,t2,t3);}

static void C_fcall trf_5553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5553(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5553(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5586(t0,t1,t2);}

static void C_fcall trf_5625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5625(t0,t1);}

static void C_fcall trf_5571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5571(t0,t1);}

static void C_fcall trf_5396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5396(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5396(t0,t1,t2,t3);}

static void C_fcall trf_5342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5342(t0,t1);}

static void C_fcall trf_5242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5242(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5242(t0,t1,t2,t3);}

static void C_fcall trf_5130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5130(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5130(t0,t1,t2,t3,t4);}

static void C_fcall trf_5157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5157(t0,t1,t2);}

static void C_fcall trf_5110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5110(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5110(t0,t1,t2,t3,t4);}

static void C_fcall trf_5117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5117(t0,t1);}

static void C_fcall trf_5044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5044(t0,t1);}

static void C_fcall trf_4980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4980(t0,t1);}

static void C_fcall trf_4814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4814(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4814(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4835(t0,t1,t2,t3);}

static void C_fcall trf_4661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4661(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4661(t0,t1,t2,t3);}

static void C_fcall trf_4686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4686(t0,t1,t2,t3);}

static void C_fcall trf_3408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3408(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3408(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4002(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4002(t0,t1,t2,t3);}

static void C_fcall trf_4557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4557(t0,t1,t2);}

static void C_fcall trf_4567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4567(t0,t1);}

static void C_fcall trf_4527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4527(t0,t1);}

static void C_fcall trf_4336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4336(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_4336(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall trf_4339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4339(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4339(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4380(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4380(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4421(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4421(t0,t1,t2,t3,t4);}

static void C_fcall trf_4259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4259(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4259(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4265(t0,t1,t2,t3);}

static void C_fcall trf_4250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4250(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4250(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4222(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4070(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4070(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4038(t0,t1,t2,t3);}

static void C_fcall trf_4005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4005(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4005(t0,t1,t2,t3);}

static void C_fcall trf_3521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3521(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3521(t0,t1,t2,t3);}

static void C_fcall trf_3760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3760(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3760(t0,t1,t2,t3,t4);}

static void C_fcall trf_3767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3767(t0,t1);}

static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3524(t0,t1,t2,t3);}

static void C_fcall trf_3551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3551(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3551(t0,t1,t2,t3);}

static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3571(t0,t1,t2,t3);}

static void C_fcall trf_3502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3502(t0,t1,t2,t3);}

static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3411(t0,t1);}

static void C_fcall trf_3443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3443(t0,t1);}

static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3051(t0,t1);}

static void C_fcall trf_3046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3046(t0,t1,t2);}

static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3015(t0,t1,t2,t3);}

static void C_fcall trf_3032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3032(t0,t1);}

static void C_fcall trf_2956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2956(t0,t1);}

static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2893(t0,t1);}

static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2888(t0,t1,t2);}

static void C_fcall trf_2828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2828(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2828(t0,t1,t2,t3);}

static void C_fcall trf_2846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2846(t0,t1,t2);}

static void C_fcall trf_2760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2760(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2760(t0,t1,t2,t3,t4);}

static void C_fcall trf_2515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2515(t0,t1);}

static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2527(t0,t1);}

static void C_fcall trf_2607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2607(t0,t1,t2);}

static void C_fcall trf_2684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2684(t0,t1);}

static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2532(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2479(t0,t1,t2);}

static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2490(t0,t1);}

static void C_fcall trf_2467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2467(t0,t1);}

static void C_fcall trf_2412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2412(t0,t1,t2);}

static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2352(t0,t1);}

static void C_fcall trf_2347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2347(t0,t1,t2);}

static void C_fcall trf_2278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2278(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2278(t0,t1,t2,t3);}

static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2313(t0,t1,t2);}

static void C_fcall trf_2282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2282(t0,t1);}

static void C_fcall trf_2235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2235(t0,t1,t2);}

static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2197(t0,t1);}

static void C_fcall trf_2081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2081(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2081(t0,t1,t2,t3);}

static void C_fcall trf_2025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2025(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2025(t0,t1,t2);}

static void C_fcall trf_1943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1943(t0,t1,t2,t3);}

static void C_fcall trf_1964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1964(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1964(t0,t1,t2,t3,t4);}

static void C_fcall trf_1880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1880(t0,t1,t2,t3);}

static void C_fcall trf_1851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1851(t0,t1,t2);}

static void C_fcall trf_1815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1815(t0,t1,t2);}

static void C_fcall trf_1740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1740(t0,t1,t2);}

static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1630(t0,t1,t2);}

static void C_fcall trf_1597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1597(t0,t1,t2);}

static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1515(t0,t1);}

static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1510(t0,t1,t2);}

static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1505(t0,t1,t2,t3);}

static void C_fcall trf_1445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1445(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1445(t0,t1,t2,t3,t4);}

static void C_fcall trf_1458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1458(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1458(t0,t1,t2,t3,t4);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1828)){
C_save(t1);
C_rereclaim2(1828*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,533);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],4,"read");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],20,"call-with-input-file");
lf[5]=C_h_intern(&lf[5],9,"read-file");
lf[6]=C_static_lambda_info(C_heaptop,19,"(do22 x24 i25 xs26)");
lf[7]=C_static_lambda_info(C_heaptop,14,"(slurp port21)");
lf[8]=C_h_intern(&lf[8],5,"port\077");
lf[9]=C_static_lambda_info(C_heaptop,30,"(body10 port17 reader18 max19)");
lf[10]=C_static_lambda_info(C_heaptop,31,"(def-max14 %port732 %reader833)");
lf[11]=C_static_lambda_info(C_heaptop,23,"(def-reader13 %port735)");
lf[12]=C_h_intern(&lf[12],18,"\003sysstandard-input");
lf[13]=C_static_lambda_info(C_heaptop,12,"(def-port12)");
lf[14]=C_h_intern(&lf[14],9,"\003syserror");
lf[15]=C_static_lambda_info(C_heaptop,17,"(read-file . g56)");
lf[16]=C_h_intern(&lf[16],8,"identity");
lf[17]=C_static_lambda_info(C_heaptop,14,"(identity x44)");
lf[18]=C_h_intern(&lf[18],7,"project");
lf[19]=C_static_lambda_info(C_heaptop,17,"(f_1583 . args46)");
lf[20]=C_static_lambda_info(C_heaptop,13,"(project n45)");
lf[21]=C_h_intern(&lf[21],7,"conjoin");
lf[22]=C_static_lambda_info(C_heaptop,14,"(loop preds50)");
lf[23]=C_static_lambda_info(C_heaptop,12,"(f_1591 x48)");
lf[24]=C_static_lambda_info(C_heaptop,19,"(conjoin . preds47)");
lf[25]=C_h_intern(&lf[25],7,"disjoin");
lf[26]=C_static_lambda_info(C_heaptop,14,"(loop preds57)");
lf[27]=C_static_lambda_info(C_heaptop,12,"(f_1624 x55)");
lf[28]=C_static_lambda_info(C_heaptop,19,"(disjoin . preds54)");
lf[29]=C_h_intern(&lf[29],10,"constantly");
lf[30]=C_static_lambda_info(C_heaptop,14,"(f_1670 . _63)");
lf[31]=C_static_lambda_info(C_heaptop,14,"(f_1672 . _64)");
lf[32]=C_static_lambda_info(C_heaptop,19,"(constantly . xs61)");
lf[33]=C_h_intern(&lf[33],4,"flip");
lf[34]=C_static_lambda_info(C_heaptop,16,"(f_1684 x66 y67)");
lf[35]=C_static_lambda_info(C_heaptop,13,"(flip proc65)");
lf[36]=C_h_intern(&lf[36],10,"complement");
lf[37]=C_static_lambda_info(C_heaptop,17,"(f_1692 . args69)");
lf[38]=C_static_lambda_info(C_heaptop,16,"(complement p68)");
lf[39]=C_h_intern(&lf[39],7,"compose");
lf[40]=C_static_lambda_info(C_heaptop,7,"(a1718)");
lf[41]=C_static_lambda_info(C_heaptop,17,"(f_1713 . args74)");
lf[42]=C_static_lambda_info(C_heaptop,18,"(rec f072 . fns73)");
lf[43]=C_static_lambda_info(C_heaptop,17,"(compose . fns70)");
lf[44]=C_h_intern(&lf[44],7,"list-of");
lf[45]=C_static_lambda_info(C_heaptop,12,"(loop lst79)");
lf[46]=C_static_lambda_info(C_heaptop,14,"(f_1734 lst77)");
lf[47]=C_static_lambda_info(C_heaptop,16,"(list-of pred76)");
lf[48]=C_h_intern(&lf[48],4,"noop");
lf[49]=C_h_intern(&lf[49],4,"void");
lf[50]=C_static_lambda_info(C_heaptop,12,"(noop . _81)");
lf[51]=C_h_intern(&lf[51],5,"atom\077");
lf[52]=C_static_lambda_info(C_heaptop,11,"(atom\077 x82)");
lf[53]=C_h_intern(&lf[53],5,"tail\077");
lf[54]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[55]=C_static_lambda_info(C_heaptop,15,"(tail\077 x83 y84)");
lf[56]=C_h_intern(&lf[56],11,"intersperse");
lf[57]=C_static_lambda_info(C_heaptop,11,"(loop ns94)");
lf[58]=C_static_lambda_info(C_heaptop,23,"(intersperse lst91 x92)");
lf[59]=C_h_intern(&lf[59],7,"butlast");
lf[60]=C_static_lambda_info(C_heaptop,12,"(loop lst99)");
lf[61]=C_static_lambda_info(C_heaptop,15,"(butlast lst97)");
lf[62]=C_h_intern(&lf[62],7,"flatten");
lf[63]=C_h_intern(&lf[63],27,"\003sysnot-a-proper-list-error");
lf[64]=C_static_lambda_info(C_heaptop,23,"(loop lists105 rest106)");
lf[65]=C_static_lambda_info(C_heaptop,21,"(flatten . lists0103)");
lf[66]=C_h_intern(&lf[66],4,"chop");
lf[67]=C_static_lambda_info(C_heaptop,24,"(do117 hd119 tl120 c121)");
lf[68]=C_static_lambda_info(C_heaptop,18,"(loop lst115 i116)");
lf[69]=C_static_string(C_heaptop,24,"invalid numeric argument");
lf[70]=C_static_lambda_info(C_heaptop,18,"(chop lst111 n112)");
lf[71]=C_h_intern(&lf[71],4,"join");
lf[72]=C_h_intern(&lf[72],10,"\003sysappend");
lf[73]=C_static_lambda_info(C_heaptop,14,"(loop lsts130)");
lf[74]=C_static_lambda_info(C_heaptop,23,"(join lsts126 . lst127)");
lf[75]=C_h_intern(&lf[75],8,"compress");
lf[76]=C_static_string(C_heaptop,37,"bad argument type - not a proper list");
lf[77]=C_h_intern(&lf[77],15,"\003syssignal-hook");
lf[78]=C_h_intern(&lf[78],11,"\000type-error");
lf[79]=C_static_lambda_info(C_heaptop,21,"(loop blst139 lst140)");
lf[80]=C_static_lambda_info(C_heaptop,25,"(compress blst135 lst136)");
lf[81]=C_h_intern(&lf[81],7,"shuffle");
lf[82]=C_h_intern(&lf[82],7,"\003sysmap");
lf[83]=C_h_intern(&lf[83],3,"cdr");
lf[84]=C_static_lambda_info(C_heaptop,17,"(a2165 x145 y146)");
lf[85]=C_h_intern(&lf[85],5,"sort!");
lf[86]=C_h_intern(&lf[86],6,"random");
lf[87]=C_static_lambda_info(C_heaptop,12,"(a2179 x144)");
lf[88]=C_static_lambda_info(C_heaptop,14,"(shuffle l143)");
lf[89]=C_h_intern(&lf[89],13,"alist-update!");
lf[90]=C_h_intern(&lf[90],4,"eqv\077");
lf[91]=C_h_intern(&lf[91],3,"eq\077");
lf[92]=C_h_intern(&lf[92],4,"assq");
lf[93]=C_h_intern(&lf[93],4,"assv");
lf[94]=C_h_intern(&lf[94],6,"equal\077");
lf[95]=C_h_intern(&lf[95],5,"assoc");
lf[96]=C_static_lambda_info(C_heaptop,13,"(loop lst156)");
lf[97]=C_static_lambda_info(C_heaptop,20,"(f_2229 x153 lst154)");
lf[98]=C_static_lambda_info(C_heaptop,41,"(alist-update! x147 y148 lst149 . cmp150)");
lf[99]=C_h_intern(&lf[99],9,"alist-ref");
lf[100]=C_static_lambda_info(C_heaptop,13,"(loop lst179)");
lf[101]=C_static_lambda_info(C_heaptop,20,"(f_2307 x176 lst177)");
lf[102]=C_static_lambda_info(C_heaptop,27,"(body167 cmp173 default174)");
lf[103]=C_static_lambda_info(C_heaptop,27,"(def-default170 %cmp165184)");
lf[104]=C_static_lambda_info(C_heaptop,12,"(def-cmp169)");
lf[105]=C_static_lambda_info(C_heaptop,33,"(alist-ref x162 lst163 . g161164)");
lf[106]=C_h_intern(&lf[106],6,"rassoc");
lf[107]=C_static_lambda_info(C_heaptop,11,"(loop l195)");
lf[108]=C_static_lambda_info(C_heaptop,29,"(rassoc x190 lst191 . tst192)");
lf[109]=C_static_lambda_info(C_heaptop,13,"(random n200)");
lf[110]=C_h_intern(&lf[110],9,"randomize");
lf[111]=C_static_lambda_info(C_heaptop,18,"(randomize . n202)");
lf[112]=C_h_intern(&lf[112],11,"make-string");
lf[113]=C_h_intern(&lf[113],13,"\003syssubstring");
lf[114]=C_static_lambda_info(C_heaptop,21,"(fixup str207 len208)");
lf[115]=C_h_intern(&lf[115],9,"read-line");
lf[116]=C_h_intern(&lf[116],17,"\003sysstring-append");
lf[117]=C_static_lambda_info(C_heaptop,38,"(loop len216 buffer217 result218 f219)");
lf[118]=C_static_string(C_heaptop,0,"");
lf[119]=C_h_intern(&lf[119],15,"\003sysread-char-0");
lf[120]=C_static_lambda_info(C_heaptop,11,"(loop i224)");
lf[121]=C_static_lambda_info(C_heaptop,17,"(a2600 return222)");
lf[122]=C_h_intern(&lf[122],6,"stream");
lf[123]=C_h_intern(&lf[123],14,"\003syscheck-port");
lf[124]=C_static_lambda_info(C_heaptop,21,"(read-line . args209)");
lf[125]=C_h_intern(&lf[125],10,"read-lines");
lf[126]=C_static_lambda_info(C_heaptop,25,"(do245 ln247 lns248 n249)");
lf[127]=C_static_lambda_info(C_heaptop,16,"(doread port244)");
lf[128]=C_static_lambda_info(C_heaptop,30,"(read-lines . port-and-max239)");
lf[129]=C_h_intern(&lf[129],18,"open-output-string");
lf[130]=C_h_intern(&lf[130],17,"get-output-string");
lf[131]=C_h_intern(&lf[131],11,"read-string");
lf[132]=C_h_intern(&lf[132],14,"\003syswrite-char");
lf[133]=C_static_lambda_info(C_heaptop,11,"(loop n272)");
lf[134]=C_static_lambda_info(C_heaptop,19,"(body262 n268 p269)");
lf[135]=C_static_lambda_info(C_heaptop,19,"(def-p265 %n260282)");
lf[136]=C_static_lambda_info(C_heaptop,10,"(def-n264)");
lf[137]=C_static_lambda_info(C_heaptop,29,"(read-string . n-and-port259)");
lf[138]=C_h_intern(&lf[138],10,"read-token");
lf[139]=C_h_intern(&lf[139],16,"\003syswrite-char-0");
lf[140]=C_h_intern(&lf[140],15,"\003syspeek-char-0");
lf[141]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[142]=C_static_lambda_info(C_heaptop,30,"(read-token pred290 . port291)");
lf[143]=C_h_intern(&lf[143],7,"display");
lf[144]=C_h_intern(&lf[144],12,"write-string");
lf[145]=C_static_lambda_info(C_heaptop,22,"(body306 n312 port313)");
lf[146]=C_h_intern(&lf[146],19,"\003sysstandard-output");
lf[147]=C_static_lambda_info(C_heaptop,22,"(def-port309 %n304317)");
lf[148]=C_static_lambda_info(C_heaptop,10,"(def-n308)");
lf[149]=C_static_lambda_info(C_heaptop,29,"(write-string s302 . more303)");
lf[150]=C_h_intern(&lf[150],7,"newline");
lf[151]=C_h_intern(&lf[151],10,"write-line");
lf[152]=C_static_lambda_info(C_heaptop,29,"(write-line str326 . port327)");
lf[153]=C_h_intern(&lf[153],20,"with-input-from-port");
lf[154]=C_static_lambda_info(C_heaptop,7,"(a3128)");
lf[155]=C_static_lambda_info(C_heaptop,7,"(a3133)");
lf[156]=C_static_lambda_info(C_heaptop,7,"(a3139)");
lf[157]=C_h_intern(&lf[157],16,"\003sysdynamic-wind");
lf[158]=C_static_lambda_info(C_heaptop,39,"(with-input-from-port port332 thunk333)");
lf[159]=C_h_intern(&lf[159],19,"with-output-to-port");
lf[160]=C_static_lambda_info(C_heaptop,7,"(a3153)");
lf[161]=C_static_lambda_info(C_heaptop,7,"(a3158)");
lf[162]=C_static_lambda_info(C_heaptop,7,"(a3164)");
lf[163]=C_h_intern(&lf[163],21,"with-output-from-port");
lf[164]=C_static_lambda_info(C_heaptop,38,"(with-output-to-port port341 thunk342)");
lf[165]=C_h_intern(&lf[165],25,"with-error-output-to-port");
lf[166]=C_h_intern(&lf[166],18,"\003sysstandard-error");
lf[167]=C_static_lambda_info(C_heaptop,7,"(a3178)");
lf[168]=C_static_lambda_info(C_heaptop,7,"(a3183)");
lf[169]=C_static_lambda_info(C_heaptop,7,"(a3189)");
lf[170]=C_h_intern(&lf[170],27,"with-error-output-from-port");
lf[171]=C_static_lambda_info(C_heaptop,44,"(with-error-output-to-port port350 thunk351)");
lf[172]=C_h_intern(&lf[172],17,"open-input-string");
lf[173]=C_h_intern(&lf[173],22,"call-with-input-string");
lf[174]=C_static_lambda_info(C_heaptop,39,"(call-with-input-string str360 proc361)");
lf[175]=C_h_intern(&lf[175],23,"call-with-output-string");
lf[176]=C_static_lambda_info(C_heaptop,33,"(call-with-output-string proc365)");
lf[177]=C_h_intern(&lf[177],22,"with-input-from-string");
lf[178]=C_static_lambda_info(C_heaptop,7,"(a3224)");
lf[179]=C_static_lambda_info(C_heaptop,7,"(a3229)");
lf[180]=C_static_lambda_info(C_heaptop,7,"(a3235)");
lf[181]=C_static_lambda_info(C_heaptop,40,"(with-input-from-string str369 thunk370)");
lf[182]=C_h_intern(&lf[182],21,"with-output-to-string");
lf[183]=C_static_lambda_info(C_heaptop,7,"(a3249)");
lf[184]=C_static_lambda_info(C_heaptop,7,"(a3254)");
lf[185]=C_static_lambda_info(C_heaptop,7,"(a3263)");
lf[186]=C_static_lambda_info(C_heaptop,32,"(with-output-to-string thunk379)");
lf[187]=C_h_intern(&lf[187],15,"make-input-port");
lf[188]=C_static_lambda_info(C_heaptop,12,"(a3286 p393)");
lf[189]=C_static_lambda_info(C_heaptop,12,"(a3307 p396)");
lf[190]=C_static_lambda_info(C_heaptop,12,"(a3328 p400)");
lf[191]=C_static_lambda_info(C_heaptop,12,"(a3337 p402)");
lf[192]=C_h_intern(&lf[192],13,"\003sysmake-port");
lf[193]=C_static_string(C_heaptop,8,"(custom)");
lf[194]=C_h_intern(&lf[194],6,"custom");
lf[195]=C_static_lambda_info(C_heaptop,54,"(make-input-port read387 ready\077388 close389 . peek390)");
lf[196]=C_h_intern(&lf[196],6,"string");
lf[197]=C_h_intern(&lf[197],16,"make-output-port");
lf[198]=C_static_lambda_info(C_heaptop,17,"(a3367 p412 c413)");
lf[199]=C_static_lambda_info(C_heaptop,17,"(a3377 p414 s415)");
lf[200]=C_static_lambda_info(C_heaptop,12,"(a3383 p416)");
lf[201]=C_static_lambda_info(C_heaptop,12,"(a3392 p418)");
lf[202]=C_static_string(C_heaptop,8,"(custom)");
lf[203]=C_static_lambda_info(C_heaptop,47,"(make-output-port write407 close408 . flush409)");
lf[205]=C_h_intern(&lf[205],5,"quote");
lf[206]=C_h_intern(&lf[206],10,"quasiquote");
lf[207]=C_h_intern(&lf[207],7,"unquote");
lf[208]=C_h_intern(&lf[208],16,"unquote-splicing");
lf[209]=C_static_lambda_info(C_heaptop,18,"(read-macro\077 l434)");
lf[210]=C_static_lambda_info(C_heaptop,17,"(read-macro-body)");
lf[211]=C_static_string(C_heaptop,1,"\047");
lf[212]=C_static_string(C_heaptop,1,"`");
lf[213]=C_static_string(C_heaptop,1,",");
lf[214]=C_static_string(C_heaptop,2,",@");
lf[215]=C_static_lambda_info(C_heaptop,19,"(read-macro-prefix)");
lf[216]=C_static_lambda_info(C_heaptop,19,"(out str454 col455)");
lf[217]=C_static_string(C_heaptop,1," ");
lf[218]=C_static_string(C_heaptop,1,")");
lf[219]=C_static_string(C_heaptop,1,")");
lf[220]=C_static_string(C_heaptop,3," . ");
lf[221]=C_static_lambda_info(C_heaptop,18,"(loop l465 col466)");
lf[222]=C_static_string(C_heaptop,1,"(");
lf[223]=C_static_string(C_heaptop,2,"()");
lf[224]=C_static_lambda_info(C_heaptop,20,"(wr-lst l462 col463)");
lf[225]=C_static_lambda_info(C_heaptop,24,"(wr-expr expr460 col461)");
lf[226]=C_static_string(C_heaptop,6,"#<eof>");
lf[227]=C_static_string(C_heaptop,1,"#");
lf[228]=C_h_intern(&lf[228],12,"vector->list");
lf[229]=C_static_string(C_heaptop,2,"#t");
lf[230]=C_static_string(C_heaptop,2,"#f");
lf[231]=C_h_intern(&lf[231],18,"\003sysnumber->string");
lf[232]=C_h_intern(&lf[232],9,"\003sysprint");
lf[233]=C_h_intern(&lf[233],21,"\003sysprocedure->string");
lf[234]=C_static_string(C_heaptop,1,"\134");
lf[235]=C_static_string(C_heaptop,1,"\042");
lf[236]=C_static_lambda_info(C_heaptop,23,"(loop i471 j472 col473)");
lf[237]=C_static_string(C_heaptop,1,"\042");
lf[238]=C_static_string(C_heaptop,1,"x");
lf[239]=C_static_string(C_heaptop,1,"U");
lf[240]=C_static_string(C_heaptop,1,"u");
lf[241]=C_h_intern(&lf[241],9,"char-name");
lf[242]=C_static_string(C_heaptop,2,"#\134");
lf[243]=C_static_string(C_heaptop,6,"#<eof>");
lf[244]=C_static_string(C_heaptop,14,"#<unspecified>");
lf[245]=C_h_intern(&lf[245],19,"\003syspointer->string");
lf[246]=C_h_intern(&lf[246],19,"\003sysuser-print-hook");
lf[247]=C_h_intern(&lf[247],13,"string-append");
lf[248]=C_static_string(C_heaptop,7,"#<port ");
lf[249]=C_static_string(C_heaptop,1,">");
lf[250]=C_static_string(C_heaptop,2,"#>");
lf[251]=C_h_intern(&lf[251],23,"\003syslambda-info->string");
lf[252]=C_static_string(C_heaptop,14,"#<lambda info ");
lf[253]=C_h_intern(&lf[253],28,"\003sysarbitrary-unbound-symbol");
lf[254]=C_static_string(C_heaptop,16,"#<unbound value>");
lf[255]=C_static_string(C_heaptop,21,"#<unprintable object>");
lf[256]=C_h_intern(&lf[256],11,"\003sysnumber\077");
lf[257]=C_static_lambda_info(C_heaptop,18,"(wr obj456 col457)");
lf[258]=C_static_string(C_heaptop,8,"        ");
lf[259]=C_static_string(C_heaptop,8,"        ");
lf[260]=C_static_lambda_info(C_heaptop,20,"(spaces n514 col515)");
lf[261]=C_static_lambda_info(C_heaptop,21,"(indent to516 col517)");
lf[262]=C_h_intern(&lf[262],28,"\006extrasreverse-string-append");
lf[263]=C_static_string(C_heaptop,1,"#");
lf[264]=C_static_lambda_info(C_heaptop,14,"(a4120 str526)");
lf[265]=C_h_intern(&lf[265],3,"max");
lf[266]=C_static_lambda_info(C_heaptop,38,"(pr obj518 col519 extra520 pp-pair521)");
lf[267]=C_h_intern(&lf[267],28,"\003syssymbol->qualified-string");
lf[268]=C_static_lambda_info(C_heaptop,33,"(pp-expr expr530 col531 extra532)");
lf[269]=C_static_string(C_heaptop,1,"(");
lf[270]=C_static_lambda_info(C_heaptop,44,"(pp-call expr535 col536 extra537 pp-item538)");
lf[271]=C_static_string(C_heaptop,1,"(");
lf[272]=C_static_lambda_info(C_heaptop,41,"(pp-list l540 col541 extra542 pp-item543)");
lf[273]=C_static_string(C_heaptop,1,")");
lf[274]=C_static_string(C_heaptop,1,")");
lf[275]=C_static_string(C_heaptop,1,".");
lf[276]=C_static_lambda_info(C_heaptop,18,"(loop l551 col552)");
lf[277]=C_static_lambda_info(C_heaptop,50,"(pp-down l545 col1546 col2547 extra548 pp-item549)");
lf[278]=C_static_lambda_info(C_heaptop,31,"(tail3 rest580 col1581 col2582)");
lf[279]=C_static_lambda_info(C_heaptop,39,"(tail2 rest573 col1574 col2575 col3576)");
lf[280]=C_static_lambda_info(C_heaptop,39,"(tail1 rest566 col1567 col2568 col3569)");
lf[281]=C_static_string(C_heaptop,1," ");
lf[282]=C_static_string(C_heaptop,1,"(");
lf[283]=C_static_lambda_info(C_heaptop,70,"(pp-general expr556 col557 extra558 named\077559 pp-1560 pp-2561 pp-3562)");
lf[284]=C_static_lambda_info(C_heaptop,35,"(pp-expr-list l592 col593 extra594)");
lf[285]=C_static_lambda_info(C_heaptop,35,"(pp-lambda expr595 col596 extra597)");
lf[286]=C_static_lambda_info(C_heaptop,31,"(pp-if expr598 col599 extra600)");
lf[287]=C_static_lambda_info(C_heaptop,33,"(pp-cond expr601 col602 extra603)");
lf[288]=C_static_lambda_info(C_heaptop,33,"(pp-case expr604 col605 extra606)");
lf[289]=C_static_lambda_info(C_heaptop,32,"(pp-and expr607 col608 extra609)");
lf[290]=C_static_lambda_info(C_heaptop,32,"(pp-let expr610 col611 extra612)");
lf[291]=C_static_lambda_info(C_heaptop,34,"(pp-begin expr615 col616 extra617)");
lf[292]=C_static_lambda_info(C_heaptop,31,"(pp-do expr618 col619 extra620)");
lf[293]=C_h_intern(&lf[293],6,"lambda");
lf[294]=C_h_intern(&lf[294],2,"if");
lf[295]=C_h_intern(&lf[295],4,"set!");
lf[296]=C_h_intern(&lf[296],4,"cond");
lf[297]=C_h_intern(&lf[297],4,"case");
lf[298]=C_h_intern(&lf[298],3,"and");
lf[299]=C_h_intern(&lf[299],2,"or");
lf[300]=C_h_intern(&lf[300],3,"let");
lf[301]=C_h_intern(&lf[301],5,"begin");
lf[302]=C_h_intern(&lf[302],2,"do");
lf[303]=C_h_intern(&lf[303],4,"let*");
lf[304]=C_h_intern(&lf[304],6,"letrec");
lf[305]=C_h_intern(&lf[305],6,"define");
lf[306]=C_static_lambda_info(C_heaptop,15,"(style head621)");
lf[307]=C_static_lambda_info(C_heaptop,18,"(pp obj491 col492)");
lf[308]=C_static_lambda_info(C_heaptop,62,"(##extras#generic-write obj424 display\077425 width426 output427)");
lf[309]=C_static_lambda_info(C_heaptop,16,"(loop j669 k670)");
lf[310]=C_static_lambda_info(C_heaptop,29,"(rev-string-append l663 i664)");
lf[311]=C_static_lambda_info(C_heaptop,37,"(##extras#reverse-string-append l661)");
lf[312]=C_h_intern(&lf[312],18,"pretty-print-width");
lf[313]=C_h_intern(&lf[313],12,"pretty-print");
lf[314]=C_static_lambda_info(C_heaptop,12,"(a4751 s677)");
lf[315]=C_h_intern(&lf[315],19,"current-output-port");
lf[316]=C_static_lambda_info(C_heaptop,30,"(pretty-print obj674 . opt675)");
lf[317]=C_h_intern(&lf[317],2,"pp");
lf[318]=C_h_intern(&lf[318],8,"->string");
lf[319]=C_h_intern(&lf[319],14,"symbol->string");
lf[320]=C_static_lambda_info(C_heaptop,15,"(->string x683)");
lf[321]=C_h_intern(&lf[321],4,"conc");
lf[322]=C_static_lambda_info(C_heaptop,16,"(conc . args687)");
lf[323]=C_static_lambda_info(C_heaptop,24,"(loop istart697 iend698)");
lf[324]=C_static_lambda_info(C_heaptop,52,"(traverse which689 where690 start691 test692 loc693)");
lf[325]=C_h_intern(&lf[325],15,"substring-index");
lf[326]=C_static_lambda_info(C_heaptop,17,"(a4870 i706 l707)");
lf[327]=C_static_lambda_info(C_heaptop,46,"(substring-index which703 where704 . start705)");
lf[328]=C_h_intern(&lf[328],18,"substring-index-ci");
lf[329]=C_static_lambda_info(C_heaptop,17,"(a4889 i711 l712)");
lf[330]=C_static_lambda_info(C_heaptop,49,"(substring-index-ci which708 where709 . start710)");
lf[331]=C_h_intern(&lf[331],15,"string-compare3");
lf[332]=C_static_lambda_info(C_heaptop,29,"(string-compare3 s1715 s2716)");
lf[333]=C_h_intern(&lf[333],18,"string-compare3-ci");
lf[334]=C_static_lambda_info(C_heaptop,32,"(string-compare3-ci s1723 s2724)");
lf[335]=C_h_intern(&lf[335],11,"substring=\077");
lf[336]=C_static_lambda_info(C_heaptop,36,"(substring=\077 s1731 s2732 . start733)");
lf[337]=C_h_intern(&lf[337],14,"substring-ci=\077");
lf[338]=C_static_lambda_info(C_heaptop,39,"(substring-ci=\077 s1742 s2743 . start744)");
lf[339]=C_h_intern(&lf[339],12,"string-split");
lf[340]=C_static_string(C_heaptop,3,"\011\012 ");
lf[341]=C_static_lambda_info(C_heaptop,27,"(add from761 to762 last763)");
lf[342]=C_static_lambda_info(C_heaptop,11,"(scan j777)");
lf[343]=C_static_lambda_info(C_heaptop,27,"(loop i767 last768 from769)");
lf[344]=C_static_lambda_info(C_heaptop,42,"(string-split str753 . delstr-and-flag754)");
lf[345]=C_h_intern(&lf[345],18,"string-intersperse");
lf[346]=C_static_string(C_heaptop,0,"");
lf[347]=C_static_lambda_info(C_heaptop,13,"(loop2 n2799)");
lf[348]=C_h_intern(&lf[348],19,"\003sysallocate-vector");
lf[349]=C_static_lambda_info(C_heaptop,18,"(loop1 ss794 n795)");
lf[350]=C_static_string(C_heaptop,1," ");
lf[351]=C_static_lambda_info(C_heaptop,38,"(string-intersperse strs787 . g786788)");
lf[352]=C_h_intern(&lf[352],12,"list->string");
lf[353]=C_h_intern(&lf[353],16,"string-translate");
lf[354]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[355]=C_static_lambda_info(C_heaptop,13,"(f_5347 c820)");
lf[356]=C_static_lambda_info(C_heaptop,15,"(instring s818)");
lf[357]=C_static_string(C_heaptop,31,"invalid translation destination");
lf[358]=C_static_lambda_info(C_heaptop,16,"(loop i834 j835)");
lf[359]=C_static_lambda_info(C_heaptop,13,"(f_5516 c825)");
lf[360]=C_static_lambda_info(C_heaptop,41,"(string-translate str814 from815 . to816)");
lf[361]=C_h_intern(&lf[361],17,"string-translate*");
lf[362]=C_h_intern(&lf[362],21,"\003sysfragments->string");
lf[363]=C_static_lambda_info(C_heaptop,14,"(loop smap853)");
lf[364]=C_static_lambda_info(C_heaptop,37,"(collect i848 from849 total850 fs851)");
lf[365]=C_static_lambda_info(C_heaptop,34,"(string-translate* str844 smap845)");
lf[366]=C_h_intern(&lf[366],11,"string-chop");
lf[367]=C_static_lambda_info(C_heaptop,22,"(loop total868 pos869)");
lf[368]=C_static_lambda_info(C_heaptop,27,"(string-chop str864 len865)");
lf[369]=C_h_intern(&lf[369],5,"write");
lf[370]=C_h_intern(&lf[370],7,"fprintf");
lf[371]=C_static_lambda_info(C_heaptop,7,"(fetch)");
lf[372]=C_static_string(C_heaptop,47,"too few arguments to formatted output procedure");
lf[373]=C_static_lambda_info(C_heaptop,6,"(next)");
lf[374]=C_h_intern(&lf[374],16,"\003sysflush-output");
lf[375]=C_static_lambda_info(C_heaptop,6,"(skip)");
lf[376]=C_static_string(C_heaptop,31,"illegal format-string character");
lf[377]=C_static_lambda_info(C_heaptop,12,"(do884 c892)");
lf[378]=C_static_lambda_info(C_heaptop,20,"(rec msg880 args881)");
lf[379]=C_static_lambda_info(C_heaptop,34,"(fprintf port876 msg877 . args878)");
lf[380]=C_h_intern(&lf[380],6,"printf");
lf[381]=C_static_lambda_info(C_heaptop,25,"(printf msg912 . args913)");
lf[382]=C_h_intern(&lf[382],7,"sprintf");
lf[383]=C_static_lambda_info(C_heaptop,27,"(sprintf fstr917 . args918)");
lf[384]=C_h_intern(&lf[384],6,"format");
lf[385]=C_h_intern(&lf[385],7,"sorted\077");
lf[386]=C_static_lambda_info(C_heaptop,12,"(do924 i926)");
lf[387]=C_static_lambda_info(C_heaptop,22,"(loop last931 next932)");
lf[388]=C_static_lambda_info(C_heaptop,25,"(sorted\077 seq921 less\077922)");
lf[389]=C_h_intern(&lf[389],5,"merge");
lf[390]=C_static_lambda_info(C_heaptop,26,"(loop x940 a941 y942 b943)");
lf[391]=C_static_lambda_info(C_heaptop,26,"(merge a936 b937 less\077938)");
lf[392]=C_h_intern(&lf[392],6,"merge!");
lf[393]=C_static_lambda_info(C_heaptop,21,"(loop r949 a950 b951)");
lf[394]=C_static_lambda_info(C_heaptop,27,"(merge! a945 b946 less\077947)");
lf[395]=C_static_lambda_info(C_heaptop,11,"(step n960)");
lf[396]=C_static_lambda_info(C_heaptop,17,"(do977 p979 i980)");
lf[397]=C_static_lambda_info(C_heaptop,23,"(sort! seq957 less\077958)");
lf[398]=C_h_intern(&lf[398],4,"sort");
lf[399]=C_h_intern(&lf[399],12,"list->vector");
lf[400]=C_h_intern(&lf[400],6,"append");
lf[401]=C_static_lambda_info(C_heaptop,22,"(sort seq985 less\077986)");
lf[402]=C_h_intern(&lf[402],13,"binary-search");
lf[403]=C_h_intern(&lf[403],3,"fx/");
lf[404]=C_static_lambda_info(C_heaptop,18,"(loop ps992 pe993)");
lf[405]=C_static_lambda_info(C_heaptop,30,"(binary-search vec988 proc989)");
tmp=C_fix(307);
C_save(tmp);
tmp=C_fix(617);
C_save(tmp);
tmp=C_fix(1237);
C_save(tmp);
tmp=C_fix(2477);
C_save(tmp);
tmp=C_fix(4957);
C_save(tmp);
tmp=C_fix(9923);
C_save(tmp);
tmp=C_fix(19853);
C_save(tmp);
tmp=C_fix(39709);
C_save(tmp);
tmp=C_fix(79423);
C_save(tmp);
tmp=C_fix(158849);
C_save(tmp);
tmp=C_fix(317701);
C_save(tmp);
tmp=C_fix(635413);
C_save(tmp);
tmp=C_fix(1270849);
C_save(tmp);
tmp=C_fix(2541701);
C_save(tmp);
tmp=C_fix(5083423);
C_save(tmp);
tmp=C_fix(10166857);
C_save(tmp);
tmp=C_fix(20333759);
C_save(tmp);
tmp=C_fix(40667527);
C_save(tmp);
tmp=C_fix(81335063);
C_save(tmp);
tmp=C_fix(162670129);
C_save(tmp);
tmp=C_fix(325340273);
C_save(tmp);
tmp=C_fix(650680571);
C_save(tmp);
tmp=C_fix(1073741823);
C_save(tmp);
lf[407]=C_h_list(23,C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(23);
lf[408]=C_h_intern(&lf[408],11,"hash-table\077");
lf[409]=C_h_intern(&lf[409],10,"hash-table");
lf[410]=C_static_lambda_info(C_heaptop,19,"(hash-table\077 x1000)");
lf[411]=C_h_intern(&lf[411],11,"make-vector");
lf[412]=C_h_intern(&lf[412],15,"make-hash-table");
lf[413]=C_static_lambda_info(C_heaptop,37,"(body1006 test1013 hashf1014 len1015)");
lf[414]=C_static_lambda_info(C_heaptop,42,"(def-len1010 %test10031018 %hashf10041019)");
lf[416]=C_static_lambda_info(C_heaptop,29,"(def-hashf1009 %test10031021)");
lf[417]=C_static_lambda_info(C_heaptop,14,"(def-test1008)");
lf[418]=C_static_lambda_info(C_heaptop,37,"(make-hash-table . test-and-size1002)");
lf[419]=C_h_intern(&lf[419],15,"hash-table-copy");
lf[420]=C_static_lambda_info(C_heaptop,14,"(copy lst1038)");
lf[421]=C_static_lambda_info(C_heaptop,14,"(do1034 i1036)");
lf[422]=C_static_lambda_info(C_heaptop,24,"(hash-table-copy ht1030)");
lf[423]=C_h_intern(&lf[423],31,"hash-table-equivalence-function");
lf[424]=C_static_lambda_info(C_heaptop,40,"(hash-table-equivalence-function ht1044)");
lf[425]=C_h_intern(&lf[425],24,"hash-table-hash-function");
lf[426]=C_static_lambda_info(C_heaptop,33,"(hash-table-hash-function ht1046)");
lf[427]=C_static_lambda_info(C_heaptop,28,"(hash-with-test x1052 d1053)");
lf[428]=C_h_intern(&lf[428],11,"input-port\077");
lf[429]=C_static_lambda_info(C_heaptop,26,"(loop k1063 i1064 len1065)");
lf[430]=C_static_lambda_info(C_heaptop,21,"(rechash x1058 d1059)");
lf[431]=C_h_intern(&lf[431],4,"hash");
lf[432]=C_static_lambda_info(C_heaptop,23,"(%hash x1048 limit1049)");
lf[433]=C_static_lambda_info(C_heaptop,24,"(hash x1071 . g10701072)");
lf[434]=C_h_intern(&lf[434],16,"hash-by-identity");
lf[435]=C_h_intern(&lf[435],11,"string-hash");
lf[436]=C_h_intern(&lf[436],5,"limit");
lf[437]=C_static_lambda_info(C_heaptop,31,"(string-hash s1078 . g10771079)");
lf[438]=C_h_intern(&lf[438],14,"string-ci-hash");
lf[439]=C_static_lambda_info(C_heaptop,34,"(string-ci-hash s1084 . g10831085)");
lf[440]=C_h_intern(&lf[440],15,"hash-table-size");
lf[441]=C_static_lambda_info(C_heaptop,24,"(hash-table-size ht1089)");
lf[442]=C_h_intern(&lf[442],14,"hash-table-ref");
lf[443]=C_static_string(C_heaptop,31,"hash-table does not contain key");
lf[444]=C_static_lambda_info(C_heaptop,8,"(f_7249)");
lf[445]=C_static_lambda_info(C_heaptop,17,"(loop bucket1101)");
lf[446]=C_static_lambda_info(C_heaptop,17,"(loop bucket1105)");
lf[447]=C_static_lambda_info(C_heaptop,45,"(hash-table-ref ht1092 key1093 . default1094)");
lf[448]=C_h_intern(&lf[448],22,"hash-table-ref/default");
lf[449]=C_static_lambda_info(C_heaptop,7,"(a7264)");
lf[450]=C_static_lambda_info(C_heaptop,47,"(hash-table-ref/default ht1110 key1111 def1112)");
lf[451]=C_h_intern(&lf[451],18,"hash-table-exists\077");
lf[452]=C_static_lambda_info(C_heaptop,35,"(hash-table-exists\077 ht1115 key1116)");
lf[453]=C_h_intern(&lf[453],16,"\003syshash-new-len");
lf[454]=C_static_lambda_info(C_heaptop,36,"(##sys#hash-new-len tab1118 req1119)");
lf[455]=C_h_intern(&lf[455],5,"floor");
lf[456]=C_h_intern(&lf[456],18,"hash-table-update!");
lf[457]=C_static_lambda_info(C_heaptop,17,"(loop bucket1196)");
lf[458]=C_static_lambda_info(C_heaptop,14,"(do1192 i1194)");
lf[459]=C_static_lambda_info(C_heaptop,17,"(loop bucket1140)");
lf[460]=C_static_lambda_info(C_heaptop,17,"(loop bucket1145)");
lf[461]=C_flonum(C_heaptop,0.5);
lf[462]=C_static_lambda_info(C_heaptop,9,"(restart)");
lf[463]=C_static_lambda_info(C_heaptop,53,"(hash-table-update! ht1124 key1125 proc1126 init1127)");
lf[464]=C_h_intern(&lf[464],26,"hash-table-update!/default");
lf[465]=C_static_lambda_info(C_heaptop,7,"(a7539)");
lf[466]=C_static_lambda_info(C_heaptop,60,"(hash-table-update!/default ht1152 key1153 func1154 def1155)");
lf[467]=C_h_intern(&lf[467],15,"hash-table-set!");
lf[468]=C_static_lambda_info(C_heaptop,13,"(a7548 x1160)");
lf[469]=C_static_lambda_info(C_heaptop,7,"(a7551)");
lf[470]=C_static_lambda_info(C_heaptop,40,"(hash-table-set! ht1157 key1158 val1159)");
lf[471]=C_h_intern(&lf[471],18,"hash-table-delete!");
lf[472]=C_static_lambda_info(C_heaptop,26,"(loop prev1173 bucket1174)");
lf[473]=C_static_lambda_info(C_heaptop,26,"(loop prev1180 bucket1181)");
lf[474]=C_static_lambda_info(C_heaptop,35,"(hash-table-delete! ht1163 key1164)");
lf[475]=C_h_intern(&lf[475],17,"hash-table-merge!");
lf[476]=C_static_lambda_info(C_heaptop,16,"(do1212 lst1214)");
lf[477]=C_static_lambda_info(C_heaptop,14,"(do1209 i1211)");
lf[478]=C_static_lambda_info(C_heaptop,35,"(hash-table-merge! ht11205 ht21206)");
lf[479]=C_h_intern(&lf[479],17,"hash-table->alist");
lf[480]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1229 lst1230)");
lf[481]=C_static_lambda_info(C_heaptop,20,"(loop i1226 lst1227)");
lf[482]=C_static_lambda_info(C_heaptop,26,"(hash-table->alist ht1222)");
lf[483]=C_h_intern(&lf[483],17,"alist->hash-table");
lf[484]=C_static_lambda_info(C_heaptop,13,"(a7933 x1240)");
lf[485]=C_h_intern(&lf[485],12,"\003sysfor-each");
lf[486]=C_static_lambda_info(C_heaptop,40,"(alist->hash-table alist1237 . rest1238)");
lf[487]=C_h_intern(&lf[487],15,"hash-table-keys");
lf[488]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1249 lst1250)");
lf[489]=C_static_lambda_info(C_heaptop,20,"(loop i1246 lst1247)");
lf[490]=C_static_lambda_info(C_heaptop,24,"(hash-table-keys ht1242)");
lf[491]=C_h_intern(&lf[491],17,"hash-table-values");
lf[492]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1262 lst1263)");
lf[493]=C_static_lambda_info(C_heaptop,20,"(loop i1259 lst1260)");
lf[494]=C_static_lambda_info(C_heaptop,26,"(hash-table-values ht1255)");
lf[495]=C_h_intern(&lf[495],15,"hash-table-walk");
lf[496]=C_static_lambda_info(C_heaptop,18,"(a8114 bucket1275)");
lf[497]=C_static_lambda_info(C_heaptop,14,"(do1272 i1274)");
lf[498]=C_static_lambda_info(C_heaptop,30,"(hash-table-walk ht1268 p1269)");
lf[499]=C_h_intern(&lf[499],15,"hash-table-fold");
lf[500]=C_h_intern(&lf[500],6,"bucket");
lf[501]=C_static_lambda_info(C_heaptop,14,"(fold2 bp1288)");
lf[502]=C_static_lambda_info(C_heaptop,20,"(loop i1285 acc1286)");
lf[503]=C_static_lambda_info(C_heaptop,39,"(hash-table-fold ht1279 p1280 init1281)");
lf[504]=C_h_intern(&lf[504],10,"make-queue");
lf[505]=C_h_intern(&lf[505],5,"queue");
lf[506]=C_static_lambda_info(C_heaptop,12,"(make-queue)");
lf[507]=C_h_intern(&lf[507],6,"queue\077");
lf[508]=C_static_lambda_info(C_heaptop,14,"(queue\077 x1292)");
lf[509]=C_h_intern(&lf[509],12,"queue-empty\077");
lf[510]=C_static_lambda_info(C_heaptop,20,"(queue-empty\077 q1293)");
lf[511]=C_h_intern(&lf[511],11,"queue-first");
lf[512]=C_static_string(C_heaptop,14,"queue is empty");
lf[513]=C_static_lambda_info(C_heaptop,19,"(queue-first q1295)");
lf[514]=C_h_intern(&lf[514],10,"queue-last");
lf[515]=C_static_string(C_heaptop,14,"queue is empty");
lf[516]=C_static_lambda_info(C_heaptop,18,"(queue-last q1299)");
lf[517]=C_h_intern(&lf[517],10,"queue-add!");
lf[518]=C_static_lambda_info(C_heaptop,28,"(queue-add! q1303 datum1304)");
lf[519]=C_h_intern(&lf[519],13,"queue-remove!");
lf[520]=C_static_string(C_heaptop,14,"queue is empty");
lf[521]=C_static_lambda_info(C_heaptop,21,"(queue-remove! q1309)");
lf[522]=C_h_intern(&lf[522],11,"queue->list");
lf[523]=C_static_lambda_info(C_heaptop,19,"(queue->list q1316)");
lf[524]=C_h_intern(&lf[524],11,"list->queue");
lf[525]=C_static_lambda_info(C_heaptop,16,"(do1319 lst1321)");
lf[526]=C_static_lambda_info(C_heaptop,22,"(list->queue lst01318)");
lf[527]=C_h_intern(&lf[527],17,"register-feature!");
lf[528]=C_h_intern(&lf[528],7,"srfi-69");
lf[529]=C_h_intern(&lf[529],7,"srfi-28");
lf[530]=C_h_intern(&lf[530],14,"make-parameter");
lf[531]=C_h_intern(&lf[531],6,"extras");
lf[532]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,533);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 105  register-feature! */
t4=*((C_word*)lf[527]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[531]);}

/* k1439 */
static void f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word ab[157],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=*((C_word*)lf[4]+1);
t5=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1443,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=lf[15],tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=lf[17],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1581,a[2]=lf[20],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1589,a[2]=lf[24],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=lf[28],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=lf[32],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1682,a[2]=lf[35],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1690,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=lf[47],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=lf[58],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=lf[61],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1874,a[2]=lf[65],tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[3]+1);
t22=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=t21,a[3]=lf[70],tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=lf[74],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=lf[98],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=lf[109],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=lf[111],tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[112]+1);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp);
t33=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t31,a[3]=t32,a[4]=lf[124],tmp=(C_word)a,a+=5,tmp));
t34=*((C_word*)lf[115]+1);
t35=*((C_word*)lf[4]+1);
t36=*((C_word*)lf[3]+1);
t37=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2734,a[2]=t35,a[3]=t34,a[4]=t36,a[5]=lf[128],tmp=(C_word)a,a+=6,tmp));
t38=*((C_word*)lf[129]+1);
t39=*((C_word*)lf[130]+1);
t40=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2826,a[2]=t38,a[3]=t39,a[4]=lf[137],tmp=(C_word)a,a+=5,tmp));
t41=*((C_word*)lf[129]+1);
t42=*((C_word*)lf[130]+1);
t43=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=t41,a[3]=t42,a[4]=lf[142],tmp=(C_word)a,a+=5,tmp));
t44=*((C_word*)lf[143]+1);
t45=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3010,a[2]=t44,a[3]=lf[149],tmp=(C_word)a,a+=4,tmp));
t46=*((C_word*)lf[143]+1);
t47=*((C_word*)lf[150]+1);
t48=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=t46,a[3]=t47,a[4]=lf[152],tmp=(C_word)a,a+=5,tmp));
t49=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3120,a[2]=lf[158],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=lf[164],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=lf[171],tmp=(C_word)a,a+=3,tmp));
t52=*((C_word*)lf[172]+1);
t53=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3195,a[2]=t52,a[3]=lf[174],tmp=(C_word)a,a+=4,tmp));
t54=*((C_word*)lf[129]+1);
t55=*((C_word*)lf[130]+1);
t56=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3204,a[2]=t54,a[3]=t55,a[4]=lf[176],tmp=(C_word)a,a+=5,tmp));
t57=*((C_word*)lf[172]+1);
t58=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3216,a[2]=t57,a[3]=lf[181],tmp=(C_word)a,a+=4,tmp));
t59=*((C_word*)lf[129]+1);
t60=*((C_word*)lf[130]+1);
t61=C_mutate((C_word*)lf[182]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=t59,a[3]=t60,a[4]=lf[186],tmp=(C_word)a,a+=5,tmp));
t62=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=lf[195],tmp=(C_word)a,a+=3,tmp));
t63=*((C_word*)lf[196]+1);
t64=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3350,a[2]=t63,a[3]=lf[203],tmp=(C_word)a,a+=4,tmp));
t65=*((C_word*)lf[129]+1);
t66=*((C_word*)lf[130]+1);
t67=C_mutate(&lf[204],(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3408,a[2]=t65,a[3]=t66,a[4]=lf[308],tmp=(C_word)a,a+=5,tmp));
t68=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=lf[311],tmp=(C_word)a,a+=3,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 887  make-parameter */
t70=*((C_word*)lf[530]+1);
((C_proc3)C_retrieve_proc(t70))(3,t70,t69,C_fix(79));}

/* k4735 in k1439 */
static void f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[73],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=C_mutate((C_word*)lf[312]+1,t1);
t3=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=lf[316],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[317]+1,*((C_word*)lf[313]+1));
t5=*((C_word*)lf[129]+1);
t6=*((C_word*)lf[143]+1);
t7=*((C_word*)lf[130]+1);
t8=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4768,a[2]=t5,a[3]=t6,a[4]=t7,a[5]=lf[320],tmp=(C_word)a,a+=6,tmp));
t9=*((C_word*)lf[247]+1);
t10=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4804,a[2]=t9,a[3]=lf[322],tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4814,a[2]=lf[324],tmp=(C_word)a,a+=3,tmp);
t12=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t11,a[3]=lf[327],tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4880,a[2]=t11,a[3]=lf[330],tmp=(C_word)a,a+=4,tmp));
t14=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4899,a[2]=lf[332],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=lf[334],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4961,a[2]=lf[336],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5025,a[2]=lf[338],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5089,a[2]=lf[344],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5224,a[2]=lf[351],tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[112]+1);
t21=*((C_word*)lf[352]+1);
t22=C_mutate((C_word*)lf[353]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5339,a[2]=t21,a[3]=t20,a[4]=lf[360],tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5541,a[2]=lf[365],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5663,a[2]=lf[368],tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[369]+1);
t26=*((C_word*)lf[150]+1);
t27=*((C_word*)lf[143]+1);
t28=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5727,a[2]=t26,a[3]=t27,a[4]=t25,a[5]=lf[379],tmp=(C_word)a,a+=6,tmp));
t29=*((C_word*)lf[370]+1);
t30=*((C_word*)lf[315]+1);
t31=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5983,a[2]=t30,a[3]=t29,a[4]=lf[381],tmp=(C_word)a,a+=5,tmp));
t32=*((C_word*)lf[129]+1);
t33=*((C_word*)lf[130]+1);
t34=*((C_word*)lf[370]+1);
t35=C_mutate((C_word*)lf[382]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5993,a[2]=t32,a[3]=t34,a[4]=t33,a[5]=lf[383],tmp=(C_word)a,a+=6,tmp));
t36=C_mutate((C_word*)lf[384]+1,*((C_word*)lf[382]+1));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1235 register-feature! */
t38=*((C_word*)lf[527]+1);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,lf[529]);}

/* k6005 in k4735 in k1439 */
static void f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word ab[107],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
t2=C_mutate((C_word*)lf[385]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6009,a[2]=lf[388],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6118,a[2]=lf[391],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[392]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6217,a[2]=lf[394],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6349,a[2]=lf[397],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[398]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6482,a[2]=lf[401],tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[399]+1);
t8=C_mutate((C_word*)lf[402]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6509,a[2]=t7,a[3]=lf[405],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[406],lf[407]);
t10=C_mutate((C_word*)lf[408]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6596,a[2]=lf[410],tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[411]+1);
t12=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6602,a[2]=t11,a[3]=lf[418],tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[411]+1);
t14=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6689,a[2]=t13,a[3]=lf[422],tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6784,a[2]=lf[424],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6793,a[2]=lf[426],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[415],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6802,a[2]=lf[432],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[431]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7034,a[2]=lf[433],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[434]+1,*((C_word*)lf[431]+1));
t20=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7066,a[2]=lf[437],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7095,a[2]=lf[439],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7124,a[2]=lf[441],tmp=(C_word)a,a+=3,tmp));
t23=*((C_word*)lf[91]+1);
t24=C_mutate((C_word*)lf[442]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7133,a[2]=t23,a[3]=lf[447],tmp=(C_word)a,a+=4,tmp));
t25=*((C_word*)lf[442]+1);
t26=C_mutate((C_word*)lf[448]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7259,a[2]=t25,a[3]=lf[450],tmp=(C_word)a,a+=4,tmp));
t27=(C_word)C_a_i_vector(&a,1,C_fix(42));
t28=*((C_word*)lf[442]+1);
t29=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7271,a[2]=t28,a[3]=t27,a[4]=lf[452],tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7288,a[2]=lf[454],tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[91]+1);
t32=*((C_word*)lf[455]+1);
t33=C_mutate((C_word*)lf[456]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7321,a[2]=t32,a[3]=t31,a[4]=lf[463],tmp=(C_word)a,a+=5,tmp));
t34=*((C_word*)lf[456]+1);
t35=C_mutate((C_word*)lf[464]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7534,a[2]=t34,a[3]=lf[466],tmp=(C_word)a,a+=4,tmp));
t36=*((C_word*)lf[456]+1);
t37=C_mutate((C_word*)lf[467]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7543,a[2]=t36,a[3]=lf[470],tmp=(C_word)a,a+=4,tmp));
t38=*((C_word*)lf[91]+1);
t39=*((C_word*)lf[455]+1);
t40=C_mutate((C_word*)lf[471]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t38,a[3]=lf[474],tmp=(C_word)a,a+=4,tmp));
t41=*((C_word*)lf[467]+1);
t42=C_mutate((C_word*)lf[475]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7781,a[2]=t41,a[3]=lf[478],tmp=(C_word)a,a+=4,tmp));
t43=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7852,a[2]=lf[482],tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[412]+1);
t45=*((C_word*)lf[467]+1);
t46=C_mutate((C_word*)lf[483]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7925,a[2]=t44,a[3]=t45,a[4]=lf[486],tmp=(C_word)a,a+=5,tmp));
t47=C_mutate((C_word*)lf[487]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7948,a[2]=lf[490],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[491]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8013,a[2]=lf[494],tmp=(C_word)a,a+=3,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1762 register-feature! */
t50=*((C_word*)lf[527]+1);
((C_proc3)C_retrieve_proc(t50))(3,t50,t49,lf[528]);}

/* k8077 in k6005 in k4735 in k1439 */
static void f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8079,2,t0,t1);}
t2=C_mutate((C_word*)lf[495]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8081,a[2]=lf[498],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[499]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8133,a[2]=lf[503],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[504]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8195,a[2]=lf[506],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[507]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=lf[508],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[509]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8207,a[2]=lf[510],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[511]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8220,a[2]=lf[513],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8241,a[2]=lf[516],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8262,a[2]=lf[518],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8294,a[2]=lf[521],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8330,a[2]=lf[523],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8339,a[2]=lf[526],tmp=(C_word)a,a+=3,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* list->queue in k8077 in k6005 in k4735 in k1439 */
static void f_8339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8339,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[524]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8350,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_8350(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8358,a[2]=t2,a[3]=t7,a[4]=lf[525],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_8358(t9,t4,t2);}}

/* do1319 in list->queue in k8077 in k6005 in k4735 in k1439 */
static void C_fcall f_8358(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8358,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8368,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* extras.scm: 1875 ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[524]);}
else{
t8=t5;
f_8368(2,t8,C_SCHEME_UNDEFINED);}}}

/* k8366 in do1319 in list->queue in k8077 in k6005 in k4735 in k1439 */
static void f_8368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8358(t3,((C_word*)t0)[2],t2);}

/* k8348 in list->queue in k8077 in k6005 in k4735 in k1439 */
static void f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[505],((C_word*)t0)[2],t1));}

/* queue->list in k8077 in k6005 in k4735 in k1439 */
static void f_8330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8330,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[505],lf[522]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k8077 in k6005 in k4735 in k1439 */
static void f_8294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8294,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[505],lf[519]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8304,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1853 ##sys#error */
t7=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[519],lf[520],t2);}
else{
t7=t5;
f_8304(2,t7,C_SCHEME_UNDEFINED);}}

/* k8302 in queue-remove! in k8077 in k6005 in k4735 in k1439 */
static void f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k8077 in k6005 in k4735 in k1439 */
static void f_8262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8262,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[505],lf[517]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8272,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_8272(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_8272(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k8270 in queue-add! in k8077 in k6005 in k4735 in k1439 */
static void C_fcall f_8272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k8077 in k6005 in k4735 in k1439 */
static void f_8241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8241,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[505],lf[514]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8251,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1834 ##sys#error */
t7=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[514],lf[515],t2);}
else{
t7=t5;
f_8251(2,t7,C_SCHEME_UNDEFINED);}}

/* k8249 in queue-last in k8077 in k6005 in k4735 in k1439 */
static void f_8251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k8077 in k6005 in k4735 in k1439 */
static void f_8220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8220,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[505],lf[511]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8230,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1823 ##sys#error */
t7=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[511],lf[512],t2);}
else{
t7=t5;
f_8230(2,t7,C_SCHEME_UNDEFINED);}}

/* k8228 in queue-first in k8077 in k6005 in k4735 in k1439 */
static void f_8230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k8077 in k6005 in k4735 in k1439 */
static void f_8207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8207,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[505],lf[509]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k8077 in k6005 in k4735 in k1439 */
static void f_8201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8201,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[505]));}

/* make-queue in k8077 in k6005 in k4735 in k1439 */
static void f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8195,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[505],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* hash-table-fold in k8077 in k6005 in k4735 in k1439 */
static void f_8133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8133,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[409],lf[499]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_block_size(t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=t3,a[3]=t9,a[4]=t6,a[5]=t7,a[6]=lf[502],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_8148(t11,t1,C_fix(0),t4);}

/* loop in hash-table-fold in k8077 in k6005 in k4735 in k1439 */
static void C_fcall f_8148(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8148,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=lf[501],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_8164(t8,t1,t4);}}

/* fold2 in loop in hash-table-fold in k8077 in k6005 in k4735 in k1439 */
static void C_fcall f_8164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8164,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1789 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_8148(t4,t1,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8185,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(*((C_word*)lf[500]+1),C_fix(0));
t5=(C_word)C_slot(*((C_word*)lf[500]+1),C_fix(1));
/* extras.scm: 1790 p */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,t4,t5,((C_word*)t0)[4]);}}

/* k8183 in fold2 in loop in hash-table-fold in k8077 in k6005 in k4735 in k1439 */
static void f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1790 fold2 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8164(t2,((C_word*)t0)[2],t1);}

/* hash-table-walk in k8077 in k6005 in k4735 in k1439 */
static void f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8081,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[409],lf[495]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8096,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t6,a[6]=lf[497],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8096(t10,t1,C_fix(0));}

/* do1272 in hash-table-walk in k8077 in k6005 in k4735 in k1439 */
static void C_fcall f_8096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8096,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8106,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[3],a[3]=lf[496],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* extras.scm: 1774 ##sys#for-each */
t6=*((C_word*)lf[485]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a8114 in do1272 in hash-table-walk in k8077 in k6005 in k4735 in k1439 */
static void f_8115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8115,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1775 p */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k8104 in do1272 in hash-table-walk in k8077 in k6005 in k4735 in k1439 */
static void f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8096(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k6005 in k4735 in k1439 */
static void f_8013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8013,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[491]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8028,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[493],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8028(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k6005 in k4735 in k1439 */
static void C_fcall f_8028(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8028,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8044,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[492],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8044(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k6005 in k4735 in k1439 */
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8044,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1757 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8028(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1758 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k6005 in k4735 in k1439 */
static void f_7948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7948,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[487]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7963,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[489],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7963(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k6005 in k4735 in k1439 */
static void C_fcall f_7963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7963,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7979,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[488],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7979(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k6005 in k4735 in k1439 */
static void C_fcall f_7979(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7979,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1743 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7963(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1744 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k6005 in k4735 in k1439 */
static void f_7925(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7925r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7925r(t0,t1,t2,t3);}}

static void f_7925r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7929,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t3);}

/* k7927 in alist->hash-table in k6005 in k4735 in k1439 */
static void f_7929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7932,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7934,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[484],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[485]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7933 in k7927 in alist->hash-table in k6005 in k4735 in k1439 */
static void f_7934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7934,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* extras.scm: 1731 hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* k7930 in k7927 in alist->hash-table in k6005 in k4735 in k1439 */
static void f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k6005 in k4735 in k1439 */
static void f_7852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7852,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[479]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7867,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[481],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7867(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k6005 in k4735 in k1439 */
static void C_fcall f_7867(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7867,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7883,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[480],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7883(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k6005 in k4735 in k1439 */
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7883,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1721 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7867(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* extras.scm: 1722 loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge! in k6005 in k4735 in k1439 */
static void f_7781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7781,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[409],lf[475]);
t5=(C_word)C_i_check_structure_2(t3,lf[409],lf[475]);
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_block_size(t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t9,a[5]=t2,a[6]=t7,a[7]=lf[477],tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_7799(t11,t1,C_fix(0));}

/* do1209 in hash-table-merge! in k6005 in k4735 in k1439 */
static void C_fcall f_7799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7799,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7809,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7822,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=lf[476],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7822(t8,t3,t4);}}

/* do1212 in do1209 in hash-table-merge! in k6005 in k4735 in k1439 */
static void C_fcall f_7822(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7822,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7835,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1707 hash-table-set! */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,((C_word*)t0)[2],t5,t6);}}

/* k7833 in do1212 in do1209 in hash-table-merge! in k6005 in k4735 in k1439 */
static void f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7822(t3,((C_word*)t0)[2],t2);}

/* k7807 in do1209 in hash-table-merge! in k6005 in k4735 in k1439 */
static void f_7809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7799(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k6005 in k4735 in k1439 */
static void f_7555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7555,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[409],lf[471]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(4));
t7=(C_word)C_block_size(t5);
t8=(C_word)C_slot(t2,C_fix(3));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7574,a[2]=t1,a[3]=t3,a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1649 hashf */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t3,t7);}

/* k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7574,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[6],t1);
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7591,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=lf[472],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7591(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=lf[473],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_7646(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}}

/* loop in k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7646,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1672 test */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k7660 in loop in k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7662,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7665,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=t2;
f_7665(t4,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=t2;
f_7665(t4,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),t3));}}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1679 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7646(t3,((C_word*)t0)[7],((C_word*)t0)[5],t2);}}

/* k7663 in k7660 in loop in k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void C_fcall f_7665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* loop in k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void C_fcall f_7591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7591,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7610,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_slot(t3,C_fix(1));
t9=t7;
f_7610(t9,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t8));}
else{
t8=(C_word)C_slot(t3,C_fix(1));
t9=t7;
f_7610(t9,(C_word)C_i_setslot(t2,C_fix(1),t8));}}
else{
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1666 loop */
t12=t1;
t13=t3;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k7608 in loop in k7572 in hash-table-delete! in k6005 in k4735 in k1439 */
static void C_fcall f_7610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* hash-table-set! in k6005 in k4735 in k1439 */
static void f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7543,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7549,a[2]=t4,a[3]=lf[468],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7552,a[2]=t4,a[3]=lf[469],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1638 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)C_retrieve_proc(t7))(6,t7,t1,t2,t3,t5,t6);}

/* a7551 in hash-table-set! in k6005 in k4735 in k1439 */
static void f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a7548 in hash-table-set! in k6005 in k4735 in k1439 */
static void f_7549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7549,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* hash-table-update!/default in k6005 in k4735 in k1439 */
static void f_7534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc(c,6);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7534,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7540,a[2]=t5,a[3]=lf[465],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1633 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)C_retrieve_proc(t7))(6,t7,t1,t2,t3,t4,t6);}

/* a7539 in hash-table-update!/default in k6005 in k4735 in k1439 */
static void f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k6005 in k4735 in k1439 */
static void f_7321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc(c,6);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7321,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[409],lf[456]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t8,a[8]=t2,a[9]=lf[462],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_7330(t10,t1);}

/* restart in hash-table-update! in k6005 in k4735 in k1439 */
static void C_fcall f_7330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7330,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t4=(C_word)C_block_size(t2);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* extras.scm: 1597 hashf */
t7=t3;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],t4);}

/* k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7346,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(2));
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[12],lf[461]);
/* extras.scm: 1599 floor */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7524,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[14],t2);
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(((C_word*)t0)[13],C_fix(1073741823)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7358,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7371,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_times(((C_word*)t0)[13],C_fix(2));
t8=(C_word)C_i_fixnum_min(C_fix(1073741823),t7);
/* extras.scm: 1602 ##sys#hash-new-len */
t9=*((C_word*)lf[453]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,lf[407],t8);}
else{
t5=(C_word)C_slot(((C_word*)t0)[9],((C_word*)t0)[7]);
t6=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7393,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=t5,a[10]=((C_word*)t0)[4],a[11]=lf[459],tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_7393(t10,((C_word*)t0)[10],t5);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7454,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=t5,a[11]=((C_word*)t0)[4],a[12]=lf[460],tmp=(C_word)a,a+=13,tmp));
t10=((C_word*)t8)[1];
f_7454(t10,((C_word*)t0)[10],t5);}}}

/* loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void C_fcall f_7454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7454,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 1622 init */
t5=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7488,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1626 test */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[11],t6);}}

/* k7486 in loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1627 proc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1628 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7454(t3,((C_word*)t0)[6],t2);}}

/* k7493 in k7486 in loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* k7477 in loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void C_fcall f_7393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7393,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7418,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 1613 init */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[10],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7434,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 1618 proc */
t9=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1619 loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* k7432 in loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* k7416 in loop in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7418,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* k7369 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1601 make-vector */
t2=*((C_word*)lf[411]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7361,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=t1;
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7714,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,a[8]=lf[458],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7714(t9,t2,C_fix(0));}

/* do1192 in k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void C_fcall f_7714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7714,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7724,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=lf[457],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_7737(t8,t3,t4);}}

/* loop in do1192 in k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7737,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7753,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1691 hashf */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k7751 in loop in do1192 in k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1693 loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_7737(t8,((C_word*)t0)[2],t7);}

/* k7722 in do1192 in k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7714(t3,((C_word*)t0)[2],t2);}

/* k7359 in k7356 in k7522 in k7344 in restart in hash-table-update! in k6005 in k4735 in k1439 */
static void f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* extras.scm: 1607 restart */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7330(t3,((C_word*)t0)[2]);}

/* ##sys#hash-new-len in k6005 in k4735 in k1439 */
static void f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7288,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_fixnum_greater_or_equal_p(t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7298,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_7298(t7,t5);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t6;
f_7298(t8,(C_word)C_eqp(t7,C_SCHEME_END_OF_LIST));}}

/* k7296 in ##sys#hash-new-len in k6005 in k4735 in k1439 */
static void C_fcall f_7298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1584 ##sys#hash-new-len */
t3=*((C_word*)lf[453]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* hash-table-exists? in k6005 in k4735 in k1439 */
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7271,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[409],lf[442]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7286,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1578 ref */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)t0)[3]);}

/* k7284 in hash-table-exists? in k6005 in k4735 in k1439 */
static void f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k6005 in k4735 in k1439 */
static void f_7259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7259,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=t4,a[3]=lf[449],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1571 hash-table-ref */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t3,t5);}

/* a7264 in hash-table-ref/default in k6005 in k4735 in k1439 */
static void f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7265,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-ref in k6005 in k4735 in k1439 */
static void f_7133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7133r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7133r(t0,t1,t2,t3,t4);}}

static void f_7133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_structure_2(t2,lf[409],lf[442]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7146,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_block_size(t6);
/* extras.scm: 1546 hashf */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k7144 in hash-table-ref in k6005 in k4735 in k1439 */
static void f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=lf[444],tmp=(C_word)a,a+=5,tmp));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7167,a[2]=t8,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=lf[445],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7167(t10,((C_word*)t0)[2],t6);}
else{
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7209,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t8,a[5]=t3,a[6]=lf[446],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_7209(t10,((C_word*)t0)[2],t6);}}

/* loop in k7144 in hash-table-ref in k6005 in k4735 in k1439 */
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7209,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1562 def */
t4=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7228,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1564 test */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k7226 in loop in k7144 in hash-table-ref in k6005 in k4735 in k1439 */
static void f_7228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1566 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7209(t3,((C_word*)t0)[5],t2);}}

/* loop in k7144 in hash-table-ref in k6005 in k4735 in k1439 */
static void C_fcall f_7167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7167,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1555 def */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_slot(t4,C_fix(1)));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1559 loop */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* f_7249 in k7144 in hash-table-ref in k6005 in k4735 in k1439 */
static void f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
/* ##sys#error */
t2=*((C_word*)lf[14]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[442],lf[443],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-size in k6005 in k4735 in k1439 */
static void f_7124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7124,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[440]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* string-ci-hash in k6005 in k4735 in k1439 */
static void f_7095(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7095r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7095r(t0,t1,t2,t3);}}

static void f_7095r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7099(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7099(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7097 in string-ci-hash in k6005 in k4735 in k1439 */
static void f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix(16777215),(C_word)C_hash_string_ci(((C_word*)t0)[3]));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,*((C_word*)lf[436]+1)));}

/* string-hash in k6005 in k4735 in k1439 */
static void f_7066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7066r(t0,t1,t2,t3);}}

static void f_7066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7070,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7070(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7070(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7068 in string-hash in k6005 in k4735 in k1439 */
static void f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix(16777215),(C_word)C_hash_string(((C_word*)t0)[3]));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,*((C_word*)lf[436]+1)));}

/* hash in k6005 in k4735 in k1439 */
static void f_7034(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7034r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7034r(t0,t1,t2,t3);}}

static void f_7034r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7038,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7038(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7038(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7036 in hash in k6005 in k4735 in k1439 */
static void f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(t1,lf[431]);
/* extras.scm: 1517 %hash */
t3=lf[415];
f_6802(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* %hash in k6005 in k4735 in k1439 */
static void f_6802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6802,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=t7,a[3]=lf[427],tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6830,a[2]=t7,a[3]=t5,a[4]=lf[430],tmp=(C_word)a,a+=5,tmp));
t10=(C_word)C_i_check_exact_2(t3,lf[431]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1513 rechash */
t12=((C_word*)t7)[1];
f_6830(t12,t11,t2,C_fix(0));}

/* k7030 in %hash in k6005 in k4735 in k1439 */
static void f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix(16777215),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,((C_word*)t0)[2]));}

/* rechash in %hash in k6005 in k4735 in k1439 */
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6830,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
case C_SCHEME_END_OF_LIST:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));
default:
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hashptr(t2));}
else{
if(C_truep((C_word)C_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1495 hash-with-test */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6805(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6932,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1497 hash-with-test */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6805(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6945,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1499 input-port? */
t5=*((C_word*)lf[428]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
t4=(C_word)C_block_size(t2);
t5=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t6=(C_truep((C_word)C_specialp(t2))?(C_word)C_peek_fixnum(t2,C_fix(0)):C_fix(0));
t7=(C_word)C_fixnum_plus(t4,t6);
t8=(C_word)C_fixnum_greaterp(t4,C_fix(4));
t9=(C_truep(t8)?C_fix(4):t4);
t10=(C_word)C_fixnum_difference(t9,t5);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6967,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t12,a[6]=lf[429],tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_6967(t14,t1,t7,t5,t10);}}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}

/* loop in rechash in %hash in k6005 in k4735 in k1439 */
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6967,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_times(t2,C_fix(16));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7002,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1509 rechash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6830(t10,t7,t8,t9);}}

/* k7000 in loop in rechash in %hash in k6005 in k4735 in k1439 */
static void f_7002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_fix(t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],t3);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1509 loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6967(t7,((C_word*)t0)[2],t4,t5,t6);}

/* k6943 in rechash in %hash in k6005 in k4735 in k1439 */
static void f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fix(260):C_fix(261)));}

/* k6930 in rechash in %hash in k6005 in k4735 in k1439 */
static void f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(C_word)C_a_i_arithmetic_shift(&a,2,t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1498 hash-with-test */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6805(t5,t3,t4,((C_word*)t0)[2]);}

/* k6922 in k6930 in rechash in %hash in k6005 in k4735 in k1439 */
static void f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k6901 in rechash in %hash in k6005 in k4735 in k1439 */
static void f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* hash-with-test in %hash in k6005 in k4735 in k1439 */
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6805,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6815,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_6815(t6,t4);}
else{
t6=(C_word)C_byteblockp(t2);
t7=t5;
f_6815(t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}

/* k6813 in hash-with-test in %hash in k6005 in k4735 in k1439 */
static void C_fcall f_6815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1482 rechash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6830(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* hash-table-hash-function in k6005 in k4735 in k1439 */
static void f_6793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6793,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[425]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k6005 in k4735 in k1439 */
static void f_6784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6784,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[423]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-copy in k6005 in k4735 in k1439 */
static void f_6689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6689,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[409],lf[419]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6702,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1447 make-vector */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t5,C_SCHEME_END_OF_LIST);}

/* k6700 in hash-table-copy in k6005 in k4735 in k1439 */
static void f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6707,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[421],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6707(t5,((C_word*)t0)[2],C_fix(0));}

/* do1034 in k6700 in hash-table-copy in k6005 in k4735 in k1439 */
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6707,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,5,lf[409],((C_word*)t0)[4],t3,t4,t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6743,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6749,a[2]=t6,a[3]=lf[420],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6749(t8,t3,t4);}}

/* copy in do1034 in k6700 in hash-table-copy in k6005 in k4735 in k1439 */
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6749,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6770,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1459 copy */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k6768 in copy in do1034 in k6700 in hash-table-copy in k6005 in k4735 in k1439 */
static void f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6741 in do1034 in k6700 in hash-table-copy in k6005 in k4735 in k1439 */
static void f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6707(t4,((C_word*)t0)[2],t3);}

/* make-hash-table in k6005 in k4735 in k1439 */
static void f_6602(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr2r,(void*)f_6602r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6602r(t0,t1,t2);}}

static void f_6602r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(16);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=lf[413],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6616,a[2]=t3,a[3]=lf[414],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6621,a[2]=t4,a[3]=lf[416],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6626,a[2]=t5,a[3]=lf[417],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-test10081022 */
t7=t6;
f_6626(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-hashf10091020 */
t9=t5;
f_6621(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-len10101017 */
t11=t4;
f_6616(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10061012 */
t13=t3;
f_6604(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-test1008 in make-hash-table in k6005 in k4735 in k1439 */
static void C_fcall f_6626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6626,NULL,2,t0,t1);}
/* def-hashf10091020 */
t2=((C_word*)t0)[2];
f_6621(t2,t1,*((C_word*)lf[94]+1));}

/* def-hashf1009 in make-hash-table in k6005 in k4735 in k1439 */
static void C_fcall f_6621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6621,NULL,3,t0,t1,t2);}
/* def-len10101017 */
t3=((C_word*)t0)[2];
f_6616(t3,t1,t2,lf[415]);}

/* def-len1010 in make-hash-table in k6005 in k4735 in k1439 */
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6616,NULL,4,t0,t1,t2,t3);}
/* body10061012 */
t4=((C_word*)t0)[2];
f_6604(t4,t1,t2,t3,C_fix(307));}

/* body1006 in make-hash-table in k6005 in k4735 in k1439 */
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(t4,lf[412]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6615,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1439 make-vector */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,C_SCHEME_END_OF_LIST);}

/* k6613 in body1006 in make-hash-table in k6005 in k4735 in k1439 */
static void f_6615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6615,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,5,lf[409],t1,C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]));}

/* hash-table? in k6005 in k4735 in k1439 */
static void f_6596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6596,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[409]));}

/* binary-search in k6005 in k4735 in k1439 */
static void f_6509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6509,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6513,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6590,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1395 list->vector */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_6513(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[402]));}}

/* k6588 in binary-search in k6005 in k4735 in k1439 */
static void f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6513(t3,t2);}

/* k6511 in binary-search in k6005 in k4735 in k1439 */
static void C_fcall f_6513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6513,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=lf[404],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6527(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k6511 in binary-search in k6005 in k4735 in k1439 */
static void C_fcall f_6527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6527,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_difference(t3,t2);
/* extras.scm: 1401 fx/ */
t6=*((C_word*)lf[403]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,C_fix(2));}

/* k6577 in loop in k6511 in binary-search in k6005 in k4735 in k1439 */
static void f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6579,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1403 proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6535 in k6577 in loop in k6511 in binary-search in k6005 in k4735 in k1439 */
static void f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1405 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6527(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1406 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6527(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k6005 in k4735 in k1439 */
static void f_6482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6482,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6500,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1385 vector->list */
t6=*((C_word*)lf[228]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6507,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1386 append */
t5=*((C_word*)lf[400]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k6505 in sort in k6005 in k4735 in k1439 */
static void f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1386 sort! */
t2=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6498 in sort in k6005 in k4735 in k1439 */
static void f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1385 sort! */
t2=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6494 in sort in k6005 in k4735 in k1439 */
static void f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1385 list->vector */
t2=*((C_word*)lf[399]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k6005 in k4735 in k1439 */
static void f_6349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6349,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6352,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=lf[395],tmp=(C_word)a,a+=6,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_i_vector_length(((C_word*)t4)[1]);
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6439,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1368 vector->list */
t11=*((C_word*)lf[228]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* extras.scm: 1374 step */
t9=((C_word*)t6)[1];
f_6352(t9,t1,t8);}}

/* k6437 in sort! in k6005 in k4735 in k1439 */
static void f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1369 step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6352(t4,t3,((C_word*)t0)[2]);}

/* k6444 in k6437 in sort! in k6005 in k4735 in k1439 */
static void f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6446,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6448,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[396],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6448(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do977 in k6444 in k6437 in sort! in k6005 in k4735 in k1439 */
static void C_fcall f_6448(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6448,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k6005 in k4735 in k1439 */
static void C_fcall f_6352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6352,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6393,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6403,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1353 less? */
t10=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k6401 in step in sort! in k6005 in k4735 in k1439 */
static void f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_car(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
f_6393(t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6393(t2,C_SCHEME_UNDEFINED);}}

/* k6391 in step in sort! in k6005 in k4735 in k1439 */
static void C_fcall f_6393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k6360 in step in sort! in k6005 in k4735 in k1439 */
static void f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1344 step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6352(t3,t2,t1);}

/* k6363 in k6360 in step in sort! in k6005 in k4735 in k1439 */
static void f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1346 step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6352(t4,t3,t2);}

/* k6369 in k6363 in k6360 in step in sort! in k6005 in k4735 in k1439 */
static void f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1347 merge! */
t2=*((C_word*)lf[392]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k6005 in k4735 in k1439 */
static void f_6217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6217,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t4,a[3]=t6,a[4]=lf[393],tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6299,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* extras.scm: 1321 less? */
t11=t4;
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* k6297 in merge! in k6005 in k4735 in k1439 */
static void f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_6302(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* extras.scm: 1324 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6220(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_6322(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1329 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6220(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k6320 in k6297 in merge! in k6005 in k4735 in k1439 */
static void f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6300 in k6297 in merge! in k6005 in k4735 in k1439 */
static void f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k6005 in k4735 in k1439 */
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6220,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_car(t3);
/* extras.scm: 1306 less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k6225 in loop in merge! in k6005 in k4735 in k1439 */
static void f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* extras.scm: 1311 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6220(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1317 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6220(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k6005 in k4735 in k1439 */
static void f_6118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6118,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6152,a[2]=t4,a[3]=t10,a[4]=lf[390],tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_6152(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k6005 in k4735 in k1439 */
static void C_fcall f_6152(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6152,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6159,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1289 less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* k6157 in loop in merge in k6005 in k4735 in k1439 */
static void f_6159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6159,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* extras.scm: 1292 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6152(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* extras.scm: 1296 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6152(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k6205 in k6157 in loop in merge in k6005 in k4735 in k1439 */
static void f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6177 in k6157 in loop in merge in k6005 in k4735 in k1439 */
static void f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k6005 in k4735 in k1439 */
static void f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6009,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6036,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=lf[386],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6036(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6084,a[2]=t3,a[3]=t7,a[4]=lf[387],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_6084(t9,t1,t4,t5);}}}

/* loop in sorted? in k6005 in k4735 in k1439 */
static void C_fcall f_6084(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6084,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6112,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* extras.scm: 1272 less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* k6110 in loop in sorted? in k6005 in k4735 in k1439 */
static void f_6112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1273 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6084(t4,((C_word*)t0)[4],t2,t3);}}

/* do924 in sorted? in k6005 in k4735 in k1439 */
static void C_fcall f_6036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6036,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6046(2,t5,t3);}
else{
t5=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[3],t6);
/* extras.scm: 1266 less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k6044 in do924 in sorted? in k6005 in k4735 in k1439 */
static void f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6046,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_6036(t3,((C_word*)t0)[5],t2);}}

/* sprintf in k4735 in k1439 */
static void f_5993(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5993r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5993r(t0,t1,t2,t3);}}

static void f_5993r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5997,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1229 open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5995 in sprintf in k4735 in k1439 */
static void f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6000,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_apply(6,0,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5998 in k5995 in sprintf in k4735 in k1439 */
static void f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1231 get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* printf in k4735 in k1439 */
static void f_5983(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5983r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5983r(t0,t1,t2,t3);}}

static void f_5983r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5991,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1221 current-output-port */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5989 in printf in k4735 in k1439 */
static void f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fprintf in k4735 in k1439 */
static void f_5727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5727r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5727r(t0,t1,t2,t3,t4);}}

static void f_5727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=lf[378],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5733(t8,t1,t3,t4);}

/* rec in fprintf in k4735 in k1439 */
static void C_fcall f_5733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5733,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,lf[370]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5742,a[2]=t7,a[3]=t2,a[4]=lf[371],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5746,a[2]=t4,a[3]=lf[373],tmp=(C_word)a,a+=4,tmp);
t11=f_5742(t9);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t13,a[9]=t9,a[10]=t8,a[11]=t7,a[12]=lf[377],tmp=(C_word)a,a+=13,tmp));
t15=((C_word*)t13)[1];
f_5769(t15,t1,t11);}

/* do884 in rec in fprintf in k4735 in k1439 */
static void C_fcall f_5769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5769,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[10]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5779,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
if(C_truep(t4)){
t5=f_5742(((C_word*)t0)[9]);
t6=(C_word)C_u_i_char_upcase(t5);
switch(t6){
case C_make_character(83):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1192 next */
t8=((C_word*)t0)[5];
f_5746(t8,t7);
case C_make_character(65):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1193 next */
t8=((C_word*)t0)[5];
f_5746(t8,t7);
case C_make_character(67):
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1194 next */
t8=((C_word*)t0)[5];
f_5746(t8,t7);
case C_make_character(66):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5851,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1195 next */
t9=((C_word*)t0)[5];
f_5746(t9,t8);
case C_make_character(79):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1196 next */
t9=((C_word*)t0)[5];
f_5746(t9,t8);
case C_make_character(88):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5885,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1197 next */
t9=((C_word*)t0)[5];
f_5746(t9,t8);
case C_make_character(33):
/* extras.scm: 1198 ##sys#flush-output */
t7=*((C_word*)lf[374]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t3,((C_word*)t0)[6]);
case C_make_character(63):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1200 next */
t8=((C_word*)t0)[5];
f_5746(t8,t7);
case C_make_character(126):
/* extras.scm: 1204 ##sys#write-char-0 */
t7=*((C_word*)lf[139]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,C_make_character(126),((C_word*)t0)[6]);
case C_make_character(37):
/* extras.scm: 1205 newline */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t3,((C_word*)t0)[6]);
default:
t7=(C_word)C_eqp(t6,C_make_character(37));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(78)));
if(C_truep(t8)){
/* extras.scm: 1206 newline */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t3,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t5))){
t9=f_5742(((C_word*)t0)[9]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=lf[375],tmp=(C_word)a,a+=5,tmp);
t11=t3;
f_5779(2,t11,f_5957(t10,t9));}
else{
/* extras.scm: 1213 ##sys#error */
t9=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t3,lf[370],lf[376],t5);}}}}
else{
/* extras.scm: 1214 ##sys#write-char-0 */
t5=*((C_word*)lf[139]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[6]);}}}

/* skip in do884 in rec in fprintf in k4735 in k1439 */
static C_word C_fcall f_5957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_5742(((C_word*)t0)[3]);
t5=t2;
t1=t5;
goto loop;}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1)));
return(t2);}}

/* k5901 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5906,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1201 next */
t3=((C_word*)t0)[2];
f_5746(t3,t2);}

/* k5904 in k5901 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_list_2(t1,lf[370]);
/* extras.scm: 1203 rec */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5733(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5883 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1197 ##sys#number->string */
t2=*((C_word*)lf[231]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k5879 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1197 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5866 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1196 ##sys#number->string */
t2=*((C_word*)lf[231]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k5862 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1196 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5849 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1195 ##sys#number->string */
t2=*((C_word*)lf[231]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k5845 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1195 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5832 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1194 ##sys#write-char-0 */
t2=*((C_word*)lf[139]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5819 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1193 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5806 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1192 write */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5777 in do884 in rec in fprintf in k4735 in k1439 */
static void f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_5742(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5769(t3,((C_word*)t0)[2],t2);}

/* next in rec in fprintf in k4735 in k1439 */
static void C_fcall f_5746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5746,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 1182 ##sys#error */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[370],lf[372]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in fprintf in k4735 in k1439 */
static C_word C_fcall f_5742(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1)));
return(t1);}

/* string-chop in k4735 in k1439 */
static void f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5663,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[366]);
t5=(C_word)C_i_check_exact_2(t3,lf[366]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5678,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=lf[367],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5678(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k4735 in k1439 */
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5678,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5698,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(t3,t2);
/* extras.scm: 1159 ##sys#substring */
t6=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
/* extras.scm: 1160 ##sys#substring */
t6=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k5707 in loop in string-chop in k4735 in k1439 */
static void f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5713,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* extras.scm: 1160 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5678(t5,t2,t3,t4);}

/* k5711 in k5707 in loop in string-chop in k4735 in k1439 */
static void f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5696 in loop in string-chop in k4735 in k1439 */
static void f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k4735 in k1439 */
static void f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5541,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[361]);
t5=(C_word)C_i_check_list_2(t3,lf[361]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5553,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,a[6]=lf[364],tmp=(C_word)a,a+=7,tmp));
/* extras.scm: 1148 collect */
t10=((C_word*)t8)[1];
f_5553(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k4735 in k1439 */
static void C_fcall f_5553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5553,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5571,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1130 ##sys#substring */
t10=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_5571(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5586,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,a[9]=lf[363],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_5586(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k4735 in k1439 */
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5586,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1134 collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_5553(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5625,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5651,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1142 ##sys#substring */
t10=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_5625(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cdr(t2);
/* extras.scm: 1147 loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k5649 in loop in collect in string-translate* in k4735 in k1439 */
static void f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5625(t4,t3);}

/* k5623 in loop in collect in string-translate* in k4735 in k1439 */
static void C_fcall f_5625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5625,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* extras.scm: 1143 collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5553(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k5579 in collect in string-translate* in k4735 in k1439 */
static void f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5571(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k5569 in collect in string-translate* in k4735 in k1439 */
static void C_fcall f_5571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1128 reverse */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5565 in collect in string-translate* in k4735 in k1439 */
static void f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1126 ##sys#fragments->string */
t2=*((C_word*)lf[362]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k4735 in k1439 */
static void f_5339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_5339r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5339r(t0,t1,t2,t3,t4);}}

static void f_5339r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=lf[356],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5376,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_5376(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t3,a[3]=lf[359],tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1084 list->string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[353]);
/* extras.scm: 1087 instring */
f_5342(t6,t3);}}}

/* k5531 in string-translate in k4735 in k1439 */
static void f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1084 instring */
f_5342(((C_word*)t0)[2],t1);}

/* f_5516 in string-translate in k4735 in k1439 */
static void f_5516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5516,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k5374 in string-translate in k4735 in k1439 */
static void f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_5379(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* extras.scm: 1092 list->string */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[353]);
t5=t2;
f_5379(2,t5,t3);}}}
else{
t3=t2;
f_5379(2,t3,C_SCHEME_FALSE);}}

/* k5377 in k5374 in string-translate in k4735 in k1439 */
static void f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5379,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[353]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1099 make-string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k5389 in k5377 in k5374 in string-translate in k4735 in k1439 */
static void f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=lf[358],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5396(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k5389 in k5377 in k5374 in string-translate in k4735 in k1439 */
static void C_fcall f_5396(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5396,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* extras.scm: 1103 ##sys#substring */
t4=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5415,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 1106 from */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k5413 in loop in k5389 in k5377 in k5374 in string-translate in k4735 in k1439 */
static void f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1113 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5396(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* extras.scm: 1115 ##sys#error */
t4=*((C_word*)lf[14]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[353],lf[357],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1118 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5396(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1110 loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5396(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1109 loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5396(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k4735 in k1439 */
static void C_fcall f_5342(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5342,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5347,a[2]=t2,a[3]=t3,a[4]=lf[355],tmp=(C_word)a,a+=5,tmp));}

/* f_5347 in instring in string-translate in k4735 in k1439 */
static void f_5347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5347,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=lf[354],tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5353(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_5353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k4735 in k1439 */
static void f_5224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5224r(t0,t1,t2,t3);}}

static void f_5224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5228,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5228(2,t5,lf[350]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5228(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5226 in string-intersperse in k4735 in k1439 */
static void f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=(C_word)C_i_check_list_2(((C_word*)t0)[3],lf[345]);
t3=(C_word)C_i_check_string_2(t1,lf[345]);
t4=(C_word)C_block_size(t1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5242,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=lf[349],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5242(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k5226 in string-intersperse in k4735 in k1439 */
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5242,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[346]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_fixnum_difference(t3,((C_word*)t0)[3]);
/* extras.scm: 1047 ##sys#allocate-vector */
t6=*((C_word*)lf[348]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[345]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_fixnum_plus(t8,t9);
/* extras.scm: 1062 loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* extras.scm: 1064 ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k5250 in loop1 in k5226 in string-intersperse in k4735 in k1439 */
static void f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=lf[347],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_5257(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k5250 in loop1 in k5226 in string-intersperse in k4735 in k1439 */
static C_word C_fcall f_5257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k4735 in k1439 */
static void f_5089(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5089r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5089r(t0,t1,t2,t3);}}

static void f_5089r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_string_2(t2,lf[339]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[340]:(C_word)C_i_vector_ref(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[339]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5110,a[2]=t2,a[3]=t14,a[4]=lf[341],tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5130,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,a[10]=lf[343],tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_5130(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k4735 in k1439 */
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5130,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5140,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* extras.scm: 1023 add */
t8=((C_word*)t0)[6];
f_5110(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_5140(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5157,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],a[12]=lf[342],tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_5157(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k4735 in k1439 */
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5157,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* extras.scm: 1028 loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5130(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5196,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1032 add */
t8=((C_word*)t0)[3];
f_5110(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* extras.scm: 1033 loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_5130(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* extras.scm: 1034 scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k5194 in scan in loop in string-split in k4735 in k1439 */
static void f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1032 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5130(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k5138 in loop in string-split in k4735 in k1439 */
static void f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k4735 in k1439 */
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5110,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1016 ##sys#substring */
t6=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k5123 in add in string-split in k4735 in k1439 */
static void f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5117,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_5117(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_5117(t5,t4);}}

/* k5115 in k5123 in add in string-split in k4735 in k1439 */
static void C_fcall f_5117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k4735 in k1439 */
static void f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5025r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5025r(t0,t1,t2,t3,t4);}}

static void f_5025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[337]);
t6=(C_word)C_i_check_string_2(t3,lf[337]);
t7=(C_word)C_block_size(t4);
t8=(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(1));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix(0));
t10=(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(2));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5044,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t7,C_fix(2)))){
t13=t12;
f_5044(t13,(C_word)C_i_vector_ref(t4,C_fix(2)));}
else{
t13=(C_word)C_block_size(t2);
t14=(C_word)C_fixnum_difference(t13,t9);
t15=(C_word)C_block_size(t3);
t16=(C_word)C_fixnum_difference(t15,t11);
t17=t12;
f_5044(t17,(C_word)C_i_fixnum_min(t14,t16));}}

/* k5042 in substring-ci=? in k4735 in k1439 */
static void C_fcall f_5044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[337]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[337]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k4735 in k1439 */
static void f_4961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4961r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4961r(t0,t1,t2,t3,t4);}}

static void f_4961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[335]);
t6=(C_word)C_i_check_string_2(t3,lf[335]);
t7=(C_word)C_block_size(t4);
t8=(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(1));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix(0));
t10=(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(2));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4980,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t7,C_fix(2)))){
t13=t12;
f_4980(t13,(C_word)C_i_vector_ref(t4,C_fix(2)));}
else{
t13=(C_word)C_block_size(t2);
t14=(C_word)C_fixnum_difference(t13,t9);
t15=(C_word)C_block_size(t3);
t16=(C_word)C_fixnum_difference(t15,t11);
t17=t12;
f_4980(t17,(C_word)C_i_fixnum_min(t14,t16));}}

/* k4978 in substring=? in k4735 in k1439 */
static void C_fcall f_4980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[335]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[335]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k4735 in k1439 */
static void f_4930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4930,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[333]);
t5=(C_word)C_i_check_string_2(t3,lf[333]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k4735 in k1439 */
static void f_4899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4899,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[331]);
t5=(C_word)C_i_check_string_2(t3,lf[331]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k4735 in k1439 */
static void f_4880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4880r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4880r(t0,t1,t2,t3,t4);}}

static void f_4880r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4890,a[2]=t3,a[3]=t2,a[4]=lf[329],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 941  traverse */
f_4814(t1,t2,t3,t6,t7,lf[328]);}

/* a4889 in substring-index-ci in k4735 in k1439 */
static void f_4890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4890,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* substring-index in k4735 in k1439 */
static void f_4861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4861r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4861r(t0,t1,t2,t3,t4);}}

static void f_4861r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4871,a[2]=t3,a[3]=t2,a[4]=lf[326],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 935  traverse */
f_4814(t1,t2,t3,t6,t7,lf[325]);}

/* a4870 in substring-index in k4735 in k1439 */
static void f_4871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4871,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k4735 in k1439 */
static void C_fcall f_4814(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4814,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4835,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,a[6]=lf[323],tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_4835(t15,t1,t4,t10);}

/* loop in traverse in k4735 in k1439 */
static void C_fcall f_4835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4835,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 929  test */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k4846 in loop in traverse in k4735 in k1439 */
static void f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 931  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4835(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k4735 in k1439 */
static void f_4804(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4804r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4804r(t0,t1,t2);}}

static void f_4804r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[318]+1),t2);}

/* k4810 in conc in k4735 in k1439 */
static void f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k4735 in k1439 */
static void f_4768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4768,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* extras.scm: 905  symbol->string */
t3=*((C_word*)lf[319]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* extras.scm: 906  ##sys#number->string */
t3=*((C_word*)lf[231]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4796,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 908  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}}}

/* k4794 in ->string in k4735 in k1439 */
static void f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4799,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 909  display */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k4797 in k4794 in ->string in k4735 in k1439 */
static void f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 910  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pretty-print in k4735 in k1439 */
static void f_4739(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4739r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4739r(t0,t1,t2,t3);}}

static void f_4739r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_4743(2,t5,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
/* extras.scm: 890  current-output-port */
t5=*((C_word*)lf[315]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4741 in pretty-print in k4735 in k1439 */
static void f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 891  pretty-print-width */
t4=*((C_word*)lf[312]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4748 in k4741 in pretty-print in k4735 in k1439 */
static void f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[4],a[3]=lf[314],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 891  ##extras#generic-write */
t3=lf[204];
f_3408(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a4751 in k4748 in k4741 in pretty-print in k4735 in k1439 */
static void f_4752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4752,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4756,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 891  display */
t4=*((C_word*)lf[143]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k4754 in a4751 in k4748 in k4741 in pretty-print in k4735 in k1439 */
static void f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k4744 in k4741 in pretty-print in k4735 in k1439 */
static void f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##extras#reverse-string-append in k1439 */
static void f_4658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4658,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4661,a[2]=t4,a[3]=lf[310],tmp=(C_word)a,a+=4,tmp));
/* extras.scm: 882  rev-string-append */
t6=((C_word*)t4)[1];
f_4661(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##extras#reverse-string-append in k1439 */
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4661,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4677,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 873  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 880  make-string */
t4=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}

/* k4675 in rev-string-append in ##extras#reverse-string-append in k1439 */
static void f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4686,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[309],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4686(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k4675 in rev-string-append in ##extras#reverse-string-append in k1439 */
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4686,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 878  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* ##extras#generic-write in k1439 */
static void C_fcall f_3408(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3408,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=lf[210],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=lf[215],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=t5,a[3]=lf[216],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3521,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,a[10]=lf[257],tmp=(C_word)a,a+=11,tmp));
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4002,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,a[9]=lf[307],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4649,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 862  make-string */
t15=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t15))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 863  wr */
t14=((C_word*)t11)[1];
f_3521(t14,t1,t2,C_fix(0));}}

/* k4647 in ##extras#generic-write in k1439 */
static void f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 862  pp */
t3=((C_word*)t0)[3];
f_4002(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4651 in k4647 in ##extras#generic-write in k1439 */
static void f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 862  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in ##extras#generic-write in k1439 */
static void C_fcall f_4002(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[151],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4002,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=lf[260],tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=lf[261],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],a[8]=lf[266],tmp=(C_word)a,a+=9,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],a[12]=lf[268],tmp=(C_word)a,a+=13,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,a[5]=lf[270],tmp=(C_word)a,a+=6,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=lf[272],tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,a[5]=lf[277],tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,a[7]=lf[283],tmp=(C_word)a,a+=8,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4484,a[2]=t11,a[3]=t15,a[4]=lf[284],tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4490,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[285],tmp=(C_word)a,a+=6,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4496,a[2]=t11,a[3]=t19,a[4]=lf[286],tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=t21,a[3]=t13,a[4]=lf[287],tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4508,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=lf[288],tmp=(C_word)a,a+=6,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4514,a[2]=t11,a[3]=t13,a[4]=lf[289],tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4520,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[290],tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4542,a[2]=t11,a[3]=t19,a[4]=lf[291],tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4548,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[292],tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4557,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=lf[306],tmp=(C_word)a,a+=11,tmp));
/* extras.scm: 859  pr */
t56=((C_word*)t9)[1];
f_4070(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4557,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[293]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_4567(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t5)){
t6=t4;
f_4567(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[304]);
t7=t4;
f_4567(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[305])));}}}

/* k4565 in style in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[294]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[295]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[296]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[297]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[298]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[299]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[300]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[301]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[302]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in ##extras#generic-write in k1439 */
static void f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4548,5,t0,t1,t2,t3,t4);}
/* extras.scm: 837  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4336(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in ##extras#generic-write in k1439 */
static void f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4542,5,t0,t1,t2,t3,t4);}
/* extras.scm: 834  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4336(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in ##extras#generic-write in k1439 */
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4520,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_4527(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_4527(t7,C_SCHEME_FALSE);}}

/* k4525 in pp-let in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 831  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4336(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in ##extras#generic-write in k1439 */
static void f_4514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4514,5,t0,t1,t2,t3,t4);}
/* extras.scm: 826  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4222(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in ##extras#generic-write in k1439 */
static void f_4508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4508,5,t0,t1,t2,t3,t4);}
/* extras.scm: 823  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4336(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in ##extras#generic-write in k1439 */
static void f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4502,5,t0,t1,t2,t3,t4);}
/* extras.scm: 820  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4222(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in ##extras#generic-write in k1439 */
static void f_4496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4496,5,t0,t1,t2,t3,t4);}
/* extras.scm: 817  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4336(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in ##extras#generic-write in k1439 */
static void f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4490,5,t0,t1,t2,t3,t4);}
/* extras.scm: 814  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4336(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in ##extras#generic-write in k1439 */
static void f_4484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4484,5,t0,t1,t2,t3,t4);}
/* extras.scm: 811  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4250(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4336,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4421,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=lf[278],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=lf[279],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=lf[280],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_i_cdr(t2);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4482,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 802  out */
t16=((C_word*)t0)[2];
f_3502(t16,t15,lf[282],t3);}

/* k4480 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 802  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4432 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4449,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4464,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 806  out */
t7=((C_word*)t0)[2];
f_3502(t7,t6,lf[281],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 808  tail1 */
t5=((C_word*)t0)[5];
f_4339(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k4462 in k4432 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 806  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4447 in k4432 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 807  tail1 */
t4=((C_word*)t0)[4];
f_4339(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4339,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4362,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 786  indent */
t13=((C_word*)t0)[2];
f_4038(t13,t12,t5,t4);}
else{
/* extras.scm: 787  tail2 */
t7=((C_word*)t0)[4];
f_4380(t7,t1,t2,t3,t4,t5);}}

/* k4364 in tail1 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 786  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4070(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4360 in tail1 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 786  tail2 */
t2=((C_word*)t0)[6];
f_4380(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4380,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4403,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 794  indent */
t13=((C_word*)t0)[2];
f_4038(t13,t12,t5,t4);}
else{
/* extras.scm: 795  tail3 */
t7=((C_word*)t0)[4];
f_4421(t7,t1,t2,t3,t4);}}

/* k4405 in tail2 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 794  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4070(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4401 in tail2 in pp-general in pp in ##extras#generic-write in k1439 */
static void f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 794  tail3 */
t2=((C_word*)t0)[5];
f_4421(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4421,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 798  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4259(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4259,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=lf[276],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4265(t10,t1,t2,t3);}

/* loop in pp-down in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4265,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4288,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 769  indent */
t10=((C_word*)t0)[4];
f_4038(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 771  out */
t4=((C_word*)t0)[2];
f_3502(t4,t1,lf[273],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4318,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4334,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 775  indent */
t8=((C_word*)t0)[4];
f_4038(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4332 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 775  out */
t2=((C_word*)t0)[3];
f_3502(t2,((C_word*)t0)[2],lf[275],t1);}

/* k4328 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 775  indent */
t2=((C_word*)t0)[4];
f_4038(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4320 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 774  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4070(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4316 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 773  out */
t2=((C_word*)t0)[3];
f_3502(t2,((C_word*)t0)[2],lf[274],t1);}

/* k4294 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 769  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4070(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4286 in loop in pp-down in pp in ##extras#generic-write in k1439 */
static void f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 768  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4265(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4250,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4254,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 759  out */
t7=((C_word*)t0)[2];
f_3502(t7,t6,lf[271],t3);}

/* k4252 in pp-list in pp in ##extras#generic-write in k1439 */
static void f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 760  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4259(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4222,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4226,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4248,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 751  out */
t9=((C_word*)t0)[2];
f_3502(t9,t8,lf[269],t3);}

/* k4246 in pp-call in pp in ##extras#generic-write in k1439 */
static void f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 751  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4224 in pp-call in pp in ##extras#generic-write in k1439 */
static void f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 753  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4259(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in ##extras#generic-write in k1439 */
static void f_4157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4157,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 731  read-macro? */
f_3411(t5,t2);}

/* k4162 in pp-expr in pp in ##extras#generic-write in k1439 */
static void f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
if(C_truep(t1)){
t2=f_3463(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_3469(((C_word*)t0)[13]);
/* extras.scm: 733  out */
t5=((C_word*)t0)[7];
f_3502(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4191,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 738  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4557(t4,t3,t2);}
else{
/* extras.scm: 745  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4250(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k4189 in k4162 in pp-expr in pp in ##extras#generic-write in k1439 */
static void f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 740  proc */
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 741  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[267]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4215 in k4189 in k4162 in pp-expr in pp in ##extras#generic-write in k1439 */
static void f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 743  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_4336(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 744  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4222(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k4173 in k4162 in pp-expr in pp in ##extras#generic-write in k1439 */
static void f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 732  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4070(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4070(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4070,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 717  max */
t14=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 728  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3521(t8,t1,t2,t3);}}

/* k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4121,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=lf[264],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 718  ##extras#generic-write */
t6=lf[204];
f_3408(t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a4120 in k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4121,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_string_length(t2);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k4084 in k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 724  ##extras#reverse-string-append */
t3=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 726  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 727  vector->list */
t3=*((C_word*)lf[228]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k4113 in k4084 in k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 727  out */
t3=((C_word*)t0)[3];
f_3502(t3,t2,lf[263],((C_word*)t0)[2]);}

/* k4117 in k4113 in k4084 in k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 727  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4250(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k4097 in k4084 in k4081 in pr in pp in ##extras#generic-write in k1439 */
static void f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 724  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4061,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 711  make-string */
t6=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 712  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4005(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4059 in indent in pp in ##extras#generic-write in k1439 */
static void f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 711  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4052 in indent in pp in ##extras#generic-write in k1439 */
static void f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 711  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4005(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in ##extras#generic-write in k1439 */
static void C_fcall f_4005(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4005,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 704  out */
t6=((C_word*)t0)[2];
f_3502(t6,t5,lf[258],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4036,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 705  ##sys#substring */
t5=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[259],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4034 in spaces in pp in ##extras#generic-write in k1439 */
static void f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 705  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4027 in spaces in pp in ##extras#generic-write in k1439 */
static void f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 704  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4005(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in ##extras#generic-write in k1439 */
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3521,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=lf[224],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=lf[225],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 643  wr-expr */
t6=t5;
f_3524(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 644  wr-lst */
t6=t4;
f_3551(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 645  out */
t6=((C_word*)t0)[8];
f_3502(t6,t1,lf[226],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3677,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 646  vector->list */
t7=*((C_word*)lf[228]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[229]:lf[230]);
/* extras.scm: 647  out */
t7=((C_word*)t0)[8];
f_3502(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 648  ##sys#number? */
t7=*((C_word*)lf[256]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}}}}}

/* k3698 in wr in ##extras#generic-write in k1439 */
static void f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 648  ##sys#number->string */
t3=*((C_word*)lf[231]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 650  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 653  ##sys#procedure->string */
t3=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 655  out */
t2=((C_word*)t0)[8];
f_3502(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 656  out */
t3=((C_word*)t0)[8];
f_3502(t3,t2,lf[237],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 670  make-string */
t3=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 672  out */
t4=((C_word*)t0)[8];
f_3502(t4,t3,lf[242],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 683  out */
t2=((C_word*)t0)[8];
f_3502(t2,((C_word*)t0)[7],lf[243],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 684  out */
t2=((C_word*)t0)[8];
f_3502(t2,((C_word*)t0)[7],lf[244],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 685  ##sys#pointer->string */
t3=*((C_word*)lf[245]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 687  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 690  port? */
t3=*((C_word*)lf[8]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}}}}}}}}}

/* k3955 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 690  string-append */
t4=*((C_word*)lf[247]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[248],t3,lf[249]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 692  out */
t3=((C_word*)t0)[5];
f_3502(t3,t2,lf[252],((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(lf[253],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
if(C_truep(t3)){
/* extras.scm: 696  out */
t4=((C_word*)t0)[5];
f_3502(t4,((C_word*)t0)[4],lf[254],((C_word*)t0)[3]);}
else{
/* extras.scm: 697  out */
t4=((C_word*)t0)[5];
f_3502(t4,((C_word*)t0)[4],lf[255],((C_word*)t0)[3]);}}}}

/* k3972 in k3955 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 693  ##sys#lambda-info->string */
t4=*((C_word*)lf[251]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3982 in k3972 in k3955 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 693  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3975 in k3972 in k3955 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 694  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],lf[250],((C_word*)t0)[2]);}

/* k3962 in k3955 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 690  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3939 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3944,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 688  ##sys#user-print-hook */
t3=*((C_word*)lf[246]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k3942 in k3939 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 689  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3949 in k3942 in k3939 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 689  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3930 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 685  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 673  char-name */
t3=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 675  out */
t3=((C_word*)t0)[6];
f_3502(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 677  out */
t3=((C_word*)t0)[6];
f_3502(t3,t2,lf[238],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[239]:lf[240]);
/* extras.scm: 680  out */
t5=((C_word*)t0)[6];
f_3502(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 682  make-string */
t3=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k3905 in k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 682  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3884 in k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 681  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k3891 in k3884 in k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 681  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3868 in k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 678  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k3875 in k3868 in k3849 in k3846 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 678  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3840 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 670  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=lf[236],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3760(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void C_fcall f_3760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3760,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3767,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_3767(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_3767(t6,C_SCHEME_FALSE);}}

/* k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void C_fcall f_3767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3790,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3794,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 664  ##sys#substring */
t9=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 666  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3760(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3819,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 668  ##sys#substring */
t4=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k3817 in k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 668  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3813 in k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 667  out */
t2=((C_word*)t0)[3];
f_3502(t2,((C_word*)t0)[2],lf[235],t1);}

/* k3796 in k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 664  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3792 in k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 663  out */
t2=((C_word*)t0)[3];
f_3502(t2,((C_word*)t0)[2],lf[234],t1);}

/* k3788 in k3765 in loop in k3756 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 661  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3760(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3737 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 653  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3714 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3719,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 651  ##sys#print */
t3=*((C_word*)lf[232]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k3717 in k3714 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 652  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3724 in k3717 in k3714 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 652  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3705 in k3698 in wr in ##extras#generic-write in k1439 */
static void f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 648  out */
t2=((C_word*)t0)[4];
f_3502(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3675 in wr in ##extras#generic-write in k1439 */
static void f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3681,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 646  out */
t3=((C_word*)t0)[3];
f_3502(t3,t2,lf[227],((C_word*)t0)[2]);}

/* k3679 in k3675 in wr in ##extras#generic-write in k1439 */
static void f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 646  wr-lst */
t2=((C_word*)t0)[4];
f_3551(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in ##extras#generic-write in k1439 */
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3524,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 628  read-macro? */
f_3411(t4,t2);}

/* k3529 in wr-expr in wr in ##extras#generic-write in k1439 */
static void f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
if(C_truep(t1)){
t2=f_3463(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3542,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_3469(((C_word*)t0)[8]);
/* extras.scm: 629  out */
t5=((C_word*)t0)[4];
f_3502(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 630  wr-lst */
t2=((C_word*)t0)[2];
f_3551(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k3540 in k3529 in wr-expr in wr in ##extras#generic-write in k1439 */
static void f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 629  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in ##extras#generic-write in k1439 */
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3551,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3634,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 635  out */
t8=((C_word*)t0)[2];
f_3502(t8,t7,lf[222],t3);}
else{
t6=t5;
f_3569(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 641  out */
t4=((C_word*)t0)[2];
f_3502(t4,t1,lf[223],t3);}}

/* k3632 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 635  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=lf[221],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3571(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3571,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3595,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3603,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 638  out */
t9=((C_word*)t0)[2];
f_3502(t9,t8,lf[217],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 639  out */
t5=((C_word*)t0)[2];
f_3502(t5,t1,lf[218],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3619,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3623,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 640  out */
t7=((C_word*)t0)[2];
f_3502(t7,t6,lf[220],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k3621 in loop in k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 640  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3617 in loop in k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 640  out */
t2=((C_word*)t0)[3];
f_3502(t2,((C_word*)t0)[2],lf[219],t1);}

/* k3601 in loop in k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 638  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3521(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3593 in loop in k3567 in wr-lst in wr in ##extras#generic-write in k1439 */
static void f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 638  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3571(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in ##extras#generic-write in k1439 */
static void C_fcall f_3502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3502,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3512,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 623  output */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3510 in out in ##extras#generic-write in k1439 */
static void f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in ##extras#generic-write in k1439 */
static C_word C_fcall f_3469(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_eqp(t2,lf[205]);
if(C_truep(t4)){
return(lf[211]);}
else{
t5=(C_word)C_eqp(t2,lf[206]);
if(C_truep(t5)){
return(lf[212]);}
else{
t6=(C_word)C_eqp(t2,lf[207]);
if(C_truep(t6)){
return(lf[213]);}
else{
t7=(C_word)C_eqp(t2,lf[208]);
return((C_truep(t7)?lf[214]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in ##extras#generic-write in k1439 */
static C_word C_fcall f_3463(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_i_cadr(t1));}

/* read-macro? in ##extras#generic-write in k1439 */
static void C_fcall f_3411(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3411,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,lf[205]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_3443(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[206]);
if(C_truep(t7)){
t8=t6;
f_3443(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[207]);
t9=t6;
f_3443(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[208])));}}}

/* k3441 in read-macro? in ##extras#generic-write in k1439 */
static void C_fcall f_3443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-output-port in k1439 */
static void f_3350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3350r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3350r(t0,t1,t2,t3,t4);}}

static void f_3350r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(31);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[198],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3378,a[2]=t2,a[3]=lf[199],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=t3,a[3]=lf[200],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3393,a[2]=t6,a[3]=lf[201],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_vector(&a,7,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,t8,t9,t10,C_SCHEME_FALSE);
t12=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3363,a[2]=t1,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 584  ##sys#make-port */
t14=*((C_word*)lf[192]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,C_SCHEME_FALSE,t11,lf[202],lf[194]);}

/* k3361 in make-output-port in k1439 */
static void f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3392 in make-output-port in k1439 */
static void f_3393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3393,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 581  flush */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a3383 in make-output-port in k1439 */
static void f_3384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 578  close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3386 in a3383 in make-output-port in k1439 */
static void f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a3377 in make-output-port in k1439 */
static void f_3378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3378,4,t0,t1,t2,t3);}
/* extras.scm: 576  write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3367 in make-output-port in k1439 */
static void f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3368,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3376,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 574  string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k3374 in a3367 in make-output-port in k1439 */
static void f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 574  write */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k1439 */
static void f_3269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+32)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3269r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3269r(t0,t1,t2,t3,t4,t5);}}

static void f_3269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(32);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=t2,a[3]=t7,a[4]=lf[188],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3308,a[2]=t2,a[3]=t7,a[4]=lf[189],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t4,a[3]=lf[190],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3338,a[2]=t3,a[3]=lf[191],tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_a_i_vector(&a,7,t8,t9,C_SCHEME_FALSE,C_SCHEME_FALSE,t10,C_SCHEME_FALSE,t11);
t13=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=t1,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 561  ##sys#make-port */
t15=*((C_word*)lf[192]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,C_SCHEME_TRUE,t12,lf[193],lf[194]);}

/* k3280 in make-input-port in k1439 */
static void f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3337 in make-input-port in k1439 */
static void f_3338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3338,3,t0,t1,t2);}
/* extras.scm: 559  ready? */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a3328 in make-input-port in k1439 */
static void f_3329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3329,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3333,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 555  close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3331 in a3328 in make-input-port in k1439 */
static void f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a3307 in make-input-port in k1439 */
static void f_3308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3308,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 546  peek */
t4=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3324,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 549  read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}}

/* k3322 in a3307 in make-input-port in k1439 */
static void f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3286 in make-input-port in k1439 */
static void f_3287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3287,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 539  read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=(C_word)C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* extras.scm: 543  read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}}}

/* with-output-to-string in k1439 */
static void f_3241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3241,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 521  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3243 in with-output-to-string in k1439 */
static void f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3250,a[2]=t3,a[3]=t5,a[4]=lf[183],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[184],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3264,a[2]=t5,a[3]=t3,a[4]=lf[185],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[157]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3263 in k3243 in with-output-to-string in k1439 */
static void f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[146]+1));
t3=C_mutate((C_word*)lf[146]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3254 in k3243 in with-output-to-string in k1439 */
static void f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3259,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 522  thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3257 in a3254 in k3243 in with-output-to-string in k1439 */
static void f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 523  get-output-string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],*((C_word*)lf[146]+1));}

/* a3249 in k3243 in with-output-to-string in k1439 */
static void f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[146]+1));
t3=C_mutate((C_word*)lf[146]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-input-from-string in k1439 */
static void f_3216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3216,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3220,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 514  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3218 in with-input-from-string in k1439 */
static void f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3225,a[2]=t3,a[3]=t5,a[4]=lf[178],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[3],a[3]=lf[179],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3236,a[2]=t5,a[3]=t3,a[4]=lf[180],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[157]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3235 in k3218 in with-input-from-string in k1439 */
static void f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[12]+1));
t3=C_mutate((C_word*)lf[12]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3229 in k3218 in with-input-from-string in k1439 */
static void f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
/* extras.scm: 515  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3224 in k3218 in with-input-from-string in k1439 */
static void f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[12]+1));
t3=C_mutate((C_word*)lf[12]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* call-with-output-string in k1439 */
static void f_3204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 507  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3206 in call-with-output-string in k1439 */
static void f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3211,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 508  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k3209 in k3206 in call-with-output-string in k1439 */
static void f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 509  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k1439 */
static void f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3195,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 500  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3197 in call-with-input-string in k1439 */
static void f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 501  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k1439 */
static void f_3170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3170,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3174,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 490  ##sys#check-port */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[170]);}

/* k3172 in with-error-output-to-port in k1439 */
static void f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3179,a[2]=t3,a[3]=t5,a[4]=lf[167],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[3],a[3]=lf[168],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3190,a[2]=t5,a[3]=t3,a[4]=lf[169],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 491  ##sys#dynamic-wind */
t9=*((C_word*)lf[157]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3189 in k3172 in with-error-output-to-port in k1439 */
static void f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[166]+1));
t3=C_mutate((C_word*)lf[166]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3183 in k3172 in with-error-output-to-port in k1439 */
static void f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
/* extras.scm: 492  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3178 in k3172 in with-error-output-to-port in k1439 */
static void f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[166]+1));
t3=C_mutate((C_word*)lf[166]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-output-to-port in k1439 */
static void f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3145,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 485  ##sys#check-port */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[163]);}

/* k3147 in with-output-to-port in k1439 */
static void f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3154,a[2]=t3,a[3]=t5,a[4]=lf[160],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[3],a[3]=lf[161],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3165,a[2]=t5,a[3]=t3,a[4]=lf[162],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 486  ##sys#dynamic-wind */
t9=*((C_word*)lf[157]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3164 in k3147 in with-output-to-port in k1439 */
static void f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[146]+1));
t3=C_mutate((C_word*)lf[146]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3158 in k3147 in with-output-to-port in k1439 */
static void f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
/* extras.scm: 487  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3153 in k3147 in with-output-to-port in k1439 */
static void f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[146]+1));
t3=C_mutate((C_word*)lf[146]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-input-from-port in k1439 */
static void f_3120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3120,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3124,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 480  ##sys#check-port */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[153]);}

/* k3122 in with-input-from-port in k1439 */
static void f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3129,a[2]=t3,a[3]=t5,a[4]=lf[154],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=lf[155],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=t5,a[3]=t3,a[4]=lf[156],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 481  ##sys#dynamic-wind */
t9=*((C_word*)lf[157]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3139 in k3122 in with-input-from-port in k1439 */
static void f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[12]+1));
t3=C_mutate((C_word*)lf[12]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3133 in k3122 in with-input-from-port in k1439 */
static void f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
/* extras.scm: 482  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3128 in k3122 in with-input-from-port in k1439 */
static void f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[12]+1));
t3=C_mutate((C_word*)lf[12]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* write-line in k1439 */
static void f_3099(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3099r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3099r(t0,t1,t2,t3);}}

static void f_3099r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[146]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 471  ##sys#check-port */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[151]);}

/* k3104 in write-line in k1439 */
static void f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[151]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 473  display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k3110 in k3104 in write-line in k1439 */
static void f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 474  newline */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1439 */
static void f_3010(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3010r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3010r(t0,t1,t2,t3);}}

static void f_3010r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=(C_word)C_i_check_string_2(t2,lf[144]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3015,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[145],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=t5,a[3]=lf[147],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3051,a[2]=t6,a[3]=lf[148],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* extras.scm: 455  def-n308 */
t8=t7;
f_3051(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* extras.scm: 455  def-port309 */
t10=t6;
f_3046(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* extras.scm: 455  body306 */
t12=t5;
f_3015(t12,t1,t8,t10);}
else{
/* extras.scm: 455  ##sys#error */
t12=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n308 in write-string in k1439 */
static void C_fcall f_3051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,2,t0,t1);}
/* extras.scm: 455  def-port309 */
t2=((C_word*)t0)[2];
f_3046(t2,t1,C_SCHEME_FALSE);}

/* def-port309 in write-string in k1439 */
static void C_fcall f_3046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3046,NULL,3,t0,t1,t2);}
/* extras.scm: 455  body306 */
t3=((C_word*)t0)[2];
f_3015(t3,t1,t2,*((C_word*)lf[146]+1));}

/* body306 in write-string in k1439 */
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 456  ##sys#check-port */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[131]);}

/* k3017 in body306 in write-string in k1439 */
static void f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[144]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_3032(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_3032(t5,C_SCHEME_FALSE);}}

/* k3030 in k3017 in body306 in write-string in k1439 */
static void C_fcall f_3032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 460  ##sys#substring */
t2=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3029(2,t2,((C_word*)t0)[3]);}}

/* k3027 in k3017 in body306 in write-string in k1439 */
static void f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 458  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1439 */
static void f_2941(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2941r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2941r(t0,t1,t2,t3);}}

static void f_2941r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2945(2,t5,*((C_word*)lf[12]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2945(2,t6,(C_word)C_i_car(t3));}
else{
/* extras.scm: 440  ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2943 in read-token in k1439 */
static void f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 441  ##sys#check-port */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[138]);}

/* k2946 in k2943 in read-token in k1439 */
static void f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 442  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2949 in k2946 in k2943 in read-token in k1439 */
static void f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=lf[141],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2956(t5,((C_word*)t0)[2]);}

/* loop in k2949 in k2946 in k2943 in read-token in k1439 */
static void C_fcall f_2956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2956,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 444  ##sys#peek-char-0 */
t3=*((C_word*)lf[140]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k2958 in loop in k2949 in k2946 in k2943 in read-token in k1439 */
static void f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_2966(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 445  pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k2964 in k2958 in loop in k2949 in k2946 in k2943 in read-token in k1439 */
static void f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 447  ##sys#read-char-0 */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 449  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k2974 in k2964 in k2958 in loop in k2949 in k2946 in k2943 in read-token in k1439 */
static void f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 447  ##sys#write-char-0 */
t2=*((C_word*)lf[139]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2967 in k2964 in k2958 in loop in k2949 in k2946 in k2943 in read-token in k1439 */
static void f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 448  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2956(t2,((C_word*)t0)[2]);}

/* read-string in k1439 */
static void f_2826(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2826r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2826r(t0,t1,t2);}}

static void f_2826r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[134],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=t3,a[3]=lf[135],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=t4,a[3]=lf[136],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n264283 */
t6=t5;
f_2893(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p265281 */
t8=t4;
f_2888(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body262267 */
t10=t3;
f_2828(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n264 in read-string in k1439 */
static void C_fcall f_2893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2893,NULL,2,t0,t1);}
/* def-p265281 */
t2=((C_word*)t0)[2];
f_2888(t2,t1,C_SCHEME_FALSE);}

/* def-p265 in read-string in k1439 */
static void C_fcall f_2888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2888,NULL,3,t0,t1,t2);}
/* body262267 */
t3=((C_word*)t0)[2];
f_2828(t3,t1,t2,*((C_word*)lf[12]+1));}

/* body262 in read-string in k1439 */
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2828,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 423  ##sys#check-port */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[131]);}

/* k2830 in body262 in read-string in k1439 */
static void f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 424  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2833 in k2830 in body262 in read-string in k1439 */
static void f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[131]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 426  ##sys#check-port */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[131]);}

/* k2839 in k2833 in k2830 in body262 in read-string in k1439 */
static void f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[133],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2846(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k2839 in k2833 in k2830 in body262 in read-string in k1439 */
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2846,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 428  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_2850(2,t5,C_SCHEME_FALSE);}}

/* k2848 in loop in k2839 in k2833 in k2830 in body262 in read-string in k1439 */
static void f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 429  ##sys#read-char-0 */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2854 in k2848 in loop in k2839 in k2833 in k2830 in body262 in read-string in k1439 */
static void f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 431  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 433  ##sys#write-char */
t3=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k2866 in k2854 in k2848 in loop in k2839 in k2833 in k2830 in body262 in read-string in k1439 */
static void f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 434  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2846(t3,((C_word*)t0)[2],t2);}

/* read-lines in k1439 */
static void f_2734(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_2734r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2734r(t0,t1,t2);}}

static void f_2734r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[12]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=lf[127],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 413  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2803,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 415  ##sys#check-port */
t11=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[125]);}}

/* k2801 in read-lines in k1439 */
static void f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 416  doread */
t2=((C_word*)t0)[4];
f_2746(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k1439 */
static void f_2746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2754,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 408  read-line */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2752 in doread in read-lines in k1439 */
static void f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?((C_word*)t0)[6]:C_fix(1000000));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=lf[126],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2760(t6,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,t2);}

/* do245 in k2752 in doread in read-lines in k1439 */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2760,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_fix(0)));
if(C_truep(t6)){
/* extras.scm: 411  reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2780,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 408  read-line */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2778 in do245 in k2752 in doread in read-lines in k1439 */
static void f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2760(t4,((C_word*)t0)[2],t1,t2,t3);}

/* read-line in k1439 */
static void f_2505(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2505r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2505r(t0,t1,t2);}}

static void f_2505r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):*((C_word*)lf[12]+1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2515,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_2515(t8,(C_truep(t7)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_2515(t6,C_SCHEME_FALSE);}}

/* k2513 in read-line in k1439 */
static void C_fcall f_2515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2518,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 360  make-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}

/* k2516 in k2513 in read-line in k1439 */
static void f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(256);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2521,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 362  ##sys#check-port */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],lf[115]);}

/* k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_mk_bool(FGETS_INTO_BUFFER))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t4=t2;
f_2527(t4,(C_word)C_eqp(lf[122],t3));}
else{
t3=t2;
f_2527(t3,C_SCHEME_FALSE);}}

/* k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void C_fcall f_2527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=lf[117],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2532(t5,((C_word*)t0)[5],C_fix(256),((C_word*)((C_word*)t0)[4])[1],lf[118],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=lf[121],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 373  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[5],t2);}}

/* a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2601,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=lf[120],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_2607(t6,t1,C_fix(0));}

/* loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2607,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[8])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 377  ##sys#substring */
t5=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 378  ##sys#read-char-0 */
t5=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[9],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 382  ##sys#substring */
t3=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_fix(0),((C_word*)t0)[9]);}}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 384  ##sys#substring */
t3=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)((C_word*)t0)[7])[1],C_fix(0),((C_word*)t0)[9]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 386  ##sys#read-char-0 */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[9],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2698,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 394  make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_2684(t3,C_SCHEME_UNDEFINED);}}}}

/* k2704 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 394  ##sys#string-append */
t2=*((C_word*)lf[116]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2696 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2684(t5,t4);}

/* k2682 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void C_fcall f_2684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 397  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2607(t4,((C_word*)t0)[2],t3);}

/* k2659 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 388  ##sys#substring */
t4=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}
else{
t3=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],t1);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 391  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2607(t5,((C_word*)t0)[5],t4);}}

/* k2672 in k2659 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 388  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2650 in k2622 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 384  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2619 in loop in a2600 in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 377  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* loop in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)fgets_into_buffer(t3,((C_word*)t0)[5],t2);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t5)?t4:C_SCHEME_END_OF_FILE));}
else{
if(C_truep(t6)){
if(C_truep(t5)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_fixnum_difference(t6,C_fix(1));
/* extras.scm: 371  fixup */
f_2479(t8,t3,t9);}
else{
t8=(C_word)C_fixnum_difference(t6,C_fix(1));
/* extras.scm: 372  fixup */
f_2479(t1,t3,t8);}}
else{
t8=(C_word)C_fixnum_times(t2,C_fix(2));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2559,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_fixnum_times(t2,C_fix(2));
/* extras.scm: 368  make-string */
t11=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t11))(3,t11,t9,t10);}}}

/* k2557 in loop in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2563,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 369  ##sys#substring */
t5=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],C_fix(0),t4);}

/* k2565 in k2557 in loop in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 369  ##sys#string-append */
t2=*((C_word*)lf[116]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2561 in k2557 in loop in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 368  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2532(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2583 in loop in k2525 in k2519 in k2516 in k2513 in read-line in k1439 */
static void f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 371  ##sys#string-append */
t2=*((C_word*)lf[116]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fixup in k1439 */
static void C_fcall f_2479(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2479,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2490,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
t5=(C_word)C_fixnum_difference(t3,C_fix(1));
t6=(C_word)C_subchar(t2,t5);
t7=t4;
f_2490(t7,(C_word)C_eqp(C_make_character(13),t6));}
else{
t5=t4;
f_2490(t5,C_SCHEME_FALSE);}}

/* k2488 in fixup in k1439 */
static void C_fcall f_2490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):((C_word*)t0)[4]);
/* extras.scm: 351  ##sys#substring */
t3=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}

/* randomize in k1439 */
static void f_2462(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2462r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2462r(t0,t1,t2);}}

static void f_2462r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t3;
f_2467(t4,(C_word)C_fudge(C_fix(2)));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[110]);
t6=t3;
f_2467(t6,t4);}}

/* k2465 in randomize in k1439 */
static void C_fcall f_2467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_randomize(t1));}

/* random in k1439 */
static void f_2450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2450,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[86]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* rassoc in k1439 */
static void f_2400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2400r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2400r(t0,t1,t2,t3,t4);}}

static void f_2400r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_list_2(t3,lf[106]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t4,C_fix(0)):*((C_word*)lf[90]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2412,a[2]=t2,a[3]=t7,a[4]=t9,a[5]=lf[107],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2412(t11,t1,t3);}

/* loop in rassoc in k1439 */
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2412,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[106]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 320  tst */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2429 in loop in rassoc in k1439 */
static void f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 322  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2412(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1439 */
static void f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2276r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2276r(t0,t1,t2,t3,t4);}}

static void f_2276r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2278,a[2]=t3,a[3]=t2,a[4]=lf[102],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2347,a[2]=t5,a[3]=lf[103],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2352,a[2]=t6,a[3]=lf[104],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp169185 */
t8=t7;
f_2352(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default170183 */
t10=t6;
f_2347(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body167172 */
t12=t5;
f_2278(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-cmp169 in alist-ref in k1439 */
static void C_fcall f_2352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,2,t0,t1);}
/* def-default170183 */
t2=((C_word*)t0)[2];
f_2347(t2,t1,*((C_word*)lf[90]+1));}

/* def-default170 in alist-ref in k1439 */
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2347,NULL,3,t0,t1,t2);}
/* body167172 */
t3=((C_word*)t0)[2];
f_2278(t3,t1,t2,C_SCHEME_FALSE);}

/* body167 in alist-ref in k1439 */
static void C_fcall f_2278(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2278,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[91]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2282(t6,*((C_word*)lf[92]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[90]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2282(t7,*((C_word*)lf[93]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[94]+1),t2);
t8=t4;
f_2282(t8,(C_truep(t7)?*((C_word*)lf[95]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t2,a[3]=lf[101],tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2307 in body167 in alist-ref in k1439 */
static void f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2307,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2313,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[100],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2313(t7,t1,t3);}

/* loop */
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2313,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 305  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2329(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2327 in loop */
static void f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2313(t3,((C_word*)t0)[5],t2);}}

/* k2280 in body167 in alist-ref in k1439 */
static void C_fcall f_2282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2282,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 308  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2283 in k2280 in body167 in alist-ref in k1439 */
static void f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1439 */
static void f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2190r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2190r(t0,t1,t2,t3,t4,t5);}}

static void f_2190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):*((C_word*)lf[90]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2197,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[91]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2197(t10,*((C_word*)lf[92]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[90]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2197(t11,*((C_word*)lf[93]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[94]+1),t7);
t12=t8;
f_2197(t12,(C_truep(t11)?*((C_word*)lf[95]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=t7,a[3]=lf[97],tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2229 in alist-update! in k1439 */
static void f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2229,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2235,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[96],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2235(t7,t1,t3);}

/* loop */
static void C_fcall f_2235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 286  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2251(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2249 in loop */
static void f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2235(t3,((C_word*)t0)[5],t2);}}

/* k2195 in alist-update! in k1439 */
static void C_fcall f_2197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 289  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2198 in k2195 in alist-update! in k1439 */
static void f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1439 */
static void f_2152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=lf[87],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2179 in shuffle in k1439 */
static void f_2180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2180,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2188,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 270  random */
t4=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_fix(10000));}

/* k2186 in a2179 in shuffle in k1439 */
static void f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2162 in shuffle in k1439 */
static void f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 270  sort! */
t3=*((C_word*)lf[85]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2165 in k2162 in shuffle in k1439 */
static void f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2166,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2158 in shuffle in k1439 */
static void f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[83]+1),t1);}

/* compress in k1439 */
static void f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2072,4,t0,t1,t2,t3);}
t4=lf[76];
t5=(C_word)C_i_check_list_2(t3,lf[75]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2081,a[2]=t4,a[3]=t7,a[4]=lf[79],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2081(t9,t1,t2,t3);}

/* loop in compress in k1439 */
static void C_fcall f_2081(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2081,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2123,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 263  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 264  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* extras.scm: 262  ##sys#signal-hook */
t4=*((C_word*)lf[77]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[78],lf[75],((C_word*)t0)[2],t3);}}
else{
/* extras.scm: 260  ##sys#signal-hook */
t4=*((C_word*)lf[77]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[78],lf[75],((C_word*)t0)[2],t2);}}}

/* k2121 in loop in compress in k1439 */
static void f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1439 */
static void f_2013(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2013r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2013r(t0,t1,t2,t3);}}

static void f_2013r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[71]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2025,a[2]=t8,a[3]=t5,a[4]=lf[73],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2025(t10,t1,t2);}

/* loop in join in k1439 */
static void C_fcall f_2025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2025,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 251  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* extras.scm: 245  ##sys#not-a-proper-list-error */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k2058 in loop in join in k1439 */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 251  ##sys#append */
t2=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1439 */
static void f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1928,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[66]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1935,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* extras.scm: 226  ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[66],lf[69],t3);}
else{
t6=t5;
f_1935(2,t6,C_SCHEME_UNDEFINED);}}

/* k1933 in chop in k1439 */
static void f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=lf[68],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1943(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k1933 in chop in k1439 */
static void C_fcall f_1943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1943,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1964,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=lf[67],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1964(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do117 in loop in k1933 in chop in k1439 */
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1964,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1978,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 237  reverse */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k1976 in do117 in loop in k1933 in chop in k1439 */
static void f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* extras.scm: 237  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1943(t4,t2,((C_word*)t0)[2],t3);}

/* k1980 in k1976 in do117 in loop in k1933 in chop in k1439 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1439 */
static void f_1874(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_1874r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1874r(t0,t1,t2);}}

static void f_1874r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1880,a[2]=t2,a[3]=t4,a[4]=lf[64],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1880(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1439 */
static void C_fcall f_1880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1880,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1915,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 218  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 219  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}
else{
/* extras.scm: 213  ##sys#not-a-proper-list-error */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}}}

/* k1920 in loop in flatten in k1439 */
static void f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1913 in loop in flatten in k1439 */
static void f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 218  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1880(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1439 */
static void f_1842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1842,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[59]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1851,a[2]=t5,a[3]=lf[60],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1851(t7,t1,t2);}

/* loop in butlast in k1439 */
static void C_fcall f_1851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1851,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1872,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 206  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k1870 in loop in butlast in k1439 */
static void f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1439 */
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1809,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1815,a[2]=t5,a[3]=t3,a[4]=lf[57],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1815(t7,t1,t2);}

/* loop in intersperse in k1439 */
static void C_fcall f_1815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1815,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1840,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 199  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k1838 in loop in intersperse in k1439 */
static void f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1439 */
static void f_1781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1781,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[53]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1793,a[2]=t2,a[3]=lf[54],tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1793(t6,t3));}}

/* loop in tail? in k1439 */
static C_word C_fcall f_1793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1439 */
static void f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_atomp(t2));}

/* noop in k1439 */
static void f_1772(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
/* extras.scm: 176  void */
t2=*((C_word*)lf[49]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* list-of in k1439 */
static void f_1732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1734,a[2]=t2,a[3]=lf[46],tmp=(C_word)a,a+=4,tmp));}

/* f_1734 in list-of in k1439 */
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1734,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[45],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1740(t6,t1,t2);}

/* loop */
static void C_fcall f_1740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1740,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1759,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 173  pred */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1757 in loop */
static void f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1740(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* compose in k1439 */
static void f_1702(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1702r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1702r(t0,t1,t2);}}

static void f_1702r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1705,a[2]=t4,a[3]=lf[42],tmp=(C_word)a,a+=4,tmp));
C_apply(4,0,t1,((C_word*)t4)[1],t2);}

/* rec in compose in k1439 */
static void f_1705(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1705r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1705r(t0,t1,t2,t3);}}

static void f_1705r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1713,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[41],tmp=(C_word)a,a+=6,tmp)));}

/* f_1713 in rec in compose in k1439 */
static void f_1713(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1713r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1713r(t0,t1,t2);}}

static void f_1713r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=lf[40],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 163  call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a1718 */
static void f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1725 in a1718 */
static void f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1439 */
static void f_1690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1690,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=t2,a[3]=lf[37],tmp=(C_word)a,a+=4,tmp));}

/* f_1692 in complement in k1439 */
static void f_1692(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1692r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1692r(t0,t1,t2);}}

static void f_1692r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k1698 */
static void f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1439 */
static void f_1682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1682,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=t2,a[3]=lf[34],tmp=(C_word)a,a+=4,tmp));}

/* f_1684 in flip in k1439 */
static void f_1684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1684,4,t0,t1,t2,t3);}
/* extras.scm: 152  proc */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* constantly in k1439 */
static void f_1659(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_1659r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1659r(t0,t1,t2);}}

static void f_1659r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1670,a[2]=t5,a[3]=lf[30],tmp=(C_word)a,a+=4,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t2,a[3]=lf[31],tmp=(C_word)a,a+=4,tmp));}}

/* f_1672 in constantly in k1439 */
static void f_1672(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1670 in constantly in k1439 */
static void f_1670(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1439 */
static void f_1622(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1622r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1622r(t0,t1,t2);}}

static void f_1622r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1624,a[2]=t2,a[3]=lf[27],tmp=(C_word)a,a+=4,tmp));}

/* f_1624 in disjoin in k1439 */
static void f_1624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1624,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1630,a[2]=t2,a[3]=t4,a[4]=lf[26],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1630(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1630,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[2]);}}

/* k1638 in loop */
static void f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 144  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1630(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1439 */
static void f_1589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1589r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1589r(t0,t1,t2);}}

static void f_1589r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1591,a[2]=t2,a[3]=lf[23],tmp=(C_word)a,a+=4,tmp));}

/* f_1591 in conjoin in k1439 */
static void f_1591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1591,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1597,a[2]=t2,a[3]=t4,a[4]=lf[22],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1597(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1597,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1610,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[2]);}}

/* k1608 in loop */
static void f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 137  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1597(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1439 */
static void f_1581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1581,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1583,a[2]=t2,a[3]=lf[19],tmp=(C_word)a,a+=4,tmp));}

/* f_1583 in project in k1439 */
static void f_1583(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1583r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1583r(t0,t1,t2);}}

static void f_1583r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,((C_word*)t0)[2]));}

/* identity in k1439 */
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1578,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* read-file in k1439 */
static void f_1443(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr2r,(void*)f_1443r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1443r(t0,t1,t2);}}

static void f_1443r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(19);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[9],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t3,a[3]=lf[10],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=lf[11],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t5,a[3]=lf[13],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port1236 */
t7=t6;
f_1515(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader1334 */
t9=t5;
f_1510(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max1431 */
t11=t4;
f_1505(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body1016 */
t13=t3;
f_1445(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port12 in read-file in k1439 */
static void C_fcall f_1515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,2,t0,t1);}
/* def-reader1334 */
t2=((C_word*)t0)[2];
f_1510(t2,t1,*((C_word*)lf[12]+1));}

/* def-reader13 in read-file in k1439 */
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,3,t0,t1,t2);}
/* def-max1431 */
t3=((C_word*)t0)[3];
f_1505(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max14 in read-file in k1439 */
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,4,t0,t1,t2,t3);}
/* body1016 */
t4=((C_word*)t0)[2];
f_1445(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body10 in read-file in k1439 */
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1445,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=lf[7],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 120  port? */
t7=*((C_word*)lf[8]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k1496 in body10 in read-file in k1439 */
static void f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 121  slurp */
t2=((C_word*)t0)[5];
f_1448(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 122  call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body10 in read-file in k1439 */
static void f_1448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1448,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1456,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 116  read */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1454 in slurp in body10 in read-file in k1439 */
static void f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1458(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* do22 in k1454 in slurp in body10 in read-file in k1439 */
static void C_fcall f_1458(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1458,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 119  reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1478,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 116  reader */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k1476 in do22 in k1454 in slurp in body10 in read-file in k1439 */
static void f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1478,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1458(t4,((C_word*)t0)[2],t1,t2,t3);}
/* end of file */
