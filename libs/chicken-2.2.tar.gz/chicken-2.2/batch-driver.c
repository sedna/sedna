/* Generated from batch-driver.scm by the Chicken compiler
   2005-09-10 23:16
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file batch-driver.c -explicit-use
   unit: driver
*/

#include "chicken.h"

#define C_METHOD_CACHE_SIZE 8


static C_TLS C_word lf[432];


C_externexport void C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_470(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_470r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_506(C_word c,C_word t0,C_word t1) C_noret;
static void f_2631(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2624(C_word t0,C_word t1) C_noret;
static void f_2620(C_word c,C_word t0,C_word t1) C_noret;
static void f_2612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2610(C_word c,C_word t0,C_word t1) C_noret;
static void f_2606(C_word c,C_word t0,C_word t1) C_noret;
static void f_2599(C_word c,C_word t0,C_word t1) C_noret;
static void f_2577(C_word c,C_word t0,C_word t1) C_noret;
static void f_522(C_word c,C_word t0,C_word t1) C_noret;
static void f_2552(C_word c,C_word t0,C_word t1) C_noret;
static void f_2565(C_word c,C_word t0,C_word t1) C_noret;
static void f_528(C_word c,C_word t0,C_word t1) C_noret;
static void f_2543(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2546(C_word t0,C_word t1) C_noret;
static void f_531(C_word c,C_word t0,C_word t1) C_noret;
static void f_2536(C_word c,C_word t0,C_word t1) C_noret;
static void f_2532(C_word c,C_word t0,C_word t1) C_noret;
static void f_534(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_920(C_word t0,C_word t1) C_noret;
static void f_2512(C_word c,C_word t0,C_word t1) C_noret;
static void f_2508(C_word c,C_word t0,C_word t1) C_noret;
static void f_2504(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_923(C_word t0,C_word t1) C_noret;
static void f_2500(C_word c,C_word t0,C_word t1) C_noret;
static void f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2496(C_word c,C_word t0,C_word t1) C_noret;
static void f_2484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2492(C_word c,C_word t0,C_word t1) C_noret;
static void f_927(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_935(C_word t0,C_word t1) C_noret;
static void f_938(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_941(C_word t0,C_word t1) C_noret;
static void C_fcall f_944(C_word t0,C_word t1) C_noret;
static void C_fcall f_947(C_word t0,C_word t1) C_noret;
static void f_2447(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_950(C_word t0,C_word t1) C_noret;
static void C_fcall f_953(C_word t0,C_word t1) C_noret;
static void f_956(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_959(C_word t0,C_word t1) C_noret;
static void C_fcall f_962(C_word t0,C_word t1) C_noret;
static void C_fcall f_965(C_word t0,C_word t1) C_noret;
static void C_fcall f_968(C_word t0,C_word t1) C_noret;
static void C_fcall f_971(C_word t0,C_word t1) C_noret;
static void C_fcall f_974(C_word t0,C_word t1) C_noret;
static void C_fcall f_977(C_word t0,C_word t1) C_noret;
static void f_2390(C_word c,C_word t0,C_word t1) C_noret;
static void f_2393(C_word c,C_word t0,C_word t1) C_noret;
static void f_2396(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_983(C_word t0,C_word t1) C_noret;
static void f_2377(C_word c,C_word t0,C_word t1) C_noret;
static void f_2380(C_word c,C_word t0,C_word t1) C_noret;
static void f_986(C_word c,C_word t0,C_word t1) C_noret;
static void f_2371(C_word c,C_word t0,C_word t1) C_noret;
static void f_2355(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2361(C_word t0,C_word t1) C_noret;
static void f_2358(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_992(C_word t0,C_word t1) C_noret;
static void f_2321(C_word c,C_word t0,C_word t1) C_noret;
static void f_995(C_word c,C_word t0,C_word t1) C_noret;
static void f_2308(C_word c,C_word t0,C_word t1) C_noret;
static void f_2312(C_word c,C_word t0,C_word t1) C_noret;
static void f_2315(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_998(C_word t0,C_word t1) C_noret;
static void f_2305(C_word c,C_word t0,C_word t1) C_noret;
static void f_2294(C_word c,C_word t0,C_word t1) C_noret;
static void f_1004(C_word c,C_word t0,C_word t1) C_noret;
static void f_603(C_word c,C_word t0,C_word t1) C_noret;
static void f_608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_616(C_word c,C_word t0,C_word t1) C_noret;
static void f_1008(C_word c,C_word t0,C_word t1) C_noret;
static void f_2286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2275(C_word c,C_word t0,C_word t1) C_noret;
static void f_1011(C_word c,C_word t0,C_word t1) C_noret;
static void f_2272(C_word c,C_word t0,C_word t1) C_noret;
static void f_1014(C_word c,C_word t0,C_word t1) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void f_1017(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1020(C_word t0,C_word t1) C_noret;
static void f_2260(C_word c,C_word t0,C_word t1) C_noret;
static void f_1024(C_word c,C_word t0,C_word t1) C_noret;
static void f_1031(C_word c,C_word t0,C_word t1) C_noret;
static void f_2253(C_word c,C_word t0,C_word t1) C_noret;
static void f_1034(C_word c,C_word t0,C_word t1) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2250(C_word c,C_word t0,C_word t1) C_noret;
static void f_1037(C_word c,C_word t0,C_word t1) C_noret;
static void f_1041(C_word c,C_word t0,C_word t1) C_noret;
static void f_1052(C_word c,C_word t0,C_word t1) C_noret;
static void f_2224(C_word c,C_word t0,C_word t1) C_noret;
static void f_2220(C_word c,C_word t0,C_word t1) C_noret;
static void f_2208(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1055(C_word t0,C_word t1) C_noret;
static void f_2201(C_word c,C_word t0,C_word t1) C_noret;
static void f_1058(C_word c,C_word t0,C_word t1) C_noret;
static void f_2189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2187(C_word c,C_word t0,C_word t1) C_noret;
static void f_1062(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1065(C_word t0,C_word t1) C_noret;
static void f_1068(C_word c,C_word t0,C_word t1) C_noret;
static void f_2166(C_word c,C_word t0,C_word t1) C_noret;
static void f_1072(C_word c,C_word t0,C_word t1) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void f_1076(C_word c,C_word t0,C_word t1) C_noret;
static void f_2152(C_word c,C_word t0,C_word t1) C_noret;
static void f_1080(C_word c,C_word t0,C_word t1) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1) C_noret;
static void f_1084(C_word c,C_word t0,C_word t1) C_noret;
static void f_2125(C_word c,C_word t0,C_word t1) C_noret;
static void f_1088(C_word c,C_word t0,C_word t1) C_noret;
static void f_1099(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1102(C_word t0,C_word t1) C_noret;
static void f_1105(C_word c,C_word t0,C_word t1) C_noret;
static void f_2078(C_word c,C_word t0,C_word t1) C_noret;
static void f_1108(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1129(C_word t0,C_word t1) C_noret;
static void f_1144(C_word c,C_word t0,C_word t1) C_noret;
static void f_1150(C_word c,C_word t0,C_word t1) C_noret;
static void f_1154(C_word c,C_word t0,C_word t1) C_noret;
static void f_1157(C_word c,C_word t0,C_word t1) C_noret;
static void f_1160(C_word c,C_word t0,C_word t1) C_noret;
static void f_1163(C_word c,C_word t0,C_word t1) C_noret;
static void f_1166(C_word c,C_word t0,C_word t1) C_noret;
static void f_1169(C_word c,C_word t0,C_word t1) C_noret;
static void f_1173(C_word c,C_word t0,C_word t1) C_noret;
static void f_1176(C_word c,C_word t0,C_word t1) C_noret;
static void f_1179(C_word c,C_word t0,C_word t1) C_noret;
static void f_2044(C_word c,C_word t0,C_word t1) C_noret;
static void f_2052(C_word c,C_word t0,C_word t1) C_noret;
static void f_1182(C_word c,C_word t0,C_word t1) C_noret;
static void f_1185(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1974(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2003(C_word c,C_word t0,C_word t1) C_noret;
static void f_2017(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2040(C_word c,C_word t0,C_word t1) C_noret;
static void f_2006(C_word c,C_word t0,C_word t1) C_noret;
static void f_1989(C_word c,C_word t0,C_word t1) C_noret;
static void f_1993(C_word c,C_word t0,C_word t1) C_noret;
static void f_1997(C_word c,C_word t0,C_word t1) C_noret;
static void f_1985(C_word c,C_word t0,C_word t1) C_noret;
static void f_1962(C_word c,C_word t0,C_word t1) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1) C_noret;
static void f_1188(C_word c,C_word t0,C_word t1) C_noret;
static void f_1191(C_word c,C_word t0,C_word t1) C_noret;
static void f_1940(C_word c,C_word t0,C_word t1) C_noret;
static void f_1952(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1194(C_word t0,C_word t1) C_noret;
static void f_1197(C_word c,C_word t0,C_word t1) C_noret;
static void f_1203(C_word c,C_word t0,C_word t1) C_noret;
static void f_1937(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1206(C_word t0,C_word t1) C_noret;
static void f_1922(C_word c,C_word t0,C_word t1) C_noret;
static void f_1209(C_word c,C_word t0,C_word t1) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1) C_noret;
static void f_1902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1761(C_word c,C_word t0,C_word t1) C_noret;
static void f_1896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1765(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1769(C_word t0,C_word t1) C_noret;
static void f_1847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1773(C_word c,C_word t0,C_word t1) C_noret;
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1825(C_word c,C_word t0,C_word t1) C_noret;
static void f_1777(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1780(C_word t0,C_word t1) C_noret;
static void f_1218(C_word c,C_word t0,C_word t1) C_noret;
static void f_1754(C_word c,C_word t0,C_word t1) C_noret;
static void f_1221(C_word c,C_word t0,C_word t1) C_noret;
static void f_1748(C_word c,C_word t0,C_word t1) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1) C_noret;
static void f_1227(C_word c,C_word t0,C_word t1) C_noret;
static void f_1230(C_word c,C_word t0,C_word t1) C_noret;
static void f_1235(C_word c,C_word t0,C_word t1) C_noret;
static void f_1238(C_word c,C_word t0,C_word t1) C_noret;
static void f_1241(C_word c,C_word t0,C_word t1) C_noret;
static void f_1244(C_word c,C_word t0,C_word t1) C_noret;
static void f_1714(C_word c,C_word t0,C_word t1) C_noret;
static void f_1721(C_word c,C_word t0,C_word t1) C_noret;
static void f_1247(C_word c,C_word t0,C_word t1) C_noret;
static void f_1711(C_word c,C_word t0,C_word t1) C_noret;
static void f_1707(C_word c,C_word t0,C_word t1) C_noret;
static void f_1256(C_word c,C_word t0,C_word t1) C_noret;
static void f_1696(C_word c,C_word t0,C_word t1) C_noret;
static void f_1703(C_word c,C_word t0,C_word t1) C_noret;
static void f_1259(C_word c,C_word t0,C_word t1) C_noret;
static void f_1664(C_word c,C_word t0,C_word t1) C_noret;
static void f_1671(C_word c,C_word t0,C_word t1) C_noret;
static void f_1674(C_word c,C_word t0,C_word t1) C_noret;
static void f_1677(C_word c,C_word t0,C_word t1) C_noret;
static void f_1683(C_word c,C_word t0,C_word t1) C_noret;
static void f_1686(C_word c,C_word t0,C_word t1) C_noret;
static void f_1689(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1262(C_word t0,C_word t1) C_noret;
static void f_1642(C_word c,C_word t0,C_word t1) C_noret;
static void f_1645(C_word c,C_word t0,C_word t1) C_noret;
static void f_1648(C_word c,C_word t0,C_word t1) C_noret;
static void f_1654(C_word c,C_word t0,C_word t1) C_noret;
static void f_1657(C_word c,C_word t0,C_word t1) C_noret;
static void f_1660(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1265(C_word t0,C_word t1) C_noret;
static void f_1271(C_word c,C_word t0,C_word t1) C_noret;
static void f_1277(C_word c,C_word t0,C_word t1) C_noret;
static void f_1280(C_word c,C_word t0,C_word t1) C_noret;
static void f_1283(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1295(C_word c,C_word t0,C_word t1) C_noret;
static void f_1609(C_word c,C_word t0,C_word t1) C_noret;
static void f_1298(C_word c,C_word t0,C_word t1) C_noret;
static void f_1302(C_word c,C_word t0,C_word t1) C_noret;
static void f_1305(C_word c,C_word t0,C_word t1) C_noret;
static void f_1308(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1314(C_word t0,C_word t1) C_noret;
static void f_1403(C_word c,C_word t0,C_word t1) C_noret;
static void f_1409(C_word c,C_word t0,C_word t1) C_noret;
static void f_1412(C_word c,C_word t0,C_word t1) C_noret;
static void f_1415(C_word c,C_word t0,C_word t1) C_noret;
static void f_1418(C_word c,C_word t0,C_word t1) C_noret;
static void f_1421(C_word c,C_word t0,C_word t1) C_noret;
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1424(C_word c,C_word t0,C_word t1) C_noret;
static void f_1427(C_word c,C_word t0,C_word t1) C_noret;
static void f_1430(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
static void f_1556(C_word c,C_word t0,C_word t1) C_noret;
static void f_1433(C_word c,C_word t0,C_word t1) C_noret;
static void f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1491(C_word c,C_word t0,C_word t1) C_noret;
static void f_1494(C_word c,C_word t0,C_word t1) C_noret;
static void f_1497(C_word c,C_word t0,C_word t1) C_noret;
static void f_1500(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
static void f_1457(C_word c,C_word t0,C_word t1) C_noret;
static void f_1460(C_word c,C_word t0,C_word t1) C_noret;
static void f_1482(C_word c,C_word t0,C_word t1) C_noret;
static void f_1463(C_word c,C_word t0,C_word t1) C_noret;
static void f_1466(C_word c,C_word t0,C_word t1) C_noret;
static void f_1441(C_word c,C_word t0,C_word t1) C_noret;
static void f_1317(C_word c,C_word t0,C_word t1) C_noret;
static void f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1335(C_word c,C_word t0,C_word t1) C_noret;
static void f_1338(C_word c,C_word t0,C_word t1) C_noret;
static void f_1357(C_word c,C_word t0,C_word t1) C_noret;
static void f_1374(C_word c,C_word t0,C_word t1) C_noret;
static void f_1377(C_word c,C_word t0,C_word t1) C_noret;
static void f_1383(C_word c,C_word t0,C_word t1) C_noret;
static void f_1386(C_word c,C_word t0,C_word t1) C_noret;
static void f_1325(C_word c,C_word t0,C_word t1) C_noret;
static void f_1117(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_877(C_word t0,C_word t1,C_word t2) C_noret;
static void f_887(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_860(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_850(C_word t0);
static void C_fcall f_820(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_826(C_word t0,C_word t1,C_word t2) C_noret;
static void f_840(C_word c,C_word t0,C_word t1) C_noret;
static void f_844(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_740(C_word t0,C_word t1) C_noret;
static void f_809(C_word c,C_word t0,C_word t1) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void f_789(C_word c,C_word t0,C_word t1) C_noret;
static void f_781(C_word c,C_word t0,C_word t1) C_noret;
static void f_750(C_word c,C_word t0,C_word t1) C_noret;
static void f_691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_695(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_701(C_word t0,C_word t1) C_noret;
static void f_716(C_word c,C_word t0,C_word t1) C_noret;
static void f_712(C_word c,C_word t0,C_word t1) C_noret;
static void f_698(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_686(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_664(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_671(C_word c,C_word t0,C_word t1) C_noret;
static void f_674(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_642(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_649(C_word c,C_word t0,C_word t1) C_noret;
static void f_662(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_624(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_628(C_word c,C_word t0,C_word t1) C_noret;
static void f_637(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_618();
static void C_fcall f_473(C_word t0,C_word t1) C_noret;

static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2624(t0,t1);}

static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2546(t0,t1);}

static void C_fcall trf_920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_920(t0,t1);}

static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_923(t0,t1);}

static void C_fcall trf_935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_935(t0,t1);}

static void C_fcall trf_941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_941(t0,t1);}

static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_944(t0,t1);}

static void C_fcall trf_947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_947(t0,t1);}

static void C_fcall trf_950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_950(t0,t1);}

static void C_fcall trf_953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_953(t0,t1);}

static void C_fcall trf_959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_959(t0,t1);}

static void C_fcall trf_962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_962(t0,t1);}

static void C_fcall trf_965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_965(t0,t1);}

static void C_fcall trf_968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_968(t0,t1);}

static void C_fcall trf_971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_971(t0,t1);}

static void C_fcall trf_974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_974(t0,t1);}

static void C_fcall trf_977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_977(t0,t1);}

static void C_fcall trf_983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_983(t0,t1);}

static void C_fcall trf_2361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2361(t0,t1);}

static void C_fcall trf_992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_992(t0,t1);}

static void C_fcall trf_998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_998(t0,t1);}

static void C_fcall trf_1020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1020(t0,t1);}

static void C_fcall trf_1055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1055(t0,t1);}

static void C_fcall trf_1065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1065(t0,t1);}

static void C_fcall trf_1102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1102(t0,t1);}

static void C_fcall trf_1129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1129(t0,t1);}

static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1974(t0,t1,t2);}

static void C_fcall trf_2019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2019(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2019(t0,t1,t2);}

static void C_fcall trf_1194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1194(t0,t1);}

static void C_fcall trf_1206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1206(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1206(t0,t1);}

static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1769(t0,t1);}

static void C_fcall trf_1780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1780(t0,t1);}

static void C_fcall trf_1262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1262(t0,t1);}

static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1265(t0,t1);}

static void C_fcall trf_1288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1288(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1288(t0,t1,t2,t3,t4);}

static void C_fcall trf_1314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1314(t0,t1);}

static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

static void C_fcall trf_1484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1484(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1484(t0,t1,t2,t3);}

static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

static void C_fcall trf_877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_877(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_877(t0,t1,t2);}

static void C_fcall trf_860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_860(t0,t1,t2);}

static void C_fcall trf_820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_820(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_820(t0,t1,t2);}

static void C_fcall trf_826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_826(t0,t1,t2);}

static void C_fcall trf_740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_740(t0,t1);}

static void C_fcall trf_701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_701(t0,t1);}

static void C_fcall trf_679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_679(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_679(t0,t1,t2,t3,t4);}

static void C_fcall trf_664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_664(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_664(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_642(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_642(t0,t1,t2,t3,t4);}

static void C_fcall trf_624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_624(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_624(t0,t1,t2,t3);}

static void C_fcall trf_473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_473(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2847)){
C_save(t1);
C_rereclaim2(2847*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,432);
lf[1]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[3]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
lf[11]=C_static_string(C_heaptop,6,".dylib");
lf[13]=C_static_string(C_heaptop,4,".dll");
lf[15]=C_static_string(C_heaptop,3,".sl");
lf[17]=C_static_string(C_heaptop,3,".so");
lf[19]=C_static_string(C_heaptop,4,".scm");
lf[21]=C_static_string(C_heaptop,6,".setup");
lf[23]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[25]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[27]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[29]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[31]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[33]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[35]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[37]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[39]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[40]=C_h_intern(&lf[40],19,"compile-source-file");
lf[41]=C_h_intern(&lf[41],4,"quit");
lf[42]=C_static_string(C_heaptop,32,"missing argument to `-~A\047 option");
lf[43]=C_static_string(C_heaptop,31,"invalid argument to `~A\047 option");
lf[44]=C_static_lambda_info(C_heaptop,16,"(option-arg p51)");
lf[45]=C_h_intern(&lf[45],12,"explicit-use");
lf[46]=C_h_intern(&lf[46],26,"\010compilerexplicit-use-flag");
lf[47]=C_h_intern(&lf[47],7,"verbose");
lf[48]=C_h_intern(&lf[48],11,"output-file");
lf[49]=C_h_intern(&lf[49],5,"split");
lf[50]=C_h_intern(&lf[50],36,"\010compilerdefault-optimization-passes");
tmp=C_intern(C_heaptop,25,"\003sysimplicit-exit-handler");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[51]=C_h_pair(C_restore,tmp);
lf[52]=C_h_intern(&lf[52],7,"profile");
lf[53]=C_h_intern(&lf[53],18,"accumulate-profile");
lf[54]=C_h_intern(&lf[54],9,"heap-size");
lf[55]=C_h_intern(&lf[55],17,"heap-initial-size");
lf[56]=C_h_intern(&lf[56],11,"heap-growth");
lf[57]=C_h_intern(&lf[57],14,"heap-shrinkage");
lf[58]=C_h_intern(&lf[58],13,"keyword-style");
lf[59]=C_h_intern(&lf[59],17,"compress-literals");
lf[60]=C_h_intern(&lf[60],4,"unit");
lf[61]=C_h_intern(&lf[61],12,"analyze-only");
lf[62]=C_h_intern(&lf[62],7,"dynamic");
lf[63]=C_h_intern(&lf[63],3,"ffi");
lf[64]=C_h_intern(&lf[64],9,"ffi-parse");
lf[65]=C_h_intern(&lf[65],5,"quiet");
lf[66]=C_h_intern(&lf[66],7,"nursery");
lf[67]=C_h_intern(&lf[67],10,"stack-size");
lf[68]=C_static_lambda_info(C_heaptop,9,"(cputime)");
lf[69]=C_h_intern(&lf[69],26,"\010compilerdebugging-chicken");
lf[70]=C_h_intern(&lf[70],6,"printf");
lf[71]=C_static_string(C_heaptop,6,"[~a]~%");
lf[72]=C_static_string(C_heaptop,12,"pass: ~a~%~!");
lf[73]=C_static_lambda_info(C_heaptop,33,"(print-header mode115 dbgmode116)");
lf[74]=C_h_intern(&lf[74],19,"\010compilerdump-nodes");
lf[75]=C_h_intern(&lf[75],12,"pretty-print");
lf[76]=C_h_intern(&lf[76],30,"\010compilerbuild-expression-tree");
lf[77]=C_static_lambda_info(C_heaptop,36,"(print-node mode119 dbgmode120 n121)");
lf[78]=C_h_intern(&lf[78],34,"\010compilerdisplay-analysis-database");
lf[79]=C_static_string(C_heaptop,16,"(iteration ~s)~%");
lf[80]=C_static_lambda_info(C_heaptop,43,"(print-db mode122 dbgmode123 db124 pass125)");
lf[81]=C_h_intern(&lf[81],12,"\003sysfor-each");
lf[82]=C_static_lambda_info(C_heaptop,32,"(print mode127 dbgmode128 xs129)");
lf[83]=C_h_intern(&lf[83],19,"\003syshash-table-set!");
lf[84]=C_h_intern(&lf[84],24,"\003sysline-number-database");
lf[85]=C_h_intern(&lf[85],10,"alist-cons");
lf[86]=C_h_intern(&lf[86],18,"\003syshash-table-ref");
lf[87]=C_h_intern(&lf[87],9,"list-info");
lf[88]=C_h_intern(&lf[88],26,"\003sysdefault-read-info-hook");
lf[89]=C_static_lambda_info(C_heaptop,22,"(f_737 a136 b137 c138)");
lf[90]=C_static_lambda_info(C_heaptop,34,"(infohook class130 data131 val132)");
lf[91]=C_static_string(C_heaptop,27,"invalid numeric argument ~S");
lf[92]=C_h_intern(&lf[92],9,"substring");
lf[93]=C_static_lambda_info(C_heaptop,16,"(arg-val str142)");
lf[94]=C_static_lambda_info(C_heaptop,14,"(loop opts155)");
lf[95]=C_static_lambda_info(C_heaptop,24,"(collect-options opt153)");
lf[96]=C_static_lambda_info(C_heaptop,12,"(begin-time)");
lf[97]=C_static_string(C_heaptop,33,"milliseconds needed for ~a: \011~s~%");
lf[98]=C_static_lambda_info(C_heaptop,18,"(end-time pass160)");
lf[99]=C_static_string(C_heaptop,0,"");
lf[100]=C_h_intern(&lf[100],15,"foreign-declare");
lf[101]=C_h_intern(&lf[101],13,"foreign-parse");
lf[102]=C_h_intern(&lf[102],7,"declare");
lf[103]=C_h_intern(&lf[103],11,"read-string");
lf[104]=C_h_intern(&lf[104],8,"\003sysread");
lf[105]=C_static_lambda_info(C_heaptop,17,"(read-form in161)");
lf[106]=C_h_intern(&lf[106],19,"\010compilertry-harder");
lf[107]=C_h_intern(&lf[107],1,"D");
lf[108]=C_h_intern(&lf[108],12,"inline-limit");
lf[109]=C_h_intern(&lf[109],20,"\010compilersplit-level");
lf[110]=C_h_intern(&lf[110],21,"\010compilerverbose-mode");
lf[111]=C_h_intern(&lf[111],31,"\003sysread-error-with-line-number");
lf[112]=C_h_intern(&lf[112],21,"\003sysinclude-pathnames");
lf[113]=C_h_intern(&lf[113],30,"\010compilerffi-include-path-list");
lf[114]=C_h_intern(&lf[114],19,"\000compiler-extension");
lf[115]=C_h_intern(&lf[115],12,"\003sysfeatures");
lf[116]=C_h_intern(&lf[116],10,"\000compiling");
lf[117]=C_h_intern(&lf[117],14,"\000match-support");
lf[118]=C_h_intern(&lf[118],6,"\000match");
lf[119]=C_h_intern(&lf[119],25,"\010compilertarget-heap-size");
lf[120]=C_h_intern(&lf[120],33,"\010compilertarget-initial-heap-size");
lf[121]=C_h_intern(&lf[121],27,"\010compilertarget-heap-growth");
lf[122]=C_h_intern(&lf[122],30,"\010compilertarget-heap-shrinkage");
lf[123]=C_h_intern(&lf[123],26,"\010compilertarget-stack-size");
lf[124]=C_h_intern(&lf[124],8,"no-trace");
lf[125]=C_h_intern(&lf[125],24,"\010compileremit-trace-info");
lf[126]=C_h_intern(&lf[126],29,"disable-stack-overflow-checks");
lf[127]=C_h_intern(&lf[127],40,"\010compilerdisable-stack-overflow-checking");
lf[128]=C_h_intern(&lf[128],7,"version");
lf[129]=C_h_intern(&lf[129],7,"newline");
lf[130]=C_h_intern(&lf[130],22,"\010compilerprint-version");
lf[131]=C_h_intern(&lf[131],4,"help");
lf[132]=C_h_intern(&lf[132],20,"\010compilerprint-usage");
lf[133]=C_h_intern(&lf[133],24,"\010compilersource-filename");
lf[134]=C_h_intern(&lf[134],28,"\010compilerprofile-lambda-list");
lf[135]=C_h_intern(&lf[135],31,"\010compilerline-number-database-2");
lf[136]=C_h_intern(&lf[136],4,"node");
lf[137]=C_h_intern(&lf[137],6,"lambda");
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[138]=C_h_pair(C_restore,tmp);
lf[139]=C_h_intern(&lf[139],23,"\010compilerconstant-table");
lf[140]=C_h_intern(&lf[140],21,"\010compilerinline-table");
lf[141]=C_h_intern(&lf[141],23,"\010compilerfirst-analysis");
lf[142]=C_h_intern(&lf[142],41,"\010compilerperform-high-level-optimizations");
lf[143]=C_static_lambda_info(C_heaptop,7,"(a1324)");
lf[144]=C_h_intern(&lf[144],37,"\010compilerinline-substitutions-enabled");
lf[145]=C_h_intern(&lf[145],22,"optimize-leaf-routines");
lf[146]=C_static_string(C_heaptop,25,"leaf routine optimization");
lf[147]=C_h_intern(&lf[147],34,"\010compilertransform-direct-lambdas!");
lf[148]=C_static_string(C_heaptop,8,"analysis");
lf[149]=C_h_intern(&lf[149],27,"\010compileranalyze-expression");
lf[150]=C_h_intern(&lf[150],18,"\010compilerdebugging");
lf[151]=C_h_intern(&lf[151],1,"p");
lf[152]=C_static_string(C_heaptop,21,"rewritings enabled...");
lf[153]=C_static_string(C_heaptop,19,"optimized-iteration");
lf[154]=C_h_intern(&lf[154],1,"5");
lf[155]=C_static_string(C_heaptop,12,"optimization");
lf[156]=C_static_lambda_info(C_heaptop,33,"(a1330 node2276 progress-flag277)");
lf[157]=C_static_string(C_heaptop,17,"optimization pass");
lf[158]=C_h_intern(&lf[158],36,"\010compilerprepare-for-code-generation");
lf[159]=C_static_lambda_info(C_heaptop,7,"(a1440)");
lf[160]=C_static_string(C_heaptop,25,"compilation finished.~%~!");
lf[161]=C_h_intern(&lf[161],30,"\010compilercompiler-cleanup-hook");
lf[162]=C_h_intern(&lf[162],1,"t");
lf[163]=C_h_intern(&lf[163],17,"\003sysdisplay-times");
lf[164]=C_h_intern(&lf[164],14,"\003sysstop-timer");
lf[165]=C_static_string(C_heaptop,15,"code generation");
lf[166]=C_h_intern(&lf[166],17,"close-output-port");
lf[167]=C_h_intern(&lf[167],22,"\010compilergenerate-code");
lf[168]=C_static_string(C_heaptop,21,"generating `~A\047 ...~%");
lf[169]=C_h_intern(&lf[169],16,"open-output-file");
lf[170]=C_h_intern(&lf[170],19,"current-output-port");
lf[171]=C_static_lambda_info(C_heaptop,35,"(loopfile lof309 file-partition310)");
lf[172]=C_static_string(C_heaptop,11,"preparation");
lf[173]=C_static_lambda_info(C_heaptop,38,"(a1446 node305 literals306 lambdas307)");
lf[174]=C_static_string(C_heaptop,27,"files to be generated: ~A~%");
lf[175]=C_h_intern(&lf[175],18,"string-intersperse");
lf[176]=C_static_string(C_heaptop,2,", ");
lf[177]=C_static_string(C_heaptop,17,"closure-converted");
lf[178]=C_h_intern(&lf[178],1,"9");
lf[179]=C_h_intern(&lf[179],4,"exit");
lf[180]=C_h_intern(&lf[180],12,"\010compilerget");
lf[181]=C_static_lambda_info(C_heaptop,24,"(f_1576 g294296 g295297)");
lf[182]=C_static_lambda_info(C_heaptop,17,"(a1573 k292 p293)");
lf[183]=C_h_intern(&lf[183],13,"\010compilerput!");
lf[184]=C_static_lambda_info(C_heaptop,24,"(f_1584 g301303 g302304)");
lf[185]=C_static_lambda_info(C_heaptop,22,"(a1581 k298 p299 x300)");
lf[186]=C_h_intern(&lf[186],23,"user-post-analysis-pass");
lf[187]=C_h_intern(&lf[187],1,"e");
lf[188]=C_h_intern(&lf[188],30,"\010compilerdump-exported-globals");
lf[189]=C_static_string(C_heaptop,14,"final-analysis");
lf[190]=C_h_intern(&lf[190],1,"8");
lf[191]=C_static_string(C_heaptop,18,"closure conversion");
lf[192]=C_h_intern(&lf[192],35,"\010compilerperform-closure-conversion");
lf[193]=C_static_string(C_heaptop,9,"optimized");
lf[194]=C_h_intern(&lf[194],1,"7");
lf[195]=C_h_intern(&lf[195],1,"s");
lf[196]=C_h_intern(&lf[196],33,"\010compilerprint-program-statistics");
lf[197]=C_static_string(C_heaptop,8,"analysis");
lf[198]=C_h_intern(&lf[198],1,"4");
lf[199]=C_static_string(C_heaptop,8,"analysis");
lf[200]=C_h_intern(&lf[200],1,"u");
lf[201]=C_h_intern(&lf[201],31,"\010compilerdump-undefined-globals");
lf[202]=C_h_intern(&lf[202],29,"\010compilercheck-global-exports");
lf[203]=C_static_lambda_info(C_heaptop,32,"(loop i269 node2270 progress271)");
lf[204]=C_static_string(C_heaptop,3,"cps");
lf[205]=C_h_intern(&lf[205],1,"3");
lf[206]=C_static_string(C_heaptop,14,"cps conversion");
lf[207]=C_h_intern(&lf[207],31,"\010compilerperform-cps-conversion");
lf[208]=C_h_intern(&lf[208],6,"unsafe");
lf[209]=C_h_intern(&lf[209],34,"\010compilerscan-toplevel-assignments");
lf[210]=C_h_intern(&lf[210],26,"\010compilerdo-lambda-lifting");
lf[211]=C_static_string(C_heaptop,13,"lambda lifted");
lf[212]=C_h_intern(&lf[212],1,"L");
lf[213]=C_static_string(C_heaptop,14,"lambda lifting");
lf[214]=C_h_intern(&lf[214],32,"\010compilerperform-lambda-lifting!");
lf[215]=C_static_string(C_heaptop,12,"pre-analysis");
lf[216]=C_static_string(C_heaptop,8,"analysis");
lf[217]=C_h_intern(&lf[217],1,"0");
lf[218]=C_static_string(C_heaptop,19,"secondary user pass");
lf[219]=C_h_intern(&lf[219],1,"U");
lf[220]=C_static_string(C_heaptop,19,"secondary user pass");
lf[221]=C_static_string(C_heaptop,16,"pre-analysis (u)");
lf[222]=C_static_string(C_heaptop,12,"analysis (u)");
lf[223]=C_static_string(C_heaptop,24,"Secondary user pass...~%");
lf[224]=C_h_intern(&lf[224],17,"hash-table->alist");
lf[225]=C_h_intern(&lf[225],26,"\010compilerfile-requirements");
lf[226]=C_h_intern(&lf[226],1,"M");
lf[227]=C_static_string(C_heaptop,15,"; requirements:");
lf[228]=C_h_intern(&lf[228],11,"user-pass-2");
lf[229]=C_h_intern(&lf[229],25,"\010compilerbuild-node-graph");
lf[230]=C_h_intern(&lf[230],32,"\010compilercanonicalize-begin-body");
lf[231]=C_static_string(C_heaptop,9,"user pass");
lf[232]=C_h_intern(&lf[232],7,"\003sysmap");
lf[233]=C_static_string(C_heaptop,16,"User pass...~%~!");
lf[234]=C_h_intern(&lf[234],9,"user-pass");
lf[235]=C_h_intern(&lf[235],12,"check-syntax");
lf[236]=C_static_string(C_heaptop,13,"canonicalized");
lf[237]=C_h_intern(&lf[237],1,"2");
lf[238]=C_static_string(C_heaptop,16,"canonicalization");
lf[239]=C_h_intern(&lf[239],18,"\010compilerunit-name");
lf[240]=C_h_intern(&lf[240],7,"warning");
lf[241]=C_static_string(C_heaptop,42,"library unit `~a\047 compiled in dynamic mode");
lf[242]=C_h_intern(&lf[242],26,"\010compilerblock-compilation");
lf[243]=C_static_string(C_heaptop,96,"compilation of library unit `~a\047 in block-mode - globals may not be accessible o"
"utside this unit");
lf[244]=C_h_intern(&lf[244],37,"\010compilerdisplay-line-number-database");
lf[245]=C_h_intern(&lf[245],1,"n");
lf[246]=C_static_string(C_heaptop,21,"line number database:");
lf[247]=C_h_intern(&lf[247],32,"\010compilerdisplay-real-name-table");
lf[248]=C_h_intern(&lf[248],1,"N");
lf[249]=C_static_string(C_heaptop,16,"real name table:");
lf[250]=C_h_intern(&lf[250],6,"append");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[251]=C_h_pair(C_restore,tmp);
lf[252]=C_h_intern(&lf[252],40,"\010compilercompressed-literals-initializer");
lf[253]=C_h_intern(&lf[253],9,"\004coreset!");
lf[254]=C_h_intern(&lf[254],5,"quote");
lf[255]=C_h_intern(&lf[255],20,"\003sysread-from-string");
lf[256]=C_h_intern(&lf[256],4,"set!");
lf[257]=C_h_intern(&lf[257],3,"let");
lf[258]=C_h_intern(&lf[258],6,"gensym");
lf[259]=C_static_lambda_info(C_heaptop,19,"(a1808 clf236 r237)");
lf[260]=C_h_intern(&lf[260],4,"fold");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[261]=C_h_pair(C_restore,tmp);
lf[262]=C_h_intern(&lf[262],28,"\010compilercompressed-literals");
lf[263]=C_h_intern(&lf[263],11,"\004coreinline");
lf[264]=C_static_string(C_heaptop,11,"C_i_setslot");
lf[265]=C_h_intern(&lf[265],33,"\010compilerprofile-info-vector-name");
lf[266]=C_static_lambda_info(C_heaptop,13,"(a1846 pl234)");
lf[267]=C_h_intern(&lf[267],21,"\010compileremit-profile");
lf[268]=C_static_string(C_heaptop,7,"PROFILE");
lf[269]=C_h_intern(&lf[269],25,"\003sysregister-profile-info");
lf[270]=C_h_intern(&lf[270],13,"\004corecallunit");
lf[271]=C_static_lambda_info(C_heaptop,12,"(a1895 n233)");
lf[272]=C_h_intern(&lf[272],19,"\010compilerused-units");
lf[273]=C_static_lambda_info(C_heaptop,13,"(a1901 ic232)");
lf[274]=C_h_intern(&lf[274],28,"\010compilerimmutable-constants");
lf[275]=C_h_intern(&lf[275],32,"\010compilercanonicalize-expression");
lf[276]=C_h_intern(&lf[276],8,"\003syscons");
lf[277]=C_h_intern(&lf[277],4,"uses");
lf[278]=C_static_string(C_heaptop,6,"source");
lf[279]=C_h_intern(&lf[279],1,"1");
lf[280]=C_static_string(C_heaptop,30,"User preprocessing pass...~%~!");
lf[281]=C_h_intern(&lf[281],22,"user-preprocessor-pass");
lf[282]=C_static_string(C_heaptop,21,"User read pass...~%~!");
lf[283]=C_h_intern(&lf[283],21,"\010compilerstring->expr");
lf[284]=C_h_intern(&lf[284],7,"reverse");
lf[285]=C_h_intern(&lf[285],33,"\010compilerclose-checked-input-file");
lf[286]=C_static_lambda_info(C_heaptop,12,"(do218 x220)");
lf[287]=C_h_intern(&lf[287],34,"\010compilercheck-and-open-input-file");
lf[288]=C_static_lambda_info(C_heaptop,16,"(do213 files215)");
lf[289]=C_h_intern(&lf[289],14,"user-read-pass");
lf[290]=C_h_intern(&lf[290],8,"epilogue");
lf[291]=C_h_intern(&lf[291],8,"prologue");
lf[292]=C_h_intern(&lf[292],8,"postlude");
lf[293]=C_h_intern(&lf[293],7,"prelude");
lf[294]=C_h_intern(&lf[294],11,"make-vector");
lf[295]=C_h_intern(&lf[295],34,"\010compilerline-number-database-size");
lf[296]=C_h_intern(&lf[296],1,"r");
lf[297]=C_static_string(C_heaptop,17,"compiler features");
lf[298]=C_h_intern(&lf[298],26,"\010compilercompiler-features");
lf[299]=C_static_string(C_heaptop,17,"target stack size");
lf[300]=C_static_string(C_heaptop,16,"target heap size");
lf[301]=C_static_string(C_heaptop,14,"home directory");
lf[302]=C_static_string(C_heaptop,17,"debugging options");
lf[303]=C_static_string(C_heaptop,7,"options");
lf[304]=C_static_string(C_heaptop,20,"compiling `~a\047 ...~%");
lf[305]=C_h_intern(&lf[305],7,"display");
lf[306]=C_static_string(C_heaptop,58,"\012\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[307]=C_h_intern(&lf[307],5,"-help");
lf[308]=C_h_intern(&lf[308],1,"h");
lf[309]=C_h_intern(&lf[309],2,"-h");
lf[310]=C_static_string(C_heaptop,12,"accumulated ");
lf[311]=C_static_string(C_heaptop,0,"");
lf[312]=C_static_string(C_heaptop,24,"Generating ~aprofile~%~!");
tmp=C_intern(C_heaptop,4,"set!");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"\003sysprofile-append-mode");
C_save(tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[313]=C_h_pair(C_restore,tmp);
lf[314]=C_h_intern(&lf[314],39,"\010compilerdefault-profiling-declarations");
lf[315]=C_static_string(C_heaptop,10,"stacktrace");
lf[316]=C_static_string(C_heaptop,4,"none");
lf[317]=C_static_string(C_heaptop,22,"debugging info: ~A~%~!");
lf[318]=C_h_intern(&lf[318],21,"no-usual-integrations");
lf[319]=C_h_intern(&lf[319],17,"standard-bindings");
lf[320]=C_h_intern(&lf[320],34,"\010compilerdefault-standard-bindings");
lf[321]=C_h_intern(&lf[321],17,"extended-bindings");
lf[322]=C_h_intern(&lf[322],34,"\010compilerdefault-extended-bindings");
lf[323]=C_h_intern(&lf[323],1,"m");
lf[324]=C_h_intern(&lf[324],14,"set-gc-report!");
lf[325]=C_h_intern(&lf[325],42,"\010compilerdefault-default-target-stack-size");
lf[326]=C_h_intern(&lf[326],41,"\010compilerdefault-default-target-heap-size");
lf[327]=C_h_intern(&lf[327],41,"\010compilerenable-sharp-greater-read-syntax");
lf[328]=C_h_intern(&lf[328],15,"run-time-macros");
lf[329]=C_h_intern(&lf[329],25,"\003sysenable-runtime-macros");
lf[330]=C_h_intern(&lf[330],22,"\004corerequire-extension");
lf[331]=C_static_lambda_info(C_heaptop,12,"(a2188 r193)");
lf[332]=C_h_intern(&lf[332],14,"string->symbol");
lf[333]=C_h_intern(&lf[333],17,"require-extension");
lf[334]=C_h_intern(&lf[334],9,"extension");
lf[335]=C_h_intern(&lf[335],16,"define-extension");
lf[336]=C_h_intern(&lf[336],13,"pathname-file");
lf[337]=C_static_string(C_heaptop,45,"no filename available for `-extension\047 option");
lf[338]=C_h_intern(&lf[338],11,"\003sysprovide");
lf[339]=C_h_intern(&lf[339],5,"match");
lf[340]=C_h_intern(&lf[340],6,"delete");
lf[341]=C_h_intern(&lf[341],3,"eq\077");
lf[342]=C_h_intern(&lf[342],4,"load");
lf[343]=C_h_intern(&lf[343],28,"\003sysresolve-include-filename");
lf[344]=C_static_lambda_info(C_heaptop,12,"(a2241 f190)");
lf[345]=C_h_intern(&lf[345],12,"load-verbose");
lf[346]=C_static_string(C_heaptop,34,"Loading compiler extensions...~%~!");
lf[347]=C_h_intern(&lf[347],6,"extend");
lf[348]=C_h_intern(&lf[348],16,"ffi-include-path");
lf[349]=C_h_intern(&lf[349],14,"ffi-no-include");
lf[350]=C_h_intern(&lf[350],25,"\010compilerffi-dont-include");
lf[351]=C_h_intern(&lf[351],27,"\010compilerregister-ffi-macro");
lf[352]=C_h_intern(&lf[352],10,"ffi-define");
lf[353]=C_h_intern(&lf[353],17,"register-feature!");
lf[354]=C_h_intern(&lf[354],7,"feature");
lf[355]=C_static_string(C_heaptop,40,"source- and output-filename are the same");
lf[356]=C_static_lambda_info(C_heaptop,15,"(a2285 g186187)");
lf[357]=C_h_intern(&lf[357],3,"any");
lf[358]=C_h_intern(&lf[358],13,"make-pathname");
lf[359]=C_h_intern(&lf[359],7,"sprintf");
lf[360]=C_static_string(C_heaptop,6,"~A~A.c");
lf[361]=C_static_lambda_info(C_heaptop,11,"(a607 i114)");
lf[362]=C_h_intern(&lf[362],13,"list-tabulate");
lf[363]=C_h_intern(&lf[363],23,"\010compilerchop-separator");
lf[364]=C_h_intern(&lf[364],12,"include-path");
lf[365]=C_h_intern(&lf[365],38,"\010compilerliteral-compression-threshold");
lf[366]=C_static_string(C_heaptop,51,"invalid argument to `-compress-literals\047 option: ~A");
lf[367]=C_static_string(C_heaptop,6,"prefix");
lf[368]=C_h_intern(&lf[368],7,"\000prefix");
lf[369]=C_static_string(C_heaptop,4,"none");
lf[370]=C_h_intern(&lf[370],5,"\000none");
lf[371]=C_static_string(C_heaptop,6,"suffix");
lf[372]=C_h_intern(&lf[372],7,"\000suffix");
lf[373]=C_static_string(C_heaptop,43,"invalid argument to `-keyword-style\047 option");
lf[374]=C_static_string(C_heaptop,41,"invalid argument to `-split-level\047 option");
lf[375]=C_h_intern(&lf[375],16,"case-insensitive");
lf[376]=C_h_intern(&lf[376],14,"case-sensitive");
lf[377]=C_static_string(C_heaptop,48,"Identifiers and symbols are case insensitive~%~!");
lf[378]=C_h_intern(&lf[378],24,"\010compilerinline-max-size");
lf[379]=C_static_string(C_heaptop,48,"invalid argument to `-inline-limit\047 option: `~A\047");
lf[380]=C_h_intern(&lf[380],6,"inline");
lf[381]=C_h_intern(&lf[381],30,"emit-external-prototypes-first");
lf[382]=C_h_intern(&lf[382],30,"\010compilerexternal-protos-first");
lf[383]=C_h_intern(&lf[383],23,"disable-c-syntax-checks");
lf[384]=C_h_intern(&lf[384],27,"\010compilerno-c-syntax-checks");
lf[385]=C_h_intern(&lf[385],5,"block");
lf[386]=C_h_intern(&lf[386],17,"fixnum-arithmetic");
lf[387]=C_h_intern(&lf[387],11,"number-type");
lf[388]=C_h_intern(&lf[388],6,"fixnum");
lf[389]=C_h_intern(&lf[389],18,"disable-interrupts");
lf[390]=C_h_intern(&lf[390],28,"\010compilerinsert-timer-checks");
lf[391]=C_h_intern(&lf[391],16,"unsafe-libraries");
lf[392]=C_h_intern(&lf[392],27,"\010compileremit-unsafe-marker");
lf[393]=C_h_intern(&lf[393],23,"\005matchset-error-control");
lf[394]=C_h_intern(&lf[394],12,"\000unspecified");
lf[395]=C_h_intern(&lf[395],11,"no-warnings");
lf[396]=C_h_intern(&lf[396],25,"\010compilerwarnings-enabled");
lf[397]=C_h_intern(&lf[397],20,"\003syswarnings-enabled");
lf[398]=C_static_string(C_heaptop,25,"Warnings are disabled~%~!");
lf[399]=C_h_intern(&lf[399],14,"no-lambda-info");
lf[400]=C_h_intern(&lf[400],26,"\010compileremit-closure-info");
lf[401]=C_h_intern(&lf[401],3,"raw");
lf[402]=C_h_intern(&lf[402],1,"b");
lf[403]=C_h_intern(&lf[403],15,"\003sysstart-timer");
lf[404]=C_h_intern(&lf[404],11,"lambda-lift");
lf[405]=C_h_intern(&lf[405],6,"string");
lf[406]=C_static_lambda_info(C_heaptop,12,"(a2483 c168)");
lf[407]=C_h_intern(&lf[407],12,"string->list");
lf[408]=C_static_lambda_info(C_heaptop,13,"(a2477 do167)");
lf[409]=C_h_intern(&lf[409],10,"append-map");
lf[410]=C_h_intern(&lf[410],5,"debug");
lf[411]=C_h_intern(&lf[411],29,"\010compilerstring->c-identifier");
lf[412]=C_h_intern(&lf[412],18,"\010compilerstringify");
lf[413]=C_static_string(C_heaptop,0,"");
lf[414]=C_h_intern(&lf[414],12,"string-split");
lf[415]=C_static_string(C_heaptop,1,";");
lf[416]=C_h_intern(&lf[416],6,"getenv");
lf[417]=C_static_string(C_heaptop,20,"CHICKEN_INCLUDE_PATH");
lf[418]=C_h_intern(&lf[418],34,"\010compilerdefault-installation-home");
lf[419]=C_static_string(C_heaptop,0,"");
lf[420]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[421]=C_h_intern(&lf[421],14,"symbol->string");
lf[422]=C_h_intern(&lf[422],9,"to-stdout");
lf[423]=C_static_string(C_heaptop,1,"c");
lf[424]=C_static_string(C_heaptop,3,"out");
lf[425]=C_h_intern(&lf[425],12,"\004coredeclare");
lf[426]=C_static_lambda_info(C_heaptop,11,"(a2611 x80)");
lf[427]=C_h_intern(&lf[427],29,"\010compilerdefault-declarations");
lf[428]=C_h_intern(&lf[428],30,"\010compilerunits-used-by-default");
lf[429]=C_h_intern(&lf[429],28,"\010compilerinitialize-compiler");
lf[430]=C_static_lambda_info(C_heaptop,44,"(compile-source-file filename48 . options49)");
lf[431]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,432);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=lf[430],tmp=(C_word)a,a+=3,tmp));
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* compile-source-file */
static void f_470(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_470r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_470r(t0,t1,t2,t3);}}

static void f_470r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=lf[44],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_506,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=C_retrieve(lf[429]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k504 in compile-source-file */
static void f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_506,2,t0,t1);}
t2=(C_word)C_i_memq(lf[45],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[46]+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2610,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2612,a[2]=lf[426],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2620,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2624,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[46]))){
t9=t8;
f_2624(t9,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,lf[277],C_retrieve(lf[428]));}}

/* k2629 in k504 in compile-source-file */
static void f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2624(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2622 in k504 in compile-source-file */
static void C_fcall f_2624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[427]),t1);}

/* k2618 in k504 in compile-source-file */
static void f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2611 in k504 in compile-source-file */
static void f_2612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2612,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[254],t2));}

/* k2608 in k504 in compile-source-file */
static void f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[425],t1);}

/* k2604 in k504 in compile-source-file */
static void f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_memq(lf[47],((C_word*)t0)[5]);
t6=(C_word)C_i_memq(lf[48],((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
f_473(t8,t6);}
else{
if(C_truep((C_word)C_i_memq(lf[422],((C_word*)t0)[5]))){
t8=t7;
f_522(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t9=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[2]);}
else{
t9=t8;
f_2599(2,t9,lf[424]);}}}}

/* k2597 in k2604 in k504 in compile-source-file */
static void f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[358]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[423]);}

/* k2575 in k2604 in k504 in compile-source-file */
static void f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
t2=*((C_word*)lf[421]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_522(2,t2,t1);}}

/* k520 in k2604 in k504 in compile-source-file */
static void f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_522,2,t0,t1);}
t2=(C_word)C_i_memq(lf[49],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_528,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2552,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
f_473(t4,t2);}
else{
t4=t3;
f_528(2,t4,C_fix(1));}}

/* k2550 in k520 in k2604 in k504 in compile-source-file */
static void f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[421]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
if(C_truep((C_word)C_i_stringp(t1))){
C_string_to_number(3,0,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_528(2,t2,t1);}}}

/* k2563 in k2550 in k520 in k2604 in k504 in compile-source-file */
static void f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k526 in k520 in k2604 in k504 in compile-source-file */
static void f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_retrieve(lf[416]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[420]);}

/* k2541 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2546(t3,t1);}
else{
t3=C_retrieve(lf[418]);
t4=t2;
f_2546(t4,(C_truep(t3)?t3:lf[419]));}}

/* k2544 in k2541 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_2546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[363]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_534,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_retrieve(lf[416]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[417]);}

/* k2534 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[413]);
t3=C_retrieve(lf[414]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[415]);}

/* k2530 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[363]),t1);}

/* k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[98],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_534,2,t0,t1);}
t2=C_retrieve(lf[50]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[51];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[52],((C_word*)t0)[10]);
t12=(C_truep(t11)?t11:(C_word)C_i_memq(lf[53],((C_word*)t0)[10]));
t13=(C_word)C_i_memq(lf[54],((C_word*)t0)[10]);
t14=(C_word)C_i_memq(lf[55],((C_word*)t0)[10]);
t15=(C_word)C_i_memq(lf[56],((C_word*)t0)[10]);
t16=(C_word)C_i_memq(lf[57],((C_word*)t0)[10]);
t17=(C_word)C_i_memq(lf[58],((C_word*)t0)[10]);
t18=(C_word)C_i_memq(lf[59],((C_word*)t0)[10]);
t19=(C_word)C_i_memq(lf[60],((C_word*)t0)[10]);
t20=(C_word)C_i_memq(lf[61],((C_word*)t0)[10]);
t21=(C_word)C_i_memq(lf[62],((C_word*)t0)[10]);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(C_word)C_i_memq(lf[63],((C_word*)t0)[10]);
t25=(C_word)C_i_memq(lf[64],((C_word*)t0)[10]);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=(C_word)C_i_memq(lf[65],((C_word*)t0)[10]);
t29=(C_word)C_i_memq(lf[66],((C_word*)t0)[10]);
t30=(C_truep(t29)?t29:(C_word)C_i_memq(lf[67],((C_word*)t0)[10]));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_618,a[2]=lf[68],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[9],a[3]=lf[73],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_642,a[2]=t32,a[3]=t23,a[4]=lf[77],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_664,a[2]=t32,a[3]=lf[80],tmp=(C_word)a,a+=4,tmp);
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_679,a[2]=t32,a[3]=lf[82],tmp=(C_word)a,a+=4,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_691,a[2]=lf[90],tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=lf[93],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_820,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=lf[95],tmp=(C_word)a,a+=5,tmp);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_850,a[2]=t4,a[3]=t31,a[4]=t6,a[5]=lf[96],tmp=(C_word)a,a+=6,tmp);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_860,a[2]=t4,a[3]=t31,a[4]=t6,a[5]=lf[98],tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_877,a[2]=t36,a[3]=t25,a[4]=t24,a[5]=lf[105],tmp=(C_word)a,a+=6,tmp);
t42=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_920,a[2]=t19,a[3]=t6,a[4]=t17,a[5]=t18,a[6]=t1,a[7]=t13,a[8]=t14,a[9]=t15,a[10]=t16,a[11]=((C_word*)t0)[8],a[12]=t37,a[13]=t30,a[14]=t12,a[15]=((C_word*)t0)[2],a[16]=t41,a[17]=t38,a[18]=t8,a[19]=t10,a[20]=t35,a[21]=t34,a[22]=t20,a[23]=((C_word*)t0)[3],a[24]=t28,a[25]=t21,a[26]=((C_word*)t0)[4],a[27]=t33,a[28]=t40,a[29]=t39,a[30]=((C_word*)t0)[5],a[31]=((C_word*)t0)[6],a[32]=((C_word*)t0)[7],a[33]=t27,a[34]=((C_word*)t0)[9],a[35]=((C_word*)t0)[10],a[36]=t23,tmp=(C_word)a,a+=37,tmp);
t43=((C_word*)((C_word*)t0)[4])[1];
t44=(C_word)C_fixnum_lessp(t43,C_fix(1));
t45=(C_truep(t44)?t44:(C_word)C_i_not(((C_word*)t0)[3]));
if(C_truep(t45)){
t46=C_set_block_item(((C_word*)t0)[4],0,C_fix(1));
t47=t42;
f_920(t47,t46);}
else{
t46=t42;
f_920(t46,C_SCHEME_UNDEFINED);}}

/* k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_920,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2512,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_473(t5,((C_word*)t0)[2]);}
else{
t3=t2;
f_923(t3,C_SCHEME_UNDEFINED);}}

/* k2510 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[412]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2506 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[411]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2502 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[239]+1,t1);
t3=((C_word*)t0)[2];
f_923(t3,t2);}

/* k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=lf[408],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[16];
f_820(t5,t4,lf[410]);}

/* k2498 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[409]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2477 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2484,a[2]=lf[406],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2496,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[407]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2494 in a2477 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2483 in a2477 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2484,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[405]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2490 in a2483 in a2477 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[332]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=C_set_block_item(lf[106],0,C_SCHEME_TRUE);
t4=(C_word)C_i_memq(lf[107],C_retrieve(lf[69]));
t5=C_mutate(((C_word *)((C_word*)t0)[35])+1,t4);
t6=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[404],((C_word*)t0)[34]))){
t7=C_set_block_item(lf[210],0,C_SCHEME_TRUE);
t8=t6;
f_935(t8,t7);}
else{
t7=t6;
f_935(t7,C_SCHEME_UNDEFINED);}}

/* k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_935,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[162],C_retrieve(lf[69])))){
t3=*((C_word*)lf[403]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_938(2,t3,C_SCHEME_UNDEFINED);}}

/* k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[402],C_retrieve(lf[69])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_941(t4,t3);}
else{
t3=t2;
f_941(t3,C_SCHEME_UNDEFINED);}}

/* k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_941,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[401],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[17],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_944(t6,t5);}
else{
t3=t2;
f_944(t3,C_SCHEME_UNDEFINED);}}

/* k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[399],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[400],0,C_SCHEME_FALSE);
t4=t2;
f_947(t4,t3);}
else{
t3=t2;
f_947(t3,C_SCHEME_UNDEFINED);}}

/* k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_947,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[395],((C_word*)t0)[33]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[32])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[398]);}
else{
t4=t3;
f_2447(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_950(t3,C_SCHEME_UNDEFINED);}}

/* k2445 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[396],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[397],0,C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
f_950(t4,t3);}

/* k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_950,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[145],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[145],0,C_SCHEME_TRUE);
t4=t2;
f_953(t4,t3);}
else{
t3=t2;
f_953(t3,C_SCHEME_UNDEFINED);}}

/* k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_953,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[208],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[208],0,C_SCHEME_TRUE);
t4=C_retrieve(lf[393]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[394]);}
else{
t3=t2;
f_956(2,t3,C_SCHEME_UNDEFINED);}}

/* k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(C_truep(((C_word*)t0)[23])?(C_word)C_i_memq(lf[391],((C_word*)t0)[33]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[392],0,C_SCHEME_TRUE);
t5=t2;
f_959(t5,t4);}
else{
t4=t2;
f_959(t4,C_SCHEME_UNDEFINED);}}

/* k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[389],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[390],0,C_SCHEME_FALSE);
t4=t2;
f_962(t4,t3);}
else{
t3=t2;
f_962(t3,C_SCHEME_UNDEFINED);}}

/* k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_962,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[386],((C_word*)t0)[33]))){
t3=C_mutate((C_word*)lf[387]+1,lf[388]);
t4=t2;
f_965(t4,t3);}
else{
t3=t2;
f_965(t3,C_SCHEME_UNDEFINED);}}

/* k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_965,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[385],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[242],0,C_SCHEME_TRUE);
t4=t2;
f_968(t4,t3);}
else{
t3=t2;
f_968(t3,C_SCHEME_UNDEFINED);}}

/* k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_968,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[383],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[384],0,C_SCHEME_TRUE);
t4=t2;
f_971(t4,t3);}
else{
t3=t2;
f_971(t3,C_SCHEME_UNDEFINED);}}

/* k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_971,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[381],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[382],0,C_SCHEME_TRUE);
t4=t2;
f_974(t4,t3);}
else{
t3=t2;
f_974(t3,C_SCHEME_UNDEFINED);}}

/* k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_974,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[380],((C_word*)t0)[33]))){
t3=C_set_block_item(lf[378],0,C_fix(10));
t4=t2;
f_977(t4,t3);}
else{
t3=t2;
f_977(t3,C_SCHEME_UNDEFINED);}}

/* k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_977,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[108],((C_word*)t0)[33]);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
f_473(t4,t2);}
else{
t4=t3;
f_983(t4,C_SCHEME_FALSE);}}

/* k2388 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2393,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_string_to_number(3,0,t2,t1);}

/* k2391 in k2388 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2396(2,t3,t1);}
else{
t3=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[379],((C_word*)t0)[2]);}}

/* k2394 in k2391 in k2388 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[378]+1,t1);
t3=((C_word*)t0)[2];
f_983(t3,t2);}

/* k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_983,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[375],((C_word*)t0)[33]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[32])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[377]);}
else{
t4=t3;
f_2377(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_986(2,t3,C_SCHEME_UNDEFINED);}}

/* k2375 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[353]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[375]);}

/* k2378 in k2375 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(C_word)C_i_memq(lf[109],((C_word*)t0)[33]);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[33],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2371,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_473(t5,t2);}
else{
t4=t3;
f_992(t4,C_SCHEME_FALSE);}}

/* k2369 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k2353 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2361,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=t1;
t5=t3;
f_2361(t5,(C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(0),t4),(C_word)C_fixnum_less_or_equal_p(t4,C_fix(2))));}
else{
t4=t3;
f_2361(t4,C_SCHEME_FALSE);}}

/* k2359 in k2353 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_2361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2358(2,t2,((C_word*)t0)[2]);}
else{
t2=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[374]);}}

/* k2356 in k2353 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=((C_word*)t0)[2];
f_992(t3,t2);}

/* k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_992,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
f_473(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_995(2,t3,C_SCHEME_UNDEFINED);}}

/* k2319 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[367],t1))){
t2=C_retrieve(lf[58]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[369],t1))){
t2=C_retrieve(lf[58]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[370]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[371],t1))){
t2=C_retrieve(lf[58]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[372]);}
else{
t2=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[373]);}}}}

/* k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
f_473(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_998(t3,C_SCHEME_UNDEFINED);}}

/* k2306 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_string_to_number(3,0,t2,t1);}

/* k2310 in k2306 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2315(2,t3,t1);}
else{
t3=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[366],((C_word*)t0)[2]);}}

/* k2313 in k2310 in k2306 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[365]+1,t1);
t3=((C_word*)t0)[2];
f_998(t3,t2);}

/* k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_998,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,((C_word*)t0)[31]);
t3=C_set_block_item(lf[111],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[31],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=((C_word*)t0)[13];
f_820(t7,t6,lf[364]);}

/* k2303 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[363]),t1);}

/* k2292 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]):C_SCHEME_END_OF_LIST);
t3=*((C_word*)lf[250]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],t1,C_retrieve(lf[112]),((C_word*)t0)[2],t2);}

/* k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=((C_word*)t0)[18];
t5=((C_word*)((C_word*)t0)[22])[1];
if(C_truep(t4)){
t6=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t6)){
t7=t3;
f_1008(2,t7,(C_word)C_a_i_list(&a,1,t4));}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_603,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}
else{
t6=t3;
f_1008(2,t6,C_SCHEME_FALSE);}}

/* k601 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_608,a[2]=t1,a[3]=lf[361],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[362]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a607 in k601 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_608,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[359]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[360],((C_word*)t0)[2],t2);}

/* k614 in a607 in k601 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[358]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[30],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[18])){
if(C_truep(((C_word*)t0)[26])){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[26],a[3]=lf[356],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[357]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[30])[1]);}
else{
t5=t4;
f_2275(2,t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2275(2,t5,C_SCHEME_FALSE);}}

/* a2285 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2286,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2273 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[355]);}
else{
t2=((C_word*)t0)[2];
f_1011(2,t2,C_SCHEME_UNDEFINED);}}

/* k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[12];
f_820(t4,t3,lf[354]);}

/* k2270 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[353]),t1);}

/* k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[12];
f_820(t4,t3,lf[352]);}

/* k2266 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[351]),t1);}

/* k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[29]))){
t3=C_set_block_item(lf[350],0,C_SCHEME_TRUE);
t4=t2;
f_1020(t4,t3);}
else{
t3=t2;
f_1020(t3,C_SCHEME_UNDEFINED);}}

/* k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1020,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[12];
f_820(t4,t3,lf[348]);}

/* k2258 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[113]));}

/* k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[114],C_retrieve(lf[115]));
t4=C_mutate((C_word*)lf[115]+1,t3);
t5=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t6=((C_word*)t0)[12];
f_820(t6,t5,lf[347]);}

/* k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1034,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[346]);}
else{
t3=t2;
f_1034(2,t3,C_SCHEME_UNDEFINED);}}

/* k2251 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=lf[344],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2241 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[343]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2248 in a2241 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[342]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=C_retrieve(lf[340]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[114],C_retrieve(lf[115]),*((C_word*)lf[341]+1));}

/* k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[116],C_retrieve(lf[115]));
t4=C_mutate((C_word*)lf[115]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[117],C_retrieve(lf[115]));
t6=(C_word)C_a_i_cons(&a,2,lf[118],t5);
t7=C_mutate((C_word*)lf[115]+1,t6);
t8=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t9=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[339]);}

/* k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[334],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2208,a[2]=t2,a[3]=((C_word*)t0)[30],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[30],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[18])){
t6=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[18]);}
else{
if(C_truep(((C_word*)t0)[27])){
t6=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[27]);}
else{
t6=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[337]);}}}
else{
t3=t2;
f_1055(t3,C_SCHEME_UNDEFINED);}}

/* k2222 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[332]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2218 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[335],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* k2206 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1055(t3,t2);}

/* k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1055,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[12];
f_820(t4,t3,lf[333]);}

/* k2199 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[332]+1),t1);}

/* k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=lf[331],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a2188 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2189,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[254],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[330],t3));}

/* k2185 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[30],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[329],0,C_SCHEME_TRUE);
t5=t3;
f_1065(t5,t4);}
else{
t4=t3;
f_1065(t4,C_SCHEME_UNDEFINED);}}

/* k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1065,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t3=C_retrieve(lf[327]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
f_473(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[326]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1072(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1072(2,t4,C_SCHEME_FALSE);}}}

/* k2164 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_740(((C_word*)t0)[2],t1);}

/* k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
f_473(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1076(2,t4,C_SCHEME_FALSE);}}

/* k2157 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_740(((C_word*)t0)[2],t1);}

/* k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2152,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
f_473(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1080(2,t4,C_SCHEME_FALSE);}}

/* k2150 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_740(((C_word*)t0)[2],t1);}

/* k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_473(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1084(2,t4,C_SCHEME_FALSE);}}

/* k2143 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_740(((C_word*)t0)[2],t1);}

/* k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1084,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2125,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_473(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[325]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1088(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1088(2,t5,C_SCHEME_FALSE);}}}

/* k2123 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_740(((C_word*)t0)[2],t1);}

/* k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,t1);
t3=(C_word)C_i_memq(lf[124],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[125]+1,t4);
t6=(C_word)C_i_memq(lf[126],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[127]+1,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[323],C_retrieve(lf[69])))){
t9=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1099(2,t9,C_SCHEME_UNDEFINED);}}

/* k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[318],((C_word*)t0)[23]))){
t3=t2;
f_1102(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[319]+1,C_retrieve(lf[320]));
t4=C_mutate((C_word*)lf[321]+1,C_retrieve(lf[322]));
t5=t2;
f_1102(t5,t4);}}

/* k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1102,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[125]))?lf[315]:lf[316]);
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[317],t3);}
else{
t3=t2;
f_1105(2,t3,C_SCHEME_UNDEFINED);}}

/* k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[53],t3);
t5=C_set_block_item(lf[267],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2078,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[313]:C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[250]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[314]),t7);}
else{
t3=t2;
f_1108(2,t3,C_SCHEME_UNDEFINED);}}

/* k2076 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[310]:lf[311]);
t4=C_retrieve(lf[70]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[312],t3,C_retrieve(lf[267]));}
else{
t3=((C_word*)t0)[2];
f_1108(2,t3,C_SCHEME_UNDEFINED);}}

/* k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[128],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[130]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[131],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1129(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[307],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1129(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[308],((C_word*)t0)[22]);
t6=t3;
f_1129(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[309],((C_word*)t0)[22])));}}}}

/* k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1129,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[132]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[22]);}
else{
t2=((C_word*)t0)[21];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[14])){
t4=t3;
f_1150(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[304],((C_word*)t0)[21]);}}
else{
if(C_truep(((C_word*)t0)[14])){
t3=((C_word*)t0)[22];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[130]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}

/* k1142 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[305]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[306]);}

/* k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[22],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
t4=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[296],lf[303],((C_word*)t0)[9]);}

/* k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[296],lf[302],C_retrieve(lf[69]));}

/* k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[296],lf[301],((C_word*)t0)[2]);}

/* k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[296],lf[300],C_retrieve(lf[119]));}

/* k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[296],lf[299],C_retrieve(lf[123]));}

/* k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[296],lf[297],C_retrieve(lf[298]));}

/* k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=*((C_word*)lf[294]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[295]),C_SCHEME_END_OF_LIST);}

/* k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t4=((C_word*)t0)[3];
f_820(t4,t3,lf[293]);}

/* k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
t3=((C_word*)t0)[3];
f_820(t3,t2,lf[292]);}

/* k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
f_820(t4,t3,lf[291]);}

/* k2042 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2052,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
f_820(t4,t3,lf[290]);}

/* k2050 in k2042 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[250]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=C_retrieve(lf[289]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[20])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[282]);}
else{
t4=t3;
f_1962(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=lf[288],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1974(t6,t2,((C_word*)t0)[4]);}}

/* do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1974,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1985,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[283]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=C_retrieve(lf[287]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2001 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2017,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
f_877(t4,t3,t1);}

/* k2015 in k2001 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[286],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2019(t5,((C_word*)t0)[2],t1);}

/* do218 in k2015 in k2001 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2019,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
f_877(t6,t5,((C_word*)t0)[6]);}}

/* k2038 in do218 in k2015 in k2001 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2019(t2,((C_word*)t0)[2],t1);}

/* k2004 in k2001 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1974(t3,((C_word*)t0)[2],t2);}

/* k1987 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[284]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1991 in k1987 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1997,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[283]),((C_word*)t0)[2]);}

/* k1995 in k1991 in k1987 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[250]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1983 in do213 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1960 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1964 in k1960 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1188(2,t3,t2);}

/* k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=C_retrieve(lf[281]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1940,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[16])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[280]);}
else{
t4=t3;
f_1940(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1194(t3,C_SCHEME_UNDEFINED);}}

/* k1938 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k1950 in k1938 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1194(t4,t3);}

/* k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1194,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=((C_word*)t0)[6];
f_679(t3,t2,lf[278],lf[279],((C_word*)((C_word*)t0)[3])[1]);}

/* k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=f_850(((C_word*)t0)[20]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t4=((C_word*)t0)[2];
f_820(t4,t3,lf[277]);}

/* k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_1206(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1937,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[277],t1);}}

/* k1935 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[102],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1206(t5,t4);}

/* k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1206(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1206,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1920 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[275]),t1);}

/* k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1212,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t3=C_retrieve(lf[258]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[134]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1761,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=lf[273],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[274]));}

/* a1901 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1902,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,2,lf[254],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[256],t3,t5));}

/* k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1896,a[2]=lf[271],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[272]));}

/* a1895 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1896,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[270],t2));}

/* k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[267]))){
t3=(C_word)C_a_i_list(&a,2,lf[254],((C_word*)t0)[2]);
t4=(C_truep(C_retrieve(lf[239]))?C_SCHEME_FALSE:lf[268]);
t5=(C_word)C_a_i_list(&a,2,lf[254],t4);
t6=(C_word)C_a_i_list(&a,3,lf[269],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[256],C_retrieve(lf[265]),t6);
t8=t2;
f_1769(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_1769(t3,C_SCHEME_END_OF_LIST);}}

/* k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=lf[266],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[134]));}

/* a1846 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1847,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fixnum_times(C_fix(5),t3);
t5=(C_word)C_a_i_list(&a,2,lf[254],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_list(&a,2,lf[254],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,5,lf[263],lf[264],C_retrieve(lf[265]),t5,t7));}

/* k1771 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=lf[259],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[260]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,lf[261],C_retrieve(lf[262]));}

/* a1808 in k1771 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1809,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1825,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[258]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1823 in a1808 in k1771 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[254],t3);
t5=(C_word)C_a_i_list(&a,2,lf[255],t4);
t6=(C_word)C_a_i_list(&a,3,lf[256],t2,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,3,lf[257],t8,((C_word*)t0)[2]));}

/* k1775 in k1771 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[252]))){
t3=(C_word)C_a_i_list(&a,3,lf[137],C_SCHEME_END_OF_LIST,t1);
t4=(C_word)C_a_i_list(&a,3,lf[253],C_retrieve(lf[252]),t3);
t5=t2;
f_1780(t5,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_1780(t3,(C_word)C_a_i_list(&a,1,t1));}}

/* k1778 in k1775 in k1771 in k1767 in k1763 in k1759 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[239]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[9]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[8])[1]:C_SCHEME_END_OF_LIST);
t5=*((C_word*)lf[250]+1);
((C_proc10)C_retrieve_proc(t5))(10,t5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[251]);}

/* k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[248],lf[249]);}

/* k1752 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[247]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1221(2,t2,C_SCHEME_UNDEFINED);}}

/* k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[245],lf[246]);}

/* k1746 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[244]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1224(2,t2,C_SCHEME_UNDEFINED);}}

/* k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[242]))?C_retrieve(lf[239]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[243],C_retrieve(lf[239]));}
else{
t4=t2;
f_1227(2,t4,C_SCHEME_UNDEFINED);}}

/* k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[239]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[241],C_retrieve(lf[239]));}
else{
t4=t2;
f_1230(2,t4,C_SCHEME_UNDEFINED);}}

/* k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,C_retrieve(lf[135]));
t3=C_set_block_item(lf[135],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=((C_word*)t0)[16];
f_860(t5,t4,lf[238]);}

/* k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=((C_word*)t0)[2];
f_679(t3,t2,lf[236],lf[237],((C_word*)((C_word*)t0)[4])[1]);}

/* k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_memq(lf[235],((C_word*)t0)[2]))){
t3=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1241(2,t3,C_SCHEME_UNDEFINED);}}

/* k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=C_retrieve(lf[234]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1714,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[11])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[233]);}
else{
t4=t3;
f_1714(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1247(2,t3,C_SCHEME_UNDEFINED);}}

/* k1712 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=f_850(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k1719 in k1712 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
f_860(t3,((C_word*)t0)[2],lf[231]);}

/* k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1709 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[136],lf[137],lf[138],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1256,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t5=C_retrieve(lf[228]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1259,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[226],lf[227]);}

/* k1694 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[224]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[225]));}
else{
t2=((C_word*)t0)[2];
f_1259(2,t2,C_SCHEME_UNDEFINED);}}

/* k1701 in k1694 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[75]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[14],a[7]=t2,a[8]=((C_word*)t0)[16],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[223]);}
else{
t4=t3;
f_1664(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1262(t3,C_SCHEME_UNDEFINED);}}

/* k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=f_850(((C_word*)t0)[8]);
t3=C_set_block_item(lf[141],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
f_664(t3,t2,lf[222],lf[217],t1,C_fix(0));}

/* k1672 in k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[3];
f_860(t3,t2,lf[221]);}

/* k1675 in k1672 in k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=f_850(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1681 in k1675 in k1672 in k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
f_860(t3,t2,lf[220]);}

/* k1684 in k1681 in k1675 in k1672 in k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
f_642(t3,t2,lf[218],lf[219],((C_word*)t0)[2]);}

/* k1687 in k1684 in k1681 in k1675 in k1672 in k1669 in k1662 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[141],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1262(t3,t2);}

/* k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1262,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[210]))){
t3=f_850(((C_word*)t0)[15]);
t4=C_set_block_item(lf[141],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
t6=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}
else{
t3=t2;
f_1265(t3,C_SCHEME_UNDEFINED);}}

/* k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1645,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
f_664(t3,t2,lf[216],lf[217],t1,C_fix(0));}

/* k1643 in k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[3];
f_860(t3,t2,lf[215]);}

/* k1646 in k1643 in k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=f_850(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_retrieve(lf[214]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1652 in k1646 in k1643 in k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
f_860(t3,t2,lf[213]);}

/* k1655 in k1652 in k1646 in k1643 in k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
f_642(t3,t2,lf[211],lf[212],((C_word*)t0)[2]);}

/* k1658 in k1655 in k1652 in k1646 in k1643 in k1640 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[141],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1265(t3,t2);}

/* k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,2,t0,t1);}
t2=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[139],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[140],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t6=(C_truep(C_retrieve(lf[106]))?(C_word)C_i_not(C_retrieve(lf[208])):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t8=(C_word)C_i_car(t7);
t9=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t5,t8);}
else{
t7=t5;
f_1271(2,t7,C_SCHEME_UNDEFINED);}}

/* k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=f_850(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1280,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t3=((C_word*)t0)[13];
f_860(t3,t2,lf[206]);}

/* k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=((C_word*)t0)[13];
f_642(t3,t2,lf[204],lf[205],((C_word*)t0)[2]);}

/* k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=t3,a[14]=((C_word*)t0)[15],a[15]=lf[203],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1288(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1288,NULL,5,t0,t1,t2,t3,t4);}
t5=f_850(((C_word*)t0)[14]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1295,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t1,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[14],tmp=(C_word)a,a+=19,tmp);
t7=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}

/* k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_retrieve(lf[141]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1609,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t3=t2;
f_1298(2,t3,C_SCHEME_UNDEFINED);}}

/* k1607 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[200],C_retrieve(lf[69])))){
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1298(2,t2,C_SCHEME_UNDEFINED);}}

/* k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=C_set_block_item(lf[141],0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t4=((C_word*)t0)[14];
f_860(t4,t3,lf[199]);}

/* k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t3=((C_word*)t0)[3];
f_664(t3,t2,lf[197],lf[198],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_memq(lf[195],C_retrieve(lf[69])))){
t3=C_retrieve(lf[196]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1308(2,t3,C_SCHEME_UNDEFINED);}}

/* k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[106]);
if(C_truep(t3)){
t4=t2;
f_1314(t4,t3);}
else{
t4=((C_word*)t0)[16];
t5=C_retrieve(lf[50]);
t6=t2;
f_1314(t6,(C_word)C_fixnum_less_or_equal_p(t4,t5));}}
else{
t3=t2;
f_1314(t3,C_SCHEME_FALSE);}}

/* k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1314,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],tmp=(C_word)a,a+=10,tmp);
t3=C_retrieve(lf[150]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[151],lf[157],((C_word*)t0)[15]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[17],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=((C_word*)t0)[12];
f_642(t3,t2,lf[193],lf[194],((C_word*)t0)[17]);}}

/* k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
t2=f_850(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t4=C_retrieve(lf[192]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=((C_word*)t0)[12];
f_860(t3,t2,lf[191]);}

/* k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
t3=((C_word*)t0)[3];
f_664(t3,t2,lf[189],lf[190],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_memq(lf[187],C_retrieve(lf[69])))){
t3=C_retrieve(lf[188]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}
else{
t3=t2;
f_1418(2,t3,C_SCHEME_UNDEFINED);}}

/* k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=C_retrieve(lf[186]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[13],a[3]=lf[182],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[13],a[3]=lf[185],tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[13],t3,t4);}
else{
t3=t2;
f_1424(2,t3,C_SCHEME_UNDEFINED);}}

/* a1581 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1582,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=lf[184],tmp=(C_word)a,a+=4,tmp));}

/* f_1584 in a1581 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1584,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[183]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a1573 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1574,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=lf[181],tmp=(C_word)a,a+=4,tmp));}

/* f_1576 in a1573 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1576,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[179]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_1427(2,t3,C_SCHEME_UNDEFINED);}}

/* k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=((C_word*)t0)[2];
f_642(t3,t2,lf[177],lf[178],((C_word*)t0)[13]);}

/* k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
if(C_truep(((C_word*)t0)[2])){
t4=((C_word*)((C_word*)t0)[10])[1];
t5=(C_word)C_fixnum_greaterp(t4,C_fix(1));
t6=t3;
f_1549(t6,(C_word)C_i_not(t5));}
else{
t4=t3;
f_1549(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1549(t4,C_SCHEME_FALSE);}}

/* k1547 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[176]);}
else{
t2=((C_word*)t0)[3];
f_1433(2,t2,C_SCHEME_UNDEFINED);}}

/* k1554 in k1547 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[174],t1);}

/* k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=f_850(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=lf[159],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[12],a[11]=lf[173],tmp=(C_word)a,a+=12,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1447,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t6=((C_word*)t0)[8];
f_860(t6,t5,lf[172]);}

/* k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=f_850(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,a[10]=lf[171],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_1484(t7,t3,((C_word*)((C_word*)t0)[2])[1],C_fix(0));}

/* loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1484(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1484,NULL,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t4)){
t6=*((C_word*)lf[169]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t6=*((C_word*)lf[170]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k1489 in loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_1494(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[168],((C_word*)t0)[9]);}}

/* k1492 in k1489 in loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[7])[1];
t4=(C_word)C_eqp(t3,C_fix(1));
t5=(C_truep(t4)?C_SCHEME_FALSE:((C_word*)t0)[12]);
t6=C_retrieve(lf[167]);
((C_proc9)C_retrieve_proc(t6))(9,t6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1495 in k1492 in k1489 in loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1500(2,t3,C_SCHEME_UNDEFINED);}}

/* k1498 in k1495 in k1492 in k1489 in loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=t2;
f_1506(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_1506(t3,C_SCHEME_FALSE);}}

/* k1504 in k1498 in k1495 in k1492 in k1489 in loopfile in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1484(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1455 in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
f_860(t3,t2,lf[165]);}

/* k1458 in k1455 in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[162],C_retrieve(lf[69])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[164]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1463(2,t3,C_SCHEME_UNDEFINED);}}

/* k1480 in k1458 in k1455 in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[163]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1461 in k1458 in k1455 in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[161]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1464 in k1461 in k1458 in k1455 in k1449 in a1446 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
t2=C_retrieve(lf[70]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a1440 in k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1407 in k1401 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=f_850(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[143],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[156],tmp=(C_word)a,a+=8,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1331,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
t5=((C_word*)t0)[3];
f_860(t5,t4,lf[155]);}

/* k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
f_642(t3,t2,lf[153],lf[154],((C_word*)t0)[5]);}

/* k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t3=((C_word*)((C_word*)t0)[6])[1];
f_1288(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[144]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[145]))){
t3=f_850(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t5=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=((C_word*)((C_word*)t0)[6])[1];
f_1288(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[151],lf[152]);}}}

/* k1355 in k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[144],0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_1288(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1372 in k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1377,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
f_860(t3,t2,lf[148]);}

/* k1375 in k1372 in k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=f_850(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1381 in k1375 in k1372 in k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1386,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
f_860(t3,t2,lf[146]);}

/* k1384 in k1381 in k1375 in k1372 in k1336 in k1333 in a1330 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_1288(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1324 in k1315 in k1312 in k1306 in k1303 in k1300 in k1296 in k1293 in loop in k1281 in k1278 in k1275 in k1269 in k1263 in k1260 in k1257 in k1254 in k1705 in k1245 in k1242 in k1239 in k1236 in k1233 in k1228 in k1225 in k1222 in k1219 in k1216 in k1210 in k1207 in k1204 in k1201 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1167 in k1164 in k1161 in k1158 in k1155 in k1152 in k1148 in k1127 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1115 in k1106 in k1103 in k1100 in k1097 in k1086 in k1082 in k1078 in k1074 in k1070 in k1066 in k1063 in k1060 in k1056 in k1053 in k1050 in k1039 in k1035 in k1032 in k1029 in k1022 in k1018 in k1015 in k1012 in k1009 in k1006 in k1002 in k996 in k993 in k990 in k984 in k981 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k925 in k921 in k918 in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[129]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* read-form in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_877(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_877,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_FALSE,t2);}
else{
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}}

/* k885 in read-form in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
if(C_truep((C_word)C_i_string_equal_p(t1,lf[99]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(C_word)C_a_i_list(&a,2,lf[100],t1);
t3=(C_word)C_a_i_list(&a,2,lf[101],t1);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[102],t2,t3));}
else{
t2=(C_word)C_a_i_list(&a,2,lf[101],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[102],t2));}}}

/* end-time in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_860,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_618();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
t5=C_retrieve(lf[70]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[97],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static C_word C_fcall f_850(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_618();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_820,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_826,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=lf[94],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_826(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_826,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
f_473(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k838 in loop in collect-options in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_844,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_826(t4,t2,t3);}

/* k842 in k838 in loop in collect-options in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_844,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_740(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_740,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_781,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_789,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=*((C_word*)lf[92]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_809,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=*((C_word*)lf[92]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
C_string_to_number(3,0,t5,t2);}}}}

/* k807 in arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k803 in arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_750(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k787 in arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k779 in arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_750(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k748 in arg-val in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[91],((C_word*)t0)[2]);}}

/* infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_691,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_695,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[88]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=lf[89],tmp=(C_word)a,a+=3,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_737 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_737,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k693 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_698,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[87],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_701(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_701(t5,C_SCHEME_FALSE);}}

/* k699 in k693 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_701,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_712,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=C_retrieve(lf[86]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[84]),t5);}
else{
t2=((C_word*)t0)[3];
f_698(2,t2,C_SCHEME_UNDEFINED);}}

/* k714 in k699 in k693 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_retrieve(lf[85]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k710 in k699 in k693 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[84]),((C_word*)t0)[2],t1);}

/* k696 in k693 in infohook in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_679,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_686,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
f_624(t6,t5,t2,t3);}

/* k684 in print in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[75]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_664(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_664,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_671,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
f_624(t7,t6,t2,t3);}

/* k669 in print-db in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_671,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[79],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k672 in k669 in print-db in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_642(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_642,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_649,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
f_624(t6,t5,t2,t3);}

/* k647 in print-node in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_662,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k660 in k647 in print-node in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[75]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void C_fcall f_624(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_624,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_628,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[72],t2);}
else{
t5=t4;
f_628(2,t5,C_SCHEME_UNDEFINED);}}

/* k626 in print-header in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[69])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[71],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k635 in k626 in print-header in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static void f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k532 in k529 in k526 in k520 in k2604 in k504 in compile-source-file */
static C_word C_fcall f_618(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file */
static void C_fcall f_473(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_473,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
t5=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[42],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[43],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}
/* end of file */
