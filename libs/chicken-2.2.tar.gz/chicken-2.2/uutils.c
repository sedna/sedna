/* Generated from utils.scm by the Chicken compiler
   2005-09-10 23:53
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: utils.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file uutils.c -explicit-use
   unit: utils
*/

#include "chicken.h"

C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[73];


C_externexport void C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_233(C_word c,C_word t0,C_word t1) C_noret;
static void f_236(C_word c,C_word t0,C_word t1) C_noret;
static void f_239(C_word c,C_word t0,C_word t1) C_noret;
static void f_1011(C_word c,C_word t0,C_word t1) C_noret;
static void f_276(C_word c,C_word t0,C_word t1) C_noret;
static void f_288(C_word c,C_word t0,C_word t1) C_noret;
static void f_291(C_word c,C_word t0,C_word t1) C_noret;
static void f_498(C_word c,C_word t0,C_word t1) C_noret;
static void f_1007(C_word c,C_word t0,C_word t1) C_noret;
static void f_501(C_word c,C_word t0,C_word t1) C_noret;
static void f_504(C_word c,C_word t0,C_word t1) C_noret;
static void f_507(C_word c,C_word t0,C_word t1) C_noret;
static void f_977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_983(C_word t0,C_word t1,C_word t2) C_noret;
static void f_987(C_word c,C_word t0,C_word t1) C_noret;
static void f_953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_959(C_word t0,C_word t1) C_noret;
static void f_963(C_word c,C_word t0,C_word t1) C_noret;
static void f_972(C_word c,C_word t0,C_word t1) C_noret;
static void f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_884(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_884r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_888(C_word t0,C_word t1) C_noret;
static void f_844(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_844r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_848(C_word t0,C_word t1) C_noret;
static void f_854(C_word c,C_word t0,C_word t1) C_noret;
static void f_862(C_word c,C_word t0,C_word t1) C_noret;
static void f_799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_824(C_word c,C_word t0,C_word t1) C_noret;
static void f_838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_817(C_word c,C_word t0,C_word t1) C_noret;
static void f_766(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_766r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_775(C_word t0,C_word t1) C_noret;
static void f_779(C_word c,C_word t0,C_word t1) C_noret;
static void f_788(C_word c,C_word t0,C_word t1) C_noret;
static void f_704(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_704r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_708(C_word c,C_word t0,C_word t1) C_noret;
static void f_758(C_word c,C_word t0,C_word t1) C_noret;
static void f_711(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_719(C_word t0,C_word t1) C_noret;
static void f_749(C_word c,C_word t0,C_word t1) C_noret;
static void f_745(C_word c,C_word t0,C_word t1) C_noret;
static void f_726(C_word c,C_word t0,C_word t1) C_noret;
static void f_732(C_word c,C_word t0,C_word t1) C_noret;
static void f_740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_692(C_word c,C_word t0,C_word t1) C_noret;
static void f_668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_674(C_word c,C_word t0,C_word t1) C_noret;
static void f_650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_656(C_word c,C_word t0,C_word t1) C_noret;
static void f_632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_638(C_word c,C_word t0,C_word t1) C_noret;
static void f_614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_620(C_word c,C_word t0,C_word t1) C_noret;
static void f_599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_605(C_word c,C_word t0,C_word t1) C_noret;
static void f_584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_590(C_word c,C_word t0,C_word t1) C_noret;
static void f_569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_575(C_word c,C_word t0,C_word t1) C_noret;
static void f_508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_521(C_word c,C_word t0,C_word t1) C_noret;
static void f_546(C_word c,C_word t0,C_word t1) C_noret;
static void f_452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_460(C_word c,C_word t0,C_word t1) C_noret;
static void f_476(C_word c,C_word t0,C_word t1) C_noret;
static void f_466(C_word c,C_word t0,C_word t1) C_noret;
static void f_357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_357r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_361(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_367(C_word t0,C_word t1) C_noret;
static void f_374(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_381(C_word t0,C_word t1) C_noret;
static void C_fcall f_323(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_329(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_303(C_word t0,C_word t1) C_noret;
static void f_343(C_word c,C_word t0,C_word t1) C_noret;
static void f_347(C_word c,C_word t0,C_word t1) C_noret;
static void f_277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_285(C_word c,C_word t0,C_word t1) C_noret;
static void f_259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_266(C_word c,C_word t0,C_word t1) C_noret;
static void f_272(C_word c,C_word t0,C_word t1) C_noret;
static void f_241(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_241r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_245(C_word c,C_word t0,C_word t1) C_noret;
static void f_248(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_983(t0,t1,t2);}

static void C_fcall trf_959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_959(t0,t1);}

static void C_fcall trf_888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_888(t0,t1);}

static void C_fcall trf_848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_848(t0,t1);}

static void C_fcall trf_775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_775(t0,t1);}

static void C_fcall trf_719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_719(t0,t1);}

static void C_fcall trf_367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_367(t0,t1);}

static void C_fcall trf_381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_381(t0,t1);}

static void C_fcall trf_323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_323(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_323(t0,t1,t2);}

static void C_fcall trf_329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_329(t0,t1,t2);}

static void C_fcall trf_303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_303(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(423)){
C_save(t1);
C_rereclaim2(423*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,73);
lf[0]=C_h_intern(&lf[0],7,"sprintf");
lf[1]=C_h_intern(&lf[1],6,"system");
lf[2]=C_h_intern(&lf[2],7,"system*");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,51,"shell invocation failed with non-zero return status");
lf[5]=C_h_intern(&lf[5],12,"file-exists\077");
lf[6]=C_h_intern(&lf[6],11,"delete-file");
lf[7]=C_h_intern(&lf[7],12,"delete-file*");
lf[8]=C_h_intern(&lf[8],12,"string-match");
lf[9]=C_h_intern(&lf[9],18,"absolute-pathname\077");
lf[10]=C_h_intern(&lf[10],13,"string-append");
lf[11]=C_static_string(C_heaptop,0,"");
lf[12]=C_h_intern(&lf[12],13,"\003syssubstring");
lf[13]=C_h_intern(&lf[13],28,"pathname-directory-separator");
lf[14]=C_static_string(C_heaptop,0,"");
lf[15]=C_static_string(C_heaptop,0,"");
lf[16]=C_h_intern(&lf[16],28,"pathname-extension-separator");
lf[17]=C_static_string(C_heaptop,0,"");
lf[18]=C_static_string(C_heaptop,0,"");
lf[19]=C_static_string(C_heaptop,0,"");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[21]=C_h_intern(&lf[21],22,"make-absolute-pathname");
lf[22]=C_h_intern(&lf[22],17,"\003sysstring-append");
lf[23]=C_static_string(C_heaptop,0,"");
lf[24]=C_h_intern(&lf[24],18,"decompose-pathname");
lf[25]=C_h_intern(&lf[25],13,"string-search");
lf[26]=C_h_intern(&lf[26],18,"pathname-directory");
lf[27]=C_h_intern(&lf[27],13,"pathname-file");
lf[28]=C_h_intern(&lf[28],18,"pathname-extension");
lf[29]=C_h_intern(&lf[29],24,"pathname-strip-directory");
lf[30]=C_h_intern(&lf[30],24,"pathname-strip-extension");
lf[31]=C_h_intern(&lf[31],26,"pathname-replace-directory");
lf[32]=C_h_intern(&lf[32],21,"pathname-replace-file");
lf[33]=C_h_intern(&lf[33],26,"pathname-replace-extension");
lf[34]=C_h_intern(&lf[34],6,"getenv");
lf[35]=C_h_intern(&lf[35],21,"call-with-output-file");
lf[36]=C_h_intern(&lf[36],21,"create-temporary-file");
lf[37]=C_static_string(C_heaptop,3,"tmp");
lf[38]=C_static_string(C_heaptop,1,"t");
lf[39]=C_static_string(C_heaptop,3,"TMP");
lf[40]=C_static_string(C_heaptop,4,"TEMP");
lf[41]=C_static_string(C_heaptop,6,"TMPDIR");
lf[42]=C_h_intern(&lf[42],9,"read-line");
lf[43]=C_h_intern(&lf[43],13,"for-each-line");
lf[44]=C_h_intern(&lf[44],18,"\003sysstandard-input");
lf[45]=C_h_intern(&lf[45],18,"for-each-argv-line");
lf[46]=C_static_string(C_heaptop,1,"-");
lf[47]=C_h_intern(&lf[47],20,"with-input-from-file");
lf[48]=C_h_intern(&lf[48],12,"\003sysfor-each");
lf[49]=C_h_intern(&lf[49],22,"command-line-arguments");
lf[50]=C_h_intern(&lf[50],8,"read-all");
lf[51]=C_h_intern(&lf[51],11,"read-string");
lf[52]=C_h_intern(&lf[52],5,"port\077");
lf[53]=C_h_intern(&lf[53],6,"shift!");
lf[54]=C_h_intern(&lf[54],8,"unshift!");
lf[55]=C_h_intern(&lf[55],13,"port-for-each");
lf[56]=C_h_intern(&lf[56],7,"reverse");
lf[57]=C_h_intern(&lf[57],8,"port-map");
lf[58]=C_static_string(C_heaptop,5,"^(.*[");
lf[59]=C_static_string(C_heaptop,6,"])\077((\134");
lf[60]=C_static_string(C_heaptop,4,")\077[^");
lf[61]=C_static_string(C_heaptop,4,"]+)$");
lf[62]=C_static_string(C_heaptop,5,"^(.*[");
lf[63]=C_static_string(C_heaptop,6,"])\077([^");
lf[64]=C_static_string(C_heaptop,5,"]+)(\134");
lf[65]=C_static_string(C_heaptop,3,"([^");
lf[66]=C_static_string(C_heaptop,5,"]+))$");
lf[67]=C_static_string(C_heaptop,3,"\134/\134");
lf[68]=C_h_intern(&lf[68],6,"string");
lf[69]=C_static_string(C_heaptop,16,"([A-Za-z]:)\077[\134/\134");
lf[70]=C_static_string(C_heaptop,3,"].*");
lf[71]=C_h_intern(&lf[71],17,"register-feature!");
lf[72]=C_h_intern(&lf[72],5,"utils");
C_register_lf(lf,73);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k231 */
static void f_233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k234 in k231 */
static void f_236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 64   register-feature! */
t3=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[72]);}

/* k237 in k234 in k231 */
static void f_239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_239,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_241,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[5]+1);
t6=*((C_word*)lf[6]+1);
t7=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_259,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_276,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 91   string */
t10=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,*((C_word*)lf[13]+1));}

/* k1009 in k237 in k234 in k231 */
static void f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 91   string-append */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[69],t1,lf[70]);}

/* k274 in k237 in k234 in k231 */
static void f_276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_276,2,t0,t1);}
t2=*((C_word*)lf[8]+1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_277,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=*((C_word*)lf[10]+1);
t5=*((C_word*)lf[9]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_288,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 99   string */
t7=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[13]+1));}

/* k286 in k274 in k237 in k234 in k231 */
static void f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 100  string */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[16]+1));}

/* k289 in k286 in k274 in k237 in k234 in k231 */
static void f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_357,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_mutate((C_word*)lf[20]+1,t3);
t5=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_452,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 148  string */
t7=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[16]+1));}

/* k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_501,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 149  string */
t4=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[13]+1));}

/* k1005 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 149  ##sys#string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[67],t1);}

/* k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_504,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 150  string-append */
t3=*((C_word*)lf[10]+1);
((C_proc12)(void*)(*((C_word*)t3+1)))(12,t3,t2,lf[62],t1,lf[63],t1,lf[64],((C_word*)t0)[2],lf[65],t1,((C_word*)t0)[2],lf[66]);}

/* k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_507,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  string-append */
t3=*((C_word*)lf[10]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[58],((C_word*)t0)[3],lf[59],((C_word*)t0)[2],lf[60],((C_word*)t0)[3],lf[61]);}

/* k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_507,2,t0,t1);}
t2=*((C_word*)lf[8]+1);
t3=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_508,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t4=*((C_word*)lf[24]+1);
t5=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_569,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_584,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_614,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_650,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_668,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[34]+1);
t14=*((C_word*)lf[20]+1);
t15=*((C_word*)lf[5]+1);
t16=*((C_word*)lf[35]+1);
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_704,a[2]=t13,a[3]=t14,a[4]=t15,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t18=*((C_word*)lf[42]+1);
t19=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_766,a[2]=t18,tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_799,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_844,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_884,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_932,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_953,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[56]+1);
t26=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,C_SCHEME_UNDEFINED);}

/* port-map in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_977,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_983,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_983(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_983,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 287  thunk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k985 in loop in port-map in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
/* utils.scm: 289  reverse */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* utils.scm: 290  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_983(t4,((C_word*)t0)[4],t3);}}

/* port-for-each in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_953,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_959,a[2]=t3,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_959(t7,t1);}

/* loop in port-for-each in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 278  thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k961 in loop in port-for-each in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  fn */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k970 in k961 in loop in port-for-each in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 281  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_959(t2,((C_word*)t0)[2]);}

/* unshift! in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_932,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_i_setslot(t3,C_fix(1),t6);
t8=(C_word)C_i_setslot(t3,C_fix(0),t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}

/* shift! in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_884(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_884r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_884r(t0,t1,t2,t3);}}

static void f_884r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_888,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_888(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_888(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k886 in shift! in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t4);
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}}

/* read-all in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_844(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_844r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_844r(t0,t1,t2);}}

static void f_844r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_848(t4,*((C_word*)lf[44]+1));}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_848(t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}

/* k846 in read-all in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_848,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_854,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 249  port? */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k852 in k846 in read-all in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 250  read-string */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_862,tmp=(C_word)a,a+=2,tmp);
/* utils.scm: 251  with-input-from-file */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a861 in k852 in k846 in read-all in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
/* read-string */
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* for-each-argv-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_799,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_824,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 237  command-line-arguments */
t4=*((C_word*)lf[49]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k822 in for-each-argv-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 240  for-each-line */
t2=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a837 in k822 in for-each-argv-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_838,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_u_i_string_equal_p(t2,lf[46]))){
/* utils.scm: 235  for-each-line */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_817,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 236  with-input-from-file */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a816 in a837 in k822 in for-each-argv-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_817,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_766(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_766r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_766r(t0,t1,t2,t3);}}

static void f_766r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):*((C_word*)lf[44]+1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_775,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_775(t9,t1);}

/* loop in for-each-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_775,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 224  read-line */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k777 in loop in for-each-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_779,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 226  proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k786 in k777 in loop in for-each-line in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 227  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_775(t2,((C_word*)t0)[2]);}

/* create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_704(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_704r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_704r(t0,t1,t2);}}

static void f_704r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 205  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[41]);}

/* k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_711(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 205  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[40]);}}

/* k756 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_711(2,t2,t1);}
else{
/* utils.scm: 205  getenv */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[39]);}}

/* k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[6],C_fix(0)):lf[37]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_719,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_719(t7,((C_word*)t0)[2]);}

/* loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_719,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 210  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k747 in loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  ##sys#string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[38],t1);}

/* k743 in loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k724 in loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_732,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 211  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k730 in k724 in loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_732,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 212  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_719(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 213  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a739 in k730 in k724 in loop in k709 in k706 in create-temporary-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_740,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_692,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a697 in pathname-replace-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_698,5,t0,t1,t2,t3,t4);}
/* utils.scm: 197  make-pathname */
t5=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a691 in pathname-replace-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
/* utils.scm: 196  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_668,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_674,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_680,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a679 in pathname-replace-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_680,5,t0,t1,t2,t3,t4);}
/* utils.scm: 193  make-pathname */
t5=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a673 in pathname-replace-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_674,2,t0,t1);}
/* utils.scm: 192  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_650,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_656,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_662,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a661 in pathname-replace-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_662,5,t0,t1,t2,t3,t4);}
/* utils.scm: 189  make-pathname */
t5=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a655 in pathname-replace-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
/* utils.scm: 188  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_632,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_638,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_644,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a643 in pathname-strip-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_644,5,t0,t1,t2,t3,t4);}
/* utils.scm: 185  make-pathname */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a637 in pathname-strip-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_638,2,t0,t1);}
/* utils.scm: 184  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_614,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_626,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a625 in pathname-strip-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_626,5,t0,t1,t2,t3,t4);}
/* utils.scm: 181  make-pathname */
t5=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a619 in pathname-strip-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_620,2,t0,t1);}
/* utils.scm: 180  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_599,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_605,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_611,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a610 in pathname-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_611,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a604 in pathname-extension in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_605,2,t0,t1);}
/* utils.scm: 176  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_584,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_590,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_596,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a595 in pathname-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_596,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a589 in pathname-file in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_590,2,t0,t1);}
/* utils.scm: 172  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_569,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_575,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_581,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a580 in pathname-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_581,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a574 in pathname-directory in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_575,2,t0,t1);}
/* utils.scm: 168  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_508,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* utils.scm: 156  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_521,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 157  string-search */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k519 in decompose-pathname in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_521,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(t1);
t3=(C_word)C_u_i_caddr(t1);
t4=(C_word)C_u_i_cddddr(t1);
t5=(C_word)C_u_i_car(t4);
/* utils.scm: 159  values */
C_values(5,0,((C_word*)t0)[4],t2,t3,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 160  string-search */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k544 in k519 in decompose-pathname in k505 in k502 in k499 in k496 in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(t1);
t3=(C_word)C_u_i_caddr(t1);
/* utils.scm: 162  values */
C_values(5,0,((C_word*)t0)[3],t2,t3,C_SCHEME_FALSE);}
else{
/* utils.scm: 163  values */
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_452r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_452r(t0,t1,t2,t3,t4);}}

static void f_452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_not(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_nullp(t2));
if(C_truep(t7)){
t8=t5;
f_460(2,t8,lf[23]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=t5;
f_460(2,t8,t2);}
else{
/* utils.scm: 139  conc-dirs */
t8=((C_word*)t0)[2];
f_323(t8,t5,t2);}}}

/* k458 in make-absolute-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_466,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 141  absolute-pathname? */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k474 in k458 in make-absolute-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_466(2,t2,((C_word*)t0)[3]);}
else{
/* utils.scm: 142  ##sys#string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k464 in k458 in make-absolute-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_357r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_357r(t0,t1,t2,t3,t4);}}

static void f_357r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_361,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_not(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_nullp(t2));
if(C_truep(t7)){
t8=t5;
f_361(2,t8,lf[19]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 115  conc-dirs */
t9=((C_word*)t0)[2];
f_323(t9,t5,t8);}
else{
/* utils.scm: 116  conc-dirs */
t8=((C_word*)t0)[2];
f_323(t8,t5,t2);}}}

/* k359 in _make-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:lf[14]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_367,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t6=t4;
f_367(t6,(C_truep(t5)?t5:lf[17]));}
else{
t5=t4;
f_367(t5,lf[18]);}}

/* k365 in k359 in _make-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_367,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_374,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_eqp(*((C_word*)lf[13]+1),(C_word)C_subchar(((C_word*)t0)[2],C_fix(0))):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(C_word)C_block_size(((C_word*)t0)[2]);
/* utils.scm: 125  ##sys#substring */
t7=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,((C_word*)t0)[2],C_fix(1),t6);}
else{
t6=t2;
f_374(2,t6,((C_word*)t0)[2]);}}

/* k372 in k365 in k359 in _make-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),*((C_word*)lf[16]+1));
t5=t2;
f_381(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_381(t4,C_SCHEME_FALSE);}}

/* k379 in k372 in k365 in k359 in _make-pathname in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?((C_word*)t0)[7]:lf[15]);
/* utils.scm: 121  string-append */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* conc-dirs in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_323(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_323,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_329,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_329(t6,t1,t2);}

/* loop in conc-dirs in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_329,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[11]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_343,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_303,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t7=(C_word)C_u_fixnum_difference(t5,C_fix(1));
t8=(C_word)C_subchar(t4,t7);
t9=t6;
f_303(t9,(C_word)C_eqp(*((C_word*)lf[13]+1),t8));}
else{
t7=t6;
f_303(t7,C_SCHEME_FALSE);}}}

/* k301 in loop in conc-dirs in k289 in k286 in k274 in k237 in k234 in k231 */
static void C_fcall f_303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* utils.scm: 105  ##sys#substring */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_343(2,t2,((C_word*)t0)[2]);}}

/* k341 in loop in conc-dirs in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* utils.scm: 112  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_329(t4,t2,t3);}

/* k345 in k341 in loop in conc-dirs in k289 in k286 in k274 in k237 in k234 in k231 */
static void f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* absolute-pathname? in k274 in k237 in k234 in k231 */
static void f_277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_285,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 95   string-match */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k283 in absolute-pathname? in k274 in k237 in k234 in k231 */
static void f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* delete-file* in k237 in k234 in k231 */
static void f_259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_259,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_266,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 85   file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k264 in delete-file* in k237 in k234 in k231 */
static void f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_266,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_272,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 85   delete-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k270 in k264 in delete-file* in k237 in k234 in k231 */
static void f_272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k237 in k234 in k231 */
static void f_241(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_241r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_241r(t0,t1,t2,t3);}}

static void f_241r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_245,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k243 in system* in k237 in k234 in k231 */
static void f_245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_248,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 74   system */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k246 in k243 in system* in k237 in k234 in k231 */
static void f_248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 76   ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[4],((C_word*)t0)[2],t1);}}
/* end of file */
