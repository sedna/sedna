/* Generated from stub.scm by the Chicken compiler
   2005-08-30 00:13
   Version 2, Build 108 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: stub.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file stub.c -explicit-use
   unit: default_stub
*/

#include "chicken.h"

C_externimport void C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[3];


C_externexport void C_default_stub_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_14(C_word c,C_word t0,C_word t1) C_noret;
static void f_17(C_word c,C_word t0,C_word t1) C_noret;
static void f_20(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_25(C_word t0,C_word t1) C_noret;
static void f_29(C_word c,C_word t0,C_word t1) C_noret;
static void f_23(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_25(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_25(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_25(t0,t1);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_default_stub_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_default_stub_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("default_stub_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(9)){
C_save(t1);
C_rereclaim2(9*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,3);
lf[0]=C_h_intern(&lf[0],14,"return-to-host");
lf[1]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[2]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k12 */
static void f_14(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k15 in k12 */
static void f_17(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k18 in k15 in k12 */
static void f_20(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_23,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_25,a[2]=t4,a[3]=lf[1],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_25(t6,t2);}

/* loop in k18 in k15 in k12 */
static void C_fcall f_25(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_25,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_29,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k27 in loop in k18 in k15 in k12 */
static void f_29(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_25(t2,((C_word*)t0)[2]);}

/* k21 in k18 in k15 in k12 */
static void f_23(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
/* end of file */
