/* Generated from regex.scm by the Chicken compiler
   2005-09-10 23:31
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: regex.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file uregex.c -explicit-use
   unit: regex
*/

#include "chicken.h"

#include <regex.h>

#define C_MAXIMAL_NUMBER_OF_SUB_MATCHES 256

regmatch_t C_match_registers[ C_MAXIMAL_NUMBER_OF_SUB_MATCHES + 1 ];

#define C_regexp_alloc_buffer(ptr) (C_set_block_item((ptr), 0, (C_word)calloc(1, sizeof(regex_t))))
#define C_regexp_count_matches(ptr) C_fix(((regex_t *)C_slot(ptr, 0))->re_nsub + 1)
#define C_regexp_register_start(i) C_fix(C_match_registers[ C_unfix(i) ].rm_so)
#define C_regexp_register_end(i) C_fix(C_match_registers[ C_unfix(i) ].rm_eo)


static C_TLS C_word lf[78];


/* from k1334 in ##regexp#re-match in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub136(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub136(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * buffer=(void * )C_c_pointer_or_null(C_a0);
char * str=(char * )C_string_or_null(C_a1);
int start=(int )C_unfix(C_a2);
int range=(int )C_unfix(C_a3);
int i, r, n;regex_t *rx = (regex_t *)buffer;if(range) str[ range ] = '0';n = rx->re_nsub + 1;r = regexec((regex_t *)buffer, str + start, n, C_match_registers, 0);if(start != 0) {  for(i = 0; i < n; ++i) {    C_match_registers[ i ].rm_so += start;    C_match_registers[ i ].rm_eo += start;  }}return(r);
C_return:
#undef return

return C_r;}

/* from k1187 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub101(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub101(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * rx=(char * )C_string_or_null(C_a0);
void * ptr=(void * )C_c_pointer_or_null(C_a1);
unsigned int flags=(unsigned int )C_num_to_unsigned_int(C_a2);
return(regcomp((regex_t *)ptr, rx, flags));
C_return:
#undef return

return C_r;}

/* from k1174 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub93(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub93(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * rx=(void * )C_c_pointer_or_null(C_a0);
regfree((regex_t *)rx);C_free(rx);
C_return:
#undef return

return C_r;}

/* from alloc */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub89(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub89(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
return(calloc(1, sizeof(regex_t)));
C_return:
#undef return

return C_r;}

/* from k380 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * rx=(char * )C_string_or_null(C_a0);
void * buffer=(void * )C_c_pointer_or_null(C_a1);
regfree(buffer);return(regcomp((regex_t *)buffer, rx, REG_EXTENDED));
C_return:
#undef return

return C_r;}

C_externexport void C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_359(C_word c,C_word t0,C_word t1) C_noret;
static void f_2261(C_word c,C_word t0,C_word t1) C_noret;
static void f_2257(C_word c,C_word t0,C_word t1) C_noret;
static void f_2253(C_word c,C_word t0,C_word t1) C_noret;
static void f_2249(C_word c,C_word t0,C_word t1) C_noret;
static void f_2245(C_word c,C_word t0,C_word t1) C_noret;
static void f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_367(C_word c,C_word t0,C_word t1) C_noret;
static void f_371(C_word c,C_word t0,C_word t1) C_noret;
static void f_2163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2167(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2175(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2207(C_word c,C_word t0,C_word t1) C_noret;
static void f_2194(C_word c,C_word t0,C_word t1) C_noret;
static void f_2197(C_word c,C_word t0,C_word t1) C_noret;
static void f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2151(C_word c,C_word t0,C_word t1) C_noret;
static void f_2158(C_word c,C_word t0,C_word t1) C_noret;
static void f_2037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2049(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2121(C_word c,C_word t0,C_word t1) C_noret;
static void f_2117(C_word c,C_word t0,C_word t1) C_noret;
static void f_2110(C_word c,C_word t0,C_word t1) C_noret;
static void f_2094(C_word c,C_word t0,C_word t1) C_noret;
static void f_2081(C_word c,C_word t0,C_word t1) C_noret;
static void f_2077(C_word c,C_word t0,C_word t1) C_noret;
static void f_2045(C_word c,C_word t0,C_word t1) C_noret;
static void f_1890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1929(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1959(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1968(C_word t0,C_word t1) C_noret;
static void C_fcall f_2015(C_word t0,C_word t1) C_noret;
static void f_2000(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1974(C_word t0,C_word t1) C_noret;
static void f_1924(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1914(C_word t0,C_word t1) C_noret;
static void f_1910(C_word c,C_word t0,C_word t1) C_noret;
static void f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_1642r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1808(C_word c,C_word t0,C_word t1) C_noret;
static void f_1878(C_word c,C_word t0,C_word t1) C_noret;
static void f_1874(C_word c,C_word t0,C_word t1) C_noret;
static void f_1857(C_word c,C_word t0,C_word t1) C_noret;
static void f_1839(C_word c,C_word t0,C_word t1) C_noret;
static void f_1832(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1770(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1775(C_word t0,C_word t1,C_word t2);
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1742(C_word c,C_word t0,C_word t1) C_noret;
static void f_1730(C_word c,C_word t0,C_word t1) C_noret;
static void f_1689(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1654(C_word *a,C_word t0,C_word t1);
static void f_1467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1467r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1623(C_word c,C_word t0,C_word t1) C_noret;
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1483(C_word t0,C_word t1) C_noret;
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1495(C_word c,C_word t0,C_word t1) C_noret;
static void f_1556(C_word c,C_word t0,C_word t1) C_noret;
static void f_1537(C_word c,C_word t0,C_word t1) C_noret;
static void f_1571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1462(C_word c,C_word t0,C_word t1) C_noret;
static void f_1449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1449r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1453(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1417(C_word c,C_word t0,C_word t1) C_noret;
static void f_1394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1398(C_word c,C_word t0,C_word t1) C_noret;
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1389(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1365(C_word c,C_word t0,C_word t1) C_noret;
static void f_1352(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1336(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1310(C_word c,C_word t0,C_word t1) C_noret;
static void f_1318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1286(C_word t0,C_word t1) C_noret;
static void f_1290(C_word c,C_word t0,C_word t1) C_noret;
static void f_1254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1229(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1229r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1236(C_word c,C_word t0,C_word t1) C_noret;
static void f_1252(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1213(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1185(C_word c,C_word t0,C_word t1) C_noret;
static void f_1171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1142(C_word c,C_word t0,C_word t1) C_noret;
static void f_986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_994(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1062(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1010(C_word c,C_word t0,C_word t1) C_noret;
static void f_582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_828(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_973(C_word c,C_word t0,C_word t1) C_noret;
static void f_969(C_word c,C_word t0,C_word t1) C_noret;
static void f_888(C_word c,C_word t0,C_word t1) C_noret;
static void f_884(C_word c,C_word t0,C_word t1) C_noret;
static void f_880(C_word c,C_word t0,C_word t1) C_noret;
static void f_865(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_617(C_word t0,C_word t1) C_noret;
static void f_643(C_word c,C_word t0,C_word t1) C_noret;
static void f_602(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_716(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_722(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_752(C_word t0,C_word t1) C_noret;
static void f_816(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_764(C_word t0,C_word t1) C_noret;
static void f_786(C_word c,C_word t0,C_word t1) C_noret;
static void f_790(C_word c,C_word t0,C_word t1) C_noret;
static void f_782(C_word c,C_word t0,C_word t1) C_noret;
static void f_740(C_word c,C_word t0,C_word t1) C_noret;
static void f_736(C_word c,C_word t0,C_word t1) C_noret;
static void f_493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_503(C_word c,C_word t0,C_word t1) C_noret;
static void f_532(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_534(C_word t0,C_word t1,C_word t2);
static void f_487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_390(C_word t0,C_word t1,C_word t2) C_noret;
static void f_416(C_word c,C_word t0,C_word t1) C_noret;
static void f_400(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_422(C_word t0,C_word t1);
static void f_373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_378(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_2175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2175(t0,t1,t2);}

static void C_fcall trf_2132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2132(t0,t1,t2);}

static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2051(t0,t1,t2);}

static void C_fcall trf_1896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1896(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1896(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1929(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1929(t0,t1,t2,t3);}

static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1968(t0,t1);}

static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2015(t0,t1);}

static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1974(t0,t1);}

static void C_fcall trf_1914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1914(t0,t1);}

static void C_fcall trf_1804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1804(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1804(t0,t1,t2,t3);}

static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1766(t0,t1,t2);}

static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1669(t0,t1,t2);}

static void C_fcall trf_1675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1675(t0,t1,t2,t3);}

static void C_fcall trf_1483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1483(t0,t1);}

static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1491(t0,t1,t2,t3);}

static void C_fcall trf_1403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1403(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1403(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1344(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1327(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1327(t0,t1,t2,t3,t4);}

static void C_fcall trf_1306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1306(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1306(t0,t1,t2,t3,t4);}

static void C_fcall trf_1260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1260(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1260(t0,t1,t2);}

static void C_fcall trf_1272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1272(t0,t1,t2);}

static void C_fcall trf_1286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1286(t0,t1);}

static void C_fcall trf_1196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1196(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1196(t0,t1,t2,t3,t4);}

static void C_fcall trf_1180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1180(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1180(t0,t1,t2,t3);}

static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_996(t0,t1,t2,t3);}

static void C_fcall trf_1062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1062(t0,t1,t2);}

static void C_fcall trf_828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_828(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_828(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_588(t0,t1,t2,t3);}

static void C_fcall trf_617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_617(t0,t1);}

static void C_fcall trf_716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_716(t0,t1,t2);}

static void C_fcall trf_722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_722(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_722(t0,t1,t2,t3);}

static void C_fcall trf_752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_752(t0,t1);}

static void C_fcall trf_764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_764(t0,t1);}

static void C_fcall trf_390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_390(t0,t1,t2);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(776)){
C_save(t1);
C_rereclaim2(776*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,78);
lf[0]=C_static_string(C_heaptop,0,"");
lf[1]=C_static_string(C_heaptop,0,"");
lf[2]=C_static_string(C_heaptop,0,"");
lf[3]=C_static_string(C_heaptop,0,"");
lf[4]=C_static_string(C_heaptop,0,"");
lf[7]=C_h_intern(&lf[7],25,"\006regexpre-compile-pattern");
lf[8]=C_h_intern(&lf[8],17,"\003sysmake-c-string");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_static_string(C_heaptop,34,"can not compile regular expression");
lf[12]=C_h_intern(&lf[12],17,"extract-bit-field");
lf[13]=C_h_intern(&lf[13],23,"utf8-start-byte->length");
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[14]=C_h_vector(256,C_pick(255),C_pick(254),C_pick(253),C_pick(252),C_pick(251),C_pick(250),C_pick(249),C_pick(248),C_pick(247),C_pick(246),C_pick(245),C_pick(244),C_pick(243),C_pick(242),C_pick(241),C_pick(240),C_pick(239),C_pick(238),C_pick(237),C_pick(236),C_pick(235),C_pick(234),C_pick(233),C_pick(232),C_pick(231),C_pick(230),C_pick(229),C_pick(228),C_pick(227),C_pick(226),C_pick(225),C_pick(224),C_pick(223),C_pick(222),C_pick(221),C_pick(220),C_pick(219),C_pick(218),C_pick(217),C_pick(216),C_pick(215),C_pick(214),C_pick(213),C_pick(212),C_pick(211),C_pick(210),C_pick(209),C_pick(208),C_pick(207),C_pick(206),C_pick(205),C_pick(204),C_pick(203),C_pick(202),C_pick(201),C_pick(200),C_pick(199),C_pick(198),C_pick(197),C_pick(196),C_pick(195),C_pick(194),C_pick(193),C_pick(192),C_pick(191),C_pick(190),C_pick(189),C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(256);
lf[15]=C_h_intern(&lf[15],18,"string-ref-at-byte");
lf[16]=C_h_intern(&lf[16],6,"regexp");
lf[17]=C_static_string(C_heaptop,27,"utf8 trailing char overflow");
tmp=C_make_character(41);
C_save(tmp);
tmp=C_make_character(125);
C_save(tmp);
tmp=C_make_character(50);
C_save(tmp);
tmp=C_make_character(123);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(127);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(1);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(40);
C_save(tmp);
lf[19]=C_h_list(32,C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(32);
lf[20]=C_h_intern(&lf[20],26,"utf8-pattern->byte-pattern");
lf[21]=C_h_intern(&lf[21],12,"string->list");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_static_string(C_heaptop,1,"(");
lf[24]=C_static_string(C_heaptop,1,")");
lf[25]=C_h_intern(&lf[25],18,"string-intersperse");
lf[26]=C_static_string(C_heaptop,1,"|");
lf[27]=C_static_string(C_heaptop,34,"full unicode classes not supported");
lf[28]=C_static_string(C_heaptop,1,"[");
lf[29]=C_static_string(C_heaptop,1,"-");
lf[30]=C_static_string(C_heaptop,1,"]");
lf[31]=C_h_intern(&lf[31],12,"char->string");
lf[32]=C_h_intern(&lf[32],12,"list->string");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[34]=C_h_intern(&lf[34],6,"append");
lf[35]=C_static_string(C_heaptop,26,"incomplete character class");
lf[36]=C_h_intern(&lf[36],26,"white-space-ignore-pattern");
lf[37]=C_static_string(C_heaptop,20,"trailing unescaped \134");
lf[38]=C_h_intern(&lf[38],20,"re-translate-pattern");
lf[39]=C_static_string(C_heaptop,34,"can not compile regular expression");
lf[40]=C_h_intern(&lf[40],14,"set-finalizer!");
lf[41]=C_h_intern(&lf[41],7,"regexp\077");
lf[43]=C_h_intern(&lf[43],9,"substring");
lf[45]=C_h_intern(&lf[45],7,"\003sysmap");
lf[47]=C_static_string(C_heaptop,1,"^");
lf[48]=C_static_string(C_heaptop,1,"$");
lf[49]=C_h_intern(&lf[49],15,"\003syssignal-hook");
lf[50]=C_h_intern(&lf[50],11,"\000type-error");
lf[51]=C_static_string(C_heaptop,51,"bad argument type - not a string or compiled regexp");
lf[52]=C_h_intern(&lf[52],12,"string-match");
lf[53]=C_h_intern(&lf[53],22,"string-match-positions");
lf[54]=C_static_string(C_heaptop,51,"bad argument type - not a string or compiled regexp");
lf[55]=C_h_intern(&lf[55],13,"string-search");
lf[56]=C_h_intern(&lf[56],23,"string-search-positions");
lf[57]=C_h_intern(&lf[57],19,"string-split-fields");
lf[58]=C_h_intern(&lf[58],6,"\000infix");
lf[59]=C_h_intern(&lf[59],7,"\000suffix");
lf[60]=C_static_string(C_heaptop,31,"record does not end with suffix");
lf[61]=C_h_intern(&lf[61],11,"make-string");
lf[62]=C_h_intern(&lf[62],17,"string-substitute");
lf[63]=C_h_intern(&lf[63],18,"string-substitute*");
lf[64]=C_h_intern(&lf[64],21,"\003sysfragments->string");
lf[65]=C_h_intern(&lf[65],13,"\003syssubstring");
lf[66]=C_h_intern(&lf[66],12,"glob->regexp");
lf[67]=C_h_intern(&lf[67],8,"\003syscons");
lf[68]=C_h_intern(&lf[68],4,"grep");
lf[69]=C_h_intern(&lf[69],18,"open-output-string");
lf[70]=C_h_intern(&lf[70],17,"get-output-string");
lf[71]=C_h_intern(&lf[71],13,"regexp-escape");
lf[72]=C_h_intern(&lf[72],16,"\003syswrite-char-0");
lf[73]=C_h_intern(&lf[73],12,"list->vector");
lf[74]=C_h_intern(&lf[74],12,"\003sysfor-each");
lf[75]=C_h_intern(&lf[75],16,"\003sysmake-pointer");
lf[76]=C_h_intern(&lf[76],17,"register-feature!");
lf[77]=C_h_intern(&lf[77],5,"regex");
C_register_lf(lf,78);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_359,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 86   register-feature! */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[77]);}

/* k357 */
static void f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 94   ##sys#make-pointer */
t3=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2259 in k357 */
static void f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[0],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 95   ##sys#make-pointer */
t4=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2255 in k2259 in k357 */
static void f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[1],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 96   ##sys#make-pointer */
t4=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2251 in k2255 in k2259 in k357 */
static void f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 97   ##sys#make-pointer */
t4=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 98   ##sys#make-pointer */
t4=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2);
t4=C_mutate(&lf[5],t3);
t5=lf[6]=C_fix(0);;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2216,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t8=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,lf[5]);}

/* a2215 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_regexp_alloc_buffer(t3));}

/* k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 103  list->vector */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[5]);}

/* k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=C_mutate(&lf[5],t1);
t3=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_373,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_390,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_465,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_487,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_493,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[18],lf[19]);
t9=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_582,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_986,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1132,tmp=(C_word)a,a+=2,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1171,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1180,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=t12,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1254,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1260,tmp=(C_word)a,a+=2,tmp));
t18=*((C_word*)lf[43]+1);
t19=C_mutate(&lf[44],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=t18,tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[46],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1327,tmp=(C_word)a,a+=2,tmp));
t21=C_SCHEME_FALSE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=*((C_word*)lf[22]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1344,a[2]=t23,a[3]=t22,tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=t24,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1394,a[2]=t24,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=t29,a[3]=t28,tmp=(C_word)a,a+=4,tmp));
t31=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1458,a[2]=t29,a[3]=t28,tmp=(C_word)a,a+=4,tmp));
t32=*((C_word*)lf[33]+1);
t33=*((C_word*)lf[43]+1);
t34=*((C_word*)lf[56]+1);
t35=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1467,a[2]=t32,a[3]=t34,a[4]=t33,tmp=(C_word)a,a+=5,tmp));
t36=*((C_word*)lf[43]+1);
t37=*((C_word*)lf[33]+1);
t38=*((C_word*)lf[61]+1);
t39=*((C_word*)lf[56]+1);
t40=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1642,a[2]=t39,a[3]=t37,a[4]=t38,a[5]=t36,tmp=(C_word)a,a+=6,tmp));
t41=*((C_word*)lf[56]+1);
t42=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=*((C_word*)lf[32]+1);
t44=*((C_word*)lf[21]+1);
t45=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=t44,a[3]=t43,tmp=(C_word)a,a+=4,tmp));
t46=*((C_word*)lf[55]+1);
t47=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=t46,tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[69]+1);
t49=*((C_word*)lf[70]+1);
t50=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t48,a[3]=t49,tmp=(C_word)a,a+=4,tmp));
t51=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t51+1)))(2,t51,C_SCHEME_UNDEFINED);}

/* regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2163,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2167,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 564  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2165 in regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2175,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2175(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2165 in regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_2175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2175,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 567  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 569  ##sys#write-char-0 */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2207,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 573  ##sys#write-char-0 */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2205 in loop in k2165 in regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 574  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2175(t3,((C_word*)t0)[2],t2);}

/* k2192 in loop in k2165 in regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 570  ##sys#write-char-0 */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2195 in k2192 in loop in k2165 in regexp-escape in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 571  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2175(t3,((C_word*)t0)[2],t2);}

/* grep in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2126,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2132,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2132(t7,t1,t3);}

/* loop in grep in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2132,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2151,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 552  string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2149 in loop in grep in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 553  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2132(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 554  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2132(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2156 in k2149 in loop in grep in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2037,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2045,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 533  string->list */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2051(t5,((C_word*)t0)[2],t1);}

/* loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2051,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 538  loop */
t14=t6;
t15=t4;
t1=t14;
t2=t15;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 539  loop */
t14=t5;
t15=t4;
t1=t14;
t2=t15;
goto loop;
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 540  loop */
t14=t7;
t15=t4;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 541  loop */
t14=t8;
t15=t4;
t1=t14;
t2=t15;
goto loop;}}}}

/* k2119 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 527  ##sys#cons */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2115 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 527  ##sys#cons */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(92),t1);}

/* k2108 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2092 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2079 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 527  ##sys#cons */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(42),t1);}

/* k2075 in loop in k2047 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 527  ##sys#cons */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(46),t1);}

/* k2043 in glob->regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 532  list->string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1890,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1896,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
/* regex.scm: 522  collect */
t8=((C_word*)t6)[1];
f_1896(t8,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1896,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1924,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 499  ##sys#substring */
t10=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[5],t3,t2);}
else{
t9=t8;
f_1914(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t2,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_1929(t10,t1,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1929(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1929,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[9]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t4);
/* regex.scm: 503  collect */
t6=((C_word*)((C_word*)t0)[7])[1];
f_1896(t6,t1,t3,((C_word*)t0)[6],t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1959,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[8],a[12]=t6,tmp=(C_word)a,a+=13,tmp);
/* regex.scm: 507  string-search-positions */
t8=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t5,((C_word*)t0)[4],((C_word*)t0)[9]);}}

/* k1957 in loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_slot(t1,C_fix(0)):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1968(t5,(C_word)C_eqp(((C_word*)t0)[7],t4));}
else{
t4=t3;
f_1968(t4,C_SCHEME_FALSE);}}

/* k1966 in k1957 in loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1974,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 513  ##sys#substring */
t6=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t5=t4;
f_1974(t5,C_SCHEME_UNDEFINED);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2015,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_slot(((C_word*)t0)[13],C_fix(0));
t5=t3;
f_2015(t5,(C_word)C_i_fixnum_min(((C_word*)t0)[2],t4));}
else{
t4=t3;
f_2015(t4,((C_word*)t0)[2]);}}}

/* k2013 in k1966 in k1957 in loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_2015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 518  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1929(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1998 in k1966 in k1957 in loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1974(t4,t3);}

/* k1972 in k1966 in k1957 in loop in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1974,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* regex.scm: 514  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1896(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k1922 in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1914(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k1912 in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 497  reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1908 in collect in string-substitute* in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 495  ##sys#fragments->string */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+35)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1642r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1642r(t0,t1,t2,t3,t4,t5);}}

static void f_1642r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(35);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t8=(C_word)C_block_size(t3);
t9=(C_word)C_u_fixnum_difference(t8,C_fix(1));
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=t13,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1669,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t14,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1766,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1804,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t15,a[10]=t18,a[11]=t14,a[12]=t7,tmp=(C_word)a,a+=13,tmp));
t20=((C_word*)t18)[1];
f_1804(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1804,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* regex.scm: 472  string-search-positions */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_fixnump(((C_word*)t0)[13]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[12],((C_word*)t0)[13]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1839,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_u_i_car(t2);
/* regex.scm: 477  substring */
t9=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)t0)[6],((C_word*)t0)[5],t8);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1857,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 481  substring */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 484  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1876 in k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=f_1654(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 485  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1872 in k1876 in k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 485  concatenate */
t2=((C_word*)t0)[3];
f_1766(t2,((C_word*)t0)[2],t1);}

/* k1855 in k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=f_1654(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 482  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1804(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1837 in k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=f_1654(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 478  substitute */
t4=((C_word*)t0)[3];
f_1669(t4,t3,((C_word*)t0)[2]);}

/* k1830 in k1837 in k1806 in loop in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 479  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1804(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* concatenate in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1766,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 462  make-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1768 in concatenate in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1775(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop in k1768 in concatenate in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static C_word C_fcall f_1775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_block_size(t3);
t5=(C_word)C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t4,t2);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* substitute in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_1675(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1675,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_1689(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 448  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 458  loop */
t17=t1;
t18=t2;
t19=t9;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t9=(C_word)C_fix((C_word)C_character_code(t7));
t10=(C_word)C_u_fixnum_difference(t9,C_fix(48));
t11=(C_word)C_u_i_list_ref(((C_word*)t0)[3],t10);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 455  substring */
t13=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,((C_word*)t0)[7],t2,t3);}}
else{
/* regex.scm: 459  loop */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k1740 in loop in substitute in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=f_1654(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 456  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k1728 in k1740 in loop in substitute in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=f_1654(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 457  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1675(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k1687 in loop in substitute in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
/* regex.scm: 448  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_1654(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static C_word C_fcall f_1654(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1467r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1467r(t0,t1,t2,t3,t4);}}

static void f_1467r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(25);
t5=(C_word)C_block_size(t4);
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t5,C_fix(0));
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t9=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t10=(C_truep(t9)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1483,a[2]=t10,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t12=(C_word)C_eqp(t8,lf[59]);
if(C_truep(t12)){
t13=t11;
f_1483(t13,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));}
else{
t13=(C_word)C_eqp(t8,lf[58]);
t14=t11;
f_1483(t14,(C_truep(t13)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1602,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_1624 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1624,4,t0,t1,t2,t3);}
/* regex.scm: 408  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_1602 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1602,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* regex.scm: 406  reverse */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1623,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 407  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k1621 */
static void f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 407  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_1582 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1582,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 401  ##sys#error */
t4=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[57],lf[60],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 402  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1483,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[58]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[59]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1491(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 413  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1493 in loop in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 420  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 421  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1556,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 422  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 423  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1554 in k1493 in loop in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 422  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1491(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1535 in k1493 in loop in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 421  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1491(t4,((C_word*)t0)[2],t2,t3);}

/* f_1571 in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1571,5,t0,t1,t2,t3,t4);}
/* regex.scm: 411  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1566 in k1481 in string-split-fields in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1566,5,t0,t1,t2,t3,t4);}
/* regex.scm: 410  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1458r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1458r(t0,t1,t2,t3,t4);}}

static void f_1458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 381  prepare */
t6=((C_word*)t0)[2];
f_1403(t6,t5,t2,t3,t4,lf[56]);}

/* k1460 in string-search-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 382  ##regexp#gather-result-positions */
f_1260(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* string-search in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1449r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1449r(t0,t1,t2,t3,t4);}}

static void f_1449r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 376  prepare */
t6=((C_word*)t0)[2];
f_1403(t6,t5,t2,t3,t4,lf[55]);}

/* k1451 in string-search in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 377  ##regexp#gather-results */
t2=lf[44];
f_1306(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* prepare in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1403,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep((C_word)C_blockp(t4))?(C_word)C_slot(t4,C_fix(1)):C_SCHEME_FALSE);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(C_truep((C_word)C_blockp(t6))?(C_word)C_slot(t6,C_fix(0)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1417,a[2]=t8,a[3]=t7,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 369  ##regexp#compile */
f_390(t9,t2,t5);}
else{
if(C_truep((C_word)C_i_structurep(t2,lf[16]))){
t10=t9;
f_1417(2,t10,(C_word)C_slot(t2,C_fix(1)));}
else{
/* regex.scm: 371  ##sys#signal-hook */
t10=*((C_word*)lf[49]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[50],t5,lf[54],t2);}}}

/* k1415 in prepare in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
/* regex.scm: 372  ##regexp#re-match */
f_1327(((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-match-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1394r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1394r(t0,t1,t2,t3,t4);}}

static void f_1394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 352  prepare */
t6=((C_word*)t0)[2];
f_1344(t6,t5,t2,t3,t4,lf[53]);}

/* k1396 in string-match-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 353  ##regexp#gather-result-positions */
f_1260(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* string-match in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1385r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1385r(t0,t1,t2,t3,t4);}}

static void f_1385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 347  prepare */
t6=((C_word*)t0)[2];
f_1344(t6,t5,t2,t3,t4,lf[52]);}

/* k1387 in string-match in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 348  ##regexp#gather-results */
t2=lf[44];
f_1306(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* prepare in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1344,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1352,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1365,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 340  string-append */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[47],t2,lf[48]);}
else{
if(C_truep((C_word)C_i_structurep(t2,lf[16]))){
t9=t8;
f_1352(2,t9,(C_word)C_slot(t2,C_fix(1)));}
else{
/* regex.scm: 342  ##sys#signal-hook */
t9=*((C_word*)lf[49]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,lf[50],t5,lf[51],t2);}}}

/* k1363 in prepare in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 340  ##regexp#compile */
f_390(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1350 in prepare in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* regex.scm: 343  ##regexp#re-match */
f_1327(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* ##regexp#re-match in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1327(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1327,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1336,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
/* ##sys#make-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t8=t7;
f_1336(2,t8,C_SCHEME_FALSE);}}

/* k1334 in ##regexp#re-match in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub136(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* ##regexp#gather-results in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1306,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1310,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 309  ##regexp#gather-result-positions */
f_1260(t5,t2,t4);}

/* k1308 in ##regexp#gather-results in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 311  ##sys#map */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1317 in k1308 in ##regexp#gather-results in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1318,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##regexp#gather-result-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1260(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1260,NULL,3,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_regexp_count_matches(t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1272,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1272(t9,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in ##regexp#gather-result-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1272,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_regexp_register_start(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t5=(C_word)C_a_i_cons(&a,2,(C_word)C_regexp_register_end(t2),C_SCHEME_END_OF_LIST);
t6=t4;
f_1286(t6,(C_word)C_a_i_cons(&a,2,t3,t5));}
else{
t5=t4;
f_1286(t5,C_SCHEME_FALSE);}}}

/* k1284 in loop in ##regexp#gather-result-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1286,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1290,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 304  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1272(t4,t2,t3);}

/* k1288 in k1284 in loop in ##regexp#gather-result-positions in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* regexp? in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1254,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[16]));}

/* regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1229(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1229r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1229r(t0,t1,t2,t3);}}

static void f_1229r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)stub89(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1236,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 282  set-finalizer! */
t7=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,((C_word*)t0)[2]);}

/* k1234 in regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 283  comp */
t3=((C_word*)t0)[3];
f_1196(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k1250 in k1234 in regexp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[16],((C_word*)t0)[3]));}
else{
/* regex.scm: 285  ##sys#error */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[16],lf[39],((C_word*)t0)[2]);}}

/* comp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1196,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t4))){
/* regex.scm: 275  %comp */
f_1180(t1,t2,t3,C_unsigned_int_to_num(&a,REG_EXTENDED));}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1213,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 276  re-translate-pattern */
t7=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t2,t6);}}

/* k1211 in comp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_truep(t2)?C_unsigned_int_to_num(&a,REG_ICASE):C_fix(0));
t4=(C_word)C_u_fixnum_plus(C_unsigned_int_to_num(&a,REG_EXTENDED),t3);
/* regex.scm: 276  %comp */
f_1180(((C_word*)t0)[3],t1,((C_word*)t0)[2],t4);}

/* %comp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1180(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1180,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1185,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t6=t5;
f_1185(2,t6,C_SCHEME_FALSE);}}

/* k1183 in %comp in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub101(C_SCHEME_UNDEFINED,t1,t3,((C_word*)t0)[2]));}

/* free in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1171,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub93(C_SCHEME_UNDEFINED,t3));}

/* re-translate-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1132,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_u_i_car(t3))){
/* regex.scm: 255  white-space-ignore-pattern */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=t4;
f_1142(2,t5,t2);}}}

/* k1140 in re-translate-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_cadr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* regex.scm: 257  utf8-pattern->byte-pattern */
t5=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],t1);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}}

/* white-space-ignore-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_994,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 236  string->list */
t4=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k992 in white-space-ignore-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_996(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* lp in k992 in white-space-ignore-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_996(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_996,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 238  reverse */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
switch(t4){
case C_make_character(92):
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t2);
t7=(C_word)C_u_i_cadr(t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* regex.scm: 242  lp */
t21=t1;
t22=t6;
t23=t8;
t1=t21;
t2=t22;
t3=t23;
goto loop;}
else{
/* regex.scm: 243  ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[16],lf[37],((C_word*)t0)[2]);}
case C_make_character(35):
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1062,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1062(t9,t1,t5);
default:
t5=(C_word)C_eqp(t4,C_make_character(32));
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_make_character(9)));
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 249  lp */
t21=t1;
t22=t7;
t23=t3;
t1=t21;
t2=t22;
t3=t23;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* regex.scm: 250  lp */
t21=t1;
t22=t7;
t23=t9;
t1=t21;
t2=t22;
t3=t23;
goto loop;}}}}

/* lp2 in lp in k992 in white-space-ignore-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_1062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1062,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* regex.scm: 246  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_996(t3,t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,C_make_character(10));
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 247  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_996(t6,t1,t5,((C_word*)t0)[3]);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 248  lp2 */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* k1008 in lp in k992 in white-space-ignore-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 238  list->string */
t2=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_582,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_716,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_588,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_828,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
/* regex.scm: 233  scan */
t11=((C_word*)t6)[1];
f_588(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_828(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word *a;
loop:
a=C_alloc(40);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_828,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_eqp(t6,((C_word*)t0)[6]);
if(C_truep(t7)){
/* regex.scm: 215  ##sys#error */
t8=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[16],lf[35],((C_word*)t0)[5]);}
else{
t8=(C_word)C_subchar(((C_word*)t0)[5],t2);
switch(t8){
case C_make_character(93):
if(C_truep(t4)){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_865,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_a_i_cons(&a,2,C_make_character(91),t5);
/* regex.scm: 220  append */
t12=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t3,t11);}
else{
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_880,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_888,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 221  class->group */
t13=((C_word*)t0)[3];
f_716(t13,t12,t3);}
case C_make_character(92):
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_subchar(((C_word*)t0)[5],t9);
t11=(C_word)C_fix((C_word)C_character_code(t10));
if(C_truep((C_word)C_fixnum_lessp(t11,C_fix(128)))){
t12=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t14=(C_word)C_a_i_cons(&a,2,t10,t13);
/* regex.scm: 225  class */
t30=t1;
t31=t12;
t32=t14;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
/* regex.scm: 226  class */
t30=t1;
t31=t12;
t32=t13;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
default:
t9=(C_word)C_fix((C_word)C_character_code(t8));
if(C_truep((C_word)C_fixnum_lessp(t9,C_fix(128)))){
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t8,t3);
/* regex.scm: 229  class */
t30=t1;
t31=t10;
t32=t11;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=(C_word)C_fix((C_word)C_character_code(t8));
/* regex.scm: 230  utf8-start-byte->length */
t12=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}}}

/* k971 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 231  string-ref-at-byte */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k967 in k971 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* regex.scm: 230  class */
t3=((C_word*)((C_word*)t0)[5])[1];
f_828(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k886 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 221  reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k882 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 221  append */
t2=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k878 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 221  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_588(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k863 in class in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_865,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(93),t1);
/* regex.scm: 220  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_588(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* scan in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_588,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,((C_word*)t0)[5]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_602,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 186  reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t6){
case C_make_character(46):
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_617,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_lessp(t8,((C_word*)t0)[5]))){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_subchar(((C_word*)t0)[4],t9);
t11=t7;
f_617(t11,(C_word)C_eqp(C_make_character(42),t10));}
else{
t9=t7;
f_617(t9,C_SCHEME_FALSE);}
case C_make_character(92):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=(C_word)C_subchar(((C_word*)t0)[4],t8);
t10=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* regex.scm: 194  scan */
t21=t1;
t22=t7;
t23=t11;
t1=t21;
t2=t22;
t3=t23;
goto loop;
case C_make_character(91):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* regex.scm: 195  class */
t8=((C_word*)((C_word*)t0)[2])[1];
f_828(t8,t1,t7,C_SCHEME_END_OF_LIST,C_SCHEME_TRUE,t3);
default:
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* regex.scm: 196  scan */
t21=t1;
t22=t7;
t23=t8;
t1=t21;
t2=t22;
t3=t23;
goto loop;}}}

/* k615 in scan in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(46),((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(42),t3);
/* regex.scm: 191  scan */
t5=((C_word*)((C_word*)t0)[3])[1];
f_588(t5,((C_word*)t0)[2],t2,t4);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_643,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 192  append */
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[19],((C_word*)t0)[4]);}}

/* k641 in k615 in scan in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 192  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_588(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k600 in scan in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 186  list->string */
t2=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_716,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_722,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_722(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_722(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_722,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 201  string-intersperse */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[26]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_752,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_u_i_car(t5);
t8=t6;
f_752(t8,(C_word)C_eqp(C_make_character(45),t7));}
else{
t7=t6;
f_752(t7,C_SCHEME_FALSE);}}}

/* k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_752,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[7]));
t4=(C_word)C_fixnum_greaterp(t3,C_fix(128));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_764,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_764(t6,t4);}
else{
t6=(C_word)C_fix((C_word)C_character_code(t2));
t7=t5;
f_764(t7,(C_word)C_fixnum_greaterp(t6,C_fix(128)));}}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_816,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 212  char->string */
t4=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k814 in k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_816,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 212  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_722(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k762 in k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_764,NULL,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 207  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[16],lf[27],((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_782,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 209  char->string */
t5=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k784 in k762 in k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_790,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 210  char->string */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k788 in k784 in k762 in k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 209  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[28],((C_word*)t0)[2],lf[29],t1,lf[30]);}

/* k780 in k762 in k750 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 208  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_722(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k738 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 201  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[23],t1,lf[24]);}

/* k734 in loop in class->group in utf8-pattern->byte-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 200  string->list */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* string-ref-at-byte in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_493,4,t0,t1,t2,t3);}
t4=(C_word)C_subchar(t2,t3);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_503,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 159  utf8-start-byte->length */
t7=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k501 in string-ref-at-byte in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_503,2,t0,t1);}
t2=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
if(C_truep((C_word)C_fixnum_greaterp(t3,t4))){
/* regex.scm: 164  ##sys#error */
t5=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,((C_word*)t0)[5],lf[16],lf[17],((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_532,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_fixnum_difference(C_fix(7),t1);
/* regex.scm: 165  extract-bit-field */
t8=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,C_fix(0),((C_word*)t0)[4]);}}}

/* k530 in k501 in string-ref-at-byte in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_534,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_534(t2,((C_word*)t0)[2],t1));}

/* loop in k530 in k501 in string-ref-at-byte in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static C_word C_fcall f_534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
t3=t1;
t4=(C_word)C_eqp(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
return((C_word)C_make_character((C_word)C_unfix(t2)));}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_fixnum_shift_left(t2,C_fix(6));
t7=(C_word)C_subchar(((C_word*)t0)[2],t1);
t8=(C_word)C_fix((C_word)C_character_code(t7));
t9=(C_word)C_u_fixnum_and(C_fix(63),t8);
t10=(C_word)C_u_fixnum_or(t6,t9);
t12=t5;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* utf8-start-byte->length in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_487,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(lf[14],t2));}

/* extract-bit-field in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_465,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_fixnum_arithmetic_shift(C_fix(-1),t2);
t6=(C_word)C_fixnum_not(t5);
t7=(C_word)C_u_fixnum_negate(t3);
t8=(C_word)C_i_fixnum_arithmetic_shift(t4,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_u_fixnum_and(t6,t8));}

/* ##regexp#compile in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void C_fcall f_390(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_390,NULL,3,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_422,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=f_422(t6,C_fix(0));
t8=(C_word)C_slot(lf[5],((C_word*)t5)[1]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_400,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_416,a[2]=t3,a[3]=t2,a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_slot(t8,C_fix(1));
/* regex.scm: 126  ##regexp#re-compile-pattern */
t12=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}

/* k414 in ##regexp#compile in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_400(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3]));}
else{
/* regex.scm: 128  ##sys#error */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)t0)[2],lf[11],((C_word*)t0)[3]);}}

/* k398 in ##regexp#compile in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* loop in ##regexp#compile in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static C_word C_fcall f_422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,C_fix(5)))){
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[6]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(&lf[6],t3);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(lf[6],C_fix(5)))){
t5=lf[6]=C_fix(0);;
return(t5);}
else{
return(C_SCHEME_UNDEFINED);}}
else{
t2=(C_word)C_slot(lf[5],t1);
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_string_equal_p(((C_word*)t0)[2],t3))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
return(t4);}
else{
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t11=t4;
t1=t11;
goto loop;}}}

/* ##regexp#re-compile-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_373,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_378,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=t4;
f_378(2,t5,C_SCHEME_FALSE);}}

/* k376 in ##regexp#re-compile-pattern in k369 in k365 in k2243 in k2247 in k2251 in k2255 in k2259 in k357 */
static void f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub5(C_SCHEME_UNDEFINED,t1,t3));}
/* end of file */
