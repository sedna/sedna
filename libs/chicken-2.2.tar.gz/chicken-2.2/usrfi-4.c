/* Generated from srfi-4.scm by the Chicken compiler
   2005-08-24 19:43
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-4.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file usrfi-4.c -explicit-use
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)


static C_TLS C_word lf[143];


/* from ext-free in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub148(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub148(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_return:
#undef return

return C_r;}

/* from ext-alloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub143(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub143(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_return:
#undef return

return C_r;}

C_externexport void C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_758(C_word c,C_word t0,C_word t1) C_noret;
static void f_762(C_word c,C_word t0,C_word t1) C_noret;
static void f_766(C_word c,C_word t0,C_word t1) C_noret;
static void f_770(C_word c,C_word t0,C_word t1) C_noret;
static void f_774(C_word c,C_word t0,C_word t1) C_noret;
static void f_778(C_word c,C_word t0,C_word t1) C_noret;
static void f_782(C_word c,C_word t0,C_word t1) C_noret;
static void f_786(C_word c,C_word t0,C_word t1) C_noret;
static void f_907(C_word c,C_word t0,C_word t1) C_noret;
static void f_911(C_word c,C_word t0,C_word t1) C_noret;
static void f_915(C_word c,C_word t0,C_word t1) C_noret;
static void f_919(C_word c,C_word t0,C_word t1) C_noret;
static void f_923(C_word c,C_word t0,C_word t1) C_noret;
static void f_927(C_word c,C_word t0,C_word t1) C_noret;
static void f_931(C_word c,C_word t0,C_word t1) C_noret;
static void f_935(C_word c,C_word t0,C_word t1) C_noret;
static void f_939(C_word c,C_word t0,C_word t1) C_noret;
static void f_943(C_word c,C_word t0,C_word t1) C_noret;
static void f_947(C_word c,C_word t0,C_word t1) C_noret;
static void f_951(C_word c,C_word t0,C_word t1) C_noret;
static void f_963(C_word c,C_word t0,C_word t1) C_noret;
static void f_967(C_word c,C_word t0,C_word t1) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1) C_noret;
static void f_1970(C_word c,C_word t0,C_word t1) C_noret;
static void f_1974(C_word c,C_word t0,C_word t1) C_noret;
static void f_1978(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1986(C_word c,C_word t0,C_word t1) C_noret;
static void f_1990(C_word c,C_word t0,C_word t1) C_noret;
static void f_1994(C_word c,C_word t0,C_word t1) C_noret;
static void f_2081(C_word c,C_word t0,C_word t1) C_noret;
static void f_2085(C_word c,C_word t0,C_word t1) C_noret;
static void f_2089(C_word c,C_word t0,C_word t1) C_noret;
static void f_2093(C_word c,C_word t0,C_word t1) C_noret;
static void f_2097(C_word c,C_word t0,C_word t1) C_noret;
static void f_2101(C_word c,C_word t0,C_word t1) C_noret;
static void f_2105(C_word c,C_word t0,C_word t1) C_noret;
static void f_2109(C_word c,C_word t0,C_word t1) C_noret;
static void f_2193(C_word c,C_word t0,C_word t1) C_noret;
static void f_2197(C_word c,C_word t0,C_word t1) C_noret;
static void f_2201(C_word c,C_word t0,C_word t1) C_noret;
static void f_2205(C_word c,C_word t0,C_word t1) C_noret;
static void f_2209(C_word c,C_word t0,C_word t1) C_noret;
static void f_2213(C_word c,C_word t0,C_word t1) C_noret;
static void f_2217(C_word c,C_word t0,C_word t1) C_noret;
static void f_2221(C_word c,C_word t0,C_word t1) C_noret;
static void f_2225(C_word c,C_word t0,C_word t1) C_noret;
static void f_2229(C_word c,C_word t0,C_word t1) C_noret;
static void f_2233(C_word c,C_word t0,C_word t1) C_noret;
static void f_2237(C_word c,C_word t0,C_word t1) C_noret;
static void f_2241(C_word c,C_word t0,C_word t1) C_noret;
static void f_2245(C_word c,C_word t0,C_word t1) C_noret;
static void f_2249(C_word c,C_word t0,C_word t1) C_noret;
static void f_2253(C_word c,C_word t0,C_word t1) C_noret;
static void f_2460(C_word c,C_word t0,C_word t1) C_noret;
static void f_2453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2398(C_word c,C_word t0,C_word t1) C_noret;
static void f_2314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2324(C_word c,C_word t0,C_word t1) C_noret;
static void f_2327(C_word c,C_word t0,C_word t1) C_noret;
static void f_2334(C_word c,C_word t0,C_word t1) C_noret;
static void f_2258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void f_2293(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2179(C_word t0,C_word t1) C_noret;
static void C_fcall f_2159(C_word t0) C_noret;
static void f_2161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2044(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2050(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2055(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2069(C_word c,C_word t0,C_word t1) C_noret;
static void f_2073(C_word c,C_word t0,C_word t1) C_noret;
static void f_2038(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2038r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2032(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2032r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2026(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2026r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2020(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2020r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2014r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2008(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2008r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2002r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1996(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1996r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1929(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1938(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1950(C_word c,C_word t0,C_word t1) C_noret;
static void f_1811(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1811r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1869(C_word t0,C_word t1) C_noret;
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1858(C_word c,C_word t0,C_word t1) C_noret;
static void f_1820(C_word c,C_word t0,C_word t1) C_noret;
static void f_1848(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1829(C_word t0,C_word t1) C_noret;
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1841(C_word c,C_word t0,C_word t1) C_noret;
static void f_1693(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1693r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1751(C_word t0,C_word t1) C_noret;
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1) C_noret;
static void f_1702(C_word c,C_word t0,C_word t1) C_noret;
static void f_1730(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1711(C_word t0,C_word t1) C_noret;
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1723(C_word c,C_word t0,C_word t1) C_noret;
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1582r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1633(C_word t0,C_word t1) C_noret;
static void C_fcall f_1628(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1622(C_word c,C_word t0,C_word t1) C_noret;
static void f_1591(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1602(C_word t0,C_word t1);
static void f_1471(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1471r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1522(C_word t0,C_word t1) C_noret;
static void C_fcall f_1517(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1473(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1511(C_word c,C_word t0,C_word t1) C_noret;
static void f_1480(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1491(C_word t0,C_word t1);
static void f_1357(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1357r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1411(C_word t0,C_word t1) C_noret;
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1401(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1400(C_word c,C_word t0,C_word t1) C_noret;
static void f_1366(C_word c,C_word t0,C_word t1) C_noret;
static void f_1375(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1387(C_word c,C_word t0,C_word t1) C_noret;
static void f_1243(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1243r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1297(C_word t0,C_word t1) C_noret;
static void C_fcall f_1292(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1286(C_word c,C_word t0,C_word t1) C_noret;
static void f_1252(C_word c,C_word t0,C_word t1) C_noret;
static void f_1261(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1266(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1273(C_word c,C_word t0,C_word t1) C_noret;
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1129r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1183(C_word t0,C_word t1) C_noret;
static void C_fcall f_1178(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1173(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1172(C_word c,C_word t0,C_word t1) C_noret;
static void f_1138(C_word c,C_word t0,C_word t1) C_noret;
static void f_1147(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1159(C_word c,C_word t0,C_word t1) C_noret;
static void f_1015(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1015r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1069(C_word t0,C_word t1) C_noret;
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1059(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1017(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1058(C_word c,C_word t0,C_word t1) C_noret;
static void f_1024(C_word c,C_word t0,C_word t1) C_noret;
static void f_1033(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1038(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1045(C_word c,C_word t0,C_word t1) C_noret;
static void f_990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_997(C_word t0,C_word t1) C_noret;
static void C_fcall f_972(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_988(C_word c,C_word t0,C_word t1) C_noret;
static void f_970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_836(C_word c,C_word t0,C_word t1) C_noret;
static void f_839(C_word c,C_word t0,C_word t1) C_noret;
static void f_856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_860(C_word c,C_word t0,C_word t1) C_noret;
static void f_863(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_887(C_word t0,C_word t1,C_word t2) C_noret;
static void f_889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_893(C_word c,C_word t0,C_word t1) C_noret;
static void f_900(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_810(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_816(C_word c,C_word t0,C_word t1) C_noret;
static void f_819(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_799(C_word t0,C_word t1,C_word t2) C_noret;
static void f_801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_788(C_word t0,C_word t1,C_word t2) C_noret;
static void f_790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_794(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_748(C_word t0,C_word t1) C_noret;
static void f_750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static C_word C_fcall f_739(C_word t0,C_word t1,C_word t2);
static C_word C_fcall f_736(C_word t0,C_word t1,C_word t2);
static void f_733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

static void C_fcall trf_2382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2382(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2382(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2164(t0,t1,t2,t3);}

static void C_fcall trf_2179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2179(t0,t1);}

static void C_fcall trf_2159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2159(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2159(t0);}

static void C_fcall trf_2044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2044(t0,t1,t2);}

static void C_fcall trf_2055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2055(t0,t1,t2);}

static void C_fcall trf_1929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1929(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1929(t0,t1,t2);}

static void C_fcall trf_1943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1943(t0,t1,t2,t3);}

static void C_fcall trf_1869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1869(t0,t1);}

static void C_fcall trf_1864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1864(t0,t1,t2);}

static void C_fcall trf_1859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1859(t0,t1,t2,t3);}

static void C_fcall trf_1813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1813(t0,t1,t2,t3);}

static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1829(t0,t1);}

static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1834(t0,t1,t2);}

static void C_fcall trf_1751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1751(t0,t1);}

static void C_fcall trf_1746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1746(t0,t1,t2);}

static void C_fcall trf_1741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1741(t0,t1,t2,t3);}

static void C_fcall trf_1695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1695(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1695(t0,t1,t2,t3);}

static void C_fcall trf_1711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1711(t0,t1);}

static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1716(t0,t1,t2);}

static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1633(t0,t1);}

static void C_fcall trf_1628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1628(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1628(t0,t1,t2);}

static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1623(t0,t1,t2,t3);}

static void C_fcall trf_1584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1584(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1584(t0,t1,t2,t3);}

static void C_fcall trf_1522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1522(t0,t1);}

static void C_fcall trf_1517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1517(t0,t1,t2);}

static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1512(t0,t1,t2,t3);}

static void C_fcall trf_1473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1473(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1473(t0,t1,t2,t3);}

static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1411(t0,t1);}

static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1406(t0,t1,t2);}

static void C_fcall trf_1401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1401(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1401(t0,t1,t2,t3);}

static void C_fcall trf_1359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1359(t0,t1,t2,t3);}

static void C_fcall trf_1380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1380(t0,t1,t2);}

static void C_fcall trf_1297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1297(t0,t1);}

static void C_fcall trf_1292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1292(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1292(t0,t1,t2);}

static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1287(t0,t1,t2,t3);}

static void C_fcall trf_1245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1245(t0,t1,t2,t3);}

static void C_fcall trf_1266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1266(t0,t1,t2);}

static void C_fcall trf_1183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1183(t0,t1);}

static void C_fcall trf_1178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1178(t0,t1,t2);}

static void C_fcall trf_1173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1173(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1173(t0,t1,t2,t3);}

static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1131(t0,t1,t2,t3);}

static void C_fcall trf_1152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1152(t0,t1,t2);}

static void C_fcall trf_1069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1069(t0,t1);}

static void C_fcall trf_1064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1064(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1064(t0,t1,t2);}

static void C_fcall trf_1059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1059(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1059(t0,t1,t2,t3);}

static void C_fcall trf_1017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1017(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1017(t0,t1,t2,t3,t4);}

static void C_fcall trf_1038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1038(t0,t1,t2);}

static void C_fcall trf_997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_997(t0,t1);}

static void C_fcall trf_972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_972(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_972(t0,t1,t2,t3);}

static void C_fcall trf_887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_887(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_887(t0,t1,t2);}

static void C_fcall trf_810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_810(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_810(t0,t1,t2,t3);}

static void C_fcall trf_799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_799(t0,t1,t2);}

static void C_fcall trf_788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_788(t0,t1,t2);}

static void C_fcall trf_748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_748(t0,t1);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(42);
if(!C_demand(42)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1113)){
C_save(t1);
C_rereclaim2(1113*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(42);
C_initialize_lf(lf,143);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,38,"numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_static_string(C_heaptop,38,"numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_static_string(C_heaptop,28,"argument may not be negative");
lf[33]=C_h_intern(&lf[33],12,"u8vector-ref");
lf[34]=C_h_intern(&lf[34],12,"s8vector-ref");
lf[35]=C_h_intern(&lf[35],13,"u16vector-ref");
lf[36]=C_h_intern(&lf[36],13,"s16vector-ref");
lf[37]=C_h_intern(&lf[37],13,"u32vector-ref");
lf[38]=C_h_intern(&lf[38],13,"s32vector-ref");
lf[39]=C_h_intern(&lf[39],13,"f32vector-ref");
lf[40]=C_h_intern(&lf[40],13,"f64vector-ref");
lf[41]=C_h_intern(&lf[41],13,"u8vector-set!");
lf[42]=C_h_intern(&lf[42],13,"s8vector-set!");
lf[43]=C_h_intern(&lf[43],14,"u16vector-set!");
lf[44]=C_h_intern(&lf[44],14,"s16vector-set!");
lf[45]=C_h_intern(&lf[45],14,"u32vector-set!");
lf[46]=C_static_string(C_heaptop,28,"argument may not be negative");
lf[47]=C_static_string(C_heaptop,30,"argument exceeds integer range");
lf[48]=C_h_intern(&lf[48],14,"s32vector-set!");
lf[49]=C_static_string(C_heaptop,30,"argument exceeds integer range");
lf[50]=C_h_intern(&lf[50],14,"f32vector-set!");
lf[51]=C_h_intern(&lf[51],14,"f64vector-set!");
lf[52]=C_h_intern(&lf[52],14,"set-finalizer!");
lf[53]=C_static_string(C_heaptop,59,"not enough memory - can not allocate external number vector");
lf[54]=C_h_intern(&lf[54],19,"\003sysallocate-vector");
lf[55]=C_h_intern(&lf[55],21,"release-number-vector");
lf[56]=C_static_string(C_heaptop,39,"bad argument type - not a number vector");
tmp=C_intern(C_heaptop,8,"u8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"s8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f64vector");
C_save(tmp);
lf[57]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[58]=C_h_intern(&lf[58],13,"make-u8vector");
lf[59]=C_h_intern(&lf[59],8,"u8vector");
lf[60]=C_h_intern(&lf[60],13,"make-s8vector");
lf[61]=C_h_intern(&lf[61],8,"s8vector");
lf[62]=C_h_intern(&lf[62],4,"fin\077");
lf[63]=C_h_intern(&lf[63],14,"make-u16vector");
lf[64]=C_h_intern(&lf[64],9,"u16vector");
lf[65]=C_h_intern(&lf[65],14,"make-s16vector");
lf[66]=C_h_intern(&lf[66],9,"s16vector");
lf[67]=C_h_intern(&lf[67],14,"make-u32vector");
lf[68]=C_h_intern(&lf[68],9,"u32vector");
lf[69]=C_h_intern(&lf[69],14,"make-s32vector");
lf[70]=C_h_intern(&lf[70],9,"s32vector");
lf[71]=C_h_intern(&lf[71],14,"make-f32vector");
lf[72]=C_h_intern(&lf[72],9,"f32vector");
lf[73]=C_h_intern(&lf[73],14,"make-f64vector");
lf[74]=C_h_intern(&lf[74],9,"f64vector");
lf[75]=C_h_intern(&lf[75],27,"\003sysnot-a-proper-list-error");
lf[76]=C_h_intern(&lf[76],14,"list->u8vector");
lf[77]=C_h_intern(&lf[77],14,"list->s8vector");
lf[78]=C_h_intern(&lf[78],15,"list->u16vector");
lf[79]=C_h_intern(&lf[79],15,"list->s16vector");
lf[80]=C_h_intern(&lf[80],15,"list->u32vector");
lf[81]=C_h_intern(&lf[81],15,"list->s32vector");
lf[82]=C_h_intern(&lf[82],15,"list->f32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f64vector");
lf[84]=C_h_intern(&lf[84],14,"u8vector->list");
lf[85]=C_h_intern(&lf[85],14,"s8vector->list");
lf[86]=C_h_intern(&lf[86],15,"u16vector->list");
lf[87]=C_h_intern(&lf[87],15,"s16vector->list");
lf[88]=C_h_intern(&lf[88],15,"u32vector->list");
lf[89]=C_h_intern(&lf[89],15,"s32vector->list");
lf[90]=C_h_intern(&lf[90],15,"f32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f64vector->list");
lf[92]=C_h_intern(&lf[92],9,"u8vector\077");
lf[93]=C_h_intern(&lf[93],9,"s8vector\077");
lf[94]=C_h_intern(&lf[94],10,"u16vector\077");
lf[95]=C_h_intern(&lf[95],10,"s16vector\077");
lf[96]=C_h_intern(&lf[96],10,"u32vector\077");
lf[97]=C_h_intern(&lf[97],10,"s32vector\077");
lf[98]=C_h_intern(&lf[98],10,"f32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f64vector\077");
lf[100]=C_static_string(C_heaptop,49,"bytevector does not have correct size for packing");
lf[101]=C_h_intern(&lf[101],21,"u8vector->byte-vector");
lf[102]=C_h_intern(&lf[102],21,"s8vector->byte-vector");
lf[103]=C_h_intern(&lf[103],22,"u16vector->byte-vector");
lf[104]=C_h_intern(&lf[104],22,"s16vector->byte-vector");
lf[105]=C_h_intern(&lf[105],22,"u32vector->byte-vector");
lf[106]=C_h_intern(&lf[106],22,"s32vector->byte-vector");
lf[107]=C_h_intern(&lf[107],22,"f32vector->byte-vector");
lf[108]=C_h_intern(&lf[108],22,"f64vector->byte-vector");
lf[109]=C_h_intern(&lf[109],21,"byte-vector->u8vector");
lf[110]=C_h_intern(&lf[110],21,"byte-vector->s8vector");
lf[111]=C_h_intern(&lf[111],22,"byte-vector->u16vector");
lf[112]=C_h_intern(&lf[112],22,"byte-vector->s16vector");
lf[113]=C_h_intern(&lf[113],22,"byte-vector->u32vector");
lf[114]=C_h_intern(&lf[114],22,"byte-vector->s32vector");
lf[115]=C_h_intern(&lf[115],22,"byte-vector->f32vector");
lf[116]=C_h_intern(&lf[116],22,"byte-vector->f64vector");
lf[117]=C_h_intern(&lf[117],18,"\003sysuser-read-hook");
lf[118]=C_h_intern(&lf[118],4,"read");
lf[119]=C_h_intern(&lf[119],2,"u8");
lf[120]=C_h_intern(&lf[120],2,"s8");
lf[121]=C_h_intern(&lf[121],3,"u16");
lf[122]=C_h_intern(&lf[122],3,"s16");
lf[123]=C_h_intern(&lf[123],3,"u32");
lf[124]=C_h_intern(&lf[124],3,"s32");
lf[125]=C_h_intern(&lf[125],3,"f32");
lf[126]=C_h_intern(&lf[126],3,"f64");
lf[127]=C_h_intern(&lf[127],1,"f");
lf[128]=C_h_intern(&lf[128],1,"F");
lf[129]=C_static_string(C_heaptop,25,"illegal bytevector syntax");
lf[130]=C_h_intern(&lf[130],19,"\003sysuser-print-hook");
lf[131]=C_h_intern(&lf[131],9,"\003sysprint");
lf[133]=C_h_intern(&lf[133],11,"subu8vector");
lf[134]=C_h_intern(&lf[134],12,"subu16vector");
lf[135]=C_h_intern(&lf[135],12,"subu32vector");
lf[136]=C_h_intern(&lf[136],11,"subs8vector");
lf[137]=C_h_intern(&lf[137],12,"subs16vector");
lf[138]=C_h_intern(&lf[138],12,"subs32vector");
lf[139]=C_h_intern(&lf[139],12,"subf32vector");
lf[140]=C_h_intern(&lf[140],12,"subf64vector");
lf[141]=C_h_intern(&lf[141],17,"register-feature!");
lf[142]=C_h_intern(&lf[142],6,"srfi-4");
C_register_lf(lf,143);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_664,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_676,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_694,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_697,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_700,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_703,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_709,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_712,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_718,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_724,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_727,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_730,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_733,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_736,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_739,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_742,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[23],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_745,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_748,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_758,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_748(t22,C_SCHEME_FALSE);}

/* k756 */
static void f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_SCHEME_FALSE);}

/* k760 in k756 */
static void f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_fix(1));}

/* k764 in k760 in k756 */
static void f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_fix(1));}

/* k768 in k764 in k760 in k756 */
static void f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_fix(2));}

/* k772 in k768 in k764 in k760 in k756 */
static void f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_fix(2));}

/* k776 in k772 in k768 in k764 in k760 in k756 */
static void f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_778,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_748(t3,C_fix(2));}

/* k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_748(t3,C_fix(3));}

/* k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_788,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_799,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_810,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_887,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_907,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
f_788(t7,*((C_word*)lf[24]+1),lf[7]);}

/* k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_907,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_919,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
f_788(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
f_788(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
f_810(t3,*((C_word*)lf[24]+1),lf[16],lf[41]);}

/* k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
f_799(t3,*((C_word*)lf[25]+1),lf[17]);}

/* k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
f_810(t3,*((C_word*)lf[26]+1),lf[18],lf[43]);}

/* k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_799(t3,*((C_word*)lf[27]+1),lf[19]);}

/* k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=*((C_word*)lf[28]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_856,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[45]+1,t4);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_832,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_mutate((C_word*)lf[48]+1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_887(t9,*((C_word*)lf[30]+1),lf[22]);}

/* k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_887(t3,*((C_word*)lf[31]+1),lf[23]);}

/* k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_970,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[52]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_972,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1015,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1129,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1471,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1582,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1693,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1811,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1929,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_1929(t16,*((C_word*)lf[58]+1),*((C_word*)lf[41]+1));}

/* k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[60]+1),*((C_word*)lf[42]+1));}

/* k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[63]+1),*((C_word*)lf[43]+1));}

/* k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[65]+1),*((C_word*)lf[44]+1));}

/* k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[67]+1),*((C_word*)lf[45]+1));}

/* k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[69]+1),*((C_word*)lf[48]+1));}

/* k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1929(t3,*((C_word*)lf[71]+1),*((C_word*)lf[50]+1));}

/* k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_1929(t3,*((C_word*)lf[73]+1),*((C_word*)lf[51]+1));}

/* k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=*((C_word*)lf[76]+1);
t4=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[77]+1);
t6=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[78]+1);
t8=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[79]+1);
t10=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[80]+1);
t12=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2020,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[81]+1);
t14=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[82]+1);
t16=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[83]+1);
t18=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2038,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2044,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_2044(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2044(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_2044(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2111,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2117,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2123,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2129,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2135,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2141,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2147,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2153,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2159,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2164,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2193,a[2]=t11,a[3]=t12,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
f_2159(t13);}

/* k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=C_mutate((C_word*)lf[102]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2159(t3);}

/* k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_2159(t3);}

/* k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[59],C_SCHEME_TRUE,lf[109]);}

/* k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[61],C_SCHEME_TRUE,lf[110]);}

/* k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[64],C_fix(2),lf[111]);}

/* k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[66],C_fix(2),lf[112]);}

/* k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[68],C_fix(4),lf[113]);}

/* k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[70],C_fix(4),lf[114]);}

/* k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_2164(t3,lf[72],C_fix(4),lf[115]);}

/* k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
f_2164(t3,lf[74],C_fix(8),lf[116]);}

/* k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=*((C_word*)lf[117]+1);
t4=*((C_word*)lf[118]+1);
t5=(C_word)C_a_i_list(&a,16,lf[119],*((C_word*)lf[76]+1),lf[120],*((C_word*)lf[77]+1),lf[121],*((C_word*)lf[78]+1),lf[122],*((C_word*)lf[79]+1),lf[123],*((C_word*)lf[80]+1),lf[124],*((C_word*)lf[81]+1),lf[125],*((C_word*)lf[82]+1),lf[126],*((C_word*)lf[83]+1));
t6=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2258,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[130]+1);
t8=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[132],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2382,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2411,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2417,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2423,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2429,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2435,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2441,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2447,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2453,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[142]);}

/* k2458 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* subf64vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2453,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[74],C_fix(8),t3,t4);}

/* subf32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2447,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[72],C_fix(4),t3,t4);}

/* subs32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2441,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[70],C_fix(4),t3,t4);}

/* subs16vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2435,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[66],C_fix(2),t3,t4);}

/* subs8vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2429,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[61],C_fix(1),t3,t4);}

/* subu32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2423,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[68],C_fix(4),t3,t4);}

/* subu16vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2417,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[64],C_fix(2),t3,t4);}

/* subu8vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2411,5,t0,t1,t2,t3,t4);}
f_2382(t1,t2,lf[59],C_fix(1),t3,t4);}

/* subvector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_2382(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2382,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t7);
t9=(C_word)C_fixnum_divide(t8,t4);
t10=(C_word)C_u_fixnum_difference(t6,t5);
t11=(C_word)C_fixnum_times(t4,t10);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2398,a[2]=t1,a[3]=t11,a[4]=t7,a[5]=t4,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=*((C_word*)lf[54]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,t11,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2396 in subvector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2314,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,3,lf[59],lf[119],*((C_word*)lf[84]+1));
t6=(C_word)C_a_i_list(&a,3,lf[61],lf[120],*((C_word*)lf[85]+1));
t7=(C_word)C_a_i_list(&a,3,lf[64],lf[121],*((C_word*)lf[86]+1));
t8=(C_word)C_a_i_list(&a,3,lf[66],lf[122],*((C_word*)lf[87]+1));
t9=(C_word)C_a_i_list(&a,3,lf[68],lf[123],*((C_word*)lf[88]+1));
t10=(C_word)C_a_i_list(&a,3,lf[70],lf[124],*((C_word*)lf[89]+1));
t11=(C_word)C_a_i_list(&a,3,lf[72],lf[125],*((C_word*)lf[90]+1));
t12=(C_word)C_a_i_list(&a,3,lf[74],lf[126],*((C_word*)lf[91]+1));
t13=(C_word)C_a_i_list(&a,8,t5,t6,t7,t8,t9,t10,t11,t12);
t14=(C_word)C_u_i_assq((C_word)C_slot(t2,C_fix(0)),t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2324,a[2]=t2,a[3]=t14,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t16=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
t15=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t1,t2,t3,t4);}}

/* k2322 in ##sys#user-print-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
t4=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2325 in k2322 in ##sys#user-print-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}

/* k2332 in k2325 in k2322 in ##sys#user-print-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2258,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2268,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2266 in ##sys#user-read-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[127]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[128]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[5],lf[129],t3);}}}

/* k2291 in k2266 in ##sys#user-read-hook in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k2219 in k2215 in k2211 in k2207 in k2203 in k2199 in k2195 in k2191 in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t1);}

/* unpack in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_2164(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2164,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2166,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2166 in unpack in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2166,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2179(t7,t5);}
else{
t7=(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3]);
t8=t6;
f_2179(t8,(C_word)C_eqp(C_fix(0),t7));}}

/* k2177 */
static void C_fcall f_2179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2179,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]));}
else{
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[7],((C_word*)t0)[4],lf[100],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* pack in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_2159(C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2159,NULL,1,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2161,tmp=(C_word)a,a+=2,tmp));}

/* f_2161 in pack in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2161,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2153,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[74]));}

/* f32vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2147,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[72]));}

/* s32vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2141,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[70]));}

/* u32vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2135,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[68]));}

/* s16vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2129,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[66]));}

/* u16vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2123,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[64]));}

/* s8vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2117,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[61]));}

/* u8vector? in k2107 in k2103 in k2099 in k2095 in k2091 in k2087 in k2083 in k2079 in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2111,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[59]));}

/* init in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_2044(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2044,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_2046 in init in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2048 */
static void f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2055(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2048 */
static void C_fcall f_2055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2055,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2067 in loop in k2048 */
static void f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_2055(t4,t2,t3);}

/* k2071 in k2067 in loop in k2048 */
static void f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2038(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2038r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2038r(t0,t1,t2);}}

static void f_2038r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2032(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2032r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2032r(t0,t1,t2);}}

static void f_2032r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2026(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2026r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2026r(t0,t1,t2);}}

static void f_2026r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2020(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2020r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2020r(t0,t1,t2);}}

static void f_2020r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2014(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2014r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2014r(t0,t1,t2);}}

static void f_2014r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2008(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2008r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2008r(t0,t1,t2);}}

static void f_2008r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_2002(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2002r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2002r(t0,t1,t2);}}

static void f_2002r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k1992 in k1988 in k1984 in k1980 in k1976 in k1972 in k1968 in k1964 in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1996(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1996r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1996r(t0,t1,t2);}}

static void f_1996r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* init in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1929(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1929,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_1931 in init in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1931,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1938,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1936 */
static void f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1943(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do464 in k1936 */
static void C_fcall f_1943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1943,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1950,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
t6=*((C_word*)lf[75]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k1948 in do464 in k1936 */
static void f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_1943(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1811(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1811r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1811r(t0,t1,t2,t3);}}

static void f_1811r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1869(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1864(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1859(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1813(t14,t1,t8,t10);}}}}

/* def-init421 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1869,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1864(t2,t1,C_SCHEME_FALSE);}

/* def-ext?422 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1864,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1859(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin423 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1859,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1813(t4,t1,t2,t3);}

/* body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1813,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
f_972(t5,lf[73],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[74],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1820(2,t5,C_SCHEME_UNDEFINED);}}

/* k1818 in k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t3;
f_1829(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1848,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_exact_to_inexact(3,0,t4,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1846 in k1818 in k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1829(t3,t2);}

/* k1827 in k1818 in k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1834(t5,((C_word*)t0)[2],C_fix(0));}

/* do430 in k1827 in k1818 in k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1841,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[23];
f_745(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1839 in do430 in k1827 in k1818 in k1856 in body419 in make-f64vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1834(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1693(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1693r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1693r(t0,t1,t2,t3);}}

static void f_1693r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1751(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1746(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1741(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1695(t14,t1,t8,t10);}}}}

/* def-init385 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1751,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1746(t2,t1,C_SCHEME_FALSE);}

/* def-ext?386 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1746,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1741(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin387 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1741,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1695(t4,t1,t2,t3);}

/* body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1695,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
f_972(t5,lf[71],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[72],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1702(2,t5,C_SCHEME_UNDEFINED);}}

/* k1700 in k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t3;
f_1711(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_exact_to_inexact(3,0,t4,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1728 in k1700 in k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1711(t3,t2);}

/* k1709 in k1700 in k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1711,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1716(t5,((C_word*)t0)[2],C_fix(0));}

/* do394 in k1709 in k1700 in k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1723,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[22];
f_742(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1721 in do394 in k1709 in k1700 in k1738 in body383 in make-f32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1716(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1582(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1582r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1582r(t0,t1,t2,t3);}}

static void f_1582r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1628,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1633(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1628(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1623(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1584(t14,t1,t8,t10);}}}}

/* def-init350 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1628(t2,t1,C_SCHEME_FALSE);}

/* def-ext?351 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1628(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1628,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1623(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin352 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1623,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1584(t4,t1,t2,t3);}

/* body348 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1584,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_972(t4,lf[69],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1620 in body348 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[70],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1591(2,t5,C_SCHEME_UNDEFINED);}}

/* k1589 in k1620 in body348 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1602(t3,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do359 in k1589 in k1620 in body348 in make-s32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static C_word C_fcall f_1602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_739(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1471(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1471r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1471r(t0,t1,t2,t3);}}

static void f_1471r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1522,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1522(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1517(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1512(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1473(t14,t1,t8,t10);}}}}

/* def-init315 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1522,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1517(t2,t1,C_SCHEME_FALSE);}

/* def-ext?316 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1517,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1512(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin317 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1473(t4,t1,t2,t3);}

/* body313 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1473(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1473,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_972(t4,lf[67],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1509 in body313 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[68],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1480(2,t5,C_SCHEME_UNDEFINED);}}

/* k1478 in k1509 in body313 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1491(t3,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do324 in k1478 in k1509 in body313 in make-u32vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static C_word C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_736(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1357(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1357r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1357r(t0,t1,t2,t3);}}

static void f_1357r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1411(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1406(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1401(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1359(t14,t1,t8,t10);}}}}

/* def-init279 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1406(t2,t1,C_SCHEME_FALSE);}

/* def-ext?280 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1406,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1401(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin281 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1401(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1401,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1359(t4,t1,t2,t3);}

/* body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1359,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_972(t4,lf[65],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1398 in body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[66],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1366(2,t5,C_SCHEME_UNDEFINED);}}

/* k1364 in k1398 in body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[65]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1373 in k1364 in k1398 in body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1380(t5,((C_word*)t0)[2],C_fix(0));}

/* do288 in k1373 in k1364 in k1398 in body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1380,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[19];
f_733(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1385 in do288 in k1373 in k1364 in k1398 in body277 in make-s16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1380(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1243(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1243r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1243r(t0,t1,t2,t3);}}

static void f_1243r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1287,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1297(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1292(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1287(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1245(t14,t1,t8,t10);}}}}

/* def-init243 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1297,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1292(t2,t1,C_SCHEME_FALSE);}

/* def-ext?244 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1292,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1287(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin245 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1245(t4,t1,t2,t3);}

/* body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1245,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_972(t4,lf[63],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1284 in body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[64],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1252(2,t5,C_SCHEME_UNDEFINED);}}

/* k1250 in k1284 in body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[63]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1259 in k1250 in k1284 in body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1266(t5,((C_word*)t0)[2],C_fix(0));}

/* do252 in k1259 in k1250 in k1284 in body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1266,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1273,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[18];
f_730(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1271 in do252 in k1259 in k1250 in k1284 in body241 in make-u16vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1266(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1129r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1129r(t0,t1,t2,t3);}}

static void f_1129r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1183(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1178(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1173(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1131(t14,t1,t8,t10);}}}}

/* def-init207 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1183,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1178(t2,t1,C_SCHEME_FALSE);}

/* def-ext?208 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1178,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1173(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin209 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1173(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1173,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1131(t4,t1,t2,t3);}

/* body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1131,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
f_972(t4,lf[60],((C_word*)t0)[5],t3);}

/* k1170 in body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[62]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1138(2,t5,C_SCHEME_UNDEFINED);}}

/* k1136 in k1170 in body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[60]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1145 in k1136 in k1170 in body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1152(t5,((C_word*)t0)[2],C_fix(0));}

/* do216 in k1145 in k1136 in k1170 in body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1152,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1159,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[17];
f_727(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1157 in do216 in k1145 in k1136 in k1170 in body205 in make-s8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1152(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1015(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1015r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1015r(t0,t1,t2,t3);}}

static void f_1015r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t8=t7;
f_1069(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
t10=t6;
f_1064(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
t12=t5;
f_1059(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
t14=t4;
f_1017(t14,t1,t8,t10,t12);}}}}

/* def-init170 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1069,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1064(t2,t1,C_SCHEME_FALSE);}

/* def-ext?171 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1064,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1059(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?172 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1059(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1059,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_1017(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1017(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1017,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
f_972(t5,lf[58],((C_word*)t0)[5],t3);}

/* k1056 in body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[59],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1024(2,t5,C_SCHEME_UNDEFINED);}}

/* k1022 in k1056 in body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[58]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1031 in k1022 in k1056 in body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1038(t5,((C_word*)t0)[2],C_fix(0));}

/* do179 in k1031 in k1022 in k1056 in body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_1038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1038,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1045,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=lf[16];
f_724(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1043 in do179 in k1031 in k1022 in k1056 in body168 in make-u8vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1038(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_990,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_997,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_997(t5,(C_word)C_u_i_memq(t4,lf[57]));}
else{
t4=t3;
f_997(t4,C_SCHEME_FALSE);}}

/* k995 in release-number-vector in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_970(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[55],lf[56],((C_word*)t0)[2]);}}

/* alloc in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_972(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_972,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)stub143(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[53],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[54]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k986 in alloc in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k965 in k961 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_970,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub148(C_SCHEME_UNDEFINED,t2));}

/* f_832 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_832,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_836,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k834 */
static void f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_839(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[48],lf[49],((C_word*)t0)[2]);}}

/* k837 in k834 */
static void f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_739(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_856 in k949 in k945 in k941 in k937 in k933 in k929 in k925 in k921 in k917 in k913 in k909 in k905 in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_856,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_860,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k858 */
static void f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[45],lf[46],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_863(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[45],lf[47],((C_word*)t0)[2]);}}}

/* k861 in k858 */
static void f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_736(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_887(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_887,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_889,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_889 in setf in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_889,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_893,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k891 */
static void f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_900(2,t3,((C_word*)t0)[2]);}
else{
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k898 in k891 */
static void f_900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_810(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_810,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_812,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));}

/* f_812 in setu in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_812,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_816,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k814 */
static void f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(0)))){
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[32],((C_word*)t0)[3]);}
else{
t3=t2;
f_819(2,t3,C_SCHEME_UNDEFINED);}}

/* k817 in k814 */
static void f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_799(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_799,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_801,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_801 in set in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_801,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_805,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k803 */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void C_fcall f_788(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_788,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_790,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_790 in get in k784 in k780 in k776 in k772 in k768 in k764 in k760 in k756 */
static void f_790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_790,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_794,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k792 */
static void f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_748(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_748,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_750 in len */
static void f_750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_750,3,t0,t1,t2);}
t3=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t3,((C_word*)t0)[2]):t3));}

/* ##sys#f64vector-set! */
static void f_745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_745,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void f_742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_742,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_739(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_736(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void f_733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_733,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_730,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_727,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void f_724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_724,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void f_718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_718,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void f_712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_712,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void f_709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_709,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_706,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void f_703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_703,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void f_700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_700,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void f_697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_697,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void f_694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_694,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void f_676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_676,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_lessp(t2,t3);
t7=(C_truep(t6)?t6:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t7)){
t8=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[6],t2,t3,t4);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void f_664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_664,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fixnum_lessp(t2,t3);
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t7)){
t8=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t8+1)))(7,t8,t1,t5,lf[4],t2,t3,t4);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}
/* end of file */
