/* Generated from match-support.scm by the Chicken compiler
   2005-08-24 19:35
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: match-support.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file match-support.c -explicit-use
   unit: match_support
*/

#include "chicken.h"


static C_TLS C_word lf[245];


C_externexport void C_match_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_7257(C_word c,C_word t0,C_word t1) C_noret;
static void f_7240(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7240r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7227(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_7186(C_word t0);
static void f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_909(C_word c,C_word t0,C_word t1) C_noret;
static void f_912(C_word c,C_word t0,C_word t1) C_noret;
static void f_1079(C_word c,C_word t0,C_word t1) C_noret;
static void f_915(C_word c,C_word t0,C_word t1) C_noret;
static void f_927(C_word c,C_word t0,C_word t1) C_noret;
static void f_933(C_word c,C_word t0,C_word t1) C_noret;
static void f_1071(C_word c,C_word t0,C_word t1) C_noret;
static void f_936(C_word c,C_word t0,C_word t1) C_noret;
static void f_1059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_939(C_word c,C_word t0,C_word t1) C_noret;
static void f_942(C_word c,C_word t0,C_word t1) C_noret;
static void f_1053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_953(C_word c,C_word t0,C_word t1) C_noret;
static void f_1023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1013(C_word c,C_word t0,C_word t1) C_noret;
static void f_1009(C_word c,C_word t0,C_word t1) C_noret;
static void f_1005(C_word c,C_word t0,C_word t1) C_noret;
static void f_1001(C_word c,C_word t0,C_word t1) C_noret;
static void f_993(C_word c,C_word t0,C_word t1) C_noret;
static void f_985(C_word c,C_word t0,C_word t1) C_noret;
static void f_977(C_word c,C_word t0,C_word t1) C_noret;
static void f_969(C_word c,C_word t0,C_word t1) C_noret;
static void f_961(C_word c,C_word t0,C_word t1) C_noret;
static void f_949(C_word c,C_word t0,C_word t1) C_noret;
static void f_749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_753(C_word c,C_word t0,C_word t1) C_noret;
static void f_756(C_word c,C_word t0,C_word t1) C_noret;
static void f_903(C_word c,C_word t0,C_word t1) C_noret;
static void f_759(C_word c,C_word t0,C_word t1) C_noret;
static void f_771(C_word c,C_word t0,C_word t1) C_noret;
static void f_777(C_word c,C_word t0,C_word t1) C_noret;
static void f_895(C_word c,C_word t0,C_word t1) C_noret;
static void f_780(C_word c,C_word t0,C_word t1) C_noret;
static void f_883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_783(C_word c,C_word t0,C_word t1) C_noret;
static void f_786(C_word c,C_word t0,C_word t1) C_noret;
static void f_853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_845(C_word c,C_word t0,C_word t1) C_noret;
static void f_841(C_word c,C_word t0,C_word t1) C_noret;
static void f_837(C_word c,C_word t0,C_word t1) C_noret;
static void f_833(C_word c,C_word t0,C_word t1) C_noret;
static void f_825(C_word c,C_word t0,C_word t1) C_noret;
static void f_817(C_word c,C_word t0,C_word t1) C_noret;
static void f_809(C_word c,C_word t0,C_word t1) C_noret;
static void f_801(C_word c,C_word t0,C_word t1) C_noret;
static void f_793(C_word c,C_word t0,C_word t1) C_noret;
static void f_537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_541(C_word c,C_word t0,C_word t1) C_noret;
static void f_544(C_word c,C_word t0,C_word t1) C_noret;
static void f_605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_743(C_word c,C_word t0,C_word t1) C_noret;
static void f_609(C_word c,C_word t0,C_word t1) C_noret;
static void f_621(C_word c,C_word t0,C_word t1) C_noret;
static void f_731(C_word c,C_word t0,C_word t1) C_noret;
static void f_727(C_word c,C_word t0,C_word t1) C_noret;
static void f_723(C_word c,C_word t0,C_word t1) C_noret;
static void f_719(C_word c,C_word t0,C_word t1) C_noret;
static void f_624(C_word c,C_word t0,C_word t1) C_noret;
static void f_660(C_word c,C_word t0,C_word t1) C_noret;
static void f_656(C_word c,C_word t0,C_word t1) C_noret;
static void f_652(C_word c,C_word t0,C_word t1) C_noret;
static void f_641(C_word c,C_word t0,C_word t1) C_noret;
static void f_550(C_word c,C_word t0,C_word t1) C_noret;
static void f_603(C_word c,C_word t0,C_word t1) C_noret;
static void f_553(C_word c,C_word t0,C_word t1) C_noret;
static void f_556(C_word c,C_word t0,C_word t1) C_noret;
static void f_567(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1175(C_word t0,C_word t1) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1) C_noret;
static void f_1215(C_word c,C_word t0,C_word t1) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1253(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2328(C_word c,C_word t0,C_word t1) C_noret;
static void f_2332(C_word c,C_word t0,C_word t1) C_noret;
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2264(C_word c,C_word t0,C_word t1) C_noret;
static void f_2267(C_word c,C_word t0,C_word t1) C_noret;
static void f_2277(C_word c,C_word t0,C_word t1) C_noret;
static void f_2292(C_word c,C_word t0,C_word t1) C_noret;
static void f_2274(C_word c,C_word t0,C_word t1) C_noret;
static void f_2247(C_word c,C_word t0,C_word t1) C_noret;
static void f_2243(C_word c,C_word t0,C_word t1) C_noret;
static void f_2239(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2130(C_word t0,C_word t1) C_noret;
static void f_2202(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2169(C_word t0,C_word t1) C_noret;
static void f_2182(C_word c,C_word t0,C_word t1) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1) C_noret;
static void f_2155(C_word c,C_word t0,C_word t1) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void f_2139(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2093(C_word t0,C_word t1) C_noret;
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2056(C_word c,C_word t0,C_word t1) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1348(C_word c,C_word t0,C_word t1) C_noret;
static void f_1992(C_word c,C_word t0,C_word t1) C_noret;
static void f_1995(C_word c,C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void f_2020(C_word c,C_word t0,C_word t1) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1) C_noret;
static void f_1920(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1887(C_word t0,C_word t1) C_noret;
static void f_1900(C_word c,C_word t0,C_word t1) C_noret;
static void f_1832(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1812(C_word t0,C_word t1) C_noret;
static void f_1785(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1765(C_word t0,C_word t1) C_noret;
static void C_fcall f_1701(C_word t0,C_word t1) C_noret;
static void f_1718(C_word c,C_word t0,C_word t1) C_noret;
static void f_1714(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
static void f_1664(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
static void f_1617(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1560(C_word t0,C_word t1) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1500(C_word t0,C_word t1) C_noret;
static void f_1513(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1446(C_word t0,C_word t1) C_noret;
static void f_1463(C_word c,C_word t0,C_word t1) C_noret;
static void f_1459(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1409(C_word t0,C_word t1) C_noret;
static void C_fcall f_1366(C_word t0,C_word t1) C_noret;
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1326(C_word c,C_word t0,C_word t1) C_noret;
static void f_1330(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1286(C_word t0);
static void f_1081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1105(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3242(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3113(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3067(C_word t0,C_word t1) C_noret;
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3051(C_word t0,C_word t1) C_noret;
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2390(C_word t0,C_word t1) C_noret;
static void C_fcall f_2399(C_word t0,C_word t1) C_noret;
static void C_fcall f_2491(C_word t0,C_word t1) C_noret;
static void C_fcall f_2568(C_word t0,C_word t1) C_noret;
static void C_fcall f_2591(C_word t0,C_word t1) C_noret;
static void C_fcall f_2680(C_word t0,C_word t1) C_noret;
static void f_2745(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2793(C_word t0,C_word t1) C_noret;
static void C_fcall f_2824(C_word t0,C_word t1) C_noret;
static void C_fcall f_2854(C_word t0,C_word t1) C_noret;
static void f_2924(C_word c,C_word t0,C_word t1) C_noret;
static void f_2926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2934(C_word c,C_word t0,C_word t1) C_noret;
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2814(C_word c,C_word t0,C_word t1) C_noret;
static void f_2810(C_word c,C_word t0,C_word t1) C_noret;
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2758(C_word c,C_word t0,C_word t1) C_noret;
static void f_2773(C_word c,C_word t0,C_word t1) C_noret;
static void f_2777(C_word c,C_word t0,C_word t1) C_noret;
static void f_2783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2781(C_word c,C_word t0,C_word t1) C_noret;
static void f_2697(C_word c,C_word t0,C_word t1) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2731(C_word c,C_word t0,C_word t1) C_noret;
static void f_2714(C_word c,C_word t0,C_word t1) C_noret;
static void f_2600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2674(C_word c,C_word t0,C_word t1) C_noret;
static void f_2647(C_word c,C_word t0,C_word t1) C_noret;
static void f_2656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2622(C_word c,C_word t0,C_word t1) C_noret;
static void f_2618(C_word c,C_word t0,C_word t1) C_noret;
static void f_2577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2500(C_word t0,C_word t1) C_noret;
static void f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2503(C_word c,C_word t0,C_word t1) C_noret;
static void f_2416(C_word c,C_word t0,C_word t1) C_noret;
static void f_2412(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2437(C_word t0,C_word t1) C_noret;
static void f_2440(C_word c,C_word t0,C_word t1) C_noret;
static void f_2371(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3199(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3205(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3244(C_word t0,C_word t1) C_noret;
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3533(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3267(C_word c,C_word t0,C_word t1) C_noret;
static void f_3271(C_word c,C_word t0,C_word t1) C_noret;
static void f_3536(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3558(C_word t0,C_word t1) C_noret;
static void C_fcall f_3293(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3307(C_word c,C_word t0,C_word t1) C_noret;
static void f_3311(C_word c,C_word t0,C_word t1) C_noret;
static void f_3569(C_word c,C_word t0,C_word t1) C_noret;
static void f_3524(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3431(C_word t0,C_word t1);
static C_word C_fcall f_3409(C_word t0,C_word t1);
static C_word C_fcall f_3327(C_word t0);
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void f_3753(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_3866(C_word t0,C_word t1) C_noret;
static void C_fcall f_3879(C_word t0,C_word t1) C_noret;
static void C_fcall f_3895(C_word t0,C_word t1) C_noret;
static void C_fcall f_3916(C_word t0,C_word t1) C_noret;
static void C_fcall f_3958(C_word t0,C_word t1) C_noret;
static void C_fcall f_4001(C_word t0,C_word t1) C_noret;
static void C_fcall f_4014(C_word t0,C_word t1) C_noret;
static void C_fcall f_4076(C_word t0,C_word t1) C_noret;
static void C_fcall f_4101(C_word t0,C_word t1) C_noret;
static void f_4126(C_word c,C_word t0,C_word t1) C_noret;
static void f_4465(C_word c,C_word t0,C_word t1) C_noret;
static void f_4755(C_word c,C_word t0,C_word t1) C_noret;
static void f_4758(C_word c,C_word t0,C_word t1) C_noret;
static void f_4703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4744(C_word c,C_word t0,C_word t1) C_noret;
static void f_4715(C_word c,C_word t0,C_word t1) C_noret;
static void f_4471(C_word c,C_word t0,C_word t1) C_noret;
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4498(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4531(C_word c,C_word t0,C_word t1) C_noret;
static void f_4619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4645(C_word c,C_word t0,C_word t1) C_noret;
static void f_4635(C_word c,C_word t0,C_word t1) C_noret;
static void f_4627(C_word c,C_word t0,C_word t1) C_noret;
static void f_4556(C_word c,C_word t0,C_word t1) C_noret;
static void f_4609(C_word c,C_word t0,C_word t1) C_noret;
static void f_4560(C_word c,C_word t0,C_word t1) C_noret;
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4587(C_word c,C_word t0,C_word t1) C_noret;
static void f_4567(C_word c,C_word t0,C_word t1) C_noret;
static void f_4579(C_word c,C_word t0,C_word t1) C_noret;
static void f_4505(C_word c,C_word t0,C_word t1) C_noret;
static void f_4502(C_word c,C_word t0,C_word t1) C_noret;
static void f_4433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4445(C_word c,C_word t0,C_word t1) C_noret;
static void f_4447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4459(C_word c,C_word t0,C_word t1) C_noret;
static void f_4135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4139(C_word c,C_word t0,C_word t1) C_noret;
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4249(C_word t0,C_word t1) C_noret;
static void f_4333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4359(C_word c,C_word t0,C_word t1) C_noret;
static void f_4349(C_word c,C_word t0,C_word t1) C_noret;
static void f_4341(C_word c,C_word t0,C_word t1) C_noret;
static void f_4268(C_word c,C_word t0,C_word t1) C_noret;
static void f_4319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4317(C_word c,C_word t0,C_word t1) C_noret;
static void f_4313(C_word c,C_word t0,C_word t1) C_noret;
static void f_4272(C_word c,C_word t0,C_word t1) C_noret;
static void f_4301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4299(C_word c,C_word t0,C_word t1) C_noret;
static void f_4279(C_word c,C_word t0,C_word t1) C_noret;
static void f_4291(C_word c,C_word t0,C_word t1) C_noret;
static void f_4242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4162(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4183(C_word t0,C_word t1) C_noret;
static void C_fcall f_4165(C_word t0,C_word t1) C_noret;
static void f_4176(C_word c,C_word t0,C_word t1) C_noret;
static void f_4180(C_word c,C_word t0,C_word t1) C_noret;
static void f_4120(C_word c,C_word t0,C_word t1) C_noret;
static void f_4095(C_word c,C_word t0,C_word t1) C_noret;
static void f_4070(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4062(C_word c,C_word t0,C_word t1) C_noret;
static void f_4033(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3726(C_word c,C_word t0,C_word t1) C_noret;
static void f_3719(C_word c,C_word t0,C_word t1) C_noret;
static void f_3715(C_word c,C_word t0,C_word t1) C_noret;
static void f_3676(C_word c,C_word t0,C_word t1) C_noret;
static void f_3711(C_word c,C_word t0,C_word t1) C_noret;
static void f_3648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1107(C_word t0,C_word t1) C_noret;
static void f_1123(C_word c,C_word t0,C_word t1) C_noret;
static void f_1165(C_word c,C_word t0,C_word t1) C_noret;
static void f_1161(C_word c,C_word t0,C_word t1) C_noret;
static void f_1150(C_word c,C_word t0,C_word t1) C_noret;
static void f_1157(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4908(C_word c,C_word t0,C_word t1) C_noret;
static void f_4917(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5039(C_word t0,C_word t1) C_noret;
static void C_fcall f_4926(C_word t0,C_word t1) C_noret;
static void C_fcall f_4932(C_word t0,C_word t1) C_noret;
static void f_4961(C_word c,C_word t0,C_word t1) C_noret;
static void f_4935(C_word c,C_word t0,C_word t1) C_noret;
static void f_4953(C_word c,C_word t0,C_word t1) C_noret;
static void f_4938(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5102(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5108(C_word t0,C_word t1) C_noret;
static void f_5907(C_word c,C_word t0,C_word t1) C_noret;
static void f_5903(C_word c,C_word t0,C_word t1) C_noret;
static void f_5899(C_word c,C_word t0,C_word t1) C_noret;
static void f_5895(C_word c,C_word t0,C_word t1) C_noret;
static void f_5887(C_word c,C_word t0,C_word t1) C_noret;
static void f_5883(C_word c,C_word t0,C_word t1) C_noret;
static void f_5875(C_word c,C_word t0,C_word t1) C_noret;
static void f_5871(C_word c,C_word t0,C_word t1) C_noret;
static void f_5867(C_word c,C_word t0,C_word t1) C_noret;
static void f_5863(C_word c,C_word t0,C_word t1) C_noret;
static void f_5859(C_word c,C_word t0,C_word t1) C_noret;
static void f_5855(C_word c,C_word t0,C_word t1) C_noret;
static void f_5851(C_word c,C_word t0,C_word t1) C_noret;
static void f_5847(C_word c,C_word t0,C_word t1) C_noret;
static void f_5843(C_word c,C_word t0,C_word t1) C_noret;
static void f_5839(C_word c,C_word t0,C_word t1) C_noret;
static void f_5831(C_word c,C_word t0,C_word t1) C_noret;
static void f_5827(C_word c,C_word t0,C_word t1) C_noret;
static void f_5819(C_word c,C_word t0,C_word t1) C_noret;
static void f_5815(C_word c,C_word t0,C_word t1) C_noret;
static void f_5811(C_word c,C_word t0,C_word t1) C_noret;
static void f_5807(C_word c,C_word t0,C_word t1) C_noret;
static void f_5803(C_word c,C_word t0,C_word t1) C_noret;
static void f_5799(C_word c,C_word t0,C_word t1) C_noret;
static void f_5795(C_word c,C_word t0,C_word t1) C_noret;
static void f_5791(C_word c,C_word t0,C_word t1) C_noret;
static void f_5787(C_word c,C_word t0,C_word t1) C_noret;
static void f_5783(C_word c,C_word t0,C_word t1) C_noret;
static void f_5779(C_word c,C_word t0,C_word t1) C_noret;
static void f_5775(C_word c,C_word t0,C_word t1) C_noret;
static void f_5771(C_word c,C_word t0,C_word t1) C_noret;
static void f_5767(C_word c,C_word t0,C_word t1) C_noret;
static void f_5763(C_word c,C_word t0,C_word t1) C_noret;
static void f_5755(C_word c,C_word t0,C_word t1) C_noret;
static void f_5751(C_word c,C_word t0,C_word t1) C_noret;
static void f_5747(C_word c,C_word t0,C_word t1) C_noret;
static void f_5743(C_word c,C_word t0,C_word t1) C_noret;
static void f_5739(C_word c,C_word t0,C_word t1) C_noret;
static void f_5735(C_word c,C_word t0,C_word t1) C_noret;
static void f_5731(C_word c,C_word t0,C_word t1) C_noret;
static void f_5727(C_word c,C_word t0,C_word t1) C_noret;
static void f_5723(C_word c,C_word t0,C_word t1) C_noret;
static void f_5719(C_word c,C_word t0,C_word t1) C_noret;
static void f_5715(C_word c,C_word t0,C_word t1) C_noret;
static void f_5707(C_word c,C_word t0,C_word t1) C_noret;
static void f_5703(C_word c,C_word t0,C_word t1) C_noret;
static void f_5695(C_word c,C_word t0,C_word t1) C_noret;
static void f_5691(C_word c,C_word t0,C_word t1) C_noret;
static void f_5687(C_word c,C_word t0,C_word t1) C_noret;
static void f_5683(C_word c,C_word t0,C_word t1) C_noret;
static void f_5679(C_word c,C_word t0,C_word t1) C_noret;
static void f_5675(C_word c,C_word t0,C_word t1) C_noret;
static void f_5671(C_word c,C_word t0,C_word t1) C_noret;
static void f_5659(C_word c,C_word t0,C_word t1) C_noret;
static void f_5655(C_word c,C_word t0,C_word t1) C_noret;
static void f_5651(C_word c,C_word t0,C_word t1) C_noret;
static void f_5647(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5166(C_word t0,C_word t1) C_noret;
static void f_5230(C_word c,C_word t0,C_word t1) C_noret;
static void f_5226(C_word c,C_word t0,C_word t1) C_noret;
static void f_5222(C_word c,C_word t0,C_word t1) C_noret;
static void f_5218(C_word c,C_word t0,C_word t1) C_noret;
static void f_5175(C_word c,C_word t0,C_word t1) C_noret;
static void f_5198(C_word c,C_word t0,C_word t1) C_noret;
static void f_5129(C_word c,C_word t0,C_word t1) C_noret;
static void f_5121(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5981(C_word c,C_word t0,C_word t1) C_noret;
static void f_5984(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5989(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6056(C_word t0,C_word t1) C_noret;
static void f_6059(C_word c,C_word t0,C_word t1) C_noret;
static void f_6020(C_word c,C_word t0,C_word t1) C_noret;
static void f_6029(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6118(C_word t0,C_word t1) C_noret;
static void f_6133(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6338(C_word t0,C_word t1) C_noret;
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6272(C_word t0,C_word t1) C_noret;
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6154(C_word t0,C_word t1) C_noret;
static void f_6185(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6166(C_word t0,C_word t1) C_noret;
static void C_fcall f_6418(C_word t0,C_word t1) C_noret;
static void C_fcall f_6458(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_6504(C_word t0);
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6518(C_word t0,C_word t1) C_noret;
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6551(C_word t0,C_word t1) C_noret;
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6836(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6775(C_word t0,C_word t1) C_noret;
static void f_6801(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7055(C_word t0,C_word t1) C_noret;
static void C_fcall f_7151(C_word t0,C_word t1) C_noret;
static void f_7165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7163(C_word c,C_word t0,C_word t1) C_noret;
static void f_7159(C_word c,C_word t0,C_word t1) C_noret;
static void f_528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

static void C_fcall trf_7209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7209(t0,t1,t2);}

static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1175(t0,t1);}

static void C_fcall trf_1253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1253(t0,t1,t2);}

static void C_fcall trf_1283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1283(t0,t1,t2);}

static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2308(t0,t1,t2);}

static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2130(t0,t1);}

static void C_fcall trf_2169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2169(t0,t1);}

static void C_fcall trf_2093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2093(t0,t1);}

static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2048(t0,t1,t2,t3);}

static void C_fcall trf_1887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1887(t0,t1);}

static void C_fcall trf_1812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1812(t0,t1);}

static void C_fcall trf_1765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1765(t0,t1);}

static void C_fcall trf_1701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1701(t0,t1);}

static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

static void C_fcall trf_1560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1560(t0,t1);}

static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1500(t0,t1);}

static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1446(t0,t1);}

static void C_fcall trf_1409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1409(t0,t1);}

static void C_fcall trf_1366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1366(t0,t1);}

static void C_fcall trf_1318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1318(t0,t1,t2,t3);}

static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2348(t0,t1,t2);}

static void C_fcall trf_3142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3142(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3142(t0,t1,t2,t3,t4);}

static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3049(t0,t1,t2,t3,t4);}

static void C_fcall trf_3067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3067(t0,t1);}

static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3051(t0,t1);}

static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2352(t0,t1,t2,t3,t4);}

static void C_fcall trf_2390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2390(t0,t1);}

static void C_fcall trf_2399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2399(t0,t1);}

static void C_fcall trf_2491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2491(t0,t1);}

static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2568(t0,t1);}

static void C_fcall trf_2591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2591(t0,t1);}

static void C_fcall trf_2680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2680(t0,t1);}

static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2793(t0,t1);}

static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2824(t0,t1);}

static void C_fcall trf_2854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2854(t0,t1);}

static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2624(t0,t1,t2,t3);}

static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2500(t0,t1);}

static void C_fcall trf_2437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2437(t0,t1);}

static void C_fcall trf_3181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3181(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3181(t0,t1,t2,t3);}

static void C_fcall trf_3205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3205(t0,t1,t2);}

static void C_fcall trf_3244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3244(t0,t1);}

static void C_fcall trf_3504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3504(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3504(t0,t1,t2,t3,t4);}

static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3253(t0,t1,t2);}

static void C_fcall trf_3558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3558(t0,t1);}

static void C_fcall trf_3293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3293(t0,t1,t2);}

static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3628(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_3755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3755(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3755(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_3866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3866(t0,t1);}

static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3879(t0,t1);}

static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3895(t0,t1);}

static void C_fcall trf_3916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3916(t0,t1);}

static void C_fcall trf_3958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3958(t0,t1);}

static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4001(t0,t1);}

static void C_fcall trf_4014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4014(t0,t1);}

static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4076(t0,t1);}

static void C_fcall trf_4101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4101(t0,t1);}

static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4717(t0,t1,t2);}

static void C_fcall trf_4507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4507(t0,t1,t2);}

static void C_fcall trf_4249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4249(t0,t1);}

static void C_fcall trf_4183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4183(t0,t1);}

static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4165(t0,t1);}

static void C_fcall trf_4035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4035(t0,t1,t2);}

static void C_fcall trf_3967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3967(t0,t1,t2,t3);}

static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3925(t0,t1,t2,t3);}

static void C_fcall trf_1107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1107(t0,t1);}

static void C_fcall trf_4901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4901(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4901(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5039(t0,t1);}

static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4926(t0,t1);}

static void C_fcall trf_4932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4932(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4932(t0,t1);}

static void C_fcall trf_5083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5083(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5083(t0,t1,t2,t3,t4);}

static void C_fcall trf_5108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5108(t0,t1);}

static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5166(t0,t1);}

static void C_fcall trf_5977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5977(t0,t1,t2,t3);}

static void C_fcall trf_5989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5989(t0,t1,t2);}

static void C_fcall trf_6056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6056(t0,t1);}

static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6108(t0,t1,t2,t3);}

static void C_fcall trf_6118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6118(t0,t1);}

static void C_fcall trf_6325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6325(t0,t1,t2);}

static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6338(t0,t1);}

static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6259(t0,t1,t2);}

static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6272(t0,t1);}

static void C_fcall trf_6141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6141(t0,t1,t2);}

static void C_fcall trf_6154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6154(t0,t1);}

static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6166(t0,t1);}

static void C_fcall trf_6418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6418(t0,t1);}

static void C_fcall trf_6458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6458(t0,t1);}

static void C_fcall trf_6514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6514(t0,t1,t2);}

static void C_fcall trf_6518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6518(t0,t1);}

static void C_fcall trf_6547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6547(t0,t1,t2);}

static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6551(t0,t1);}

static void C_fcall trf_6581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6581(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6581(t0,t1,t2,t3);}

static void C_fcall trf_6775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6775(t0,t1);}

static void C_fcall trf_6583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6583(t0,t1,t2);}

static void C_fcall trf_6886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6886(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6886(t0,t1,t2,t3);}

static void C_fcall trf_7055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7055(t0,t1);}

static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7151(t0,t1);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_match_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_match_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("match_support_toplevel"));
C_check_nursery_minimum(152);
if(!C_demand(152)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2937)){
C_save(t1);
C_rereclaim2(2937*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(152);
C_initialize_lf(lf,245);
lf[0]=C_h_intern(&lf[0],13,"\005matchversion");
lf[1]=C_static_string(C_heaptop,42,"Version 1.18, July 17, 1995 (Chicken port)");
lf[2]=C_h_intern(&lf[2],16,"\005matchsyntax-err");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],13,"\000syntax-error");
lf[5]=C_static_lambda_info(C_heaptop,30,"(##match#syntax-err obj2 msg3)");
lf[6]=C_h_intern(&lf[6],15,"\005matchset-error");
lf[7]=C_h_intern(&lf[7],15,"\003sysmatch-error");
lf[8]=C_static_lambda_info(C_heaptop,22,"(##match#set-error v4)");
lf[9]=C_h_intern(&lf[9],19,"\005matcherror-control");
lf[10]=C_h_intern(&lf[10],6,"\000error");
lf[11]=C_h_intern(&lf[11],23,"\005matchset-error-control");
lf[12]=C_static_lambda_info(C_heaptop,30,"(##match#set-error-control v5)");
lf[13]=C_h_intern(&lf[13],4,"null");
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"symbol\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"boolean\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"number\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"string\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"char\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"procedure\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"vector\077");
C_save(tmp);
lf[14]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[15]=C_h_intern(&lf[15],25,"\005matchdisjoint-predicates");
lf[16]=C_h_intern(&lf[16],14,"string->symbol");
lf[17]=C_h_intern(&lf[17],13,"string-append");
lf[18]=C_h_intern(&lf[18],14,"symbol->string");
lf[19]=C_static_lambda_info(C_heaptop,12,"(a7164 x473)");
lf[20]=C_h_intern(&lf[20],7,"\003sysmap");
lf[21]=C_static_lambda_info(C_heaptop,20,"(symbol-append l472)");
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[22]=C_h_list(28,C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(28);
lf[23]=C_h_intern(&lf[23],10,"vector-ref");
lf[24]=C_h_intern(&lf[24],1,"x");
lf[25]=C_h_intern(&lf[25],6,"lambda");
lf[26]=C_h_intern(&lf[26],3,"let");
lf[27]=C_h_intern(&lf[27],5,"unbox");
lf[28]=C_h_intern(&lf[28],3,"car");
lf[29]=C_h_intern(&lf[29],3,"cdr");
lf[30]=C_h_intern(&lf[30],13,"\003sysblock-ref");
lf[31]=C_static_string(C_heaptop,21,"unnested get! pattern");
lf[32]=C_static_lambda_info(C_heaptop,18,"(getter e467 p468)");
lf[33]=C_h_intern(&lf[33],4,"set-");
lf[34]=C_h_intern(&lf[34],1,"!");
lf[35]=C_static_lambda_info(C_heaptop,16,"(mk-setter s463)");
lf[36]=C_h_intern(&lf[36],1,"y");
lf[37]=C_h_intern(&lf[37],11,"vector-set!");
lf[38]=C_h_intern(&lf[38],8,"set-box!");
lf[39]=C_h_intern(&lf[39],8,"set-car!");
lf[40]=C_h_intern(&lf[40],8,"set-cdr!");
lf[41]=C_h_intern(&lf[41],14,"\003sysblock-set!");
lf[42]=C_static_string(C_heaptop,21,"unnested set! pattern");
lf[43]=C_static_lambda_info(C_heaptop,18,"(setter e460 p461)");
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[44]=C_h_list(14,C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(14);
lf[45]=C_static_lambda_info(C_heaptop,12,"(add-d a458)");
lf[46]=C_static_lambda_info(C_heaptop,12,"(add-a a456)");
lf[47]=C_static_lambda_info(C_heaptop,11,"(disjoint\077)");
lf[48]=C_h_intern(&lf[48],6,"equal\077");
lf[49]=C_h_intern(&lf[49],7,"string\077");
lf[50]=C_h_intern(&lf[50],8,"boolean\077");
lf[51]=C_h_intern(&lf[51],5,"char\077");
lf[52]=C_h_intern(&lf[52],7,"number\077");
lf[53]=C_h_intern(&lf[53],7,"symbol\077");
lf[54]=C_h_intern(&lf[54],5,"quote");
lf[55]=C_static_lambda_info(C_heaptop,20,"(equal-test\077 tst453)");
lf[56]=C_h_intern(&lf[56],3,"not");
lf[57]=C_static_lambda_info(C_heaptop,10,"(mem l432)");
lf[58]=C_static_lambda_info(C_heaptop,10,"(mem l442)");
lf[59]=C_h_intern(&lf[59],5,"list\077");
tmp=C_intern(C_heaptop,5,"list\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"null\077");
C_save(tmp);
lf[60]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[61]=C_static_lambda_info(C_heaptop,10,"(mem l448)");
lf[62]=C_h_intern(&lf[62],5,"null\077");
lf[63]=C_h_intern(&lf[63],5,"pair\077");
lf[64]=C_static_lambda_info(C_heaptop,14,"(in e421 l422)");
lf[65]=C_h_intern(&lf[65],4,"cond");
lf[66]=C_h_intern(&lf[66],2,"if");
lf[67]=C_static_lambda_info(C_heaptop,14,"(loop code413)");
lf[68]=C_static_lambda_info(C_heaptop,25,"(guarantees code408 x409)");
lf[69]=C_h_intern(&lf[69],3,"and");
lf[70]=C_h_intern(&lf[70],8,"\003syscons");
lf[71]=C_h_intern(&lf[71],30,"call-with-current-continuation");
lf[72]=C_h_intern(&lf[72],6,"caddar");
lf[73]=C_h_intern(&lf[73],6,"cddadr");
lf[74]=C_h_intern(&lf[74],6,"caadar");
lf[75]=C_h_intern(&lf[75],6,"cadadr");
lf[76]=C_h_intern(&lf[76],5,"cadar");
lf[77]=C_h_intern(&lf[77],6,"cdddar");
lf[78]=C_h_intern(&lf[78],5,"cddar");
lf[79]=C_h_intern(&lf[79],6,"cdadar");
lf[80]=C_h_intern(&lf[80],4,"cdar");
lf[81]=C_h_intern(&lf[81],5,"cdadr");
lf[82]=C_h_intern(&lf[82],5,"caadr");
lf[83]=C_h_intern(&lf[83],4,"caar");
lf[84]=C_h_intern(&lf[84],12,"\000unspecified");
lf[85]=C_h_intern(&lf[85],5,"\000fail");
lf[86]=C_static_lambda_info(C_heaptop,23,"(assm tst400 f401 s402)");
lf[87]=C_h_intern(&lf[87],6,"append");
lf[88]=C_static_lambda_info(C_heaptop,31,"(emit tst388 sf389 kf390 ks391)");
lf[89]=C_h_intern(&lf[89],3,"...");
lf[90]=C_h_intern(&lf[90],3,"___");
lf[91]=C_h_intern(&lf[91],9,"substring");
lf[92]=C_h_intern(&lf[92],6,"andmap");
lf[93]=C_h_intern(&lf[93],13,"char-numeric\077");
lf[94]=C_h_intern(&lf[94],12,"string->list");
lf[95]=C_static_lambda_info(C_heaptop,16,"(dot-dot-k\077 s91)");
lf[96]=C_static_lambda_info(C_heaptop,10,"(val x298)");
lf[97]=C_static_lambda_info(C_heaptop,12,"(fail sf300)");
lf[98]=C_static_lambda_info(C_heaptop,15,"(success sf302)");
lf[99]=C_h_intern(&lf[99],1,"_");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
lf[100]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[101]=C_static_lambda_info(C_heaptop,13,"(a3943 sf319)");
lf[102]=C_static_lambda_info(C_heaptop,17,"(loop p317 sf318)");
lf[103]=C_static_lambda_info(C_heaptop,13,"(a3986 sf325)");
lf[104]=C_static_lambda_info(C_heaptop,17,"(loop p323 sf324)");
lf[105]=C_static_lambda_info(C_heaptop,14,"(f_4037 sf334)");
lf[106]=C_static_lambda_info(C_heaptop,12,"(rloop n333)");
lf[107]=C_h_intern(&lf[107],1,"\077");
lf[108]=C_static_lambda_info(C_heaptop,13,"(a4238 sf344)");
lf[109]=C_static_lambda_info(C_heaptop,13,"(a4241 sf345)");
lf[110]=C_static_lambda_info(C_heaptop,12,"(a4300 x355)");
lf[111]=C_h_intern(&lf[111],3,"map");
lf[112]=C_h_intern(&lf[112],4,"cons");
lf[113]=C_h_intern(&lf[113],7,"reverse");
lf[114]=C_static_lambda_info(C_heaptop,12,"(a4318 x354)");
lf[115]=C_static_lambda_info(C_heaptop,17,"(a4350 b352 f353)");
lf[116]=C_static_lambda_info(C_heaptop,13,"(a4332 sf351)");
lf[117]=C_static_lambda_info(C_heaptop,10,"(ks sf341)");
lf[118]=C_static_lambda_info(C_heaptop,13,"(a4134 sf338)");
lf[119]=C_static_lambda_info(C_heaptop,13,"(a4446 sf360)");
lf[120]=C_static_lambda_info(C_heaptop,13,"(a4432 sf359)");
lf[121]=C_h_intern(&lf[121],7,"vector\077");
lf[122]=C_h_intern(&lf[122],13,"vector-length");
lf[123]=C_h_intern(&lf[123],2,">=");
lf[124]=C_h_intern(&lf[124],1,">");
lf[125]=C_h_intern(&lf[125],1,"-");
lf[126]=C_static_lambda_info(C_heaptop,12,"(a4588 x376)");
lf[127]=C_static_lambda_info(C_heaptop,17,"(a4636 b374 f375)");
lf[128]=C_static_lambda_info(C_heaptop,13,"(a4618 sf373)");
lf[129]=C_static_lambda_info(C_heaptop,14,"(f_4509 sf368)");
lf[130]=C_static_lambda_info(C_heaptop,12,"(vloop n367)");
lf[131]=C_static_lambda_info(C_heaptop,13,"(a4485 sf365)");
lf[132]=C_static_lambda_info(C_heaptop,14,"(f_4719 sf383)");
lf[133]=C_static_lambda_info(C_heaptop,12,"(vloop n382)");
lf[134]=C_static_lambda_info(C_heaptop,13,"(a4702 sf380)");
lf[135]=C_h_intern(&lf[135],9,"\003syserror");
lf[136]=C_static_string(C_heaptop,18,"THIS NEVER HAPPENS");
lf[137]=C_h_intern(&lf[137],7,"newline");
lf[138]=C_h_intern(&lf[138],7,"display");
lf[139]=C_static_string(C_heaptop,30,"FATAL ERROR IN PATTERN MATCHER");
lf[140]=C_h_intern(&lf[140],4,"get!");
lf[141]=C_h_intern(&lf[141],4,"set!");
lf[142]=C_h_intern(&lf[142],1,"$");
lf[143]=C_h_intern(&lf[143],2,"or");
lf[144]=C_h_intern(&lf[144],1,"=");
lf[145]=C_static_lambda_info(C_heaptop,34,"(next p309 e310 sf311 kf312 ks313)");
lf[146]=C_static_lambda_info(C_heaptop,54,"(gen x290 sf291 plist292 erract293 length>=294 eta295)");
lf[147]=C_static_lambda_info(C_heaptop,8,"(const\077)");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"match-lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-lambda*");
C_save(tmp);
lf[148]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[149]=C_static_lambda_info(C_heaptop,8,"(isval\077)");
lf[150]=C_static_lambda_info(C_heaptop,8,"(small\077)");
lf[151]=C_static_lambda_info(C_heaptop,11,"(loop e255)");
lf[152]=C_static_lambda_info(C_heaptop,11,"(loop e249)");
lf[153]=C_static_lambda_info(C_heaptop,25,"(loop b277 new-b278 e279)");
lf[154]=C_static_lambda_info(C_heaptop,23,"(inline-let let-exp240)");
lf[155]=C_static_lambda_info(C_heaptop,13,"(a3216 x1231)");
lf[156]=C_static_lambda_info(C_heaptop,25,"(permutation p1229 p2230)");
lf[157]=C_static_lambda_info(C_heaptop,23,"(find-prefix b227 a228)");
lf[158]=C_static_string(C_heaptop,29,"duplicate variable in pattern");
lf[159]=C_h_intern(&lf[159],6,"gensym");
lf[160]=C_static_lambda_info(C_heaptop,18,"(a2534 p2180 a181)");
lf[161]=C_static_lambda_info(C_heaptop,17,"(a2576 p182 a183)");
lf[162]=C_static_lambda_info(C_heaptop,16,"(a2609 plist194)");
lf[163]=C_static_lambda_info(C_heaptop,16,"(a2655 cdr-p191)");
lf[164]=C_static_string(C_heaptop,33,"variables of or-pattern differ in");
lf[165]=C_static_lambda_info(C_heaptop,25,"(a2642 car-p189 car-a190)");
lf[166]=C_static_lambda_info(C_heaptop,19,"(or* plist187 k188)");
lf[167]=C_static_lambda_info(C_heaptop,29,"(a2599 first-p184 first-a185)");
lf[168]=C_static_string(C_heaptop,23,"no variables allowed in");
lf[169]=C_static_lambda_info(C_heaptop,19,"(a2709 p2195 a2196)");
lf[170]=C_static_lambda_info(C_heaptop,12,"(a2782 _201)");
lf[171]=C_static_lambda_info(C_heaptop,17,"(a2753 q198 b199)");
lf[172]=C_static_lambda_info(C_heaptop,18,"(a2801 p1202 a203)");
lf[173]=C_static_lambda_info(C_heaptop,21,"(a2902 cdr-p206 a207)");
lf[174]=C_static_lambda_info(C_heaptop,21,"(a2892 car-p204 a205)");
lf[175]=C_h_intern(&lf[175],12,"list->vector");
lf[176]=C_static_lambda_info(C_heaptop,18,"(a2925 pl208 a209)");
lf[177]=C_h_intern(&lf[177],12,"vector->list");
lf[178]=C_static_lambda_info(C_heaptop,22,"(bound p168 a169 k170)");
lf[179]=C_static_lambda_info(C_heaptop,6,"(g115)");
lf[180]=C_static_lambda_info(C_heaptop,21,"(a3095 cdr-p218 a219)");
lf[181]=C_static_lambda_info(C_heaptop,21,"(a3089 car-p216 a217)");
lf[182]=C_static_lambda_info(C_heaptop,27,"(boundv plist210 a211 k212)");
lf[183]=C_static_lambda_info(C_heaptop,21,"(a3170 cdr-p225 a226)");
lf[184]=C_static_lambda_info(C_heaptop,21,"(a3160 car-p223 a224)");
lf[185]=C_static_lambda_info(C_heaptop,27,"(bound* plist220 a221 k222)");
lf[186]=C_static_lambda_info(C_heaptop,17,"(a3233 p232 a233)");
lf[187]=C_static_lambda_info(C_heaptop,18,"(bound pattern161)");
tmp=C_intern(C_heaptop,10,"quasiquote");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"unquote-splicing");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"$");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"=");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"and");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"or");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"not");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"set!");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"get!");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"...");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"___");
C_save(tmp);
lf[188]=C_h_list(15,C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(15);
lf[189]=C_static_lambda_info(C_heaptop,18,"(pattern-var\077 x90)");
lf[190]=C_static_lambda_info(C_heaptop,9,"(simple\077)");
lf[191]=C_static_lambda_info(C_heaptop,15,"(g88 x119 y120)");
lf[192]=C_h_intern(&lf[192],10,"quasiquote");
lf[193]=C_h_intern(&lf[193],7,"unquote");
lf[194]=C_h_intern(&lf[194],16,"unquote-splicing");
lf[195]=C_h_intern(&lf[195],6,"vector");
lf[196]=C_static_string(C_heaptop,23,"syntax error in pattern");
lf[197]=C_static_lambda_info(C_heaptop,15,"(ordinary p117)");
lf[198]=C_static_lambda_info(C_heaptop,16,"(g109 x143 y144)");
lf[199]=C_static_string(C_heaptop,23,"syntax error in pattern");
lf[200]=C_static_lambda_info(C_heaptop,12,"(quasi p141)");
lf[201]=C_static_string(C_heaptop,42,"invalid use of unquote-splicing in pattern");
lf[202]=C_static_lambda_info(C_heaptop,14,"(ordlist p156)");
lf[203]=C_static_lambda_info(C_heaptop,29,"(validate-pattern pattern103)");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_static_string(C_heaptop,29,"Warning: unreachable pattern ");
lf[206]=C_h_intern(&lf[206],2,"in");
lf[207]=C_static_lambda_info(C_heaptop,12,"(a1258 x102)");
lf[208]=C_h_intern(&lf[208],12,"\003sysfor-each");
lf[209]=C_static_lambda_info(C_heaptop,36,"(unreachable plist100 match-expr101)");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[210]=C_h_pair(C_restore,tmp);
lf[211]=C_static_lambda_info(C_heaptop,11,"(a1186 x95)");
lf[212]=C_static_lambda_info(C_heaptop,11,"(a1198 x96)");
lf[213]=C_h_intern(&lf[213],6,"\000match");
lf[214]=C_static_lambda_info(C_heaptop,11,"(a1223 x99)");
tmp=C_intern(C_heaptop,11,"unspecified");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"error");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"fail");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
lf[215]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[216]=C_static_string(C_heaptop,57,"invalid value for ##match#error-control, legal values are");
lf[217]=C_static_lambda_info(C_heaptop,26,"(error-maker match-expr94)");
lf[218]=C_h_intern(&lf[218],1,"n");
lf[219]=C_h_intern(&lf[219],1,"l");
lf[220]=C_h_intern(&lf[220],6,"length");
lf[221]=C_h_intern(&lf[221],2,"=>");
lf[222]=C_static_lambda_info(C_heaptop,10,"(a604 c39)");
lf[223]=C_static_lambda_info(C_heaptop,37,"(genmatch x32 clauses33 match-expr34)");
lf[224]=C_h_intern(&lf[224],6,"letrec");
lf[225]=C_h_intern(&lf[225],10,"\003sysappend");
lf[226]=C_static_lambda_info(C_heaptop,14,"(a846 v68 g69)");
lf[227]=C_static_lambda_info(C_heaptop,10,"(a852 v67)");
lf[228]=C_static_lambda_info(C_heaptop,10,"(a882 _66)");
lf[229]=C_static_lambda_info(C_heaptop,43,"(genletrec pat51 exp52 body53 match-expr54)");
lf[230]=C_h_intern(&lf[230],5,"begin");
lf[231]=C_h_intern(&lf[231],8,"\003sysvoid");
lf[232]=C_static_lambda_info(C_heaptop,15,"(a1022 v87 g88)");
lf[233]=C_h_intern(&lf[233],6,"define");
lf[234]=C_static_lambda_info(C_heaptop,11,"(a1052 v86)");
lf[235]=C_static_lambda_info(C_heaptop,11,"(a1058 _85)");
lf[236]=C_static_lambda_info(C_heaptop,36,"(gendefine pat71 exp72 match-expr73)");
lf[237]=C_static_lambda_info(C_heaptop,5,"(rac)");
lf[238]=C_static_lambda_info(C_heaptop,10,"(rdc l475)");
lf[239]=C_h_intern(&lf[239],15,"\005matchexpanders");
lf[240]=C_h_intern(&lf[240],19,"match-error-control");
lf[241]=C_static_lambda_info(C_heaptop,30,"(match-error-control . arg502)");
lf[242]=C_h_intern(&lf[242],17,"register-feature!");
lf[243]=C_h_intern(&lf[243],13,"match-support");
lf[244]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,245);
t2=C_mutate((C_word*)lf[0]+1,lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_517,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[9]+1,lf[10]);
t6=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t7=(C_word)C_a_i_cons(&a,2,lf[13],lf[14]);
t8=C_mutate((C_word*)lf[15]+1,t7);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7151,a[2]=lf[21],tmp=(C_word)a,a+=3,tmp);
t10=lf[22];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6886,a[2]=t10,a[3]=lf[32],tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6581,a[2]=t10,a[3]=t9,a[4]=lf[43],tmp=(C_word)a,a+=5,tmp);
t13=lf[44];
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=t13,a[3]=lf[45],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6514,a[2]=t13,a[3]=lf[46],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6504,a[2]=lf[47],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6418,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6108,a[2]=t16,a[3]=t17,a[4]=lf[64],tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5977,a[2]=t15,a[3]=t14,a[4]=lf[68],tmp=(C_word)a,a+=5,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=t19,a[3]=t21,a[4]=lf[86],tmp=(C_word)a,a+=5,tmp));
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4901,a[2]=t18,a[3]=t21,a[4]=lf[88],tmp=(C_word)a,a+=5,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1107,a[2]=lf[95],tmp=(C_word)a,a+=3,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3628,a[2]=t15,a[3]=t14,a[4]=t24,a[5]=t21,a[6]=t11,a[7]=t12,a[8]=t9,a[9]=t23,a[10]=t26,a[11]=lf[146],tmp=(C_word)a,a+=12,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=lf[154],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=t24,a[3]=lf[187],tmp=(C_word)a,a+=4,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1081,a[2]=t24,a[3]=lf[189],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t24,a[3]=t30,a[4]=lf[203],tmp=(C_word)a,a+=5,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1253,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=lf[217],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_537,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,a[7]=t28,a[8]=lf[223],tmp=(C_word)a,a+=9,tmp);
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_749,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,a[7]=lf[229],tmp=(C_word)a,a+=8,tmp);
t36=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_905,a[2]=t33,a[3]=t31,a[4]=t29,a[5]=t26,a[6]=t32,a[7]=t28,a[8]=lf[236],tmp=(C_word)a,a+=9,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7186,a[2]=lf[237],tmp=(C_word)a,a+=3,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7209,a[2]=t39,a[3]=lf[238],tmp=(C_word)a,a+=4,tmp));
t41=(C_word)C_a_i_list(&a,4,t34,t35,t36,t30);
t42=C_mutate((C_word*)lf[239]+1,t41);
t43=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7240,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t45=*((C_word*)lf[242]+1);
((C_proc3)C_retrieve_proc(t45))(3,t45,t44,lf[243]);}

/* k7255 */
static void f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* match-error-control */
static void f_7240(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7240r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7240r(t0,t1,t2);}}

static void f_7240r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[9]+1));}}

/* rdc */
static void C_fcall f_7209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7209,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7227,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* k7225 in rdc */
static void f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rac */
static C_word C_fcall f_7186(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
return((C_word)C_i_car(t1));}
else{
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}}

/* gendefine */
static void f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_905,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t6=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k907 in gendefine */
static void f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[7]);}

/* k910 in k907 in gendefine */
static void f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
f_1283(t4,t3,((C_word*)t0)[2]);}

/* k1077 in k910 in k907 in gendefine */
static void f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k913 in k910 in k907 in gendefine */
static void f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t6=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k925 in k913 in k910 in k907 in gendefine */
static void f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1069 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=lf[235],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1058 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1059,3,t0,t1,t2);}
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_949,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=lf[234],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1052 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1053,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[233],t2,C_SCHEME_FALSE));}

/* k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[87],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_969,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,lf[218]);
t5=(C_word)C_a_i_list(&a,1,lf[219]);
t6=(C_word)C_a_i_list(&a,2,lf[220],lf[219]);
t7=(C_word)C_a_i_list(&a,3,lf[123],t6,lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[25],t5,t7);
t9=(C_word)C_a_i_list(&a,3,lf[25],t4,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t9);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_977,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t13,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[3],a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1023,a[2]=lf[232],tmp=(C_word)a,a+=3,tmp);
t19=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t19))(5,t19,t17,t18,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a1022 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1023,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[141],t2,t3));}

/* k1011 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[231]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1007 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1003 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[25],t1);}

/* k999 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_993,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k991 in k999 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k983 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k975 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k967 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[26],t1,((C_word*)t0)[4]);
f_3244(((C_word*)t0)[2],t2);}

/* k959 in k951 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k947 in k940 in k937 in k934 in k931 in k925 in k913 in k910 in k907 in gendefine */
static void f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[230],t1);}

/* genletrec */
static void f_749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_749,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k751 in genletrec */
static void f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[7]);}

/* k754 in k751 in genletrec */
static void f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_903,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
f_1283(t4,t3,((C_word*)t0)[2]);}

/* k901 in k754 in k751 in genletrec */
static void f_903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k757 in k754 in k751 in genletrec */
static void f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t6=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k769 in k757 in k754 in k751 in genletrec */
static void f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_771,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k893 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=lf[228],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a882 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_883,3,t0,t1,t2);}
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_793,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[218]);
t4=(C_word)C_a_i_list(&a,1,lf[219]);
t5=(C_word)C_a_i_list(&a,2,lf[220],lf[219]);
t6=(C_word)C_a_i_list(&a,3,lf[123],t5,lf[218]);
t7=(C_word)C_a_i_list(&a,3,lf[25],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[25],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_801,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t10,tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=lf[227],tmp=(C_word)a,a+=3,tmp);
t13=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,((C_word*)t0)[2]);}

/* a852 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_853,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE));}

/* k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_809,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_837,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=lf[226],tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t8,t9,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a846 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_847,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[141],t2,t3));}

/* k843 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k839 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k835 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[25],t1);}

/* k831 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_833,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_825,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k823 in k831 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k815 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k807 in k803 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k799 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k791 in k784 in k781 in k778 in k775 in k769 in k757 in k754 in k751 in genletrec */
static void f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[224],t1,((C_word*)t0)[2]));}

/* genmatch */
static void f_537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_537,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_541,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t6=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k539 in genmatch */
static void f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
f_1175(t2,((C_word*)t0)[8]);}

/* k542 in k539 in genmatch */
static void f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[222],tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a604 in k542 in k539 in genmatch */
static void f_605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_609,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=((C_word*)t0)[2];
f_1283(t6,t4,t5);}

/* k741 in a604 in k542 in k539 in genmatch */
static void f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2348(t2,((C_word*)t0)[2],t1);}

/* k607 in a604 in k542 in k539 in genmatch */
static void f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_609,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_621,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t6=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_731,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=t2;
f_624(2,t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_624(2,t4,C_SCHEME_FALSE);}}

/* k729 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_624(2,t3,C_SCHEME_FALSE);}}

/* k725 in k729 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_624(2,t2,C_SCHEME_FALSE);}}

/* k721 in k725 in k729 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_624(2,t2,C_SCHEME_FALSE);}}

/* k717 in k721 in k725 in k729 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_624(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_624(2,t2,C_SCHEME_FALSE);}}

/* k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]):((C_word*)t0)[8]);
t3=(C_truep(t1)?(C_word)C_i_cddr(((C_word*)t0)[7]):(C_word)C_i_cdr(((C_word*)t0)[7]));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_656,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_660,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k658 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[25],t1);}

/* k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);}

/* k650 in k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_652,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=t4;
f_641(2,t5,C_SCHEME_FALSE);}}

/* k639 in k650 in k654 in k622 in k619 in k607 in a604 in k542 in k539 in genmatch */
static void f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_641,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k548 in k542 in k539 in genmatch */
static void f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_553,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_603,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t5=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k601 in k548 in k542 in k539 in genmatch */
static void f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3628(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k551 in k548 in k542 in k539 in genmatch */
static void f_553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_1253(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k554 in k551 in k548 in k542 in k539 in genmatch */
static void f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[218]);
t4=(C_word)C_a_i_list(&a,1,lf[219]);
t5=(C_word)C_a_i_list(&a,2,lf[220],lf[219]);
t6=(C_word)C_a_i_list(&a,3,lf[123],t5,lf[218]);
t7=(C_word)C_a_i_list(&a,3,lf[25],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[25],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t8);
t10=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t2,t9,((C_word*)((C_word*)t0)[2])[1]);}

/* k565 in k554 in k551 in k548 in k542 in k539 in genmatch */
static void f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[26],t1,((C_word*)t0)[4]);
f_3244(((C_word*)t0)[2],t2);}

/* error-maker */
static void C_fcall f_1175(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,2,t1,t2);}
t3=(C_word)C_eqp(*((C_word*)lf[9]+1),lf[84]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=lf[211],tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4));}
else{
t4=*((C_word*)lf[9]+1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[10]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[85]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1199,a[2]=lf[212],tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5));}
else{
t5=(C_word)C_eqp(*((C_word*)lf[9]+1),lf[213]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,lf[215],lf[216]);}}}}

/* k1210 in error-maker */
static void f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1213 in k1210 in error-maker */
static void f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[54],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,3,lf[7],t1,t3);
t5=(C_word)C_a_i_list(&a,3,lf[25],t2,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[3],a[3]=lf[214],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t7,t8));}

/* a1223 in k1213 in k1210 in error-maker */
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t2));}

/* a1198 in error-maker */
static void f_1199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1199,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[7],t2));}

/* a1186 in error-maker */
static void f_1187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1187,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[210]);}

/* unreachable */
static void C_fcall f_1253(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1253,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=t3,a[3]=lf[207],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1258 in unreachable */
static void f_1259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1259,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
if(C_truep((C_word)C_i_car(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
t5=*((C_word*)lf[204]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,lf[205],t4,lf[206],((C_word*)t0)[2]);}}

/* validate-pattern */
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1283,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=lf[190],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1316,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t3,a[7]=t5,a[8]=lf[197],tmp=(C_word)a,a+=9,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2046,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t3,a[7]=t7,a[8]=lf[200],tmp=(C_word)a,a+=9,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2308,a[2]=t2,a[3]=t5,a[4]=t9,a[5]=lf[202],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t5)[1];
f_1316(3,t13,t1,t2);}

/* ordlist in validate-pattern */
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t3,t4);}
else{
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],lf[201]);}}}

/* k2326 in ordlist in validate-pattern */
static void f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_2308(t4,t2,t3);}

/* k2330 in k2326 in ordlist in validate-pattern */
static void f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* quasi in validate-pattern */
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[7],a[3]=lf[198],tmp=(C_word)a,a+=4,tmp);
t4=f_1286(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[54],t5));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[193]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(t2);
t10=t7;
f_2093(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_2093(t9,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t7;
f_2130(t9,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t5=t2;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[177]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t5=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,((C_word*)t0)[2],lf[199]);}}}}}

/* k2262 in quasi in validate-pattern */
static void f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2265 in k2262 in quasi in validate-pattern */
static void f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t1);
f_1107(t3,t4);}

/* k2275 in k2265 in k2262 in quasi in validate-pattern */
static void f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2290 in k2275 in k2265 in k2262 in quasi in validate-pattern */
static void f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2272 in k2265 in k2262 in quasi in validate-pattern */
static void f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[195]+1),t1);}

/* k2245 in quasi in validate-pattern */
static void f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_2130(t3,C_SCHEME_FALSE);}}

/* k2241 in k2245 in quasi in validate-pattern */
static void f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2130(t2,C_SCHEME_FALSE);}}

/* k2237 in k2241 in k2245 in quasi in validate-pattern */
static void f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2130(t2,(C_word)C_i_nullp(t1));}

/* k2128 in quasi in validate-pattern */
static void C_fcall f_2130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2130,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2202,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[8]);
f_1107(t4,t5);}
else{
t4=t2;
f_2169(t4,C_SCHEME_FALSE);}}}

/* k2200 in k2128 in quasi in validate-pattern */
static void f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2169(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2169(t2,C_SCHEME_FALSE);}}

/* k2167 in k2128 in quasi in validate-pattern */
static void C_fcall f_2169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2169,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2182,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_2048(t4,((C_word*)t0)[4],t2,t3);}}

/* k2180 in k2167 in k2128 in quasi in validate-pattern */
static void f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2143 in k2128 in quasi in validate-pattern */
static void f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2155,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
f_2308(t4,t3,t1);}

/* k2153 in k2143 in k2128 in quasi in validate-pattern */
static void f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t3,t2,((C_word*)t0)[2]);}

/* k2157 in k2153 in k2143 in k2128 in quasi in validate-pattern */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2137 in k2128 in quasi in validate-pattern */
static void f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t2,((C_word*)t0)[2],t1);}

/* k2091 in quasi in validate-pattern */
static void C_fcall f_2093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1316(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_2048(t4,((C_word*)t0)[3],t2,t3);}}

/* g109 in quasi in validate-pattern */
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_2046(3,t5,t4,t2);}

/* k2054 in g109 in quasi in validate-pattern */
static void f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2060,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2046(3,t3,t2,((C_word*)t0)[2]);}

/* k2058 in k2054 in g109 in quasi in validate-pattern */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ordinary in validate-pattern */
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1316,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[7],a[3]=lf[191],tmp=(C_word)a,a+=4,tmp);
t4=f_1286(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t2,lf[99]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[99]);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=((C_word*)t0)[4];
f_1081(3,t7,t6,t2);}}}

/* k1346 in ordinary in validate-pattern */
static void f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[80],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_eqp(t2,lf[192]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[9]);
t7=t4;
f_1366(t7,(C_word)C_i_nullp(t6));}
else{
t6=t4;
f_1366(t6,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(C_word)C_eqp(t4,lf[54]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(((C_word*)t0)[9]);
t9=t6;
f_1409(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_1409(t8,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(C_word)C_eqp(t6,lf[107]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cddr(((C_word*)t0)[9]);
t11=t8;
f_1446(t11,(C_word)C_i_listp(t10));}
else{
t10=t8;
f_1446(t10,C_SCHEME_FALSE);}}
else{
t8=(C_word)C_i_car(((C_word*)t0)[9]);
t9=(C_word)C_eqp(t8,lf[144]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_i_cddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cdddr(((C_word*)t0)[9]);
t14=t10;
f_1500(t14,(C_word)C_i_nullp(t13));}
else{
t13=t10;
f_1500(t13,C_SCHEME_FALSE);}}
else{
t12=t10;
f_1500(t12,C_SCHEME_FALSE);}}
else{
t10=(C_word)C_i_car(((C_word*)t0)[9]);
t11=(C_word)C_eqp(t10,lf[69]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t13))){
t14=(C_word)C_i_cdr(((C_word*)t0)[9]);
t15=t12;
f_1560(t15,(C_word)C_i_pairp(t14));}
else{
t14=t12;
f_1560(t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_i_car(((C_word*)t0)[9]);
t13=(C_word)C_eqp(t12,lf[143]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t15))){
t16=(C_word)C_i_cdr(((C_word*)t0)[9]);
t17=t14;
f_1607(t17,(C_word)C_i_pairp(t16));}
else{
t16=t14;
f_1607(t16,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_i_car(((C_word*)t0)[9]);
t15=(C_word)C_eqp(t14,lf[56]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t17))){
t18=(C_word)C_i_cdr(((C_word*)t0)[9]);
t19=t16;
f_1654(t19,(C_word)C_i_pairp(t18));}
else{
t18=t16;
f_1654(t18,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_i_car(((C_word*)t0)[9]);
t17=(C_word)C_eqp(t16,lf[142]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cadr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_symbolp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[9]);
t22=t18;
f_1701(t22,(C_word)C_i_listp(t21));}
else{
t21=t18;
f_1701(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_1701(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_i_car(((C_word*)t0)[9]);
t19=(C_word)C_eqp(t18,lf[141]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t21=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1785,a[2]=t20,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cadr(((C_word*)t0)[9]);
t24=((C_word*)t0)[4];
f_1081(3,t24,t22,t23);}
else{
t22=t20;
f_1765(t22,C_SCHEME_FALSE);}}
else{
t20=(C_word)C_i_car(((C_word*)t0)[9]);
t21=(C_word)C_eqp(t20,lf[140]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1832,a[2]=t22,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_cadr(((C_word*)t0)[9]);
t26=((C_word*)t0)[4];
f_1081(3,t26,t24,t25);}
else{
t24=t22;
f_1812(t24,C_SCHEME_FALSE);}}
else{
t22=(C_word)C_i_car(((C_word*)t0)[9]);
t23=(C_word)C_eqp(t22,lf[193]);
if(C_truep(t23)){
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_i_cdr(((C_word*)t0)[9]);
t26=((C_word*)t0)[6];
f_1318(t26,((C_word*)t0)[8],t24,t25);}
else{
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_eqp(t24,lf[194]);
if(C_truep(t25)){
t26=(C_word)C_i_car(((C_word*)t0)[9]);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
t28=((C_word*)t0)[6];
f_1318(t28,((C_word*)t0)[8],t26,t27);}
else{
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=t26,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_i_cadr(((C_word*)t0)[9]);
f_1107(t28,t29);}
else{
t28=t26;
f_1887(t28,C_SCHEME_FALSE);}}}}}}}}}}}}}}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[177]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[2],lf[196]);}}}}

/* k1990 in k1346 in ordinary in validate-pattern */
static void f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t4=t3;
f_2005(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_car(t1);
f_1107(t3,t4);}}

/* k2003 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[3])[1],t4);}
else{
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2018 in k2003 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2000 in k1993 in k1990 in k1346 in ordinary in validate-pattern */
static void f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[195]+1),t1);}

/* k1918 in k1346 in ordinary in validate-pattern */
static void f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1887(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1887(t2,C_SCHEME_FALSE);}}

/* k1885 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1887,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1898 in k1885 in k1346 in ordinary in validate-pattern */
static void f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k1830 in k1346 in ordinary in validate-pattern */
static void f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1812(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1812(t2,C_SCHEME_FALSE);}}

/* k1810 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1783 in k1346 in ordinary in validate-pattern */
static void f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1765(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1765(t2,C_SCHEME_FALSE);}}

/* k1763 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1699 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1701,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1716 in k1699 in k1346 in ordinary in validate-pattern */
static void f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1712 in k1699 in k1346 in ordinary in validate-pattern */
static void f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[142],t1);}

/* k1652 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1662 in k1652 in k1346 in ordinary in validate-pattern */
static void f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[56],t1);}

/* k1605 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1615 in k1605 in k1346 in ordinary in validate-pattern */
static void f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[143],t1);}

/* k1558 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1568 in k1558 in k1346 in ordinary in validate-pattern */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1498 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t5,t4,t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1511 in k1498 in k1346 in ordinary in validate-pattern */
static void f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[144],((C_word*)t0)[2],t1));}

/* k1444 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[4],t2,t3);}}

/* k1461 in k1444 in k1346 in ordinary in validate-pattern */
static void f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1457 in k1444 in k1346 in ordinary in validate-pattern */
static void f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[107],t1);}

/* k1407 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* k1364 in k1346 in ordinary in validate-pattern */
static void C_fcall f_1366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_2046(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_1318(t4,((C_word*)t0)[3],t2,t3);}}

/* g88 in ordinary in validate-pattern */
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1318,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1326,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_1316(3,t5,t4,t2);}

/* k1324 in g88 in ordinary in validate-pattern */
static void f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1330,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1316(3,t3,t2,((C_word*)t0)[2]);}

/* k1328 in k1324 in g88 in ordinary in validate-pattern */
static void f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* simple? in validate-pattern */
static C_word C_fcall f_1286(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=(C_word)C_i_stringp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_charp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_numberp(t1);
return((C_truep(t5)?t5:(C_word)C_i_nullp(t1)));}}}}

/* pattern-var? */
static void f_1081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1081,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1105,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_1107(t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1103 in pattern-var? */
static void f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[2],lf[188]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}}

/* bound */
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2348,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3205,a[2]=lf[156],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3181,a[2]=t7,a[3]=lf[157],tmp=(C_word)a,a+=4,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t7,a[5]=t5,a[6]=t14,a[7]=t10,a[8]=t4,a[9]=t2,a[10]=lf[178],tmp=(C_word)a,a+=11,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t10,a[5]=lf[182],tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=t10,a[3]=t14,a[4]=lf[185],tmp=(C_word)a,a+=5,tmp));
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3234,a[2]=t4,a[3]=lf[186],tmp=(C_word)a,a+=4,tmp);
t19=((C_word*)t10)[1];
f_2352(t19,t1,t2,C_SCHEME_END_OF_LIST,t18);}

/* a3233 in bound */
static void f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3234,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k3240 in a3233 in bound */
static void f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]));}

/* bound* in bound */
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3142,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t4;
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=lf[184],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
f_2352(t7,t1,t5,t3,t6);}}

/* a3160 in bound* in bound */
static void f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3161,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[183],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
f_3142(t6,t1,t4,t3,t5);}

/* a3170 in a3160 in bound* in bound */
static void f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3171,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* boundv in bound */
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3051,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[179],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cadr(t2);
f_1107(t8,t9);}
else{
t8=t6;
f_3067(t8,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_3051(t6,t1);}
else{
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}}}

/* k3111 in boundv in bound */
static void f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3067(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_3067(t2,C_SCHEME_FALSE);}}

/* k3065 in boundv in bound */
static void C_fcall f_3067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[8])[1];
f_2352(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=((C_word*)t0)[3];
f_3051(t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3090,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=lf[181],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)((C_word*)t0)[8])[1];
f_2352(t5,((C_word*)t0)[7],t2,((C_word*)t0)[5],t4);}}}

/* a3089 in k3065 in boundv in bound */
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3090,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[180],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3049(t5,t1,((C_word*)t0)[2],t3,t4);}

/* a3095 in a3089 in k3065 in boundv in bound */
static void f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3096,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* g115 in boundv in bound */
static void C_fcall f_3051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* bound in bound */
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[99],t2);
if(C_truep(t5)){
t6=t4;
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2371,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t2,t3))){
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],lf[158]);}
else{
t7=t6;
f_2371(2,t7,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=t2,a[12]=t1,a[13]=t4,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_2390(t8,(C_word)C_eqp(lf[54],t7));}
else{
t7=t6;
f_2390(t7,C_SCHEME_FALSE);}}}}

/* k2388 in bound in bound */
static void C_fcall f_2390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2390,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=t2;
f_2399(t4,(C_word)C_eqp(lf[107],t3));}
else{
t3=t2;
f_2399(t3,C_SCHEME_FALSE);}}}

/* k2397 in k2388 in bound in bound */
static void C_fcall f_2399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_i_symbolp(t3);
t5=(C_word)C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2437(t7,t5);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[13]);
t8=t6;
f_2437(t8,(C_word)C_i_memq(t7,((C_word*)t0)[9]));}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
t6=(C_word)C_a_i_list(&a,2,lf[107],t5);
t7=(C_word)C_i_cddr(((C_word*)t0)[13]);
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2491(t4,(C_word)C_eqp(lf[144],t3));}
else{
t3=t2;
f_2491(t3,C_SCHEME_FALSE);}}}

/* k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2491,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[13]);
t3=(C_word)C_i_symbolp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_2500(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[13]);
t7=t5;
f_2500(t7,(C_word)C_i_memq(t6,((C_word*)t0)[9]));}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2568(t4,(C_word)C_eqp(lf[69],t3));}
else{
t3=t2;
f_2568(t3,C_SCHEME_FALSE);}}}

/* k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[11],a[3]=lf[161],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
f_3142(t4,((C_word*)t0)[9],t2,((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2591(t4,(C_word)C_eqp(lf[143],t3));}
else{
t3=t2;
f_2591(t3,C_SCHEME_FALSE);}}}

/* k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=lf[167],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
f_2352(t4,((C_word*)t0)[6],t2,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2680(t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t2;
f_2680(t3,C_SCHEME_FALSE);}}}

/* k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=lf[169],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)((C_word*)t0)[7])[1];
f_2352(t5,((C_word*)t0)[6],t3,((C_word*)t0)[9],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[11]);
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[143],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
f_1107(t2,t4);}
else{
t4=t2;
f_2745(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2745(2,t3,C_SCHEME_FALSE);}}}

/* k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=lf[171],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)((C_word*)t0)[5])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=t2;
f_2793(t4,(C_word)C_eqp(lf[142],t3));}
else{
t3=t2;
f_2793(t3,C_SCHEME_FALSE);}}}

/* k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=lf[172],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
f_3142(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=t2;
f_2824(t4,(C_word)C_eqp(lf[141],t3));}
else{
t3=t2;
f_2824(t3,C_SCHEME_FALSE);}}}

/* k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2854(t4,(C_word)C_eqp(lf[140],t3));}
else{
t3=t2;
f_2854(t3,C_SCHEME_FALSE);}}}

/* k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2854,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=lf[174],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[177]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}}}}

/* k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[5],a[3]=lf[176],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3049(t3,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* a2925 in k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2926,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2934,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[175]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2932 in a2925 in k2922 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2892 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2893,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[173],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
f_2352(t6,t1,t4,t3,t5);}

/* a2902 in a2892 in k2852 in k2822 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2903,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2802,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2810,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2814,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* k2812 in a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[142],t1);}

/* k2808 in a2801 in k2791 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2754,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2758,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3181(t5,t4,t3,((C_word*)t0)[2]);}

/* k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2783,a[2]=lf[170],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* a2782 in k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2783,3,t0,t1,t2);}
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2779 in k2775 in k2771 in k2756 in a2753 in k2743 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2695 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[56],t1);
t3=((C_word*)((C_word*)t0)[5])[1];
f_2352(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2710,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_3205(t5,((C_word*)t0)[4],t3);}

/* k2729 in a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2714(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[168]);}}

/* k2712 in a2709 in k2678 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[56],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2600,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2610,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=lf[162],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,a[8]=lf[166],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2624(t9,t1,t4,t5);}

/* or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2624,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=t2,a[8]=lf[165],tmp=(C_word)a,a+=9,tmp);
t6=((C_word*)((C_word*)t0)[3])[1];
f_2352(t6,t1,t4,((C_word*)t0)[2],t5);}}

/* a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2647,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_3205(t5,t3,((C_word*)t0)[2]);}

/* k2672 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2647(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[164]);}}

/* k2645 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[163],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2624(t4,((C_word*)t0)[2],t2,t3);}

/* a2655 in k2645 in a2642 in or* in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2656,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2610,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k2620 in a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[143],t1);}

/* k2616 in a2609 in a2599 in k2589 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2576 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2577,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[69],t2);}

/* k2583 in a2576 in k2566 in k2489 in k2397 in k2388 in bound in bound */
static void f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2498 in k2489 in k2397 in k2388 in bound in bound */
static void C_fcall f_2500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=lf[160],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[5])[1];
f_2352(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t3);}}

/* a2534 in k2498 in k2489 in k2397 in k2388 in bound in bound */
static void f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2535,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[144],t4,t2);
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t3);}

/* k2501 in k2498 in k2489 in k2397 in k2388 in bound in bound */
static void f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_list(&a,3,lf[144],t1,t6);
t8=((C_word*)((C_word*)t0)[5])[1];
f_2352(t8,((C_word*)t0)[4],t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2414 in k2397 in k2388 in bound in bound */
static void f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k2410 in k2397 in k2388 in bound in bound */
static void f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2352(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2435 in k2397 in k2388 in bound in bound */
static void C_fcall f_2437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2437,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2438 in k2435 in k2397 in k2388 in bound in bound */
static void f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[5])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[107],t1);
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k2369 in bound in bound */
static void f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* find-prefix in bound */
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3181,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
t9=t6;
t10=t7;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k3197 in find-prefix in bound */
static void f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* permutation in bound */
static void C_fcall f_3205(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3205,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t3,a[3]=lf[155],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t6,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a3216 in permutation in bound */
static void f_3217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3217,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,((C_word*)t0)[2]));}

/* inline-let */
static void C_fcall f_3244(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3244,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3327,a[2]=lf[147],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3409,a[2]=t3,a[3]=lf[149],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=t3,a[3]=lf[150],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_caddr(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3504,a[2]=t5,a[3]=t9,a[4]=t4,a[5]=lf[153],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3504(t11,t1,t6,C_SCHEME_END_OF_LIST,t7);}

/* loop in inline-let */
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3504,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3524,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t5);
t7=f_3409(((C_word*)t0)[4],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t9=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}
else{
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
t14=t1;
t15=t8;
t16=t10;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k3531 in loop in inline-let */
static void f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=t1;
t4=((C_word*)t0)[3];
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3253,a[2]=t3,a[3]=t6,a[4]=lf[152],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3253(t8,t2,t4);}

/* loop in k3531 in loop in inline-let */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3253,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_fix(1):C_fix(0)));}}

/* k3265 in loop in k3531 in loop in inline-let */
static void f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_3253(t4,t2,t3);}

/* k3269 in k3265 in loop in k3531 in loop in inline-let */
static void f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k3534 in k3531 in loop in inline-let */
static void f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(C_fix(0),t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=((C_word*)((C_word*)t0)[7])[1];
f_3504(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_nequalp(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3558(t4,t2);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(t4);
t6=t3;
f_3558(t6,f_3431(((C_word*)t0)[2],t5));}}}

/* k3556 in k3534 in k3531 in loop in inline-let */
static void C_fcall f_3558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3558,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cadr(t4);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3293,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=lf[151],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3293(t11,t3,t6);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[6])[1];
f_3504(t5,((C_word*)t0)[5],t2,t4,((C_word*)t0)[3]);}}

/* loop in k3556 in k3534 in k3531 in loop in inline-let */
static void C_fcall f_3293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3293,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t2));}}

/* k3305 in loop in k3556 in k3534 in k3531 in loop in inline-let */
static void f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_3293(t4,t2,t3);}

/* k3309 in k3305 in loop in k3556 in k3534 in k3531 in loop in inline-let */
static void f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3567 in k3556 in k3534 in k3531 in loop in inline-let */
static void f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_3504(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3522 in loop in inline-let */
static void f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[26],t1,((C_word*)t0)[2]));}

/* small? in inline-let */
static C_word C_fcall f_3431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=f_3327(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t3,lf[25]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(t1);
t8=f_3327(t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdddr(t1);
return((C_word)C_i_nullp(t9));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}

/* isval? in inline-let */
static C_word C_fcall f_3409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=f_3327(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t3,lf[148]));}
else{
return(C_SCHEME_FALSE);}}}

/* const? in inline-let */
static C_word C_fcall f_3327(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t2=(C_word)C_i_symbolp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_i_stringp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_charp(t1);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_i_numberp(t1);
if(C_truep(t6)){
return(t6);}
else{
t7=(C_word)C_i_nullp(t1);
if(C_truep(t7)){
return(t7);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t8=(C_word)C_i_car(t1);
t9=(C_word)C_eqp(t8,lf[54]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_symbolp(t11))){
t12=(C_word)C_i_cddr(t1);
return((C_word)C_i_nullp(t12));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}}}}}}

/* gen */
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
if(C_truep((C_word)C_i_nullp(t4))){
t8=t5;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t2);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3639,a[2]=t9,a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3648,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t4,a[8]=lf[97],tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=t10,a[3]=t11,a[4]=t4,a[5]=lf[98],tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3753,a[2]=t12,a[3]=t11,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=t6,a[11]=t10,a[12]=t7,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[7],a[16]=((C_word*)t0)[8],a[17]=((C_word*)t0)[9],a[18]=t9,tmp=(C_word)a,a+=19,tmp);
t14=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t4);}}

/* k3751 in gen */
static void f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[16],a[12]=t3,a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=lf[145],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_3755(t5,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* next in k3751 in gen */
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3755,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(lf[99],t2);
if(C_truep(t7)){
t8=t6;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t4);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_a_i_cons(&a,2,t2,t3);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[14])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[14])+1,t9);
t11=t6;
((C_proc3)C_retrieve_proc(t11))(3,t11,t1,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_a_i_list(&a,2,lf[62],t3);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_equalp(t2,lf[100]))){
t8=(C_word)C_a_i_list(&a,2,lf[62],t3);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[48],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[48],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[48],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[48],t3,t2);
t9=((C_word*)t0)[13];
f_4901(t9,t1,t8,t4,t5,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t5,a[16]=t4,a[17]=t1,a[18]=((C_word*)t0)[13],a[19]=t2,a[20]=t3,tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t8;
f_3866(t10,(C_word)C_eqp(lf[54],t9));}
else{
t9=t8;
f_3866(t9,C_SCHEME_FALSE);}}}}}}}}}}

/* k3864 in next in k3751 in gen */
static void C_fcall f_3866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3866,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,3,lf[48],((C_word*)t0)[20],((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
f_4901(t3,((C_word*)t0)[17],t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_3879(t4,(C_word)C_eqp(lf[107],t3));}
else{
t3=t2;
f_3879(t3,C_SCHEME_FALSE);}}}

/* k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[19]);
t4=((C_word*)t0)[18];
f_4901(t4,((C_word*)t0)[17],t3,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_3895(t4,(C_word)C_eqp(lf[144],t3));}
else{
t3=t2;
f_3895(t3,C_SCHEME_FALSE);}}}

/* k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3895,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[20]);
t3=(C_word)C_i_cadr(((C_word*)t0)[20]);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[19]);
t5=((C_word*)((C_word*)t0)[18])[1];
f_3755(t5,((C_word*)t0)[17],t2,t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[14],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_3916(t4,(C_word)C_eqp(lf[69],t3));}
else{
t3=t2;
f_3916(t3,C_SCHEME_FALSE);}}}

/* k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3916,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[20]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=t4,a[6]=((C_word*)t0)[19],a[7]=lf[102],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3925(t6,((C_word*)t0)[15],t2,((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[13],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_3958(t4,(C_word)C_eqp(lf[143],t3));}
else{
t3=t2;
f_3958(t3,C_SCHEME_FALSE);}}}

/* k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3958,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_word)C_i_cdr(((C_word*)t0)[19]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[18],a[9]=lf[104],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_3967(t7,((C_word*)t0)[14],t3,((C_word*)t0)[13]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4001(t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t2;
f_4001(t3,C_SCHEME_FALSE);}}}

/* k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=((C_word*)((C_word*)t0)[19])[1];
f_3755(t3,((C_word*)t0)[18],t2,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4014(t4,(C_word)C_eqp(lf[142],t3));}
else{
t3=t2;
f_4014(t3,C_SCHEME_FALSE);}}}

/* k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_i_cdr(((C_word*)t0)[20]);
t4=(C_word)C_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=t4,a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
f_7151(t5,(C_word)C_a_i_list(&a,2,t2,lf[107]));}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[11],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4076(t4,(C_word)C_eqp(lf[141],t3));}
else{
t3=t2;
f_4076(t3,C_SCHEME_FALSE);}}}

/* k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4076,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[19]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[14];
f_6581(t4,t3,((C_word*)t0)[13],((C_word*)t0)[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4101(t4,(C_word)C_eqp(lf[140],t3));}
else{
t3=t2;
f_4101(t3,C_SCHEME_FALSE);}}}

/* k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4101,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[18]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[13];
f_6886(t4,t3,((C_word*)t0)[12],((C_word*)t0)[18]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[18]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[18]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[18]);
f_1107(t2,t4);}
else{
t4=t2;
f_4126(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4126(2,t3,C_SCHEME_FALSE);}}}

/* k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[59],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=lf[118],tmp=(C_word)a,a+=15,tmp);
t4=((C_word*)t0)[8];
f_4901(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[16]))){
t2=(C_word)C_a_i_list(&a,2,lf[63],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[16],a[9]=lf[120],tmp=(C_word)a,a+=10,tmp);
t4=((C_word*)t0)[8];
f_4901(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[16]))){
t3=(C_word)C_i_vector_length(((C_word*)t0)[16]);
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(6)))){
t4=(C_word)C_i_vector_length(((C_word*)t0)[16]);
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(5));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[16],t5);
f_1107(t2,t6);}
else{
t4=t2;
f_4465(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4465(2,t3,C_SCHEME_FALSE);}}}}

/* k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[13],t5);
f_1107(t4,t6);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[13]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_list(&a,2,lf[121],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[12],a[9]=lf[134],tmp=(C_word)a,a+=10,tmp);
t5=((C_word*)t0)[5];
f_4901(t5,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[6],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[138]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[139]);}}}

/* k4753 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[137]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4756 in k4753 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,lf[136]);}

/* a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4703,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[122],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[48],t3,((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4717,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],a[9]=lf[133],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_4717(t9,t5,C_fix(0));}

/* vloop in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4717,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=lf[132],tmp=(C_word)a,a+=11,tmp));}

/* f_4719 in vloop in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4719,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[23],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4717(t7,t5,t6);}}

/* k4742 */
static void f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4713 in a4702 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
f_4901(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_list(&a,2,lf[121],((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=lf[131],tmp=(C_word)a,a+=14,tmp);
t7=((C_word*)t0)[4];
f_4901(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[5],t6);}

/* a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4486,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[122],((C_word*)t0)[12]);
t4=(C_word)C_a_i_list(&a,3,lf[123],t3,((C_word*)t0)[11]);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t2,a[13]=t4,a[14]=t1,a[15]=((C_word*)t0)[10],tmp=(C_word)a,a+=16,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4502,a[2]=t1,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4507,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=lf[130],tmp=(C_word)a,a+=14,tmp));
t7=((C_word*)t5)[1];
f_4507(t7,t3,C_fix(0));}

/* vloop in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4507,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=lf[129],tmp=(C_word)a,a+=15,tmp));}

/* f_4509 in vloop in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[62],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4509,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[13],((C_word*)t0)[12]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,lf[99]);
if(C_truep(t4)){
t5=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(3));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(4));
t8=(C_word)C_i_vector_ref(((C_word*)t0)[11],t7);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(5));
t10=(C_word)C_i_vector_ref(((C_word*)t0)[11],t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t6,a[8]=t1,a[9]=t8,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t13=(C_word)C_a_i_list(&a,3,lf[23],((C_word*)t0)[7],t8);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4619,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t8,a[6]=t6,a[7]=lf[128],tmp=(C_word)a,a+=8,tmp);
t15=((C_word*)((C_word*)t0)[4])[1];
f_3755(t15,t11,t12,t13,t2,((C_word*)t0)[3],t14);}}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,3,lf[23],((C_word*)t0)[7],((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4531,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[13]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4507(t7,t5,t6);}}

/* k4529 */
static void f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4618 */
static void f_4619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4619,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,3,lf[125],((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[4],a[3]=lf[127],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4636 in a4618 */
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
f_3639(3,t5,t4,t2);}

/* k4643 in a4636 in a4618 */
static void f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[112],t1,((C_word*)t0)[2]));}

/* k4633 in a4618 */
static void f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4625 in a4618 */
static void f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4554 */
static void f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[11],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[112]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4607 in k4554 */
static void f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4558 in k4554 */
static void f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_a_i_list(&a,2,lf[122],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[125],t4,C_fix(1));
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=lf[126],tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a4588 in k4558 in k4554 */
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4589,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[54],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4585 in k4558 in k4554 */
static void f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4565 in k4558 in k4554 */
static void f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[124],((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4579,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4577 in k4565 in k4558 in k4554 */
static void f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[66],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[26],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k4503 in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4500 in k4496 in a4485 in k4469 in k4463 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4433,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4445,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=((C_word*)t0)[2];
f_6514(t5,t4,((C_word*)t0)[3]);}

/* k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=lf[119],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)((C_word*)t0)[9])[1];
f_3755(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],((C_word*)t0)[8],t2);}

/* a4446 in k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4447,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
f_6547(t5,t4,((C_word*)t0)[2]);}

/* k4457 in a4446 in k4443 in a4432 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
f_1107(t3,t4);}

/* k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=lf[117],tmp=(C_word)a,a+=12,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_4140(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(1):
t3=(C_word)C_a_i_list(&a,2,lf[63],((C_word*)t0)[12]);
t4=((C_word*)t0)[3];
f_4901(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[10],t2);
default:
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[12]);
t5=((C_word*)t0)[3];
f_4901(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[10],t2);}}

/* ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4140,3,t0,t1,t2);}
t3=(C_word)C_i_list_ref(((C_word*)t0)[10],C_fix(2));
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,lf[99]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t2);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=lf[109],tmp=(C_word)a,a+=3,tmp);
t10=((C_word*)((C_word*)t0)[4])[1];
f_3755(t10,t6,t7,((C_word*)t0)[5],t2,t8,t9);}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t7))){
t8=(C_word)C_i_car(((C_word*)t0)[10]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=t6;
f_4249(t10,(C_word)C_i_equalp(t9,t3));}
else{
t8=t6;
f_4249(t8,C_SCHEME_FALSE);}}}}

/* k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=((C_word*)((C_word*)t0)[10])[1];
f_3755(t3,((C_word*)t0)[9],t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(3));
t3=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(4));
t4=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(5));
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_a_i_list(&a,2,lf[28],t3);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4333,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,a[7]=lf[116],tmp=(C_word)a,a+=8,tmp);
t9=((C_word*)((C_word*)t0)[10])[1];
f_3755(t9,t5,t6,t7,((C_word*)t0)[7],((C_word*)t0)[6],t8);}}

/* a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,2,lf[29],((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4349,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[4],a[3]=lf[115],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4350 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4351,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
f_3639(3,t5,t4,t2);}

/* k4357 in a4350 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[112],t1,((C_word*)t0)[2]));}

/* k4347 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4339 in a4332 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4319,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a4318 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4319,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[113],t2));}

/* k4315 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k4311 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4301,a[2]=lf[110],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a4300 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4301,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[54],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4297 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4277 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[62],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4291,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4289 in k4277 in k4270 in k4266 in k4247 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[66],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[26],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a4241 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4242,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a4238 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4239,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(t1);
t9=t3;
f_4183(t9,(C_word)C_i_nullp(t8));}
else{
t8=t3;
f_4183(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4183(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4183(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4183(t4,C_SCHEME_FALSE);}}

/* k4181 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4183,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4165(t2,(C_word)C_i_car(((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4165(t3,(C_word)C_a_i_list(&a,3,lf[25],t2,((C_word*)t0)[3]));}}

/* k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4174 in k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4180,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4178 in k4174 in k4163 in k4160 in ks in k4137 in a4134 in k4124 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4118 in k4099 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4093 in k4074 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4035,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=lf[106],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4035(t7,t3,C_fix(1));}

/* rloop in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4035,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=lf[105],tmp=(C_word)a,a+=11,tmp));}

/* f_4037 in rloop in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_list_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
t7=((C_word*)((C_word*)t0)[2])[1];
f_4035(t7,t5,t6);}}

/* k4060 */
static void f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[7])[1];
f_3755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4031 in k4068 in k4012 in k3999 in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
f_4901(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3967,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=lf[103],tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)((C_word*)t0)[4])[1];
f_3755(t7,t1,t5,((C_word*)t0)[3],t3,t6,((C_word*)t0)[2]);}}

/* a3986 in loop in k3956 in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_3987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3987,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_3967(t4,t1,t3,t2);}

/* loop in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3925,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=lf[101],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)((C_word*)t0)[4])[1];
f_3755(t6,t1,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],t5);}}

/* a3943 in loop in k3914 in k3893 in k3877 in k3864 in next in k3751 in gen */
static void f_3944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3944,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_3925(t4,t1,t3,t2);}

/* success in gen */
static void f_3657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3657,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_cddddr(t3);
t5=(C_word)C_i_set_car(t4,C_SCHEME_TRUE);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_i_caddr(t8);
t10=(C_word)C_i_car(((C_word*)t0)[4]);
t11=(C_word)C_i_cadddr(t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t7,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3719,a[2]=t11,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,((C_word*)t0)[2],t9);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}}

/* k3724 in success in gen */
static void f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3717 in success in gen */
static void f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3713 in success in gen */
static void f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3674 in success in gen */
static void f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[3];
f_3648(3,t4,t3,((C_word*)t0)[2]);}

/* k3709 in k3674 in success in gen */
static void f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3711,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,3,lf[26],t5,((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[25],((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,lf[71],t7));}

/* fail in gen */
static void f_3648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3648,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=((C_word*)((C_word*)t0)[6])[1];
f_3628(t4,t1,((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* val in gen */
static void f_3639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3639,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* dot-dot-k? */
static void C_fcall f_1107(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1107,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
if(C_truep((C_truep((C_word)C_eqp(t3,lf[89]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[90]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[18]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1121 in dot-dot-k? */
static void f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_less_or_equalp(C_fix(3),t2))){
t3=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_string_ref(t1,C_fix(1));
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1150,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[91]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t1,C_fix(2),t2);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1163 in k1121 in dot-dot-k? */
static void f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1159 in k1121 in dot-dot-k? */
static void f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[93]+1),t1);}

/* k1148 in k1121 in dot-dot-k? */
static void f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[91]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1155 in k1148 in k1121 in dot-dot-k? */
static void f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* emit */
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4901,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=t3,a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=((C_word*)t0)[2];
f_6108(t7,t6,t2,t3);}

/* k4906 in emit */
static void f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[56],((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_6108(t4,t2,t3,((C_word*)t0)[6]);}}

/* k4915 in k4906 in emit */
static void f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4926,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t4,lf[48]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[49],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[50],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_charp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[51],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[52],t2);
t8=t3;
f_4926(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t6))){
t8=(C_word)C_i_car(t6);
t9=t7;
f_5039(t9,(C_word)C_eqp(lf[54],t8));}
else{
t8=t7;
f_5039(t8,C_SCHEME_FALSE);}}}}}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_eqp(t6,lf[62]);
if(C_truep(t7)){
t8=(C_word)C_a_i_list(&a,2,lf[59],t2);
t9=t3;
f_4926(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t8=t3;
f_4926(t8,C_SCHEME_END_OF_LIST);}}}}

/* k5037 in k4915 in k4906 in emit */
static void C_fcall f_5039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[53],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4926(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[2];
f_4926(t2,C_SCHEME_END_OF_LIST);}}

/* k4924 in k4915 in k4906 in emit */
static void C_fcall f_4926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4926,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4932,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(t2,lf[59]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[62],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[56],t5);
t7=t3;
f_4932(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t3;
f_4932(t5,C_SCHEME_END_OF_LIST);}}

/* k4930 in k4924 in k4915 in k4906 in emit */
static void C_fcall f_4932(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4932,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4959 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4938,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[56],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4953,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[87]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4951 in k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4936 in k4933 in k4930 in k4924 in k4915 in k4906 in emit */
static void f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_5083(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* assm */
static void C_fcall f_5083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5083,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_equalp(t4,t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t4,C_SCHEME_TRUE);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[63]);
if(C_truep(t9)){
t10=*((C_word*)lf[9]+1);
if(C_truep((C_truep((C_word)C_eqp(t10,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t10,lf[85]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t11=(C_word)C_i_car(t3);
if(C_truep((C_truep((C_word)C_eqp(t11,lf[65]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t11,lf[7]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t12=(C_word)C_i_cadr(t2);
t13=((C_word*)t0)[2];
f_5977(t13,t7,t4,t12);}
else{
t12=t7;
f_5102(2,t12,C_SCHEME_FALSE);}}
else{
t11=t7;
f_5102(2,t11,C_SCHEME_FALSE);}}
else{
t10=t7;
f_5102(2,t10,C_SCHEME_FALSE);}}}}

/* k5100 in assm */
static void f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[66]);
if(C_truep(t4)){
t5=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t6=t2;
f_5108(t6,(C_word)C_i_equalp(t5,((C_word*)t0)[4]));}
else{
t5=t2;
f_5108(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5108(t3,C_SCHEME_FALSE);}}}

/* k5106 in k5100 in assm */
static void C_fcall f_5108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5108,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[69]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5129,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(t7);
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[3],t8);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[69],((C_word*)t0)[3],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[6]);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[66],t6,t7,((C_word*)t0)[4]));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[71]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[6]);}
else{
t7=t2;
f_5166(t7,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5166(t6,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5166(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5166(t3,C_SCHEME_FALSE);}}}

/* k5905 in k5106 in k5100 in assm */
static void f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[25]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5901 in k5905 in k5106 in k5100 in assm */
static void f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5883,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5875,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5873 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[26]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5867,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5865 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5859,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5857 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5851,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5849 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5847,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5843,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5841 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5831,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5829 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5817 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5813 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5811,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[25]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5805 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5801 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5795,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5793 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5789 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5781 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5777 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5771,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5769 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5765 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5747,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5751,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5755,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5753 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5749 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5745 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5735,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5739,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5737 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5733 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5729 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5719,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5723,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5721 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5717 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5707,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5705 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5703,2,t0,t1);}
t2=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5695,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5693 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5691,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5687,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5685 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5683,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5679,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5677 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5166(t2,C_SCHEME_FALSE);}}

/* k5669 in k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5651,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5655,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5659,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
f_5166(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5166(t3,C_SCHEME_FALSE);}}

/* k5657 in k5669 in k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5653 in k5669 in k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5649 in k5669 in k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5645 in k5669 in k5673 in k5681 in k5689 in k5701 in k5713 in k5725 in k5741 in k5761 in k5773 in k5785 in k5797 in k5809 in k5825 in k5837 in k5845 in k5853 in k5861 in k5869 in k5881 in k5885 in k5893 in k5897 in k5901 in k5905 in k5106 in k5100 in assm */
static void f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5166(t2,(C_word)C_i_equalp(((C_word*)t0)[2],t1));}

/* k5164 in k5106 in k5100 in assm */
static void C_fcall f_5166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[66],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]));}}

/* k5228 in k5164 in k5106 in k5100 in assm */
static void f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5230,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k5224 in k5228 in k5164 in k5106 in k5100 in assm */
static void f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5220 in k5228 in k5164 in k5106 in k5100 in assm */
static void f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5218,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k5216 in k5220 in k5228 in k5164 in k5106 in k5100 in assm */
static void f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5173 in k5220 in k5228 in k5164 in k5106 in k5100 in assm */
static void f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t9=((C_word*)((C_word*)t0)[3])[1];
f_5083(t9,t7,((C_word*)t0)[2],t8,t1);}

/* k5196 in k5173 in k5220 in k5228 in k5164 in k5106 in k5100 in assm */
static void f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5198,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[26],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[25],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[71],t3));}

/* k5127 in k5106 in k5100 in assm */
static void f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k5119 in k5106 in k5100 in assm */
static void f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5121,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[66],t1,t2,((C_word*)t0)[2]));}

/* guarantees */
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5977,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5981,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
f_6514(t5,t4,t3);}

/* k5979 in guarantees */
static void f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
f_6547(t3,t2,((C_word*)t0)[2]);}

/* k5982 in k5979 in guarantees */
static void f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5989,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=lf[67],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5989(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k5982 in k5979 in guarantees */
static void C_fcall f_5989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5989,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t3,lf[65]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[7]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_equalp(t2,((C_word*)t0)[4]);
t5=(C_truep(t4)?t4:(C_word)C_i_equalp(t2,((C_word*)t0)[3]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[66]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cadr(t2);
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[25]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[26]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=t10;
f_6056(t14,(C_word)C_i_symbolp(t13));}
else{
t13=t10;
f_6056(t13,C_SCHEME_FALSE);}}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6054 in loop in k5982 in k5979 in guarantees */
static void C_fcall f_6056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6056,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_5989(t4,t2,t3);}}

/* k6057 in k6054 in loop in k5982 in k5979 in guarantees */
static void f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_5989(t3,((C_word*)t0)[4],t2);}}

/* k6018 in loop in k5982 in k5979 in guarantees */
static void f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_5989(t4,t2,t3);}}

/* k6027 in k6018 in loop in k5982 in k5979 in guarantees */
static void f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5989(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* in */
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6108,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_member(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6118,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[59]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[62],t8);
t10=(C_word)C_i_member(t9,t3);
if(C_truep(t10)){
t11=t5;
f_6118(t11,t10);}
else{
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[63],t11);
t13=t5;
f_6118(t13,(C_word)C_i_member(t12,t3));}}
else{
t8=t5;
f_6118(t8,C_SCHEME_FALSE);}}}

/* k6116 in in */
static void C_fcall f_6118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[56]);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
f_6418(t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k6131 in k6116 in in */
static void f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=lf[57],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6141(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=f_6504(((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=lf[58],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6259(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[59]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,a[5]=lf[61],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6325(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6325,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_memq(t8,lf[60]);
t10=t4;
f_6338(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6338(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6338(t7,C_SCHEME_FALSE);}}}

/* k6336 in mem in k6131 in k6116 in in */
static void C_fcall f_6338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_6325(t3,((C_word*)t0)[4],t2);}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6259,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6272,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_i_equalp(t8,t9);
t11=t4;
f_6272(t11,(C_word)C_i_not(t10));}
else{
t8=t4;
f_6272(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6272(t7,C_SCHEME_FALSE);}}}

/* k6270 in mem in k6131 in k6116 in in */
static void C_fcall f_6272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_6259(t3,((C_word*)t0)[4],t2);}}

/* mem in k6131 in k6116 in in */
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6141,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6504(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_equalp(((C_word*)t0)[5],t8);
t10=t4;
f_6154(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6154(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6154(t7,C_SCHEME_FALSE);}}}

/* k6152 in mem in k6131 in k6116 in in */
static void C_fcall f_6154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6154,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,2,lf[56],t3);
t5=(C_word)C_i_equalp(((C_word*)t0)[5],t4);
if(C_truep(t5)){
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[5]);
t8=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_equalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
f_6418(t9,((C_word*)t0)[5]);}
else{
t9=t6;
f_6166(t9,C_SCHEME_FALSE);}}}}

/* k6183 in k6152 in mem in k6131 in k6116 in in */
static void f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=(C_word)C_i_equalp(t2,t3);
t5=((C_word*)t0)[2];
f_6166(t5,(C_word)C_i_not(t4));}
else{
t2=((C_word*)t0)[2];
f_6166(t2,C_SCHEME_FALSE);}}

/* k6164 in k6152 in mem in k6131 in k6116 in in */
static void C_fcall f_6166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_6141(t3,((C_word*)t0)[4],t2);}}

/* equal-test? */
static void C_fcall f_6418(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6418,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[48]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_stringp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[49]);}
else{
if(C_truep((C_word)C_booleanp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[50]);}
else{
if(C_truep((C_word)C_charp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[51]);}
else{
if(C_truep((C_word)C_i_numberp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[52]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_car(t5);
t10=(C_word)C_eqp(lf[54],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t5);
t12=t6;
f_6458(t12,(C_word)C_i_symbolp(t11));}
else{
t11=t6;
f_6458(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6458(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_6458(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_6458(t7,C_SCHEME_FALSE);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6456 in equal-test? */
static void C_fcall f_6458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?lf[53]:C_SCHEME_FALSE));}

/* disjoint? */
static C_word C_fcall f_6504(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t2,*((C_word*)lf[15]+1)));}

/* add-a */
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6514,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6518,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6518(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6518(t4,C_SCHEME_FALSE);}}

/* k6516 in add-a */
static void C_fcall f_6518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6518,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[28],((C_word*)t0)[3]));}}

/* add-d */
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6547,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6551,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6551(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6551(t4,C_SCHEME_FALSE);}}

/* k6549 in add-d */
static void C_fcall f_6551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[29],((C_word*)t0)[3]));}}

/* setter */
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[233],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6581,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[3],a[3]=lf[35],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_a_i_list(&a,2,lf[24],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_list(&a,1,lf[36]);
t11=(C_word)C_i_caddr(t2);
t12=(C_word)C_a_i_list(&a,4,lf[37],lf[24],t11,lf[36]);
t13=(C_word)C_a_i_list(&a,3,lf[25],t10,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[26],t9,t13));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[27]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[24],t9);
t11=(C_word)C_a_i_list(&a,1,t10);
t12=(C_word)C_a_i_list(&a,1,lf[36]);
t13=(C_word)C_a_i_list(&a,3,lf[38],lf[24],lf[36]);
t14=(C_word)C_a_i_list(&a,3,lf[25],t12,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[26],t11,t14));}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[28]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[24],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(C_word)C_a_i_list(&a,1,lf[36]);
t15=(C_word)C_a_i_list(&a,3,lf[39],lf[24],lf[36]);
t16=(C_word)C_a_i_list(&a,3,lf[25],t14,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[26],t13,t16));}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[29]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_a_i_list(&a,2,lf[24],t13);
t15=(C_word)C_a_i_list(&a,1,t14);
t16=(C_word)C_a_i_list(&a,1,lf[36]);
t17=(C_word)C_a_i_list(&a,3,lf[40],lf[24],lf[36]);
t18=(C_word)C_a_i_list(&a,3,lf[25],t16,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_list(&a,3,lf[26],t15,t18));}
else{
t13=(C_word)C_i_car(t2);
t14=(C_word)C_eqp(t13,lf[30]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,lf[24],t15);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(C_word)C_a_i_list(&a,1,lf[36]);
t19=(C_word)C_i_caddr(t2);
t20=(C_word)C_a_i_list(&a,4,lf[41],lf[24],t19,lf[36]);
t21=(C_word)C_a_i_list(&a,3,lf[25],t18,t20);
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_word)C_a_i_list(&a,3,lf[26],t17,t21));}
else{
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6775,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t16)){
t18=(C_word)C_i_cadr(t16);
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_a_i_list(&a,2,t18,t19);
t21=(C_word)C_a_i_list(&a,2,lf[24],t20);
t22=(C_word)C_a_i_list(&a,1,t21);
t23=(C_word)C_a_i_list(&a,1,lf[36]);
t24=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6836,a[2]=t22,a[3]=t17,a[4]=t23,tmp=(C_word)a,a+=5,tmp);
t25=(C_word)C_i_cddr(t16);
t26=t4;
f_6583(t26,t24,t25);}
else{
t18=t17;
f_6775(t18,C_SCHEME_FALSE);}}}}}}}
else{
t5=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,lf[42]);}}

/* k6834 in setter */
static void f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[24],lf[36]);
t3=(C_word)C_a_i_list(&a,3,lf[25],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
f_6775(t4,(C_word)C_a_i_list(&a,3,lf[26],((C_word*)t0)[2],t3));}

/* k6773 in setter */
static void C_fcall f_6775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[24],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,1,lf[36]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6801,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
f_6583(t8,t6,t7);}}

/* k6799 in k6773 in setter */
static void f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[24],lf[36]);
t3=(C_word)C_a_i_list(&a,3,lf[25],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[26],((C_word*)t0)[2],t3));}

/* mk-setter in setter */
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6583,NULL,3,t0,t1,t2);}
f_7151(t1,(C_word)C_a_i_list(&a,3,lf[33],t2,lf[34]));}

/* getter */
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[214],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6886,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[23]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,2,lf[24],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_caddr(t2);
t10=(C_word)C_a_i_list(&a,3,lf[23],lf[24],t9);
t11=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[26],t8,t11));}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[27]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[24],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_list(&a,2,lf[27],lf[24]);
t12=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_list(&a,3,lf[26],t10,t12));}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[28]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,2,lf[24],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(C_word)C_a_i_list(&a,2,lf[28],lf[24]);
t14=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[26],t12,t14));}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[29]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,2,lf[24],t12);
t14=(C_word)C_a_i_list(&a,1,t13);
t15=(C_word)C_a_i_list(&a,2,lf[29],lf[24]);
t16=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[26],t14,t16));}
else{
t12=(C_word)C_i_car(t2);
t13=(C_word)C_eqp(t12,lf[30]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t2);
t15=(C_word)C_a_i_list(&a,2,lf[24],t14);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(C_word)C_i_caddr(t2);
t18=(C_word)C_a_i_list(&a,3,lf[30],lf[24],t17);
t19=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t18);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[26],t16,t19));}
else{
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_assq(t14,((C_word*)t0)[2]);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t15)){
t17=(C_word)C_i_cadr(t15);
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,2,t17,t18);
t20=(C_word)C_a_i_list(&a,2,lf[24],t19);
t21=(C_word)C_a_i_list(&a,1,t20);
t22=(C_word)C_i_cddr(t15);
t23=(C_word)C_a_i_list(&a,2,t22,lf[24]);
t24=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t23);
t25=t16;
f_7055(t25,(C_word)C_a_i_list(&a,3,lf[26],t21,t24));}
else{
t17=t16;
f_7055(t17,C_SCHEME_FALSE);}}}}}}}
else{
t4=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,lf[31]);}}

/* k7053 in getter */
static void C_fcall f_7055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7055,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,2,lf[24],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t5,lf[24]);
t7=(C_word)C_a_i_list(&a,3,lf[25],C_SCHEME_END_OF_LIST,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[26],t4,t7));}}

/* symbol-append */
static void C_fcall f_7151(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7159,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7165,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a7164 in symbol-append */
static void f_7165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7165,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=*((C_word*)lf[18]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
C_number_to_string(3,0,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k7161 in symbol-append */
static void f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[17]+1),t1);}

/* k7157 in symbol-append */
static void f_7159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##match#set-error-control */
static void f_528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_528,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[9]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#set-error */
static void f_523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_523,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[7]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#syntax-err */
static void f_517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_517,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[4],t3,t2);}
/* end of file */
