/* Generated from support.scm by the Chicken compiler
   2005-09-24 22:23
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file support.c -explicit-use
   unit: support
*/

#include "chicken.h"

#define C_METHOD_CACHE_SIZE 8


static C_TLS C_word lf[709];


/* from k1954 */
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k1947 */
static C_word C_fcall stub131(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub131(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_externexport void C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_2775(C_word c,C_word t0,C_word t1) C_noret;
static void f_2778(C_word c,C_word t0,C_word t1) C_noret;
static void f_8335(C_word c,C_word t0,C_word t1) C_noret;
static void f_8400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8427(C_word c,C_word t0,C_word t1) C_noret;
static void f_8411(C_word c,C_word t0,C_word t1) C_noret;
static void f_8414(C_word c,C_word t0,C_word t1) C_noret;
static void f_8416(C_word c,C_word t0,C_word t1) C_noret;
static void f_8420(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8404(C_word t0,C_word t1) C_noret;
static void f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8374(C_word c,C_word t0,C_word t1) C_noret;
static void f_8398(C_word c,C_word t0,C_word t1) C_noret;
static void f_8384(C_word c,C_word t0,C_word t1) C_noret;
static void f_8388(C_word c,C_word t0,C_word t1) C_noret;
static void f_8359(C_word c,C_word t0,C_word t1) C_noret;
static void f_8367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8269(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8274(C_word t0,C_word t1) C_noret;
static void f_8278(C_word c,C_word t0,C_word t1) C_noret;
static void f_8329(C_word c,C_word t0,C_word t1) C_noret;
static void f_8308(C_word c,C_word t0,C_word t1) C_noret;
static void f_8320(C_word c,C_word t0,C_word t1) C_noret;
static void f_8323(C_word c,C_word t0,C_word t1) C_noret;
static void f_8296(C_word c,C_word t0,C_word t1) C_noret;
static void f_8096(C_word c,C_word t0,C_word t1) C_noret;
static void f_8099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8109(C_word c,C_word t0,C_word t1) C_noret;
static void f_8112(C_word c,C_word t0,C_word t1) C_noret;
static void f_8229(C_word c,C_word t0,C_word t1) C_noret;
static void f_8234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8219(C_word c,C_word t0,C_word t1) C_noret;
static void f_8209(C_word c,C_word t0,C_word t1) C_noret;
static void f_8198(C_word c,C_word t0,C_word t1) C_noret;
static void f_8115(C_word c,C_word t0,C_word t1) C_noret;
static void f_8118(C_word c,C_word t0,C_word t1) C_noret;
static void f_8121(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8132(C_word t0,C_word t1) C_noret;
static void C_fcall f_8140(C_word t0,C_word t1) C_noret;
static void f_8147(C_word c,C_word t0,C_word t1) C_noret;
static void f_8170(C_word c,C_word t0,C_word t1) C_noret;
static void f_8162(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8144(C_word t0,C_word t1) C_noret;
static void f_8136(C_word c,C_word t0,C_word t1) C_noret;
static void f_8128(C_word c,C_word t0,C_word t1) C_noret;
static void f_8009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8031(C_word c,C_word t0,C_word t1) C_noret;
static void f_8037(C_word c,C_word t0,C_word t1) C_noret;
static void f_8090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8040(C_word c,C_word t0,C_word t1) C_noret;
static void f_8055(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8063(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8073(C_word c,C_word t0,C_word t1) C_noret;
static void f_8058(C_word c,C_word t0,C_word t1) C_noret;
static void f_8046(C_word c,C_word t0,C_word t1) C_noret;
static void f_8013(C_word c,C_word t0,C_word t1) C_noret;
static void f_8003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7991(C_word c,C_word t0,C_word t1) C_noret;
static void f_7997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7983(C_word c,C_word t0,C_word t1) C_noret;
static void f_7900(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7900r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7919(C_word c,C_word t0,C_word t1) C_noret;
static void f_7944(C_word c,C_word t0,C_word t1) C_noret;
static void f_7948(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7957(C_word c,C_word t0,C_word t1) C_noret;
static void f_7970(C_word c,C_word t0,C_word t1) C_noret;
static void f_7974(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7903(C_word t0,C_word t1) C_noret;
static void f_7907(C_word c,C_word t0,C_word t1) C_noret;
static void f_7913(C_word c,C_word t0,C_word t1) C_noret;
static void f_7894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7850(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7850r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_7862(C_word c,C_word t0,C_word t1) C_noret;
static void f_7866(C_word c,C_word t0,C_word t1) C_noret;
static void f_7870(C_word c,C_word t0,C_word t1) C_noret;
static void f_7858(C_word c,C_word t0,C_word t1) C_noret;
static void f_7841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7808(C_word c,C_word t0,C_word t1) C_noret;
static void f_7812(C_word c,C_word t0,C_word t1) C_noret;
static void f_7815(C_word c,C_word t0,C_word t1) C_noret;
static void f_7770(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7770r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_7784(C_word c,C_word t0,C_word t1) C_noret;
static void f_7774(C_word c,C_word t0,C_word t1) C_noret;
static void f_7781(C_word c,C_word t0,C_word t1) C_noret;
static void f_7728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7709(C_word t0,C_word t1) C_noret;
static void f_7502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7630(C_word c,C_word t0,C_word t1) C_noret;
static void f_7675(C_word c,C_word t0,C_word t1) C_noret;
static void f_7679(C_word c,C_word t0,C_word t1) C_noret;
static void f_7633(C_word c,C_word t0,C_word t1) C_noret;
static void f_7638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7642(C_word c,C_word t0,C_word t1) C_noret;
static void f_7636(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7593(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7597(C_word c,C_word t0,C_word t1) C_noret;
static void f_7606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7610(C_word c,C_word t0,C_word t1) C_noret;
static void f_7600(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7558(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7564(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7591(C_word c,C_word t0,C_word t1) C_noret;
static void f_7577(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7511(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7517(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7556(C_word c,C_word t0,C_word t1) C_noret;
static void f_7538(C_word c,C_word t0,C_word t1) C_noret;
static void f_7343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7500(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7346(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7365(C_word t0,C_word t1) C_noret;
static void f_7449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7461(C_word c,C_word t0,C_word t1) C_noret;
static void f_7419(C_word c,C_word t0,C_word t1) C_noret;
static void f_7430(C_word c,C_word t0,C_word t1) C_noret;
static void f_7410(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7396(C_word t0,C_word t1) C_noret;
static void f_7384(C_word c,C_word t0,C_word t1) C_noret;
static void f_7265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7326(C_word t0,C_word t1) C_noret;
static void C_fcall f_7299(C_word t0,C_word t1) C_noret;
static void C_fcall f_7293(C_word t0,C_word t1) C_noret;
static void f_7269(C_word c,C_word t0,C_word t1) C_noret;
static void f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7208(C_word t0,C_word t1) C_noret;
static void C_fcall f_7167(C_word t0,C_word t1) C_noret;
static void C_fcall f_7120(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_7098(C_word *a,C_word t0,C_word t1);
static void f_6765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7021(C_word c,C_word t0,C_word t1) C_noret;
static void f_6777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6787(C_word t0,C_word t1) C_noret;
static void f_6805(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6839(C_word t0,C_word t1) C_noret;
static void C_fcall f_6768(C_word t0,C_word t1) C_noret;
static void f_6500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6759(C_word c,C_word t0,C_word t1) C_noret;
static void f_6506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6516(C_word t0,C_word t1) C_noret;
static void C_fcall f_6525(C_word t0,C_word t1) C_noret;
static void C_fcall f_6537(C_word t0,C_word t1) C_noret;
static void C_fcall f_6549(C_word t0,C_word t1) C_noret;
static void f_6555(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6589(C_word t0,C_word t1) C_noret;
static void f_6460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6494(C_word c,C_word t0,C_word t1) C_noret;
static void f_6466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6470(C_word c,C_word t0,C_word t1) C_noret;
static void f_6429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6442(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6433(C_word t0,C_word t1) C_noret;
static void f_6398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6411(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6402(C_word t0,C_word t1) C_noret;
static void f_5639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6392(C_word c,C_word t0,C_word t1) C_noret;
static void f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5676(C_word t0,C_word t1) C_noret;
static void C_fcall f_5691(C_word t0,C_word t1) C_noret;
static void C_fcall f_5706(C_word t0,C_word t1) C_noret;
static void C_fcall f_5744(C_word t0,C_word t1) C_noret;
static void C_fcall f_5759(C_word t0,C_word t1) C_noret;
static void C_fcall f_5801(C_word t0,C_word t1) C_noret;
static void f_5987(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6159(C_word t0,C_word t1) C_noret;
static void C_fcall f_6047(C_word t0,C_word t1) C_noret;
static void f_6051(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6015(C_word t0,C_word t1) C_noret;
static void f_6019(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_6010(C_word *a,C_word t0);
static void f_5902(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5917(C_word t0,C_word t1) C_noret;
static void f_5858(C_word c,C_word t0,C_word t1) C_noret;
static void f_5762(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5777(C_word t0,C_word t1) C_noret;
static void f_5709(C_word c,C_word t0,C_word t1) C_noret;
static void f_5603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5607(C_word c,C_word t0,C_word t1) C_noret;
static void f_5618(C_word c,C_word t0,C_word t1) C_noret;
static void f_5624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5628(C_word c,C_word t0,C_word t1) C_noret;
static void f_5610(C_word c,C_word t0,C_word t1) C_noret;
static void f_5564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_5583(C_word c,C_word t0,C_word t1) C_noret;
static void f_5586(C_word c,C_word t0,C_word t1) C_noret;
static void f_5589(C_word c,C_word t0,C_word t1) C_noret;
static void f_5592(C_word c,C_word t0,C_word t1) C_noret;
static void f_5595(C_word c,C_word t0,C_word t1) C_noret;
static void f_5598(C_word c,C_word t0,C_word t1) C_noret;
static void f_5570(C_word c,C_word t0,C_word t1) C_noret;
static void f_5484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5488(C_word c,C_word t0,C_word t1) C_noret;
static void f_5440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5469(C_word t0,C_word t1) C_noret;
static void f_5462(C_word c,C_word t0,C_word t1) C_noret;
static void f_5466(C_word c,C_word t0,C_word t1) C_noret;
static void f_5447(C_word c,C_word t0,C_word t1) C_noret;
static void f_5452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5422(C_word t0,C_word t1) C_noret;
static void f_5425(C_word c,C_word t0,C_word t1) C_noret;
static void f_5360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5376(C_word t0,C_word t1) C_noret;
static void f_5379(C_word c,C_word t0,C_word t1) C_noret;
static void f_5268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5204(C_word t0,C_word t1) C_noret;
static void f_5218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5226(C_word c,C_word t0,C_word t1) C_noret;
static void f_4987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5166(C_word c,C_word t0,C_word t1) C_noret;
static void f_5172(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5084(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5128(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5019(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5041(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4990(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5014(C_word c,C_word t0,C_word t1) C_noret;
static void f_4925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4929(C_word c,C_word t0,C_word t1) C_noret;
static void f_4932(C_word c,C_word t0,C_word t1) C_noret;
static void f_4935(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_4946(C_word t0,C_word t1);
static void f_4891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4911(C_word c,C_word t0,C_word t1) C_noret;
static void f_4915(C_word c,C_word t0,C_word t1) C_noret;
static void f_4713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4717(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4725(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4874(C_word c,C_word t0,C_word t1) C_noret;
static void f_4882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4877(C_word c,C_word t0,C_word t1) C_noret;
static void f_4826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4830(C_word c,C_word t0,C_word t1) C_noret;
static void f_4833(C_word c,C_word t0,C_word t1) C_noret;
static void f_4868(C_word c,C_word t0,C_word t1) C_noret;
static void f_4860(C_word c,C_word t0,C_word t1) C_noret;
static void f_4844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4839(C_word c,C_word t0,C_word t1) C_noret;
static void f_4793(C_word c,C_word t0,C_word t1) C_noret;
static void f_4796(C_word c,C_word t0,C_word t1) C_noret;
static void f_4807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4802(C_word c,C_word t0,C_word t1) C_noret;
static void f_4777(C_word c,C_word t0,C_word t1) C_noret;
static void f_4769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4764(C_word c,C_word t0,C_word t1) C_noret;
static void f_4748(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4642(C_word c,C_word t0,C_word t1) C_noret;
static void f_4645(C_word c,C_word t0,C_word t1) C_noret;
static void f_4705(C_word c,C_word t0,C_word t1) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4664(C_word t0,C_word t1) C_noret;
static void f_4668(C_word c,C_word t0,C_word t1) C_noret;
static void f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4632(C_word c,C_word t0,C_word t1) C_noret;
static void f_4572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4578(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4598(C_word c,C_word t0,C_word t1) C_noret;
static void f_4602(C_word c,C_word t0,C_word t1) C_noret;
static void f_4278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4303(C_word t0,C_word t1) C_noret;
static void C_fcall f_4513(C_word t0,C_word t1) C_noret;
static void f_4543(C_word c,C_word t0,C_word t1) C_noret;
static void f_4539(C_word c,C_word t0,C_word t1) C_noret;
static void f_4520(C_word c,C_word t0,C_word t1) C_noret;
static void f_4524(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4500(C_word c,C_word t0,C_word t1) C_noret;
static void f_4473(C_word c,C_word t0,C_word t1) C_noret;
static void f_4477(C_word c,C_word t0,C_word t1) C_noret;
static void f_4435(C_word c,C_word t0,C_word t1) C_noret;
static void f_4402(C_word c,C_word t0,C_word t1) C_noret;
static void f_4381(C_word c,C_word t0,C_word t1) C_noret;
static void f_4377(C_word c,C_word t0,C_word t1) C_noret;
static void f_4365(C_word c,C_word t0,C_word t1) C_noret;
static void f_4373(C_word c,C_word t0,C_word t1) C_noret;
static void f_4369(C_word c,C_word t0,C_word t1) C_noret;
static void f_4327(C_word c,C_word t0,C_word t1) C_noret;
static void f_4323(C_word c,C_word t0,C_word t1) C_noret;
static void f_4310(C_word c,C_word t0,C_word t1) C_noret;
static void f_3751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4273(C_word c,C_word t0,C_word t1) C_noret;
static void f_4276(C_word c,C_word t0,C_word t1) C_noret;
static void f_3754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4263(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4002(C_word t0,C_word t1) C_noret;
static void C_fcall f_4124(C_word t0,C_word t1) C_noret;
static void f_4167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4181(C_word t0,C_word t1) C_noret;
static void f_4188(C_word c,C_word t0,C_word t1) C_noret;
static void f_4191(C_word c,C_word t0,C_word t1) C_noret;
static void f_4209(C_word c,C_word t0,C_word t1) C_noret;
static void f_4198(C_word c,C_word t0,C_word t1) C_noret;
static void f_4202(C_word c,C_word t0,C_word t1) C_noret;
static void f_4185(C_word c,C_word t0,C_word t1) C_noret;
static void f_4174(C_word c,C_word t0,C_word t1) C_noret;
static void f_4161(C_word c,C_word t0,C_word t1) C_noret;
static void f_4149(C_word c,C_word t0,C_word t1) C_noret;
static void f_4133(C_word c,C_word t0,C_word t1) C_noret;
static void f_4103(C_word c,C_word t0,C_word t1) C_noret;
static void f_4087(C_word c,C_word t0,C_word t1) C_noret;
static void f_4083(C_word c,C_word t0,C_word t1) C_noret;
static void f_4050(C_word c,C_word t0,C_word t1) C_noret;
static void f_4011(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3980(C_word t0,C_word t1) C_noret;
static void f_3966(C_word c,C_word t0,C_word t1) C_noret;
static void f_3940(C_word c,C_word t0,C_word t1) C_noret;
static void f_3889(C_word c,C_word t0,C_word t1) C_noret;
static void f_3909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3899(C_word c,C_word t0,C_word t1) C_noret;
static void f_3907(C_word c,C_word t0,C_word t1) C_noret;
static void f_3892(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3839(C_word t0,C_word t1) C_noret;
static void f_3842(C_word c,C_word t0,C_word t1) C_noret;
static void f_3849(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3836(C_word t0,C_word t1) C_noret;
static void f_3813(C_word c,C_word t0,C_word t1) C_noret;
static void f_3742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3290(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3370(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3380(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3396(C_word t0,C_word t1) C_noret;
static void C_fcall f_3453(C_word t0,C_word t1) C_noret;
static void f_3484(C_word c,C_word t0,C_word t1) C_noret;
static void f_3474(C_word c,C_word t0,C_word t1) C_noret;
static void f_3460(C_word c,C_word t0,C_word t1) C_noret;
static void f_3464(C_word c,C_word t0,C_word t1) C_noret;
static void f_3444(C_word c,C_word t0,C_word t1) C_noret;
static void f_3434(C_word c,C_word t0,C_word t1) C_noret;
static void f_3411(C_word c,C_word t0,C_word t1) C_noret;
static void f_3383(C_word c,C_word t0,C_word t1) C_noret;
static void f_3293(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3328(C_word t0,C_word t1) C_noret;
static void f_3296(C_word c,C_word t0,C_word t1) C_noret;
static void f_3299(C_word c,C_word t0,C_word t1) C_noret;
static void f_3302(C_word c,C_word t0,C_word t1) C_noret;
static void f_3261(C_word c,C_word t0,C_word t1) C_noret;
static void f_3267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3278(C_word c,C_word t0,C_word t1) C_noret;
static void f_3237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3253(C_word c,C_word t0,C_word t1) C_noret;
static void f_3201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3208(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3211(C_word t0,C_word t1) C_noret;
static void f_3191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_3134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_3138(C_word c,C_word t0,C_word t1) C_noret;
static void f_3168(C_word c,C_word t0,C_word t1) C_noret;
static void f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3086(C_word c,C_word t0,C_word t1) C_noret;
static void f_3113(C_word c,C_word t0,C_word t1) C_noret;
static void f_3036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3040(C_word c,C_word t0,C_word t1) C_noret;
static void f_3062(C_word c,C_word t0,C_word t1) C_noret;
static void f_3018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3018r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3022(C_word c,C_word t0,C_word t1) C_noret;
static void f_3030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3004(C_word c,C_word t0,C_word t1) C_noret;
static void f_2939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2980(C_word c,C_word t0,C_word t1) C_noret;
static void f_2983(C_word c,C_word t0,C_word t1) C_noret;
static void f_2943(C_word c,C_word t0,C_word t1) C_noret;
static void f_2961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2965(C_word c,C_word t0,C_word t1) C_noret;
static void f_2946(C_word c,C_word t0,C_word t1) C_noret;
static void f_2951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2886(C_word c,C_word t0,C_word t1) C_noret;
static void f_2890(C_word c,C_word t0,C_word t1) C_noret;
static void f_2779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2819(C_word c,C_word t0,C_word t1) C_noret;
static void f_2869(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2869r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2875(C_word c,C_word t0,C_word t1) C_noret;
static void f_2825(C_word c,C_word t0,C_word t1) C_noret;
static void f_2853(C_word c,C_word t0,C_word t1) C_noret;
static void f_2867(C_word c,C_word t0,C_word t1) C_noret;
static void f_2859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2829(C_word c,C_word t0,C_word t1) C_noret;
static void f_2794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2800(C_word c,C_word t0,C_word t1) C_noret;
static void f_2811(C_word c,C_word t0,C_word t1) C_noret;
static void f_2808(C_word c,C_word t0,C_word t1) C_noret;
static void f_2786(C_word c,C_word t0,C_word t1) C_noret;
static void f_2404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2768(C_word c,C_word t0,C_word t1) C_noret;
static void f_2407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2612(C_word t0,C_word t1) C_noret;
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2722(C_word c,C_word t0,C_word t1) C_noret;
static void f_2718(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2668(C_word t0,C_word t1) C_noret;
static void f_2691(C_word c,C_word t0,C_word t1) C_noret;
static void f_2687(C_word c,C_word t0,C_word t1) C_noret;
static void f_2631(C_word c,C_word t0,C_word t1) C_noret;
static void f_2634(C_word c,C_word t0,C_word t1) C_noret;
static void f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2662(C_word c,C_word t0,C_word t1) C_noret;
static void f_2648(C_word c,C_word t0,C_word t1) C_noret;
static void f_2652(C_word c,C_word t0,C_word t1) C_noret;
static void f_2644(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2561(C_word t0,C_word t1) C_noret;
static void f_2581(C_word c,C_word t0,C_word t1) C_noret;
static void f_2573(C_word c,C_word t0,C_word t1) C_noret;
static void f_2577(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2409(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2419(C_word t0,C_word t1) C_noret;
static void C_fcall f_2428(C_word t0,C_word t1) C_noret;
static void C_fcall f_2452(C_word t0,C_word t1) C_noret;
static void f_2459(C_word c,C_word t0,C_word t1) C_noret;
static void f_2439(C_word c,C_word t0,C_word t1) C_noret;
static void f_2321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2392(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2355(C_word t0,C_word t1) C_noret;
static void f_2385(C_word c,C_word t0,C_word t1) C_noret;
static void f_2373(C_word c,C_word t0,C_word t1) C_noret;
static void f_2223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2249(C_word t0,C_word t1) C_noret;
static void f_2292(C_word c,C_word t0,C_word t1) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void f_2227(C_word c,C_word t0,C_word t1) C_noret;
static void f_2187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2031(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2033(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2062(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2041(C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1958(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1958r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1974(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1986(C_word t0,C_word t1) C_noret;
static void f_1951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1942(C_word c,C_word t0,C_word t1) C_noret;
static void f_1892(C_word c,C_word t0,C_word t1) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1810(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1812(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1834(C_word t0,C_word t1) C_noret;
static void f_1873(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1841(C_word t0,C_word t1) C_noret;
static void f_1857(C_word c,C_word t0,C_word t1) C_noret;
static void f_1845(C_word c,C_word t0,C_word t1) C_noret;
static void f_1849(C_word c,C_word t0,C_word t1) C_noret;
static void f_1806(C_word c,C_word t0,C_word t1) C_noret;
static void f_1750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_1756(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1780(C_word c,C_word t0,C_word t1) C_noret;
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1732(C_word c,C_word t0,C_word t1) C_noret;
static void f_1688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1658(C_word t0,C_word t1,C_word t2);
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_1608(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1587(C_word t0,C_word t1) C_noret;
static void f_1595(C_word c,C_word t0,C_word t1) C_noret;
static void f_1599(C_word c,C_word t0,C_word t1) C_noret;
static void f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1) C_noret;
static void f_1517(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1517r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1521(C_word c,C_word t0,C_word t1) C_noret;
static void f_1524(C_word c,C_word t0,C_word t1) C_noret;
static void f_1532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1536(C_word c,C_word t0,C_word t1) C_noret;
static void f_1527(C_word c,C_word t0,C_word t1) C_noret;
static void f_1498(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1498r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1502(C_word c,C_word t0,C_word t1) C_noret;
static void f_1515(C_word c,C_word t0,C_word t1) C_noret;
static void f_1505(C_word c,C_word t0,C_word t1) C_noret;
static void f_1508(C_word c,C_word t0,C_word t1) C_noret;
static void f_1479(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1479r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1486(C_word c,C_word t0,C_word t1) C_noret;
static void f_1496(C_word c,C_word t0,C_word t1) C_noret;
static void f_1489(C_word c,C_word t0,C_word t1) C_noret;
static void f_1439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1439r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1449(C_word c,C_word t0,C_word t1) C_noret;
static void f_1464(C_word c,C_word t0,C_word t1) C_noret;
static void f_1469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1477(C_word c,C_word t0,C_word t1) C_noret;
static void f_1452(C_word c,C_word t0,C_word t1) C_noret;
static void f_1455(C_word c,C_word t0,C_word t1) C_noret;
static void f_1458(C_word c,C_word t0,C_word t1) C_noret;
static void f_1412(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1412r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1426(C_word c,C_word t0,C_word t1) C_noret;
static void f_1407(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_8404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8404(t0,t1);}

static void C_fcall trf_8274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8274(t0,t1);}

static void C_fcall trf_8132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8132(t0,t1);}

static void C_fcall trf_8140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8140(t0,t1);}

static void C_fcall trf_8144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8144(t0,t1);}

static void C_fcall trf_8018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8018(t0,t1,t2,t3);}

static void C_fcall trf_8063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8063(t0,t1,t2);}

static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7950(t0,t1,t2,t3);}

static void C_fcall trf_7903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7903(t0,t1);}

static void C_fcall trf_7737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7737(t0,t1,t2);}

static void C_fcall trf_7709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7709(t0,t1);}

static void C_fcall trf_7593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7593(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7593(t0,t1,t2,t3);}

static void C_fcall trf_7558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7558(t0,t1,t2);}

static void C_fcall trf_7564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7564(t0,t1,t2);}

static void C_fcall trf_7511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7511(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7511(t0,t1,t2,t3);}

static void C_fcall trf_7517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7517(t0,t1,t2);}

static void C_fcall trf_7487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7487(t0,t1,t2,t3);}

static void C_fcall trf_7346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7346(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7346(t0,t1,t2,t3);}

static void C_fcall trf_7365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7365(t0,t1);}

static void C_fcall trf_7396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7396(t0,t1);}

static void C_fcall trf_7326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7326(t0,t1);}

static void C_fcall trf_7299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7299(t0,t1);}

static void C_fcall trf_7293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7293(t0,t1);}

static void C_fcall trf_7208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7208(t0,t1);}

static void C_fcall trf_7167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7167(t0,t1);}

static void C_fcall trf_7120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7120(t0,t1);}

static void C_fcall trf_6787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6787(t0,t1);}

static void C_fcall trf_6839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6839(t0,t1);}

static void C_fcall trf_6768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6768(t0,t1);}

static void C_fcall trf_6516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6516(t0,t1);}

static void C_fcall trf_6525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6525(t0,t1);}

static void C_fcall trf_6537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6537(t0,t1);}

static void C_fcall trf_6549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6549(t0,t1);}

static void C_fcall trf_6589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6589(t0,t1);}

static void C_fcall trf_6433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6433(t0,t1);}

static void C_fcall trf_6402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6402(t0,t1);}

static void C_fcall trf_5651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5651(t0,t1,t2);}

static void C_fcall trf_5676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5676(t0,t1);}

static void C_fcall trf_5691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5691(t0,t1);}

static void C_fcall trf_5706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5706(t0,t1);}

static void C_fcall trf_5744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5744(t0,t1);}

static void C_fcall trf_5759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5759(t0,t1);}

static void C_fcall trf_5801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5801(t0,t1);}

static void C_fcall trf_6159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6159(t0,t1);}

static void C_fcall trf_6047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6047(t0,t1);}

static void C_fcall trf_6015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6015(t0,t1);}

static void C_fcall trf_5917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5917(t0,t1);}

static void C_fcall trf_5777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5777(t0,t1);}

static void C_fcall trf_5469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5469(t0,t1);}

static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5422(t0,t1);}

static void C_fcall trf_5376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5376(t0,t1);}

static void C_fcall trf_5204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5204(t0,t1);}

static void C_fcall trf_5062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5062(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5062(t0,t1,t2,t3);}

static void C_fcall trf_5097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5097(t0,t1,t2,t3);}

static void C_fcall trf_5019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5019(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5019(t0,t1,t2,t3);}

static void C_fcall trf_4990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4990(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4990(t0,t1,t2,t3);}

static void C_fcall trf_4897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4897(t0,t1,t2);}

static void C_fcall trf_4725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4725(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4725(t0,t1,t2,t3);}

static void C_fcall trf_4719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4719(t0,t1,t2);}

static void C_fcall trf_4664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4664(t0,t1);}

static void C_fcall trf_4578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4578(t0,t1,t2);}

static void C_fcall trf_4303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4303(t0,t1);}

static void C_fcall trf_4513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4513(t0,t1);}

static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4459(t0,t1,t2,t3,t4);}

static void C_fcall trf_4002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4002(t0,t1);}

static void C_fcall trf_4124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4124(t0,t1);}

static void C_fcall trf_4181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4181(t0,t1);}

static void C_fcall trf_3980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3980(t0,t1);}

static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3839(t0,t1);}

static void C_fcall trf_3836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3836(t0,t1);}

static void C_fcall trf_3370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3370(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3370(t0,t1,t2);}

static void C_fcall trf_3396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3396(t0,t1);}

static void C_fcall trf_3453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3453(t0,t1);}

static void C_fcall trf_3328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3328(t0,t1);}

static void C_fcall trf_3243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3243(t0,t1,t2);}

static void C_fcall trf_3211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3211(t0,t1);}

static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2612(t0,t1);}

static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2621(t0,t1,t2,t3,t4);}

static void C_fcall trf_2668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2668(t0,t1);}

static void C_fcall trf_2561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2561(t0,t1);}

static void C_fcall trf_2409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2409(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2409(t0,t1,t2,t3);}

static void C_fcall trf_2419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2419(t0,t1);}

static void C_fcall trf_2428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2428(t0,t1);}

static void C_fcall trf_2452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2452(t0,t1);}

static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2327(t0,t1,t2);}

static void C_fcall trf_2355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2355(t0,t1);}

static void C_fcall trf_2249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2249(t0,t1);}

static void C_fcall trf_2086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2086(t0,t1,t2,t3);}

static void C_fcall trf_2033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2033(t0,t1,t2);}

static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2041(t0,t1);}

static void C_fcall trf_1986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1986(t0,t1);}

static void C_fcall trf_1812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1812(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1812(t0,t1,t2);}

static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1834(t0,t1);}

static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1841(t0,t1);}

static void C_fcall trf_1756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1756(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1756(t0,t1,t2,t3);}

static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1608(t0,t1,t2,t3);}

static void C_fcall trf_1587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1587(t0,t1);}

static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1547(t0,t1,t2);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(84);
if(!C_demand(84)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4629)){
C_save(t1);
C_rereclaim2(4629*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(84);
C_initialize_lf(lf,709);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[11]=C_h_pair(C_restore,tmp);
lf[13]=C_static_string(C_heaptop,6,".dylib");
lf[15]=C_static_string(C_heaptop,4,".dll");
lf[17]=C_static_string(C_heaptop,3,".sl");
lf[19]=C_static_string(C_heaptop,3,".so");
lf[21]=C_static_string(C_heaptop,4,".scm");
lf[23]=C_static_string(C_heaptop,6,".setup");
lf[25]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[27]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[29]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[31]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[33]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[35]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[37]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[39]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[41]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[42]=C_h_intern(&lf[42],15,"\010compilerbanner");
lf[43]=C_static_string(C_heaptop,125,"  _______   _     __          \012 / ___/ /  (_)___/ /_____ ___ \012/ /__/ _ \134/ / __/ "
" \047_/ -_) _ \134\012\134___/_//_/_/\134__/_/\134_\134\134__/_//_/\012\012");
lf[44]=C_h_intern(&lf[44],30,"\010compilercompiler-cleanup-hook");
lf[45]=C_static_lambda_info(C_heaptop,8,"(f_1407)");
lf[46]=C_h_intern(&lf[46],26,"\010compilerdebugging-chicken");
lf[47]=C_h_intern(&lf[47],25,"\010compilerwarnings-enabled");
lf[48]=C_h_intern(&lf[48],13,"\010compilerbomb");
lf[49]=C_h_intern(&lf[49],5,"error");
lf[50]=C_h_intern(&lf[50],13,"string-append");
lf[51]=C_static_string(C_heaptop,28,"[internal compiler screwup] ");
lf[52]=C_static_string(C_heaptop,27,"[internal compiler screwup]");
lf[53]=C_static_lambda_info(C_heaptop,34,"(##compiler#bomb . msg-and-args48)");
lf[54]=C_h_intern(&lf[54],18,"\010compilerdebugging");
lf[55]=C_h_intern(&lf[55],12,"flush-output");
lf[56]=C_h_intern(&lf[56],7,"newline");
lf[57]=C_h_intern(&lf[57],6,"printf");
lf[58]=C_static_string(C_heaptop,3,"~s ");
lf[59]=C_h_intern(&lf[59],5,"force");
lf[60]=C_static_lambda_info(C_heaptop,11,"(a1468 x52)");
lf[61]=C_h_intern(&lf[61],12,"\003sysfor-each");
lf[62]=C_h_intern(&lf[62],7,"display");
lf[63]=C_static_string(C_heaptop,2,": ");
lf[64]=C_static_string(C_heaptop,2,"~a");
lf[65]=C_static_lambda_info(C_heaptop,44,"(##compiler#debugging mode49 msg50 . args51)");
lf[66]=C_h_intern(&lf[66],7,"warning");
lf[67]=C_h_intern(&lf[67],7,"fprintf");
lf[68]=C_static_string(C_heaptop,9,"Warning: ");
lf[69]=C_h_intern(&lf[69],18,"current-error-port");
lf[70]=C_static_lambda_info(C_heaptop,24,"(warning msg58 . args59)");
lf[71]=C_h_intern(&lf[71],4,"quit");
lf[72]=C_h_intern(&lf[72],4,"exit");
lf[73]=C_static_string(C_heaptop,7,"Error: ");
lf[74]=C_static_lambda_info(C_heaptop,21,"(quit msg62 . args63)");
lf[75]=C_h_intern(&lf[75],21,"\003syssyntax-error-hook");
lf[76]=C_h_intern(&lf[76],5,"write");
lf[77]=C_static_lambda_info(C_heaptop,11,"(a1531 x70)");
lf[78]=C_static_string(C_heaptop,18,"Syntax error: ~a~%");
lf[79]=C_static_lambda_info(C_heaptop,40,"(##sys#syntax-error-hook msg67 . args68)");
lf[80]=C_h_intern(&lf[80],9,"map-llist");
lf[81]=C_static_lambda_info(C_heaptop,14,"(loop llist77)");
lf[82]=C_static_lambda_info(C_heaptop,26,"(map-llist proc74 llist75)");
lf[83]=C_h_intern(&lf[83],24,"\010compilercheck-signature");
lf[84]=C_static_string(C_heaptop,64,"Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[85]=C_h_intern(&lf[85],18,"\010compilerreal-name");
lf[86]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[87]=C_static_lambda_info(C_heaptop,16,"(loop as84 ll85)");
lf[88]=C_static_lambda_info(C_heaptop,49,"(##compiler#check-signature var79 args80 llist81)");
lf[89]=C_h_intern(&lf[89],13,"\010compilerposq");
lf[90]=C_static_lambda_info(C_heaptop,10,"(loop i94)");
lf[91]=C_static_lambda_info(C_heaptop,27,"(##compiler#posq x90 lst91)");
lf[92]=C_h_intern(&lf[92],18,"\010compilerstringify");
lf[93]=C_h_intern(&lf[93],14,"symbol->string");
lf[94]=C_h_intern(&lf[94],7,"sprintf");
lf[95]=C_static_string(C_heaptop,2,"~a");
lf[96]=C_static_lambda_info(C_heaptop,26,"(##compiler#stringify x96)");
lf[97]=C_h_intern(&lf[97],18,"\010compilersymbolify");
lf[98]=C_h_intern(&lf[98],14,"string->symbol");
lf[99]=C_static_string(C_heaptop,2,"~a");
lf[100]=C_static_lambda_info(C_heaptop,26,"(##compiler#symbolify x97)");
lf[101]=C_h_intern(&lf[101],16,"\010compilerflonum\077");
lf[102]=C_static_lambda_info(C_heaptop,24,"(##compiler#flonum\077 x98)");
lf[103]=C_h_intern(&lf[103],26,"\010compilerbuild-lambda-list");
lf[104]=C_static_lambda_info(C_heaptop,19,"(loop vars103 n104)");
lf[105]=C_static_lambda_info(C_heaptop,53,"(##compiler#build-lambda-list vars99 argc100 rest101)");
lf[106]=C_h_intern(&lf[106],29,"\010compilerstring->c-identifier");
lf[107]=C_h_intern(&lf[107],24,"\003sysstring->c-identifier");
lf[108]=C_h_intern(&lf[108],21,"\010compilerc-ify-string");
lf[109]=C_h_intern(&lf[109],12,"list->string");
tmp=C_make_character(34);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[110]=C_h_pair(C_restore,tmp);
lf[111]=C_h_intern(&lf[111],6,"append");
tmp=C_make_character(92);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[112]=C_h_pair(C_restore,tmp);
lf[113]=C_h_intern(&lf[113],12,"string->list");
tmp=C_make_character(48);
C_save(tmp);
tmp=C_make_character(48);
C_save(tmp);
lf[114]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_make_character(48);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[115]=C_h_pair(C_restore,tmp);
tmp=C_make_character(34);
C_save(tmp);
tmp=C_make_character(39);
C_save(tmp);
tmp=C_make_character(92);
C_save(tmp);
tmp=C_make_character(63);
C_save(tmp);
lf[116]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[117]=C_static_lambda_info(C_heaptop,15,"(loop chars112)");
lf[118]=C_static_lambda_info(C_heaptop,32,"(##compiler#c-ify-string str110)");
lf[119]=C_h_intern(&lf[119],28,"\010compilervalid-c-identifier\077");
lf[120]=C_static_lambda_info(C_heaptop,12,"(a1914 c125)");
lf[121]=C_h_intern(&lf[121],3,"any");
lf[122]=C_h_intern(&lf[122],8,"->string");
lf[123]=C_static_lambda_info(C_heaptop,40,"(##compiler#valid-c-identifier\077 name120)");
lf[124]=C_h_intern(&lf[124],14,"\010compilerwords");
lf[125]=C_static_lambda_info(C_heaptop,26,"(##compiler#words a130133)");
lf[126]=C_h_intern(&lf[126],21,"\010compilerwords->bytes");
lf[127]=C_static_lambda_info(C_heaptop,33,"(##compiler#words->bytes a134137)");
lf[128]=C_h_intern(&lf[128],34,"\010compilercheck-and-open-input-file");
lf[129]=C_static_string(C_heaptop,1,"-");
lf[130]=C_h_intern(&lf[130],18,"current-input-port");
lf[131]=C_h_intern(&lf[131],15,"open-input-file");
lf[132]=C_static_string(C_heaptop,20,"Can not open file ~s");
lf[133]=C_static_string(C_heaptop,31,"Can not open file ~s in line ~s");
lf[134]=C_h_intern(&lf[134],12,"file-exists\077");
lf[135]=C_static_lambda_info(C_heaptop,57,"(##compiler#check-and-open-input-file fname139 . line140)");
lf[136]=C_h_intern(&lf[136],33,"\010compilerclose-checked-input-file");
lf[137]=C_static_string(C_heaptop,1,"-");
lf[138]=C_h_intern(&lf[138],16,"close-input-port");
lf[139]=C_static_lambda_info(C_heaptop,54,"(##compiler#close-checked-input-file port143 fname144)");
lf[140]=C_h_intern(&lf[140],19,"\010compilerfold-inner");
lf[141]=C_static_lambda_info(C_heaptop,12,"(fold xs148)");
lf[142]=C_h_intern(&lf[142],7,"reverse");
lf[143]=C_static_lambda_info(C_heaptop,38,"(##compiler#fold-inner proc145 lst146)");
lf[144]=C_h_intern(&lf[144],28,"\010compilerfollow-without-loop");
lf[145]=C_static_lambda_info(C_heaptop,13,"(a2100 x2156)");
lf[146]=C_static_lambda_info(C_heaptop,19,"(loop x154 done155)");
lf[147]=C_static_lambda_info(C_heaptop,57,"(##compiler#follow-without-loop seed150 proc151 abort152)");
lf[148]=C_h_intern(&lf[148],18,"\010compilerconstant\077");
lf[149]=C_h_intern(&lf[149],5,"quote");
lf[150]=C_static_lambda_info(C_heaptop,27,"(##compiler#constant\077 x158)");
lf[151]=C_h_intern(&lf[151],29,"\010compilercollapsable-literal\077");
lf[152]=C_static_lambda_info(C_heaptop,38,"(##compiler#collapsable-literal\077 x169)");
lf[153]=C_h_intern(&lf[153],19,"\010compilerimmediate\077");
lf[154]=C_static_lambda_info(C_heaptop,28,"(##compiler#immediate\077 x178)");
lf[155]=C_h_intern(&lf[155],29,"\010compilercompressable-literal");
lf[156]=C_h_intern(&lf[156],5,"every");
lf[157]=C_h_intern(&lf[157],12,"vector->list");
lf[158]=C_static_lambda_info(C_heaptop,10,"(rec x194)");
lf[159]=C_static_lambda_info(C_heaptop,45,"(##compiler#compressable-literal lit189 t190)");
lf[160]=C_h_intern(&lf[160],32,"\010compilercanonicalize-begin-body");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[161]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[162]=C_h_pair(C_restore,tmp);
lf[163]=C_h_intern(&lf[163],3,"let");
lf[164]=C_h_intern(&lf[164],6,"gensym");
lf[165]=C_h_intern(&lf[165],1,"t");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[166]=C_h_pair(C_restore,tmp);
lf[167]=C_static_lambda_info(C_heaptop,12,"(loop xs212)");
lf[168]=C_static_lambda_info(C_heaptop,44,"(##compiler#canonicalize-begin-body body210)");
lf[169]=C_h_intern(&lf[169],34,"\010compilerextract-mutable-constants");
lf[170]=C_h_intern(&lf[170],12,"\004coreinclude");
lf[171]=C_h_intern(&lf[171],9,"\004coreset!");
lf[172]=C_h_intern(&lf[172],5,"cons*");
lf[173]=C_h_intern(&lf[173],7,"\003sysmap");
lf[174]=C_h_intern(&lf[174],2,"if");
lf[175]=C_h_intern(&lf[175],20,"\004corecompiletimeonly");
lf[176]=C_h_intern(&lf[176],19,"\004corecompiletimetoo");
lf[177]=C_h_intern(&lf[177],4,"set!");
lf[178]=C_h_intern(&lf[178],6,"lambda");
lf[179]=C_h_intern(&lf[179],11,"\004coreinline");
lf[180]=C_h_intern(&lf[180],20,"\004coreinline_allocate");
lf[181]=C_h_intern(&lf[181],18,"\004coreinline_update");
lf[182]=C_h_intern(&lf[182],19,"\004coreinline_loc_ref");
lf[183]=C_h_intern(&lf[183],22,"\004coreinline_loc_update");
lf[184]=C_h_intern(&lf[184],12,"\004coredeclare");
lf[185]=C_h_intern(&lf[185],14,"\004coreimmutable");
lf[186]=C_h_intern(&lf[186],14,"\004coreundefined");
lf[187]=C_h_intern(&lf[187],14,"\004coreprimitive");
lf[188]=C_h_intern(&lf[188],15,"\004coreinline_ref");
lf[189]=C_static_lambda_info(C_heaptop,20,"(g231 op235 args236)");
lf[190]=C_h_intern(&lf[190],10,"alist-cons");
lf[191]=C_h_intern(&lf[191],25,"\010compilermake-random-name");
lf[192]=C_h_intern(&lf[192],8,"\003syscons");
lf[193]=C_static_lambda_info(C_heaptop,21,"(a2653 var278 val279)");
lf[194]=C_h_intern(&lf[194],3,"map");
lf[195]=C_h_intern(&lf[195],4,"caar");
lf[196]=C_h_intern(&lf[196],5,"cadar");
lf[197]=C_h_intern(&lf[197],5,"cddar");
lf[198]=C_h_intern(&lf[198],4,"cdar");
lf[199]=C_static_lambda_info(C_heaptop,30,"(g226 g227272 g228273 g229274)");
lf[200]=C_static_lambda_info(C_heaptop,11,"(walk x222)");
lf[201]=C_static_lambda_info(C_heaptop,45,"(##compiler#extract-mutable-constants exp219)");
lf[202]=C_h_intern(&lf[202],21,"\010compilerstring->expr");
lf[203]=C_static_string(C_heaptop,35,"can not parse expression: ~s [~a]~%");
lf[204]=C_static_lambda_info(C_heaptop,7,"(a2799)");
lf[205]=C_static_lambda_info(C_heaptop,13,"(a2793 ex289)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[206]=C_h_pair(C_restore,tmp);
lf[207]=C_h_intern(&lf[207],5,"begin");
lf[208]=C_h_intern(&lf[208],4,"read");
lf[209]=C_static_lambda_info(C_heaptop,12,"(a2858 x291)");
lf[210]=C_h_intern(&lf[210],6,"unfold");
lf[211]=C_h_intern(&lf[211],11,"eof-object\077");
lf[212]=C_h_intern(&lf[212],6,"values");
lf[213]=C_static_lambda_info(C_heaptop,7,"(a2852)");
lf[214]=C_h_intern(&lf[214],22,"with-input-from-string");
lf[215]=C_static_lambda_info(C_heaptop,7,"(a2824)");
lf[216]=C_static_lambda_info(C_heaptop,7,"(a2874)");
lf[217]=C_static_lambda_info(C_heaptop,17,"(a2868 . g287292)");
lf[218]=C_static_lambda_info(C_heaptop,7,"(a2818)");
lf[219]=C_h_intern(&lf[219],22,"with-exception-handler");
lf[220]=C_static_lambda_info(C_heaptop,15,"(a2787 g286288)");
lf[221]=C_h_intern(&lf[221],30,"call-with-current-continuation");
lf[222]=C_static_lambda_info(C_heaptop,32,"(##compiler#string->expr str285)");
lf[223]=C_h_intern(&lf[223],30,"\010compilerdecompose-lambda-list");
lf[224]=C_h_intern(&lf[224],25,"\003sysdecompose-lambda-list");
lf[225]=C_h_intern(&lf[225],30,"\010compilerexpand-profile-lambda");
lf[226]=C_h_intern(&lf[226],29,"\010compilerprofile-lambda-index");
lf[227]=C_h_intern(&lf[227],28,"\010compilerprofile-lambda-list");
lf[228]=C_h_intern(&lf[228],17,"\003sysprofile-entry");
lf[229]=C_h_intern(&lf[229],33,"\010compilerprofile-info-vector-name");
lf[230]=C_h_intern(&lf[230],5,"apply");
lf[231]=C_h_intern(&lf[231],16,"\003sysprofile-exit");
lf[232]=C_h_intern(&lf[232],16,"\003sysdynamic-wind");
lf[233]=C_static_lambda_info(C_heaptop,59,"(##compiler#expand-profile-lambda name293 llist294 body295)");
lf[234]=C_h_intern(&lf[234],37,"\010compilerinitialize-analysis-database");
lf[235]=C_h_intern(&lf[235],13,"\010compilerput!");
lf[236]=C_h_intern(&lf[236],8,"constant");
lf[237]=C_static_lambda_info(C_heaptop,12,"(a2950 s306)");
lf[238]=C_h_intern(&lf[238],26,"\010compilermutable-constants");
lf[239]=C_h_intern(&lf[239],35,"\010compilerfoldable-extended-bindings");
lf[240]=C_h_intern(&lf[240],8,"foldable");
lf[241]=C_h_intern(&lf[241],16,"extended-binding");
lf[242]=C_static_lambda_info(C_heaptop,12,"(a2960 s304)");
lf[243]=C_h_intern(&lf[243],17,"extended-bindings");
lf[244]=C_h_intern(&lf[244],35,"\010compilerfoldable-standard-bindings");
lf[245]=C_h_intern(&lf[245],41,"\010compilerside-effecting-standard-bindings");
lf[246]=C_h_intern(&lf[246],14,"side-effecting");
lf[247]=C_h_intern(&lf[247],16,"standard-binding");
lf[248]=C_static_lambda_info(C_heaptop,12,"(a2975 s301)");
lf[249]=C_h_intern(&lf[249],17,"standard-bindings");
lf[250]=C_static_lambda_info(C_heaptop,47,"(##compiler#initialize-analysis-database db300)");
lf[251]=C_h_intern(&lf[251],12,"\010compilerget");
lf[252]=C_h_intern(&lf[252],18,"\003syshash-table-ref");
lf[253]=C_static_lambda_info(C_heaptop,37,"(##compiler#get db309 key310 prop311)");
lf[254]=C_h_intern(&lf[254],16,"\010compilerget-all");
lf[255]=C_static_lambda_info(C_heaptop,15,"(a3029 prop318)");
lf[256]=C_h_intern(&lf[256],10,"filter-map");
lf[257]=C_static_lambda_info(C_heaptop,44,"(##compiler#get-all db314 key315 . props316)");
lf[258]=C_h_intern(&lf[258],19,"\003syshash-table-set!");
lf[259]=C_static_lambda_info(C_heaptop,45,"(##compiler#put! db319 key320 prop321 val322)");
lf[260]=C_h_intern(&lf[260],17,"\010compilercollect!");
lf[261]=C_static_lambda_info(C_heaptop,49,"(##compiler#collect! db325 key326 prop327 val328)");
lf[262]=C_h_intern(&lf[262],15,"\010compilercount!");
lf[263]=C_static_lambda_info(C_heaptop,49,"(##compiler#count! db331 key332 prop333 . val334)");
lf[264]=C_h_intern(&lf[264],17,"\010compilerget-line");
lf[265]=C_h_intern(&lf[265],24,"\003sysline-number-database");
lf[266]=C_static_lambda_info(C_heaptop,28,"(##compiler#get-line exp338)");
lf[267]=C_h_intern(&lf[267],19,"\010compilerget-line-2");
lf[268]=C_static_lambda_info(C_heaptop,30,"(##compiler#get-line-2 exp339)");
lf[269]=C_h_intern(&lf[269],30,"\010compilerfind-lambda-container");
lf[270]=C_h_intern(&lf[270],12,"contained-in");
lf[271]=C_static_lambda_info(C_heaptop,12,"(loop id349)");
lf[272]=C_static_lambda_info(C_heaptop,53,"(##compiler#find-lambda-container id345 cid346 db347)");
lf[273]=C_h_intern(&lf[273],37,"\010compilerdisplay-line-number-database");
lf[274]=C_static_string(C_heaptop,7,"~S ~S~%");
lf[275]=C_h_intern(&lf[275],3,"cdr");
lf[276]=C_static_lambda_info(C_heaptop,21,"(a3266 key354 val355)");
lf[277]=C_h_intern(&lf[277],23,"\003syshash-table-for-each");
lf[278]=C_static_lambda_info(C_heaptop,41,"(##compiler#display-line-number-database)");
lf[279]=C_h_intern(&lf[279],34,"\010compilerdisplay-analysis-database");
lf[280]=C_static_string(C_heaptop,7,"\011css=~s");
lf[281]=C_static_string(C_heaptop,8,"\011refs=~s");
lf[282]=C_static_string(C_heaptop,7,"\011val=~s");
lf[283]=C_static_string(C_heaptop,8,"\011pval=~s");
lf[284]=C_h_intern(&lf[284],7,"unknown");
lf[285]=C_h_intern(&lf[285],8,"captured");
tmp=C_intern(C_heaptop,8,"captured");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cpt");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,8,"assigned");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"set");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,5,"boxed");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"box");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"global");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"glo");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,16,"assigned-locally");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"stl");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,12,"contractable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"con");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,16,"standard-binding");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"stb");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,8,"foldable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"fld");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"simple");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"sim");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"inlinable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"inl");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,14,"side-effecting");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"sef");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,11,"collapsable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"col");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"removable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"rem");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,8,"constant");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"con");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"undefined");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"und");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"replacing");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"rpg");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,6,"unused");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"uud");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,16,"extended-binding");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"xtb");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,12,"customizable");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cst");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,21,"has-unused-parameters");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"hup");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,10,"boxed-rest");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"bxr");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[286]=C_h_list(21,C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(21);
lf[287]=C_static_string(C_heaptop,3,"\011~a");
lf[288]=C_h_intern(&lf[288],5,"value");
lf[289]=C_h_intern(&lf[289],15,"potential-value");
lf[290]=C_h_intern(&lf[290],10,"replacable");
lf[291]=C_static_string(C_heaptop,6,"\011~a=~s");
lf[292]=C_h_intern(&lf[292],10,"references");
lf[293]=C_h_intern(&lf[293],10,"call-sites");
lf[294]=C_static_string(C_heaptop,16,"Illegal property");
lf[295]=C_h_intern(&lf[295],4,"home");
lf[296]=C_h_intern(&lf[296],8,"contains");
lf[297]=C_h_intern(&lf[297],8,"use-expr");
lf[298]=C_h_intern(&lf[298],12,"closure-size");
lf[299]=C_h_intern(&lf[299],14,"rest-parameter");
lf[300]=C_h_intern(&lf[300],16,"o-r/access-count");
lf[301]=C_h_intern(&lf[301],18,"captured-variables");
lf[302]=C_h_intern(&lf[302],13,"explicit-rest");
lf[303]=C_h_intern(&lf[303],8,"assigned");
lf[304]=C_h_intern(&lf[304],5,"boxed");
lf[305]=C_h_intern(&lf[305],6,"global");
lf[306]=C_h_intern(&lf[306],12,"contractable");
lf[307]=C_h_intern(&lf[307],16,"assigned-locally");
lf[308]=C_h_intern(&lf[308],11,"collapsable");
lf[309]=C_h_intern(&lf[309],9,"removable");
lf[310]=C_h_intern(&lf[310],9,"undefined");
lf[311]=C_h_intern(&lf[311],9,"replacing");
lf[312]=C_h_intern(&lf[312],6,"unused");
lf[313]=C_h_intern(&lf[313],6,"simple");
lf[314]=C_h_intern(&lf[314],9,"inlinable");
lf[315]=C_h_intern(&lf[315],21,"has-unused-parameters");
lf[316]=C_h_intern(&lf[316],12,"customizable");
lf[317]=C_h_intern(&lf[317],10,"boxed-rest");
lf[318]=C_static_lambda_info(C_heaptop,12,"(loop es365)");
lf[319]=C_static_lambda_info(C_heaptop,23,"(a3285 sym358 plist359)");
lf[320]=C_static_lambda_info(C_heaptop,44,"(##compiler#display-analysis-database db357)");
lf[321]=C_h_intern(&lf[321],9,"make-node");
lf[322]=C_h_intern(&lf[322],4,"node");
lf[323]=C_static_lambda_info(C_heaptop,49,"(f_3661 class437 parameters438 subexpressions439)");
lf[324]=C_h_intern(&lf[324],5,"node\077");
lf[325]=C_static_lambda_info(C_heaptop,12,"(node\077 x440)");
lf[326]=C_h_intern(&lf[326],10,"node-class");
lf[327]=C_static_lambda_info(C_heaptop,17,"(node-class x441)");
lf[328]=C_h_intern(&lf[328],15,"node-class-set!");
lf[329]=C_h_intern(&lf[329],14,"\003sysblock-set!");
lf[330]=C_static_lambda_info(C_heaptop,29,"(node-class-set! x443 val444)");
lf[331]=C_h_intern(&lf[331],15,"node-parameters");
lf[332]=C_static_lambda_info(C_heaptop,22,"(node-parameters x447)");
lf[333]=C_h_intern(&lf[333],20,"node-parameters-set!");
lf[334]=C_static_lambda_info(C_heaptop,34,"(node-parameters-set! x449 val450)");
lf[335]=C_h_intern(&lf[335],19,"node-subexpressions");
lf[336]=C_static_lambda_info(C_heaptop,26,"(node-subexpressions x453)");
lf[337]=C_h_intern(&lf[337],24,"node-subexpressions-set!");
lf[338]=C_static_lambda_info(C_heaptop,38,"(node-subexpressions-set! x455 val456)");
lf[339]=C_static_lambda_info(C_heaptop,26,"(make-node c463 p464 s465)");
lf[340]=C_h_intern(&lf[340],16,"\010compilervarnode");
lf[341]=C_h_intern(&lf[341],13,"\004corevariable");
lf[342]=C_static_lambda_info(C_heaptop,27,"(##compiler#varnode var466)");
lf[343]=C_h_intern(&lf[343],14,"\010compilerqnode");
lf[344]=C_static_lambda_info(C_heaptop,27,"(##compiler#qnode const470)");
lf[345]=C_h_intern(&lf[345],25,"\010compilerbuild-node-graph");
lf[346]=C_static_string(C_heaptop,14,"bad expression");
lf[347]=C_h_intern(&lf[347],15,"\004coreglobal-ref");
lf[348]=C_h_intern(&lf[348],8,"truncate");
lf[349]=C_static_string(C_heaptop,59,"literal \047~s\047 is out of range - will be truncated to integer");
lf[350]=C_h_intern(&lf[350],6,"fixnum");
lf[351]=C_h_intern(&lf[351],11,"number-type");
lf[352]=C_static_lambda_info(C_heaptop,12,"(a3908 b495)");
lf[353]=C_h_intern(&lf[353],6,"unzip1");
lf[354]=C_h_intern(&lf[354],9,"\004coreproc");
lf[355]=C_h_intern(&lf[355],29,"\004coreforeign-callback-wrapper");
lf[356]=C_h_intern(&lf[356],5,"sixth");
lf[357]=C_h_intern(&lf[357],5,"fifth");
lf[358]=C_h_intern(&lf[358],8,"\004coreapp");
lf[359]=C_h_intern(&lf[359],9,"\004corecall");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[360]=C_h_pair(C_restore,tmp);
lf[361]=C_static_lambda_info(C_heaptop,7,"(a4160)");
lf[362]=C_h_intern(&lf[362],24,"\010compilersource-filename");
lf[363]=C_static_string(C_heaptop,2,": ");
lf[364]=C_static_string(C_heaptop,1," ");
lf[365]=C_h_intern(&lf[365],28,"\003syssymbol->qualified-string");
lf[366]=C_h_intern(&lf[366],11,"make-string");
lf[367]=C_h_intern(&lf[367],3,"max");
lf[368]=C_h_intern(&lf[368],34,"\010compileralways-bound-to-procedure");
lf[369]=C_static_lambda_info(C_heaptop,21,"(a4166 name534 ln535)");
lf[370]=C_h_intern(&lf[370],13,"\004corecallunit");
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[371]=C_h_pair(C_restore,tmp);
lf[372]=C_static_lambda_info(C_heaptop,11,"(walk x477)");
lf[373]=C_h_intern(&lf[373],1,"o");
lf[374]=C_static_string(C_heaptop,27,"eliminated procedure checks");
lf[375]=C_static_lambda_info(C_heaptop,36,"(##compiler#build-node-graph exp474)");
lf[376]=C_h_intern(&lf[376],30,"\010compilerbuild-expression-tree");
lf[377]=C_h_intern(&lf[377],12,"\004coreclosure");
lf[378]=C_h_intern(&lf[378],4,"last");
lf[379]=C_h_intern(&lf[379],4,"list");
lf[380]=C_h_intern(&lf[380],7,"butlast");
lf[381]=C_h_intern(&lf[381],11,"\004corelambda");
lf[382]=C_h_intern(&lf[382],9,"\004corebind");
lf[383]=C_static_lambda_info(C_heaptop,31,"(loop n568 vals569 bindings570)");
lf[384]=C_h_intern(&lf[384],10,"\004coreunbox");
lf[385]=C_h_intern(&lf[385],8,"\004coreref");
lf[386]=C_h_intern(&lf[386],11,"\004coreupdate");
lf[387]=C_h_intern(&lf[387],13,"\004coreupdate_i");
lf[388]=C_h_intern(&lf[388],8,"\004corebox");
lf[389]=C_h_intern(&lf[389],9,"\004corecond");
lf[390]=C_static_lambda_info(C_heaptop,11,"(walk n552)");
lf[391]=C_static_lambda_info(C_heaptop,42,"(##compiler#build-expression-tree node550)");
lf[392]=C_h_intern(&lf[392],21,"\010compilerfold-boolean");
tmp=C_static_string(C_heaptop,5,"C_and");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[393]=C_h_pair(C_restore,tmp);
lf[394]=C_static_lambda_info(C_heaptop,14,"(fold vars582)");
lf[395]=C_static_lambda_info(C_heaptop,40,"(##compiler#fold-boolean proc579 lst580)");
lf[396]=C_h_intern(&lf[396],31,"\010compilerinline-lambda-bindings");
lf[397]=C_h_intern(&lf[397],8,"split-at");
lf[398]=C_static_lambda_info(C_heaptop,7,"(a4631)");
lf[399]=C_static_lambda_info(C_heaptop,29,"(a4649 var598 val599 body600)");
lf[400]=C_h_intern(&lf[400],10,"fold-right");
lf[401]=C_h_intern(&lf[401],4,"take");
lf[402]=C_static_string(C_heaptop,10,"C_a_i_list");
lf[403]=C_h_intern(&lf[403],34,"\010compilercopy-node-tree-and-rename");
lf[404]=C_static_lambda_info(C_heaptop,25,"(a4637 largs594 rargs595)");
lf[405]=C_static_lambda_info(C_heaptop,31,"(a4625 vars591 argc592 rest593)");
lf[406]=C_static_lambda_info(C_heaptop,69,"(##compiler#inline-lambda-bindings llist587 args588 body589 copy\077590)");
lf[407]=C_h_intern(&lf[407],9,"alist-ref");
lf[408]=C_h_intern(&lf[408],3,"eq\077");
lf[409]=C_static_lambda_info(C_heaptop,19,"(rename v616 rl617)");
lf[410]=C_static_lambda_info(C_heaptop,15,"(a4768 g631632)");
lf[411]=C_static_lambda_info(C_heaptop,15,"(a4806 g639640)");
lf[412]=C_static_lambda_info(C_heaptop,15,"(a4843 g649650)");
lf[413]=C_static_lambda_info(C_heaptop,31,"(a4825 vars641 argc642 rest643)");
lf[414]=C_static_lambda_info(C_heaptop,15,"(a4881 g654655)");
lf[415]=C_h_intern(&lf[415],18,"\010compilertree-copy");
lf[416]=C_static_lambda_info(C_heaptop,17,"(walk n618 rl619)");
lf[417]=C_h_intern(&lf[417],4,"cons");
lf[418]=C_static_lambda_info(C_heaptop,65,"(##compiler#copy-node-tree-and-rename node610 vars611 aliases612)");
lf[419]=C_static_lambda_info(C_heaptop,10,"(rec t660)");
lf[420]=C_static_lambda_info(C_heaptop,27,"(##compiler#tree-copy t658)");
lf[421]=C_h_intern(&lf[421],19,"\010compilercopy-node!");
lf[422]=C_static_lambda_info(C_heaptop,7,"(do669)");
lf[423]=C_static_lambda_info(C_heaptop,37,"(##compiler#copy-node! from662 to663)");
lf[424]=C_h_intern(&lf[424],19,"\010compilermatch-node");
lf[425]=C_static_lambda_info(C_heaptop,19,"(resolve v686 x687)");
lf[426]=C_static_lambda_info(C_heaptop,18,"(match1 x692 p693)");
lf[427]=C_static_lambda_info(C_heaptop,18,"(loop ns699 ps700)");
lf[428]=C_static_lambda_info(C_heaptop,18,"(matchn n694 p695)");
lf[429]=C_h_intern(&lf[429],1,"a");
lf[430]=C_static_string(C_heaptop,7,"matched");
lf[431]=C_static_lambda_info(C_heaptop,46,"(##compiler#match-node node679 pat680 vars681)");
lf[432]=C_h_intern(&lf[432],37,"\010compilerexpression-has-side-effects\077");
lf[433]=C_h_intern(&lf[433],24,"foreign-callback-stub-id");
lf[434]=C_static_lambda_info(C_heaptop,13,"(a5217 fs729)");
lf[435]=C_h_intern(&lf[435],4,"find");
lf[436]=C_h_intern(&lf[436],22,"foreign-callback-stubs");
lf[437]=C_static_lambda_info(C_heaptop,11,"(walk n713)");
lf[438]=C_static_lambda_info(C_heaptop,55,"(##compiler#expression-has-side-effects\077 node710 db711)");
lf[439]=C_h_intern(&lf[439],28,"\010compilersimple-lambda-node\077");
lf[440]=C_static_lambda_info(C_heaptop,10,"(rec n739)");
lf[441]=C_static_lambda_info(C_heaptop,40,"(##compiler#simple-lambda-node\077 node733)");
lf[442]=C_h_intern(&lf[442],30,"\010compilerdump-exported-globals");
lf[443]=C_h_intern(&lf[443],26,"\010compilerblock-compilation");
lf[444]=C_h_intern(&lf[444],20,"\010compilerexport-list");
lf[445]=C_h_intern(&lf[445],22,"\010compilerblock-globals");
lf[446]=C_static_lambda_info(C_heaptop,23,"(a5368 sym751 plist752)");
lf[447]=C_static_lambda_info(C_heaptop,40,"(##compiler#dump-exported-globals db750)");
lf[448]=C_h_intern(&lf[448],31,"\010compilerdump-undefined-globals");
lf[449]=C_static_lambda_info(C_heaptop,23,"(a5414 sym757 plist758)");
lf[450]=C_static_lambda_info(C_heaptop,41,"(##compiler#dump-undefined-globals db756)");
lf[451]=C_h_intern(&lf[451],29,"\010compilercheck-global-exports");
lf[452]=C_static_string(C_heaptop,44,"exported global variable `~S\047 is not defined");
lf[453]=C_static_lambda_info(C_heaptop,15,"(a5451 g765766)");
lf[454]=C_h_intern(&lf[454],6,"delete");
lf[455]=C_static_string(C_heaptop,53,"exported global variable `~S\047 is used but not defined");
lf[456]=C_static_lambda_info(C_heaptop,23,"(a5457 sym762 plist763)");
lf[457]=C_static_lambda_info(C_heaptop,39,"(##compiler#check-global-exports db760)");
lf[458]=C_h_intern(&lf[458],36,"\010compilercompute-database-statistics");
lf[459]=C_h_intern(&lf[459],29,"\010compilercurrent-program-size");
lf[460]=C_h_intern(&lf[460],30,"\010compileroriginal-program-size");
lf[461]=C_static_lambda_info(C_heaptop,15,"(a5498 prop776)");
lf[462]=C_static_lambda_info(C_heaptop,23,"(a5492 sym774 plist775)");
lf[463]=C_static_lambda_info(C_heaptop,46,"(##compiler#compute-database-statistics db768)");
lf[464]=C_h_intern(&lf[464],33,"\010compilerprint-program-statistics");
lf[465]=C_static_lambda_info(C_heaptop,7,"(a5569)");
lf[466]=C_static_string(C_heaptop,26,";   database entries: \011~s\012");
lf[467]=C_static_string(C_heaptop,26,";   known call sites: \011~s\012");
lf[468]=C_static_string(C_heaptop,26,";   global variables: \011~s\012");
lf[469]=C_static_string(C_heaptop,26,";   known procedures: \011~s\012");
lf[470]=C_static_string(C_heaptop,37,";   variables with known values: \011~s\012");
lf[471]=C_static_string(C_heaptop,50,";   program size: \011~s \011original program size: \011~s\012");
lf[472]=C_h_intern(&lf[472],1,"s");
lf[473]=C_static_string(C_heaptop,19,"program statistics:");
lf[474]=C_static_lambda_info(C_heaptop,72,"(a5575 size784 osize785 kvars786 kprocs787 globs788 sites789 entries790)");
lf[475]=C_static_lambda_info(C_heaptop,43,"(##compiler#print-program-statistics db783)");
lf[476]=C_h_intern(&lf[476],35,"\010compilerpprint-expressions-to-file");
lf[477]=C_h_intern(&lf[477],17,"close-output-port");
lf[478]=C_h_intern(&lf[478],12,"pretty-print");
lf[479]=C_static_lambda_info(C_heaptop,12,"(a5623 x799)");
lf[480]=C_static_lambda_info(C_heaptop,7,"(a5617)");
lf[481]=C_h_intern(&lf[481],19,"with-output-to-port");
lf[482]=C_h_intern(&lf[482],16,"open-output-file");
lf[483]=C_h_intern(&lf[483],19,"current-output-port");
lf[484]=C_static_lambda_info(C_heaptop,59,"(##compiler#pprint-expressions-to-file exps796 filename797)");
lf[485]=C_h_intern(&lf[485],27,"\010compilerforeign-type-check");
lf[486]=C_h_intern(&lf[486],4,"char");
lf[487]=C_h_intern(&lf[487],13,"unsigned-char");
lf[488]=C_h_intern(&lf[488],6,"unsafe");
lf[489]=C_h_intern(&lf[489],25,"\003sysforeign-char-argument");
lf[490]=C_h_intern(&lf[490],3,"int");
lf[491]=C_h_intern(&lf[491],27,"\003sysforeign-fixnum-argument");
lf[492]=C_h_intern(&lf[492],5,"float");
lf[493]=C_h_intern(&lf[493],27,"\003sysforeign-flonum-argument");
lf[494]=C_h_intern(&lf[494],7,"pointer");
lf[495]=C_h_intern(&lf[495],26,"\003sysforeign-block-argument");
lf[496]=C_h_intern(&lf[496],15,"nonnull-pointer");
lf[497]=C_h_intern(&lf[497],8,"u8vector");
lf[498]=C_h_intern(&lf[498],34,"\003sysforeign-number-vector-argument");
lf[499]=C_h_intern(&lf[499],16,"nonnull-u8vector");
tmp=C_intern(C_heaptop,16,"nonnull-u8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"u8vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-u16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u16vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,16,"nonnull-s8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"s8vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-s16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s16vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-u32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u32vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-s32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s32vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-f32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f32vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,17,"nonnull-f64vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f64vector");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[500]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[501]=C_h_intern(&lf[501],7,"integer");
lf[502]=C_h_intern(&lf[502],4,"long");
lf[503]=C_h_intern(&lf[503],28,"\003sysforeign-integer-argument");
lf[504]=C_h_intern(&lf[504],16,"unsigned-integer");
lf[505]=C_h_intern(&lf[505],13,"unsigned-long");
lf[506]=C_h_intern(&lf[506],37,"\003sysforeign-unsigned-integer-argument");
lf[507]=C_h_intern(&lf[507],9,"c-pointer");
lf[508]=C_h_intern(&lf[508],28,"\003sysforeign-pointer-argument");
lf[509]=C_h_intern(&lf[509],17,"nonnull-c-pointer");
lf[510]=C_h_intern(&lf[510],8,"c-string");
lf[511]=C_h_intern(&lf[511],9,"c-string*");
lf[512]=C_h_intern(&lf[512],17,"\003sysmake-c-string");
lf[513]=C_h_intern(&lf[513],27,"\003sysforeign-string-argument");
lf[514]=C_h_intern(&lf[514],16,"nonnull-c-string");
lf[515]=C_h_intern(&lf[515],17,"nonnull-c-string*");
lf[516]=C_h_intern(&lf[516],6,"symbol");
lf[517]=C_h_intern(&lf[517],18,"\003syssymbol->string");
lf[518]=C_static_lambda_info(C_heaptop,6,"(g883)");
lf[519]=C_h_intern(&lf[519],4,"this");
lf[520]=C_h_intern(&lf[520],8,"slot-ref");
lf[521]=C_static_lambda_info(C_heaptop,6,"(g880)");
lf[522]=C_static_lambda_info(C_heaptop,6,"(g879)");
lf[523]=C_h_intern(&lf[523],3,"ref");
lf[524]=C_h_intern(&lf[524],8,"function");
lf[525]=C_h_intern(&lf[525],8,"instance");
lf[526]=C_h_intern(&lf[526],12,"instance-ref");
lf[527]=C_h_intern(&lf[527],16,"nonnull-instance");
lf[528]=C_h_intern(&lf[528],5,"const");
lf[529]=C_h_intern(&lf[529],27,"\010compilerforeign-type-table");
lf[530]=C_h_intern(&lf[530],17,"nonnull-u16vector");
lf[531]=C_h_intern(&lf[531],16,"nonnull-s8vector");
lf[532]=C_h_intern(&lf[532],17,"nonnull-s16vector");
lf[533]=C_h_intern(&lf[533],17,"nonnull-u32vector");
lf[534]=C_h_intern(&lf[534],17,"nonnull-s32vector");
lf[535]=C_h_intern(&lf[535],17,"nonnull-f32vector");
lf[536]=C_h_intern(&lf[536],17,"nonnull-f64vector");
lf[537]=C_h_intern(&lf[537],9,"u16vector");
lf[538]=C_h_intern(&lf[538],8,"s8vector");
lf[539]=C_h_intern(&lf[539],9,"s16vector");
lf[540]=C_h_intern(&lf[540],9,"u32vector");
lf[541]=C_h_intern(&lf[541],9,"s32vector");
lf[542]=C_h_intern(&lf[542],9,"f32vector");
lf[543]=C_h_intern(&lf[543],9,"f64vector");
lf[544]=C_h_intern(&lf[544],22,"nonnull-scheme-pointer");
lf[545]=C_h_intern(&lf[545],19,"nonnull-byte-vector");
lf[546]=C_h_intern(&lf[546],11,"byte-vector");
lf[547]=C_h_intern(&lf[547],14,"scheme-pointer");
lf[548]=C_h_intern(&lf[548],6,"double");
lf[549]=C_h_intern(&lf[549],6,"number");
lf[550]=C_h_intern(&lf[550],12,"unsigned-int");
lf[551]=C_h_intern(&lf[551],5,"short");
lf[552]=C_h_intern(&lf[552],14,"unsigned-short");
lf[553]=C_h_intern(&lf[553],4,"byte");
lf[554]=C_h_intern(&lf[554],13,"unsigned-byte");
lf[555]=C_static_lambda_info(C_heaptop,13,"(repeat t808)");
lf[556]=C_static_lambda_info(C_heaptop,20,"(a5644 t805 next806)");
lf[557]=C_static_string(C_heaptop,34,"foreign type `~S\047 refers to itself");
lf[558]=C_static_lambda_info(C_heaptop,7,"(a6391)");
lf[559]=C_static_lambda_info(C_heaptop,48,"(##compiler#foreign-type-check param803 type804)");
lf[560]=C_h_intern(&lf[560],36,"\010compilerforeign-type-convert-result");
lf[561]=C_static_lambda_info(C_heaptop,50,"(##compiler#foreign-type-convert-result r893 t894)");
lf[562]=C_h_intern(&lf[562],38,"\010compilerforeign-type-convert-argument");
lf[563]=C_static_lambda_info(C_heaptop,52,"(##compiler#foreign-type-convert-argument a898 t899)");
lf[564]=C_h_intern(&lf[564],27,"\010compilerfinal-foreign-type");
lf[565]=C_static_lambda_info(C_heaptop,20,"(a6465 t904 next905)");
lf[566]=C_static_string(C_heaptop,34,"foreign type `~S\047 refers to itself");
lf[567]=C_static_lambda_info(C_heaptop,7,"(a6493)");
lf[568]=C_static_lambda_info(C_heaptop,37,"(##compiler#final-foreign-type t0903)");
lf[569]=C_h_intern(&lf[569],37,"\010compilerestimate-foreign-result-size");
lf[570]=C_h_intern(&lf[570],4,"bool");
lf[571]=C_h_intern(&lf[571],4,"void");
lf[572]=C_h_intern(&lf[572],13,"scheme-object");
lf[573]=C_static_lambda_info(C_heaptop,20,"(a6505 t910 next911)");
lf[574]=C_static_string(C_heaptop,34,"foreign type `~S\047 refers to itself");
lf[575]=C_static_lambda_info(C_heaptop,7,"(a6758)");
lf[576]=C_static_lambda_info(C_heaptop,49,"(##compiler#estimate-foreign-result-size type909)");
lf[577]=C_h_intern(&lf[577],46,"\010compilerestimate-foreign-result-location-size");
lf[578]=C_static_string(C_heaptop,54,"can not compute size of location for foreign type `~S\047");
lf[579]=C_static_lambda_info(C_heaptop,10,"(err t979)");
lf[580]=C_static_lambda_info(C_heaptop,20,"(a6776 t980 next981)");
lf[581]=C_static_string(C_heaptop,34,"foreign type `~S\047 refers to itself");
lf[582]=C_static_lambda_info(C_heaptop,7,"(a7020)");
lf[583]=C_static_lambda_info(C_heaptop,58,"(##compiler#estimate-foreign-result-location-size type977)");
lf[584]=C_h_intern(&lf[584],30,"\010compilerfinish-foreign-result");
lf[585]=C_h_intern(&lf[585],17,"\003syspeek-c-string");
lf[586]=C_h_intern(&lf[586],25,"\003syspeek-nonnull-c-string");
lf[587]=C_h_intern(&lf[587],26,"\003syspeek-and-free-c-string");
lf[588]=C_h_intern(&lf[588],34,"\003syspeek-and-free-nonnull-c-string");
lf[589]=C_h_intern(&lf[589],17,"\003sysintern-symbol");
lf[590]=C_h_intern(&lf[590],35,"\010tinyclosmake-instance-from-pointer");
lf[591]=C_static_lambda_info(C_heaptop,7,"(g1053)");
lf[592]=C_h_intern(&lf[592],4,"make");
lf[593]=C_static_lambda_info(C_heaptop,52,"(##compiler#finish-foreign-result type1048 body1049)");
lf[594]=C_h_intern(&lf[594],28,"\010compilerscan-used-variables");
lf[595]=C_static_lambda_info(C_heaptop,12,"(walk n1066)");
lf[596]=C_static_lambda_info(C_heaptop,50,"(##compiler#scan-used-variables node1062 vars1063)");
lf[597]=C_h_intern(&lf[597],28,"\010compilerscan-free-variables");
lf[598]=C_h_intern(&lf[598],11,"lset-adjoin");
lf[599]=C_static_lambda_info(C_heaptop,34,"(a7448 vars1108 argc1109 rest1110)");
lf[600]=C_static_lambda_info(C_heaptop,18,"(walk n1087 e1088)");
lf[601]=C_static_lambda_info(C_heaptop,13,"(a7492 n1113)");
lf[602]=C_static_lambda_info(C_heaptop,23,"(walkeach ns1111 e1112)");
lf[603]=C_static_lambda_info(C_heaptop,41,"(##compiler#scan-free-variables node1083)");
lf[604]=C_h_intern(&lf[604],25,"\010compilertopological-sort");
lf[605]=C_static_lambda_info(C_heaptop,13,"(loop at1127)");
lf[606]=C_static_lambda_info(C_heaptop,20,"(insert x1124 y1125)");
lf[607]=C_static_lambda_info(C_heaptop,13,"(loop at1131)");
lf[608]=C_static_lambda_info(C_heaptop,14,"(lookup x1129)");
lf[609]=C_h_intern(&lf[609],7,"colored");
lf[610]=C_static_lambda_info(C_heaptop,13,"(a7605 v1135)");
lf[611]=C_static_lambda_info(C_heaptop,26,"(visit u1133 adj-list1134)");
lf[612]=C_static_lambda_info(C_heaptop,15,"(a7637 def1142)");
lf[613]=C_static_lambda_info(C_heaptop,15,"(a7680 def1141)");
lf[614]=C_static_lambda_info(C_heaptop,46,"(##compiler#topological-sort dag1117 pred1118)");
lf[615]=C_h_intern(&lf[615],23,"\010compilerchop-separator");
lf[616]=C_h_intern(&lf[616],9,"substring");
lf[617]=C_h_intern(&lf[617],28,"pathname-directory-separator");
lf[618]=C_static_lambda_info(C_heaptop,35,"(##compiler#chop-separator str1150)");
lf[619]=C_h_intern(&lf[619],23,"\010compilerchop-extension");
lf[620]=C_static_lambda_info(C_heaptop,12,"(loop i1155)");
lf[621]=C_static_lambda_info(C_heaptop,35,"(##compiler#chop-extension str1152)");
lf[622]=C_h_intern(&lf[622],22,"\010compilerprint-version");
lf[623]=C_static_string(C_heaptop,6,"~A~%~A");
lf[624]=C_h_intern(&lf[624],15,"chicken-version");
lf[625]=C_static_string(C_heaptop,2,"~A");
lf[626]=C_h_intern(&lf[626],9,"\003syserror");
lf[627]=C_static_lambda_info(C_heaptop,34,"(##compiler#print-version . b1157)");
lf[628]=C_h_intern(&lf[628],20,"\010compilerprint-usage");
lf[629]=C_static_string(C_heaptop,4795,"Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source file "
"name with extension, or \042-\042 for\012  standard input. OPTION may be one of the follo"
"wing:\012\012  General options:\012\012    -help                       display this text and"
" exit\012    -version                    display compiler version and exit\012    -ver"
"bose                    display information on compilation progress\012    -quiet  "
"                    do not display compile information\012\012  File and pathname opti"
"ons:\012\012    -output-file FILENAME       specifies output-filename, default is \047out"
".c\047\012    -split NUMBER               split the output into smaller files\012    -spl"
"it-level NUMBER         how hard the compiler should try partitioning the output"
"\012    -include-path PATHNAME      specifies alternative path for included files\012 "
"   -to-stdout                  write compiled file to stdout instead of file\012\012  "
"Language options:\012\012    -feature SYMBOL             register feature identifier\012 "
"   -ffi-define SYMBOL          define preprocessor macro for ``easy\047\047 FFI parser"
"\012    -ffi-include-path PATH      set include path for ``easy\047\047 FFI parser\012    -f"
"fi-no-include             don\047t parse include files when encountered by the FFI "
"parser\012    -ffi                        parse and compile C/C++ code and generate"
" Scheme bindings\012    -ffi-parse                  parse C/C++ code without includ"
"ing it\012\012  Syntax related options:\012\012    -case-insensitive           don\047t preserv"
"e case of read symbols\012    -keyword-style STYLE        allow alternative keyword"
" syntax (none, prefix or suffix)\012    -run-time-macros            macros are made"
" available at run-time\012\012  Translation options:\012\012    -explicit-use               "
"do not use units \047library\047 and \047eval\047 by default\012    -check-syntax              "
" stop compilation after macro-expansion\012    -analyze-only               stop com"
"pilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings      "
"          disable warnings\012    -debug-level NUMBER         set level of availabl"
"e debugging information\012    -no-trace                   disable tracing informat"
"ion\012    -profile                    executable emits profiling information \012    "
"-accumulate-profile         executable emits profiling information in append mod"
"e\012    -no-lambda-info             omit additional procedure-information\012\012  Optim"
"ization options:\012\012    -optimize-level NUMBER      enable certain sets of optimiz"
"ation options\012    -optimize-leaf-routines     enable leaf routine optimization\012 "
"   -lambda-lift                enable lambda-lifting\012    -no-usual-integrations "
"     standard procedures may be redefined\012    -unsafe                     disabl"
"e safety checks\012    -block                      enable block-compilation\012    -di"
"sable-interrupts         disable interrupts in compiled code\012    -fixnum-arithme"
"tic          assume all numbers are fixnums\012    -benchmark-mode             fixn"
"um mode, no interrupts and opt.-level 3\012    -disable-stack-overflow-checks  disa"
"bles detection of stack-overflows.\012    -inline                     enable inlini"
"ng\012    -inline-limit               set inlining threshold\012\012  Configuration optio"
"ns:\012\012    -unit NAME                  compile file as a library unit\012    -uses NA"
"ME                  declare library unit as used.\012    -heap-size NUMBER         "
"  specifies heap-size of compiled executable\012    -heap-initial-size NUMBER   spe"
"cifies heap-size at startup time\012    -heap-growth PERCENTAGE     specifies growt"
"h-rate of expanding heap\012    -heap-shrinkage PERCENTAGE  specifies shrink-rate o"
"f contracting heap\012    -nursery NUMBER\012    -stack-size NUMBER          specifies"
" nursery size of compiled executable\012    -extend FILENAME            load file b"
"efore compilation commences\012    -prelude EXPRESSION         add expression to fr"
"ont of source file\012    -postlude EXPRESSION        add expression to end of sour"
"ce file\012    -prologue FILENAME          include file before main source file\012   "
" -epilogue FILENAME          include file after main source file\012    -dynamic   "
"                 compile as dynamically loadable code\012    -require-extension NAM"
"E     require extension NAME in compiled code\012    -extension                  co"
"mpile as extension (dynamic or static)\012\012  Obscure options:\012\012    -debug MODES    "
"            display debugging output for the given modes\012    -compress-literals "
"NUMBER   compile literals above threshold as strings\012    -disable-c-syntax-check"
"s    disable syntax check of C code fragments\012    -unsafe-libraries           ma"
"rks the generated file as being linked\012                                with the "
"unsafe runtime system\012    -raw                        do not generate implicit i"
"nit- and exit code\011\011\011       \012    -emit-external-prototypes-first  emit protoypes"
" for callbacks before foreign\012                                declarations\012");
lf[630]=C_static_lambda_info(C_heaptop,24,"(##compiler#print-usage)");
lf[631]=C_h_intern(&lf[631],36,"\010compilermake-block-variable-literal");
lf[632]=C_h_intern(&lf[632],31,"\010compilerblock-variable-literal");
lf[633]=C_static_lambda_info(C_heaptop,49,"(##compiler#make-block-variable-literal name1164)");
lf[634]=C_h_intern(&lf[634],32,"\010compilerblock-variable-literal\077");
lf[635]=C_static_lambda_info(C_heaptop,42,"(##compiler#block-variable-literal\077 x1165)");
lf[636]=C_h_intern(&lf[636],36,"\010compilerblock-variable-literal-name");
lf[637]=C_static_lambda_info(C_heaptop,46,"(##compiler#block-variable-literal-name x1166)");
lf[638]=C_h_intern(&lf[638],41,"\010compilerblock-variable-literal-name-set!");
lf[639]=C_static_lambda_info(C_heaptop,59,"(##compiler#block-variable-literal-name-set! x1168 val1169)");
lf[640]=C_static_string(C_heaptop,7,"~A-~A~A");
lf[641]=C_h_intern(&lf[641],6,"random");
lf[642]=C_h_intern(&lf[642],15,"current-seconds");
lf[643]=C_static_lambda_info(C_heaptop,42,"(##compiler#make-random-name . prefix1174)");
lf[644]=C_h_intern(&lf[644],23,"\010compilerset-real-name!");
lf[645]=C_h_intern(&lf[645],24,"\010compilerreal-name-table");
lf[646]=C_static_lambda_info(C_heaptop,46,"(##compiler#set-real-name! name1177 rname1178)");
lf[647]=C_static_lambda_info(C_heaptop,15,"(resolve n1182)");
lf[648]=C_static_string(C_heaptop,8,"~A in ~A");
lf[649]=C_static_lambda_info(C_heaptop,29,"(loop prev1189 container1190)");
lf[650]=C_static_lambda_info(C_heaptop,39,"(##compiler#real-name var1179 . db1180)");
lf[651]=C_h_intern(&lf[651],19,"\010compilerreal-name2");
lf[652]=C_static_lambda_info(C_heaptop,38,"(##compiler#real-name2 var1194 db1195)");
lf[653]=C_h_intern(&lf[653],32,"\010compilerdisplay-real-name-table");
lf[654]=C_static_string(C_heaptop,7,"~S ~S~%");
lf[655]=C_static_lambda_info(C_heaptop,23,"(a7996 key1197 val1198)");
lf[656]=C_static_lambda_info(C_heaptop,36,"(##compiler#display-real-name-table)");
lf[657]=C_h_intern(&lf[657],12,"string-null\077");
lf[658]=C_static_lambda_info(C_heaptop,20,"(string-null\077 x1199)");
lf[659]=C_h_intern(&lf[659],19,"\010compilerdump-nodes");
lf[660]=C_h_intern(&lf[660],10,"write-char");
lf[661]=C_static_string(C_heaptop,3," ~S");
lf[662]=C_static_lambda_info(C_heaptop,14,"(do1215 i1217)");
lf[663]=C_static_string(C_heaptop,3,"[~S");
lf[664]=C_static_lambda_info(C_heaptop,17,"(a8089 g12121213)");
lf[665]=C_static_string(C_heaptop,10,"~%~A<~A ~S");
lf[666]=C_static_lambda_info(C_heaptop,18,"(loop i1202 n1203)");
lf[667]=C_static_lambda_info(C_heaptop,29,"(##compiler#dump-nodes n1200)");
lf[668]=C_h_intern(&lf[668],41,"\010compilerenable-sharp-greater-read-syntax");
lf[669]=C_h_intern(&lf[669],18,"\003sysuser-read-hook");
lf[670]=C_h_intern(&lf[670],10,"\003sysappend");
lf[671]=C_h_intern(&lf[671],15,"foreign-declare");
lf[672]=C_h_intern(&lf[672],7,"declare");
lf[673]=C_static_string(C_heaptop,54,"static C_word ~A() { ~A; return C_SCHEME_UNDEFINED; }\012");
lf[674]=C_h_intern(&lf[674],5,"code_");
lf[675]=C_h_intern(&lf[675],13,"foreign-parse");
lf[676]=C_h_intern(&lf[676],23,"\010compilercheck-c-syntax");
lf[677]=C_h_intern(&lf[677],34,"\010compilerscan-sharp-greater-string");
lf[678]=C_h_intern(&lf[678],9,"read-char");
lf[679]=C_h_intern(&lf[679],5,"parse");
lf[680]=C_h_intern(&lf[680],7,"execute");
lf[681]=C_static_string(C_heaptop,35,"invalid tag in `#>(...) ...<#\047 form");
lf[682]=C_static_lambda_info(C_heaptop,13,"(a8233 t1244)");
lf[683]=C_h_intern(&lf[683],9,"peek-char");
lf[684]=C_static_lambda_info(C_heaptop,40,"(##sys#user-read-hook char1228 port1229)");
lf[685]=C_static_lambda_info(C_heaptop,45,"(##compiler#enable-sharp-greater-read-syntax)");
lf[686]=C_static_string(C_heaptop,38,"unexpected end of `#> ... <#\047 sequence");
lf[687]=C_h_intern(&lf[687],17,"get-output-string");
lf[688]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[689]=C_h_intern(&lf[689],18,"open-output-string");
lf[690]=C_static_lambda_info(C_heaptop,47,"(##compiler#scan-sharp-greater-string port1251)");
lf[691]=C_h_intern(&lf[691],35,"\010compilerprocess-custom-declaration");
lf[692]=C_h_intern(&lf[692],29,"\010compilercustom-declare-alist");
lf[693]=C_static_lambda_info(C_heaptop,17,"(a8363 g12761280)");
lf[694]=C_static_lambda_info(C_heaptop,8,"(f_8384)");
lf[695]=C_h_intern(&lf[695],31,"\010compileremit-control-file-item");
lf[696]=C_static_lambda_info(C_heaptop,60,"(##compiler#process-custom-declaration spec1261 strings1262)");
lf[697]=C_h_intern(&lf[697],25,"\010compilercsc-control-file");
lf[698]=C_static_string(C_heaptop,4,"~S~%");
lf[699]=C_static_lambda_info(C_heaptop,34,"(##compiler#compiler-cleanup-hook)");
lf[700]=C_static_string(C_heaptop,6,"#%csc\012");
lf[701]=C_h_intern(&lf[701],26,"pathname-replace-extension");
lf[702]=C_static_string(C_heaptop,3,"csc");
lf[703]=C_static_lambda_info(C_heaptop,44,"(##compiler#emit-control-file-item item1282)");
lf[704]=C_h_intern(&lf[704],27,"condition-property-accessor");
lf[705]=C_h_intern(&lf[705],3,"exn");
lf[706]=C_h_intern(&lf[706],7,"message");
lf[707]=C_h_intern(&lf[707],19,"condition-predicate");
lf[708]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,709);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate(&lf[40],lf[41]);
t23=C_mutate((C_word*)lf[42]+1,lf[43]);
t24=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=lf[45],tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[46],0,C_SCHEME_END_OF_LIST);
t26=C_set_block_item(lf[47],0,C_SCHEME_TRUE);
t27=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=lf[65],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1479,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1498,a[2]=lf[74],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=lf[79],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=lf[91],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=lf[96],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=lf[100],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[106]+1,C_retrieve(lf[107]));
t40=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=lf[118],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=lf[123],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1944,a[2]=lf[125],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=lf[135],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2005,a[2]=lf[139],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=lf[143],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=lf[147],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=lf[150],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2157,a[2]=lf[152],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2187,a[2]=lf[154],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=lf[159],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=lf[168],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=lf[201],tmp=(C_word)a,a+=3,tmp));
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 316  condition-predicate */
t55=C_retrieve(lf[707]);
((C_proc3)C_retrieve_proc(t55))(3,t55,t54,lf[705]);}

/* k2773 */
static void f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 317  condition-property-accessor */
t3=C_retrieve(lf[704]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[705],lf[706]);}

/* k2776 in k2773 */
static void f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[206],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[222],tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[223]+1,C_retrieve(lf[224]));
t4=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=lf[233],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=lf[250],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3018,a[2]=lf[257],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=lf[259],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=lf[261],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3134,a[2]=lf[263],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=lf[266],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3201,a[2]=lf[268],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=lf[272],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=lf[278],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=lf[320],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=lf[323],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3667,a[2]=lf[325],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=lf[327],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=lf[330],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=lf[332],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3700,a[2]=lf[334],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=lf[336],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=lf[338],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3727,a[2]=lf[339],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=lf[342],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=lf[344],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=lf[375],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=lf[391],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[392]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=lf[395],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[396]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=lf[406],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4713,a[2]=lf[418],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4891,a[2]=lf[420],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4925,a[2]=lf[423],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4987,a[2]=lf[431],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[432]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5182,a[2]=lf[438],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[439]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5268,a[2]=lf[441],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[442]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=lf[447],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[448]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5409,a[2]=lf[450],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=lf[457],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[458]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=lf[463],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[464]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5564,a[2]=lf[475],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[476]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5603,a[2]=lf[484],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[485]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5639,a[2]=lf[559],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[560]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6398,a[2]=lf[561],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[562]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6429,a[2]=lf[563],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[564]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6460,a[2]=lf[568],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[569]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6500,a[2]=lf[576],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[577]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6765,a[2]=lf[583],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[584]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7027,a[2]=lf[593],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[594]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7265,a[2]=lf[596],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[597]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7343,a[2]=lf[603],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[604]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7502,a[2]=lf[614],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[615]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7699,a[2]=lf[618],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[619]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7728,a[2]=lf[621],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[622]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7770,a[2]=lf[627],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[628]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7808,a[2]=lf[630],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[631]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7820,a[2]=lf[633],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[634]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7826,a[2]=lf[635],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[636]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7832,a[2]=lf[637],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[638]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7841,a[2]=lf[639],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7850,a[2]=lf[643],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[644]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7894,a[2]=lf[646],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7900,a[2]=lf[650],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[651]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7979,a[2]=lf[652],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[653]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7991,a[2]=lf[656],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[657]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8003,a[2]=lf[658],tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[659]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8009,a[2]=lf[667],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[668]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8096,a[2]=lf[685],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[677]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8265,a[2]=lf[690],tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1428 ##compiler#enable-sharp-greater-read-syntax */
t71=C_retrieve(lf[668]);
((C_proc2)C_retrieve_proc(t71))(2,t71,t70);}

/* k8333 in k2776 in k2773 */
static void f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
t2=C_mutate((C_word*)lf[691]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8337,a[2]=lf[696],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[695]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8400,a[2]=lf[703],tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8400,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[697]))){
t4=t3;
f_8404(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8411,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8427,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1454 pathname-replace-extension */
t6=C_retrieve(lf[701]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[362]),lf[702]);}}

/* k8425 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1454 open-output-file */
t2=*((C_word*)lf[482]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8409 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8411,2,t0,t1);}
t2=C_mutate((C_word*)lf[697]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1455 display */
t4=*((C_word*)lf[62]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[700],C_retrieve(lf[697]));}

/* k8412 in k8409 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8414,2,t0,t1);}
t2=*((C_word*)lf[44]+1);
t3=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8416,a[2]=t2,a[3]=lf[699],tmp=(C_word)a,a+=4,tmp));
t4=((C_word*)t0)[2];
f_8404(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k8412 in k8409 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8420,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1459 close-output-port */
t3=*((C_word*)lf[477]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[697]));}

/* k8418 in ##compiler#compiler-cleanup-hook in k8412 in k8409 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void f_8420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1460 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8402 in ##compiler#emit-control-file-item in k8333 in k2776 in k2773 */
static void C_fcall f_8404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1461 fprintf */
t2=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[697]),lf[698],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8337,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[692]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8359,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_8359(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8374,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1441 open-output-file */
t14=*((C_word*)lf[482]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k8372 in ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[692]));
t5=C_mutate((C_word*)lf[692]+1,t4);
t6=*((C_word*)lf[44]+1);
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8384,a[2]=t1,a[3]=t6,a[4]=lf[694],tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8398,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1449 cons* */
t9=C_retrieve(lf[172]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8396 in k8372 in ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1449 ##compiler#emit-control-file-item */
t2=C_retrieve(lf[695]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_8384 in k8372 in ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8388,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1447 close-output-port */
t3=*((C_word*)lf[477]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8386 */
static void f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1448 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8357 in ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8359,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[62]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8367,a[2]=t2,a[3]=t3,a[4]=lf[693],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a8363 in k8357 in ##compiler#process-custom-declaration in k8333 in k2776 in k2773 */
static void f_8367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8367,3,t0,t1,t2);}
/* support.scm: 1450 g1275 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8265,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8269,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1409 open-output-string */
t4=C_retrieve(lf[689]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8269,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=lf[688],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8274(t5,((C_word*)t0)[2]);}

/* loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void C_fcall f_8274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8274,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1411 read-char */
t3=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8278,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1412 quit */
t2=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[686]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8296,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1414 newline */
t3=*((C_word*)lf[56]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8308,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1417 read-char */
t3=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1425 write-char */
t3=*((C_word*)lf[660]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k8327 in k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1426 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8274(t2,((C_word*)t0)[2]);}

/* k8306 in k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8308,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1419 get-output-string */
t3=C_retrieve(lf[687]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8320,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1421 write-char */
t4=*((C_word*)lf[660]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k8318 in k8306 in k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1422 write-char */
t3=*((C_word*)lf[660]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8321 in k8318 in k8306 in k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1423 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8274(t2,((C_word*)t0)[2]);}

/* k8294 in k8276 in loop in k8267 in ##compiler#scan-sharp-greater-string in k2776 in k2773 */
static void f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1415 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8274(t2,((C_word*)t0)[2]);}

/* ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
t2=C_retrieve(lf[669]);
t3=C_mutate((C_word*)lf[669]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8099,a[2]=t2,a[3]=lf[684],tmp=(C_word)a,a+=4,tmp));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8099,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8109,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1363 read-char */
t6=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* support.scm: 1406 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8109,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1367 peek-char */
t9=*((C_word*)lf[683]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[2]);}

/* k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
switch(t1){
case C_make_character(33):
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8198,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1369 read-char */
t4=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);
case C_make_character(63):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8209,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1373 read-char */
t4=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);
case C_make_character(58):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8219,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1376 read-char */
t4=*((C_word*)lf[678]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);
case C_make_character(40):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8229,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1379 read */
t4=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);
default:
t3=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t4=t2;
f_8115(2,t4,t3);}}

/* k8227 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[682],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}

/* a8233 in k8227 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8234,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[672]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[679]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[680]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* support.scm: 1387 quit */
t7=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,lf[681],t2);}}}}

/* k8217 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8115(2,t3,t2);}

/* k8207 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8115(2,t3,t2);}

/* k8196 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t4=((C_word*)t0)[2];
f_8115(2,t4,t3);}

/* k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1390 ##compiler#scan-sharp-greater-string */
t3=C_retrieve(lf[677]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1391 ##compiler#check-c-syntax */
t3=C_retrieve(lf[676]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8128,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_a_i_list(&a,2,lf[671],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[672],t4);
t6=t3;
f_8132(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_8132(t4,C_SCHEME_END_OF_LIST);}}

/* k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void C_fcall f_8132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8132,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8136,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_a_i_list(&a,2,lf[675],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[672],t4);
t6=t3;
f_8140(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_8140(t4,C_SCHEME_END_OF_LIST);}}

/* k8138 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void C_fcall f_8140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8140,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8144,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1400 gensym */
t4=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[674]);}
else{
t3=t2;
f_8144(t3,C_SCHEME_END_OF_LIST);}}

/* k8145 in k8138 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8170,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1403 sprintf */
t3=C_retrieve(lf[94]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[673],t1,((C_word*)t0)[2]);}

/* k8168 in k8145 in k8138 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8170,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[671],t1);
t3=(C_word)C_a_i_list(&a,2,lf[672],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8162,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1404 symbol->string */
t5=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8160 in k8168 in k8145 in k8138 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8162,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[179],t1);
t3=((C_word*)t0)[3];
f_8144(t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t2));}

/* k8142 in k8138 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void C_fcall f_8144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1358 ##sys#append */
t2=*((C_word*)lf[670]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8134 in k8130 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1358 ##sys#append */
t2=*((C_word*)lf[670]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8126 in k8119 in k8116 in k8113 in k8110 in k8107 in ##sys#user-read-hook in ##compiler#enable-sharp-greater-read-syntax in k2776 in k2773 */
static void f_8128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1358 ##sys#cons */
t2=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[207],t1);}

/* ##compiler#dump-nodes in k2776 in k2773 */
static void f_8009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8013,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8018,a[2]=t5,a[3]=lf[666],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8018(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k2776 in k2773 */
static void C_fcall f_8018(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8018,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8031,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1341 make-string */
t11=*((C_word*)lf[366]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t2,C_make_character(32));}

/* k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8031,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1343 printf */
t4=C_retrieve(lf[57]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[665],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8040,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[664],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8089 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8090,3,t0,t1,t2);}
/* loop1201 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8018(t3,t1,((C_word*)t0)[2],t2);}

/* k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8040,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8055,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1347 printf */
t6=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[663],t5);}
else{
t4=t3;
f_8046(2,t4,C_SCHEME_UNDEFINED);}}

/* k8053 in k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8058,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8063,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=lf[662],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8063(t6,t2,C_fix(5));}

/* do1215 in k8053 in k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void C_fcall f_8063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8073,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1350 printf */
t5=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[661],t4);}}

/* k8071 in do1215 in k8053 in k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8063(t3,((C_word*)t0)[2],t2);}

/* k8056 in k8053 in k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1351 write-char */
t2=*((C_word*)lf[660]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(93));}

/* k8044 in k8038 in k8035 in k8029 in loop in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1352 write-char */
t2=*((C_word*)lf[660]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(62));}

/* k8011 in ##compiler#dump-nodes in k2776 in k2773 */
static void f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1353 newline */
t2=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k2776 in k2773 */
static void f_8003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8003,3,t0,t1,t2);}
/* support.scm: 1331 string-null? */
t3=C_retrieve(lf[657]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#display-real-name-table in k2776 in k2773 */
static void f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7997,a[2]=lf[655],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1323 ##sys#hash-table-for-each */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[645]));}

/* a7996 in ##compiler#display-real-name-table in k2776 in k2773 */
static void f_7997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7997,4,t0,t1,t2,t3);}
/* support.scm: 1325 printf */
t4=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[654],t2,t3);}

/* ##compiler#real-name2 in k2776 in k2773 */
static void f_7979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7979,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7983,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1319 ##sys#hash-table-ref */
t5=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[645]),t2);}

/* k7981 in ##compiler#real-name2 in k2776 in k2773 */
static void f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1320 ##compiler#real-name */
t2=C_retrieve(lf[85]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k2776 in k2773 */
static void f_7900(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7900r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7900r(t0,t1,t2,t3);}}

static void f_7900r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7903,a[2]=lf[647],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7919,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1303 resolve */
f_7903(t5,t2);}

/* k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7919,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1307 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1316 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1304 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7948,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1308 ##compiler#get */
t3=C_retrieve(lf[251]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[270]);}

/* k7946 in k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7948,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=lf[649],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7950(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7946 in k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7950,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1310 resolve */
f_7903(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k7955 in loop in k7946 in k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7970,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1313 sprintf */
t4=C_retrieve(lf[94]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[648],((C_word*)t0)[4],t1);}}

/* k7968 in k7955 in loop in k7946 in k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7974,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1314 ##compiler#get */
t3=C_retrieve(lf[251]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[270]);}

/* k7972 in k7968 in k7955 in loop in k7946 in k7942 in k7917 in ##compiler#real-name in k2776 in k2773 */
static void f_7974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1313 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7950(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k2776 in k2773 */
static void C_fcall f_7903(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7903,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1298 ##sys#hash-table-ref */
t4=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[645]),t2);}

/* k7905 in resolve in ##compiler#real-name in k2776 in k2773 */
static void f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7913,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1300 ##sys#hash-table-ref */
t3=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[645]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7911 in k7905 in resolve in ##compiler#real-name in k2776 in k2773 */
static void f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k2776 in k2773 */
static void f_7894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7894,4,t0,t1,t2,t3);}
/* support.scm: 1294 ##sys#hash-table-set! */
t4=C_retrieve(lf[258]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[645]),t2,t3);}

/* ##compiler#make-random-name in k2776 in k2773 */
static void f_7850(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_7850r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7850r(t0,t1,t2);}}

static void f_7850r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7862,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1281 gensym */
t5=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7862(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1281 ##sys#error */
t6=*((C_word*)lf[626]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k7860 in ##compiler#make-random-name in k2776 in k2773 */
static void f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7866,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1282 current-seconds */
t3=C_retrieve(lf[642]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7864 in k7860 in ##compiler#make-random-name in k2776 in k2773 */
static void f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7870,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1283 random */
t3=C_retrieve(lf[641]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k7868 in k7864 in k7860 in ##compiler#make-random-name in k2776 in k2773 */
static void f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1280 sprintf */
t2=C_retrieve(lf[94]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[640],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7856 in ##compiler#make-random-name in k2776 in k2773 */
static void f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1279 string->symbol */
t2=*((C_word*)lf[98]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name-set! in k2776 in k2773 */
static void f_7841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7841,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[632]);
/* support.scm: 1272 ##sys#block-set! */
t5=*((C_word*)lf[329]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* ##compiler#block-variable-literal-name in k2776 in k2773 */
static void f_7832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7832,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[632]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k2776 in k2773 */
static void f_7826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7826,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[632]));}

/* ##compiler#make-block-variable-literal in k2776 in k2773 */
static void f_7820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7820,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[632],t2));}

/* ##compiler#print-usage in k2776 in k2773 */
static void f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1168 ##compiler#print-version */
t3=C_retrieve(lf[622]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7810 in ##compiler#print-usage in k2776 in k2773 */
static void f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1169 newline */
t3=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7813 in k7810 in ##compiler#print-usage in k2776 in k2773 */
static void f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1170 display */
t2=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[629]);}

/* ##compiler#print-version in k2776 in k2773 */
static void f_7770(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_7770r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7770r(t0,t1,t2);}}

static void f_7770r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7774,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7784,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t5=t4;
f_7784(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7784(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1164 ##sys#error */
t6=*((C_word*)lf[626]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k7782 in ##compiler#print-version in k2776 in k2773 */
static void f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1164 printf */
t2=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[625],*((C_word*)lf[42]+1));}
else{
t2=((C_word*)t0)[2];
f_7774(2,t2,C_SCHEME_UNDEFINED);}}

/* k7772 in ##compiler#print-version in k2776 in k2773 */
static void f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1165 chicken-version */
t3=C_retrieve(lf[624]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k7779 in k7772 in ##compiler#print-version in k2776 in k2773 */
static void f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1165 printf */
t2=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[623],t1,lf[3]);}

/* ##compiler#chop-extension in k2776 in k2773 */
static void f_7728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7728,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7737,a[2]=t6,a[3]=t2,a[4]=lf[620],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7737(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k2776 in k2773 */
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7737,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1157 substring */
t6=*((C_word*)lf[616]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1158 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k2776 in k2773 */
static void f_7699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7699,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7709,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_7709(t7,(C_word)C_eqp(t6,C_retrieve(lf[617])));}
else{
t6=t5;
f_7709(t6,C_SCHEME_FALSE);}}

/* k7707 in ##compiler#chop-separator in k2776 in k2773 */
static void C_fcall f_7709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1150 substring */
t2=*((C_word*)lf[616]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k2776 in k2773 */
static void f_7502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7502,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7511,a[2]=t3,a[3]=t5,a[4]=lf[606],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=t5,a[3]=t3,a[4]=lf[608],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7593,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=lf[611],tmp=(C_word)a,a+=7,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7630,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7681,a[2]=t8,a[3]=lf[613],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a7680 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7681,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1133 insert */
t5=((C_word*)t0)[2];
f_7511(t5,t1,t3,t4);}

/* k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1136 caar */
t4=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k7673 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7679,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1136 cdar */
t3=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7677 in k7673 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1136 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7593(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7631 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[612],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7637 in k7631 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1138 lookup */
t5=((C_word*)t0)[2];
f_7558(t5,t3,t4);}

/* k7640 in a7637 in k7631 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[609]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1140 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7593(t5,((C_word*)t0)[4],t3,t4);}}

/* k7634 in k7631 in k7628 in ##compiler#topological-sort in k2776 in k2773 */
static void f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k2776 in k2773 */
static void C_fcall f_7593(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7593,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7597,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1121 insert */
t5=((C_word*)t0)[2];
f_7511(t5,t4,t2,lf[609]);}

/* k7595 in visit in ##compiler#topological-sort in k2776 in k2773 */
static void f_7597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[610],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7605 in k7595 in visit in ##compiler#topological-sort in k2776 in k2773 */
static void f_7606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7606,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7610,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1124 lookup */
t4=((C_word*)t0)[2];
f_7558(t4,t3,t2);}

/* k7608 in a7605 in k7595 in visit in ##compiler#topological-sort in k2776 in k2773 */
static void f_7610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[609]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1126 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7593(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k7598 in k7595 in visit in ##compiler#topological-sort in k2776 in k2773 */
static void f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k2776 in k2773 */
static void C_fcall f_7558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7558,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7564,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=lf[607],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7564(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k2776 in k2773 */
static void C_fcall f_7564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7564,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7591,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1116 caar */
t5=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7589 in loop in lookup in ##compiler#topological-sort in k2776 in k2773 */
static void f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1116 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7575 in loop in lookup in ##compiler#topological-sort in k2776 in k2773 */
static void f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1116 cdar */
t2=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1117 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7564(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k2776 in k2773 */
static void C_fcall f_7511(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7511,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7517,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=lf[605],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_7517(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k2776 in k2773 */
static void C_fcall f_7517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7517,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7556,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1110 caar */
t5=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7554 in loop in insert in ##compiler#topological-sort in k2776 in k2773 */
static void f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1110 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7536 in loop in insert in ##compiler#topological-sort in k2776 in k2773 */
static void f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1111 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7517(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7343,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7346,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=lf[600],tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7487,a[2]=t6,a[3]=lf[602],tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7500,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1093 walk */
t12=((C_word*)t6)[1];
f_7346(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k7498 in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k2776 in k2773 */
static void C_fcall f_7487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7487,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7493,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[601],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7492 in walkeach in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7493,3,t0,t1,t2);}
/* support.scm: 1091 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7346(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void C_fcall f_7346(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7346,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[149]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t7,a[8]=t9,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t12=t11;
f_7365(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[186]);
if(C_truep(t12)){
t13=t11;
f_7365(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[187]);
if(C_truep(t13)){
t14=t11;
f_7365(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[354]);
t15=t11;
f_7365(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[188])));}}}}

/* k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void C_fcall f_7365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7365,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[341]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1075 lset-adjoin */
t5=C_retrieve(lf[598]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[408]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[177]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_7396(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7410,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1078 lset-adjoin */
t7=C_retrieve(lf[598]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[408]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[163]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1081 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7346(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[381]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[599],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1084 ##compiler#decompose-lambda-list */
t8=C_retrieve(lf[223]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1088 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7487(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a7448 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7449,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7461,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1087 append */
t7=*((C_word*)lf[111]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7459 in a7448 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1087 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7346(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7417 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7430,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1082 append */
t4=*((C_word*)lf[111]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7428 in k7417 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1082 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7346(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7408 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7396(t3,t2);}

/* k7394 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void C_fcall f_7396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1079 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7346(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7382 in k7363 in walk in ##compiler#scan-free-variables in k2776 in k2773 */
static void f_7384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k2776 in k2773 */
static void f_7265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7265,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7269,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7271,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=lf[595],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7271(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k2776 in k2773 */
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7271,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[341]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[177]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7293,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7299,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_7299(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_7299(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[149]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7326,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7326(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[186]);
t12=t10;
f_7326(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[187])));}}}

/* k7324 in walk in ##compiler#scan-used-variables in k2776 in k2773 */
static void C_fcall f_7326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k7297 in walk in ##compiler#scan-used-variables in k2776 in k2773 */
static void C_fcall f_7299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7299,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7293(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_7293(t2,C_SCHEME_UNDEFINED);}}

/* k7291 in walk in ##compiler#scan-used-variables in k2776 in k2773 */
static void C_fcall f_7293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7267 in ##compiler#scan-used-variables in k2776 in k2773 */
static void f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k2776 in k2773 */
static void f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[102],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7027,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[510]);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[149],C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[585],t3,t6));}
else{
t6=(C_word)C_eqp(t4,lf[514]);
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,2,lf[149],C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[586],t3,t7));}
else{
t7=(C_word)C_eqp(t4,lf[511]);
if(C_truep(t7)){
t8=(C_word)C_a_i_list(&a,2,lf[149],C_fix(0));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,3,lf[587],t3,t8));}
else{
t8=(C_word)C_eqp(t4,lf[515]);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[149],C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[588],t3,t9));}
else{
t9=(C_word)C_eqp(t4,lf[516]);
if(C_truep(t9)){
t10=(C_word)C_a_i_list(&a,2,lf[149],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[585],t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,2,lf[589],t11));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7098,a[2]=t3,a[3]=lf[591],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[525]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7120,a[2]=t3,a[3]=t10,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(t2);
t17=t13;
f_7120(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7120(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7120(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(t2);
t14=(C_word)C_eqp(t13,lf[526]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7167,a[2]=t3,a[3]=t10,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(t2);
t19=t15;
f_7167(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7167(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7167(t17,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_car(t2);
t17=(C_word)C_eqp(t16,lf[527]);
if(C_truep(t17)){
t18=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(t2);
t21=t15;
f_7208(t21,(C_word)C_i_nullp(t20));}
else{
t20=t15;
f_7208(t20,C_SCHEME_FALSE);}}
else{
t19=t15;
f_7208(t19,C_SCHEME_FALSE);}}
else{
t18=t15;
f_7208(t18,C_SCHEME_FALSE);}}}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t3);}}}}}}}

/* k7206 in ##compiler#finish-foreign-result in k2776 in k2773 */
static void C_fcall f_7208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7208,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[149],lf[519]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,4,lf[592],t3,t4,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7165 in ##compiler#finish-foreign-result in k2776 in k2773 */
static void C_fcall f_7167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7167,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1038 g1053 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7098(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7118 in ##compiler#finish-foreign-result in k2776 in k2773 */
static void C_fcall f_7120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7120,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1038 g1053 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7098(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g1053 in ##compiler#finish-foreign-result in k2776 in k2773 */
static C_word C_fcall f_7098(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_a_i_list(&a,3,lf[590],((C_word*)t0)[2],t1));}

/* ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void f_6765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6768,a[2]=lf[579],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6777,a[2]=t3,a[3]=lf[580],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7021,a[2]=t2,a[3]=lf[582],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1005 ##compiler#follow-without-loop */
t6=*((C_word*)lf[144]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a7020 in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
/* support.scm: 1025 quit */
t2=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[581],((C_word*)t0)[2]);}

/* a6776 in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void f_6777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6777,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[486]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_6787(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[490]);
if(C_truep(t7)){
t8=t6;
f_6787(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[551]);
if(C_truep(t8)){
t9=t6;
f_6787(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[570]);
if(C_truep(t9)){
t10=t6;
f_6787(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[552]);
if(C_truep(t10)){
t11=t6;
f_6787(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[487]);
if(C_truep(t11)){
t12=t6;
f_6787(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[550]);
if(C_truep(t12)){
t13=t6;
f_6787(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[502]);
if(C_truep(t13)){
t14=t6;
f_6787(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[505]);
if(C_truep(t14)){
t15=t6;
f_6787(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[553]);
if(C_truep(t15)){
t16=t6;
f_6787(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[554]);
if(C_truep(t16)){
t17=t6;
f_6787(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[507]);
if(C_truep(t17)){
t18=t6;
f_6787(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[494]);
if(C_truep(t18)){
t19=t6;
f_6787(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[509]);
if(C_truep(t19)){
t20=t6;
f_6787(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[504]);
if(C_truep(t20)){
t21=t6;
f_6787(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[501]);
if(C_truep(t21)){
t22=t6;
f_6787(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[492]);
if(C_truep(t22)){
t23=t6;
f_6787(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[510]);
if(C_truep(t23)){
t24=t6;
f_6787(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[516]);
if(C_truep(t24)){
t25=t6;
f_6787(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[547]);
if(C_truep(t25)){
t26=t6;
f_6787(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[544]);
if(C_truep(t26)){
t27=t6;
f_6787(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[514]);
if(C_truep(t27)){
t28=t6;
f_6787(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[511]);
t29=t6;
f_6787(t29,(C_truep(t28)?t28:(C_word)C_eqp(t4,lf[515])));}}}}}}}}}}}}}}}}}}}}}}}

/* k6785 in a6776 in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void C_fcall f_6787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6787,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1013 ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[548]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[549]));
if(C_truep(t3)){
/* support.scm: 1015 ##compiler#words->bytes */
t4=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1017 ##sys#hash-table-ref */
t5=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[529]),((C_word*)t0)[3]);}
else{
t5=t4;
f_6805(2,t5,C_SCHEME_FALSE);}}}}

/* k6803 in k6785 in a6776 in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1019 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[523]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_6839(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[496]);
if(C_truep(t5)){
t6=t4;
f_6839(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[494]);
if(C_truep(t6)){
t7=t4;
f_6839(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[507]);
if(C_truep(t7)){
t8=t4;
f_6839(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[509]);
t9=t4;
f_6839(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[524])));}}}}}
else{
/* support.scm: 1024 err */
f_6768(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k6837 in k6803 in k6785 in a6776 in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void C_fcall f_6839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1022 ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1023 err */
f_6768(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k2776 in k2773 */
static void C_fcall f_6768(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6768,NULL,2,t1,t2);}
/* support.scm: 1004 quit */
t3=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[578],t2);}

/* ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void f_6500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6506,a[2]=lf[573],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=t2,a[3]=lf[575],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 979  ##compiler#follow-without-loop */
t5=*((C_word*)lf[144]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6758 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
/* support.scm: 1000 quit */
t2=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[574],((C_word*)t0)[2]);}

/* a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void f_6506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6506,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[486]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6516,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6516(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[490]);
if(C_truep(t7)){
t8=t6;
f_6516(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[551]);
if(C_truep(t8)){
t9=t6;
f_6516(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[570]);
if(C_truep(t9)){
t10=t6;
f_6516(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[571]);
if(C_truep(t10)){
t11=t6;
f_6516(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[552]);
if(C_truep(t11)){
t12=t6;
f_6516(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[572]);
if(C_truep(t12)){
t13=t6;
f_6516(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[487]);
if(C_truep(t13)){
t14=t6;
f_6516(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[550]);
if(C_truep(t14)){
t15=t6;
f_6516(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[553]);
t16=t6;
f_6516(t16,(C_truep(t15)?t15:(C_word)C_eqp(t4,lf[554])));}}}}}}}}}}

/* k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void C_fcall f_6516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6516,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[510]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6525(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[514]);
if(C_truep(t4)){
t5=t3;
f_6525(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[507]);
if(C_truep(t5)){
t6=t3;
f_6525(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[509]);
if(C_truep(t6)){
t7=t3;
f_6525(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[516]);
if(C_truep(t7)){
t8=t3;
f_6525(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[511]);
t9=t3;
f_6525(t9,(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[4],lf[515])));}}}}}}}

/* k6523 in k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void C_fcall f_6525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6525,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 985  ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[504]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6537(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[502]);
if(C_truep(t4)){
t5=t3;
f_6537(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[501]);
t6=t3;
f_6537(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[505])));}}}}

/* k6535 in k6523 in k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void C_fcall f_6537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6537,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 987  ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[492]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_6549(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[548]);
t5=t3;
f_6549(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[549])));}}}

/* k6547 in k6535 in k6523 in k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void C_fcall f_6549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6549,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 989  ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 991  ##sys#hash-table-ref */
t3=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[529]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6555(2,t3,C_SCHEME_FALSE);}}}

/* k6553 in k6547 in k6535 in k6523 in k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 993  next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[523]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_6589(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[496]);
if(C_truep(t5)){
t6=t4;
f_6589(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[494]);
if(C_truep(t6)){
t7=t4;
f_6589(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[507]);
if(C_truep(t7)){
t8=t4;
f_6589(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[509]);
if(C_truep(t8)){
t9=t4;
f_6589(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[524]);
if(C_truep(t9)){
t10=t4;
f_6589(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[525]);
if(C_truep(t10)){
t11=t4;
f_6589(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[526]);
t12=t4;
f_6589(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[527])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k6587 in k6553 in k6547 in k6535 in k6523 in k6514 in a6505 in ##compiler#estimate-foreign-result-size in k2776 in k2773 */
static void C_fcall f_6589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 997  ##compiler#words->bytes */
t2=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k2776 in k2773 */
static void f_6460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6466,a[2]=lf[565],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6494,a[2]=t2,a[3]=lf[567],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 966  ##compiler#follow-without-loop */
t5=*((C_word*)lf[144]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6493 in ##compiler#final-foreign-type in k2776 in k2773 */
static void f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
/* support.scm: 973  quit */
t2=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[566],((C_word*)t0)[2]);}

/* a6465 in ##compiler#final-foreign-type in k2776 in k2773 */
static void f_6466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6466,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6470,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 969  ##sys#hash-table-ref */
t5=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[529]),t2);}
else{
t5=t4;
f_6470(2,t5,C_SCHEME_FALSE);}}

/* k6468 in a6465 in ##compiler#final-foreign-type in k2776 in k2773 */
static void f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 971  next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k2776 in k2773 */
static void f_6429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6429,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6433,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6442,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 960  ##sys#hash-table-ref */
t6=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[529]),t3);}
else{
t5=t4;
f_6433(t5,C_SCHEME_FALSE);}}

/* k6440 in ##compiler#foreign-type-convert-argument in k2776 in k2773 */
static void f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6442,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_6433(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6433(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6433(t2,C_SCHEME_FALSE);}}

/* k6431 in ##compiler#foreign-type-convert-argument in k2776 in k2773 */
static void C_fcall f_6433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k2776 in k2773 */
static void f_6398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6398,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6411,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 953  ##sys#hash-table-ref */
t6=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[529]),t3);}
else{
t5=t4;
f_6402(t5,C_SCHEME_FALSE);}}

/* k6409 in ##compiler#foreign-type-convert-result in k2776 in k2773 */
static void f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_6402(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6402(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6402(t2,C_SCHEME_FALSE);}}

/* k6400 in ##compiler#foreign-type-convert-result in k2776 in k2773 */
static void C_fcall f_6402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5639,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5645,a[2]=t2,a[3]=lf[556],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t3,a[3]=lf[558],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 857  ##compiler#follow-without-loop */
t6=*((C_word*)lf[144]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a6391 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
/* support.scm: 946  quit */
t2=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[557],((C_word*)t0)[2]);}

/* a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5645,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5651,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[555],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5651(t7,t1,t2);}

/* repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5651,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[486]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[487]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[4]:(C_word)C_a_i_list(&a,2,lf[489],((C_word*)t0)[4])));}
else{
t6=(C_word)C_eqp(t3,lf[490]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5676(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[550]);
if(C_truep(t8)){
t9=t7;
f_5676(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[551]);
if(C_truep(t9)){
t10=t7;
f_5676(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[552]);
if(C_truep(t10)){
t11=t7;
f_5676(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[553]);
t12=t7;
f_5676(t12,(C_truep(t11)?t11:(C_word)C_eqp(t3,lf[554])));}}}}}}

/* k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5676,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[491],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[492]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5691(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[548]);
t5=t3;
f_5691(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[549])));}}}

/* k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5691,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[493],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[494]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5706(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[546]);
t5=t3;
f_5706(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[547])));}}}

/* k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5706,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 866  gensym */
t3=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[496]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5744(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[544]);
t5=t3;
f_5744(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[545])));}}}

/* k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5744,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[495],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[497]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5759(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[537]);
if(C_truep(t4)){
t5=t3;
f_5759(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[538]);
if(C_truep(t5)){
t6=t3;
f_5759(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[539]);
if(C_truep(t6)){
t7=t3;
f_5759(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[540]);
if(C_truep(t7)){
t8=t3;
f_5759(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[541]);
if(C_truep(t8)){
t9=t3;
f_5759(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[542]);
t10=t3;
f_5759(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[543])));}}}}}}}}

/* k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5759,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 878  gensym */
t3=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[499]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5801(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[530]);
if(C_truep(t4)){
t5=t3;
f_5801(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[531]);
if(C_truep(t5)){
t6=t3;
f_5801(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[532]);
if(C_truep(t6)){
t7=t3;
f_5801(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[533]);
if(C_truep(t7)){
t8=t3;
f_5801(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[534]);
if(C_truep(t8)){
t9=t3;
f_5801(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[535]);
t10=t3;
f_5801(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[536])));}}}}}}}}

/* k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5801,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[488]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[500]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[149],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[498],t4,((C_word*)t0)[6]));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[501]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[502]));
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[503],((C_word*)t0)[6])));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[504]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[505]));
if(C_truep(t5)){
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[488]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[506],((C_word*)t0)[6])));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[507]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 898  gensym */
t8=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[509]);
if(C_truep(t7)){
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,lf[508],((C_word*)t0)[6]));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[510]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[4],lf[511]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 906  gensym */
t11=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[514]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[4],lf[515]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[488]))){
t12=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,2,lf[512],((C_word*)t0)[6]));}
else{
t12=(C_word)C_a_i_list(&a,2,lf[513],((C_word*)t0)[6]);
t13=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_list(&a,2,lf[512],t12));}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[516]);
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[488]))){
t13=(C_word)C_a_i_list(&a,2,lf[517],((C_word*)t0)[6]);
t14=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,2,lf[512],t13));}
else{
t13=(C_word)C_a_i_list(&a,2,lf[517],((C_word*)t0)[6]);
t14=(C_word)C_a_i_list(&a,2,lf[513],t13);
t15=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,2,lf[512],t14));}}
else{
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
/* support.scm: 922  ##sys#hash-table-ref */
t14=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[529]),((C_word*)t0)[5]);}
else{
t14=t13;
f_5987(2,t14,C_SCHEME_FALSE);}}}}}}}}}}

/* k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 924  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[3],a[3]=lf[518],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6015,a[2]=((C_word*)t0)[3],a[3]=lf[521],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[3],a[3]=lf[522],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t6)){
/* support.scm: 926  g879 */
t7=t4;
f_6047(t7,((C_word*)t0)[5]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[494]);
if(C_truep(t8)){
/* support.scm: 926  g879 */
t9=t4;
f_6047(t9,((C_word*)t0)[5]);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[524]);
if(C_truep(t10)){
/* support.scm: 926  g879 */
t11=t4;
f_6047(t11,((C_word*)t0)[5]);}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[507]);
if(C_truep(t12)){
/* support.scm: 926  g879 */
t13=t4;
f_6047(t13,((C_word*)t0)[5]);}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[525]);
if(C_truep(t14)){
/* support.scm: 926  g880 */
t15=t3;
f_6015(t15,((C_word*)t0)[5]);}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[526]);
if(C_truep(t16)){
/* support.scm: 926  g880 */
t17=t3;
f_6015(t17,((C_word*)t0)[5]);}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[527]);
if(C_truep(t18)){
t19=(C_word)C_a_i_list(&a,2,lf[149],lf[519]);
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[520],((C_word*)t0)[3],t19));}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[528]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6159(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6159(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[496]);
if(C_truep(t22)){
/* support.scm: 926  g883 */
t23=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t23))(2,t23,f_6010(C_a_i(&a,6),t2));}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[509]);
/* support.scm: 926  g883 */
t25=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t25))(2,t25,(C_truep(t24)?f_6010(C_a_i(&a,6),t2):((C_word*)t0)[3]));}}}}}}}}}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6157 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_6159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* support.scm: 926  repeat */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5651(t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g879 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_6047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6047,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6051,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 928  gensym */
t3=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6049 in g879 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6051,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[508],t1);
t5=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[174],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[163],t3,t6));}

/* g880 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_6015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6015,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6019,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 934  gensym */
t3=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6017 in g880 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[149],lf[519]);
t5=(C_word)C_a_i_list(&a,3,lf[520],((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,4,lf[174],t1,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[163],t3,t7));}

/* g883 in k5985 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static C_word C_fcall f_6010(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_list(&a,2,lf[508],((C_word*)t0)[2]));}

/* k5900 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5917,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[488]))){
t5=t4;
f_5917(t5,(C_word)C_a_i_list(&a,2,lf[512],t1));}
else{
t5=(C_word)C_a_i_list(&a,2,lf[513],t1);
t6=t4;
f_5917(t6,(C_word)C_a_i_list(&a,2,lf[512],t5));}}

/* k5915 in k5900 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5917,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[174],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[163],((C_word*)t0)[2],t3));}

/* k5856 in k5799 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[508],t1);
t5=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[174],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[163],t3,t6));}

/* k5760 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5777,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[488]))){
t5=t4;
f_5777(t5,t1);}
else{
t5=(C_word)C_a_i_list(&a,2,lf[149],((C_word*)t0)[2]);
t6=t4;
f_5777(t6,(C_word)C_a_i_list(&a,3,lf[498],t5,t1));}}

/* k5775 in k5760 in k5757 in k5742 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void C_fcall f_5777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5777,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[174],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[163],((C_word*)t0)[2],t3));}

/* k5707 in k5704 in k5689 in k5674 in repeat in a5644 in ##compiler#foreign-type-check in k2776 in k2773 */
static void f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_truep(C_retrieve(lf[488]))?t1:(C_word)C_a_i_list(&a,2,lf[495],t1));
t5=(C_word)C_a_i_list(&a,2,lf[149],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[174],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[163],t3,t6));}

/* ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5603,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5607,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 838  open-output-file */
t5=*((C_word*)lf[482]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 838  current-output-port */
t5=*((C_word*)lf[483]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5605 in ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5610,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[2],a[3]=lf[480],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 839  with-output-to-port */
t4=C_retrieve(lf[481]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a5617 in k5605 in ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=lf[479],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5623 in a5617 in k5605 in ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5628,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 843  pretty-print */
t4=C_retrieve(lf[478]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5626 in a5623 in a5617 in k5605 in ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 844  newline */
t2=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5608 in k5605 in ##compiler#pprint-expressions-to-file in k2776 in k2773 */
static void f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 846  close-output-port */
t2=*((C_word*)lf[477]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5564,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5570,a[2]=t2,a[3]=lf[465],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5576,a[2]=lf[474],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5576,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5583,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 826  ##compiler#debugging */
t10=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[472],lf[473]);}

/* k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 827  printf */
t3=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[471],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5584 in k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 828  printf */
t3=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],((C_word*)t0)[2]);}

/* k5587 in k5584 in k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 829  printf */
t3=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[469],((C_word*)t0)[2]);}

/* k5590 in k5587 in k5584 in k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 830  printf */
t3=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[468],((C_word*)t0)[2]);}

/* k5593 in k5590 in k5587 in k5584 in k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 831  printf */
t3=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[467],((C_word*)t0)[2]);}

/* k5596 in k5593 in k5590 in k5587 in k5584 in k5581 in a5575 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 832  printf */
t2=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[466],((C_word*)t0)[2]);}

/* a5569 in ##compiler#print-program-statistics in k2776 in k2773 */
static void f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
/* support.scm: 825  ##compiler#compute-database-statistics */
t2=C_retrieve(lf[458]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k2776 in k2773 */
static void f_5484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5484,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5488,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5493,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,a[7]=lf[462],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 801  ##sys#hash-table-for-each */
t15=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a5492 in ##compiler#compute-database-statistics in k2776 in k2773 */
static void f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5493,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[461],tmp=(C_word)a,a+=8,tmp);
/* for-each */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5498 in a5492 in ##compiler#compute-database-statistics in k2776 in k2773 */
static void f_5499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5499,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[305]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[288]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[381],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[293]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k5486 in ##compiler#compute-database-statistics in k2776 in k2773 */
static void f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 815  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[459]),C_retrieve(lf[460]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#check-global-exports in k2776 in k2773 */
static void f_5440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5440,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[444]))){
t3=C_retrieve(lf[444]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5447,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5458,a[2]=t4,a[3]=lf[456],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 773  ##sys#hash-table-for-each */
t7=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5457 in ##compiler#check-global-exports in k2776 in k2773 */
static void f_5458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5458,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5462,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5469,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[303],t3);
t7=t5;
f_5469(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_5469(t6,C_SCHEME_FALSE);}}

/* k5467 in a5457 in ##compiler#check-global-exports in k2776 in k2773 */
static void C_fcall f_5469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 776  warning */
t2=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[455],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5462(2,t2,C_SCHEME_UNDEFINED);}}

/* k5460 in a5457 in ##compiler#check-global-exports in k2776 in k2773 */
static void f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 777  delete */
t3=C_retrieve(lf[454]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[408]+1));}

/* k5464 in k5460 in a5457 in ##compiler#check-global-exports in k2776 in k2773 */
static void f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5445 in ##compiler#check-global-exports in k2776 in k2773 */
static void f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=lf[453],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a5451 in k5445 in ##compiler#check-global-exports in k2776 in k2773 */
static void f_5452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5452,3,t0,t1,t2);}
/* warning */
t3=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[452],t2);}

/* ##compiler#dump-undefined-globals in k2776 in k2773 */
static void f_5409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5409,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=lf[449],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 762  ##sys#hash-table-for-each */
t4=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5414 in ##compiler#dump-undefined-globals in k2776 in k2773 */
static void f_5415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5415,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[305],t3))){
t5=(C_word)C_i_assq(lf[303],t3);
t6=t4;
f_5422(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5422(t5,C_SCHEME_FALSE);}}

/* k5420 in a5414 in ##compiler#dump-undefined-globals in k2776 in k2773 */
static void C_fcall f_5422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5422,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 766  write */
t3=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5423 in k5420 in a5414 in ##compiler#dump-undefined-globals in k2776 in k2773 */
static void f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 767  newline */
t2=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-exported-globals in k2776 in k2773 */
static void f_5360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5360,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[443]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5369,a[2]=lf[446],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 751  ##sys#hash-table-for-each */
t4=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}}

/* a5368 in ##compiler#dump-exported-globals in k2776 in k2773 */
static void f_5369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5369,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5376,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[305],t3))){
if(C_truep((C_word)C_i_assq(lf[303],t3))){
t5=(C_truep(C_retrieve(lf[444]))?(C_word)C_i_memq(t2,C_retrieve(lf[444])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5376(t6,t5);}
else{
t6=(C_word)C_i_memq(t2,C_retrieve(lf[445]));
t7=t4;
f_5376(t7,(C_word)C_i_not(t6));}}
else{
t5=t4;
f_5376(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5376(t5,C_SCHEME_FALSE);}}

/* k5374 in a5368 in ##compiler#dump-exported-globals in k2776 in k2773 */
static void C_fcall f_5376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 757  write */
t3=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5377 in k5374 in a5368 in ##compiler#dump-exported-globals in k2776 in k2773 */
static void f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 758  newline */
t2=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k2776 in k2773 */
static void f_5268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5268,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5292,a[2]=t9,a[3]=t7,a[4]=lf[440],tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5292(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k2776 in k2773 */
static void f_5292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5292,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[341],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 742  every */
t15=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[370]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 744  every */
t9=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k2776 in k2773 */
static void f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5182,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5188,a[2]=t5,a[3]=lf[437],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5188(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k2776 in k2773 */
static void f_5188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5188,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[341]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5204,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5204(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[149]);
if(C_truep(t9)){
t10=t8;
f_5204(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[186]);
if(C_truep(t10)){
t11=t8;
f_5204(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[354]);
t12=t8;
f_5204(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[347])));}}}}

/* k5202 in walk in ##compiler#expression-has-side-effects? in k2776 in k2773 */
static void C_fcall f_5204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5204,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[381]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5218,a[2]=t5,a[3]=lf[434],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 725  find */
t7=C_retrieve(lf[435]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],t6,C_retrieve(lf[436]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[174]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[163]));
if(C_truep(t4)){
/* support.scm: 726  any */
t5=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a5217 in k5202 in walk in ##compiler#expression-has-side-effects? in k2776 in k2773 */
static void f_5218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 725  foreign-callback-stub-id */
t4=C_retrieve(lf[433]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5224 in a5217 in k5202 in walk in ##compiler#expression-has-side-effects? in k2776 in k2773 */
static void f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k2776 in k2773 */
static void f_4987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4987,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4990,a[2]=t4,a[3]=t6,a[4]=lf[425],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=t9,a[3]=t7,a[4]=lf[426],tmp=(C_word)a,a+=5,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5062,a[2]=t9,a[3]=t12,a[4]=t7,a[5]=lf[428],tmp=(C_word)a,a+=6,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5166,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 709  matchn */
t15=((C_word*)t12)[1];
f_5062(t15,t14,t2,t3);}

/* k5164 in ##compiler#match-node in k2776 in k2773 */
static void f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 712  ##compiler#debugging */
t7=*((C_word*)lf[54]+1);
((C_proc7)C_retrieve_proc(t7))(7,t7,t2,lf[429],lf[430],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5170 in k5164 in ##compiler#match-node in k2776 in k2773 */
static void f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k2776 in k2773 */
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5062,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 698  resolve */
t4=((C_word*)t0)[4];
f_4990(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5084,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 700  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5019(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k5082 in matchn in ##compiler#match-node in k2776 in k2773 */
static void f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=lf[427],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5097(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k5082 in matchn in ##compiler#match-node in k2776 in k2773 */
static void C_fcall f_5097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5097,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 704  resolve */
t4=((C_word*)t0)[4];
f_4990(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5128,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 706  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5062(t7,t4,t5,t6);}}}}

/* k5126 in loop in k5082 in matchn in ##compiler#match-node in k2776 in k2773 */
static void f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 707  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5097(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k2776 in k2773 */
static void C_fcall f_5019(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5019,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 691  resolve */
t4=((C_word*)t0)[3];
f_4990(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5041,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 693  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k5039 in match1 in ##compiler#match-node in k2776 in k2773 */
static void f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 693  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5019(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k2776 in k2773 */
static void C_fcall f_4990(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4990,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5014,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 686  alist-cons */
t6=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k5012 in resolve in ##compiler#match-node in k2776 in k2773 */
static void f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k2776 in k2773 */
static void f_4925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4925,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4929,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 668  node-class-set! */
t7=C_retrieve(lf[328]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t3,t6);}

/* k4927 in ##compiler#copy-node! in k2776 in k2773 */
static void f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 669  node-parameters-set! */
t5=C_retrieve(lf[333]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4930 in k4927 in ##compiler#copy-node! in k2776 in k2773 */
static void f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 670  node-subexpressions-set! */
t5=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4933 in k4930 in k4927 in ##compiler#copy-node! in k2776 in k2773 */
static void f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=lf[422],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4946(t4,C_fix(4)));}

/* do669 in k4933 in k4930 in k4927 in ##compiler#copy-node! in k2776 in k2773 */
static C_word C_fcall f_4946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k2776 in k2773 */
static void f_4891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4891,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4897,a[2]=t4,a[3]=lf[419],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4897(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k2776 in k2773 */
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4897,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 664  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4909 in rec in ##compiler#tree-copy in k2776 in k2773 */
static void f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4915,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 664  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4897(t4,t2,t3);}

/* k4913 in k4909 in rec in ##compiler#tree-copy in k2776 in k2773 */
static void f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4713,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4717,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 632  map */
t6=*((C_word*)lf[194]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[417]+1),t3,t4);}

/* k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=lf[409],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=t4,a[3]=t2,a[4]=lf[416],tmp=(C_word)a,a+=5,tmp));
/* support.scm: 659  walk */
t6=((C_word*)t4)[1];
f_4725(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void C_fcall f_4725(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4725,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[341]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4748,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 639  rename */
f_4719(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[177]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4777,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 640  rename */
f_4719(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[163]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4793,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 643  gensym */
t15=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[381]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4826,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,a[7]=lf[413],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 647  ##compiler#decompose-lambda-list */
t16=C_retrieve(lf[223]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4874,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 658  ##compiler#tree-copy */
t15=C_retrieve(lf[415]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}}}}}

/* k4872 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4877,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[414],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4881 in k4872 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4882,3,t0,t1,t2);}
/* walk615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4725(t3,t1,t2,((C_word*)t0)[2]);}

/* k4875 in k4872 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4826,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[164]),t2);}

/* k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 651  append */
t3=*((C_word*)lf[111]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4831 in k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 655  rename */
f_4719(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_4868(2,t6,C_SCHEME_FALSE);}}

/* k4866 in k4831 in k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 655  ##compiler#build-lambda-list */
t2=*((C_word*)lf[103]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4858 in k4831 in k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4839,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[412],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4843 in k4858 in k4831 in k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4844,3,t0,t1,t2);}
/* walk615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4725(t3,t1,t2,((C_word*)t0)[2]);}

/* k4837 in k4858 in k4831 in k4828 in a4825 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[381],((C_word*)t0)[2],t1));}

/* k4791 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 644  alist-cons */
t3=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4794 in k4791 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[411],tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4806 in k4794 in k4791 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4807,3,t0,t1,t2);}
/* walk615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4725(t3,t1,t2,((C_word*)t0)[2]);}

/* k4800 in k4794 in k4791 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[163],((C_word*)t0)[2],t1));}

/* k4775 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4764,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[410],tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4768 in k4775 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4769,3,t0,t1,t2);}
/* walk615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4725(t3,t1,t2,((C_word*)t0)[2]);}

/* k4762 in k4775 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[177],((C_word*)t0)[2],t1));}

/* k4746 in walk in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 639  ##compiler#varnode */
t2=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k4715 in ##compiler#copy-node-tree-and-rename in k2776 in k2773 */
static void C_fcall f_4719(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4719,NULL,3,t1,t2,t3);}
/* support.scm: 633  alist-ref */
t4=C_retrieve(lf[407]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[408]+1),t2);}

/* ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4620,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4626,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=lf[405],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 610  ##compiler#decompose-lambda-list */
t7=C_retrieve(lf[223]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4626,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4632,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=lf[398],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4638,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=lf[404],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4638,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[164]),((C_word*)t0)[2]);}
else{
t5=t4;
f_4642(2,t5,((C_word*)t0)[2]);}}

/* k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 616  ##compiler#copy-node-tree-and-rename */
t3=C_retrieve(lf[403]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_4645(2,t3,((C_word*)t0)[3]);}}

/* k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4650,a[2]=lf[399],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 622  last */
t5=C_retrieve(lf[378]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_4664(t4,t1);}}

/* k4703 in k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4681,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 624  ##compiler#qnode */
t4=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[402],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_4681(2,t8,(C_word)C_a_i_record(&a,4,lf[322],lf[180],t6,t7));}}

/* k4679 in k4703 in k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4664(t3,(C_word)C_a_i_record(&a,4,lf[322],lf[163],((C_word*)t0)[2],t2));}

/* k4662 in k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void C_fcall f_4664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4664,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 628  take */
t3=C_retrieve(lf[401]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4666 in k4662 in k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 618  fold-right */
t2=C_retrieve(lf[400]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4649 in k4643 in k4640 in a4637 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4650,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[322],lf[163],t5,t6));}

/* a4631 in a4625 in ##compiler#inline-lambda-bindings in k2776 in k2773 */
static void f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
/* support.scm: 613  split-at */
t2=C_retrieve(lf[397]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k2776 in k2773 */
static void f_4572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4572,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4578,a[2]=t5,a[3]=t2,a[4]=lf[394],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4578(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k2776 in k2773 */
static void C_fcall f_4578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4578,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 606  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k4596 in fold in ##compiler#fold-boolean in k2776 in k2773 */
static void f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 607  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4578(t4,t2,t3);}

/* k4600 in k4596 in fold in ##compiler#fold-boolean in k2776 in k2773 */
static void f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[322],lf[179],lf[393],t2));}

/* ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4278,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t4,a[3]=lf[390],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4284(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4284,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[174]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4303,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_4303(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[388]);
t12=t10;
f_4303(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[389])));}}

/* k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void C_fcall f_4303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4303,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[341]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[347]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[149]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[149],t6));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[163]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4377,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 580  butlast */
t10=C_retrieve(lf[380]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[381]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[178]:lf[381]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4402,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 587  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_4284(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[370]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4435,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[186]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[382]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4459,a[2]=t14,a[3]=((C_word*)t0)[4],a[4]=lf[383],tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_4459(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[384]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4513(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[385]);
if(C_truep(t14)){
t15=t13;
f_4513(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[386]);
t16=t13;
f_4513(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[387])));}}}}}}}}}}}}}

/* k4511 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void C_fcall f_4513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4513,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 597  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4284(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4541 in k4511 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 598  append */
t2=*((C_word*)lf[111]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4537 in k4511 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4518 in k4511 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k4522 in k4518 in k4511 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 597  cons* */
t2=C_retrieve(lf[172]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4459,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 594  reverse */
t7=*((C_word*)lf[142]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4500,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 595  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_4284(3,t10,t8,t9);}}

/* k4498 in loop in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 595  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4459(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4471 in loop in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 594  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4284(3,t4,t2,t3);}

/* k4475 in k4471 in loop in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[382],((C_word*)t0)[2],t1));}

/* k4433 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 589  cons* */
t2=C_retrieve(lf[172]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[370],((C_word*)t0)[2],t1);}

/* k4400 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4402,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4379 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4375 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 580  map */
t2=*((C_word*)lf[194]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[379]+1),((C_word*)t0)[2],t1);}

/* k4363 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4369,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 581  last */
t4=C_retrieve(lf[378]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4371 in k4363 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 581  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4284(3,t2,((C_word*)t0)[2],t1);}

/* k4367 in k4363 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[163],((C_word*)t0)[2],t1));}

/* k4325 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 568  ##sys#cons */
t2=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4321 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 568  ##sys#cons */
t2=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[377],t1);}

/* k4308 in k4301 in walk in ##compiler#build-expression-tree in k2776 in k2773 */
static void f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k2776 in k2773 */
static void f_3751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3751,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3754,a[2]=t4,a[3]=t6,a[4]=lf[372],tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4273,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 564  walk */
t9=((C_word*)t6)[1];
f_3754(3,t9,t8,t2);}

/* k4271 in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 565  ##compiler#debugging */
t3=*((C_word*)lf[54]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[373],lf[374],((C_word*)((C_word*)t0)[2])[1]);}

/* k4274 in k4271 in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(49);
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3754,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 497  ##compiler#varnode */
t3=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 498  ##compiler#bomb */
t3=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[346]);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[347]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[322],lf[347],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[174]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[186]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[149]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3836,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[350],C_retrieve(lf[351]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_3839(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_3839(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_3839(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[163]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 516  walk */
t38=t1;
t39=t11;
t1=t38;
t2=t39;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3889,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 517  unzip1 */
t13=C_retrieve(lf[353]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[178]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3940,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_caddr(t2);
/* support.scm: 520  walk */
t38=t13;
t39=t14;
t1=t38;
t2=t39;
c=3;
goto loop;}
else{
t11=(C_word)C_eqp(t4,lf[187]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_i_car(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t13,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t12))){
t15=(C_word)C_i_car(t12);
t16=t14;
f_3980(t16,(C_word)C_eqp(lf[149],t15));}
else{
t15=t14;
f_3980(t15,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t4,lf[177]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4002(t14,t12);}
else{
t14=(C_word)C_eqp(t4,lf[179]);
t15=t13;
f_4002(t15,(C_truep(t14)?t14:(C_word)C_eqp(t4,lf[370])));}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4263,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k4261 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4263,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[359],lf[371],t1));}

/* k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_4002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4002,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[4])[1],t6);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[354]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,t3,C_SCHEME_TRUE);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[322],lf[354],t4,C_SCHEME_END_OF_LIST));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[171]);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4050,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t8=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)((C_word*)t0)[4])[1],t7);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[355]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[6]);
t8=(C_word)C_i_cadr(t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t10=(C_word)C_i_cadr(t9);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,a[6]=t8,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 536  fifth */
t12=C_retrieve(lf[357]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[180]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4124(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[188]);
if(C_truep(t7)){
t8=t6;
f_4124(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[181]);
if(C_truep(t8)){
t9=t6;
f_4124(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[182]);
t10=t6;
f_4124(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[3],lf[183])));}}}}}}}}

/* k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_4124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4133,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[358]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[6],a[3]=lf[361],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=lf[369],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 544  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4181,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[368])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_4181(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_4181(t5,C_SCHEME_FALSE);}}

/* k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_4181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4181,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 553  ##compiler#real-name */
t4=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 561  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4186 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 554  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k4189 in k4186 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 558  max */
t6=*((C_word*)lf[367]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k4207 in k4189 in k4186 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 558  make-string */
t2=*((C_word*)lf[366]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k4196 in k4189 in k4186 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4202(2,t3,((C_word*)t0)[3]);}
else{
/* support.scm: 560  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[365]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4200 in k4196 in k4189 in k4186 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 555  string-append */
t2=*((C_word*)lf[50]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_retrieve(lf[362]),lf[363],((C_word*)t0)[3],((C_word*)t0)[2],lf[364],t1);}

/* k4183 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4174,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k4172 in k4183 in k4179 in a4166 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[359],((C_word*)t0)[2],t1));}

/* a4160 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
/* support.scm: 545  ##compiler#get-line-2 */
t2=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4147 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[359],lf[360],t1));}

/* k4131 in k4122 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4101 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4103,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4087,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 537  sixth */
t6=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k4085 in k4101 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 537  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3754(3,t2,((C_word*)t0)[2],t1);}

/* k4081 in k4101 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[322],lf[355],((C_word*)t0)[2],t2));}

/* k4048 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[177],((C_word*)t0)[2],t1));}

/* k4009 in k4000 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3978 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_3980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3980,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k3964 in k3978 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3938 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[322],lf[178],((C_word*)t0)[2],t2));}

/* k3887 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3892,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[4],a[3]=lf[352],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3908 in k3887 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3909,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 518  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3754(3,t4,t1,t3);}

/* k3897 in k3887 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3907,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 519  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3754(3,t3,t2,((C_word*)t0)[2]);}

/* k3905 in k3897 in k3887 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 518  append */
t3=*((C_word*)lf[111]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3890 in k3887 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3892,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],lf[163],((C_word*)t0)[2],t1));}

/* k3837 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_3839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 509  warning */
t3=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[349],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3836(t2,((C_word*)t0)[2]);}}

/* k3840 in k3837 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 510  truncate */
t3=*((C_word*)lf[348]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3847 in k3840 in k3837 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3836(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k3834 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void C_fcall f_3836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 505  ##compiler#qnode */
t2=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3811 in walk in ##compiler#build-node-graph in k2776 in k2773 */
static void f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3813,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[322],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k2776 in k2773 */
static void f_3742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3742,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[322],lf[149],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k2776 in k2773 */
static void f_3733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3733,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[322],lf[341],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k2776 in k2773 */
static void f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3727,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[322],t2,t3,t4));}

/* node-subexpressions-set! in k2776 in k2773 */
static void f_3718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3718,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[322]);
/* support.scm: 483  ##sys#block-set! */
t5=*((C_word*)lf[329]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-subexpressions in k2776 in k2773 */
static void f_3709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3709,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[322]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-parameters-set! in k2776 in k2773 */
static void f_3700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3700,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[322]);
/* support.scm: 483  ##sys#block-set! */
t5=*((C_word*)lf[329]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-parameters in k2776 in k2773 */
static void f_3691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3691,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[322]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-class-set! in k2776 in k2773 */
static void f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3682,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[322]);
/* support.scm: 483  ##sys#block-set! */
t5=*((C_word*)lf[329]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node-class in k2776 in k2773 */
static void f_3673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3673,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[322]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node? in k2776 in k2773 */
static void f_3667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3667,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[322]));}

/* f_3661 in k2776 in k2773 */
static void f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3661,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[322],t2,t3,t4));}

/* ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3280,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3286,a[2]=lf[319],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 440  ##sys#hash-table-for-each */
t4=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3286,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3290,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 446  write */
t13=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}

/* k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=lf[318],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3370(t6,t2,((C_word*)t0)[2]);}

/* loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void C_fcall f_3370(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3370,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 450  caar */
t4=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[285]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3396(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[303]);
if(C_truep(t5)){
t6=t4;
f_3396(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[304]);
if(C_truep(t6)){
t7=t4;
f_3396(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[305]);
if(C_truep(t7)){
t8=t4;
f_3396(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[306]);
if(C_truep(t8)){
t9=t4;
f_3396(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[247]);
if(C_truep(t9)){
t10=t4;
f_3396(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[240]);
if(C_truep(t10)){
t11=t4;
f_3396(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[307]);
if(C_truep(t11)){
t12=t4;
f_3396(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[246]);
if(C_truep(t12)){
t13=t4;
f_3396(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[308]);
if(C_truep(t13)){
t14=t4;
f_3396(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[309]);
if(C_truep(t14)){
t15=t4;
f_3396(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[310]);
if(C_truep(t15)){
t16=t4;
f_3396(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[311]);
if(C_truep(t16)){
t17=t4;
f_3396(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[312]);
if(C_truep(t17)){
t18=t4;
f_3396(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[313]);
if(C_truep(t18)){
t19=t4;
f_3396(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[314]);
if(C_truep(t19)){
t20=t4;
f_3396(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[315]);
if(C_truep(t20)){
t21=t4;
f_3396(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[241]);
if(C_truep(t21)){
t22=t4;
f_3396(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[316]);
if(C_truep(t22)){
t23=t4;
f_3396(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[236]);
t24=t4;
f_3396(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[317])));}}}}}}}}}}}}}}}}}}}}

/* k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void C_fcall f_3396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3396,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 454  caar */
t3=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[284]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[284]);
t4=((C_word*)t0)[8];
f_3383(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[284]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_3383(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 458  cdar */
t6=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 460  cdar */
t6=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[290]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3453(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[295]);
if(C_truep(t7)){
t8=t6;
f_3453(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[296]);
if(C_truep(t8)){
t9=t6;
f_3453(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[270]);
if(C_truep(t9)){
t10=t6;
f_3453(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[297]);
if(C_truep(t10)){
t11=t6;
f_3453(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[298]);
if(C_truep(t11)){
t12=t6;
f_3453(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[299]);
if(C_truep(t12)){
t13=t6;
f_3453(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[300]);
if(C_truep(t13)){
t14=t6;
f_3453(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[301]);
t15=t6;
f_3453(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[302])));}}}}}}}}}}}}}

/* k3451 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void C_fcall f_3453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3453,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 463  caar */
t3=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[292]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 465  cdar */
t4=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[293]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 467  cdar */
t5=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 468  ##compiler#bomb */
t5=*((C_word*)lf[48]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[294],t4);}}}}

/* k3482 in k3451 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3383(2,t3,t2);}

/* k3472 in k3451 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3383(2,t3,t2);}

/* k3458 in k3451 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 463  cdar */
t3=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3462 in k3458 in k3451 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 463  printf */
t2=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[291],((C_word*)t0)[2],t1);}

/* k3442 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3383(2,t3,t2);}

/* k3432 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3383(2,t3,t2);}

/* k3409 in k3394 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[286]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 454  printf */
t4=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[287],t3);}

/* k3381 in k3378 in loop in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 469  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3370(t3,((C_word*)t0)[2],t2);}

/* k3291 in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[284]);
t5=t3;
f_3328(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3328(t4,C_SCHEME_FALSE);}}

/* k3326 in k3291 in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void C_fcall f_3328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3328,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 471  printf */
t7=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[282],t6);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 472  printf */
t7=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[283],t6);}
else{
t2=((C_word*)t0)[3];
f_3296(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3294 in k3291 in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 473  printf */
t4=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[281],t3);}
else{
t3=t2;
f_3299(2,t3,C_SCHEME_UNDEFINED);}}

/* k3297 in k3294 in k3291 in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 474  printf */
t4=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}
else{
t3=t2;
f_3302(2,t3,C_SCHEME_UNDEFINED);}}

/* k3300 in k3297 in k3294 in k3291 in k3288 in a3285 in ##compiler#display-analysis-database in k2776 in k2773 */
static void f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 475  newline */
t2=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k2776 in k2773 */
static void f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3267,a[2]=lf[276],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 425  ##sys#hash-table-for-each */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[265]));}

/* a3266 in ##compiler#display-line-number-database in k2776 in k2773 */
static void f_3267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3267,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3278,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[275]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3276 in a3266 in ##compiler#display-line-number-database in k2776 in k2773 */
static void f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 427  printf */
t2=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[274],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k2776 in k2773 */
static void f_3237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3237,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=lf[271],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3243(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k2776 in k2773 */
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3243,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 421  ##compiler#get */
t5=C_retrieve(lf[251]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[270]);}}

/* k3251 in loop in ##compiler#find-lambda-container in k2776 in k2773 */
static void f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 422  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3243(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k2776 in k2773 */
static void f_3201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3201,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 413  ##sys#hash-table-ref */
t5=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[265]),t3);}

/* k3206 in ##compiler#get-line-2 in k2776 in k2773 */
static void f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_3211(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_3211(t3,C_SCHEME_FALSE);}}

/* k3209 in k3206 in ##compiler#get-line-2 in k2776 in k2773 */
static void C_fcall f_3211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 415  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 416  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k2776 in k2773 */
static void f_3191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3191,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 409  ##compiler#get */
t4=C_retrieve(lf[251]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[265]),t3,t2);}

/* ##compiler#count! in k2776 in k2773 */
static void f_3134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_3134r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3134r(t0,t1,t2,t3,t4,t5);}}

static void f_3134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3138,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 397  ##sys#hash-table-ref */
t7=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3136 in ##compiler#count! in k2776 in k2773 */
static void f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3138,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 402  alist-cons */
t7=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 403  ##sys#hash-table-set! */
t6=C_retrieve(lf[258]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k3166 in k3136 in ##compiler#count! in k2776 in k2773 */
static void f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k2776 in k2773 */
static void f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3082,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3086,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 389  ##sys#hash-table-ref */
t7=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3084 in ##compiler#collect! in k2776 in k2773 */
static void f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 393  alist-cons */
t6=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 394  ##sys#hash-table-set! */
t4=C_retrieve(lf[258]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k3111 in k3084 in ##compiler#collect! in k2776 in k2773 */
static void f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k2776 in k2773 */
static void f_3036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3036,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3040,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 381  ##sys#hash-table-ref */
t7=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3038 in ##compiler#put! in k2776 in k2773 */
static void f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 385  alist-cons */
t5=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 386  ##sys#hash-table-set! */
t4=C_retrieve(lf[258]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3060 in k3038 in ##compiler#put! in k2776 in k2773 */
static void f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k2776 in k2773 */
static void f_3018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3018r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3018r(t0,t1,t2,t3,t4);}}

static void f_3018r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3022,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 375  ##sys#hash-table-ref */
t6=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3020 in ##compiler#get-all in k2776 in k2773 */
static void f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3030,a[2]=t1,a[3]=lf[255],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 377  filter-map */
t3=C_retrieve(lf[256]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a3029 in k3020 in ##compiler#get-all in k2776 in k2773 */
static void f_3030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3030,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k2776 in k2773 */
static void f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3000,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 369  ##sys#hash-table-ref */
t6=C_retrieve(lf[252]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3002 in ##compiler#get in k2776 in k2773 */
static void f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2939,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=t2,a[3]=lf[248],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[249]));}

/* a2975 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 355  ##compiler#put! */
t4=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[247],C_SCHEME_TRUE);}

/* k2978 in a2975 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[245])))){
/* support.scm: 356  ##compiler#put! */
t3=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[246],C_SCHEME_TRUE);}
else{
t3=t2;
f_2983(2,t3,C_SCHEME_UNDEFINED);}}

/* k2981 in k2978 in a2975 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[244])))){
/* support.scm: 357  ##compiler#put! */
t2=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[240],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2941 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[3],a[3]=lf[242],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[243]));}

/* a2960 in k2941 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2961,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 361  ##compiler#put! */
t4=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[241],C_SCHEME_TRUE);}

/* k2963 in a2960 in k2941 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[239])))){
/* support.scm: 362  ##compiler#put! */
t2=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[240],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2944 in k2941 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=lf[237],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[238]));}

/* a2950 in k2944 in k2941 in ##compiler#initialize-analysis-database in k2776 in k2773 */
static void f_2951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2951,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 365  ##compiler#put! */
t4=C_retrieve(lf[235]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[236],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k2776 in k2773 */
static void f_2882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2882,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[226]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2886,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 337  gensym */
t7=C_retrieve(lf[164]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k2884 in ##compiler#expand-profile-lambda in k2776 in k2773 */
static void f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 338  alist-cons */
t3=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[227]));}

/* k2888 in k2884 in ##compiler#expand-profile-lambda in k2776 in k2773 */
static void f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=C_mutate((C_word*)lf[227]+1,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[226]+1,t3);
t5=(C_word)C_a_i_list(&a,2,lf[149],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[228],t5,C_retrieve(lf[229]));
t7=(C_word)C_a_i_list(&a,3,lf[178],C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[5],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,3,lf[230],t8,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[178],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,lf[149],((C_word*)t0)[6]);
t12=(C_word)C_a_i_list(&a,3,lf[231],t11,C_retrieve(lf[229]));
t13=(C_word)C_a_i_list(&a,3,lf[178],C_SCHEME_END_OF_LIST,t12);
t14=(C_word)C_a_i_list(&a,4,lf[232],t7,t10,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[3],t14));}

/* ##compiler#string->expr in k2776 in k2773 */
static void f_2779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=lf[220],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[221]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2788,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2794,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[205],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2819,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=lf[218],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[3],a[3]=lf[215],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=lf[217],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2868 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2869(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2869r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2869r(t0,t1,t2);}}

static void f_2869r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2875,a[2]=t2,a[3]=lf[216],tmp=(C_word)a,a+=4,tmp);
/* g286288 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2874 in a2868 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2824 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2853,a[2]=lf[213],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 325  with-input-from-string */
t4=C_retrieve(lf[214]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a2852 in a2824 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2859,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2867,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 325  read */
t4=*((C_word*)lf[208]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2865 in a2852 in a2824 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 325  unfold */
t2=C_retrieve(lf[210]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[211]+1),*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* a2858 in a2852 in a2824 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2859,3,t0,t1,t2);}
/* support.scm: 325  read */
t3=*((C_word*)lf[208]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2827 in a2824 in a2818 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[206]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
/* support.scm: 315  ##sys#cons */
t3=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[207],t1);}}}

/* a2793 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[204],tmp=(C_word)a,a+=7,tmp);
/* g286288 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2799 in a2793 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 322  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2809 in a2799 in a2793 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 323  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 324  ->string */
t2=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2806 in a2799 in a2793 in a2787 in ##compiler#string->expr in k2776 in k2773 */
static void f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 320  quit */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[203],((C_word*)t0)[2],t1);}

/* k2784 in ##compiler#string->expr in k2776 in k2773 */
static void f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#extract-mutable-constants */
static void f_2404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2404,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=t4,a[3]=t6,a[4]=lf[200],tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 312  walk */
t9=((C_word*)t6)[1];
f_2407(3,t9,t8,t2);}

/* k2766 in ##compiler#extract-mutable-constants */
static void f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 313  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#extract-mutable-constants */
static void f_2407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2407,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[189],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[149]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
t9=t6;
f_2561(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_2561(t8,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2612,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[163]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=t6;
f_2612(t11,(C_word)C_i_listp(t10));}
else{
t10=t6;
f_2612(t10,C_SCHEME_FALSE);}}
else{
t9=t6;
f_2612(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k2610 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[199],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2621(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g231234 */
t4=((C_word*)t0)[3];
f_2409(t4,((C_word*)t0)[2],t2,t3);}}

/* g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2621,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2631,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t6=*((C_word*)lf[142]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2722,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t8=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t7=t5;
f_2668(t7,C_SCHEME_FALSE);}}}

/* k2720 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* cddar */
t3=*((C_word*)lf[197]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2668(t2,C_SCHEME_FALSE);}}

/* k2716 in k2720 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2668(t2,(C_word)C_i_nullp(t1));}

/* k2666 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* cadar */
t4=*((C_word*)lf[196]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* g231234 */
t4=((C_word*)t0)[2];
f_2409(t4,((C_word*)t0)[4],t2,t3);}}

/* k2689 in k2666 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2691,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2687,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* caar */
t4=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2685 in k2689 in k2666 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* g226271 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2621(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2634,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t3=*((C_word*)lf[142]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2648,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[3],a[3]=lf[193],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[194]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a2653 in k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2654,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2662,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* walk221 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2407(3,t5,t4,t3);}

/* k2660 in a2653 in k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2646 in k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2650 in k2646 in k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2642 in k2632 in k2629 in g226 in k2610 in walk in ##compiler#extract-mutable-constants */
static void f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[163],t1);}

/* k2559 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2561,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2581,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##compiler#collapsable-literal? */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g231234 */
t4=((C_word*)t0)[2];
f_2409(t4,((C_word*)t0)[4],t2,t3);}}

/* k2579 in k2559 in walk in ##compiler#extract-mutable-constants */
static void f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2581,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##compiler#make-random-name */
t3=C_retrieve(lf[191]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2571 in k2579 in k2559 in walk in ##compiler#extract-mutable-constants */
static void f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* alist-cons */
t3=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2575 in k2571 in k2579 in k2559 in walk in ##compiler#extract-mutable-constants */
static void f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* g231 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2409(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2409,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[170]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2419(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[184]);
if(C_truep(t7)){
t8=t6;
f_2419(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[185]);
if(C_truep(t8)){
t9=t6;
f_2419(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[186]);
if(C_truep(t9)){
t10=t6;
f_2419(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[187]);
t11=t6;
f_2419(t11,(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[188])));}}}}}

/* k2417 in g231 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2419,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[171]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_2428(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[177]);
if(C_truep(t4)){
t5=t3;
f_2428(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[178]);
if(C_truep(t5)){
t6=t3;
f_2428(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[179]);
if(C_truep(t6)){
t7=t3;
f_2428(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[180]);
if(C_truep(t7)){
t8=t3;
f_2428(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[181]);
if(C_truep(t8)){
t9=t3;
f_2428(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[182]);
t10=t3;
f_2428(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[183])));}}}}}}}}

/* k2426 in k2417 in g231 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2428,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[174]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2452(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[175]);
t5=t3;
f_2452(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[3],lf[176])));}}}

/* k2450 in k2426 in k2417 in g231 in walk in ##compiler#extract-mutable-constants */
static void C_fcall f_2452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2452,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
/* map */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}}

/* k2457 in k2450 in k2426 in k2417 in g231 in walk in ##compiler#extract-mutable-constants */
static void f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2437 in k2426 in k2417 in g231 in walk in ##compiler#extract-mutable-constants */
static void f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 307  cons* */
t2=C_retrieve(lf[172]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#canonicalize-begin-body */
static void f_2321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2321,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2327,a[2]=t4,a[3]=lf[167],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2327(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[161]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[162]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2355,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_2355(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 283  ##compiler#constant? */
t8=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k2390 in loop in ##compiler#canonicalize-begin-body */
static void f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2355(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[166])));}

/* k2353 in loop in ##compiler#canonicalize-begin-body */
static void C_fcall f_2355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2355,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 285  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2327(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 286  gensym */
t3=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[165]);}}

/* k2383 in k2353 in loop in ##compiler#canonicalize-begin-body */
static void f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2373,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 287  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2327(t7,t5,t6);}

/* k2371 in k2383 in k2353 in loop in ##compiler#canonicalize-begin-body */
static void f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[163],((C_word*)t0)[2],t1));}

/* ##compiler#compressable-literal */
static void f_2223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2223,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2227,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2238,a[2]=t8,a[3]=t5,a[4]=lf[158],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2238(3,t10,t6,t2);}

/* rec in ##compiler#compressable-literal */
static void f_2238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2238,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_numberp(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_2249(t7,t5);}
else{
t7=(C_word)C_charp(t2);
if(C_truep(t7)){
t8=t6;
f_2249(t8,t7);}
else{
t8=(C_word)C_i_stringp(t2);
if(C_truep(t8)){
t9=t6;
f_2249(t9,t8);}
else{
t9=(C_word)C_booleanp(t2);
if(C_truep(t9)){
t10=t6;
f_2249(t10,t9);}
else{
t10=(C_word)C_i_nullp(t2);
t11=t6;
f_2249(t11,(C_truep(t10)?t10:(C_word)C_i_symbolp(t2)));}}}}}

/* k2247 in rec in ##compiler#compressable-literal */
static void C_fcall f_2249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 269  rec */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2238(3,t6,t4,t5);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 270  vector->list */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}}

/* k2290 in k2247 in rec in ##compiler#compressable-literal */
static void f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 270  every */
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2266 in k2247 in rec in ##compiler#compressable-literal */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 269  rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2238(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2225 in ##compiler#compressable-literal */
static void f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=((C_word*)t0)[3];
t4=(C_word)C_fixnum_greaterp(t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?((C_word*)((C_word*)t0)[4])[1]:C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? */
static void f_2187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2187,3,t0,t1,t2);}
t3=(C_word)C_fixnump(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eqp(C_SCHEME_UNDEFINED,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_nullp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_eofp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_charp(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t7)?t7:(C_word)C_booleanp(t2)));}}}}}

/* ##compiler#collapsable-literal? */
static void f_2157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2157,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? */
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2111,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[149],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop */
static void f_2080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2080,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2086,a[2]=t3,a[3]=t6,a[4]=t4,a[5]=lf[146],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2086(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop */
static void C_fcall f_2086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2086,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 233  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=lf[145],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 234  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a2100 in loop in ##compiler#follow-without-loop */
static void f_2101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2101,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 234  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2086(t4,t1,t2,t3);}

/* ##compiler#fold-inner */
static void f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2017,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2031,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 223  reverse */
t6=*((C_word*)lf[142]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k2029 in ##compiler#fold-inner */
static void f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2033,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[141],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2033(t5,((C_word*)t0)[2],t1);}

/* fold in k2029 in ##compiler#fold-inner */
static void C_fcall f_2033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2033,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_2041(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 228  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k2060 in fold in k2029 in ##compiler#fold-inner */
static void f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2041(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k2039 in fold in k2029 in ##compiler#fold-inner */
static void C_fcall f_2041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file */
static void f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2005,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[137]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 218  close-input-port */
t4=*((C_word*)lf[138]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file */
static void f_1958(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1958r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1958r(t0,t1,t2,t3);}}

static void f_1958r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[129]))){
/* support.scm: 212  current-input-port */
t4=*((C_word*)lf[130]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1974,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 213  file-exists? */
t5=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k1972 in ##compiler#check-and-open-input-file */
static void f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 213  open-input-file */
t2=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_1986(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_1986(t5,(C_word)C_i_not(t4));}}}

/* k1984 in k1972 in ##compiler#check-and-open-input-file */
static void C_fcall f_1986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 214  quit */
t2=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[132],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 215  quit */
t3=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[133],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes */
static void f_1951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1951,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub135(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words */
static void f_1944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1944,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub131(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? */
static void f_1888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1888,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 193  ->string */
t5=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1940 in ##compiler#valid-c-identifier? */
static void f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 193  string->list */
t2=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1890 in ##compiler#valid-c-identifier? */
static void f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=lf[120],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 197  any */
t7=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1914 in k1890 in ##compiler#valid-c-identifier? */
static void f_1915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1915,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string */
static void f_1794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 178  string->list */
t5=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1808 in ##compiler#c-ify-string */
static void f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1812,a[2]=t3,a[3]=lf[117],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1812(t5,((C_word*)t0)[2],t1);}

/* loop in k1808 in ##compiler#c-ify-string */
static void C_fcall f_1812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1812,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[110]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1834,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_1834(t7,t5);}
else{
t7=(C_word)C_fixnum_greaterp(t4,C_fix(128));
t8=t6;
f_1834(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[116])));}}}

/* k1832 in loop in k1808 in ##compiler#c-ify-string */
static void C_fcall f_1834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_1841(t3,lf[114]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_1841(t4,(C_truep(t3)?lf[115]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 190  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1812(t4,t2,t3);}}

/* k1871 in k1832 in loop in k1808 in ##compiler#c-ify-string */
static void f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1839 in k1832 in loop in k1808 in ##compiler#c-ify-string */
static void C_fcall f_1841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 188  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k1855 in k1839 in k1832 in loop in k1808 in ##compiler#c-ify-string */
static void f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 188  string->list */
t2=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1843 in k1839 in k1832 in loop in k1808 in ##compiler#c-ify-string */
static void f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1849,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 189  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1812(t4,t2,t3);}

/* k1847 in k1843 in k1839 in k1832 in loop in k1808 in ##compiler#c-ify-string */
static void f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 184  append */
t2=*((C_word*)lf[111]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[112],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1804 in ##compiler#c-ify-string */
static void f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* support.scm: 175  list->string */
t3=*((C_word*)lf[109]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list */
static void f_1750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1750,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1756,a[2]=t6,a[3]=t4,a[4]=lf[104],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1756(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list */
static void C_fcall f_1756(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1756,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1780,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 170  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k1778 in loop in ##compiler#build-lambda-list */
static void f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#flonum? */
static void f_1734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1734,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_i_exactp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#symbolify */
static void f_1709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1709,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
t3=*((C_word*)lf[98]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
t4=C_retrieve(lf[94]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[99],t2);}}}

/* k1730 in ##compiler#symbolify */
static void f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
t2=*((C_word*)lf[98]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify */
static void f_1688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1688,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
t3=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 157  sprintf */
t3=C_retrieve(lf[94]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[95],t2);}}}

/* ##compiler#posq */
static void f_1652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1652,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=t2,a[3]=lf[90],tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1658(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq */
static C_word C_fcall f_1658(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature */
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1584,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=t2,a[3]=t4,a[4]=lf[86],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1608,a[2]=t7,a[3]=t5,a[4]=lf[87],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1608(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature */
static void C_fcall f_1608(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_1587(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_1587(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature */
static void C_fcall f_1587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1587,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  ##compiler#real-name */
t3=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1593 in err in ##compiler#check-signature */
static void f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1599,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
t4=*((C_word*)lf[80]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[85]),t3);}

/* k1597 in k1593 in err in ##compiler#check-signature */
static void f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[84],((C_word*)t0)[2],t1);}

/* map-llist */
static void f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1541,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1547,a[2]=t5,a[3]=t2,a[4]=lf[81],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1547(t7,t1,t3);}

/* loop in map-llist */
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1568 in loop in map-llist */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1574,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1547(t4,t2,t3);}

/* k1572 in k1568 in loop in map-llist */
static void f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#syntax-error-hook */
static void f_1517(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1517r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1517r(t0,t1,t2,t3);}}

static void f_1517r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 123  current-error-port */
t5=C_retrieve(lf[69]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1519 in ##sys#syntax-error-hook */
static void f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 124  fprintf */
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[78],((C_word*)t0)[2]);}

/* k1522 in k1519 in ##sys#syntax-error-hook */
static void f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[3],a[3]=lf[77],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1531 in k1522 in k1519 in ##sys#syntax-error-hook */
static void f_1532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1532,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 125  write */
t4=*((C_word*)lf[76]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k1534 in a1531 in k1522 in k1519 in ##sys#syntax-error-hook */
static void f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 125  newline */
t2=*((C_word*)lf[56]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1525 in k1522 in k1519 in ##sys#syntax-error-hook */
static void f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 126  exit */
t2=C_retrieve(lf[72]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit */
static void f_1498(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1498r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1498r(t0,t1,t2,t3);}}

static void f_1498r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1502,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 116  current-error-port */
t5=C_retrieve(lf[69]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1500 in quit */
static void f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  string-append */
t4=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[73],((C_word*)t0)[2]);}

/* k1513 in k1500 in quit */
static void f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[67]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1503 in k1500 in quit */
static void f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 118  newline */
t3=*((C_word*)lf[56]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1506 in k1503 in k1500 in quit */
static void f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 119  exit */
t2=C_retrieve(lf[72]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* warning */
static void f_1479(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1479r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1479r(t0,t1,t2,t3);}}

static void f_1479r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep(*((C_word*)lf[47]+1))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1486,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  current-error-port */
t5=C_retrieve(lf[69]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1484 in warning */
static void f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 112  string-append */
t4=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[68],((C_word*)t0)[2]);}

/* k1494 in k1484 in warning */
static void f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[67]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1487 in k1484 in warning */
static void f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  newline */
t2=*((C_word*)lf[56]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging */
static void f_1439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1439r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1439r(t0,t1,t2,t3,t4);}}

static void f_1439r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,*((C_word*)lf[46]+1)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 100  printf */
t6=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[64],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k1447 in ##compiler#debugging */
static void f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 103  display */
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[63]);}
else{
t3=t2;
f_1452(2,t3,C_SCHEME_UNDEFINED);}}

/* k1462 in k1447 in ##compiler#debugging */
static void f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=lf[60],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1468 in k1462 in k1447 in ##compiler#debugging */
static void f_1469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 104  force */
t4=C_retrieve(lf[59]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1475 in a1468 in k1462 in k1447 in ##compiler#debugging */
static void f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 104  printf */
t2=C_retrieve(lf[57]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k1450 in k1447 in ##compiler#debugging */
static void f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 105  newline */
t3=*((C_word*)lf[56]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1453 in k1450 in k1447 in ##compiler#debugging */
static void f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 106  flush-output */
t3=*((C_word*)lf[55]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1456 in k1453 in k1450 in k1447 in ##compiler#debugging */
static void f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb */
static void f_1412(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1412r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1412r(t0,t1,t2);}}

static void f_1412r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 94   string-append */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[51],t4);}
else{
/* support.scm: 95   error */
t3=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[52]);}}

/* k1424 in ##compiler#bomb */
static void f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[49]+1),t1,t2);}

/* f_1407 */
static void f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
/* end of file */
