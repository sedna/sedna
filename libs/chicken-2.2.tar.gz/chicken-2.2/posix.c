/* Generated from posix.scm by the Chicken compiler
   2005-09-10 23:09
   Version 2, Build 111 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: posix.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file posix.c -explicit-use
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#ifdef ECOS
#include <cyg/posix/signal.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANONYMOUS
# define MAP_ANONYMOUS    0
#endif

#ifndef C_MACOSX
extern char **environ;
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
#ifndef ECOS
static C_TLS struct passwd *C_user;
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)   	(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name),	C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#ifndef ECOS
#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#endif
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#ifdef C_MACOSX
# define C_getenventry(i)   NULL
#else
# define C_getenventry(i)   environ[ i ]
#endif

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);				       
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_exec_args() {
  char **a = C_exec_args;
  while((*a) != NULL) C_free(*(a++));
}

static void C_fcall C_free_exec_env() {
  char **a = C_exec_env;
  while((*a) != NULL) C_free(*(a++));
}

#define C_set_exec_arg(i, a, len)      C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)      C_set_arg_string(C_exec_env, i, a, len)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigprocmask(d)    C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)    FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd) FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd) FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_timeval.tv_sec = C_unfix(t), C_timeval.tv_usec = 0, C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if !defined(C_GNU_ENV)
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
#else
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), asctime(&C_tm) )
#endif

#ifndef ECOS
static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))
#endif

C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[532];


/* from k4998 in set-root-directory! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub975(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub975(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k4438 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub826(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub826(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_return:
#undef return

return C_r;}

/* from k4360 */
static C_word C_fcall stub794(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub794(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub791(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub791(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub789(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub789(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub725(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub725(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k4088 */
static C_word C_fcall stub718(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub718(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub713(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub713(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k4069 */
static C_word C_fcall stub706(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub706(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4045 */
static C_word C_fcall stub694(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub694(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub689(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub689(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub652(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub652(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);
              else return(C_hostbuf);
C_return:
#undef return

return C_r;}

/* from k3865 */
static C_word C_fcall stub644(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub644(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k3776 */
static C_word C_fcall stub627(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub627(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k3751 */
static C_word C_fcall stub621(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub621(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from asctime */
static C_word C_fcall stub610(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub610(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k3700 */
static C_word C_fcall stub601(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub601(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k3619 */
static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k3557 */
static C_word C_fcall stub545(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub545(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k3457 */
static C_word C_fcall stub523(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub523(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2949 in k2945 in file-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub404(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub404(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from current-effective-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub359(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub359(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from current-effective-user-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub357(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub357(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from current-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub355(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub355(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from current-user-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall stub353(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub353(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k2625 */
static C_word C_fcall stub324(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub324(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k2494 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub297(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub297(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_return:
#undef return

return C_r;}

/* from k2487 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub293(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub293(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_return:
#undef return

return C_r;}

/* from k2426 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub281(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub281(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_return:
#undef return

return C_r;}

/* from k1424 */
static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k1414 */
static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k1404 */
static C_word C_fcall stub63(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub63(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k1160 */
static C_word C_fcall stub9(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub9(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k1149 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_return:
#undef return

return C_r;}

C_externexport void C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1132(C_word c,C_word t0,C_word t1) C_noret;
static void f_1135(C_word c,C_word t0,C_word t1) C_noret;
static void f_1138(C_word c,C_word t0,C_word t1) C_noret;
static void f_1141(C_word c,C_word t0,C_word t1) C_noret;
static void f_1144(C_word c,C_word t0,C_word t1) C_noret;
static void f_2279(C_word c,C_word t0,C_word t1) C_noret;
static void f_5031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2337(C_word c,C_word t0,C_word t1) C_noret;
static void f_2915(C_word c,C_word t0,C_word t1) C_noret;
static void f_5008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5000(C_word c,C_word t0,C_word t1) C_noret;
static void f_4775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4926(C_word t0,C_word t1) C_noret;
static void f_4932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4921(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4916(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4903(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4911(C_word c,C_word t0,C_word t1,...) C_noret;
static void C_fcall f_4784(C_word t0,C_word t1) C_noret;
static void f_4891(C_word c,C_word t0,C_word t1) C_noret;
static void f_4794(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4815(C_word c,C_word t0,C_word t1) C_noret;
static void f_4877(C_word c,C_word t0,C_word t1) C_noret;
static void f_4884(C_word c,C_word t0,C_word t1) C_noret;
static void f_4871(C_word c,C_word t0,C_word t1) C_noret;
static void f_4830(C_word c,C_word t0,C_word t1) C_noret;
static void f_4861(C_word c,C_word t0,C_word t1) C_noret;
static void f_4847(C_word c,C_word t0,C_word t1) C_noret;
static void f_4859(C_word c,C_word t0,C_word t1) C_noret;
static void f_4855(C_word c,C_word t0,C_word t1) C_noret;
static void f_4842(C_word c,C_word t0,C_word t1) C_noret;
static void f_4840(C_word c,C_word t0,C_word t1) C_noret;
static void f_4895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4461(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4461r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4727(C_word t0,C_word t1) C_noret;
static void C_fcall f_4722(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4671(C_word c,C_word t0,C_word t1) C_noret;
static void f_4675(C_word c,C_word t0,C_word t1) C_noret;
static void f_4678(C_word c,C_word t0,C_word t1) C_noret;
static void f_4718(C_word c,C_word t0,C_word t1) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1) C_noret;
static void f_4709(C_word c,C_word t0,C_word t1) C_noret;
static void f_4684(C_word c,C_word t0,C_word t1) C_noret;
static void f_4693(C_word c,C_word t0,C_word t1) C_noret;
static void f_4494(C_word c,C_word t0,C_word t1) C_noret;
static void f_4497(C_word c,C_word t0,C_word t1) C_noret;
static void f_4500(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1) C_noret;
static void f_4658(C_word c,C_word t0,C_word t1) C_noret;
static void f_4662(C_word c,C_word t0,C_word t1) C_noret;
static void f_4642(C_word c,C_word t0,C_word t1) C_noret;
static void f_4626(C_word c,C_word t0,C_word t1) C_noret;
static void f_4630(C_word c,C_word t0,C_word t1) C_noret;
static void f_4557(C_word c,C_word t0,C_word t1) C_noret;
static void f_4613(C_word c,C_word t0,C_word t1) C_noret;
static void f_4617(C_word c,C_word t0,C_word t1) C_noret;
static void f_4563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4572(C_word t0,C_word t1) C_noret;
static void f_4604(C_word c,C_word t0,C_word t1) C_noret;
static void f_4588(C_word c,C_word t0,C_word t1) C_noret;
static void f_4561(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4515(C_word t0,C_word t1) C_noret;
static void C_fcall f_4529(C_word t0,C_word t1) C_noret;
static void f_4545(C_word c,C_word t0,C_word t1) C_noret;
static void f_4548(C_word c,C_word t0,C_word t1) C_noret;
static void f_4525(C_word c,C_word t0,C_word t1) C_noret;
static void f_4484(C_word c,C_word t0,C_word t1) C_noret;
static void f_4472(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4447(C_word c,C_word t0,C_word t1) C_noret;
static void f_4391(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4391r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4398(C_word c,C_word t0,C_word t1) C_noret;
static void f_4413(C_word c,C_word t0,C_word t1) C_noret;
static void f_4364(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4364r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4354(C_word c,C_word t0,C_word t1) C_noret;
static void f_4351(C_word c,C_word t0,C_word t1) C_noret;
static void f_4275(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4275r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4096(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4096r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4227(C_word t0,C_word t1) C_noret;
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4108(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4116(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_4159(C_word t0,C_word t1,C_word t2);
static void C_fcall f_4129(C_word t0,C_word t1) C_noret;
static void f_4154(C_word c,C_word t0,C_word t1) C_noret;
static void f_4132(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_4077(C_word t0,C_word t1,C_word t2);
static C_word C_fcall f_4058(C_word t0,C_word t1,C_word t2);
static void f_4016(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4016r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4038(C_word c,C_word t0,C_word t1) C_noret;
static void f_4042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3910(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3910r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4008(C_word c,C_word t0,C_word t1) C_noret;
static void f_3941(C_word c,C_word t0,C_word t1) C_noret;
static void f_3948(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3967(C_word c,C_word t0,C_word t1) C_noret;
static void f_3977(C_word c,C_word t0,C_word t1) C_noret;
static void f_3981(C_word c,C_word t0,C_word t1) C_noret;
static void f_3931(C_word c,C_word t0,C_word t1) C_noret;
static void f_3898(C_word c,C_word t0,C_word t1) C_noret;
static void f_3902(C_word c,C_word t0,C_word t1) C_noret;
static void f_3905(C_word c,C_word t0,C_word t1) C_noret;
static void f_3868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3872(C_word c,C_word t0,C_word t1) C_noret;
static void f_3875(C_word c,C_word t0,C_word t1) C_noret;
static void f_3839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3843(C_word c,C_word t0,C_word t1) C_noret;
static void f_3846(C_word c,C_word t0,C_word t1) C_noret;
static void f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3784(C_word c,C_word t0,C_word t1) C_noret;
static void f_3790(C_word c,C_word t0,C_word t1) C_noret;
static void f_3773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3754(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3754r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_3758(C_word c,C_word t0,C_word t1) C_noret;
static void f_3720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3727(C_word c,C_word t0,C_word t1) C_noret;
static void f_3730(C_word c,C_word t0,C_word t1) C_noret;
static void f_3733(C_word c,C_word t0,C_word t1) C_noret;
static void f_3703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3707(C_word c,C_word t0,C_word t1) C_noret;
static void f_3710(C_word c,C_word t0,C_word t1) C_noret;
static void f_3684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3625(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3625r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
static void f_3563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
static void f_3567(C_word c,C_word t0,C_word t1) C_noret;
static void f_3573(C_word c,C_word t0,C_word t1) C_noret;
static void f_3592(C_word c,C_word t0,C_word t1) C_noret;
static void f_3579(C_word c,C_word t0,C_word t1) C_noret;
static void f_3460(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3466(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3470(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3504(C_word c,C_word t0,C_word t1) C_noret;
static void f_3508(C_word c,C_word t0,C_word t1) C_noret;
static void f_3496(C_word c,C_word t0,C_word t1) C_noret;
static void f_3440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3448(C_word c,C_word t0,C_word t1) C_noret;
static void f_3423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3434(C_word c,C_word t0,C_word t1) C_noret;
static void f_3438(C_word c,C_word t0,C_word t1) C_noret;
static void f_3397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3421(C_word c,C_word t0,C_word t1) C_noret;
static void f_3404(C_word c,C_word t0,C_word t1) C_noret;
static void f_3354(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3354r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_3361(C_word t0,C_word t1) C_noret;
static void f_3382(C_word c,C_word t0,C_word t1) C_noret;
static void f_3378(C_word c,C_word t0,C_word t1) C_noret;
static void f_3326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3308(C_word c,C_word t0,C_word t1) C_noret;
static void f_3289(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3289r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3293(C_word c,C_word t0,C_word t1) C_noret;
static void f_3274(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3274r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3278(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3256(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3204(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3210(C_word t0,C_word t1) C_noret;
static void f_3143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3171(C_word c,C_word t0,C_word t1) C_noret;
static void f_3167(C_word c,C_word t0,C_word t1) C_noret;
static void f_3160(C_word c,C_word t0,C_word t1) C_noret;
static void f_3116(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3116r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_3123(C_word t0,C_word t1) C_noret;
static void f_3126(C_word c,C_word t0,C_word t1) C_noret;
static void f_3071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3075(C_word c,C_word t0,C_word t1) C_noret;
static void f_3110(C_word c,C_word t0,C_word t1) C_noret;
static void f_3093(C_word c,C_word t0,C_word t1) C_noret;
static void f_3057(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3057r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3069(C_word c,C_word t0,C_word t1) C_noret;
static void f_3043(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3043r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3055(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3041(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2999(C_word c,C_word t0,C_word t1) C_noret;
static void f_2966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2947(C_word c,C_word t0,C_word t1) C_noret;
static void f_2951(C_word c,C_word t0,C_word t1) C_noret;
static void f_2916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2940(C_word c,C_word t0,C_word t1) C_noret;
static void f_2924(C_word c,C_word t0,C_word t1) C_noret;
static void f_2927(C_word c,C_word t0,C_word t1) C_noret;
static void f_2878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2911(C_word c,C_word t0,C_word t1) C_noret;
static void f_2899(C_word c,C_word t0,C_word t1) C_noret;
static void f_2907(C_word c,C_word t0,C_word t1) C_noret;
static void f_2903(C_word c,C_word t0,C_word t1) C_noret;
static void f_2857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2873(C_word c,C_word t0,C_word t1) C_noret;
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2852(C_word c,C_word t0,C_word t1) C_noret;
static void f_2846(C_word c,C_word t0,C_word t1) C_noret;
static void f_2824(C_word c,C_word t0,C_word t1) C_noret;
static void f_2834(C_word c,C_word t0,C_word t1) C_noret;
static void f_2828(C_word c,C_word t0,C_word t1) C_noret;
static void f_2818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2782(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2804(C_word c,C_word t0,C_word t1) C_noret;
static void f_2800(C_word c,C_word t0,C_word t1) C_noret;
static void f_2792(C_word c,C_word t0,C_word t1) C_noret;
static void f_2767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2777(C_word c,C_word t0,C_word t1) C_noret;
static void f_2752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2762(C_word c,C_word t0,C_word t1) C_noret;
static void f_2749(C_word c,C_word t0,C_word t1) C_noret;
static void f_2746(C_word c,C_word t0,C_word t1) C_noret;
static void f_2743(C_word c,C_word t0,C_word t1) C_noret;
static void f_2740(C_word c,C_word t0,C_word t1) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2738(C_word c,C_word t0,C_word t1) C_noret;
static void f_2734(C_word c,C_word t0,C_word t1) C_noret;
static void f_2683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2708(C_word c,C_word t0,C_word t1) C_noret;
static void f_2704(C_word c,C_word t0,C_word t1) C_noret;
static void f_2635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2623(C_word c,C_word t0,C_word t1) C_noret;
static void f_2651(C_word c,C_word t0,C_word t1) C_noret;
static void f_2561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2565(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2586(C_word c,C_word t0,C_word t1) C_noret;
static void f_2498(C_word c,C_word t0,C_word t1) C_noret;
static void f_2556(C_word c,C_word t0,C_word t1) C_noret;
static void f_2502(C_word c,C_word t0,C_word t1) C_noret;
static void f_2505(C_word c,C_word t0,C_word t1) C_noret;
static void f_2537(C_word c,C_word t0,C_word t1) C_noret;
static void f_2508(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2527(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2491(C_word t0);
static void f_2430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2482(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2434(C_word t0,C_word t1) C_noret;
static void f_2444(C_word c,C_word t0,C_word t1) C_noret;
static void f_2448(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2458(C_word c,C_word t0,C_word t1) C_noret;
static void f_2468(C_word c,C_word t0,C_word t1) C_noret;
static void f_2452(C_word c,C_word t0,C_word t1) C_noret;
static void f_2377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2417(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2381(C_word t0,C_word t1) C_noret;
static void f_2391(C_word c,C_word t0,C_word t1) C_noret;
static void f_2395(C_word c,C_word t0,C_word t1) C_noret;
static void f_2399(C_word c,C_word t0,C_word t1) C_noret;
static void f_2403(C_word c,C_word t0,C_word t1) C_noret;
static void f_2407(C_word c,C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1) C_noret;
static void f_2372(C_word c,C_word t0,C_word t1) C_noret;
static void f_2343(C_word c,C_word t0,C_word t1) C_noret;
static void f_2350(C_word c,C_word t0,C_word t1) C_noret;
static void f_2354(C_word c,C_word t0,C_word t1) C_noret;
static void f_2358(C_word c,C_word t0,C_word t1) C_noret;
static void f_2362(C_word c,C_word t0,C_word t1) C_noret;
static void f_2366(C_word c,C_word t0,C_word t1) C_noret;
static void f_2312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2319(C_word c,C_word t0,C_word t1) C_noret;
static void f_2294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2304(C_word c,C_word t0,C_word t1) C_noret;
static void f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2238(C_word c,C_word t0,C_word t1) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1) C_noret;
static void f_2218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2218r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2222(C_word c,C_word t0,C_word t1) C_noret;
static void f_2228(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2228r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2232(C_word c,C_word t0,C_word t1) C_noret;
static void f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2198r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2202(C_word c,C_word t0,C_word t1) C_noret;
static void f_2208(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2208r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2212(C_word c,C_word t0,C_word t1) C_noret;
static void f_2174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2174r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2178(C_word c,C_word t0,C_word t1) C_noret;
static void f_2189(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2189r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2193(C_word c,C_word t0,C_word t1) C_noret;
static void f_2183(C_word c,C_word t0,C_word t1) C_noret;
static void f_2150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2154(C_word c,C_word t0,C_word t1) C_noret;
static void f_2165(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2165r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void f_2134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2138(C_word c,C_word t0,C_word t1) C_noret;
static void f_2141(C_word c,C_word t0,C_word t1) C_noret;
static void f_2098(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2098r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2129(C_word c,C_word t0,C_word t1) C_noret;
static void f_2119(C_word c,C_word t0,C_word t1) C_noret;
static void f_2112(C_word c,C_word t0,C_word t1) C_noret;
static void f_2062(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2062r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2093(C_word c,C_word t0,C_word t1) C_noret;
static void f_2083(C_word c,C_word t0,C_word t1) C_noret;
static void f_2076(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2047(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2041(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2029(C_word t0);
static void f_1986(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1986r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1990(C_word c,C_word t0,C_word t1) C_noret;
static void f_1999(C_word c,C_word t0,C_word t1) C_noret;
static void f_1963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1) C_noret;
static void f_1970(C_word c,C_word t0,C_word t1) C_noret;
static void f_1909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1916(C_word c,C_word t0,C_word t1) C_noret;
static void f_1919(C_word c,C_word t0,C_word t1) C_noret;
static void f_1922(C_word c,C_word t0,C_word t1) C_noret;
static void f_1961(C_word c,C_word t0,C_word t1) C_noret;
static void f_1926(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1940(C_word t0,C_word t1) C_noret;
static void f_1950(C_word c,C_word t0,C_word t1) C_noret;
static void f_1957(C_word c,C_word t0,C_word t1) C_noret;
static void f_1885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1907(C_word c,C_word t0,C_word t1) C_noret;
static void f_1903(C_word c,C_word t0,C_word t1) C_noret;
static void f_1861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1883(C_word c,C_word t0,C_word t1) C_noret;
static void f_1879(C_word c,C_word t0,C_word t1) C_noret;
static void f_1837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1859(C_word c,C_word t0,C_word t1) C_noret;
static void f_1855(C_word c,C_word t0,C_word t1) C_noret;
static void f_1779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1792(C_word c,C_word t0,C_word t1) C_noret;
static void f_1804(C_word c,C_word t0,C_word t1) C_noret;
static void f_1798(C_word c,C_word t0,C_word t1) C_noret;
static void f_1742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1758(C_word c,C_word t0,C_word t1) C_noret;
static void f_1746(C_word c,C_word t0,C_word t1) C_noret;
static void f_1749(C_word c,C_word t0,C_word t1) C_noret;
static void f_1733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1) C_noret;
static void f_1724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1731(C_word c,C_word t0,C_word t1) C_noret;
static void f_1718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1722(C_word c,C_word t0,C_word t1) C_noret;
static void f_1712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1716(C_word c,C_word t0,C_word t1) C_noret;
static void f_1706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1710(C_word c,C_word t0,C_word t1) C_noret;
static void f_1700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1704(C_word c,C_word t0,C_word t1) C_noret;
static void f_1694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1698(C_word c,C_word t0,C_word t1) C_noret;
static void f_1688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1692(C_word c,C_word t0,C_word t1) C_noret;
static void f_1656(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1656r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1667(C_word c,C_word t0,C_word t1) C_noret;
static void f_1660(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1619(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1651(C_word c,C_word t0,C_word t1) C_noret;
static void f_1644(C_word c,C_word t0,C_word t1) C_noret;
static void f_1623(C_word c,C_word t0,C_word t1) C_noret;
static void f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1427r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1443(C_word c,C_word t0,C_word t1) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1449(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1452(C_word t0,C_word t1) C_noret;
static void f_1534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1532(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
static void f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1507(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1495(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1417(C_word t0,C_word t1);
static C_word C_fcall f_1407(C_word t0,C_word t1);
static C_word C_fcall f_1401(C_word t0);
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1376(C_word c,C_word t0,C_word t1) C_noret;
static void f_1379(C_word c,C_word t0,C_word t1) C_noret;
static void f_1382(C_word c,C_word t0,C_word t1) C_noret;
static void f_1389(C_word c,C_word t0,C_word t1) C_noret;
static void f_1330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1330r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1337(C_word c,C_word t0,C_word t1) C_noret;
static void f_1346(C_word c,C_word t0,C_word t1) C_noret;
static void f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1288r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1298(C_word c,C_word t0,C_word t1) C_noret;
static void f_1301(C_word c,C_word t0,C_word t1) C_noret;
static void f_1304(C_word c,C_word t0,C_word t1) C_noret;
static void f_1273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1235r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1265(C_word c,C_word t0,C_word t1) C_noret;
static void f_1252(C_word c,C_word t0,C_word t1) C_noret;
static void f_1255(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1180(C_word t0) C_noret;
static void f_1186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1195(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1163(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1167(C_word c,C_word t0,C_word t1) C_noret;
static void f_1178(C_word c,C_word t0,C_word t1) C_noret;
static void f_1174(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1146(C_word t0);

static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4926(t0,t1);}

static void C_fcall trf_4921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4921(t0,t1,t2);}

static void C_fcall trf_4916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4916(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4916(t0,t1,t2,t3);}

static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4777(t0,t1,t2,t3,t4);}

static void C_fcall trf_4784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4784(t0,t1);}

static void C_fcall trf_4796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4796(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4796(t0,t1,t2,t3);}

static void C_fcall trf_4727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4727(t0,t1);}

static void C_fcall trf_4722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4722(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4722(t0,t1,t2);}

static void C_fcall trf_4463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4463(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4463(t0,t1,t2,t3);}

static void C_fcall trf_4572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4572(t0,t1);}

static void C_fcall trf_4515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4515(t0,t1);}

static void C_fcall trf_4529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4529(t0,t1);}

static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4441(t0,t1,t2);}

static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4227(t0,t1);}

static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4222(t0,t1,t2);}

static void C_fcall trf_4098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4098(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4098(t0,t1,t2,t3);}

static void C_fcall trf_4116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4116(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4116(t0,t1,t2,t3);}

static void C_fcall trf_4129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4129(t0,t1);}

static void C_fcall trf_3916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3916(t0,t1,t2);}

static void C_fcall trf_3950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3950(t0,t1,t2);}

static void C_fcall trf_3466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3466(t0,t1,t2);}

static void C_fcall trf_3478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3478(t0,t1,t2);}

static void C_fcall trf_3361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3361(t0,t1);}

static void C_fcall trf_3256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3256(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3256(t0,t1,t2,t3);}

static void C_fcall trf_3182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3182(t0,t1,t2,t3);}

static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3210(t0,t1);}

static void C_fcall trf_3123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3123(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3123(t0,t1);}

static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3028(t0,t1,t2,t3,t4);}

static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2991(t0,t1,t2);}

static void C_fcall trf_2782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2782(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2782(t0,t1,t2,t3);}

static void C_fcall trf_2570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2570(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2570(t0,t1,t2,t3);}

static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2513(t0,t1,t2);}

static void C_fcall trf_2434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2434(t0,t1);}

static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2454(t0,t1,t2);}

static void C_fcall trf_2381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2381(t0,t1);}

static void C_fcall trf_2047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2047(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2047(t0,t1,t2,t3,t4);}

static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2041(t0,t1);}

static void C_fcall trf_1940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1940(t0,t1);}

static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1619(t0,t1,t2,t3);}

static void C_fcall trf_1452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1452(t0,t1);}

static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

static void C_fcall trf_1495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1495(t0,t1);}

static void C_fcall trf_1180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1180(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1180(t0);}

static void C_fcall trf_1163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1163(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1163(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2304)){
C_save(t1);
C_rereclaim2(2304*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,532);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_lambda_info(C_heaptop,18,"(make-nonblocking)");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_static_string(C_heaptop,3," - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_static_lambda_info(C_heaptop,39,"(posix-error type13 loc14 msg15 args16)");
lf[12]=C_h_intern(&lf[12],18,"\003syscurrent-thread");
lf[13]=C_static_lambda_info(C_heaptop,7,"(a1194)");
lf[14]=C_h_intern(&lf[14],12,"\003sysschedule");
lf[15]=C_static_lambda_info(C_heaptop,16,"(a1185 return18)");
lf[16]=C_static_lambda_info(C_heaptop,7,"(yield)");
lf[17]=C_h_intern(&lf[17],8,"pipe/buf");
lf[18]=C_h_intern(&lf[18],11,"open/rdonly");
lf[19]=C_h_intern(&lf[19],11,"open/wronly");
lf[20]=C_h_intern(&lf[20],9,"open/rdwr");
lf[21]=C_h_intern(&lf[21],9,"open/read");
lf[22]=C_h_intern(&lf[22],10,"open/write");
lf[23]=C_h_intern(&lf[23],10,"open/creat");
lf[24]=C_h_intern(&lf[24],11,"open/append");
lf[25]=C_h_intern(&lf[25],9,"open/excl");
lf[26]=C_h_intern(&lf[26],11,"open/noctty");
lf[27]=C_h_intern(&lf[27],13,"open/nonblock");
lf[28]=C_h_intern(&lf[28],10,"open/trunc");
lf[29]=C_h_intern(&lf[29],9,"open/sync");
lf[30]=C_h_intern(&lf[30],10,"open/fsync");
lf[31]=C_h_intern(&lf[31],11,"open/binary");
lf[32]=C_h_intern(&lf[32],9,"open/text");
lf[33]=C_h_intern(&lf[33],10,"perm/irusr");
lf[34]=C_h_intern(&lf[34],10,"perm/iwusr");
lf[35]=C_h_intern(&lf[35],10,"perm/ixusr");
lf[36]=C_h_intern(&lf[36],10,"perm/irgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/iwgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/ixgrp");
lf[39]=C_h_intern(&lf[39],10,"perm/iroth");
lf[40]=C_h_intern(&lf[40],10,"perm/iwoth");
lf[41]=C_h_intern(&lf[41],10,"perm/ixoth");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxu");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxg");
lf[44]=C_h_intern(&lf[44],10,"perm/irwxo");
lf[45]=C_h_intern(&lf[45],10,"perm/isvtx");
lf[46]=C_h_intern(&lf[46],10,"perm/isuid");
lf[47]=C_h_intern(&lf[47],10,"perm/isgid");
lf[48]=C_h_intern(&lf[48],9,"file-open");
lf[49]=C_h_intern(&lf[49],11,"\000file-error");
lf[50]=C_static_string(C_heaptop,17,"can not open file");
lf[51]=C_h_intern(&lf[51],17,"\003sysmake-c-string");
lf[52]=C_h_intern(&lf[52],20,"\003sysexpand-home-path");
lf[53]=C_static_lambda_info(C_heaptop,39,"(file-open filename22 flags23 . mode24)");
lf[54]=C_h_intern(&lf[54],10,"file-close");
lf[55]=C_static_string(C_heaptop,18,"can not close file");
lf[56]=C_static_lambda_info(C_heaptop,17,"(file-close fd31)");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_static_string(C_heaptop,22,"can not read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[62]=C_static_lambda_info(C_heaptop,34,"(file-read fd34 size35 . buffer36)");
lf[63]=C_h_intern(&lf[63],10,"file-write");
lf[64]=C_static_string(C_heaptop,21,"can not write to file");
lf[65]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[66]=C_static_lambda_info(C_heaptop,35,"(file-write fd43 buffer44 . size45)");
lf[67]=C_h_intern(&lf[67],13,"string-length");
lf[68]=C_h_intern(&lf[68],12,"file-mkstemp");
lf[69]=C_h_intern(&lf[69],13,"\003syssubstring");
lf[70]=C_static_string(C_heaptop,29,"can not create temporary file");
lf[71]=C_static_lambda_info(C_heaptop,25,"(file-mkstemp template53)");
lf[72]=C_static_lambda_info(C_heaptop,9,"(fd_zero)");
lf[73]=C_static_lambda_info(C_heaptop,14,"(fd_set a6671)");
lf[74]=C_static_lambda_info(C_heaptop,15,"(fd_test a7277)");
lf[75]=C_h_intern(&lf[75],11,"file-select");
lf[76]=C_static_string(C_heaptop,6,"failed");
lf[77]=C_static_lambda_info(C_heaptop,13,"(a1508 fd103)");
lf[78]=C_h_intern(&lf[78],12,"\003sysfor-each");
lf[79]=C_static_lambda_info(C_heaptop,13,"(a1533 fd100)");
lf[80]=C_static_lambda_info(C_heaptop,12,"(a1573 fd93)");
lf[81]=C_static_lambda_info(C_heaptop,12,"(a1599 fd86)");
lf[82]=C_static_lambda_info(C_heaptop,39,"(file-select fdsr78 fdsw79 . timeout80)");
lf[83]=C_h_intern(&lf[83],8,"seek/set");
lf[84]=C_h_intern(&lf[84],8,"seek/end");
lf[85]=C_h_intern(&lf[85],8,"seek/cur");
lf[87]=C_static_string(C_heaptop,19,"can not access file");
lf[88]=C_static_string(C_heaptop,42,"bad argument type - not a fixnum or string");
lf[89]=C_static_lambda_info(C_heaptop,35,"(##sys#stat file109 link110 loc111)");
lf[90]=C_h_intern(&lf[90],9,"file-stat");
lf[91]=C_h_intern(&lf[91],9,"\003syserror");
lf[92]=C_static_lambda_info(C_heaptop,26,"(file-stat f114 . link115)");
lf[93]=C_h_intern(&lf[93],9,"file-size");
lf[94]=C_static_lambda_info(C_heaptop,16,"(file-size f120)");
lf[95]=C_h_intern(&lf[95],22,"file-modification-time");
lf[96]=C_static_lambda_info(C_heaptop,29,"(file-modification-time f122)");
lf[97]=C_h_intern(&lf[97],16,"file-access-time");
lf[98]=C_static_lambda_info(C_heaptop,23,"(file-access-time f124)");
lf[99]=C_h_intern(&lf[99],16,"file-change-time");
lf[100]=C_static_lambda_info(C_heaptop,23,"(file-change-time f126)");
lf[101]=C_h_intern(&lf[101],10,"file-owner");
lf[102]=C_static_lambda_info(C_heaptop,17,"(file-owner f128)");
lf[103]=C_h_intern(&lf[103],16,"file-permissions");
lf[104]=C_static_lambda_info(C_heaptop,23,"(file-permissions f130)");
lf[105]=C_h_intern(&lf[105],13,"regular-file\077");
lf[106]=C_static_lambda_info(C_heaptop,24,"(regular-file\077 fname132)");
lf[107]=C_h_intern(&lf[107],14,"symbolic-link\077");
lf[108]=C_static_lambda_info(C_heaptop,25,"(symbolic-link\077 fname136)");
lf[109]=C_h_intern(&lf[109],13,"file-position");
lf[110]=C_static_string(C_heaptop,38,"can not retrieve file position of port");
lf[111]=C_h_intern(&lf[111],6,"stream");
lf[112]=C_static_string(C_heaptop,12,"invalid file");
lf[113]=C_h_intern(&lf[113],5,"port\077");
lf[114]=C_static_lambda_info(C_heaptop,23,"(file-position port140)");
lf[115]=C_h_intern(&lf[115],18,"set-file-position!");
lf[116]=C_static_string(C_heaptop,25,"can not set file position");
lf[117]=C_static_string(C_heaptop,12,"invalid file");
lf[118]=C_h_intern(&lf[118],13,"\000bounds-error");
lf[119]=C_static_string(C_heaptop,30,"invalid negative port position");
lf[120]=C_static_lambda_info(C_heaptop,47,"(set-file-position! port143 pos144 . whence145)");
lf[121]=C_h_intern(&lf[121],16,"create-directory");
lf[122]=C_static_string(C_heaptop,24,"can not create directory");
lf[123]=C_static_lambda_info(C_heaptop,26,"(create-directory name150)");
lf[124]=C_h_intern(&lf[124],16,"change-directory");
lf[125]=C_static_string(C_heaptop,32,"can not change current directory");
lf[126]=C_static_lambda_info(C_heaptop,26,"(change-directory name152)");
lf[127]=C_h_intern(&lf[127],16,"delete-directory");
lf[128]=C_static_string(C_heaptop,24,"can not delete directory");
lf[129]=C_static_lambda_info(C_heaptop,26,"(delete-directory name154)");
lf[130]=C_h_intern(&lf[130],6,"string");
lf[131]=C_h_intern(&lf[131],9,"substring");
lf[132]=C_h_intern(&lf[132],9,"directory");
lf[133]=C_static_string(C_heaptop,22,"can not open directory");
lf[134]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[135]=C_h_intern(&lf[135],16,"\003sysmake-pointer");
lf[136]=C_static_lambda_info(C_heaptop,19,"(directory spec160)");
lf[137]=C_h_intern(&lf[137],10,"directory\077");
lf[138]=C_h_intern(&lf[138],13,"\003sysfile-info");
lf[139]=C_static_lambda_info(C_heaptop,21,"(directory\077 fname172)");
lf[140]=C_h_intern(&lf[140],17,"current-directory");
lf[141]=C_static_string(C_heaptop,34,"can not retrieve current directory");
lf[142]=C_static_lambda_info(C_heaptop,29,"(current-directory . g177178)");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_static_lambda_info(C_heaptop,6,"(mode)");
lf[145]=C_static_string(C_heaptop,35,"illegal input/output mode specifier");
lf[146]=C_static_lambda_info(C_heaptop,14,"(badmode m188)");
lf[147]=C_static_string(C_heaptop,17,"can not open pipe");
lf[148]=C_h_intern(&lf[148],13,"\003sysmake-port");
lf[149]=C_h_intern(&lf[149],21,"\003sysstream-port-class");
lf[150]=C_static_string(C_heaptop,6,"(pipe)");
lf[151]=C_static_lambda_info(C_heaptop,33,"(check loc189 cmd190 inp191 r192)");
lf[152]=C_h_intern(&lf[152],15,"open-input-pipe");
lf[153]=C_h_intern(&lf[153],7,"\000binary");
lf[154]=C_static_lambda_info(C_heaptop,31,"(open-input-pipe cmd195 . m196)");
lf[155]=C_h_intern(&lf[155],16,"open-output-pipe");
lf[156]=C_static_lambda_info(C_heaptop,32,"(open-output-pipe cmd201 . m202)");
lf[157]=C_h_intern(&lf[157],16,"close-input-pipe");
lf[158]=C_h_intern(&lf[158],23,"close-input/output-pipe");
lf[159]=C_static_string(C_heaptop,24,"error while closing pipe");
lf[160]=C_h_intern(&lf[160],14,"\003syscheck-port");
lf[161]=C_static_lambda_info(C_heaptop,26,"(close-input-pipe port207)");
lf[162]=C_h_intern(&lf[162],17,"close-output-pipe");
lf[163]=C_h_intern(&lf[163],20,"call-with-input-pipe");
lf[164]=C_static_lambda_info(C_heaptop,7,"(a2158)");
lf[165]=C_static_lambda_info(C_heaptop,20,"(a2164 . results225)");
lf[166]=C_static_lambda_info(C_heaptop,47,"(call-with-input-pipe cmd221 proc222 . mode223)");
lf[167]=C_h_intern(&lf[167],21,"call-with-output-pipe");
lf[168]=C_static_lambda_info(C_heaptop,7,"(a2182)");
lf[169]=C_static_lambda_info(C_heaptop,20,"(a2188 . results231)");
lf[170]=C_static_lambda_info(C_heaptop,48,"(call-with-output-pipe cmd227 proc228 . mode229)");
lf[171]=C_h_intern(&lf[171],20,"with-input-from-pipe");
lf[172]=C_h_intern(&lf[172],18,"\003sysstandard-input");
lf[173]=C_static_lambda_info(C_heaptop,20,"(a2207 . results238)");
lf[174]=C_static_lambda_info(C_heaptop,48,"(with-input-from-pipe cmd233 thunk234 . mode235)");
lf[175]=C_h_intern(&lf[175],19,"with-output-to-pipe");
lf[176]=C_h_intern(&lf[176],19,"\003sysstandard-output");
lf[177]=C_static_lambda_info(C_heaptop,20,"(a2227 . results247)");
lf[178]=C_static_lambda_info(C_heaptop,47,"(with-output-to-pipe cmd242 thunk243 . mode244)");
lf[179]=C_h_intern(&lf[179],11,"create-pipe");
lf[180]=C_static_string(C_heaptop,19,"can not create pipe");
lf[181]=C_static_lambda_info(C_heaptop,13,"(create-pipe)");
lf[182]=C_h_intern(&lf[182],11,"signal/term");
lf[183]=C_h_intern(&lf[183],11,"signal/kill");
lf[184]=C_h_intern(&lf[184],10,"signal/int");
lf[185]=C_h_intern(&lf[185],10,"signal/hup");
lf[186]=C_h_intern(&lf[186],10,"signal/fpe");
lf[187]=C_h_intern(&lf[187],10,"signal/ill");
lf[188]=C_h_intern(&lf[188],11,"signal/segv");
lf[189]=C_h_intern(&lf[189],11,"signal/abrt");
lf[190]=C_h_intern(&lf[190],11,"signal/trap");
lf[191]=C_h_intern(&lf[191],11,"signal/quit");
lf[192]=C_h_intern(&lf[192],11,"signal/alrm");
lf[193]=C_h_intern(&lf[193],13,"signal/vtalrm");
lf[194]=C_h_intern(&lf[194],11,"signal/prof");
lf[195]=C_h_intern(&lf[195],9,"signal/io");
lf[196]=C_h_intern(&lf[196],10,"signal/urg");
lf[197]=C_h_intern(&lf[197],11,"signal/chld");
lf[198]=C_h_intern(&lf[198],11,"signal/cont");
lf[199]=C_h_intern(&lf[199],11,"signal/stop");
lf[200]=C_h_intern(&lf[200],11,"signal/tstp");
lf[201]=C_h_intern(&lf[201],11,"signal/pipe");
lf[202]=C_h_intern(&lf[202],11,"signal/xcpu");
lf[203]=C_h_intern(&lf[203],11,"signal/xfsz");
lf[204]=C_h_intern(&lf[204],11,"signal/usr1");
lf[205]=C_h_intern(&lf[205],11,"signal/usr2");
lf[206]=C_h_intern(&lf[206],12,"signal/winch");
lf[207]=C_h_intern(&lf[207],18,"\003sysinterrupt-hook");
lf[208]=C_h_intern(&lf[208],19,"set-signal-handler!");
lf[209]=C_static_lambda_info(C_heaptop,36,"(set-signal-handler! sig259 proc260)");
lf[210]=C_h_intern(&lf[210],18,"\003syscontext-switch");
lf[211]=C_static_lambda_info(C_heaptop,41,"(##sys#interrupt-hook reason263 state264)");
lf[212]=C_h_intern(&lf[212],16,"set-signal-mask!");
lf[213]=C_h_intern(&lf[213],14,"\000process-error");
lf[214]=C_static_string(C_heaptop,23,"can not set signal mask");
lf[215]=C_static_lambda_info(C_heaptop,12,"(a2329 s269)");
lf[216]=C_static_lambda_info(C_heaptop,26,"(set-signal-mask! sigs268)");
lf[217]=C_h_intern(&lf[217],18,"system-information");
lf[218]=C_h_intern(&lf[218],25,"\003syspeek-nonnull-c-string");
lf[219]=C_static_string(C_heaptop,35,"can not retrieve system information");
lf[220]=C_static_lambda_info(C_heaptop,20,"(system-information)");
lf[221]=C_h_intern(&lf[221],16,"user-information");
lf[222]=C_static_lambda_info(C_heaptop,26,"(user-information user277)");
lf[223]=C_h_intern(&lf[223],17,"group-information");
lf[224]=C_static_lambda_info(C_heaptop,10,"(rec i289)");
lf[225]=C_static_lambda_info(C_heaptop,28,"(group-information group285)");
lf[227]=C_static_lambda_info(C_heaptop,16,"(_ensure-groups)");
lf[228]=C_h_intern(&lf[228],10,"get-groups");
lf[229]=C_static_lambda_info(C_heaptop,11,"(loop i305)");
lf[230]=C_static_string(C_heaptop,40,"can not retrieve supplementary group ids");
lf[231]=C_static_string(C_heaptop,13,"out of memory");
lf[232]=C_static_string(C_heaptop,40,"can not retrieve supplementary group ids");
lf[233]=C_static_lambda_info(C_heaptop,12,"(get-groups)");
lf[234]=C_h_intern(&lf[234],11,"set-groups!");
lf[235]=C_static_string(C_heaptop,35,"can not set supplementary group ids");
lf[236]=C_static_lambda_info(C_heaptop,19,"(do311 lst313 i314)");
lf[237]=C_static_string(C_heaptop,13,"out of memory");
lf[238]=C_static_lambda_info(C_heaptop,21,"(set-groups! lst0310)");
lf[239]=C_h_intern(&lf[239],17,"initialize-groups");
lf[240]=C_static_string(C_heaptop,42,"can not initialize supplementary group ids");
lf[241]=C_static_lambda_info(C_heaptop,33,"(initialize-groups user330 id331)");
lf[242]=C_h_intern(&lf[242],10,"errno/perm");
lf[243]=C_h_intern(&lf[243],11,"errno/noent");
lf[244]=C_h_intern(&lf[244],10,"errno/srch");
lf[245]=C_h_intern(&lf[245],10,"errno/intr");
lf[246]=C_h_intern(&lf[246],8,"errno/io");
lf[247]=C_h_intern(&lf[247],12,"errno/noexec");
lf[248]=C_h_intern(&lf[248],10,"errno/badf");
lf[249]=C_h_intern(&lf[249],11,"errno/child");
lf[250]=C_h_intern(&lf[250],11,"errno/nomem");
lf[251]=C_h_intern(&lf[251],11,"errno/acces");
lf[252]=C_h_intern(&lf[252],11,"errno/fault");
lf[253]=C_h_intern(&lf[253],10,"errno/busy");
lf[254]=C_h_intern(&lf[254],12,"errno/notdir");
lf[255]=C_h_intern(&lf[255],11,"errno/isdir");
lf[256]=C_h_intern(&lf[256],11,"errno/inval");
lf[257]=C_h_intern(&lf[257],11,"errno/mfile");
lf[258]=C_h_intern(&lf[258],11,"errno/nospc");
lf[259]=C_h_intern(&lf[259],11,"errno/spipe");
lf[260]=C_h_intern(&lf[260],10,"errno/pipe");
lf[261]=C_h_intern(&lf[261],11,"errno/again");
lf[262]=C_h_intern(&lf[262],10,"errno/rofs");
lf[263]=C_h_intern(&lf[263],11,"errno/exist");
lf[264]=C_h_intern(&lf[264],16,"errno/wouldblock");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_static_string(C_heaptop,24,"can not change file mode");
lf[267]=C_static_lambda_info(C_heaptop,32,"(change-file-mode fname343 m344)");
lf[268]=C_h_intern(&lf[268],17,"change-file-owner");
lf[269]=C_static_string(C_heaptop,25,"can not change file owner");
lf[270]=C_static_lambda_info(C_heaptop,39,"(change-file-owner fn347 uid348 gid349)");
lf[271]=C_h_intern(&lf[271],15,"current-user-id");
lf[272]=C_static_lambda_info(C_heaptop,17,"(current-user-id)");
lf[273]=C_h_intern(&lf[273],16,"current-group-id");
lf[274]=C_static_lambda_info(C_heaptop,18,"(current-group-id)");
lf[275]=C_h_intern(&lf[275],25,"current-effective-user-id");
lf[276]=C_static_lambda_info(C_heaptop,27,"(current-effective-user-id)");
lf[277]=C_h_intern(&lf[277],26,"current-effective-group-id");
lf[278]=C_static_lambda_info(C_heaptop,28,"(current-effective-group-id)");
lf[279]=C_h_intern(&lf[279],12,"set-user-id!");
lf[280]=C_static_string(C_heaptop,19,"can not set user ID");
lf[281]=C_static_lambda_info(C_heaptop,20,"(set-user-id! id361)");
lf[282]=C_h_intern(&lf[282],13,"set-group-id!");
lf[283]=C_static_string(C_heaptop,20,"can not set group ID");
lf[284]=C_static_lambda_info(C_heaptop,21,"(set-group-id! id363)");
lf[285]=C_static_lambda_info(C_heaptop,33,"(check filename366 acc367 loc368)");
lf[286]=C_h_intern(&lf[286],17,"file-read-access\077");
lf[287]=C_static_lambda_info(C_heaptop,31,"(file-read-access\077 filename372)");
lf[288]=C_h_intern(&lf[288],18,"file-write-access\077");
lf[289]=C_static_lambda_info(C_heaptop,32,"(file-write-access\077 filename373)");
lf[290]=C_h_intern(&lf[290],20,"file-execute-access\077");
lf[291]=C_static_lambda_info(C_heaptop,34,"(file-execute-access\077 filename374)");
lf[292]=C_h_intern(&lf[292],14,"create-session");
lf[293]=C_static_string(C_heaptop,22,"can not create session");
lf[294]=C_static_lambda_info(C_heaptop,16,"(create-session)");
lf[295]=C_h_intern(&lf[295],16,"process-group-id");
lf[296]=C_static_string(C_heaptop,33,"can not retrieve process group ID");
lf[297]=C_static_lambda_info(C_heaptop,25,"(process-group-id pid381)");
lf[298]=C_h_intern(&lf[298],21,"set-process-group-id!");
lf[299]=C_static_string(C_heaptop,28,"can not set process group ID");
lf[300]=C_static_lambda_info(C_heaptop,38,"(set-process-group-id! pid386 pgid387)");
lf[301]=C_h_intern(&lf[301],20,"create-symbolic-link");
lf[302]=C_h_intern(&lf[302],18,"create-symbol-link");
lf[303]=C_static_string(C_heaptop,28,"can not create symbolic link");
lf[304]=C_static_lambda_info(C_heaptop,36,"(create-symbolic-link old391 new392)");
lf[305]=C_h_intern(&lf[305],18,"read-symbolic-link");
lf[306]=C_static_string(C_heaptop,26,"can not read symbolic link");
lf[307]=C_static_lambda_info(C_heaptop,29,"(read-symbolic-link fname397)");
lf[308]=C_h_intern(&lf[308],9,"file-link");
lf[309]=C_h_intern(&lf[309],9,"hard-link");
lf[310]=C_static_string(C_heaptop,26,"could not create hard link");
lf[311]=C_static_lambda_info(C_heaptop,25,"(file-link old412 new413)");
lf[312]=C_h_intern(&lf[312],12,"fileno/stdin");
lf[313]=C_h_intern(&lf[313],13,"fileno/stdout");
lf[314]=C_h_intern(&lf[314],13,"fileno/stderr");
lf[315]=C_h_intern(&lf[315],7,"\000append");
lf[316]=C_static_string(C_heaptop,27,"invalid mode for input file");
lf[317]=C_static_string(C_heaptop,1,"a");
lf[318]=C_static_string(C_heaptop,21,"invalid mode argument");
lf[319]=C_static_string(C_heaptop,1,"r");
lf[320]=C_static_string(C_heaptop,1,"w");
lf[321]=C_static_lambda_info(C_heaptop,18,"(mode inp432 m433)");
lf[322]=C_static_string(C_heaptop,17,"can not open file");
lf[323]=C_static_string(C_heaptop,8,"(fdport)");
lf[324]=C_static_lambda_info(C_heaptop,32,"(check loc437 fd438 inp439 r440)");
lf[325]=C_h_intern(&lf[325],16,"open-input-file*");
lf[326]=C_static_lambda_info(C_heaptop,31,"(open-input-file* fd443 . m444)");
lf[327]=C_h_intern(&lf[327],17,"open-output-file*");
lf[328]=C_static_lambda_info(C_heaptop,32,"(open-output-file* fd446 . m447)");
lf[329]=C_h_intern(&lf[329],12,"port->fileno");
lf[330]=C_h_intern(&lf[330],6,"socket");
lf[331]=C_h_intern(&lf[331],20,"\003systcp-port->fileno");
lf[332]=C_static_string(C_heaptop,25,"port has no attached file");
lf[333]=C_static_string(C_heaptop,38,"can not access file-descriptor of port");
lf[334]=C_h_intern(&lf[334],25,"\003syspeek-unsigned-integer");
lf[335]=C_static_lambda_info(C_heaptop,22,"(port->fileno port452)");
lf[336]=C_h_intern(&lf[336],16,"duplicate-fileno");
lf[337]=C_static_string(C_heaptop,33,"can not duplicate file descriptor");
lf[338]=C_static_lambda_info(C_heaptop,34,"(duplicate-fileno old456 . new457)");
lf[339]=C_h_intern(&lf[339],13,"file-truncate");
lf[340]=C_static_string(C_heaptop,21,"can not truncate file");
lf[341]=C_static_string(C_heaptop,12,"invalid file");
lf[342]=C_static_lambda_info(C_heaptop,31,"(file-truncate fname463 off464)");
lf[343]=C_h_intern(&lf[343],4,"lock");
lf[344]=C_static_lambda_info(C_heaptop,30,"(setup port468 args469 loc470)");
lf[345]=C_static_lambda_info(C_heaptop,27,"(err msg483 lock484 loc485)");
lf[346]=C_h_intern(&lf[346],9,"file-lock");
lf[347]=C_static_string(C_heaptop,17,"can not lock file");
lf[348]=C_static_lambda_info(C_heaptop,29,"(file-lock port486 . args487)");
lf[349]=C_h_intern(&lf[349],18,"file-lock/blocking");
lf[350]=C_static_string(C_heaptop,17,"can not lock file");
lf[351]=C_static_lambda_info(C_heaptop,38,"(file-lock/blocking port489 . args490)");
lf[352]=C_h_intern(&lf[352],14,"file-test-lock");
lf[353]=C_static_string(C_heaptop,19,"can not unlock file");
lf[354]=C_static_lambda_info(C_heaptop,34,"(file-test-lock port492 . args493)");
lf[355]=C_h_intern(&lf[355],11,"file-unlock");
lf[356]=C_static_string(C_heaptop,19,"can not unlock file");
lf[357]=C_static_lambda_info(C_heaptop,21,"(file-unlock lock502)");
lf[358]=C_h_intern(&lf[358],11,"create-fifo");
lf[359]=C_static_string(C_heaptop,19,"can not create FIFO");
lf[360]=C_static_lambda_info(C_heaptop,32,"(create-fifo fname505 . mode506)");
lf[361]=C_h_intern(&lf[361],5,"fifo\077");
lf[362]=C_static_string(C_heaptop,19,"file does not exist");
lf[363]=C_static_lambda_info(C_heaptop,19,"(fifo\077 filename510)");
lf[364]=C_h_intern(&lf[364],6,"setenv");
lf[365]=C_static_lambda_info(C_heaptop,22,"(setenv var513 val514)");
lf[366]=C_h_intern(&lf[366],8,"unsetenv");
lf[367]=C_static_lambda_info(C_heaptop,17,"(unsetenv var518)");
lf[368]=C_h_intern(&lf[368],19,"current-environment");
lf[369]=C_static_lambda_info(C_heaptop,11,"(scan j531)");
lf[370]=C_static_lambda_info(C_heaptop,11,"(loop i528)");
lf[371]=C_static_lambda_info(C_heaptop,21,"(current-environment)");
lf[372]=C_h_intern(&lf[372],9,"prot/read");
lf[373]=C_h_intern(&lf[373],10,"prot/write");
lf[374]=C_h_intern(&lf[374],9,"prot/exec");
lf[375]=C_h_intern(&lf[375],9,"prot/none");
lf[376]=C_h_intern(&lf[376],9,"map/fixed");
lf[377]=C_h_intern(&lf[377],10,"map/shared");
lf[378]=C_h_intern(&lf[378],11,"map/private");
lf[379]=C_h_intern(&lf[379],13,"map/anonymous");
lf[380]=C_h_intern(&lf[380],8,"map/file");
lf[381]=C_h_intern(&lf[381],18,"map-file-to-memory");
lf[382]=C_h_intern(&lf[382],4,"mmap");
lf[383]=C_static_string(C_heaptop,26,"can not map file to memory");
lf[384]=C_h_intern(&lf[384],20,"\003syspointer->address");
lf[385]=C_static_string(C_heaptop,41,"bad argument type - not a foreign pointer");
lf[386]=C_h_intern(&lf[386],16,"\003sysnull-pointer");
lf[387]=C_static_lambda_info(C_heaptop,66,"(map-file-to-memory addr556 len557 prot558 flag559 fd560 . off561)");
lf[388]=C_h_intern(&lf[388],22,"unmap-file-from-memory");
lf[389]=C_static_string(C_heaptop,30,"can not unmap file from memory");
lf[390]=C_static_lambda_info(C_heaptop,41,"(unmap-file-from-memory mmap576 . len577)");
lf[391]=C_h_intern(&lf[391],26,"memory-mapped-file-pointer");
lf[392]=C_static_lambda_info(C_heaptop,36,"(memory-mapped-file-pointer mmap580)");
lf[393]=C_h_intern(&lf[393],19,"memory-mapped-file\077");
lf[394]=C_static_lambda_info(C_heaptop,26,"(memory-mapped-file\077 x582)");
lf[395]=C_h_intern(&lf[395],19,"seconds->local-time");
lf[396]=C_h_intern(&lf[396],18,"\003sysdecode-seconds");
lf[397]=C_static_lambda_info(C_heaptop,29,"(seconds->local-time secs595)");
lf[398]=C_h_intern(&lf[398],17,"seconds->utc-time");
lf[399]=C_static_lambda_info(C_heaptop,27,"(seconds->utc-time secs597)");
lf[400]=C_h_intern(&lf[400],15,"seconds->string");
lf[401]=C_static_string(C_heaptop,33,"can not convert seconds to string");
lf[402]=C_static_lambda_info(C_heaptop,25,"(seconds->string secs605)");
lf[403]=C_h_intern(&lf[403],12,"time->string");
lf[404]=C_static_string(C_heaptop,29,"can not time vector to string");
lf[405]=C_static_string(C_heaptop,21,"time vector too short");
lf[406]=C_static_lambda_info(C_heaptop,20,"(time->string tm614)");
lf[407]=C_h_intern(&lf[407],5,"_exit");
lf[408]=C_h_intern(&lf[408],23,"\003syscleanup-before-exit");
lf[409]=C_static_lambda_info(C_heaptop,17,"(_exit . code624)");
lf[410]=C_h_intern(&lf[410],10,"set-alarm!");
lf[411]=C_static_lambda_info(C_heaptop,20,"(set-alarm! a626629)");
lf[412]=C_h_intern(&lf[412],19,"set-buffering-mode!");
lf[413]=C_static_string(C_heaptop,26,"can not set buffering mode");
lf[414]=C_h_intern(&lf[414],5,"\000full");
lf[415]=C_h_intern(&lf[415],5,"\000line");
lf[416]=C_h_intern(&lf[416],5,"\000none");
lf[417]=C_static_string(C_heaptop,22,"invalid buffering-mode");
lf[418]=C_static_lambda_info(C_heaptop,47,"(set-buffering-mode! port630 mode631 . size632)");
lf[419]=C_h_intern(&lf[419],14,"terminal-port\077");
lf[420]=C_static_lambda_info(C_heaptop,24,"(terminal-port\077 port639)");
lf[421]=C_h_intern(&lf[421],13,"terminal-name");
lf[422]=C_static_string(C_heaptop,35,"port is not connected to a terminal");
lf[423]=C_static_lambda_info(C_heaptop,23,"(terminal-name port648)");
lf[424]=C_h_intern(&lf[424],13,"get-host-name");
lf[425]=C_h_intern(&lf[425],6,"\000error");
lf[426]=C_static_string(C_heaptop,26,"can not retrieve host-name");
lf[427]=C_static_lambda_info(C_heaptop,15,"(get-host-name)");
lf[428]=C_h_intern(&lf[428],12,"glob->regexp");
lf[429]=C_h_intern(&lf[429],13,"make-pathname");
lf[430]=C_h_intern(&lf[430],18,"decompose-pathname");
lf[431]=C_h_intern(&lf[431],4,"glob");
lf[432]=C_static_lambda_info(C_heaptop,7,"(a3930)");
lf[433]=C_h_intern(&lf[433],12,"string-match");
lf[434]=C_static_lambda_info(C_heaptop,11,"(loop f680)");
lf[435]=C_static_string(C_heaptop,1,".");
lf[436]=C_static_string(C_heaptop,1,"*");
lf[437]=C_static_lambda_info(C_heaptop,38,"(a3936 dir667670 file668671 ext669672)");
lf[438]=C_static_lambda_info(C_heaptop,15,"(conc paths665)");
lf[439]=C_static_lambda_info(C_heaptop,17,"(glob . paths663)");
lf[440]=C_h_intern(&lf[440],12,"process-fork");
lf[441]=C_static_string(C_heaptop,28,"can not create child process");
lf[442]=C_static_lambda_info(C_heaptop,16,"(f_4042 a693696)");
lf[443]=C_static_lambda_info(C_heaptop,25,"(process-fork . thunk691)");
lf[444]=C_static_lambda_info(C_heaptop,24,"(setarg a704710 a703711)");
lf[445]=C_static_lambda_info(C_heaptop,24,"(setenv a716722 a715723)");
lf[446]=C_h_intern(&lf[446],24,"pathname-strip-directory");
lf[447]=C_h_intern(&lf[447],15,"process-execute");
lf[448]=C_static_string(C_heaptop,23,"can not execute process");
lf[449]=C_static_lambda_info(C_heaptop,12,"(do745 i748)");
lf[450]=C_static_lambda_info(C_heaptop,18,"(do741 al743 i744)");
lf[451]=C_static_lambda_info(C_heaptop,31,"(body732 arglist738 envlist739)");
lf[452]=C_static_lambda_info(C_heaptop,31,"(def-envlist735 %arglist730767)");
lf[453]=C_static_lambda_info(C_heaptop,16,"(def-arglist734)");
lf[454]=C_static_lambda_info(C_heaptop,39,"(process-execute filename728 . g727729)");
lf[455]=C_h_intern(&lf[455],12,"process-wait");
lf[456]=C_static_string(C_heaptop,32,"waiting for child process failed");
lf[457]=C_static_lambda_info(C_heaptop,24,"(process-wait . args773)");
lf[458]=C_h_intern(&lf[458],18,"current-process-id");
lf[459]=C_static_lambda_info(C_heaptop,20,"(current-process-id)");
lf[460]=C_h_intern(&lf[460],17,"parent-process-id");
lf[461]=C_static_lambda_info(C_heaptop,19,"(parent-process-id)");
lf[462]=C_h_intern(&lf[462],5,"sleep");
lf[463]=C_static_lambda_info(C_heaptop,15,"(sleep a793796)");
lf[464]=C_h_intern(&lf[464],14,"process-signal");
lf[465]=C_static_string(C_heaptop,32,"could not send signal to process");
lf[466]=C_static_lambda_info(C_heaptop,31,"(process-signal id797 . sig798)");
lf[467]=C_h_intern(&lf[467],6,"getenv");
lf[468]=C_h_intern(&lf[468],11,"process-run");
lf[469]=C_static_string(C_heaptop,7,"/bin/sh");
lf[470]=C_static_string(C_heaptop,2,"-c");
lf[471]=C_static_string(C_heaptop,5,"SHELL");
lf[472]=C_static_lambda_info(C_heaptop,28,"(process-run f806 . args807)");
lf[473]=C_h_intern(&lf[473],15,"make-input-port");
lf[474]=C_h_intern(&lf[474],16,"make-output-port");
lf[475]=C_static_lambda_info(C_heaptop,7,"(a4446)");
lf[476]=C_h_intern(&lf[476],7,"process");
lf[477]=C_static_string(C_heaptop,25,"process exited abnormally");
lf[478]=C_static_lambda_info(C_heaptop,22,"(a4452 _831 f832 s833)");
lf[479]=C_static_lambda_info(C_heaptop,13,"(wait pid830)");
lf[480]=C_static_lambda_info(C_heaptop,7,"(a4471)");
lf[481]=C_static_lambda_info(C_heaptop,7,"(a4483)");
lf[482]=C_h_intern(&lf[482],25,"\003systhread-block-for-i/o!");
lf[483]=C_static_string(C_heaptop,22,"can not read from pipe");
lf[484]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[485]=C_static_lambda_info(C_heaptop,7,"(fetch)");
lf[486]=C_static_string(C_heaptop,21,"can not write to pipe");
lf[487]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[488]=C_static_lambda_info(C_heaptop,12,"(a4562 s890)");
lf[489]=C_static_lambda_info(C_heaptop,7,"(a4612)");
lf[490]=C_static_lambda_info(C_heaptop,7,"(a4625)");
lf[491]=C_static_lambda_info(C_heaptop,7,"(a4641)");
lf[492]=C_static_lambda_info(C_heaptop,7,"(a4657)");
lf[493]=C_static_string(C_heaptop,7,"/bin/sh");
lf[494]=C_static_string(C_heaptop,2,"-c");
lf[495]=C_static_string(C_heaptop,5,"SHELL");
lf[496]=C_static_lambda_info(C_heaptop,7,"(a4670)");
lf[497]=C_static_lambda_info(C_heaptop,28,"(a4489 in2853855 out2854856)");
lf[498]=C_static_lambda_info(C_heaptop,28,"(a4477 in1847849 out1848850)");
lf[499]=C_static_lambda_info(C_heaptop,24,"(body839 args845 env846)");
lf[500]=C_static_lambda_info(C_heaptop,24,"(def-env842 %args837906)");
lf[501]=C_static_lambda_info(C_heaptop,13,"(def-args841)");
lf[502]=C_static_lambda_info(C_heaptop,26,"(process cmd835 . g834836)");
lf[503]=C_h_intern(&lf[503],10,"find-files");
lf[504]=C_static_lambda_info(C_heaptop,13,"(f_4895 x945)");
lf[505]=C_static_string(C_heaptop,1,".");
lf[506]=C_static_string(C_heaptop,2,"..");
lf[507]=C_static_lambda_info(C_heaptop,7,"(a4841)");
lf[508]=C_static_string(C_heaptop,1,"*");
lf[509]=C_static_lambda_info(C_heaptop,7,"(a4846)");
lf[510]=C_static_lambda_info(C_heaptop,7,"(a4860)");
lf[511]=C_h_intern(&lf[511],16,"\003sysdynamic-wind");
lf[512]=C_h_intern(&lf[512],13,"pathname-file");
lf[513]=C_static_lambda_info(C_heaptop,17,"(loop fs947 r948)");
lf[514]=C_static_string(C_heaptop,1,"*");
lf[515]=C_static_lambda_info(C_heaptop,15,"(f_4911 . _943)");
lf[516]=C_static_lambda_info(C_heaptop,15,"(f_4903 . _942)");
lf[517]=C_static_lambda_info(C_heaptop,34,"(body930 action937 id938 limit939)");
lf[518]=C_static_lambda_info(C_heaptop,38,"(def-limit934 %action927960 %id928961)");
lf[519]=C_static_lambda_info(C_heaptop,25,"(def-id933 %action927963)");
lf[520]=C_static_lambda_info(C_heaptop,17,"(a4931 x965 y966)");
lf[521]=C_static_lambda_info(C_heaptop,15,"(def-action932)");
lf[522]=C_static_lambda_info(C_heaptop,48,"(find-files dir924 pred925 . action-id-limit926)");
lf[523]=C_h_intern(&lf[523],19,"set-root-directory!");
lf[524]=C_static_string(C_heaptop,31,"unable to change root directory");
lf[525]=C_static_lambda_info(C_heaptop,28,"(set-root-directory! dir980)");
lf[526]=C_h_intern(&lf[526],23,"\003sysuser-interrupt-hook");
lf[527]=C_static_lambda_info(C_heaptop,12,"(a5030 n274)");
lf[528]=C_h_intern(&lf[528],11,"make-vector");
lf[529]=C_h_intern(&lf[529],17,"register-feature!");
lf[530]=C_h_intern(&lf[530],5,"posix");
lf[531]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,532);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1130 */
static void f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1133 in k1130 */
static void f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1136 in k1133 in k1130 */
static void f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1139 in k1136 in k1133 in k1130 */
static void f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[529]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[530]);}

/* k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[4]+1);
t4=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=t3,a[3]=lf[10],tmp=(C_word)a,a+=4,tmp));
t5=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1180,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[17]+1,C_fix((C_word)PIPE_BUF));
t7=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_RDONLY));
t8=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_WRONLY));
t9=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_RDONLY));
t11=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_WRONLY));
t12=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_CREAT));
t13=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_APPEND));
t14=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_EXCL));
t15=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NOCTTY));
t16=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_NONBLOCK));
t17=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_TRUNC));
t18=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t19=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_FSYNC));
t20=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_BINARY));
t21=C_mutate((C_word*)lf[32]+1,C_fix((C_word)O_TEXT));
t22=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IRUSR));
t23=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IWUSR));
t24=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IXUSR));
t25=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IRGRP));
t26=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IWGRP));
t27=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IXGRP));
t28=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IROTH));
t29=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IWOTH));
t30=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IXOTH));
t31=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXU));
t32=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXG));
t33=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_IRWXO));
t34=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISVTX));
t35=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISUID));
t36=C_mutate((C_word*)lf[47]+1,C_fix((C_word)S_ISGID));
t37=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t38=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t37);
t39=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=t38,a[3]=lf[53],tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1273,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp));
t41=*((C_word*)lf[57]+1);
t42=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1288,a[2]=t41,a[3]=lf[62],tmp=(C_word)a,a+=4,tmp));
t43=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=lf[66],tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[67]+1);
t45=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=t44,a[3]=lf[71],tmp=(C_word)a,a+=4,tmp));
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=lf[72],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=lf[73],tmp=(C_word)a,a+=3,tmp);
t48=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=lf[74],tmp=(C_word)a,a+=3,tmp);
t49=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1427,a[2]=t47,a[3]=t48,a[4]=t46,a[5]=lf[82],tmp=(C_word)a,a+=6,tmp));
t50=C_mutate((C_word*)lf[83]+1,C_fix((C_word)SEEK_SET));
t51=C_mutate((C_word*)lf[84]+1,C_fix((C_word)SEEK_END));
t52=C_mutate((C_word*)lf[85]+1,C_fix((C_word)SEEK_CUR));
t53=C_mutate(&lf[86],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=lf[89],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=lf[92],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=lf[96],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=lf[98],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1706,a[2]=lf[100],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=lf[106],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=lf[120],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=lf[123],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=lf[126],tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=lf[129],tmp=(C_word)a,a+=3,tmp));
t68=*((C_word*)lf[4]+1);
t69=*((C_word*)lf[57]+1);
t70=*((C_word*)lf[130]+1);
t71=*((C_word*)lf[131]+1);
t72=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=t69,a[3]=t71,a[4]=lf[136],tmp=(C_word)a,a+=5,tmp));
t73=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=lf[139],tmp=(C_word)a,a+=3,tmp));
t74=*((C_word*)lf[57]+1);
t75=*((C_word*)lf[131]+1);
t76=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=t74,a[3]=t75,a[4]=lf[142],tmp=(C_word)a,a+=5,tmp));
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=lf[144],tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2041,a[2]=lf[146],tmp=(C_word)a,a+=3,tmp);
t79=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=lf[151],tmp=(C_word)a,a+=3,tmp);
t80=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2062,a[2]=t78,a[3]=t79,a[4]=t77,a[5]=lf[154],tmp=(C_word)a,a+=6,tmp));
t81=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2098,a[2]=t78,a[3]=t79,a[4]=t77,a[5]=lf[156],tmp=(C_word)a,a+=6,tmp));
t82=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=lf[161],tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[162]+1,*((C_word*)lf[157]+1));
t84=*((C_word*)lf[152]+1);
t85=*((C_word*)lf[155]+1);
t86=*((C_word*)lf[157]+1);
t87=*((C_word*)lf[162]+1);
t88=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=t84,a[3]=t86,a[4]=lf[166],tmp=(C_word)a,a+=5,tmp));
t89=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2174,a[2]=t85,a[3]=t87,a[4]=lf[170],tmp=(C_word)a,a+=5,tmp));
t90=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2198,a[2]=t84,a[3]=t86,a[4]=lf[174],tmp=(C_word)a,a+=5,tmp));
t91=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=t85,a[3]=t87,a[4]=lf[178],tmp=(C_word)a,a+=5,tmp));
t92=C_mutate((C_word*)lf[179]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2238,a[2]=lf[181],tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[182]+1,C_fix((C_word)SIGTERM));
t94=C_mutate((C_word*)lf[183]+1,C_fix((C_word)SIGKILL));
t95=C_mutate((C_word*)lf[184]+1,C_fix((C_word)SIGINT));
t96=C_mutate((C_word*)lf[185]+1,C_fix((C_word)SIGHUP));
t97=C_mutate((C_word*)lf[186]+1,C_fix((C_word)SIGFPE));
t98=C_mutate((C_word*)lf[187]+1,C_fix((C_word)SIGILL));
t99=C_mutate((C_word*)lf[188]+1,C_fix((C_word)SIGSEGV));
t100=C_mutate((C_word*)lf[189]+1,C_fix((C_word)SIGABRT));
t101=C_mutate((C_word*)lf[190]+1,C_fix((C_word)SIGTRAP));
t102=C_mutate((C_word*)lf[191]+1,C_fix((C_word)SIGQUIT));
t103=C_mutate((C_word*)lf[192]+1,C_fix((C_word)SIGALRM));
t104=C_mutate((C_word*)lf[193]+1,C_fix((C_word)SIGVTALRM));
t105=C_mutate((C_word*)lf[194]+1,C_fix((C_word)SIGPROF));
t106=C_mutate((C_word*)lf[195]+1,C_fix((C_word)SIGIO));
t107=C_mutate((C_word*)lf[196]+1,C_fix((C_word)SIGURG));
t108=C_mutate((C_word*)lf[197]+1,C_fix((C_word)SIGCHLD));
t109=C_mutate((C_word*)lf[198]+1,C_fix((C_word)SIGCONT));
t110=C_mutate((C_word*)lf[199]+1,C_fix((C_word)SIGSTOP));
t111=C_mutate((C_word*)lf[200]+1,C_fix((C_word)SIGTSTP));
t112=C_mutate((C_word*)lf[201]+1,C_fix((C_word)SIGPIPE));
t113=C_mutate((C_word*)lf[202]+1,C_fix((C_word)SIGXCPU));
t114=C_mutate((C_word*)lf[203]+1,C_fix((C_word)SIGXFSZ));
t115=C_mutate((C_word*)lf[204]+1,C_fix((C_word)SIGUSR1));
t116=C_mutate((C_word*)lf[205]+1,C_fix((C_word)SIGUSR2));
t117=C_mutate((C_word*)lf[206]+1,C_fix((C_word)SIGWINCH));
t118=*((C_word*)lf[207]+1);
t119=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=t118,tmp=(C_word)a,a+=4,tmp);
t120=*((C_word*)lf[528]+1);
((C_proc4)C_retrieve_proc(t120))(4,t120,t119,C_fix(256),C_SCHEME_FALSE);}

/* k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=t1,a[3]=lf[209],tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[211],tmp=(C_word)a,a+=5,tmp));
t4=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=lf[216],tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5031,a[2]=lf[527],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[208]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,*((C_word*)lf[184]+1),t6);}

/* a5030 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_5031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5031,3,t0,t1,t2);}
t3=*((C_word*)lf[526]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2339,a[2]=lf[220],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=lf[222],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=lf[225],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[226],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=lf[227],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2498,a[2]=lf[233],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[242]+1,C_fix((C_word)EPERM));
t10=C_mutate((C_word*)lf[243]+1,C_fix((C_word)ENOENT));
t11=C_mutate((C_word*)lf[244]+1,C_fix((C_word)ESRCH));
t12=C_mutate((C_word*)lf[245]+1,C_fix((C_word)EINTR));
t13=C_mutate((C_word*)lf[246]+1,C_fix((C_word)EIO));
t14=C_mutate((C_word*)lf[247]+1,C_fix((C_word)ENOEXEC));
t15=C_mutate((C_word*)lf[248]+1,C_fix((C_word)EBADF));
t16=C_mutate((C_word*)lf[249]+1,C_fix((C_word)ECHILD));
t17=C_mutate((C_word*)lf[250]+1,C_fix((C_word)ENOMEM));
t18=C_mutate((C_word*)lf[251]+1,C_fix((C_word)EACCES));
t19=C_mutate((C_word*)lf[252]+1,C_fix((C_word)EFAULT));
t20=C_mutate((C_word*)lf[253]+1,C_fix((C_word)EBUSY));
t21=C_mutate((C_word*)lf[254]+1,C_fix((C_word)ENOTDIR));
t22=C_mutate((C_word*)lf[255]+1,C_fix((C_word)EISDIR));
t23=C_mutate((C_word*)lf[256]+1,C_fix((C_word)EINVAL));
t24=C_mutate((C_word*)lf[257]+1,C_fix((C_word)EMFILE));
t25=C_mutate((C_word*)lf[258]+1,C_fix((C_word)ENOSPC));
t26=C_mutate((C_word*)lf[259]+1,C_fix((C_word)ESPIPE));
t27=C_mutate((C_word*)lf[260]+1,C_fix((C_word)EPIPE));
t28=C_mutate((C_word*)lf[261]+1,C_fix((C_word)EAGAIN));
t29=C_mutate((C_word*)lf[262]+1,C_fix((C_word)EROFS));
t30=C_mutate((C_word*)lf[263]+1,C_fix((C_word)EEXIST));
t31=C_mutate((C_word*)lf[264]+1,C_fix((C_word)EWOULDBLOCK));
t32=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=lf[267],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=lf[270],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=lf[272],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=lf[274],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=lf[276],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=lf[278],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=lf[281],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=lf[284],tmp=(C_word)a,a+=3,tmp));
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=lf[285],tmp=(C_word)a,a+=3,tmp);
t41=C_mutate((C_word*)lf[286]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=t40,a[3]=lf[287],tmp=(C_word)a,a+=4,tmp));
t42=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=t40,a[3]=lf[289],tmp=(C_word)a,a+=4,tmp));
t43=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2818,a[2]=t40,a[3]=lf[291],tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=lf[294],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2839,a[2]=lf[297],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=lf[300],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=lf[304],tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[131]+1);
t49=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[2],a[3]=t48,tmp=(C_word)a,a+=4,tmp);
t50=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
t51=*((C_word*)lf[57]+1);
((C_proc3)C_retrieve_proc(t51))(3,t51,t49,t50);}

/* k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word ab[182],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[307],tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2966,a[2]=lf[311],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[312]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[313]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[314]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=lf[321],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=lf[324],tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3043,a[2]=t7,a[3]=t8,a[4]=lf[326],tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3057,a[2]=t7,a[3]=t8,a[4]=lf[328],tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=lf[335],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3116,a[2]=lf[338],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=lf[342],tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3182,a[2]=lf[344],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=lf[345],tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3274,a[2]=t14,a[3]=t15,a[4]=lf[348],tmp=(C_word)a,a+=5,tmp));
t17=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3289,a[2]=t14,a[3]=t15,a[4]=lf[351],tmp=(C_word)a,a+=5,tmp));
t18=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3304,a[2]=t14,a[3]=t15,a[4]=lf[354],tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=lf[357],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=lf[360],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=lf[363],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=lf[365],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=lf[367],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3460,a[2]=lf[371],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[372]+1,C_fix((C_word)PROT_READ));
t26=C_mutate((C_word*)lf[373]+1,C_fix((C_word)PROT_WRITE));
t27=C_mutate((C_word*)lf[374]+1,C_fix((C_word)PROT_EXEC));
t28=C_mutate((C_word*)lf[375]+1,C_fix((C_word)PROT_NONE));
t29=C_mutate((C_word*)lf[376]+1,C_fix((C_word)MAP_FIXED));
t30=C_mutate((C_word*)lf[377]+1,C_fix((C_word)MAP_SHARED));
t31=C_mutate((C_word*)lf[378]+1,C_fix((C_word)MAP_PRIVATE));
t32=C_mutate((C_word*)lf[379]+1,C_fix((C_word)MAP_ANONYMOUS));
t33=C_mutate((C_word*)lf[380]+1,C_fix((C_word)MAP_FILE));
t34=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=lf[387],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3625,a[2]=lf[390],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=lf[392],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[393]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=lf[394],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3675,a[2]=lf[397],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[398]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3684,a[2]=lf[399],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[400]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=lf[402],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3720,a[2]=lf[406],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3754,a[2]=lf[409],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[410]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=lf[411],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3780,a[2]=lf[418],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=lf[420],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=lf[423],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3898,a[2]=lf[427],tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[428]+1);
t49=*((C_word*)lf[132]+1);
t50=*((C_word*)lf[429]+1);
t51=*((C_word*)lf[430]+1);
t52=C_mutate((C_word*)lf[431]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3910,a[2]=t48,a[3]=t49,a[4]=t50,a[5]=t51,a[6]=lf[439],tmp=(C_word)a,a+=7,tmp));
t53=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=lf[443],tmp=(C_word)a,a+=3,tmp));
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4058,a[2]=lf[444],tmp=(C_word)a,a+=3,tmp);
t55=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=lf[445],tmp=(C_word)a,a+=3,tmp);
t56=*((C_word*)lf[446]+1);
t57=C_mutate((C_word*)lf[447]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4096,a[2]=t56,a[3]=t55,a[4]=t54,a[5]=lf[454],tmp=(C_word)a,a+=6,tmp));
t58=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=lf[457],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[458]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=lf[459],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[460]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=lf[461],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4357,a[2]=lf[463],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[464]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4364,a[2]=lf[466],tmp=(C_word)a,a+=3,tmp));
t63=*((C_word*)lf[440]+1);
t64=*((C_word*)lf[447]+1);
t65=*((C_word*)lf[467]+1);
t66=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=t63,a[3]=t65,a[4]=t64,a[5]=lf[472],tmp=(C_word)a,a+=6,tmp));
t67=*((C_word*)lf[179]+1);
t68=*((C_word*)lf[440]+1);
t69=*((C_word*)lf[336]+1);
t70=*((C_word*)lf[54]+1);
t71=*((C_word*)lf[468]+1);
t72=*((C_word*)lf[57]+1);
t73=*((C_word*)lf[58]+1);
t74=*((C_word*)lf[473]+1);
t75=*((C_word*)lf[474]+1);
t76=*((C_word*)lf[63]+1);
t77=*((C_word*)lf[455]+1);
t78=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4441,a[2]=t77,a[3]=lf[479],tmp=(C_word)a,a+=4,tmp);
t79=C_mutate((C_word*)lf[476]+1,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4461,a[2]=t68,a[3]=t69,a[4]=t72,a[5]=t74,a[6]=t75,a[7]=t70,a[8]=t78,a[9]=t67,a[10]=lf[502],tmp=(C_word)a,a+=11,tmp));
t80=*((C_word*)lf[431]+1);
t81=*((C_word*)lf[433]+1);
t82=*((C_word*)lf[429]+1);
t83=*((C_word*)lf[137]+1);
t84=C_mutate((C_word*)lf[503]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4775,a[2]=t83,a[3]=t82,a[4]=t80,a[5]=t81,a[6]=lf[522],tmp=(C_word)a,a+=7,tmp));
t85=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=lf[525],tmp=(C_word)a,a+=3,tmp));
t86=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t86+1)))(2,t86,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_5008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5008,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[523]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5000,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_5000(2,t6,C_SCHEME_FALSE);}}

/* k4998 in set-root-directory! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(C_word)stub975(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[523],lf[524],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_4775r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4775r(t0,t1,t2,t3,t4);}}

static void f_4775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=lf[517],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=t5,a[3]=lf[518],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t6,a[3]=lf[519],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4926,a[2]=t7,a[3]=lf[521],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t9=t8;
f_4926(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t7;
f_4921(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
t13=t6;
f_4916(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
t15=t5;
f_4777(t15,t1,t9,t11,t13);}
else{
t15=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action932 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4926,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4932,a[2]=lf[520],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
f_4921(t3,t1,t2);}

/* a4931 in def-action932 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4932,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id933 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4921,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_4916(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit934 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4916(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4916,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_4777(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[503]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_4784(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=t4,a[3]=t7,a[4]=lf[515],tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_4784(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4903,a[2]=lf[516],tmp=(C_word)a,a+=3,tmp));}}

/* f_4903 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4903(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4911 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4911(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4784,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=lf[504],tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4891,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[514]);}

/* k4889 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=lf[513],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4796(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4796,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=*((C_word*)lf[512]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k4875 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)((C_word*)t0)[7])[1];
f_4796(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4882 in k4875 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4796(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[505]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[506]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=((C_word*)((C_word*)t0)[10])[1];
f_4796(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4842,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=lf[507],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=lf[509],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4861,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=lf[510],tmp=(C_word)a,a+=6,tmp);
t11=*((C_word*)lf[511]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=((C_word*)((C_word*)t0)[8])[1];
f_4796(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a4860 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a4846 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[508]);}

/* k4857 in a4846 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4853 in a4846 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4796(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4841 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4838 in k4828 in k4869 in k4813 in loop in k4792 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4796(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4895 in k4782 in body930 in find-files in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4895,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4461(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3r,(void*)f_4461r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4461r(t0,t1,t2,t3);}}

static void f_4461r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(20);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=lf[499],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=t4,a[3]=lf[500],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=t5,a[3]=lf[501],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_4727(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_4722(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t4;
f_4463(t11,t1,t7,t9);}
else{
t11=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args841 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4727,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4722(t2,t1,C_SCHEME_FALSE);}

/* def-env842 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4722(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4722,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_4463(t3,t1,t2,C_SCHEME_FALSE);}

/* body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4463,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[10],lf[476]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[9],a[3]=lf[480],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=lf[498],tmp=(C_word)a,a+=14,tmp);
C_call_with_values(4,0,t1,t5,t6);}

/* a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[12],a[3]=lf[481],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t3,a[14]=lf[497],tmp=(C_word)a,a+=15,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4490,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[13],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[5],a[11]=lf[496],tmp=(C_word)a,a+=12,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(*((C_word*)lf[312]+1),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_4681(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],*((C_word*)lf[312]+1));}}

/* k4716 in k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4679 in k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(*((C_word*)lf[313]+1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_4684(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],*((C_word*)lf[313]+1));}}

/* k4707 in k4679 in k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4682 in k4679 in k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=*((C_word*)lf[447]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[467]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[495]);}}

/* k4691 in k4682 in k4679 in k4676 in k4673 in a4670 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[493]);
t3=(C_word)C_a_i_list(&a,2,lf[494],((C_word*)t0)[4]);
t4=*((C_word*)lf[447]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}

/* k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=t5,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
t7=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=f_1146(((C_word*)t0)[13]);
t3=f_1146(((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_fix(256));}

/* k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[11],a[3]=t1,a[4]=((C_word*)t0)[12],a[5]=t3,a[6]=t5,a[7]=lf[485],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4626,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=lf[490],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=t5,a[5]=lf[491],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=lf[492],tmp=(C_word)a,a+=9,tmp);
t11=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t11))(5,t11,t7,t8,t9,t10);}

/* a4657 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4660 in a4657 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)t0)[4];
f_4441(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4641 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[2];
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=(C_word)stub826(C_SCHEME_UNDEFINED,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(C_fix(1),t5));}}

/* a4625 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
f_4515(t3,t2);}

/* k4628 in a4625 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_subchar(((C_word*)t0)[2],t2));}}

/* k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[488],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=lf[489],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}

/* a4612 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4615 in a4612 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)t0)[4];
f_4441(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4562 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4563,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_block_size(((C_word*)t3)[1]);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=lf[487],tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4572(t10,t1);}

/* loop in a4562 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4572,NULL,2,t0,t1);}
t2=(C_word)C_write(((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1180(t5);}
else{
t5=lf[5];
f_1163(t5,t1,lf[49],lf[486],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)((C_word*)t0)[4])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4604,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=*((C_word*)lf[131]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)((C_word*)t0)[5])[1],t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4602 in loop in a4562 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4572(t5,((C_word*)t0)[2]);}

/* k4586 in loop in a4562 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4572(t2,((C_word*)t0)[2]);}

/* k4559 in k4555 in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fetch in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4515,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4525,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[484],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4529(t6,t2);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4529,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],C_fix(256));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[482]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[12]+1),((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t5=lf[5];
f_1163(t5,t1,lf[49],lf[476],lf[483],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4543 in loop in fetch in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1180(t2);}

/* k4546 in k4543 in loop in fetch in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4529(t2,((C_word*)t0)[2]);}

/* k4523 in fetch in k4511 in k4498 in k4495 in k4492 in a4489 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a4483 in a4477 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4471 in body839 in process in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* wait in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4441,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4447,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[475],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4453,a[2]=t2,a[3]=lf[478],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t3,t4);}

/* a4452 in wait in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4453,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[91]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[476],lf[477],((C_word*)t0)[2],t4);}}

/* a4446 in wait in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4391(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4391r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4391r(t0,t1,t2,t3);}}

static void f_4391r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k4396 in process-run in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[6])){
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[471]);}}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k4411 in k4396 in process-run in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[469]);
t3=(C_word)C_a_i_list(&a,2,lf[470],((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* process-signal in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4364(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4364r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4364r(t0,t1,t2,t3);}}

static void f_4364r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[464]);
t7=(C_word)C_i_check_exact_2(t5,lf[464]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
t10=lf[5];
f_1163(t10,t1,lf[213],lf[464],lf[465],(C_word)C_a_i_list(&a,2,t2,t5));}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4357,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub794(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub791(C_SCHEME_UNDEFINED));}

/* current-process-id in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub789(C_SCHEME_UNDEFINED));}

/* process-wait in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4275(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4275r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4275r(t0,t1,t2);}}

static void f_4275r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(3);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_truep(t8)?C_fix((C_word)WNOHANG):C_fix(0));
t13=(C_word)C_i_check_exact_2(t11,lf[455]);
t14=(C_word)C_waitpid(t11,t12);
t15=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t16=(C_word)C_eqp(t14,C_fix(-1));
if(C_truep(t16)){
t17=lf[5];
f_1163(t17,t1,lf[213],lf[455],lf[456],(C_word)C_a_i_list(&a,1,t11));}
else{
t17=(C_truep(t15)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
C_values(5,0,t1,t14,t15,t17);}}
else{
t11=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4096(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_4096r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4096r(t0,t1,t2,t3);}}

static void f_4096r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=lf[451],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4222,a[2]=t4,a[3]=lf[452],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4227,a[2]=t5,a[3]=lf[453],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_4227(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_4222(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t4;
f_4098(t11,t1,t7,t9);}
else{
t11=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist734 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4222(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist735 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4222,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_4098(t3,t1,t2,C_SCHEME_FALSE);}

/* body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4098,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[447]);
t5=(C_word)C_i_check_list_2(t2,lf[447]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4108,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_4058(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4116,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=lf[450],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4116(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do741 in k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4116(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4116,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_4058(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[3],a[3]=lf[449],tmp=(C_word)a,a+=4,tmp);
t7=t5;
f_4129(t7,f_4159(t6,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_4129(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[447]);
t6=(C_word)C_block_size(t4);
t7=f_4058(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t14=t1;
t15=t8;
t16=t9;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}

/* do745 in do741 in k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_4159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_4077(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[447]);
t5=(C_word)C_block_size(t3);
t6=f_4077(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k4127 in do741 in k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_4129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4152 in k4127 in do741 in k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4130 in k4127 in do741 in k4106 in body732 in process-execute in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub713(C_SCHEME_UNDEFINED);
t5=(C_word)stub725(C_SCHEME_UNDEFINED);
t6=lf[5];
f_1163(t6,((C_word*)t0)[3],lf[213],lf[447],lf[448],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_4077(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub718(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_4058(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub706(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4016(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4016r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4016r(t0,t1,t2);}}

static void f_4016r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub689(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
t5=lf[5];
f_1163(t5,t1,lf[213],lf[440],lf[441],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k4036 in process-fork in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=lf[442],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_4042 in k4036 in process-fork in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4042,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub694(C_SCHEME_UNDEFINED,t3));}

/* glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3910(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_3910r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3910r(t0,t1,t2);}}

static void f_3910r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(10);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=lf[438],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3916(t6,t1,t2);}

/* conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3916,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3931,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[432],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=lf[437],tmp=(C_word)a,a+=8,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3937,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4008,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[436]);
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k4006 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:lf[435]);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3946 in k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=lf[434],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3950(t5,((C_word*)t0)[2],t1);}

/* loop in k3946 in k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=((C_word*)((C_word*)t0)[6])[1];
f_3916(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
t5=*((C_word*)lf[433]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3965 in loop in k3946 in k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3950(t3,((C_word*)t0)[6],t2);}}

/* k3975 in k3965 in loop in k3946 in k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_3950(t4,t2,t3);}

/* k3979 in k3975 in k3965 in loop in k3946 in k3939 in a3936 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3930 in conc in glob in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub652(t3),C_fix(0));}

/* k3900 in get-host-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3905(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[5];
f_1163(t3,t2,lf[425],lf[424],lf[426],C_SCHEME_END_OF_LIST);}}

/* k3903 in k3900 in get-host-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3872,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[421]);}

/* k3870 in terminal-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_eqp(lf[111],t3);
t5=(C_truep(t4)?(C_word)C_tty_portp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t2;
f_3875(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,lf[421],lf[422],((C_word*)t0)[2]);}}

/* k3873 in k3870 in terminal-name in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub644(t4,t5);
t7=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* terminal-port? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3843,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[419]);}

/* k3841 in terminal-port? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[334]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3844 in k3841 in terminal-port? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3780r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3780r(t0,t1,t2,t3,t4);}}

static void f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3784,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[412]);}

/* k3782 in set-buffering-mode! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3784,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[414]);
if(C_truep(t6)){
t7=t5;
f_3790(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[415]);
if(C_truep(t7)){
t8=t5;
f_3790(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[416]);
if(C_truep(t8)){
t9=t5;
f_3790(2,t9,C_fix((C_word)_IONBF));}
else{
t9=*((C_word*)lf[91]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[412],lf[417],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k3788 in k3782 in set-buffering-mode! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[412]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[111],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
t6=*((C_word*)lf[91]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[412],lf[413],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3773,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub627(C_SCHEME_UNDEFINED,t3));}

/* _exit in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3754(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3754r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3754r(t0,t1,t2);}}

static void f_3754r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3758,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[408]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3756 in _exit in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
t4=((C_word*)t0)[2];
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub621(C_SCHEME_UNDEFINED,t5));}

/* time->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3720,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[403]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3727,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[403],lf[405],t2);}
else{
t6=t4;
f_3727(2,t6,C_SCHEME_UNDEFINED);}}

/* k3725 in time->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub610(t4,t3),C_fix(0));}

/* k3728 in k3725 in time->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3733(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[403],lf[404],((C_word*)t0)[2]);}}

/* k3731 in k3728 in k3725 in time->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3703,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub601(t5,t6);
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3705 in seconds->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3710,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3710(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[400],lf[401],((C_word*)t0)[2]);}}

/* k3708 in k3705 in seconds->string in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->utc-time in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3684,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[398]);
t4=*((C_word*)lf[396]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3675,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[395]);
t4=*((C_word*)lf[396]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3669,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[382]));}

/* memory-mapped-file-pointer in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3660,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[382],lf[391]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3625(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3625r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3625r(t0,t1,t2,t3);}}

static void f_3625r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(6);
t4=(C_word)C_i_check_structure_2(t2,lf[382],lf[388]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub570(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=lf[5];
f_1163(t12,t1,lf[49],lf[388],lf[389],(C_word)C_a_i_list(&a,2,t2,t6));}}

/* map-file-to-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc(c,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_3563r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_3563r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void f_3563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3567,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_3567(2,t10,t2);}
else{
t10=*((C_word*)lf[386]+1);
((C_proc2)C_retrieve_proc(t10))(2,t10,t8);}}

/* k3565 in map-file-to-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_3573(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[381],lf[385],t1);}}

/* k3571 in k3565 in map-file-to-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub545(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
t17=*((C_word*)lf[384]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t14);}

/* k3590 in k3571 in k3565 in map-file-to-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=lf[5];
f_1163(t3,((C_word*)t0)[8],lf[49],lf[381],lf[383],(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[8];
f_3579(2,t3,C_SCHEME_UNDEFINED);}}

/* k3577 in k3571 in k3565 in map-file-to-memory in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[382],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3466,a[2]=t3,a[3]=lf[370],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3466(t5,t1,C_fix(0));}

/* loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3466,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3470,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub523(t5,t6);
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3468 in loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3478,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=lf[369],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3478(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k3468 in loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3478,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=*((C_word*)lf[69]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3502 in scan in k3468 in loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
t5=*((C_word*)lf[69]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k3506 in k3502 in scan in k3468 in loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[2])[1];
f_3466(t5,t3,t4);}

/* k3494 in k3506 in k3502 in scan in k3468 in loop in current-environment in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3440,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3446 in unsetenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3423,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[364]);
t5=(C_word)C_i_check_string_2(t3,lf[364]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k3432 in setenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3436 in k3432 in setenv in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3397,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3421,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3419 in fifo? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3402 in fifo? in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
t2=lf[5];
f_1163(t2,((C_word*)t0)[3],lf[49],lf[361],lf[362],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* create-fifo in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3354(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3354r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3354r(t0,t1,t2,t3);}}

static void f_3354r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[358]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_3361(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_3361(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k3359 in create-fifo in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3361,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[358]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3382,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3380 in k3359 in create-fifo in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3376 in k3359 in create-fifo in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[358],lf[359],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3326,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[343],lf[355]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
t9=lf[5];
f_1163(t9,t1,lf[49],lf[355],lf[356],(C_word)C_a_i_list(&a,1,t2));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3304r(t0,t1,t2,t3);}}

static void f_3304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_3182(t4,t2,t3,lf[352]);}

/* k3306 in file-test-lock in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
f_3256(((C_word*)t0)[3],lf[353],t1,lf[352]);}}

/* file-lock/blocking in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3289(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3289r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3289r(t0,t1,t2,t3);}}

static void f_3289r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3293,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_3182(t4,t2,t3,lf[349]);}

/* k3291 in file-lock/blocking in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
f_3256(((C_word*)t0)[2],lf[350],t1,lf[349]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3274(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3274r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3274r(t0,t1,t2,t3);}}

static void f_3274r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3278,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_3182(t4,t2,t3,lf[346]);}

/* k3276 in file-lock in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
f_3256(((C_word*)t0)[2],lf[347],t1,lf[346]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3256(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3256,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
t8=lf[5];
f_1163(t8,t1,lf[49],t4,t2,(C_word)C_a_i_list(&a,3,t5,t6,t7));}

/* setup in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3182(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3182,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3204,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t16=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
t15=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k3202 in setup in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_3210(t6,t5);}
else{
t5=t3;
f_3210(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k3208 in k3202 in setup in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[343],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3143,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[339]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3160,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3171,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3160(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[339],lf[341],t2);}}}

/* k3169 in file-truncate in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3165 in file-truncate in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3160(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k3158 in file-truncate in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3160,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[5];
f_1163(t2,((C_word*)t0)[4],lf[49],lf[339],lf[340],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3116(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3116r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3116r(t0,t1,t2,t3);}}

static void f_3116r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[336]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3123(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[336]);
t8=t5;
f_3123(t8,(C_word)C_dup2(t2,t6));}}

/* k3121 in duplicate-fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3123(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3123,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=lf[5];
f_1163(t3,t2,lf[49],lf[336],lf[337],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=t2;
f_3126(2,t3,C_SCHEME_UNDEFINED);}}

/* k3124 in k3121 in duplicate-fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3071,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[329]);}

/* k3073 in port->fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[330],t2);
if(C_truep(t3)){
t4=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[334]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k3108 in k3073 in port->fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
t2=lf[5];
f_1163(t2,((C_word*)t0)[3],lf[60],lf[329],lf[332],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=lf[5];
f_1163(t4,t3,lf[49],lf[329],lf[333],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t3;
f_3093(2,t4,C_SCHEME_UNDEFINED);}}}

/* k3091 in k3108 in k3073 in port->fileno in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3057(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3057r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3057r(t0,t1,t2,t3);}}

static void f_3057r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[327]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3069,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2991(t5,C_SCHEME_FALSE,t3);}

/* k3067 in open-output-file* in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
f_3028(((C_word*)t0)[2],lf[327],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3043(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3043r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3043r(t0,t1,t2,t3);}}

static void f_3043r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[325]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3055,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2991(t5,C_SCHEME_TRUE,t3);}

/* k3053 in open-input-file* in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
f_3028(((C_word*)t0)[2],lf[325],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_3028(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
t6=lf[5];
f_1163(t6,t1,lf[49],t2,lf[322],(C_word)C_a_i_list(&a,1,t3));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[148]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[149]+1),lf[323],lf[111]);}}

/* k3039 in check in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2991(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[315]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
t8=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[316],t5);}
else{
t8=t4;
f_2999(2,t8,lf[317]);}}
else{
t7=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[318],t5);}}
else{
t5=t4;
f_2999(2,t5,(C_truep(t2)?lf[319]:lf[320]));}}

/* k2997 in mode in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2966,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[308]);
t5=(C_word)C_i_check_string_2(t3,lf[308]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2947,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_2947(2,t9,C_SCHEME_FALSE);}}

/* k2945 in file-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_2951(2,t3,C_SCHEME_FALSE);}}

/* k2949 in k2945 in file-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(C_word)stub404(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[4],lf[49],lf[309],lf[310],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2916,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[305]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2938 in read-symbolic-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2922 in read-symbolic-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2927,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=lf[5];
f_1163(t4,t3,lf[49],lf[305],lf[306],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t3;
f_2927(2,t4,C_SCHEME_UNDEFINED);}}

/* k2925 in k2922 in read-symbolic-link in k2913 in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2878,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[301]);
t5=(C_word)C_i_check_string_2(t3,lf[301]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2899,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2909 in create-symbolic-link in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2897 in create-symbolic-link in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2907,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2905 in k2897 in create-symbolic-link in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2901 in k2897 in create-symbolic-link in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[4],lf[49],lf[302],lf[303],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2857,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[298]);
t5=(C_word)C_i_check_exact_2(t3,lf[298]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2873,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k2871 in set-process-group-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[298],lf[299],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* process-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[295]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_2846(2,t6,C_SCHEME_UNDEFINED);}}

/* k2850 in process-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[295],lf[296],((C_word*)t0)[2]);}

/* k2844 in process-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* create-session in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2828(2,t4,C_SCHEME_UNDEFINED);}}

/* k2832 in create-session in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[292],lf[293]);}

/* k2826 in create-session in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2818,3,t0,t1,t2);}
f_2782(t1,t2,C_fix((C_word)X_OK),lf[290]);}

/* file-write-access? in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2812,3,t0,t1,t2);}
f_2782(t1,t2,C_fix((C_word)W_OK),lf[288]);}

/* file-read-access? in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2806,3,t0,t1,t2);}
f_2782(t1,t2,C_fix((C_word)R_OK),lf[286]);}

/* check in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2782(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2782,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2802 in check in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2798 in check in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2792,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2792(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2790 in k2798 in check in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-group-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2767,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2775 in set-group-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[279],lf[283],((C_word*)t0)[2]);}

/* set-user-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2752,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2762,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2760 in set-user-id! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[279],lf[280],((C_word*)t0)[2]);}

/* current-effective-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub359(C_SCHEME_UNDEFINED));}

/* current-effective-user-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub357(C_SCHEME_UNDEFINED));}

/* current-group-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub355(C_SCHEME_UNDEFINED));}

/* current-user-id in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub353(C_SCHEME_UNDEFINED));}

/* change-file-owner in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2710,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[268]);
t6=(C_word)C_i_check_exact_2(t3,lf[268]);
t7=(C_word)C_i_check_exact_2(t4,lf[268]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2734,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2738,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}

/* k2736 in change-file-owner in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2732 in change-file-owner in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[268],lf[269],(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2683,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2704,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2706 in change-file-mode in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2702 in change-file-mode in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[265],lf[266],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2635,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[239]);
t5=(C_word)C_i_check_exact_2(t3,lf[239]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_2623(2,t9,C_SCHEME_FALSE);}}

/* k2621 in initialize-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub324(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2649 in k2621 in initialize-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[239],lf[240],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2565,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_2491(t4);
if(C_truep(t5)){
t6=t3;
f_2565(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[234],lf[237]);}}

/* k2563 in set-groups! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2570,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[236],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2570(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do311 in k2563 in set-groups! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2570,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[234]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k2584 in do311 in k2563 in set-groups! in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[234],lf[235],((C_word*)t0)[2]);}

/* get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2498,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2556,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2502(2,t4,C_SCHEME_UNDEFINED);}}

/* k2554 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[228],lf[232]);}

/* k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_2491(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_2505(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[228],lf[231]);}}

/* k2503 in k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub293(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_2508(2,t5,C_SCHEME_UNDEFINED);}}

/* k2535 in k2503 in k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[228],lf[230]);}

/* k2506 in k2503 in k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2513,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[229],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2513(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2506 in k2503 in k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2513,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2527,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k2525 in loop in k2506 in k2503 in k2500 in get-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_2491(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub297(C_SCHEME_UNDEFINED,t2));}

/* group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2430,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2434(t4,(C_word)C_getgrgid(t2));}
else{
t4=(C_word)C_i_check_string_2(t2,lf[223]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k2480 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2434(t2,(C_word)C_getgrnam(t1));}

/* k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2434,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k2446 in k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2452,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t4,a[3]=lf[224],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2454(t6,t2,C_fix(0));}

/* rec in k2446 in k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub281(t5,t6);
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2456 in rec in k2446 in k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_2454(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k2466 in k2456 in rec in k2446 in k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2468,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2450 in k2446 in k2442 in k2432 in group-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(6,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2377,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2381,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2381(t4,(C_word)C_getpwuid(t2));}
else{
t4=(C_word)C_i_check_string_2(t2,lf[221]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k2415 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2381(t2,(C_word)C_getpwnam(t1));}

/* k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2381,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2389 in k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k2393 in k2389 in k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2399,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k2397 in k2393 in k2389 in k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2403,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k2401 in k2397 in k2393 in k2389 in k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2407,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k2405 in k2401 in k2397 in k2393 in k2389 in k2379 in user-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,7,((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2343(2,t3,C_SCHEME_UNDEFINED);}}

/* k2370 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[219]);}

/* k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k2348 in k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k2352 in k2348 in k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2358,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k2356 in k2352 in k2348 in k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2362,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k2360 in k2356 in k2352 in k2348 in k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2366,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k2364 in k2360 in k2356 in k2352 in k2348 in k2341 in system-information in k2335 in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(7,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-signal-mask! in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2312,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[212]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2330,a[2]=lf[215],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2329 in set-signal-mask! in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2330,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[212]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k2317 in set-signal-mask! in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask(C_fix(0)),C_fix(0)))){
t2=lf[5];
f_1163(t2,((C_word*)t0)[2],lf[213],lf[212],lf[214],C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2294,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2304,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2302 in ##sys#interrupt-hook in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[210]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2277 in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2281,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[208]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* create-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
t3=lf[5];
f_1163(t3,t2,lf[49],lf[179],lf[180],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2242(2,t3,C_SCHEME_UNDEFINED);}}

/* k2240 in create-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2218r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2218r(t0,t1,t2,t3,t4);}}

static void f_2218r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[176]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2222,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2220 in with-output-to-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
t2=C_mutate((C_word*)lf[176]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2228,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[177],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2227 in k2220 in with-output-to-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2228(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2228r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2228r(t0,t1,t2);}}

static void f_2228r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2232,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2230 in a2227 in k2220 in with-output-to-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[176]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2198r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2198r(t0,t1,t2,t3,t4);}}

static void f_2198r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[172]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2200 in with-input-from-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=C_mutate((C_word*)lf[172]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2208,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[173],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2207 in k2200 in with-input-from-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2208r(t0,t1,t2);}}

static void f_2208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2212,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2210 in a2207 in k2200 in with-input-from-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[172]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2174r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2174r(t0,t1,t2,t3,t4);}}

static void f_2174r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2178,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2176 in call-with-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2183,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[168],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2189,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[169],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2188 in k2176 in call-with-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2189r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2189r(t0,t1,t2);}}

static void f_2189r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2191 in a2188 in k2176 in call-with-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2182 in k2176 in call-with-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2150r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2150r(t0,t1,t2,t3,t4);}}

static void f_2150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2154,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2152 in call-with-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[164],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2165,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[165],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2164 in k2152 in call-with-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2165(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2165r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2165r(t0,t1,t2);}}

static void f_2165r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2169,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2167 in a2164 in k2152 in call-with-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2158 in k2152 in call-with-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2134,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2138,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[157]);}

/* k2136 in close-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2141,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=lf[5];
f_1163(t5,t3,lf[49],lf[158],lf[159],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t5=t3;
f_2141(2,t5,C_SCHEME_UNDEFINED);}}

/* k2139 in k2136 in close-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2098(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2098r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2098r(t0,t1,t2,t3);}}

static void f_2098r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[155]);
t5=f_2029(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2112,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[153]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
f_2041(t6,t5);}}}

/* k2127 in open-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2112(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2117 in open-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2112(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2110 in open-output-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2047(((C_word*)t0)[3],lf[155],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2062(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2062r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2062r(t0,t1,t2,t3);}}

static void f_2062r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_2029(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2076,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2083,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[153]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2093,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
f_2041(t6,t5);}}}

/* k2091 in open-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2076(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2081 in open-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2076(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2074 in open-input-pipe in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2047(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2047(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2047,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
t6=lf[5];
f_1163(t6,t1,lf[49],t2,lf[147],(C_word)C_a_i_list(&a,1,t3));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2060,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[148]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[149]+1),lf[150],lf[111]);}}

/* k2058 in check in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_2041(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,2,t1,t2);}
t3=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[145],t2);}

/* mode in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_2029(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* current-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1986(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1986r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1986r(t0,t1,t2);}}

static void f_1986r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1990(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1990(2,t5,(C_word)C_i_car(t2));}
else{
t5=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1988 in current-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k1997 in k1988 in current-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
t3=lf[5];
f_1163(t3,((C_word*)t0)[2],lf[49],lf[140],lf[141],C_SCHEME_END_OF_LIST);}}

/* directory? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1963,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[137]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1982 in directory? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1968 in directory? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1909,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[132]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_fix(256));}

/* k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[135]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[135]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1959 in k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1924 in k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=lf[5];
f_1163(t3,((C_word*)t0)[6],lf[49],lf[132],lf[133],(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=lf[134],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1940(t6,((C_word*)t0)[6]);}}

/* loop in k1924 in k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1940,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1948 in loop in k1924 in k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
f_1940(t3,t2);}

/* k1955 in k1948 in loop in k1924 in k1920 in k1917 in k1914 in directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1885,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[127]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1905 in delete-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1901 in delete-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[127],lf[128],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* change-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1861,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[124]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1881 in change-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1877 in change-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[124],lf[125],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* create-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1837,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[121]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1857 in create-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1853 in create-directory in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[5];
f_1163(t3,((C_word*)t0)[3],lf[49],lf[121],lf[122],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* set-file-position! in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1779r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1779r(t0,t1,t2,t3,t4);}}

static void f_1779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[115]);
t8=(C_word)C_i_check_exact_2(t6,lf[115]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[118],lf[115],lf[119],t3,t2);}
else{
t10=t9;
f_1792(2,t10,C_SCHEME_UNDEFINED);}}

/* k1790 in set-file-position! in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1802 in k1790 in set-file-position! in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[111]);
t4=((C_word*)t0)[4];
f_1798(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1798(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[115],lf[117],((C_word*)t0)[5]);}}}

/* k1796 in k1790 in set-file-position! in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=lf[5];
f_1163(t2,((C_word*)t0)[4],lf[49],lf[115],lf[116],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* file-position in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1758,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1756 in file-position in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[111]);
t4=((C_word*)t0)[2];
f_1746(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1746(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[109],lf[112],((C_word*)t0)[3]);}}}

/* k1744 in file-position in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1749,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=lf[5];
f_1163(t3,t2,lf[49],lf[109],lf[110],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=t2;
f_1749(2,t3,C_SCHEME_UNDEFINED);}}

/* k1747 in k1744 in file-position in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1733,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[107]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t4,t2,C_SCHEME_TRUE,lf[107]);}

/* k1738 in symbolic-link? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1724,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t4,t2,C_SCHEME_TRUE,lf[105]);}

/* k1729 in regular-file? in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1718,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[103]);}

/* k1720 in file-permissions in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[101]);}

/* k1714 in file-owner in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1706,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[99]);}

/* k1708 in file-change-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[97]);}

/* k1702 in file-access-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1694,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[95]);}

/* k1696 in file-modification-time in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1688,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1619(t3,t2,C_SCHEME_FALSE,lf[93]);}

/* k1690 in file-size in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1656(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1656r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1656r(t0,t1,t2,t3);}}

static void f_1656r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1667(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1667(2,t7,(C_word)C_i_car(t3));}
else{
t7=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k1665 in file-stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1619(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[90]);}

/* k1658 in file-stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime)));}

/* ##sys#stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1619(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1623,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_1623(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t6=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[88],t2);}}}

/* k1649 in ##sys#stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1642 in ##sys#stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1623(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k1621 in ##sys#stat in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[5];
f_1163(t2,((C_word*)t0)[4],lf[49],((C_word*)t0)[3],lf[87],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1427r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1427r(t0,t1,t2,t3,t4);}}

static void f_1427r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1401(C_fix(0));
t10=f_1401(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1443(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
t14=t12;
f_1443(2,t14,f_1407(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[75]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=lf[81],tmp=(C_word)a,a+=5,tmp);
t15=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a1599 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1600,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[75]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1407(C_fix(0),t2));}

/* k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1449(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
t5=t3;
f_1449(2,t5,f_1407(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[75]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[80],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a1573 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1574,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[75]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1407(C_fix(1),t2));}

/* k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[75]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1452(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1452(t4,(C_word)C_C_select(t3));}}

/* k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1452,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[5];
f_1163(t2,((C_word*)t0)[5],lf[49],lf[75],lf[76],(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
t4=t3;
f_1491(t4,f_1417(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1534,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=lf[79],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1491(t4,C_SCHEME_FALSE);}}}}

/* a1533 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1534,3,t0,t1,t2);}
t3=f_1417(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1530 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1491(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1489 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t3=t2;
f_1495(t3,f_1417(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1509,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=lf[77],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1495(t3,C_SCHEME_FALSE);}}

/* a1508 in k1489 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=f_1417(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1505 in k1489 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1495(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1493 in k1489 in k1450 in k1447 in k1441 in file-select in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_1417(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub74(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_1407(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub68(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_1401(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub63(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1374 in file-mkstemp in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1377 in k1374 in file-mkstemp in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=lf[5];
f_1163(t4,t2,lf[49],lf[68],lf[70],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t2;
f_1382(2,t4,C_SCHEME_UNDEFINED);}}

/* k1380 in k1377 in k1374 in file-mkstemp in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=*((C_word*)lf[69]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1387 in k1380 in k1377 in k1374 in file-mkstemp in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1330r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1330r(t0,t1,t2,t3,t4);}}

static void f_1330r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[63]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1337,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1337(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[63],lf[65],t3);}}

/* k1335 in file-write in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[63]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1346,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=lf[5];
f_1163(t8,t6,lf[49],lf[63],lf[64],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3));}
else{
t8=t6;
f_1346(2,t8,C_SCHEME_UNDEFINED);}}

/* k1344 in k1335 in file-write in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1288r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1288r(t0,t1,t2,t3,t4);}}

static void f_1288r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1298,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1298(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1296 in file-read in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1301(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k1299 in k1296 in file-read in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1304,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=lf[5];
f_1163(t5,t3,lf[49],lf[58],lf[59],(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t5=t3;
f_1304(2,t5,C_SCHEME_UNDEFINED);}}

/* k1302 in k1299 in k1296 in file-read in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1273,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[54]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=lf[5];
f_1163(t4,t1,lf[49],lf[54],lf[55],(C_word)C_a_i_list(&a,1,t2));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1235r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1235r(t0,t1,t2,t3,t4);}}

static void f_1235r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[48]);
t8=(C_word)C_i_check_exact_2(t3,lf[48]);
t9=(C_word)C_i_check_exact_2(t6,lf[48]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1252,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1265,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=*((C_word*)lf[52]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k1263 in file-open in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1250 in file-open in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1255,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=lf[5];
f_1163(t5,t3,lf[49],lf[48],lf[50],(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t5=t3;
f_1255(2,t5,C_SCHEME_UNDEFINED);}}

/* k1253 in k1250 in file-open in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* yield in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1180(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1180,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=lf[15],tmp=(C_word)a,a+=3,tmp);
C_call_cc(3,0,t1,t2);}

/* a1185 in yield in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1186,3,t0,t1,t2);}
t3=*((C_word*)lf[12]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1195,a[2]=t2,a[3]=lf[13],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t1);}

/* a1194 in a1185 in yield in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* posix-error in k1142 in k1139 in k1136 in k1133 in k1130 */
static void C_fcall f_1163(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1163,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1167,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1165 in posix-error in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub9(t4,t5);
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1176 in k1165 in posix-error in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1172 in k1165 in posix-error in k1142 in k1139 in k1136 in k1133 in k1130 */
static void f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* make-nonblocking in k1142 in k1139 in k1136 in k1133 in k1130 */
static C_word C_fcall f_1146(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub3(C_SCHEME_UNDEFINED,t2));}
/* end of file */
