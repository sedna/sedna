/* Generated from posixwin.scm by the Chicken compiler
   2005-09-10 23:32
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: posixwin.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file uposixwin.c -explicit-use
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>

#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX 256
#define PIPE_BUF 512

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;
/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

static C_TLS char C_hostname[256];
static C_TLS char C_osver[16];
static C_TLS char C_osrel[16];
static C_TLS char C_processor[16];

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR *opendir(const char *name);
static int closedir(DIR *dir);
static struct dirent *readdir(DIR *dir);

static DIR *opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}
static int closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}
static struct dirent *readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)   	(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name),	C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid            getpid
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d)           C_fix(_pipe(C_pipefds, PIPE_BUF, O_BINARY))
#define C_close(fd)         C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);				       
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}

static void C_fcall C_set_exec_arg(int i, char *a, int len);
void C_fcall C_set_exec_arg(int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  C_exec_args[ i ] = ptr;
}

static void C_fcall C_free_exec_args();
void C_fcall C_free_exec_args() {
  char **a = C_exec_args;
  while((*a) != NULL) C_free(*(a++));
}

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), C_exec_args))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )

/* mapping from Win32 error codes to errno */
typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;
static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,      EINVAL},
    {ERROR_FILE_NOT_FOUND,        ENOENT},
    {ERROR_PATH_NOT_FOUND,        ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,   EMFILE},
    {ERROR_ACCESS_DENIED,         EACCES},
    {ERROR_INVALID_HANDLE,        EBADF},
    {ERROR_ARENA_TRASHED,         ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,     ENOMEM},
    {ERROR_INVALID_BLOCK,         ENOMEM},
    {ERROR_BAD_ENVIRONMENT,       E2BIG},
    {ERROR_BAD_FORMAT,            ENOEXEC},
    {ERROR_INVALID_ACCESS,        EINVAL},
    {ERROR_INVALID_DATA,          EINVAL},
    {ERROR_INVALID_DRIVE,         ENOENT},
    {ERROR_CURRENT_DIRECTORY,     EACCES},
    {ERROR_NOT_SAME_DEVICE,       EXDEV},
    {ERROR_NO_MORE_FILES,         ENOENT},
    {ERROR_LOCK_VIOLATION,        EACCES},
    {ERROR_BAD_NETPATH,           ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,          ENOENT},
    {ERROR_FILE_EXISTS,           EEXIST},
    {ERROR_CANNOT_MAKE,           EACCES},
    {ERROR_FAIL_I24,              EACCES},
    {ERROR_INVALID_PARAMETER,     EINVAL},
    {ERROR_NO_PROC_SLOTS,         EAGAIN},
    {ERROR_DRIVE_LOCKED,          EACCES},
    {ERROR_BROKEN_PIPE,           EPIPE},
    {ERROR_DISK_FULL,             ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,        EINVAL},
    {ERROR_WAIT_NO_CHILDREN,      ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,    ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,         EINVAL},
    {ERROR_SEEK_ON_DEVICE,        EACCES},
    {ERROR_DIR_NOT_EMPTY,         ENOTEMPTY},
    {ERROR_NOT_LOCKED,            EACCES},
    {ERROR_BAD_PATHNAME,          ENOENT},
    {ERROR_MAX_THRDS_REACHED,     EAGAIN},
    {ERROR_LOCK_FAILED,           EACCES},
    {ERROR_ALREADY_EXISTS,        EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,   EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,      ENOMEM},
    {0, 0}
};

static void set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

/* functions for creating process with redirected I/O */
static int zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}
static int close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}
static int redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_errno(GetLastError());
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}
static int run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
    {
	set_errno(GetLastError());
	return 0;
    }
}
static int pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
    {
	set_errno(GetLastError());
	return 0;
    }
}
static int pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    set_errno(GetLastError());
    return 0;
}
static int pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else 
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

int process_wait(int h, int t)
{   
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    set_errno(GetLastError());
    return 0;
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

int get_hostname()
{
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
    {
	int nok = gethostname(C_hostname, 256);
	WSACleanup();
	return !nok;
    }
    return 0;
}

int sysinfo()
{
    OSVERSIONINFO ovf;
    ZeroMemory(&ovf, sizeof(ovf));
    ovf.dwOSVersionInfoSize = sizeof(ovf);
    if (get_hostname() && GetVersionEx(&ovf))
    {
	SYSTEM_INFO si;
	_snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d", 
			   ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	switch (ovf.dwPlatformId)
	{
	case VER_PLATFORM_WIN32s:
	    strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
	    break;
	case VER_PLATFORM_WIN32_WINDOWS:
	    strncpy(C_osrel, "Win9x", sizeof(C_osrel) - 1);
	    break;
	case VER_PLATFORM_WIN32_NT:
	default:
	    strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
	    break;
	}
	GetSystemInfo(&si);
	switch (si.wProcessorArchitecture)
	{
    	case PROCESSOR_ARCHITECTURE_INTEL:
	    strncpy(C_processor, "Intel", sizeof(C_processor) - 1);
	    break;
    	case PROCESSOR_ARCHITECTURE_UNKNOWN:
	default:
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    break;
	}
	return 1;
    }
    set_errno(GetLastError());
    return 0;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)


C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[243];


/* from close-handle in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall stub400(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub400(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from get-shell in k647 in k644 in k641 in k638 in k635 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub391(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub391(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
    char *ret = getenv("COMSPEC");
    if (ret)
	return (ret);
    else
    {
	OSVERSIONINFO ovf;
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (GetVersionEx(&ovf) && (ovf.dwPlatformId == VER_PLATFORM_WIN32_NT))
	    return ("cmd.exe");
	else
	    return ("command.com");
    }
C_return:
#undef return

return C_r;}

/* from current-process-id in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall stub389(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub389(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeargs */
static C_word C_fcall stub369(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub369(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k2202 */
static C_word C_fcall stub362(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub362(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub319(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub319(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k2062 */
static C_word C_fcall stub312(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub312(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub265(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub265(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from asctime */
static C_word C_fcall stub254(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub254(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub230(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub230(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

C_externexport void C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_637(C_word c,C_word t0,C_word t1) C_noret;
static void f_640(C_word c,C_word t0,C_word t1) C_noret;
static void f_643(C_word c,C_word t0,C_word t1) C_noret;
static void f_646(C_word c,C_word t0,C_word t1) C_noret;
static void f_649(C_word c,C_word t0,C_word t1) C_noret;
static void f_2562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2710(C_word t0,C_word t1) C_noret;
static void f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2705(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2687(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2695(C_word c,C_word t0,C_word t1,...) C_noret;
static void C_fcall f_2568(C_word t0,C_word t1) C_noret;
static void f_2675(C_word c,C_word t0,C_word t1) C_noret;
static void f_2578(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2599(C_word c,C_word t0,C_word t1) C_noret;
static void f_2661(C_word c,C_word t0,C_word t1) C_noret;
static void f_2668(C_word c,C_word t0,C_word t1) C_noret;
static void f_2655(C_word c,C_word t0,C_word t1) C_noret;
static void f_2614(C_word c,C_word t0,C_word t1) C_noret;
static void f_2645(C_word c,C_word t0,C_word t1) C_noret;
static void f_2631(C_word c,C_word t0,C_word t1) C_noret;
static void f_2643(C_word c,C_word t0,C_word t1) C_noret;
static void f_2639(C_word c,C_word t0,C_word t1) C_noret;
static void f_2626(C_word c,C_word t0,C_word t1) C_noret;
static void f_2624(C_word c,C_word t0,C_word t1) C_noret;
static void f_2679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2531(C_word c,C_word t0,C_word t1) C_noret;
static void f_2557(C_word c,C_word t0,C_word t1) C_noret;
static void f_2542(C_word c,C_word t0,C_word t1) C_noret;
static void f_2546(C_word c,C_word t0,C_word t1) C_noret;
static void f_2550(C_word c,C_word t0,C_word t1) C_noret;
static void f_2554(C_word c,C_word t0,C_word t1) C_noret;
static void f_2519(C_word c,C_word t0,C_word t1) C_noret;
static void f_2516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2477(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2477r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2496(C_word c,C_word t0,C_word t1) C_noret;
static void f_2329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2432(C_word t0,C_word t1) C_noret;
static void C_fcall f_2427(C_word t0,C_word t1) C_noret;
static void C_fcall f_2331(C_word t0,C_word t1) C_noret;
static void f_2423(C_word c,C_word t0,C_word t1) C_noret;
static void f_2338(C_word c,C_word t0,C_word t1) C_noret;
static void f_2410(C_word c,C_word t0,C_word t1) C_noret;
static void f_2413(C_word c,C_word t0,C_word t1) C_noret;
static void f_2416(C_word c,C_word t0,C_word t1) C_noret;
static void f_2403(C_word c,C_word t0,C_word t1) C_noret;
static void f_2400(C_word c,C_word t0,C_word t1) C_noret;
static void f_2376(C_word c,C_word t0,C_word t1) C_noret;
static void f_2351(C_word c,C_word t0,C_word t1) C_noret;
static void f_2370(C_word c,C_word t0,C_word t1) C_noret;
static void f_2357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2355(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2326(C_word t0);
static void f_2297(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2297r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2314(C_word c,C_word t0,C_word t1) C_noret;
static void f_2291(C_word c,C_word t0,C_word t1) C_noret;
static void f_2288(C_word c,C_word t0,C_word t1) C_noret;
static void f_2207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2207r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2214(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2255(C_word c,C_word t0,C_word t1) C_noret;
static void f_2236(C_word c,C_word t0,C_word t1) C_noret;
static void f_2239(C_word c,C_word t0,C_word t1) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2199(C_word t0,C_word t1,C_word t2);
static void f_2067(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2067r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2154(C_word t0,C_word t1) C_noret;
static void C_fcall f_2149(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2069(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2076(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2084(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2117(C_word c,C_word t0,C_word t1) C_noret;
static void f_2098(C_word c,C_word t0,C_word t1) C_noret;
static void f_2101(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2059(C_word t0,C_word t1,C_word t2);
static void f_1950(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1950r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1956(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_1981(C_word c,C_word t0,C_word t1) C_noret;
static void f_1988(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1990(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2007(C_word c,C_word t0,C_word t1) C_noret;
static void f_2017(C_word c,C_word t0,C_word t1) C_noret;
static void f_2021(C_word c,C_word t0,C_word t1) C_noret;
static void f_1971(C_word c,C_word t0,C_word t1) C_noret;
static void f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1904(C_word c,C_word t0,C_word t1) C_noret;
static void f_1878(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1878r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1882(C_word c,C_word t0,C_word t1) C_noret;
static void f_1848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1855(C_word c,C_word t0,C_word t1) C_noret;
static void f_1858(C_word c,C_word t0,C_word t1) C_noret;
static void f_1861(C_word c,C_word t0,C_word t1) C_noret;
static void f_1831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1835(C_word c,C_word t0,C_word t1) C_noret;
static void f_1838(C_word c,C_word t0,C_word t1) C_noret;
static void f_1820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1749(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1759(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1767(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1793(C_word c,C_word t0,C_word t1) C_noret;
static void f_1797(C_word c,C_word t0,C_word t1) C_noret;
static void f_1785(C_word c,C_word t0,C_word t1) C_noret;
static void f_1737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1742(C_word c,C_word t0,C_word t1) C_noret;
static void f_1726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1731(C_word c,C_word t0,C_word t1) C_noret;
static void f_1735(C_word c,C_word t0,C_word t1) C_noret;
static void f_1702(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1702r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1706(C_word t0,C_word t1) C_noret;
static void f_1715(C_word c,C_word t0,C_word t1) C_noret;
static void f_1709(C_word c,C_word t0,C_word t1) C_noret;
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1700(C_word c,C_word t0,C_word t1) C_noret;
static void f_1686(C_word c,C_word t0,C_word t1) C_noret;
static void f_1680(C_word c,C_word t0,C_word t1) C_noret;
static void f_1659(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1659r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1668(C_word c,C_word t0,C_word t1) C_noret;
static void f_1648(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1648r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1657(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1634(C_word c,C_word t0,C_word t1) C_noret;
static void f_1646(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1593(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1601(C_word c,C_word t0,C_word t1) C_noret;
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1551(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void f_1566(C_word c,C_word t0,C_word t1) C_noret;
static void f_1558(C_word c,C_word t0,C_word t1) C_noret;
static void f_1527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1549(C_word c,C_word t0,C_word t1) C_noret;
static void f_1545(C_word c,C_word t0,C_word t1) C_noret;
static void f_1537(C_word c,C_word t0,C_word t1) C_noret;
static void f_1471(C_word c,C_word t0,C_word t1) C_noret;
static void f_1484(C_word c,C_word t0,C_word t1) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1455(C_word c,C_word t0,C_word t1) C_noret;
static void f_1461(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1461r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1465(C_word c,C_word t0,C_word t1) C_noret;
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1431r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1435(C_word c,C_word t0,C_word t1) C_noret;
static void f_1441(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1441r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1445(C_word c,C_word t0,C_word t1) C_noret;
static void f_1407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1411(C_word c,C_word t0,C_word t1) C_noret;
static void f_1422(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1422r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1426(C_word c,C_word t0,C_word t1) C_noret;
static void f_1416(C_word c,C_word t0,C_word t1) C_noret;
static void f_1383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1387(C_word c,C_word t0,C_word t1) C_noret;
static void f_1398(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1398r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1402(C_word c,C_word t0,C_word t1) C_noret;
static void f_1392(C_word c,C_word t0,C_word t1) C_noret;
static void f_1367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1371(C_word c,C_word t0,C_word t1) C_noret;
static void f_1334(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1334r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1362(C_word c,C_word t0,C_word t1) C_noret;
static void f_1352(C_word c,C_word t0,C_word t1) C_noret;
static void f_1345(C_word c,C_word t0,C_word t1) C_noret;
static void f_1301(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1301r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1329(C_word c,C_word t0,C_word t1) C_noret;
static void f_1319(C_word c,C_word t0,C_word t1) C_noret;
static void f_1312(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1287(C_word c,C_word t0,C_word t1) C_noret;
static void f_1299(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1277(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1265(C_word t0);
static void f_1222(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1222r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1226(C_word t0,C_word t1) C_noret;
static void f_1235(C_word c,C_word t0,C_word t1) C_noret;
static void f_1238(C_word c,C_word t0,C_word t1) C_noret;
static void f_1202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1220(C_word c,C_word t0,C_word t1) C_noret;
static void f_1206(C_word c,C_word t0,C_word t1) C_noret;
static void f_1148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1152(C_word c,C_word t0,C_word t1) C_noret;
static void f_1155(C_word c,C_word t0,C_word t1) C_noret;
static void f_1158(C_word c,C_word t0,C_word t1) C_noret;
static void f_1200(C_word c,C_word t0,C_word t1) C_noret;
static void f_1162(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1179(C_word t0,C_word t1) C_noret;
static void f_1189(C_word c,C_word t0,C_word t1) C_noret;
static void f_1196(C_word c,C_word t0,C_word t1) C_noret;
static void f_1171(C_word c,C_word t0,C_word t1) C_noret;
static void f_1124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1146(C_word c,C_word t0,C_word t1) C_noret;
static void f_1142(C_word c,C_word t0,C_word t1) C_noret;
static void f_1134(C_word c,C_word t0,C_word t1) C_noret;
static void f_1100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1122(C_word c,C_word t0,C_word t1) C_noret;
static void f_1118(C_word c,C_word t0,C_word t1) C_noret;
static void f_1110(C_word c,C_word t0,C_word t1) C_noret;
static void f_1076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1098(C_word c,C_word t0,C_word t1) C_noret;
static void f_1094(C_word c,C_word t0,C_word t1) C_noret;
static void f_1086(C_word c,C_word t0,C_word t1) C_noret;
static void f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1021r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1028(C_word c,C_word t0,C_word t1) C_noret;
static void f_1043(C_word c,C_word t0,C_word t1) C_noret;
static void f_1034(C_word c,C_word t0,C_word t1) C_noret;
static void f_1037(C_word c,C_word t0,C_word t1) C_noret;
static void f_981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1000(C_word c,C_word t0,C_word t1) C_noret;
static void f_985(C_word c,C_word t0,C_word t1) C_noret;
static void f_994(C_word c,C_word t0,C_word t1) C_noret;
static void f_988(C_word c,C_word t0,C_word t1) C_noret;
static void f_978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_976(C_word c,C_word t0,C_word t1) C_noret;
static void f_962(C_word c,C_word t0,C_word t1) C_noret;
static void f_952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_956(C_word c,C_word t0,C_word t1) C_noret;
static void f_946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_950(C_word c,C_word t0,C_word t1) C_noret;
static void f_940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_944(C_word c,C_word t0,C_word t1) C_noret;
static void f_934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_938(C_word c,C_word t0,C_word t1) C_noret;
static void f_928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_932(C_word c,C_word t0,C_word t1) C_noret;
static void f_922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_926(C_word c,C_word t0,C_word t1) C_noret;
static void f_894(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_894r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_898(C_word t0,C_word t1) C_noret;
static void f_901(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_856(C_word t0,C_word t1) C_noret;
static void f_889(C_word c,C_word t0,C_word t1) C_noret;
static void f_885(C_word c,C_word t0,C_word t1) C_noret;
static void f_860(C_word c,C_word t0,C_word t1) C_noret;
static void f_869(C_word c,C_word t0,C_word t1) C_noret;
static void f_821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_825(C_word c,C_word t0,C_word t1) C_noret;
static void f_828(C_word c,C_word t0,C_word t1) C_noret;
static void f_848(C_word c,C_word t0,C_word t1) C_noret;
static void f_831(C_word c,C_word t0,C_word t1) C_noret;
static void f_838(C_word c,C_word t0,C_word t1) C_noret;
static void f_785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_789(C_word c,C_word t0,C_word t1) C_noret;
static void f_801(C_word c,C_word t0,C_word t1) C_noret;
static void f_795(C_word c,C_word t0,C_word t1) C_noret;
static void f_746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_746r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_750(C_word c,C_word t0,C_word t1) C_noret;
static void f_753(C_word c,C_word t0,C_word t1) C_noret;
static void f_765(C_word c,C_word t0,C_word t1) C_noret;
static void f_756(C_word c,C_word t0,C_word t1) C_noret;
static void f_731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_741(C_word c,C_word t0,C_word t1) C_noret;
static void f_699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_723(C_word c,C_word t0,C_word t1) C_noret;
static void f_707(C_word c,C_word t0,C_word t1) C_noret;
static void f_716(C_word c,C_word t0,C_word t1) C_noret;
static void f_710(C_word c,C_word t0,C_word t1) C_noret;
static void f_651(C_word c,C_word t0,C_word t1) C_noret;
static void f_657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_666(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_2710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2710(t0,t1);}

static void C_fcall trf_2705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2705(t0,t1,t2);}

static void C_fcall trf_2700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2700(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2700(t0,t1,t2,t3);}

static void C_fcall trf_2564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2564(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2564(t0,t1,t2,t3,t4);}

static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2568(t0,t1);}

static void C_fcall trf_2580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2580(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2580(t0,t1,t2,t3);}

static void C_fcall trf_2432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2432(t0,t1);}

static void C_fcall trf_2427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2427(t0,t1);}

static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2331(t0,t1);}

static void C_fcall trf_2222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2222(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2222(t0,t1,t2,t3);}

static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2154(t0,t1);}

static void C_fcall trf_2149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2149(t0,t1,t2);}

static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2069(t0,t1,t2);}

static void C_fcall trf_2084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2084(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2084(t0,t1,t2,t3);}

static void C_fcall trf_1956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1956(t0,t1,t2);}

static void C_fcall trf_1990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1990(t0,t1,t2);}

static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1755(t0,t1,t2);}

static void C_fcall trf_1767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1767(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1767(t0,t1,t2);}

static void C_fcall trf_1706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1706(t0,t1);}

static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1630(t0,t1,t2,t3);}

static void C_fcall trf_1593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1593(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1593(t0,t1,t2);}

static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1551(t0,t1,t2);}

static void C_fcall trf_1283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1283(t0,t1,t2,t3);}

static void C_fcall trf_1277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1277(t0,t1);}

static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1226(t0,t1);}

static void C_fcall trf_1179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1179(t0,t1);}

static void C_fcall trf_898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_898(t0,t1);}

static void C_fcall trf_856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_856(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1620)){
C_save(t1);
C_rereclaim2(1620*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,243);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_h_intern(&lf[3],18,"\003syscurrent-thread");
lf[4]=C_h_intern(&lf[4],12,"\003sysschedule");
lf[5]=C_h_intern(&lf[5],8,"pipe/buf");
lf[6]=C_h_intern(&lf[6],11,"open/rdonly");
lf[7]=C_h_intern(&lf[7],11,"open/wronly");
lf[8]=C_h_intern(&lf[8],9,"open/rdwr");
lf[9]=C_h_intern(&lf[9],9,"open/read");
lf[10]=C_h_intern(&lf[10],10,"open/write");
lf[11]=C_h_intern(&lf[11],10,"open/creat");
lf[12]=C_h_intern(&lf[12],11,"open/append");
lf[13]=C_h_intern(&lf[13],9,"open/excl");
lf[14]=C_h_intern(&lf[14],10,"open/trunc");
lf[15]=C_h_intern(&lf[15],11,"open/binary");
lf[16]=C_h_intern(&lf[16],9,"open/text");
lf[17]=C_h_intern(&lf[17],10,"perm/irusr");
lf[18]=C_h_intern(&lf[18],10,"perm/iwusr");
lf[19]=C_h_intern(&lf[19],10,"perm/ixusr");
lf[20]=C_h_intern(&lf[20],10,"perm/irgrp");
lf[21]=C_h_intern(&lf[21],10,"perm/iwgrp");
lf[22]=C_h_intern(&lf[22],10,"perm/ixgrp");
lf[23]=C_h_intern(&lf[23],10,"perm/iroth");
lf[24]=C_h_intern(&lf[24],10,"perm/iwoth");
lf[25]=C_h_intern(&lf[25],10,"perm/ixoth");
lf[26]=C_h_intern(&lf[26],10,"perm/irwxu");
lf[27]=C_h_intern(&lf[27],10,"perm/irwxg");
lf[28]=C_h_intern(&lf[28],10,"perm/irwxo");
lf[29]=C_h_intern(&lf[29],9,"file-open");
lf[30]=C_h_intern(&lf[30],15,"\003syssignal-hook");
lf[31]=C_h_intern(&lf[31],11,"\000file-error");
lf[32]=C_static_string(C_heaptop,17,"can not open file");
lf[33]=C_h_intern(&lf[33],16,"\003sysupdate-errno");
lf[34]=C_h_intern(&lf[34],17,"\003sysmake-c-string");
lf[35]=C_h_intern(&lf[35],20,"\003sysexpand-home-path");
lf[36]=C_h_intern(&lf[36],10,"file-close");
lf[37]=C_static_string(C_heaptop,18,"can not close file");
lf[38]=C_h_intern(&lf[38],11,"make-string");
lf[39]=C_h_intern(&lf[39],9,"file-read");
lf[40]=C_static_string(C_heaptop,22,"can not read from file");
lf[41]=C_h_intern(&lf[41],11,"\000type-error");
lf[42]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[43]=C_h_intern(&lf[43],10,"file-write");
lf[44]=C_static_string(C_heaptop,21,"can not write to file");
lf[45]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[46]=C_h_intern(&lf[46],13,"string-length");
lf[47]=C_h_intern(&lf[47],12,"file-mkstemp");
lf[48]=C_h_intern(&lf[48],13,"\003syssubstring");
lf[49]=C_static_string(C_heaptop,29,"can not create temporary file");
lf[50]=C_h_intern(&lf[50],8,"seek/set");
lf[51]=C_h_intern(&lf[51],8,"seek/end");
lf[52]=C_h_intern(&lf[52],8,"seek/cur");
lf[54]=C_static_string(C_heaptop,19,"can not access file");
lf[55]=C_static_string(C_heaptop,42,"bad argument type - not a fixnum or string");
lf[56]=C_h_intern(&lf[56],9,"file-stat");
lf[57]=C_h_intern(&lf[57],9,"file-size");
lf[58]=C_h_intern(&lf[58],22,"file-modification-time");
lf[59]=C_h_intern(&lf[59],16,"file-access-time");
lf[60]=C_h_intern(&lf[60],16,"file-change-time");
lf[61]=C_h_intern(&lf[61],10,"file-owner");
lf[62]=C_h_intern(&lf[62],16,"file-permissions");
lf[63]=C_h_intern(&lf[63],13,"regular-file\077");
lf[64]=C_h_intern(&lf[64],13,"\003sysfile-info");
lf[65]=C_h_intern(&lf[65],14,"symbolic-link\077");
lf[66]=C_h_intern(&lf[66],13,"file-position");
lf[67]=C_static_string(C_heaptop,38,"can not retrieve file position of port");
lf[68]=C_h_intern(&lf[68],6,"stream");
lf[69]=C_static_string(C_heaptop,12,"invalid file");
lf[70]=C_h_intern(&lf[70],5,"port\077");
lf[71]=C_h_intern(&lf[71],18,"set-file-position!");
lf[72]=C_static_string(C_heaptop,25,"can not set file position");
lf[73]=C_static_string(C_heaptop,12,"invalid file");
lf[74]=C_h_intern(&lf[74],13,"\000bounds-error");
lf[75]=C_static_string(C_heaptop,30,"invalid negative port position");
lf[76]=C_h_intern(&lf[76],16,"create-directory");
lf[77]=C_static_string(C_heaptop,24,"can not create directory");
lf[78]=C_h_intern(&lf[78],16,"change-directory");
lf[79]=C_static_string(C_heaptop,32,"can not change current directory");
lf[80]=C_h_intern(&lf[80],16,"delete-directory");
lf[81]=C_static_string(C_heaptop,24,"can not delete directory");
lf[82]=C_h_intern(&lf[82],13,"string-append");
lf[83]=C_h_intern(&lf[83],6,"string");
lf[84]=C_h_intern(&lf[84],9,"substring");
lf[85]=C_h_intern(&lf[85],9,"directory");
lf[86]=C_static_string(C_heaptop,22,"can not open directory");
lf[87]=C_h_intern(&lf[87],16,"\003sysmake-pointer");
lf[88]=C_h_intern(&lf[88],10,"directory\077");
lf[89]=C_h_intern(&lf[89],17,"current-directory");
lf[90]=C_static_string(C_heaptop,34,"can not retrieve current directory");
lf[91]=C_h_intern(&lf[91],5,"\000text");
lf[92]=C_h_intern(&lf[92],9,"\003syserror");
lf[93]=C_static_string(C_heaptop,35,"illegal input/output mode specifier");
lf[94]=C_static_string(C_heaptop,17,"can not open pipe");
lf[95]=C_h_intern(&lf[95],13,"\003sysmake-port");
lf[96]=C_h_intern(&lf[96],21,"\003sysstream-port-class");
lf[97]=C_static_string(C_heaptop,6,"(pipe)");
lf[98]=C_h_intern(&lf[98],15,"open-input-pipe");
lf[99]=C_h_intern(&lf[99],7,"\000binary");
lf[100]=C_h_intern(&lf[100],16,"open-output-pipe");
lf[101]=C_h_intern(&lf[101],16,"close-input-pipe");
lf[102]=C_static_string(C_heaptop,24,"error while closing pipe");
lf[103]=C_h_intern(&lf[103],17,"close-output-pipe");
lf[104]=C_h_intern(&lf[104],20,"call-with-input-pipe");
lf[105]=C_h_intern(&lf[105],21,"call-with-output-pipe");
lf[106]=C_h_intern(&lf[106],20,"with-input-from-pipe");
lf[107]=C_h_intern(&lf[107],18,"\003sysstandard-input");
lf[108]=C_h_intern(&lf[108],19,"with-output-to-pipe");
lf[109]=C_h_intern(&lf[109],19,"\003sysstandard-output");
lf[110]=C_h_intern(&lf[110],11,"create-pipe");
lf[111]=C_static_string(C_heaptop,19,"can not create pipe");
lf[112]=C_h_intern(&lf[112],10,"errno/perm");
lf[113]=C_h_intern(&lf[113],11,"errno/noent");
lf[114]=C_h_intern(&lf[114],10,"errno/srch");
lf[115]=C_h_intern(&lf[115],10,"errno/intr");
lf[116]=C_h_intern(&lf[116],8,"errno/io");
lf[117]=C_h_intern(&lf[117],12,"errno/noexec");
lf[118]=C_h_intern(&lf[118],10,"errno/badf");
lf[119]=C_h_intern(&lf[119],11,"errno/child");
lf[120]=C_h_intern(&lf[120],11,"errno/nomem");
lf[121]=C_h_intern(&lf[121],11,"errno/acces");
lf[122]=C_h_intern(&lf[122],11,"errno/fault");
lf[123]=C_h_intern(&lf[123],10,"errno/busy");
lf[124]=C_h_intern(&lf[124],11,"errno/exist");
lf[125]=C_h_intern(&lf[125],12,"errno/notdir");
lf[126]=C_h_intern(&lf[126],11,"errno/isdir");
lf[127]=C_h_intern(&lf[127],11,"errno/inval");
lf[128]=C_h_intern(&lf[128],11,"errno/mfile");
lf[129]=C_h_intern(&lf[129],11,"errno/nospc");
lf[130]=C_h_intern(&lf[130],11,"errno/spipe");
lf[131]=C_h_intern(&lf[131],10,"errno/pipe");
lf[132]=C_h_intern(&lf[132],11,"errno/again");
lf[133]=C_h_intern(&lf[133],10,"errno/rofs");
lf[134]=C_h_intern(&lf[134],10,"errno/nxio");
lf[135]=C_h_intern(&lf[135],10,"errno/2big");
lf[136]=C_h_intern(&lf[136],10,"errno/xdev");
lf[137]=C_h_intern(&lf[137],11,"errno/nodev");
lf[138]=C_h_intern(&lf[138],11,"errno/nfile");
lf[139]=C_h_intern(&lf[139],11,"errno/notty");
lf[140]=C_h_intern(&lf[140],10,"errno/fbig");
lf[141]=C_h_intern(&lf[141],11,"errno/mlink");
lf[142]=C_h_intern(&lf[142],9,"errno/dom");
lf[143]=C_h_intern(&lf[143],11,"errno/range");
lf[144]=C_h_intern(&lf[144],12,"errno/deadlk");
lf[145]=C_h_intern(&lf[145],17,"errno/nametoolong");
lf[146]=C_h_intern(&lf[146],11,"errno/nolck");
lf[147]=C_h_intern(&lf[147],11,"errno/nosys");
lf[148]=C_h_intern(&lf[148],14,"errno/notempty");
lf[149]=C_h_intern(&lf[149],11,"errno/ilseq");
lf[150]=C_h_intern(&lf[150],16,"change-file-mode");
lf[151]=C_static_string(C_heaptop,24,"can not change file mode");
lf[152]=C_h_intern(&lf[152],17,"file-read-access\077");
lf[153]=C_h_intern(&lf[153],18,"file-write-access\077");
lf[154]=C_h_intern(&lf[154],20,"file-execute-access\077");
lf[155]=C_h_intern(&lf[155],12,"fileno/stdin");
lf[156]=C_h_intern(&lf[156],13,"fileno/stdout");
lf[157]=C_h_intern(&lf[157],13,"fileno/stderr");
lf[158]=C_h_intern(&lf[158],7,"\000append");
lf[159]=C_static_string(C_heaptop,27,"invalid mode for input file");
lf[160]=C_static_string(C_heaptop,1,"a");
lf[161]=C_static_string(C_heaptop,21,"invalid mode argument");
lf[162]=C_static_string(C_heaptop,1,"r");
lf[163]=C_static_string(C_heaptop,1,"w");
lf[164]=C_static_string(C_heaptop,17,"can not open file");
lf[165]=C_static_string(C_heaptop,8,"(fdport)");
lf[166]=C_h_intern(&lf[166],16,"open-input-file*");
lf[167]=C_h_intern(&lf[167],17,"open-output-file*");
lf[168]=C_h_intern(&lf[168],12,"port->fileno");
lf[169]=C_static_string(C_heaptop,25,"port has no attached file");
lf[170]=C_static_string(C_heaptop,38,"can not access file-descriptor of port");
lf[171]=C_h_intern(&lf[171],25,"\003syspeek-unsigned-integer");
lf[172]=C_h_intern(&lf[172],16,"duplicate-fileno");
lf[173]=C_static_string(C_heaptop,33,"can not duplicate file descriptor");
lf[174]=C_h_intern(&lf[174],6,"setenv");
lf[175]=C_h_intern(&lf[175],8,"unsetenv");
lf[176]=C_h_intern(&lf[176],19,"current-environment");
lf[177]=C_h_intern(&lf[177],17,"\003syspeek-c-string");
lf[178]=C_h_intern(&lf[178],19,"seconds->local-time");
lf[179]=C_h_intern(&lf[179],18,"\003sysdecode-seconds");
lf[180]=C_h_intern(&lf[180],17,"seconds->utc-time");
lf[181]=C_h_intern(&lf[181],15,"seconds->string");
lf[182]=C_static_string(C_heaptop,33,"can not convert seconds to string");
lf[183]=C_h_intern(&lf[183],12,"time->string");
lf[184]=C_static_string(C_heaptop,29,"can not time vector to string");
lf[185]=C_static_string(C_heaptop,21,"time vector too short");
lf[186]=C_h_intern(&lf[186],5,"_exit");
lf[187]=C_h_intern(&lf[187],23,"\003syscleanup-before-exit");
lf[188]=C_h_intern(&lf[188],19,"set-buffering-mode!");
lf[189]=C_static_string(C_heaptop,26,"can not set buffering mode");
lf[190]=C_h_intern(&lf[190],5,"\000full");
lf[191]=C_h_intern(&lf[191],5,"\000line");
lf[192]=C_h_intern(&lf[192],5,"\000none");
lf[193]=C_static_string(C_heaptop,22,"invalid buffering-mode");
lf[194]=C_h_intern(&lf[194],12,"glob->regexp");
lf[195]=C_h_intern(&lf[195],13,"make-pathname");
lf[196]=C_h_intern(&lf[196],18,"decompose-pathname");
lf[197]=C_h_intern(&lf[197],4,"glob");
lf[198]=C_h_intern(&lf[198],12,"string-match");
lf[199]=C_static_string(C_heaptop,1,".");
lf[200]=C_static_string(C_heaptop,1,"*");
lf[201]=C_h_intern(&lf[201],13,"spawn/overlay");
lf[202]=C_h_intern(&lf[202],10,"spawn/wait");
lf[203]=C_h_intern(&lf[203],12,"spawn/nowait");
lf[204]=C_h_intern(&lf[204],13,"spawn/nowaito");
lf[205]=C_h_intern(&lf[205],12,"spawn/detach");
lf[206]=C_h_intern(&lf[206],24,"pathname-strip-directory");
lf[207]=C_h_intern(&lf[207],15,"process-execute");
lf[208]=C_static_string(C_heaptop,23,"can not execute process");
lf[209]=C_h_intern(&lf[209],13,"process-spawn");
lf[210]=C_static_string(C_heaptop,23,"can not execute process");
lf[211]=C_h_intern(&lf[211],18,"current-process-id");
lf[212]=C_h_intern(&lf[212],9,"get-shell");
lf[213]=C_h_intern(&lf[213],6,"getenv");
lf[214]=C_h_intern(&lf[214],11,"process-run");
lf[215]=C_static_string(C_heaptop,2,"/c");
lf[217]=C_h_intern(&lf[217],15,"make-input-port");
lf[218]=C_h_intern(&lf[218],16,"make-output-port");
lf[219]=C_h_intern(&lf[219],7,"process");
lf[220]=C_static_string(C_heaptop,23,"could not write to pipe");
lf[221]=C_static_string(C_heaptop,24,"could not read from pipe");
lf[222]=C_static_string(C_heaptop,24,"could not create process");
lf[223]=C_h_intern(&lf[223],14,"C_close_handle");
lf[224]=C_static_string(C_heaptop,4," /c ");
lf[225]=C_static_string(C_heaptop,1,"\000");
lf[226]=C_static_string(C_heaptop,22,"could not redirect I/O");
lf[227]=C_h_intern(&lf[227],12,"process-wait");
lf[228]=C_h_intern(&lf[228],5,"sleep");
lf[229]=C_h_intern(&lf[229],13,"get-host-name");
lf[230]=C_static_string(C_heaptop,26,"can not retrieve host-name");
lf[231]=C_h_intern(&lf[231],18,"system-information");
lf[232]=C_static_string(C_heaptop,7,"windows");
lf[233]=C_static_string(C_heaptop,35,"can not retrieve system-information");
lf[234]=C_h_intern(&lf[234],10,"find-files");
lf[235]=C_static_string(C_heaptop,1,".");
lf[236]=C_static_string(C_heaptop,2,"..");
lf[237]=C_static_string(C_heaptop,1,"*");
lf[238]=C_h_intern(&lf[238],16,"\003sysdynamic-wind");
lf[239]=C_h_intern(&lf[239],13,"pathname-file");
lf[240]=C_static_string(C_heaptop,1,"*");
lf[241]=C_h_intern(&lf[241],17,"register-feature!");
lf[242]=C_h_intern(&lf[242],5,"posix");
C_register_lf(lf,243);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k635 */
static void f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k638 in k635 */
static void f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k641 in k638 in k635 */
static void f_643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k644 in k641 in k638 in k635 */
static void f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 597  register-feature! */
t3=*((C_word*)lf[241]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[242]);}

/* k647 in k644 in k641 in k638 in k635 */
static void f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word ab[188],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_651,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[5]+1,C_fix((C_word)PIPE_BUF));
t4=C_mutate((C_word*)lf[6]+1,C_fix((C_word)O_RDONLY));
t5=C_mutate((C_word*)lf[7]+1,C_fix((C_word)O_WRONLY));
t6=C_mutate((C_word*)lf[8]+1,C_fix((C_word)O_RDWR));
t7=C_mutate((C_word*)lf[9]+1,C_fix((C_word)O_RDWR));
t8=C_mutate((C_word*)lf[10]+1,C_fix((C_word)O_WRONLY));
t9=C_mutate((C_word*)lf[11]+1,C_fix((C_word)O_CREAT));
t10=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_APPEND));
t11=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_EXCL));
t12=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_TRUNC));
t13=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_BINARY));
t14=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_TEXT));
t15=C_mutate((C_word*)lf[17]+1,C_fix((C_word)S_IREAD));
t16=C_mutate((C_word*)lf[18]+1,C_fix((C_word)S_IWRITE));
t17=C_mutate((C_word*)lf[19]+1,C_fix((C_word)S_IEXEC));
t18=C_mutate((C_word*)lf[20]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[21]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[22]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[23]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t25=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t26=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t27=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t28=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t27);
t29=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_731,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[38]+1);
t32=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_785,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[46]+1);
t35=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_821,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[50]+1,C_fix((C_word)SEEK_SET));
t37=C_mutate((C_word*)lf[51]+1,C_fix((C_word)SEEK_END));
t38=C_mutate((C_word*)lf[52]+1,C_fix((C_word)SEEK_CUR));
t39=C_mutate(&lf[53],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_856,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_894,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_922,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_928,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_934,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_940,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_946,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_952,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_958,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_978,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_981,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1021,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1076,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1100,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1124,tmp=(C_word)a,a+=2,tmp));
t54=*((C_word*)lf[82]+1);
t55=*((C_word*)lf[38]+1);
t56=*((C_word*)lf[83]+1);
t57=*((C_word*)lf[84]+1);
t58=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1148,a[2]=t55,a[3]=t57,tmp=(C_word)a,a+=4,tmp));
t59=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1202,tmp=(C_word)a,a+=2,tmp));
t60=*((C_word*)lf[38]+1);
t61=*((C_word*)lf[84]+1);
t62=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1222,a[2]=t60,a[3]=t61,tmp=(C_word)a,a+=4,tmp));
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1265,tmp=(C_word)a,a+=2,tmp);
t64=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1277,tmp=(C_word)a,a+=2,tmp);
t65=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1283,tmp=(C_word)a,a+=2,tmp);
t66=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1301,a[2]=t64,a[3]=t65,a[4]=t63,tmp=(C_word)a,a+=5,tmp));
t67=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1334,a[2]=t64,a[3]=t65,a[4]=t63,tmp=(C_word)a,a+=5,tmp));
t68=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1367,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[103]+1,*((C_word*)lf[101]+1));
t70=*((C_word*)lf[98]+1);
t71=*((C_word*)lf[100]+1);
t72=*((C_word*)lf[101]+1);
t73=*((C_word*)lf[103]+1);
t74=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=t70,a[3]=t72,tmp=(C_word)a,a+=4,tmp));
t75=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t71,a[3]=t73,tmp=(C_word)a,a+=4,tmp));
t76=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=t70,a[3]=t72,tmp=(C_word)a,a+=4,tmp));
t77=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=t71,a[3]=t73,tmp=(C_word)a,a+=4,tmp));
t78=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1471,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[112]+1,C_fix((C_word)EPERM));
t80=C_mutate((C_word*)lf[113]+1,C_fix((C_word)ENOENT));
t81=C_mutate((C_word*)lf[114]+1,C_fix((C_word)ESRCH));
t82=C_mutate((C_word*)lf[115]+1,C_fix((C_word)EINTR));
t83=C_mutate((C_word*)lf[116]+1,C_fix((C_word)EIO));
t84=C_mutate((C_word*)lf[117]+1,C_fix((C_word)ENOEXEC));
t85=C_mutate((C_word*)lf[118]+1,C_fix((C_word)EBADF));
t86=C_mutate((C_word*)lf[119]+1,C_fix((C_word)ECHILD));
t87=C_mutate((C_word*)lf[120]+1,C_fix((C_word)ENOMEM));
t88=C_mutate((C_word*)lf[121]+1,C_fix((C_word)EACCES));
t89=C_mutate((C_word*)lf[122]+1,C_fix((C_word)EFAULT));
t90=C_mutate((C_word*)lf[123]+1,C_fix((C_word)EBUSY));
t91=C_mutate((C_word*)lf[124]+1,C_fix((C_word)EEXIST));
t92=C_mutate((C_word*)lf[125]+1,C_fix((C_word)ENOTDIR));
t93=C_mutate((C_word*)lf[126]+1,C_fix((C_word)EISDIR));
t94=C_mutate((C_word*)lf[127]+1,C_fix((C_word)EINVAL));
t95=C_mutate((C_word*)lf[128]+1,C_fix((C_word)EMFILE));
t96=C_mutate((C_word*)lf[129]+1,C_fix((C_word)ENOSPC));
t97=C_mutate((C_word*)lf[130]+1,C_fix((C_word)ESPIPE));
t98=C_mutate((C_word*)lf[131]+1,C_fix((C_word)EPIPE));
t99=C_mutate((C_word*)lf[132]+1,C_fix((C_word)EAGAIN));
t100=C_mutate((C_word*)lf[133]+1,C_fix((C_word)EROFS));
t101=C_mutate((C_word*)lf[134]+1,C_fix((C_word)ENXIO));
t102=C_mutate((C_word*)lf[135]+1,C_fix((C_word)E2BIG));
t103=C_mutate((C_word*)lf[136]+1,C_fix((C_word)EXDEV));
t104=C_mutate((C_word*)lf[137]+1,C_fix((C_word)ENODEV));
t105=C_mutate((C_word*)lf[138]+1,C_fix((C_word)ENFILE));
t106=C_mutate((C_word*)lf[139]+1,C_fix((C_word)ENOTTY));
t107=C_mutate((C_word*)lf[140]+1,C_fix((C_word)EFBIG));
t108=C_mutate((C_word*)lf[141]+1,C_fix((C_word)EMLINK));
t109=C_mutate((C_word*)lf[142]+1,C_fix((C_word)EDOM));
t110=C_mutate((C_word*)lf[143]+1,C_fix((C_word)ERANGE));
t111=C_mutate((C_word*)lf[144]+1,C_fix((C_word)EDEADLK));
t112=C_mutate((C_word*)lf[145]+1,C_fix((C_word)ENAMETOOLONG));
t113=C_mutate((C_word*)lf[146]+1,C_fix((C_word)ENOLCK));
t114=C_mutate((C_word*)lf[147]+1,C_fix((C_word)ENOSYS));
t115=C_mutate((C_word*)lf[148]+1,C_fix((C_word)ENOTEMPTY));
t116=C_mutate((C_word*)lf[149]+1,C_fix((C_word)EILSEQ));
t117=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1527,tmp=(C_word)a,a+=2,tmp));
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1551,tmp=(C_word)a,a+=2,tmp);
t119=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=t118,tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=t118,tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=t118,tmp=(C_word)a,a+=3,tmp));
t122=C_mutate((C_word*)lf[155]+1,C_fix((C_word)0));
t123=C_mutate((C_word*)lf[156]+1,C_fix((C_word)1));
t124=C_mutate((C_word*)lf[157]+1,C_fix((C_word)2));
t125=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1593,tmp=(C_word)a,a+=2,tmp);
t126=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1630,tmp=(C_word)a,a+=2,tmp);
t127=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1648,a[2]=t125,a[3]=t126,tmp=(C_word)a,a+=4,tmp));
t128=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=t125,a[3]=t126,tmp=(C_word)a,a+=4,tmp));
t129=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1670,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1702,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1726,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1737,tmp=(C_word)a,a+=2,tmp));
t133=*((C_word*)lf[84]+1);
t134=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=t133,tmp=(C_word)a,a+=3,tmp));
t135=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1814,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[180]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1820,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1831,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[183]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1848,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[186]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1878,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1897,tmp=(C_word)a,a+=2,tmp));
t141=*((C_word*)lf[194]+1);
t142=*((C_word*)lf[85]+1);
t143=*((C_word*)lf[195]+1);
t144=*((C_word*)lf[196]+1);
t145=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1950,a[2]=t141,a[3]=t142,a[4]=t143,a[5]=t144,tmp=(C_word)a,a+=6,tmp));
t146=C_mutate((C_word*)lf[201]+1,C_fix((C_word)P_OVERLAY));
t147=C_mutate((C_word*)lf[202]+1,C_fix((C_word)P_WAIT));
t148=C_mutate((C_word*)lf[203]+1,C_fix((C_word)P_NOWAIT));
t149=C_mutate((C_word*)lf[204]+1,C_fix((C_word)P_NOWAITO));
t150=C_mutate((C_word*)lf[205]+1,C_fix((C_word)P_DETACH));
t151=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2059,tmp=(C_word)a,a+=2,tmp);
t152=*((C_word*)lf[206]+1);
t153=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2067,a[2]=t152,a[3]=t151,tmp=(C_word)a,a+=4,tmp));
t154=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2199,tmp=(C_word)a,a+=2,tmp);
t155=*((C_word*)lf[206]+1);
t156=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2207,a[2]=t155,a[3]=t154,tmp=(C_word)a,a+=4,tmp));
t157=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2288,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2291,tmp=(C_word)a,a+=2,tmp));
t159=*((C_word*)lf[209]+1);
t160=*((C_word*)lf[213]+1);
t161=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t159,tmp=(C_word)a,a+=3,tmp));
t162=C_mutate(&lf[216],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2326,tmp=(C_word)a,a+=2,tmp));
t163=*((C_word*)lf[217]+1);
t164=*((C_word*)lf[218]+1);
t165=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2329,a[2]=t163,a[3]=t164,tmp=(C_word)a,a+=4,tmp));
t166=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2477,tmp=(C_word)a,a+=2,tmp));
t167=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2516,tmp=(C_word)a,a+=2,tmp));
t168=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2519,tmp=(C_word)a,a+=2,tmp));
t169=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2531,tmp=(C_word)a,a+=2,tmp));
t170=*((C_word*)lf[197]+1);
t171=*((C_word*)lf[198]+1);
t172=*((C_word*)lf[195]+1);
t173=*((C_word*)lf[88]+1);
t174=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2562,a[2]=t173,a[3]=t172,a[4]=t170,a[5]=t171,tmp=(C_word)a,a+=6,tmp));
t175=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t175+1)))(2,t175,C_SCHEME_UNDEFINED);}

/* find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2562r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2562r(t0,t1,t2,t3,t4);}}

static void f_2562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2564,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action458489 */
t9=t8;
f_2710(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id459487 */
t11=t7;
f_2705(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit460484 */
t13=t6;
f_2700(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body456462 */
t15=t5;
f_2564(t15,t1,t9,t11,t13);}}}}

/* def-action458 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2710,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2716,tmp=(C_word)a,a+=2,tmp);
/* def-id459487 */
t3=((C_word*)t0)[2];
f_2705(t3,t1,t2);}

/* a2715 in def-action458 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2716,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id459 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2705,NULL,3,t0,t1,t2);}
/* def-limit460484 */
t3=((C_word*)t0)[2];
f_2700(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit460 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2700,NULL,4,t0,t1,t2,t3);}
/* body456462 */
t4=((C_word*)t0)[2];
f_2564(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2564,NULL,5,t0,t1,t2,t3,t4);}
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t6,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t8=t4;
if(C_truep(t8)){
t9=(C_word)C_fixnump(t4);
t10=t7;
f_2568(t10,(C_truep(t9)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2695,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t9=t7;
f_2568(t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2687,tmp=(C_word)a,a+=2,tmp));}}

/* f_2687 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2687(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_2695 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2695(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2675,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1429 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[240]);}

/* k2673 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1429 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2580(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2580,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1435 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1436 pathname-file */
t3=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1442 pproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k2659 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1442 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1443 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2580(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2666 in k2659 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2580(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[235]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[236]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 1436 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_2580(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1437 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1439 ##sys#dynamic-wind */
t11=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 1441 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2580(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a2644 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a2630 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2643,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1440 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[237]);}

/* k2641 in a2630 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1440 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2637 in a2630 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1440 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2580(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2625 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2622 in k2612 in k2653 in k2597 in loop in k2576 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1438 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2580(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_2679 in k2566 in body456 in find-files in k647 in k644 in k641 in k638 in k635 */
static void f_2679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2679,3,t0,t1,t2);}
/* posixwin.scm: 1427 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2542,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1404 ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2555 in system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1405 ##sys#error */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[231],lf[233]);}

/* k2540 in system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2546,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k2544 in k2540 in system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2550,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k2548 in k2544 in k2540 in system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k2552 in k2548 in k2544 in k2540 in system-information in k647 in k644 in k641 in k638 in k635 */
static void f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1402 values */
C_values(7,0,((C_word*)t0)[5],lf[232],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* get-host-name in k647 in k644 in k641 in k638 in k635 */
static void f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1397 ##sys#error */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[229],lf[230]);}}

/* sleep in k647 in k644 in k641 in k638 in k635 */
static void f_2516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2516,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k647 in k644 in k641 in k638 in k635 */
static void f_2477(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_2477r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2477r(t0,t1,t2,t3);}}

static void f_2477r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
if(C_truep((C_word)C_process_wait(t2,t5))){
/* posixwin.scm: 1378 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1380 ##sys#update-errno */
t9=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k2494 in process-wait in k647 in k644 in k641 in k638 in k635 */
static void f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1381 values */
C_values(5,0,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* process in k647 in k644 in k641 in k638 in k635 */
static void f_2329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2329r(t0,t1,t2,t3);}}

static void f_2329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2432,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args412430 */
t7=t6;
f_2432(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env413428 */
t9=t5;
f_2427(t9,t1);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body410415 */
t11=t4;
f_2331(t11,t1);}}}

/* def-args412 in process in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2432,NULL,2,t0,t1);}
/* def-env413428 */
t2=((C_word*)t0)[2];
f_2427(t2,t1);}

/* def-env413 in process in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2427,NULL,2,t0,t1);}
/* body410415 */
t2=((C_word*)t0)[2];
f_2331(t2,t1);}

/* body410 in process in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2331,NULL,2,t0,t1);}
if(C_truep((C_word)C_redir_io())){
t2=C_fix((C_word)C_wr0_);
t3=C_fix((C_word)C_rd1_);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1339 get-shell */
t6=*((C_word*)lf[212]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixwin.scm: 1370 ##sys#error */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[219],lf[226]);}}

/* k2421 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1339 string-append */
t2=*((C_word*)lf[82]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[224],((C_word*)t0)[2],lf[225]);}

/* k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(C_word)C_run_process(t1);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1343 make-input-port */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t5,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1365 ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2408 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1366 C_close_handle */
t3=*((C_word*)lf[223]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2411 in k2408 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1367 C_close_handle */
t3=*((C_word*)lf[223]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2414 in k2411 in k2408 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1368 ##sys#error */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[219],lf[222]);}

/* a2402 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
/* posixwin.scm: 1352 close-handle */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_2326(((C_word*)t0)[2]));}

/* a2399 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pipe_ready(((C_word*)t0)[2]));}

/* a2375 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(C_word)C_pipe_read(((C_word*)t0)[2]);
switch(t2){
case C_fix(-1):
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_FILE);
case C_fix(0):
/* posixwin.scm: 1347 ##sys#error */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[219],lf[221]);
default:
t3=(C_word)C_eqp(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_make_character((C_word)C_rdbuf):C_SCHEME_UNDEFINED));}}

/* k2349 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1356 make-output-port */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a2369 in k2349 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
/* posixwin.scm: 1361 close-handle */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_2326(((C_word*)t0)[2]));}

/* a2356 in k2349 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2357,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_pipe_write(((C_word*)t0)[2],t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1359 ##sys#error */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[219],lf[220]);}}

/* k2353 in k2349 in k2336 in body410 in process in k647 in k644 in k641 in k638 in k635 */
static void f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1342 values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* close-handle in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall f_2326(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub400(C_SCHEME_UNDEFINED,t1));}

/* process-run in k647 in k644 in k641 in k638 in k635 */
static void f_2297(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2297r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2297r(t0,t1,t2,t3);}}

static void f_2297r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1321 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[203]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1322 get-shell */
t7=*((C_word*)lf[212]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2312 in process-run in k647 in k644 in k641 in k638 in k635 */
static void f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[215],((C_word*)t0)[4]);
/* posixwin.scm: 1322 process-spawn */
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],*((C_word*)lf[203]+1),t1,t2);}

/* get-shell in k647 in k644 in k641 in k638 in k635 */
static void f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub391(t2),C_fix(0));}

/* current-process-id in k647 in k644 in k641 in k638 in k635 */
static void f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub389(C_SCHEME_UNDEFINED));}

/* process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2207r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2207r(t0,t1,t2,t3,t4);}}

static void f_2207r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2214,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1280 pathname-strip-directory */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}

/* k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_2199(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2222,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2222(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do376 in k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2222,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_2199(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1287 ##sys#expand-home-path */
t7=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_block_size(t4);
t6=f_2199(t3,t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t13=t1;
t14=t7;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k2253 in do376 in k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1287 ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2234 in do376 in k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(C_word)C_spawnvp(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1288 ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2237 in k2234 in do376 in k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub369(C_SCHEME_UNDEFINED);
/* posixwin.scm: 1291 ##sys#error */
t5=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[209],lf[210],((C_word*)t0)[2]);}
else{
t4=t2;
f_2242(2,t4,C_SCHEME_UNDEFINED);}}

/* k2240 in k2237 in k2234 in do376 in k2212 in process-spawn in k647 in k644 in k641 in k638 in k635 */
static void f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setarg in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall f_2199(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub362(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-execute in k647 in k644 in k641 in k638 in k635 */
static void f_2067(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2067r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2067r(t0,t1,t2,t3);}}

static void f_2067r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2154,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist328350 */
t7=t6;
f_2154(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist329348 */
t9=t5;
f_2149(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body326331 */
t11=t4;
f_2069(t11,t1,t7);}}}

/* def-arglist328 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2154,NULL,2,t0,t1);}
/* def-envlist329348 */
t2=((C_word*)t0)[2];
f_2149(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist329 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2149,NULL,3,t0,t1,t2);}
/* body326331 */
t3=((C_word*)t0)[2];
f_2069(t3,t1,t2);}

/* body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2069,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_car(t2):C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2076,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1256 pathname-strip-directory */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}

/* k2074 in body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_2059(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2084,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2084(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do336 in k2074 in body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_2084(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2084,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_2059(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1262 ##sys#expand-home-path */
t7=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_block_size(t4);
t6=f_2059(t3,t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t13=t1;
t14=t7;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k2115 in do336 in k2074 in body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1262 ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2096 in do336 in k2074 in body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(C_word)C_execvp(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1263 ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2099 in k2096 in do336 in k2074 in body326 in process-execute in k647 in k644 in k641 in k638 in k635 */
static void f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(-1));
if(C_truep(t2)){
t3=(C_word)stub319(C_SCHEME_UNDEFINED);
/* posixwin.scm: 1266 ##sys#error */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[207],lf[208],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* setarg in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall f_2059(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub312(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* glob in k647 in k644 in k641 in k638 in k635 */
static void f_1950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_1950r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1950r(t0,t1,t2);}}

static void f_1950r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1956(t6,t1,t2);}

/* conc in glob in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1956,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_1977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1977,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[200]);
/* posixwin.scm: 1226 make-pathname */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k2046 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1226 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:lf[199]);
/* posixwin.scm: 1227 directory */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k1986 in k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1990(t5,((C_word*)t0)[2],t1);}

/* loop in k1986 in k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1990,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* posixwin.scm: 1228 conc */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1956(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1229 string-match */
t5=*((C_word*)lf[198]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k2005 in loop in k1986 in k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2007,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixwin.scm: 1230 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixwin.scm: 1231 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1990(t3,((C_word*)t0)[6],t2);}}

/* k2015 in k2005 in loop in k1986 in k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1230 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1990(t4,t2,t3);}

/* k2019 in k2015 in k2005 in loop in k1986 in k1979 in a1976 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a1970 in conc in glob in k647 in k644 in k641 in k638 in k635 */
static void f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
/* posixwin.scm: 1225 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k647 in k644 in k641 in k638 in k635 */
static void f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1897r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1897r(t0,t1,t2,t3,t4);}}

static void f_1897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(5);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)BUFSIZ));
t7=t3;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1904,a[2]=t1,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(t7,lf[190]);
if(C_truep(t9)){
t10=t8;
f_1904(2,t10,C_fix((C_word)_IOFBF));}
else{
t10=(C_word)C_eqp(t7,lf[191]);
if(C_truep(t10)){
t11=t8;
f_1904(2,t11,C_fix((C_word)_IOLBF));}
else{
t11=(C_word)C_eqp(t7,lf[192]);
if(C_truep(t11)){
t12=t8;
f_1904(2,t12,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1205 ##sys#error */
t12=*((C_word*)lf[92]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t8,lf[188],lf[193],t3,t2);}}}}

/* k1902 in set-buffering-mode! in k647 in k644 in k641 in k638 in k635 */
static void f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[68],t2);
t4=(C_truep(t3)?(C_word)C_setvbuf(((C_word*)t0)[4],t1,((C_word*)t0)[3]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
/* posixwin.scm: 1211 ##sys#error */
t5=*((C_word*)lf[92]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[2],lf[188],lf[189],((C_word*)t0)[4],t1,((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* _exit in k647 in k644 in k641 in k638 in k635 */
static void f_1878(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1878r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1878r(t0,t1,t2);}}

static void f_1878r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1189 ##sys#cleanup-before-exit */
t4=*((C_word*)lf[187]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1880 in _exit in k647 in k644 in k641 in k638 in k635 */
static void f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_fix(0));
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub265(C_SCHEME_UNDEFINED,t3));}

/* time->string in k647 in k644 in k641 in k638 in k635 */
static void f_1848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1848,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[183]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1178 ##sys#error */
t6=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[183],lf[185],t2);}
else{
t6=t4;
f_1855(2,t6,C_SCHEME_UNDEFINED);}}

/* k1853 in time->string in k647 in k644 in k641 in k638 in k635 */
static void f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub254(t4,t3),C_fix(0));}

/* k1856 in k1853 in time->string in k647 in k644 in k641 in k638 in k635 */
static void f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_1861(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1180 ##sys#error */
t3=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[183],lf[184],((C_word*)t0)[2]);}}

/* k1859 in k1856 in k1853 in time->string in k647 in k644 in k641 in k638 in k635 */
static void f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->string in k647 in k644 in k641 in k638 in k635 */
static void f_1831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1831,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub245(t5,t4),C_fix(0));}

/* k1833 in seconds->string in k647 in k644 in k641 in k638 in k635 */
static void f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_1838(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1171 ##sys#error */
t3=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[181],lf[182],((C_word*)t0)[2]);}}

/* k1836 in k1833 in seconds->string in k647 in k644 in k641 in k638 in k635 */
static void f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->utc-time in k647 in k644 in k641 in k638 in k635 */
static void f_1820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1820,3,t0,t1,t2);}
/* posixwin.scm: 1165 ##sys#decode-seconds */
t3=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k647 in k644 in k641 in k638 in k635 */
static void f_1814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1814,3,t0,t1,t2);}
/* posixwin.scm: 1161 ##sys#decode-seconds */
t3=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k647 in k644 in k641 in k638 in k635 */
static void f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1755(t5,t1,C_fix(0));}

/* loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[177]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub230(t5,t4),C_fix(0));}

/* k1757 in loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1767,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1767(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k1757 in loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1767(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1767,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1153 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1154 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k1791 in scan in k1757 in loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1153 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k1795 in k1791 in scan in k1757 in loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1785,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1153 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1755(t5,t3,t4);}

/* k1783 in k1795 in k1791 in scan in k1757 in loop in current-environment in k647 in k644 in k641 in k638 in k635 */
static void f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k647 in k644 in k641 in k638 in k635 */
static void f_1737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1737,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1141 ##sys#make-c-string */
t4=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1740 in unsetenv in k647 in k644 in k641 in k638 in k635 */
static void f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k647 in k644 in k641 in k638 in k635 */
static void f_1726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1731,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1136 ##sys#make-c-string */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1729 in setenv in k647 in k644 in k641 in k638 in k635 */
static void f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1136 ##sys#make-c-string */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1733 in k1729 in setenv in k647 in k644 in k641 in k638 in k635 */
static void f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1702(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1702r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1702r(t0,t1,t2,t3);}}

static void f_1702r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t5=t4;
f_1706(t5,(C_word)C_dup(t2));}
else{
t5=(C_word)C_slot(t3,C_fix(0));
t6=t4;
f_1706(t6,(C_word)C_dup2(t2,t5));}}

/* k1704 in duplicate-fileno in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1706,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1126 ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1709(2,t3,C_SCHEME_UNDEFINED);}}

/* k1713 in k1704 in duplicate-fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1127 ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[172],lf[173],((C_word*)t0)[2]);}

/* k1707 in k1704 in duplicate-fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1109 ##sys#peek-unsigned-integer */
t4=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k1698 in port->fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1115 ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[41],lf[168],lf[169],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1112 ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_1680(2,t4,C_SCHEME_UNDEFINED);}}}

/* k1684 in k1698 in port->fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1113 ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[168],lf[170],((C_word*)t0)[2]);}

/* k1678 in k1698 in port->fileno in k647 in k644 in k641 in k638 in k635 */
static void f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k647 in k644 in k641 in k638 in k635 */
static void f_1659(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1659r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1659r(t0,t1,t2,t3);}}

static void f_1659r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1668,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1104 mode */
f_1593(t4,C_SCHEME_FALSE,t3);}

/* k1666 in open-output-file* in k647 in k644 in k641 in k638 in k635 */
static void f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1104 check */
f_1630(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k647 in k644 in k641 in k638 in k635 */
static void f_1648(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1648r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1648r(t0,t1,t2,t3);}}

static void f_1648r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1657,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1100 mode */
f_1593(t4,C_SCHEME_TRUE,t3);}

/* k1655 in open-input-file* in k647 in k644 in k641 in k638 in k635 */
static void f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1100 check */
f_1630(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1630(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1630,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1634,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1091 ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1632 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1093 ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[31],lf[164],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1094 ##sys#make-port */
t3=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[96]+1),lf[165],lf[68]);}}

/* k1644 in k1632 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1593(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1593,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[158]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1086 ##sys#error */
t8=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[159],t5);}
else{
t8=t4;
f_1601(2,t8,lf[160]);}}
else{
/* posixwin.scm: 1087 ##sys#error */
t7=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[161],t5);}}
else{
t5=t4;
f_1601(2,t5,(C_truep(t2)?lf[162]:lf[163]));}}

/* k1599 in mode in k647 in k644 in k641 in k638 in k635 */
static void f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1082 ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k647 in k644 in k641 in k638 in k635 */
static void f_1584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1584,3,t0,t1,t2);}
/* posixwin.scm: 1066 check */
f_1551(t1,t2,C_fix((C_word)2));}

/* file-write-access? in k647 in k644 in k641 in k638 in k635 */
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1578,3,t0,t1,t2);}
/* posixwin.scm: 1065 check */
f_1551(t1,t2,C_fix((C_word)4));}

/* file-read-access? in k647 in k644 in k641 in k638 in k635 */
static void f_1572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1572,3,t0,t1,t2);}
/* posixwin.scm: 1064 check */
f_1551(t1,t2,C_fix((C_word)2));}

/* check in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1551(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1570,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1061 ##sys#expand-home-path */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1568 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1061 ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1564 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1558(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1062 ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1556 in k1564 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k647 in k644 in k641 in k638 in k635 */
static void f_1527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1527,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1545,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1549,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1050 ##sys#expand-home-path */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1547 in change-file-mode in k647 in k644 in k641 in k638 in k635 */
static void f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1050 ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1543 in change-file-mode in k647 in k644 in k641 in k638 in k635 */
static void f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1051 ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1535 in k1543 in change-file-mode in k647 in k644 in k641 in k638 in k635 */
static void f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1052 ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[31],lf[150],lf[151],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 958  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1475(2,t3,C_SCHEME_UNDEFINED);}}

/* k1482 in create-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 959  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[31],lf[110],lf[111]);}

/* k1473 in create-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 960  values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1451r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1451r(t0,t1,t2,t3,t4);}}

static void f_1451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[109]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1455,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k1453 in with-output-to-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1461,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 943  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1460 in k1453 in with-output-to-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1461(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1461r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1461r(t0,t1,t2);}}

static void f_1461r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1465,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 945  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1463 in a1460 in k1453 in with-output-to-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[109]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1431r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1431r(t0,t1,t2,t3,t4);}}

static void f_1431r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[107]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1435,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k1433 in with-input-from-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1441,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 933  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1440 in k1433 in with-input-from-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1441(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1441r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1441r(t0,t1,t2);}}

static void f_1441r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1445,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 935  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1443 in a1440 in k1433 in with-input-from-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[107]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1407r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1407r(t0,t1,t2,t3,t4);}}

static void f_1407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1411,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1409 in call-with-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1422,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 923  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1421 in k1409 in call-with-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1422(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1422r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1422r(t0,t1,t2);}}

static void f_1422r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 926  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1424 in a1421 in k1409 in call-with-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1415 in k1409 in call-with-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1416,2,t0,t1);}
/* posixwin.scm: 924  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1383r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1383r(t0,t1,t2,t3,t4);}}

static void f_1383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1385 in call-with-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1392,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1398,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 915  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1397 in k1385 in call-with-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1398(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1398r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1398r(t0,t1,t2);}}

static void f_1398r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 918  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1400 in a1397 in k1385 in call-with-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1391 in k1385 in call-with-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
/* posixwin.scm: 916  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1367,3,t0,t1,t2);}
t3=(C_word)close_pipe(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1371,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 904  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1369 in close-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 905  ##sys#signal-hook */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[31],lf[101],lf[102],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1334(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1334r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1334r(t0,t1,t2,t3);}}

static void f_1334r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t4=f_1265(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1345,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 897  ##sys#make-c-string */
t8=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(C_word)C_eqp(t4,lf[99]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 898  ##sys#make-c-string */
t9=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
/* posixwin.scm: 899  badmode */
f_1277(t5,t4);}}}

/* k1360 in open-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1362,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1345(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1350 in open-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1345(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1343 in open-output-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 894  check */
f_1283(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1301(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1301r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1301r(t0,t1,t2,t3);}}

static void f_1301r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t4=f_1265(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1312,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 887  ##sys#make-c-string */
t8=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(C_word)C_eqp(t4,lf[99]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 888  ##sys#make-c-string */
t9=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
/* posixwin.scm: 889  badmode */
f_1277(t5,t4);}}}

/* k1327 in open-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1312(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1317 in open-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1312(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1310 in open-input-pipe in k647 in k644 in k641 in k638 in k635 */
static void f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 884  check */
f_1283(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1283(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1283,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1287,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 874  ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1285 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 876  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[31],lf[94],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 877  ##sys#make-port */
t3=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[96]+1),lf[97],lf[68]);}}

/* k1297 in k1285 in check in k647 in k644 in k641 in k638 in k635 */
static void f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1277(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1277,NULL,2,t1,t2);}
/* posixwin.scm: 872  ##sys#error */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[93],t2);}

/* mode in k647 in k644 in k641 in k638 in k635 */
static C_word C_fcall f_1265(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[91]));}

/* current-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1222(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1222r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1222r(t0,t1,t2);}}

static void f_1222r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1226(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_1226(t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}

/* k1224 in current-directory in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1226,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 859  change-directory */
t2=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 860  make-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}}

/* k1233 in k1224 in current-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1238,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 862  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1236 in k1233 in k1224 in current-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 864  substring */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[5]);}
else{
/* posixwin.scm: 865  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[31],lf[89],lf[90]);}}

/* directory? in k647 in k644 in k641 in k638 in k635 */
static void f_1202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 851  ##sys#expand-home-path */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1218 in directory? in k647 in k644 in k641 in k638 in k635 */
static void f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 851  ##sys#file-info */
t2=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1204 in directory? in k647 in k644 in k641 in k638 in k635 */
static void f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k647 in k644 in k641 in k638 in k635 */
static void f_1148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 831  make-string */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(256));}

/* k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 832  ##sys#make-pointer */
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 833  ##sys#make-pointer */
t3=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 834  ##sys#expand-home-path */
t4=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1198 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 834  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1160 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 837  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1179(t6,((C_word*)t0)[6]);}}

/* loop in k1160 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_1179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1179,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 846  substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1187 in loop in k1160 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1196,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 847  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1179(t3,t2);}

/* k1194 in k1187 in loop in k1160 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1169 in k1160 in k1156 in k1153 in k1150 in directory in k647 in k644 in k641 in k638 in k635 */
static void f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 838  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[85],lf[86],((C_word*)t0)[2]);}

/* delete-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 820  ##sys#expand-home-path */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1144 in delete-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 820  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1140 in delete-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 821  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1132 in k1140 in delete-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 822  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[80],lf[81],((C_word*)t0)[2]);}

/* change-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1118,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1122,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 813  ##sys#expand-home-path */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1120 in change-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 813  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1116 in change-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 814  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1108 in k1116 in change-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 815  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[78],lf[79],((C_word*)t0)[2]);}

/* create-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1076,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1094,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1098,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 806  ##sys#expand-home-path */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1096 in create-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 806  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1092 in create-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 807  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1084 in k1092 in create-directory in k647 in k644 in k641 in k638 in k635 */
static void f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 808  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[76],lf[77],((C_word*)t0)[2]);}

/* set-file-position! in k647 in k644 in k641 in k638 in k635 */
static void f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1021r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1021r(t0,t1,t2,t3,t4);}}

static void f_1021r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1028,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 791  ##sys#signal-hook */
t8=*((C_word*)lf[30]+1);
((C_proc7)(void*)(*((C_word*)t8+1)))(7,t8,t7,lf[74],lf[71],lf[75],t3,t2);}
else{
t8=t7;
f_1028(2,t8,C_SCHEME_UNDEFINED);}}

/* k1026 in set-file-position! in k647 in k644 in k641 in k638 in k635 */
static void f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 792  port? */
t4=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1041 in k1026 in set-file-position! in k647 in k644 in k641 in k638 in k635 */
static void f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[68]);
t4=((C_word*)t0)[4];
f_1034(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1034(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 796  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[41],lf[71],lf[73],((C_word*)t0)[5]);}}}

/* k1032 in k1026 in set-file-position! in k647 in k644 in k641 in k638 in k635 */
static void f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 797  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1035 in k1032 in k1026 in set-file-position! in k647 in k644 in k641 in k638 in k635 */
static void f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 798  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[31],lf[71],lf[72],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k647 in k644 in k641 in k638 in k635 */
static void f_981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_981,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1000,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 775  port? */
t5=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k998 in file-position in k647 in k644 in k641 in k638 in k635 */
static void f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[68]);
t4=((C_word*)t0)[2];
f_985(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_985(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 780  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[41],lf[66],lf[69],((C_word*)t0)[3]);}}}

/* k983 in file-position in k647 in k644 in k641 in k638 in k635 */
static void f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_988,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 782  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_988(2,t3,C_SCHEME_UNDEFINED);}}

/* k992 in k983 in file-position in k647 in k644 in k641 in k638 in k635 */
static void f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 783  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[66],lf[67],((C_word*)t0)[2]);}

/* k986 in k983 in file-position in k647 in k644 in k641 in k638 in k635 */
static void f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k647 in k644 in k641 in k638 in k635 */
static void f_978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_978,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* regular-file? in k647 in k644 in k641 in k638 in k635 */
static void f_958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_958,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 766  ##sys#expand-home-path */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k974 in regular-file? in k647 in k644 in k641 in k638 in k635 */
static void f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 766  ##sys#file-info */
t2=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k960 in regular-file? in k647 in k644 in k641 in k638 in k635 */
static void f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k647 in k644 in k641 in k638 in k635 */
static void f_952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_952,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 762  ##sys#stat */
f_856(t3,t2);}

/* k954 in file-permissions in k647 in k644 in k641 in k638 in k635 */
static void f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k647 in k644 in k641 in k638 in k635 */
static void f_946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 761  ##sys#stat */
f_856(t3,t2);}

/* k948 in file-owner in k647 in k644 in k641 in k638 in k635 */
static void f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k647 in k644 in k641 in k638 in k635 */
static void f_940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_940,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 760  ##sys#stat */
f_856(t3,t2);}

/* k942 in file-change-time in k647 in k644 in k641 in k638 in k635 */
static void f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k647 in k644 in k641 in k638 in k635 */
static void f_934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_934,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 759  ##sys#stat */
f_856(t3,t2);}

/* k936 in file-access-time in k647 in k644 in k641 in k638 in k635 */
static void f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k647 in k644 in k641 in k638 in k635 */
static void f_928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 758  ##sys#stat */
f_856(t3,t2);}

/* k930 in file-modification-time in k647 in k644 in k641 in k638 in k635 */
static void f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k647 in k644 in k641 in k638 in k635 */
static void f_922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_922,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_926,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 757  ##sys#stat */
f_856(t3,t2);}

/* k924 in file-size in k647 in k644 in k641 in k638 in k635 */
static void f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k647 in k644 in k641 in k638 in k635 */
static void f_894(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_894r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_894r(t0,t1,t2,t3);}}

static void f_894r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_898,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_898(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_898(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k896 in file-stat in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_898,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 752  ##sys#stat */
f_856(t2,((C_word*)t0)[2]);}

/* k899 in k896 in file-stat in k647 in k644 in k641 in k638 in k635 */
static void f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime)));}

/* ##sys#stat in k647 in k644 in k641 in k638 in k635 */
static void C_fcall f_856(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_856,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_860,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_860(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_885,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 745  ##sys#expand-home-path */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 746  ##sys#signal-hook */
t4=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[41],lf[55],t2);}}}

/* k887 in ##sys#stat in k647 in k644 in k641 in k638 in k635 */
static void f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 745  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k883 in ##sys#stat in k647 in k644 in k641 in k638 in k635 */
static void f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_860(2,t2,(C_word)C_stat(t1));}

/* k858 in ##sys#stat in k647 in k644 in k641 in k638 in k635 */
static void f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 748  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k867 in k858 in ##sys#stat in k647 in k644 in k641 in k638 in k635 */
static void f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 749  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[31],lf[54],((C_word*)t0)[2]);}

/* file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 714  ##sys#make-c-string */
t4=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k823 in file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 716  string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k826 in k823 in file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_848,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 718  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_831(2,t4,C_SCHEME_UNDEFINED);}}

/* k846 in k826 in k823 in file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 719  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[47],lf[49],((C_word*)t0)[2]);}

/* k829 in k826 in k823 in file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 720  ##sys#substring */
t4=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k836 in k829 in k826 in k823 in file-mkstemp in k647 in k644 in k641 in k638 in k635 */
static void f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 720  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k647 in k644 in k641 in k638 in k635 */
static void f_785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_785r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_785r(t0,t1,t2,t3,t4);}}

static void f_785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_789,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_789(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 701  ##sys#signal-hook */
t7=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[41],lf[43],lf[45],t3);}}

/* k787 in file-write in k647 in k644 in k641 in k638 in k635 */
static void f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_789,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_795,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_801,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 706  ##sys#update-errno */
t8=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_795(2,t7,C_SCHEME_UNDEFINED);}}

/* k799 in k787 in file-write in k647 in k644 in k641 in k638 in k635 */
static void f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 707  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[31],lf[43],lf[44],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k793 in k787 in file-write in k647 in k644 in k641 in k638 in k635 */
static void f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k647 in k644 in k641 in k638 in k635 */
static void f_746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_746r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_746r(t0,t1,t2,t3,t4);}}

static void f_746r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_750,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t6=t5;
f_750(2,t6,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 688  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k748 in file-read in k647 in k644 in k641 in k638 in k635 */
static void f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_753(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 690  ##sys#signal-hook */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[41],lf[39],lf[42],t1);}}

/* k751 in k748 in file-read in k647 in k644 in k641 in k638 in k635 */
static void f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_756,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 693  ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_756(2,t5,C_SCHEME_UNDEFINED);}}

/* k763 in k751 in k748 in file-read in k647 in k644 in k641 in k638 in k635 */
static void f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 694  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[31],lf[39],lf[40],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k754 in k751 in k748 in file-read in k647 in k644 in k641 in k638 in k635 */
static void f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k647 in k644 in k641 in k638 in k635 */
static void f_731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_731,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_741,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 680  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k739 in file-close in k647 in k644 in k641 in k638 in k635 */
static void f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 681  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[36],lf[37],((C_word*)t0)[2]);}

/* file-open in k647 in k644 in k641 in k638 in k635 */
static void f_699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_699r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_699r(t0,t1,t2,t3,t4);}}

static void f_699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_707,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 670  ##sys#expand-home-path */
t9=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k721 in file-open in k647 in k644 in k641 in k638 in k635 */
static void f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 670  ##sys#make-c-string */
t2=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k705 in file-open in k647 in k644 in k641 in k638 in k635 */
static void f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_707,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_716,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 672  ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_710(2,t5,C_SCHEME_UNDEFINED);}}

/* k714 in k705 in file-open in k647 in k644 in k641 in k638 in k635 */
static void f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 673  ##sys#signal-hook */
t2=*((C_word*)lf[30]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[31],lf[29],lf[32],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k708 in k705 in file-open in k647 in k644 in k641 in k638 in k635 */
static void f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* yield in k647 in k644 in k641 in k638 in k635 */
static void f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_657,tmp=(C_word)a,a+=2,tmp);
/* posixwin.scm: 602  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a656 in yield in k647 in k644 in k641 in k638 in k635 */
static void f_657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_657,3,t0,t1,t2);}
t3=*((C_word*)lf[3]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* posixwin.scm: 606  ##sys#schedule */
t6=*((C_word*)lf[4]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a665 in a656 in yield in k647 in k644 in k641 in k638 in k635 */
static void f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_666,2,t0,t1);}
/* posixwin.scm: 605  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}
/* end of file */
