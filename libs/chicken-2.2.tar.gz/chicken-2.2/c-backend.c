/* Generated from c-backend.scm by the Chicken compiler
   2005-09-24 22:28
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file c-backend.c -explicit-use
   unit: backend
*/

#include "chicken.h"


static C_TLS C_word lf[901];


C_externexport void C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_8701(C_word c,C_word t0,C_word t1) C_noret;
static void f_8705(C_word c,C_word t0,C_word t1) C_noret;
static void f_8697(C_word c,C_word t0,C_word t1) C_noret;
static void f_1088(C_word c,C_word t0,C_word t1) C_noret;
static void f_7990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8071(C_word t0,C_word t1) C_noret;
static void f_8137(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8572(C_word t0,C_word t1) C_noret;
static void C_fcall f_8514(C_word t0,C_word t1) C_noret;
static void C_fcall f_8478(C_word t0,C_word t1) C_noret;
static void C_fcall f_8443(C_word t0,C_word t1) C_noret;
static void C_fcall f_8395(C_word t0,C_word t1) C_noret;
static void C_fcall f_8347(C_word t0,C_word t1) C_noret;
static void C_fcall f_8299(C_word t0,C_word t1) C_noret;
static void C_fcall f_8264(C_word t0,C_word t1) C_noret;
static void C_fcall f_8228(C_word t0,C_word t1) C_noret;
static void C_fcall f_8192(C_word t0,C_word t1) C_noret;
static void C_fcall f_8170(C_word t0,C_word t1) C_noret;
static void C_fcall f_8165(C_word t0,C_word t1) C_noret;
static void C_fcall f_8160(C_word t0,C_word t1) C_noret;
static void C_fcall f_7992(C_word t0,C_word t1) C_noret;
static void f_7217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7247(C_word t0,C_word t1) C_noret;
static void C_fcall f_7274(C_word t0,C_word t1) C_noret;
static void C_fcall f_7448(C_word t0,C_word t1) C_noret;
static void f_7457(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7845(C_word t0,C_word t1) C_noret;
static void C_fcall f_7812(C_word t0,C_word t1) C_noret;
static void f_7822(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7780(C_word t0,C_word t1) C_noret;
static void C_fcall f_7745(C_word t0,C_word t1) C_noret;
static void C_fcall f_7675(C_word t0,C_word t1) C_noret;
static void C_fcall f_7630(C_word t0,C_word t1) C_noret;
static void C_fcall f_7598(C_word t0,C_word t1) C_noret;
static void C_fcall f_7566(C_word t0,C_word t1) C_noret;
static void C_fcall f_7534(C_word t0,C_word t1) C_noret;
static void C_fcall f_7502(C_word t0,C_word t1) C_noret;
static void C_fcall f_7480(C_word t0,C_word t1) C_noret;
static void C_fcall f_7219(C_word t0,C_word t1) C_noret;
static void f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6158(C_word t0,C_word t1) C_noret;
static void C_fcall f_6236(C_word t0,C_word t1) C_noret;
static void C_fcall f_6248(C_word t0,C_word t1) C_noret;
static void C_fcall f_6344(C_word t0,C_word t1) C_noret;
static void f_6359(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6964(C_word t0,C_word t1) C_noret;
static void f_6980(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6984(C_word t0,C_word t1) C_noret;
static void f_6997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6995(C_word c,C_word t0,C_word t1) C_noret;
static void f_6991(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6918(C_word t0,C_word t1) C_noret;
static void f_6931(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6868(C_word t0,C_word t1) C_noret;
static void C_fcall f_6818(C_word t0,C_word t1) C_noret;
static void C_fcall f_6783(C_word t0,C_word t1) C_noret;
static void C_fcall f_6748(C_word t0,C_word t1) C_noret;
static void C_fcall f_6713(C_word t0,C_word t1) C_noret;
static void C_fcall f_6674(C_word t0,C_word t1) C_noret;
static void f_6684(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6614(C_word t0,C_word t1) C_noret;
static void f_6631(C_word c,C_word t0,C_word t1) C_noret;
static void f_6641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6639(C_word c,C_word t0,C_word t1) C_noret;
static void f_6635(C_word c,C_word t0,C_word t1) C_noret;
static void f_6627(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6575(C_word t0,C_word t1) C_noret;
static void f_6585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6539(C_word t0,C_word t1) C_noret;
static void C_fcall f_6503(C_word t0,C_word t1) C_noret;
static void C_fcall f_6467(C_word t0,C_word t1) C_noret;
static void C_fcall f_6431(C_word t0,C_word t1) C_noret;
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6413(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6404(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6391(C_word t0,C_word t1) C_noret;
static void C_fcall f_6103(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6098(C_word t0,C_word t1) C_noret;
static void f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6035(C_word c,C_word t0,C_word t1) C_noret;
static void f_6038(C_word c,C_word t0,C_word t1) C_noret;
static void f_6041(C_word c,C_word t0,C_word t1) C_noret;
static void f_6044(C_word c,C_word t0,C_word t1) C_noret;
static void f_6050(C_word c,C_word t0,C_word t1) C_noret;
static void f_6094(C_word c,C_word t0,C_word t1) C_noret;
static void f_6053(C_word c,C_word t0,C_word t1) C_noret;
static void f_6061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6082(C_word c,C_word t0,C_word t1) C_noret;
static void f_6065(C_word c,C_word t0,C_word t1) C_noret;
static void f_6056(C_word c,C_word t0,C_word t1) C_noret;
static void f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5688(C_word c,C_word t0,C_word t1) C_noret;
static void f_5691(C_word c,C_word t0,C_word t1) C_noret;
static void f_5694(C_word c,C_word t0,C_word t1) C_noret;
static void f_5697(C_word c,C_word t0,C_word t1) C_noret;
static void f_5703(C_word c,C_word t0,C_word t1) C_noret;
static void f_5966(C_word c,C_word t0,C_word t1) C_noret;
static void f_5969(C_word c,C_word t0,C_word t1) C_noret;
static void f_6029(C_word c,C_word t0,C_word t1) C_noret;
static void f_5972(C_word c,C_word t0,C_word t1) C_noret;
static void f_5975(C_word c,C_word t0,C_word t1) C_noret;
static void f_5978(C_word c,C_word t0,C_word t1) C_noret;
static void f_5981(C_word c,C_word t0,C_word t1) C_noret;
static void f_6014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6022(C_word c,C_word t0,C_word t1) C_noret;
static void f_5984(C_word c,C_word t0,C_word t1) C_noret;
static void f_6012(C_word c,C_word t0,C_word t1) C_noret;
static void f_5987(C_word c,C_word t0,C_word t1) C_noret;
static void f_5990(C_word c,C_word t0,C_word t1) C_noret;
static void f_5993(C_word c,C_word t0,C_word t1) C_noret;
static void f_5705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_5715(C_word t0,C_word t1) C_noret;
static void C_fcall f_5724(C_word t0,C_word t1) C_noret;
static void C_fcall f_5748(C_word t0,C_word t1) C_noret;
static void f_5754(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5788(C_word t0,C_word t1) C_noret;
static void f_5445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5455(C_word c,C_word t0,C_word t1) C_noret;
static void f_5458(C_word c,C_word t0,C_word t1) C_noret;
static void f_5461(C_word c,C_word t0,C_word t1) C_noret;
static void f_5676(C_word c,C_word t0,C_word t1) C_noret;
static void f_5467(C_word c,C_word t0,C_word t1) C_noret;
static void f_5470(C_word c,C_word t0,C_word t1) C_noret;
static void f_5473(C_word c,C_word t0,C_word t1) C_noret;
static void f_5476(C_word c,C_word t0,C_word t1) C_noret;
static void f_5479(C_word c,C_word t0,C_word t1) C_noret;
static void f_5482(C_word c,C_word t0,C_word t1) C_noret;
static void f_5485(C_word c,C_word t0,C_word t1) C_noret;
static void f_5488(C_word c,C_word t0,C_word t1) C_noret;
static void f_5491(C_word c,C_word t0,C_word t1) C_noret;
static void f_5494(C_word c,C_word t0,C_word t1) C_noret;
static void f_5665(C_word c,C_word t0,C_word t1) C_noret;
static void f_5497(C_word c,C_word t0,C_word t1) C_noret;
static void f_5500(C_word c,C_word t0,C_word t1) C_noret;
static void f_5503(C_word c,C_word t0,C_word t1) C_noret;
static void f_5506(C_word c,C_word t0,C_word t1) C_noret;
static void f_5509(C_word c,C_word t0,C_word t1) C_noret;
static void f_5512(C_word c,C_word t0,C_word t1) C_noret;
static void f_5515(C_word c,C_word t0,C_word t1) C_noret;
static void f_5518(C_word c,C_word t0,C_word t1) C_noret;
static void f_5643(C_word c,C_word t0,C_word t1) C_noret;
static void f_5613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5633(C_word c,C_word t0,C_word t1) C_noret;
static void f_5621(C_word c,C_word t0,C_word t1) C_noret;
static void f_5625(C_word c,C_word t0,C_word t1) C_noret;
static void f_5629(C_word c,C_word t0,C_word t1) C_noret;
static void f_5521(C_word c,C_word t0,C_word t1) C_noret;
static void f_5524(C_word c,C_word t0,C_word t1) C_noret;
static void f_5554(C_word c,C_word t0,C_word t1) C_noret;
static void f_5557(C_word c,C_word t0,C_word t1) C_noret;
static void f_5595(C_word c,C_word t0,C_word t1) C_noret;
static void f_5591(C_word c,C_word t0,C_word t1) C_noret;
static void f_5560(C_word c,C_word t0,C_word t1) C_noret;
static void f_5563(C_word c,C_word t0,C_word t1) C_noret;
static void f_5566(C_word c,C_word t0,C_word t1) C_noret;
static void f_5533(C_word c,C_word t0,C_word t1) C_noret;
static void f_5536(C_word c,C_word t0,C_word t1) C_noret;
static void f_5527(C_word c,C_word t0,C_word t1) C_noret;
static void f_5427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5437(C_word c,C_word t0,C_word t1) C_noret;
static void f_5440(C_word c,C_word t0,C_word t1) C_noret;
static void f_5376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5380(C_word c,C_word t0,C_word t1) C_noret;
static void f_5385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5392(C_word t0,C_word t1) C_noret;
static void f_5412(C_word c,C_word t0,C_word t1) C_noret;
static void f_5360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5374(C_word c,C_word t0,C_word t1) C_noret;
static void f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5358(C_word c,C_word t0,C_word t1) C_noret;
static void f_5255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5293(C_word t0,C_word t1) C_noret;
static void f_5303(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5296(C_word t0,C_word t1) C_noret;
static void C_fcall f_5280(C_word t0,C_word t1) C_noret;
static void f_1153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_5222(C_word c,C_word t0,C_word t1) C_noret;
static void f_5226(C_word c,C_word t0,C_word t1) C_noret;
static void f_5229(C_word c,C_word t0,C_word t1) C_noret;
static void f_5232(C_word c,C_word t0,C_word t1) C_noret;
static void f_5235(C_word c,C_word t0,C_word t1) C_noret;
static void f_5238(C_word c,C_word t0,C_word t1) C_noret;
static void f_5241(C_word c,C_word t0,C_word t1) C_noret;
static void f_5244(C_word c,C_word t0,C_word t1) C_noret;
static void f_5247(C_word c,C_word t0,C_word t1) C_noret;
static void f_5250(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4330(C_word t0,C_word t1) C_noret;
static void f_5206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5210(C_word c,C_word t0,C_word t1) C_noret;
static void f_5204(C_word c,C_word t0,C_word t1) C_noret;
static void f_4336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4340(C_word c,C_word t0,C_word t1) C_noret;
static void f_4343(C_word c,C_word t0,C_word t1) C_noret;
static void f_4346(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4352(C_word t0,C_word t1) C_noret;
static void C_fcall f_4358(C_word t0,C_word t1) C_noret;
static void f_4361(C_word c,C_word t0,C_word t1) C_noret;
static void f_4364(C_word c,C_word t0,C_word t1) C_noret;
static void f_4367(C_word c,C_word t0,C_word t1) C_noret;
static void f_4370(C_word c,C_word t0,C_word t1) C_noret;
static void f_5190(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4373(C_word t0,C_word t1) C_noret;
static void f_4379(C_word c,C_word t0,C_word t1) C_noret;
static void f_4382(C_word c,C_word t0,C_word t1) C_noret;
static void f_4385(C_word c,C_word t0,C_word t1) C_noret;
static void f_4388(C_word c,C_word t0,C_word t1) C_noret;
static void f_4391(C_word c,C_word t0,C_word t1) C_noret;
static void f_4394(C_word c,C_word t0,C_word t1) C_noret;
static void f_4397(C_word c,C_word t0,C_word t1) C_noret;
static void f_4400(C_word c,C_word t0,C_word t1) C_noret;
static void f_4403(C_word c,C_word t0,C_word t1) C_noret;
static void f_4406(C_word c,C_word t0,C_word t1) C_noret;
static void f_4409(C_word c,C_word t0,C_word t1) C_noret;
static void f_4412(C_word c,C_word t0,C_word t1) C_noret;
static void f_5159(C_word c,C_word t0,C_word t1) C_noret;
static void f_4415(C_word c,C_word t0,C_word t1) C_noret;
static void f_5107(C_word c,C_word t0,C_word t1) C_noret;
static void f_5110(C_word c,C_word t0,C_word t1) C_noret;
static void f_5113(C_word c,C_word t0,C_word t1) C_noret;
static void f_5142(C_word c,C_word t0,C_word t1) C_noret;
static void f_5145(C_word c,C_word t0,C_word t1) C_noret;
static void f_4418(C_word c,C_word t0,C_word t1) C_noret;
static void f_4421(C_word c,C_word t0,C_word t1) C_noret;
static void f_4424(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5079(C_word t0,C_word t1) C_noret;
static void f_5082(C_word c,C_word t0,C_word t1) C_noret;
static void f_4427(C_word c,C_word t0,C_word t1) C_noret;
static void f_4430(C_word c,C_word t0,C_word t1) C_noret;
static void f_4433(C_word c,C_word t0,C_word t1) C_noret;
static void f_4436(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4439(C_word t0,C_word t1) C_noret;
static void f_4442(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5051(C_word c,C_word t0,C_word t1) C_noret;
static void f_4445(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4984(C_word t0,C_word t1) C_noret;
static void f_4996(C_word c,C_word t0,C_word t1) C_noret;
static void f_4999(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5005(C_word t0,C_word t1) C_noret;
static void f_4906(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4948(C_word t0,C_word t1) C_noret;
static void f_4909(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4915(C_word t0,C_word t1) C_noret;
static void f_4918(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4924(C_word t0,C_word t1) C_noret;
static void f_4842(C_word c,C_word t0,C_word t1) C_noret;
static void f_4845(C_word c,C_word t0,C_word t1) C_noret;
static void f_4848(C_word c,C_word t0,C_word t1) C_noret;
static void f_4851(C_word c,C_word t0,C_word t1) C_noret;
static void f_4854(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4869(C_word t0,C_word t1) C_noret;
static void f_4857(C_word c,C_word t0,C_word t1) C_noret;
static void f_4860(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4825(C_word c,C_word t0,C_word t1) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1) C_noret;
static void f_4805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4813(C_word c,C_word t0,C_word t1) C_noret;
static void f_4684(C_word c,C_word t0,C_word t1) C_noret;
static void f_4690(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4795(C_word c,C_word t0,C_word t1) C_noret;
static void f_4803(C_word c,C_word t0,C_word t1) C_noret;
static void f_4799(C_word c,C_word t0,C_word t1) C_noret;
static void f_4780(C_word c,C_word t0,C_word t1) C_noret;
static void f_4693(C_word c,C_word t0,C_word t1) C_noret;
static void f_4696(C_word c,C_word t0,C_word t1) C_noret;
static void f_4738(C_word c,C_word t0,C_word t1) C_noret;
static void f_4741(C_word c,C_word t0,C_word t1) C_noret;
static void f_4744(C_word c,C_word t0,C_word t1) C_noret;
static void f_4699(C_word c,C_word t0,C_word t1) C_noret;
static void f_4702(C_word c,C_word t0,C_word t1) C_noret;
static void f_4705(C_word c,C_word t0,C_word t1) C_noret;
static void f_4708(C_word c,C_word t0,C_word t1) C_noret;
static void f_4717(C_word c,C_word t0,C_word t1) C_noret;
static void f_4720(C_word c,C_word t0,C_word t1) C_noret;
static void f_4448(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4471(C_word t0,C_word t1) C_noret;
static void f_4618(C_word c,C_word t0,C_word t1) C_noret;
static void f_4621(C_word c,C_word t0,C_word t1) C_noret;
static void f_4633(C_word c,C_word t0,C_word t1) C_noret;
static void f_4624(C_word c,C_word t0,C_word t1) C_noret;
static void f_4477(C_word c,C_word t0,C_word t1) C_noret;
static void f_4480(C_word c,C_word t0,C_word t1) C_noret;
static void f_4483(C_word c,C_word t0,C_word t1) C_noret;
static void f_4595(C_word c,C_word t0,C_word t1) C_noret;
static void f_4486(C_word c,C_word t0,C_word t1) C_noret;
static void f_4489(C_word c,C_word t0,C_word t1) C_noret;
static void f_4492(C_word c,C_word t0,C_word t1) C_noret;
static void f_4495(C_word c,C_word t0,C_word t1) C_noret;
static void f_4564(C_word c,C_word t0,C_word t1) C_noret;
static void f_4560(C_word c,C_word t0,C_word t1) C_noret;
static void f_4498(C_word c,C_word t0,C_word t1) C_noret;
static void f_4501(C_word c,C_word t0,C_word t1) C_noret;
static void f_4504(C_word c,C_word t0,C_word t1) C_noret;
static void f_4507(C_word c,C_word t0,C_word t1) C_noret;
static void f_4510(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4541(C_word c,C_word t0,C_word t1) C_noret;
static void f_4516(C_word c,C_word t0,C_word t1) C_noret;
static void f_4451(C_word c,C_word t0,C_word t1) C_noret;
static void f_4461(C_word c,C_word t0,C_word t1) C_noret;
static void f_4454(C_word c,C_word t0,C_word t1) C_noret;
static void f_3561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3568(C_word c,C_word t0,C_word t1) C_noret;
static void f_3642(C_word c,C_word t0,C_word t1) C_noret;
static void f_3660(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3717(C_word c,C_word t0,C_word t1) C_noret;
static void f_3673(C_word c,C_word t0,C_word t1) C_noret;
static void f_3636(C_word c,C_word t0,C_word t1) C_noret;
static void f_3632(C_word c,C_word t0,C_word t1) C_noret;
static void f_3628(C_word c,C_word t0,C_word t1) C_noret;
static void f_3599(C_word c,C_word t0,C_word t1) C_noret;
static void f_3603(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3514(C_word t0,C_word t1) C_noret;
static void C_fcall f_3520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3549(C_word c,C_word t0,C_word t1) C_noret;
static void f_3530(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4310(C_word c,C_word t0,C_word t1) C_noret;
static void f_4313(C_word c,C_word t0,C_word t1) C_noret;
static void f_4278(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4287(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4300(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3840(C_word c,C_word t0,C_word t1) C_noret;
static void f_4153(C_word c,C_word t0,C_word t1) C_noret;
static void f_4125(C_word c,C_word t0,C_word t1) C_noret;
static void f_4080(C_word c,C_word t0,C_word t1) C_noret;
static void f_4086(C_word c,C_word t0,C_word t1) C_noret;
static void f_4089(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3964(C_word t0,C_word t1) C_noret;
static void f_4032(C_word c,C_word t0,C_word t1) C_noret;
static void f_4035(C_word c,C_word t0,C_word t1) C_noret;
static void f_4038(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4011(C_word c,C_word t0,C_word t1) C_noret;
static void f_4014(C_word c,C_word t0,C_word t1) C_noret;
static void f_3979(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4001(C_word c,C_word t0,C_word t1) C_noret;
static void f_3876(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3882(C_word t0,C_word t1) C_noret;
static void f_3867(C_word c,C_word t0,C_word t1) C_noret;
static void f_3870(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3555(C_word t0,C_word t1) C_noret;
static void C_fcall f_4155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4162(C_word c,C_word t0,C_word t1) C_noret;
static void f_4165(C_word c,C_word t0,C_word t1) C_noret;
static void f_4168(C_word c,C_word t0,C_word t1) C_noret;
static void f_4171(C_word c,C_word t0,C_word t1) C_noret;
static void f_4174(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4238(C_word c,C_word t0,C_word t1) C_noret;
static void f_4234(C_word c,C_word t0,C_word t1) C_noret;
static void f_4219(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4198(C_word t0,C_word t1) C_noret;
static void f_4209(C_word c,C_word t0,C_word t1) C_noret;
static void f_4205(C_word c,C_word t0,C_word t1) C_noret;
static void f_4189(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4247(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4254(C_word c,C_word t0,C_word t1) C_noret;
static void f_4257(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3226(C_word t0,C_word t1) C_noret;
static void f_3391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3395(C_word c,C_word t0,C_word t1) C_noret;
static void f_3398(C_word c,C_word t0,C_word t1) C_noret;
static void f_3401(C_word c,C_word t0,C_word t1) C_noret;
static void f_3404(C_word c,C_word t0,C_word t1) C_noret;
static void f_3407(C_word c,C_word t0,C_word t1) C_noret;
static void f_3512(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3410(C_word t0,C_word t1) C_noret;
static void C_fcall f_3413(C_word t0,C_word t1) C_noret;
static void f_3419(C_word c,C_word t0,C_word t1) C_noret;
static void f_3501(C_word c,C_word t0,C_word t1) C_noret;
static void f_3457(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3463(C_word t0,C_word t1) C_noret;
static void f_3481(C_word c,C_word t0,C_word t1) C_noret;
static void f_3477(C_word c,C_word t0,C_word t1) C_noret;
static void f_3473(C_word c,C_word t0,C_word t1) C_noret;
static void f_3425(C_word c,C_word t0,C_word t1) C_noret;
static void f_3428(C_word c,C_word t0,C_word t1) C_noret;
static void f_3431(C_word c,C_word t0,C_word t1) C_noret;
static void f_3434(C_word c,C_word t0,C_word t1) C_noret;
static void f_3437(C_word c,C_word t0,C_word t1) C_noret;
static void f_3447(C_word c,C_word t0,C_word t1) C_noret;
static void f_3440(C_word c,C_word t0,C_word t1) C_noret;
static void f_3343(C_word c,C_word t0,C_word t1) C_noret;
static void f_3362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3366(C_word c,C_word t0,C_word t1) C_noret;
static void f_3369(C_word c,C_word t0,C_word t1) C_noret;
static void f_3372(C_word c,C_word t0,C_word t1) C_noret;
static void f_3375(C_word c,C_word t0,C_word t1) C_noret;
static void f_3389(C_word c,C_word t0,C_word t1) C_noret;
static void f_3385(C_word c,C_word t0,C_word t1) C_noret;
static void f_3378(C_word c,C_word t0,C_word t1) C_noret;
static void f_3346(C_word c,C_word t0,C_word t1) C_noret;
static void f_3360(C_word c,C_word t0,C_word t1) C_noret;
static void f_3349(C_word c,C_word t0,C_word t1) C_noret;
static void f_3356(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3271(C_word c,C_word t0,C_word t1) C_noret;
static void f_3274(C_word c,C_word t0,C_word t1) C_noret;
static void f_3277(C_word c,C_word t0,C_word t1) C_noret;
static void f_3280(C_word c,C_word t0,C_word t1) C_noret;
static void f_3283(C_word c,C_word t0,C_word t1) C_noret;
static void f_3286(C_word c,C_word t0,C_word t1) C_noret;
static void f_3289(C_word c,C_word t0,C_word t1) C_noret;
static void f_3292(C_word c,C_word t0,C_word t1) C_noret;
static void f_3295(C_word c,C_word t0,C_word t1) C_noret;
static void f_3298(C_word c,C_word t0,C_word t1) C_noret;
static void f_3301(C_word c,C_word t0,C_word t1) C_noret;
static void f_3304(C_word c,C_word t0,C_word t1) C_noret;
static void f_3307(C_word c,C_word t0,C_word t1) C_noret;
static void f_3321(C_word c,C_word t0,C_word t1) C_noret;
static void f_3317(C_word c,C_word t0,C_word t1) C_noret;
static void f_3310(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3229(C_word t0,C_word t1) C_noret;
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3252(C_word c,C_word t0,C_word t1) C_noret;
static void f_3233(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2920(C_word t0,C_word t1) C_noret;
static void f_2924(C_word c,C_word t0,C_word t1) C_noret;
static void f_2948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2952(C_word c,C_word t0,C_word t1) C_noret;
static void f_2955(C_word c,C_word t0,C_word t1) C_noret;
static void f_3224(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2958(C_word t0,C_word t1) C_noret;
static void f_3210(C_word c,C_word t0,C_word t1) C_noret;
static void f_2961(C_word c,C_word t0,C_word t1) C_noret;
static void f_2964(C_word c,C_word t0,C_word t1) C_noret;
static void f_2967(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2973(C_word t0,C_word t1) C_noret;
static void C_fcall f_2979(C_word t0,C_word t1) C_noret;
static void f_2982(C_word c,C_word t0,C_word t1) C_noret;
static void f_2985(C_word c,C_word t0,C_word t1) C_noret;
static void f_2988(C_word c,C_word t0,C_word t1) C_noret;
static void f_2991(C_word c,C_word t0,C_word t1) C_noret;
static void f_3192(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2994(C_word t0,C_word t1) C_noret;
static void f_2997(C_word c,C_word t0,C_word t1) C_noret;
static void f_3185(C_word c,C_word t0,C_word t1) C_noret;
static void f_3166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3177(C_word c,C_word t0,C_word t1) C_noret;
static void f_3000(C_word c,C_word t0,C_word t1) C_noret;
static void f_3091(C_word c,C_word t0,C_word t1) C_noret;
static void f_3094(C_word c,C_word t0,C_word t1) C_noret;
static void f_3097(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3148(C_word t0,C_word t1) C_noret;
static void f_3126(C_word c,C_word t0,C_word t1) C_noret;
static void f_3129(C_word c,C_word t0,C_word t1) C_noret;
static void f_3136(C_word c,C_word t0,C_word t1) C_noret;
static void f_3003(C_word c,C_word t0,C_word t1) C_noret;
static void f_3006(C_word c,C_word t0,C_word t1) C_noret;
static void f_3009(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3063(C_word t0,C_word t1) C_noret;
static void f_3066(C_word c,C_word t0,C_word t1) C_noret;
static void f_3012(C_word c,C_word t0,C_word t1) C_noret;
static void f_3015(C_word c,C_word t0,C_word t1) C_noret;
static void f_3051(C_word c,C_word t0,C_word t1) C_noret;
static void f_3054(C_word c,C_word t0,C_word t1) C_noret;
static void f_3021(C_word c,C_word t0,C_word t1) C_noret;
static void f_3030(C_word c,C_word t0,C_word t1) C_noret;
static void f_3033(C_word c,C_word t0,C_word t1) C_noret;
static void f_2927(C_word c,C_word t0,C_word t1) C_noret;
static void f_2932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2936(C_word c,C_word t0,C_word t1) C_noret;
static void f_2946(C_word c,C_word t0,C_word t1) C_noret;
static void f_2939(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2867(C_word t0,C_word t1) C_noret;
static void f_2874(C_word c,C_word t0,C_word t1) C_noret;
static void f_2914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2877(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2703(C_word t0,C_word t1) C_noret;
static void f_2859(C_word c,C_word t0,C_word t1) C_noret;
static void f_2723(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2729(C_word t0,C_word t1) C_noret;
static void f_2822(C_word c,C_word t0,C_word t1) C_noret;
static void f_2826(C_word c,C_word t0,C_word t1) C_noret;
static void f_2830(C_word c,C_word t0,C_word t1) C_noret;
static void f_2834(C_word c,C_word t0,C_word t1) C_noret;
static void f_2838(C_word c,C_word t0,C_word t1) C_noret;
static void f_2747(C_word c,C_word t0,C_word t1) C_noret;
static void f_2750(C_word c,C_word t0,C_word t1) C_noret;
static void f_2753(C_word c,C_word t0,C_word t1) C_noret;
static void f_2811(C_word c,C_word t0,C_word t1) C_noret;
static void f_2756(C_word c,C_word t0,C_word t1) C_noret;
static void f_2795(C_word c,C_word t0,C_word t1) C_noret;
static void f_2798(C_word c,C_word t0,C_word t1) C_noret;
static void f_2759(C_word c,C_word t0,C_word t1) C_noret;
static void f_2762(C_word c,C_word t0,C_word t1) C_noret;
static void f_2765(C_word c,C_word t0,C_word t1) C_noret;
static void f_2780(C_word c,C_word t0,C_word t1) C_noret;
static void f_2785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2768(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2706(C_word t0,C_word t1) C_noret;
static void f_2720(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1204(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2671(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2681(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2636(C_word c,C_word t0,C_word t1) C_noret;
static void f_2639(C_word c,C_word t0,C_word t1) C_noret;
static void f_2642(C_word c,C_word t0,C_word t1) C_noret;
static void f_2645(C_word c,C_word t0,C_word t1) C_noret;
static void f_2648(C_word c,C_word t0,C_word t1) C_noret;
static void f_2651(C_word c,C_word t0,C_word t1) C_noret;
static void f_2553(C_word c,C_word t0,C_word t1) C_noret;
static void f_2556(C_word c,C_word t0,C_word t1) C_noret;
static void f_2559(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2595(C_word c,C_word t0,C_word t1) C_noret;
static void f_2598(C_word c,C_word t0,C_word t1) C_noret;
static void f_2601(C_word c,C_word t0,C_word t1) C_noret;
static void f_2604(C_word c,C_word t0,C_word t1) C_noret;
static void f_2582(C_word c,C_word t0,C_word t1) C_noret;
static void f_2585(C_word c,C_word t0,C_word t1) C_noret;
static void f_2544(C_word c,C_word t0,C_word t1) C_noret;
static void f_2516(C_word c,C_word t0,C_word t1) C_noret;
static void f_2519(C_word c,C_word t0,C_word t1) C_noret;
static void f_2536(C_word c,C_word t0,C_word t1) C_noret;
static void f_2522(C_word c,C_word t0,C_word t1) C_noret;
static void f_2525(C_word c,C_word t0,C_word t1) C_noret;
static void f_2500(C_word c,C_word t0,C_word t1) C_noret;
static void f_2504(C_word c,C_word t0,C_word t1) C_noret;
static void f_2486(C_word c,C_word t0,C_word t1) C_noret;
static void f_2489(C_word c,C_word t0,C_word t1) C_noret;
static void f_2470(C_word c,C_word t0,C_word t1) C_noret;
static void f_2474(C_word c,C_word t0,C_word t1) C_noret;
static void f_2452(C_word c,C_word t0,C_word t1) C_noret;
static void f_2455(C_word c,C_word t0,C_word t1) C_noret;
static void f_2432(C_word c,C_word t0,C_word t1) C_noret;
static void f_2396(C_word c,C_word t0,C_word t1) C_noret;
static void f_2408(C_word c,C_word t0,C_word t1) C_noret;
static void f_2399(C_word c,C_word t0,C_word t1) C_noret;
static void f_2377(C_word c,C_word t0,C_word t1) C_noret;
static void f_2380(C_word c,C_word t0,C_word t1) C_noret;
static void f_2358(C_word c,C_word t0,C_word t1) C_noret;
static void f_2361(C_word c,C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1) C_noret;
static void f_2342(C_word c,C_word t0,C_word t1) C_noret;
static void f_2320(C_word c,C_word t0,C_word t1) C_noret;
static void f_2316(C_word c,C_word t0,C_word t1) C_noret;
static void f_2260(C_word c,C_word t0,C_word t1) C_noret;
static void f_2293(C_word c,C_word t0,C_word t1) C_noret;
static void f_2263(C_word c,C_word t0,C_word t1) C_noret;
static void f_2281(C_word c,C_word t0,C_word t1) C_noret;
static void f_2266(C_word c,C_word t0,C_word t1) C_noret;
static void f_2269(C_word c,C_word t0,C_word t1) C_noret;
static void f_2224(C_word c,C_word t0,C_word t1) C_noret;
static void f_2204(C_word c,C_word t0,C_word t1) C_noret;
static void f_2207(C_word c,C_word t0,C_word t1) C_noret;
static void f_2210(C_word c,C_word t0,C_word t1) C_noret;
static void f_2163(C_word c,C_word t0,C_word t1) C_noret;
static void f_2166(C_word c,C_word t0,C_word t1) C_noret;
static void f_2187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2191(C_word c,C_word t0,C_word t1) C_noret;
static void f_2194(C_word c,C_word t0,C_word t1) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1) C_noret;
static void f_2185(C_word c,C_word t0,C_word t1) C_noret;
static void f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2172(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1888(C_word t0,C_word t1) C_noret;
static void f_2113(C_word c,C_word t0,C_word t1) C_noret;
static void f_2109(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1894(C_word t0,C_word t1) C_noret;
static void f_1196(C_word c,C_word t0,C_word t1) C_noret;
static void f_2102(C_word c,C_word t0,C_word t1) C_noret;
static void f_1186(C_word c,C_word t0,C_word t1) C_noret;
static void f_2095(C_word c,C_word t0,C_word t1) C_noret;
static void f_1900(C_word c,C_word t0,C_word t1) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_2051(C_word c,C_word t0,C_word t1) C_noret;
static void f_2054(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2069(C_word t0,C_word t1) C_noret;
static void f_2057(C_word c,C_word t0,C_word t1) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void f_2063(C_word c,C_word t0,C_word t1) C_noret;
static void f_2045(C_word c,C_word t0,C_word t1) C_noret;
static void f_1951(C_word c,C_word t0,C_word t1) C_noret;
static void f_2029(C_word c,C_word t0,C_word t1) C_noret;
static void f_2032(C_word c,C_word t0,C_word t1) C_noret;
static void f_2001(C_word c,C_word t0,C_word t1) C_noret;
static void f_2004(C_word c,C_word t0,C_word t1) C_noret;
static void f_2007(C_word c,C_word t0,C_word t1) C_noret;
static void f_2010(C_word c,C_word t0,C_word t1) C_noret;
static void f_2013(C_word c,C_word t0,C_word t1) C_noret;
static void f_1954(C_word c,C_word t0,C_word t1) C_noret;
static void f_1957(C_word c,C_word t0,C_word t1) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1988(C_word c,C_word t0,C_word t1) C_noret;
static void f_1991(C_word c,C_word t0,C_word t1) C_noret;
static void f_1960(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1963(C_word c,C_word t0,C_word t1) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1) C_noret;
static void f_1912(C_word c,C_word t0,C_word t1) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1) C_noret;
static void f_1841(C_word c,C_word t0,C_word t1) C_noret;
static void f_1844(C_word c,C_word t0,C_word t1) C_noret;
static void f_1824(C_word c,C_word t0,C_word t1) C_noret;
static void f_1827(C_word c,C_word t0,C_word t1) C_noret;
static void f_1782(C_word c,C_word t0,C_word t1) C_noret;
static void f_1785(C_word c,C_word t0,C_word t1) C_noret;
static void f_1746(C_word c,C_word t0,C_word t1) C_noret;
static void f_1742(C_word c,C_word t0,C_word t1) C_noret;
static void f_1692(C_word c,C_word t0,C_word t1) C_noret;
static void f_1660(C_word c,C_word t0,C_word t1) C_noret;
static void f_1663(C_word c,C_word t0,C_word t1) C_noret;
static void f_1625(C_word c,C_word t0,C_word t1) C_noret;
static void f_1651(C_word c,C_word t0,C_word t1) C_noret;
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1641(C_word c,C_word t0,C_word t1) C_noret;
static void f_1644(C_word c,C_word t0,C_word t1) C_noret;
static void f_1628(C_word c,C_word t0,C_word t1) C_noret;
static void f_1593(C_word c,C_word t0,C_word t1) C_noret;
static void f_1596(C_word c,C_word t0,C_word t1) C_noret;
static void f_1599(C_word c,C_word t0,C_word t1) C_noret;
static void f_1602(C_word c,C_word t0,C_word t1) C_noret;
static void f_1564(C_word c,C_word t0,C_word t1) C_noret;
static void f_1567(C_word c,C_word t0,C_word t1) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void f_1573(C_word c,C_word t0,C_word t1) C_noret;
static void f_1527(C_word c,C_word t0,C_word t1) C_noret;
static void f_1530(C_word c,C_word t0,C_word t1) C_noret;
static void f_1533(C_word c,C_word t0,C_word t1) C_noret;
static void f_1536(C_word c,C_word t0,C_word t1) C_noret;
static void f_1494(C_word c,C_word t0,C_word t1) C_noret;
static void f_1497(C_word c,C_word t0,C_word t1) C_noret;
static void f_1500(C_word c,C_word t0,C_word t1) C_noret;
static void f_1503(C_word c,C_word t0,C_word t1) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void f_1478(C_word c,C_word t0,C_word t1) C_noret;
static void f_1448(C_word c,C_word t0,C_word t1) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1407(C_word c,C_word t0,C_word t1) C_noret;
static void f_1410(C_word c,C_word t0,C_word t1) C_noret;
static void f_1413(C_word c,C_word t0,C_word t1) C_noret;
static void f_1319(C_word c,C_word t0,C_word t1) C_noret;
static void f_1322(C_word c,C_word t0,C_word t1) C_noret;
static void f_1325(C_word c,C_word t0,C_word t1) C_noret;
static void f_1328(C_word c,C_word t0,C_word t1) C_noret;
static void f_1331(C_word c,C_word t0,C_word t1) C_noret;
static void f_1334(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1198(C_word t0);
static void C_fcall f_1156(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1176(C_word c,C_word t0,C_word t1) C_noret;
static void f_1160(C_word c,C_word t0,C_word t1) C_noret;
static void f_1108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1151(C_word c,C_word t0,C_word t1) C_noret;
static void f_1091(C_word c,C_word t0,C_word t1) C_noret;
static void f_1097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1102(C_word c,C_word t0,C_word t1) C_noret;
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1081(C_word c,C_word t0,C_word t1) C_noret;
static void f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1046(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1046r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

static void C_fcall trf_8071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8071(t0,t1);}

static void C_fcall trf_8572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8572(t0,t1);}

static void C_fcall trf_8514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8514(t0,t1);}

static void C_fcall trf_8478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8478(t0,t1);}

static void C_fcall trf_8443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8443(t0,t1);}

static void C_fcall trf_8395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8395(t0,t1);}

static void C_fcall trf_8347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8347(t0,t1);}

static void C_fcall trf_8299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8299(t0,t1);}

static void C_fcall trf_8264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8264(t0,t1);}

static void C_fcall trf_8228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8228(t0,t1);}

static void C_fcall trf_8192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8192(t0,t1);}

static void C_fcall trf_8170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8170(t0,t1);}

static void C_fcall trf_8165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8165(t0,t1);}

static void C_fcall trf_8160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8160(t0,t1);}

static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7992(t0,t1);}

static void C_fcall trf_7247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7247(t0,t1);}

static void C_fcall trf_7274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7274(t0,t1);}

static void C_fcall trf_7448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7448(t0,t1);}

static void C_fcall trf_7845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7845(t0,t1);}

static void C_fcall trf_7812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7812(t0,t1);}

static void C_fcall trf_7780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7780(t0,t1);}

static void C_fcall trf_7745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7745(t0,t1);}

static void C_fcall trf_7675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7675(t0,t1);}

static void C_fcall trf_7630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7630(t0,t1);}

static void C_fcall trf_7598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7598(t0,t1);}

static void C_fcall trf_7566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7566(t0,t1);}

static void C_fcall trf_7534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7534(t0,t1);}

static void C_fcall trf_7502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7502(t0,t1);}

static void C_fcall trf_7480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7480(t0,t1);}

static void C_fcall trf_7219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7219(t0,t1);}

static void C_fcall trf_6158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6158(t0,t1);}

static void C_fcall trf_6236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6236(t0,t1);}

static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6248(t0,t1);}

static void C_fcall trf_6344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6344(t0,t1);}

static void C_fcall trf_6964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6964(t0,t1);}

static void C_fcall trf_6984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6984(t0,t1);}

static void C_fcall trf_6918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6918(t0,t1);}

static void C_fcall trf_6868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6868(t0,t1);}

static void C_fcall trf_6818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6818(t0,t1);}

static void C_fcall trf_6783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6783(t0,t1);}

static void C_fcall trf_6748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6748(t0,t1);}

static void C_fcall trf_6713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6713(t0,t1);}

static void C_fcall trf_6674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6674(t0,t1);}

static void C_fcall trf_6614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6614(t0,t1);}

static void C_fcall trf_6575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6575(t0,t1);}

static void C_fcall trf_6539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6539(t0,t1);}

static void C_fcall trf_6503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6503(t0,t1);}

static void C_fcall trf_6467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6467(t0,t1);}

static void C_fcall trf_6431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6431(t0,t1);}

static void C_fcall trf_6405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6405(t0,t1,t2);}

static void C_fcall trf_6396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6396(t0,t1,t2);}

static void C_fcall trf_6391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6391(t0,t1);}

static void C_fcall trf_6103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6103(t0,t1,t2);}

static void C_fcall trf_6098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6098(t0,t1);}

static void C_fcall trf_5715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5715(t0,t1);}

static void C_fcall trf_5724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5724(t0,t1);}

static void C_fcall trf_5748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5748(t0,t1);}

static void C_fcall trf_5788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5788(t0,t1);}

static void C_fcall trf_5392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5392(t0,t1);}

static void C_fcall trf_5264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5264(t0,t1,t2);}

static void C_fcall trf_5293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5293(t0,t1);}

static void C_fcall trf_5296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5296(t0,t1);}

static void C_fcall trf_5280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5280(t0,t1);}

static void C_fcall trf_4330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4330(t0,t1);}

static void C_fcall trf_4352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4352(t0,t1);}

static void C_fcall trf_4358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4358(t0,t1);}

static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4373(t0,t1);}

static void C_fcall trf_5079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5079(t0,t1);}

static void C_fcall trf_4439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4439(t0,t1);}

static void C_fcall trf_5041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5041(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5041(t0,t1,t2,t3);}

static void C_fcall trf_4984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4984(t0,t1);}

static void C_fcall trf_5005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5005(t0,t1);}

static void C_fcall trf_4948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4948(t0,t1);}

static void C_fcall trf_4915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4915(t0,t1);}

static void C_fcall trf_4924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4924(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4924(t0,t1);}

static void C_fcall trf_4869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4869(t0,t1);}

static void C_fcall trf_4815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4815(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4815(t0,t1,t2,t3);}

static void C_fcall trf_4770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4770(t0,t1,t2,t3);}

static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4471(t0,t1);}

static void C_fcall trf_4531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4531(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4531(t0,t1,t2,t3);}

static void C_fcall trf_3695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3695(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3695(t0,t1,t2,t3);}

static void C_fcall trf_3514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3514(t0,t1);}

static void C_fcall trf_3520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3520(t0,t1,t2,t3);}

static void C_fcall trf_4259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4259(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4259(t0,t1,t2,t3,t4);}

static void C_fcall trf_4268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4268(t0,t1,t2,t3);}

static void C_fcall trf_4287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4287(t0,t1,t2);}

static void C_fcall trf_3818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3818(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3818(t0,t1,t2,t3,t4);}

static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3964(t0,t1);}

static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3969(t0,t1,t2,t3);}

static void C_fcall trf_3988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3988(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3988(t0,t1,t2);}

static void C_fcall trf_3882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3882(t0,t1);}

static void C_fcall trf_3555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3555(t0,t1);}

static void C_fcall trf_4155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4155(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4155(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4179(t0,t1,t2,t3);}

static void C_fcall trf_4198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4198(t0,t1);}

static void C_fcall trf_4247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4247(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4247(t0,t1,t2,t3);}

static void C_fcall trf_3226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3226(t0,t1);}

static void C_fcall trf_3410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3410(t0,t1);}

static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3413(t0,t1);}

static void C_fcall trf_3463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3463(t0,t1);}

static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3265(t0,t1,t2);}

static void C_fcall trf_3229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3229(t0,t1);}

static void C_fcall trf_3242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3242(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3242(t0,t1,t2,t3);}

static void C_fcall trf_2920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2920(t0,t1);}

static void C_fcall trf_2958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2958(t0,t1);}

static void C_fcall trf_2973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2973(t0,t1);}

static void C_fcall trf_2979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2979(t0,t1);}

static void C_fcall trf_2994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2994(t0,t1);}

static void C_fcall trf_3148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3148(t0,t1);}

static void C_fcall trf_3063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3063(t0,t1);}

static void C_fcall trf_2867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2867(t0,t1);}

static void C_fcall trf_2703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2703(t0,t1);}

static void C_fcall trf_2729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2729(t0,t1);}

static void C_fcall trf_2706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2706(t0,t1);}

static void C_fcall trf_1204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1204(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1204(t0,t1,t2,t3,t4);}

static void C_fcall trf_2671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2671(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2671(t0,t1,t2,t3);}

static void C_fcall trf_1207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1207(t0,t1,t2,t3);}

static void C_fcall trf_2572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2572(t0,t1,t2,t3);}

static void C_fcall trf_1888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1888(t0,t1);}

static void C_fcall trf_1894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1894(t0,t1);}

static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2069(t0,t1);}

static void C_fcall trf_1397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1397(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1397(t0,t1,t2,t3,t4);}

static void C_fcall trf_1156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1156(t0,t1,t2);}

static void C_fcall trf_1120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1120(t0,t1,t2,t3);}

static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(18);
if(!C_demand(18)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2067)){
C_save(t1);
C_rereclaim2(2067*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(18);
C_initialize_lf(lf,901);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_static_lambda_info(C_heaptop,10,"(a1051 x9)");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_static_lambda_info(C_heaptop,24,"(##compiler#gen . data8)");
lf[7]=C_h_intern(&lf[7],17,"\010compilergen-list");
lf[8]=C_static_lambda_info(C_heaptop,11,"(a1072 x11)");
lf[9]=C_h_intern(&lf[9],11,"intersperse");
lf[10]=C_static_lambda_info(C_heaptop,27,"(##compiler#gen-list lst10)");
lf[11]=C_h_intern(&lf[11],31,"\010compilercompute-namespace-size");
lf[12]=C_static_lambda_info(C_heaptop,39,"(##compiler#compute-namespace-size n12)");
lf[13]=C_h_intern(&lf[13],18,"\010compilerunique-id");
lf[14]=C_h_intern(&lf[14],29,"\010compilerquick-namespace-list");
lf[15]=C_h_intern(&lf[15],35,"\010compilersetup-quick-namespace-list");
lf[16]=C_h_intern(&lf[16],6,"append");
lf[17]=C_static_lambda_info(C_heaptop,12,"(a1096 ns13)");
lf[18]=C_h_intern(&lf[18],24,"\010compilernamespace-table");
lf[19]=C_static_lambda_info(C_heaptop,39,"(##compiler#setup-quick-namespace-list)");
lf[20]=C_h_intern(&lf[20],25,"\010compilernamespace-lookup");
lf[21]=C_h_intern(&lf[21],13,"\010compilerbomb");
lf[22]=C_static_string(C_heaptop,23,"symbol not in namespace");
lf[23]=C_h_intern(&lf[23],4,"cdar");
lf[24]=C_static_lambda_info(C_heaptop,19,"(loop nslist16 i17)");
lf[25]=C_static_lambda_info(C_heaptop,35,"(##compiler#namespace-lookup sym14)");
lf[26]=C_h_intern(&lf[26],22,"\010compilergenerate-code");
lf[27]=C_static_string(C_heaptop,17,"can\047t find lambda");
lf[28]=C_h_intern(&lf[28],17,"lambda-literal-id");
lf[29]=C_static_lambda_info(C_heaptop,12,"(a1167 ll48)");
lf[30]=C_h_intern(&lf[30],4,"find");
lf[31]=C_static_lambda_info(C_heaptop,18,"(find-lambda id45)");
lf[32]=C_static_string(C_heaptop,0,"");
lf[33]=C_static_lambda_info(C_heaptop,11,"(prefix-id)");
lf[34]=C_h_intern(&lf[34],14,"\004coreimmediate");
lf[35]=C_h_intern(&lf[35],4,"bool");
lf[36]=C_static_string(C_heaptop,13,"C_SCHEME_TRUE");
lf[37]=C_static_string(C_heaptop,14,"C_SCHEME_FALSE");
lf[38]=C_h_intern(&lf[38],4,"char");
lf[39]=C_static_string(C_heaptop,17,"C_make_character(");
lf[40]=C_h_intern(&lf[40],3,"nil");
lf[41]=C_static_string(C_heaptop,20,"C_SCHEME_END_OF_LIST");
lf[42]=C_h_intern(&lf[42],3,"fix");
lf[43]=C_static_string(C_heaptop,6,"C_fix(");
lf[44]=C_h_intern(&lf[44],3,"eof");
lf[45]=C_static_string(C_heaptop,20,"C_SCHEME_END_OF_FILE");
lf[46]=C_static_string(C_heaptop,13,"bad immediate");
lf[47]=C_h_intern(&lf[47],12,"\004coreliteral");
lf[48]=C_static_string(C_heaptop,3,"lf[");
lf[49]=C_h_intern(&lf[49],2,"if");
lf[50]=C_static_string(C_heaptop,5,"else{");
lf[51]=C_static_string(C_heaptop,3,")){");
lf[52]=C_static_string(C_heaptop,11,"if(C_truep(");
lf[53]=C_h_intern(&lf[53],9,"\004coreproc");
lf[54]=C_static_string(C_heaptop,0,"");
lf[55]=C_static_string(C_heaptop,8,"(C_word)");
lf[56]=C_h_intern(&lf[56],9,"\004corebind");
lf[57]=C_static_lambda_info(C_heaptop,23,"(loop bs74 i75 count76)");
lf[58]=C_h_intern(&lf[58],8,"\004coreref");
lf[59]=C_static_string(C_heaptop,2,")[");
lf[60]=C_static_string(C_heaptop,10,"((C_word*)");
lf[61]=C_h_intern(&lf[61],10,"\004coreunbox");
lf[62]=C_static_string(C_heaptop,4,")[1]");
lf[63]=C_static_string(C_heaptop,10,"((C_word*)");
lf[64]=C_h_intern(&lf[64],13,"\004coreupdate_i");
lf[65]=C_static_string(C_heaptop,17,"C_set_block_item(");
lf[66]=C_h_intern(&lf[66],11,"\004coreupdate");
lf[67]=C_static_string(C_heaptop,2,")+");
lf[68]=C_static_string(C_heaptop,1,",");
lf[69]=C_static_string(C_heaptop,20,"C_mutate(((C_word *)");
lf[70]=C_h_intern(&lf[70],16,"\004coreupdatebox_i");
lf[71]=C_static_string(C_heaptop,3,",0,");
lf[72]=C_static_string(C_heaptop,17,"C_set_block_item(");
lf[73]=C_h_intern(&lf[73],14,"\004coreupdatebox");
lf[74]=C_static_string(C_heaptop,4,")+1,");
lf[75]=C_static_string(C_heaptop,20,"C_mutate(((C_word *)");
lf[76]=C_h_intern(&lf[76],12,"\004coreclosure");
lf[77]=C_static_string(C_heaptop,17,"tmp=(C_word)a,a+=");
lf[78]=C_static_string(C_heaptop,5,",tmp)");
lf[79]=C_static_string(C_heaptop,2,"a[");
lf[80]=C_static_string(C_heaptop,2,"]=");
lf[81]=C_static_lambda_info(C_heaptop,17,"(a1636 x102 j103)");
lf[82]=C_h_intern(&lf[82],8,"for-each");
lf[83]=C_h_intern(&lf[83],4,"iota");
lf[84]=C_static_string(C_heaptop,19,"(*a=C_CLOSURE_TYPE|");
lf[85]=C_h_intern(&lf[85],8,"\004corebox");
lf[86]=C_static_string(C_heaptop,24,",tmp=(C_word)a,a+=2,tmp)");
lf[87]=C_static_string(C_heaptop,25,"(*a=C_VECTOR_TYPE|1,a[1]=");
lf[88]=C_h_intern(&lf[88],10,"\004corelocal");
lf[89]=C_h_intern(&lf[89],13,"\004coresetlocal");
lf[90]=C_h_intern(&lf[90],11,"\004coreglobal");
lf[91]=C_static_string(C_heaptop,3,"lf[");
lf[92]=C_static_string(C_heaptop,1,"]");
lf[93]=C_static_string(C_heaptop,12,"C_retrieve2(");
lf[94]=C_static_string(C_heaptop,3,"lf[");
lf[95]=C_static_string(C_heaptop,2,"],");
lf[96]=C_h_intern(&lf[96],21,"\010compilerc-ify-string");
lf[97]=C_h_intern(&lf[97],14,"symbol->string");
lf[98]=C_static_string(C_heaptop,11,"*((C_word*)");
lf[99]=C_static_string(C_heaptop,3,"lf[");
lf[100]=C_static_string(C_heaptop,4,"]+1)");
lf[101]=C_static_string(C_heaptop,11,"C_retrieve(");
lf[102]=C_static_string(C_heaptop,3,"lf[");
lf[103]=C_static_string(C_heaptop,2,"])");
lf[104]=C_h_intern(&lf[104],14,"\004coresetglobal");
lf[105]=C_static_string(C_heaptop,10,"C_mutate(&");
lf[106]=C_static_string(C_heaptop,3,"lf[");
lf[107]=C_static_string(C_heaptop,2,"],");
lf[108]=C_static_string(C_heaptop,18,"C_mutate((C_word*)");
lf[109]=C_static_string(C_heaptop,3,"lf[");
lf[110]=C_static_string(C_heaptop,4,"]+1,");
lf[111]=C_h_intern(&lf[111],16,"\004coresetglobal_i");
lf[112]=C_static_string(C_heaptop,3,"lf[");
lf[113]=C_static_string(C_heaptop,2,"]=");
lf[114]=C_static_string(C_heaptop,17,"C_set_block_item(");
lf[115]=C_static_string(C_heaptop,3,"lf[");
lf[116]=C_static_string(C_heaptop,4,"],0,");
lf[117]=C_h_intern(&lf[117],14,"\004coreundefined");
lf[118]=C_static_string(C_heaptop,18,"C_SCHEME_UNDEFINED");
lf[119]=C_h_intern(&lf[119],9,"\004corecall");
lf[120]=C_static_string(C_heaptop,2,");");
lf[121]=C_static_string(C_heaptop,0,"");
lf[122]=C_static_string(C_heaptop,3,",0,");
lf[123]=C_static_string(C_heaptop,10,"goto loop;");
lf[124]=C_static_string(C_heaptop,2,"c=");
lf[125]=C_static_string(C_heaptop,2,"=t");
lf[126]=C_static_lambda_info(C_heaptop,21,"(a1973 from145 to146)");
lf[127]=C_static_lambda_info(C_heaptop,20,"(a1983 arg141 tr142)");
lf[128]=C_h_intern(&lf[128],26,"lambda-literal-temporaries");
lf[129]=C_static_string(C_heaptop,2,");");
lf[130]=C_h_intern(&lf[130],22,"lambda-literal-looping");
lf[131]=C_static_string(C_heaptop,2,");");
lf[132]=C_static_string(C_heaptop,2,")(");
lf[133]=C_static_string(C_heaptop,2,",t");
lf[134]=C_h_intern(&lf[134],6,"unsafe");
lf[135]=C_static_string(C_heaptop,20,"(void*)(*((C_word*)t");
lf[136]=C_static_string(C_heaptop,4,"+1))");
lf[137]=C_static_string(C_heaptop,17,"C_retrieve_proc(t");
lf[138]=C_static_string(C_heaptop,1,")");
lf[139]=C_h_intern(&lf[139],19,"no-procedure-checks");
lf[140]=C_static_string(C_heaptop,8,"((C_proc");
lf[141]=C_static_string(C_heaptop,1,")");
lf[142]=C_h_intern(&lf[142],24,"\010compileremit-trace-info");
lf[143]=C_static_string(C_heaptop,9,"C_trace(\042");
lf[144]=C_static_string(C_heaptop,3,"\042);");
lf[145]=C_h_intern(&lf[145],16,"string-translate");
lf[146]=C_static_string(C_heaptop,1,"\134");
lf[147]=C_static_string(C_heaptop,1,"/");
lf[148]=C_h_intern(&lf[148],8,"->string");
lf[149]=C_static_string(C_heaptop,3,"/* ");
lf[150]=C_static_string(C_heaptop,3," */");
lf[151]=C_h_intern(&lf[151],17,"string-translate*");
tmp=C_static_string(C_heaptop,2,"*/");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"* /");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[152]=C_h_pair(C_restore,tmp);
lf[153]=C_h_intern(&lf[153],27,"lambda-literal-closure-size");
lf[154]=C_h_intern(&lf[154],12,"\004corerecurse");
lf[155]=C_static_string(C_heaptop,10,"goto loop;");
lf[156]=C_static_string(C_heaptop,2,"=t");
lf[157]=C_static_lambda_info(C_heaptop,21,"(a2176 from179 to180)");
lf[158]=C_static_lambda_info(C_heaptop,20,"(a2186 arg175 tr176)");
lf[159]=C_static_string(C_heaptop,3,"t0,");
lf[160]=C_h_intern(&lf[160],16,"\004coredirect_call");
lf[161]=C_static_string(C_heaptop,9,"C_a_i(&a,");
lf[162]=C_h_intern(&lf[162],13,"\004corecallunit");
lf[163]=C_static_string(C_heaptop,2,");");
lf[164]=C_static_string(C_heaptop,2,"C_");
lf[165]=C_static_string(C_heaptop,10,"_toplevel(");
lf[166]=C_static_string(C_heaptop,20,",C_SCHEME_UNDEFINED,");
lf[167]=C_h_intern(&lf[167],11,"\004corereturn");
lf[168]=C_static_string(C_heaptop,2,");");
lf[169]=C_static_string(C_heaptop,7,"return(");
lf[170]=C_h_intern(&lf[170],11,"\004coreinline");
lf[171]=C_static_string(C_heaptop,8,"(C_word)");
lf[172]=C_h_intern(&lf[172],20,"\004coreinline_allocate");
lf[173]=C_static_string(C_heaptop,8,"(C_word)");
lf[174]=C_static_string(C_heaptop,4,"(&a,");
lf[175]=C_h_intern(&lf[175],15,"\004coreinline_ref");
lf[176]=C_h_intern(&lf[176],34,"\010compilerforeign-result-conversion");
lf[177]=C_static_string(C_heaptop,1,"a");
lf[178]=C_h_intern(&lf[178],18,"\004coreinline_update");
lf[179]=C_static_string(C_heaptop,21,"),C_SCHEME_UNDEFINED)");
lf[180]=C_static_string(C_heaptop,2,"=(");
lf[181]=C_h_intern(&lf[181],36,"\010compilerforeign-argument-conversion");
lf[182]=C_h_intern(&lf[182],33,"\010compilerforeign-type-declaration");
lf[183]=C_static_string(C_heaptop,0,"");
lf[184]=C_h_intern(&lf[184],19,"\004coreinline_loc_ref");
lf[185]=C_static_string(C_heaptop,3,")))");
lf[186]=C_static_string(C_heaptop,3,"*((");
lf[187]=C_static_string(C_heaptop,17,"*)C_data_pointer(");
lf[188]=C_static_string(C_heaptop,0,"");
lf[189]=C_static_string(C_heaptop,1,"a");
lf[190]=C_h_intern(&lf[190],22,"\004coreinline_loc_update");
lf[191]=C_static_string(C_heaptop,21,"),C_SCHEME_UNDEFINED)");
lf[192]=C_static_string(C_heaptop,3,"))=");
lf[193]=C_static_string(C_heaptop,4,"((*(");
lf[194]=C_static_string(C_heaptop,17,"*)C_data_pointer(");
lf[195]=C_static_string(C_heaptop,0,"");
lf[196]=C_h_intern(&lf[196],11,"\004coreswitch");
lf[197]=C_static_string(C_heaptop,8,"default:");
lf[198]=C_static_string(C_heaptop,5,"case ");
lf[199]=C_static_lambda_info(C_heaptop,18,"(do225 j227 ps228)");
lf[200]=C_static_string(C_heaptop,2,"){");
lf[201]=C_static_string(C_heaptop,7,"switch(");
lf[202]=C_h_intern(&lf[202],9,"\004corecond");
lf[203]=C_static_string(C_heaptop,2,")\077");
lf[204]=C_static_string(C_heaptop,9,"(C_truep(");
lf[205]=C_static_string(C_heaptop,8,"bad form");
lf[206]=C_static_lambda_info(C_heaptop,14,"(expr n56 i57)");
lf[207]=C_static_lambda_info(C_heaptop,13,"(a2676 xs247)");
lf[208]=C_h_intern(&lf[208],13,"pair-for-each");
lf[209]=C_static_lambda_info(C_heaptop,24,"(expr-args args245 i246)");
lf[210]=C_static_lambda_info(C_heaptop,32,"(expression node51 temps52 ll53)");
lf[211]=C_h_intern(&lf[211],13,"string-append");
lf[212]=C_static_string(C_heaptop,1,"0");
lf[213]=C_static_lambda_info(C_heaptop,11,"(pad0 n256)");
lf[214]=C_h_intern(&lf[214],30,"\010compilerexternal-protos-first");
lf[215]=C_h_intern(&lf[215],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[216]=C_h_intern(&lf[216],22,"foreign-callback-stubs");
lf[217]=C_h_intern(&lf[217],29,"\010compilerforeign-declarations");
lf[218]=C_static_lambda_info(C_heaptop,15,"(a2784 decl268)");
lf[219]=C_static_string(C_heaptop,2,"*/");
lf[220]=C_static_string(C_heaptop,10,"#include \042");
lf[221]=C_h_intern(&lf[221],28,"\010compilertarget-include-file");
lf[222]=C_static_string(C_heaptop,1,"\042");
lf[223]=C_h_intern(&lf[223],18,"\010compilerunit-name");
lf[224]=C_static_string(C_heaptop,33,"   default nursery (stack) size: ");
lf[225]=C_h_intern(&lf[225],42,"\010compilerdefault-default-target-stack-size");
lf[226]=C_static_string(C_heaptop,22,"   default heap size: ");
lf[227]=C_h_intern(&lf[227],41,"\010compilerdefault-default-target-heap-size");
lf[228]=C_h_intern(&lf[228],34,"\010compilerdefault-installation-home");
lf[229]=C_static_string(C_heaptop,13,"not specified");
lf[230]=C_static_string(C_heaptop,30,"   default installation home: ");
lf[231]=C_static_string(C_heaptop,9,"   unit: ");
lf[232]=C_h_intern(&lf[232],19,"\010compilerused-units");
lf[233]=C_static_string(C_heaptop,15,"   used units: ");
lf[234]=C_h_intern(&lf[234],27,"\010compilercompiler-arguments");
lf[235]=C_static_string(C_heaptop,18,"/* Generated from ");
lf[236]=C_static_string(C_heaptop,24," by the Chicken compiler");
lf[237]=C_static_string(C_heaptop,3,"   ");
lf[238]=C_static_string(C_heaptop,3,"   ");
lf[239]=C_static_string(C_heaptop,17,"   command line: ");
lf[240]=C_h_intern(&lf[240],15,"chicken-version");
lf[241]=C_h_intern(&lf[241],15,"\003sysmatch-error");
lf[242]=C_h_intern(&lf[242],18,"\003sysdecode-seconds");
lf[243]=C_h_intern(&lf[243],15,"current-seconds");
lf[244]=C_static_lambda_info(C_heaptop,8,"(header)");
lf[245]=C_static_string(C_heaptop,13,"C_TLS C_word ");
lf[246]=C_static_string(C_heaptop,3,"lf[");
lf[247]=C_static_string(C_heaptop,2,"];");
lf[248]=C_static_string(C_heaptop,28,"C_externimport C_TLS C_word ");
lf[249]=C_static_string(C_heaptop,3,"lf[");
lf[250]=C_static_string(C_heaptop,2,"];");
lf[251]=C_static_string(C_heaptop,23,"static C_TLS C_word lf[");
lf[252]=C_static_string(C_heaptop,2,"];");
lf[253]=C_static_string(C_heaptop,22,"C_externimport void C_");
lf[254]=C_static_string(C_heaptop,46,"_toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[255]=C_static_lambda_info(C_heaptop,13,"(a2913 uu280)");
lf[256]=C_static_lambda_info(C_heaptop,14,"(declarations)");
lf[257]=C_static_string(C_heaptop,10,") C_noret;");
lf[258]=C_h_intern(&lf[258],9,"make-list");
lf[259]=C_static_string(C_heaptop,7,",C_word");
lf[260]=C_static_string(C_heaptop,21,"typedef void (*C_proc");
lf[261]=C_static_string(C_heaptop,8,")(C_word");
lf[262]=C_static_lambda_info(C_heaptop,12,"(a2931 s322)");
lf[263]=C_h_intern(&lf[263],4,"none");
lf[264]=C_static_string(C_heaptop,9,",C_word t");
lf[265]=C_static_string(C_heaptop,10,") C_noret;");
lf[266]=C_static_string(C_heaptop,12,"static void ");
lf[267]=C_static_string(C_heaptop,2,"r(");
lf[268]=C_static_string(C_heaptop,14,",...) C_noret;");
lf[269]=C_static_string(C_heaptop,8," C_noret");
lf[270]=C_static_string(C_heaptop,9,"C_word *a");
lf[271]=C_static_string(C_heaptop,9,"C_word c,");
lf[272]=C_h_intern(&lf[272],8,"toplevel");
lf[273]=C_static_string(C_heaptop,2,"C_");
lf[274]=C_static_string(C_heaptop,9,"_toplevel");
lf[275]=C_static_string(C_heaptop,8,"toplevel");
lf[276]=C_static_string(C_heaptop,20,"C_externexport void ");
lf[277]=C_static_string(C_heaptop,20,"C_externimport void ");
lf[278]=C_static_string(C_heaptop,49,"C_externexport void C_dynamic_and_unsafe(void) {}");
lf[279]=C_h_intern(&lf[279],27,"\010compileremit-unsafe-marker");
lf[280]=C_static_string(C_heaptop,8,"C_fcall ");
lf[281]=C_static_string(C_heaptop,7,"C_word ");
lf[282]=C_static_string(C_heaptop,5,"void ");
lf[283]=C_static_string(C_heaptop,15,"C_externexport ");
lf[284]=C_static_string(C_heaptop,7,"static ");
lf[285]=C_static_string(C_heaptop,15,"C_externimport ");
lf[286]=C_h_intern(&lf[286],21,"small-parameter-limit");
lf[287]=C_h_intern(&lf[287],11,"lset-adjoin");
lf[288]=C_h_intern(&lf[288],1,"=");
lf[289]=C_static_lambda_info(C_heaptop,12,"(a3165 s300)");
lf[290]=C_h_intern(&lf[290],32,"lambda-literal-callee-signatures");
lf[291]=C_h_intern(&lf[291],24,"lambda-literal-allocated");
lf[292]=C_h_intern(&lf[292],21,"lambda-literal-direct");
lf[293]=C_h_intern(&lf[293],33,"lambda-literal-rest-argument-mode");
lf[294]=C_h_intern(&lf[294],28,"lambda-literal-rest-argument");
lf[295]=C_h_intern(&lf[295],24,"lambda-literal-partition");
lf[296]=C_h_intern(&lf[296],27,"\010compilermake-variable-list");
lf[297]=C_static_string(C_heaptop,1,"t");
lf[298]=C_h_intern(&lf[298],27,"lambda-literal-customizable");
lf[299]=C_h_intern(&lf[299],29,"lambda-literal-argument-count");
lf[300]=C_static_lambda_info(C_heaptop,13,"(a2947 ll284)");
lf[301]=C_static_lambda_info(C_heaptop,12,"(prototypes)");
lf[302]=C_static_string(C_heaptop,16,"C_adjust_stack(-");
lf[303]=C_static_string(C_heaptop,2,");");
lf[304]=C_static_string(C_heaptop,8,"C_word t");
lf[305]=C_static_string(C_heaptop,8,"=C_pick(");
lf[306]=C_static_string(C_heaptop,2,");");
lf[307]=C_static_lambda_info(C_heaptop,17,"(do333 i335 j336)");
lf[308]=C_static_lambda_info(C_heaptop,14,"(restore n332)");
lf[309]=C_static_string(C_heaptop,3,");}");
lf[310]=C_h_intern(&lf[310],27,"\010compilermake-argument-list");
lf[311]=C_static_string(C_heaptop,1,"t");
lf[312]=C_static_string(C_heaptop,4,"(k)(");
lf[313]=C_static_string(C_heaptop,6,"(a,n);");
lf[314]=C_static_string(C_heaptop,7,"_vector");
lf[315]=C_static_string(C_heaptop,15,"=C_restore_rest");
lf[316]=C_static_string(C_heaptop,15,"a=C_alloc(n+1);");
lf[317]=C_static_string(C_heaptop,15,"a=C_alloc(n*3);");
lf[318]=C_static_string(C_heaptop,18,"n=C_rest_count(0);");
lf[319]=C_static_string(C_heaptop,7,"(C_proc");
lf[320]=C_static_string(C_heaptop,4," k){");
lf[321]=C_static_string(C_heaptop,6,"int n;");
lf[322]=C_static_string(C_heaptop,11,"C_word *a,t");
lf[323]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[324]=C_static_string(C_heaptop,7,"(C_proc");
lf[325]=C_static_string(C_heaptop,22," k) C_regparm C_noret;");
lf[326]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[327]=C_static_lambda_info(C_heaptop,13,"(f_3267 n341)");
lf[328]=C_static_lambda_info(C_heaptop,18,"(emitter vflag340)");
lf[329]=C_static_string(C_heaptop,3,");}");
lf[330]=C_static_string(C_heaptop,1,"t");
lf[331]=C_static_string(C_heaptop,4,"(k)(");
lf[332]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[333]=C_static_string(C_heaptop,7,"(C_proc");
lf[334]=C_static_string(C_heaptop,4," k){");
lf[335]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[336]=C_static_string(C_heaptop,7,"(C_proc");
lf[337]=C_static_string(C_heaptop,22," k) C_regparm C_noret;");
lf[338]=C_static_lambda_info(C_heaptop,12,"(a3361 n374)");
lf[339]=C_static_string(C_heaptop,3,");}");
lf[340]=C_static_string(C_heaptop,1,"t");
lf[341]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[342]=C_static_string(C_heaptop,14,"(void *dummy){");
lf[343]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[344]=C_static_string(C_heaptop,32,"(void *dummy) C_regparm C_noret;");
lf[345]=C_h_intern(&lf[345],6,"vector");
lf[346]=C_h_intern(&lf[346],23,"lambda-literal-external");
lf[347]=C_static_lambda_info(C_heaptop,13,"(a3390 ll356)");
lf[348]=C_static_lambda_info(C_heaptop,13,"(trampolines)");
lf[349]=C_h_intern(&lf[349],14,"\003syscopy-bytes");
lf[350]=C_h_intern(&lf[350],11,"make-string");
lf[351]=C_static_lambda_info(C_heaptop,44,"(string-like-substring s449 start450 end451)");
lf[352]=C_static_string(C_heaptop,2,");");
lf[353]=C_static_lambda_info(C_heaptop,22,"(do437 i439 offset440)");
lf[354]=C_static_string(C_heaptop,10,"C_heaptop,");
lf[355]=C_h_intern(&lf[355],6,"modulo");
lf[356]=C_h_intern(&lf[356],3,"fx/");
lf[357]=C_static_lambda_info(C_heaptop,51,"(gen-string-like-lit to430 lit431 conser432 top433)");
lf[358]=C_static_string(C_heaptop,29,"type of literal not supported");
lf[359]=C_static_lambda_info(C_heaptop,20,"(bad-literal lit391)");
lf[360]=C_h_intern(&lf[360],6,"flonum");
lf[361]=C_h_intern(&lf[361],11,"number-type");
lf[362]=C_static_string(C_heaptop,20,"=C_flonum(C_heaptop,");
lf[363]=C_static_string(C_heaptop,2,");");
lf[364]=C_static_string(C_heaptop,7,"=C_fix(");
lf[365]=C_static_string(C_heaptop,2,");");
lf[366]=C_static_string(C_heaptop,20,"=C_SCHEME_UNDEFINED;");
lf[367]=C_h_intern(&lf[367],6,"fixnum");
lf[368]=C_static_string(C_heaptop,7,"=C_fix(");
lf[369]=C_static_string(C_heaptop,2,");");
lf[370]=C_h_intern(&lf[370],7,"warning");
lf[371]=C_static_string(C_heaptop,50,"coerced inexact literal number `~S\047 to fixnum `~S\047");
lf[372]=C_h_intern(&lf[372],11,"\003sysflo2fix");
lf[373]=C_static_string(C_heaptop,31,"=C_flonum(C_heaptop, C_strtod(\042");
lf[374]=C_static_string(C_heaptop,10,"\042, NULL));");
lf[375]=C_static_string(C_heaptop,20,"=C_flonum(C_heaptop,");
lf[376]=C_static_string(C_heaptop,2,");");
lf[377]=C_static_string(C_heaptop,13,"C_SCHEME_TRUE");
lf[378]=C_static_string(C_heaptop,14,"C_SCHEME_FALSE");
lf[379]=C_static_string(C_heaptop,18,"=C_make_character(");
lf[380]=C_static_string(C_heaptop,2,");");
lf[381]=C_static_string(C_heaptop,22,"=C_SCHEME_END_OF_LIST;");
lf[382]=C_static_string(C_heaptop,15,"C_static_string");
lf[383]=C_static_string(C_heaptop,20,"C_static_lambda_info");
lf[384]=C_static_string(C_heaptop,2,");");
lf[385]=C_static_string(C_heaptop,7,"C_drop(");
lf[386]=C_static_string(C_heaptop,2,");");
lf[387]=C_static_string(C_heaptop,8,",C_pick(");
lf[388]=C_static_lambda_info(C_heaptop,12,"(do413 k415)");
lf[389]=C_static_string(C_heaptop,10,"=C_h_list(");
lf[390]=C_static_string(C_heaptop,12,"C_save(tmp);");
lf[391]=C_static_string(C_heaptop,3,"tmp");
lf[392]=C_static_lambda_info(C_heaptop,21,"(do409 len411 lst412)");
lf[393]=C_static_string(C_heaptop,25,"=C_h_pair(C_restore,tmp);");
lf[394]=C_static_string(C_heaptop,3,"tmp");
lf[395]=C_static_string(C_heaptop,12,"C_save(tmp);");
lf[396]=C_static_string(C_heaptop,3,"tmp");
lf[397]=C_static_string(C_heaptop,10,"C_h_vector");
lf[398]=C_static_string(C_heaptop,15,"C_h_intern_in(&");
lf[399]=C_static_string(C_heaptop,7,",stable");
lf[400]=C_static_string(C_heaptop,2,");");
lf[401]=C_static_string(C_heaptop,22,"C_intern_in(C_heaptop,");
lf[402]=C_static_string(C_heaptop,7,",stable");
lf[403]=C_static_string(C_heaptop,2,");");
lf[404]=C_static_string(C_heaptop,12,"C_h_intern(&");
lf[405]=C_static_string(C_heaptop,2,");");
lf[406]=C_static_string(C_heaptop,19,"C_intern(C_heaptop,");
lf[407]=C_static_string(C_heaptop,2,");");
lf[408]=C_static_string(C_heaptop,1,"=");
lf[409]=C_static_string(C_heaptop,13,"C_pbytevector");
lf[410]=C_static_string(C_heaptop,12,"C_bytevector");
lf[411]=C_static_string(C_heaptop,13,"C_h_structure");
lf[412]=C_h_intern(&lf[412],15,"\003sysbytevector\077");
lf[413]=C_h_intern(&lf[413],4,"void");
lf[414]=C_h_intern(&lf[414],32,"\010compilerblock-variable-literal\077");
lf[415]=C_static_lambda_info(C_heaptop,28,"(gen-lit lit401 to402 lf403)");
lf[416]=C_static_string(C_heaptop,2,");");
lf[417]=C_static_string(C_heaptop,7,"C_drop(");
lf[418]=C_static_string(C_heaptop,2,");");
lf[419]=C_static_string(C_heaptop,8,",C_pick(");
lf[420]=C_static_lambda_info(C_heaptop,12,"(do463 j465)");
lf[421]=C_static_string(C_heaptop,12,"C_save(tmp);");
lf[422]=C_static_string(C_heaptop,3,"tmp");
lf[423]=C_static_lambda_info(C_heaptop,17,"(do459 j461 n462)");
lf[424]=C_static_lambda_info(C_heaptop,44,"(gen-vector-like-lit to455 lit456 conser457)");
lf[425]=C_h_intern(&lf[425],7,"sprintf");
lf[426]=C_static_string(C_heaptop,8,"~Alf[~s]");
lf[427]=C_static_lambda_info(C_heaptop,20,"(do385 i387 lits388)");
lf[428]=C_static_lambda_info(C_heaptop,15,"(literal-frame)");
lf[429]=C_h_intern(&lf[429],25,"\010compilerwords-per-flonum");
lf[430]=C_h_intern(&lf[430],6,"reduce");
lf[431]=C_h_intern(&lf[431],1,"+");
lf[432]=C_h_intern(&lf[432],7,"\003sysmap");
lf[433]=C_h_intern(&lf[433],12,"vector->list");
lf[434]=C_h_intern(&lf[434],14,"\010compilerwords");
lf[435]=C_static_lambda_info(C_heaptop,16,"(loop i395 s396)");
lf[436]=C_h_intern(&lf[436],19,"\010compilerimmediate\077");
lf[437]=C_static_lambda_info(C_heaptop,21,"(literal-size lit392)");
lf[438]=C_h_intern(&lf[438],19,"lambda-literal-body");
lf[439]=C_static_string(C_heaptop,18,"C_word *a=C_alloc(");
lf[440]=C_static_string(C_heaptop,2,");");
lf[441]=C_static_string(C_heaptop,8,"C_word t");
lf[442]=C_static_lambda_info(C_heaptop,17,"(do561 i563 j564)");
lf[443]=C_static_string(C_heaptop,11,"C_word tmp;");
lf[444]=C_static_string(C_heaptop,9,",C_word t");
lf[445]=C_static_string(C_heaptop,2,"){");
lf[446]=C_static_string(C_heaptop,12,"static void ");
lf[447]=C_static_string(C_heaptop,2,"r(");
lf[448]=C_static_string(C_heaptop,2,",t");
lf[449]=C_static_string(C_heaptop,4,");}}");
lf[450]=C_static_string(C_heaptop,1,"t");
lf[451]=C_static_string(C_heaptop,2,"r(");
lf[452]=C_h_intern(&lf[452],4,"list");
lf[453]=C_static_string(C_heaptop,1,"t");
lf[454]=C_static_string(C_heaptop,35,"=C_restore_rest(a,C_rest_count(0));");
lf[455]=C_static_string(C_heaptop,1,"t");
lf[456]=C_static_string(C_heaptop,42,"=C_restore_rest_vector(a,C_rest_count(0));");
lf[457]=C_static_string(C_heaptop,3,");}");
lf[458]=C_static_string(C_heaptop,5,"else{");
lf[459]=C_static_string(C_heaptop,13,"a=C_alloc((c-");
lf[460]=C_static_string(C_heaptop,5,")*3);");
lf[461]=C_static_string(C_heaptop,8,",(void*)");
lf[462]=C_static_string(C_heaptop,1,"r");
lf[463]=C_static_string(C_heaptop,18,"C_save_and_reclaim");
lf[464]=C_static_string(C_heaptop,9,"C_reclaim");
lf[465]=C_static_string(C_heaptop,10,"((void*)tr");
lf[466]=C_static_string(C_heaptop,3,");}");
lf[467]=C_static_string(C_heaptop,5,",NULL");
lf[468]=C_static_string(C_heaptop,8,",(void*)");
lf[469]=C_static_string(C_heaptop,18,"C_save_and_reclaim");
lf[470]=C_static_string(C_heaptop,9,"C_reclaim");
lf[471]=C_static_string(C_heaptop,10,"((void*)tr");
lf[472]=C_static_string(C_heaptop,14,"C_register_lf(");
lf[473]=C_static_string(C_heaptop,3,"lf,");
lf[474]=C_static_string(C_heaptop,2,");");
lf[475]=C_static_string(C_heaptop,16,"C_initialize_lf(");
lf[476]=C_static_string(C_heaptop,3,"lf,");
lf[477]=C_static_string(C_heaptop,2,");");
lf[478]=C_static_string(C_heaptop,10,"a=C_alloc(");
lf[479]=C_static_string(C_heaptop,2,");");
lf[480]=C_static_string(C_heaptop,15,"if(!C_demand_2(");
lf[481]=C_static_string(C_heaptop,3,")){");
lf[482]=C_static_string(C_heaptop,11,"C_save(t1);");
lf[483]=C_static_string(C_heaptop,13,"C_rereclaim2(");
lf[484]=C_static_string(C_heaptop,20,"*sizeof(C_word), 1);");
lf[485]=C_static_string(C_heaptop,14,"t1=C_restore;}");
lf[486]=C_static_string(C_heaptop,24,"C_check_nursery_minimum(");
lf[487]=C_static_string(C_heaptop,2,");");
lf[488]=C_static_string(C_heaptop,13,"if(!C_demand(");
lf[489]=C_static_string(C_heaptop,3,")){");
lf[490]=C_static_string(C_heaptop,11,"C_save(t1);");
lf[491]=C_static_string(C_heaptop,44,"C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[492]=C_static_string(C_heaptop,23,"toplevel_initialized=1;");
lf[493]=C_h_intern(&lf[493],26,"\010compilertarget-stack-size");
lf[494]=C_static_string(C_heaptop,15,"C_resize_stack(");
lf[495]=C_static_string(C_heaptop,2,");");
lf[496]=C_h_intern(&lf[496],30,"\010compilertarget-heap-shrinkage");
lf[497]=C_static_string(C_heaptop,17,"C_heap_shrinkage=");
lf[498]=C_h_intern(&lf[498],27,"\010compilertarget-heap-growth");
lf[499]=C_static_string(C_heaptop,14,"C_heap_growth=");
lf[500]=C_h_intern(&lf[500],33,"\010compilertarget-initial-heap-size");
lf[501]=C_static_string(C_heaptop,26,"C_set_or_change_heap_size(");
lf[502]=C_static_string(C_heaptop,4,",1);");
lf[503]=C_h_intern(&lf[503],25,"\010compilertarget-heap-size");
lf[504]=C_static_string(C_heaptop,26,"C_set_or_change_heap_size(");
lf[505]=C_static_string(C_heaptop,4,",1);");
lf[506]=C_static_string(C_heaptop,23,"C_heap_size_is_fixed=1;");
lf[507]=C_h_intern(&lf[507],40,"\010compilerdisable-stack-overflow-checking");
lf[508]=C_static_string(C_heaptop,29,"C_disable_overflow_check = 1;");
lf[509]=C_static_string(C_heaptop,6,"stable");
lf[510]=C_static_string(C_heaptop,21,"=C_new_symbol_table(\042");
lf[511]=C_static_string(C_heaptop,2,"\042,");
lf[512]=C_static_string(C_heaptop,2,");");
lf[513]=C_h_intern(&lf[513],4,"caar");
lf[514]=C_static_lambda_info(C_heaptop,18,"(do519 i521 ns522)");
lf[515]=C_static_string(C_heaptop,10,"C_word *a;");
lf[516]=C_static_string(C_heaptop,59,"if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[517]=C_static_string(C_heaptop,30,"else C_toplevel_entry(C_text(\042");
lf[518]=C_static_string(C_heaptop,4,"\042));");
lf[519]=C_static_lambda_info(C_heaptop,19,"(a4804 lit517 n518)");
lf[520]=C_h_intern(&lf[520],4,"fold");
lf[521]=C_static_string(C_heaptop,22,"C_SYMBOL_TABLE *stable");
lf[522]=C_static_lambda_info(C_heaptop,18,"(do509 i511 ns512)");
lf[523]=C_static_string(C_heaptop,29,"if(!C_demand(c*C_SIZEOF_PAIR+");
lf[524]=C_static_string(C_heaptop,3,")){");
lf[525]=C_h_intern(&lf[525],28,"\010compilerinsert-timer-checks");
lf[526]=C_static_string(C_heaptop,22,"C_check_for_interrupt;");
lf[527]=C_static_string(C_heaptop,5,"if(c<");
lf[528]=C_static_string(C_heaptop,21,") C_bad_min_argc_2(c,");
lf[529]=C_static_string(C_heaptop,5,",t0);");
lf[530]=C_h_intern(&lf[530],14,"no-argc-checks");
lf[531]=C_static_string(C_heaptop,4,",c2,");
lf[532]=C_static_string(C_heaptop,2,");");
lf[533]=C_static_string(C_heaptop,1,"c");
lf[534]=C_static_string(C_heaptop,12,"C_save_rest(");
lf[535]=C_static_string(C_heaptop,15,"C_word *a,c2=c;");
lf[536]=C_static_string(C_heaptop,10,"va_list v;");
lf[537]=C_static_string(C_heaptop,22,"if(!C_stack_probe(a)){");
lf[538]=C_static_string(C_heaptop,23,"if(!C_stack_probe(&a)){");
lf[539]=C_static_string(C_heaptop,22,"C_check_for_interrupt;");
lf[540]=C_static_string(C_heaptop,5,"if(c<");
lf[541]=C_static_string(C_heaptop,21,") C_bad_min_argc_2(c,");
lf[542]=C_static_string(C_heaptop,5,",t0);");
lf[543]=C_static_string(C_heaptop,6,"if(c!=");
lf[544]=C_static_string(C_heaptop,17,") C_bad_argc_2(c,");
lf[545]=C_static_string(C_heaptop,5,",t0);");
lf[546]=C_static_string(C_heaptop,10,"C_word *a;");
lf[547]=C_static_string(C_heaptop,5,"loop:");
lf[548]=C_static_string(C_heaptop,10,"a=C_alloc(");
lf[549]=C_static_string(C_heaptop,2,");");
lf[550]=C_static_string(C_heaptop,10,"C_word ab[");
lf[551]=C_static_string(C_heaptop,8,"],*a=ab;");
lf[552]=C_static_string(C_heaptop,14,"C_stack_check;");
lf[553]=C_static_string(C_heaptop,5,"loop:");
lf[554]=C_static_string(C_heaptop,10,"C_word *a;");
lf[555]=C_static_string(C_heaptop,8,"C_word t");
lf[556]=C_static_string(C_heaptop,8,"C_word t");
lf[557]=C_static_lambda_info(C_heaptop,17,"(do503 i505 j506)");
lf[558]=C_static_string(C_heaptop,11,"C_word tmp;");
lf[559]=C_static_string(C_heaptop,2,"){");
lf[560]=C_static_string(C_heaptop,4,",...");
lf[561]=C_static_string(C_heaptop,9,"C_word *a");
lf[562]=C_static_string(C_heaptop,9,"C_word c,");
lf[563]=C_static_string(C_heaptop,71,"static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[564]=C_static_string(C_heaptop,63,"C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[565]=C_static_string(C_heaptop,2,"C_");
lf[566]=C_static_string(C_heaptop,34,"(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[567]=C_static_string(C_heaptop,7,"void C_");
lf[568]=C_static_string(C_heaptop,18,"C_main_entry_point");
lf[569]=C_static_string(C_heaptop,40,"static C_TLS int toplevel_initialized=0;");
lf[570]=C_static_string(C_heaptop,8,"C_fcall ");
lf[571]=C_static_string(C_heaptop,7,"C_word ");
lf[572]=C_static_string(C_heaptop,5,"void ");
lf[573]=C_static_string(C_heaptop,15,"C_externexport ");
lf[574]=C_static_string(C_heaptop,7,"static ");
lf[575]=C_static_string(C_heaptop,15,"C_externimport ");
lf[576]=C_static_string(C_heaptop,3,"/* ");
lf[577]=C_static_string(C_heaptop,3," */");
lf[578]=C_h_intern(&lf[578],16,"\010compilercleanup");
lf[579]=C_h_intern(&lf[579],18,"\010compilerdebugging");
lf[580]=C_h_intern(&lf[580],1,"o");
lf[581]=C_static_string(C_heaptop,32,"dropping unused closure argument");
lf[582]=C_static_string(C_heaptop,9,"_toplevel");
lf[583]=C_static_string(C_heaptop,8,"toplevel");
lf[584]=C_static_string(C_heaptop,1,"t");
lf[585]=C_static_string(C_heaptop,1,"t");
lf[586]=C_h_intern(&lf[586],18,"\010compilerreal-name");
lf[587]=C_static_lambda_info(C_heaptop,13,"(a4335 ll472)");
lf[588]=C_static_lambda_info(C_heaptop,13,"(a5205 ll601)");
lf[589]=C_h_intern(&lf[589],6,"filter");
lf[590]=C_static_lambda_info(C_heaptop,12,"(procedures)");
lf[591]=C_static_string(C_heaptop,17,"/* end of file */");
lf[592]=C_h_intern(&lf[592],31,"generate-foreign-callback-stubs");
lf[593]=C_h_intern(&lf[593],31,"\010compilergenerate-foreign-stubs");
lf[594]=C_h_intern(&lf[594],29,"\010compilerforeign-lambda-stubs");
lf[595]=C_h_intern(&lf[595],36,"\010compilergenerate-external-variables");
lf[596]=C_h_intern(&lf[596],27,"\010compilerexternal-variables");
lf[597]=C_h_intern(&lf[597],1,"p");
lf[598]=C_static_string(C_heaptop,24,"code generation phase...");
lf[599]=C_static_lambda_info(C_heaptop,99,"(##compiler#generate-code literals19 lambdas20 out21 source-file22 dynamic23 db2"
"4 file-partition25)");
lf[600]=C_h_intern(&lf[600],11,"string-copy");
lf[601]=C_static_lambda_info(C_heaptop,11,"(loop i640)");
lf[602]=C_static_lambda_info(C_heaptop,25,"(##compiler#cleanup s636)");
lf[603]=C_static_string(C_heaptop,7,"C_word ");
lf[604]=C_static_lambda_info(C_heaptop,12,"(a5349 i653)");
lf[605]=C_h_intern(&lf[605],13,"list-tabulate");
lf[606]=C_static_lambda_info(C_heaptop,46,"(##compiler#make-variable-list n651 prefix652)");
lf[607]=C_static_lambda_info(C_heaptop,12,"(a5365 i656)");
lf[608]=C_static_lambda_info(C_heaptop,46,"(##compiler#make-argument-list n654 prefix655)");
lf[609]=C_static_string(C_heaptop,0,"");
lf[610]=C_static_string(C_heaptop,7,"static ");
lf[611]=C_static_lambda_info(C_heaptop,15,"(a5384 g658659)");
lf[612]=C_static_lambda_info(C_heaptop,48,"(##compiler#generate-external-variables vars657)");
lf[613]=C_h_intern(&lf[613],41,"\010compilergenerate-foreign-callback-header");
lf[614]=C_static_string(C_heaptop,15,"C_externexport ");
lf[615]=C_static_lambda_info(C_heaptop,15,"(a5432 stub668)");
lf[616]=C_static_lambda_info(C_heaptop,63,"(##compiler#generate-foreign-callback-stub-prototypes stubs667)");
lf[617]=C_static_string(C_heaptop,38,"C_k=C_restore_callback_continuation();");
lf[618]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[619]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[620]=C_static_string(C_heaptop,11,"return C_r;");
lf[621]=C_static_string(C_heaptop,13,"#undef return");
lf[622]=C_static_string(C_heaptop,9,"C_return:");
lf[623]=C_static_string(C_heaptop,38,"C_k=C_restore_callback_continuation();");
lf[624]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[625]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[626]=C_static_string(C_heaptop,11,"return C_r;");
lf[627]=C_static_string(C_heaptop,2,");");
lf[628]=C_static_string(C_heaptop,1,"t");
lf[629]=C_static_string(C_heaptop,4,"C_r=");
lf[630]=C_static_string(C_heaptop,51,"int C_dummy=C_save_callback_continuation(&C_a,C_k);");
lf[631]=C_static_string(C_heaptop,2,"=(");
lf[632]=C_static_string(C_heaptop,3,"C_a");
lf[633]=C_static_string(C_heaptop,2,");");
lf[634]=C_static_string(C_heaptop,0,"");
lf[635]=C_static_string(C_heaptop,3,"t~a");
lf[636]=C_static_lambda_info(C_heaptop,32,"(a5612 type688 index689 name690)");
lf[637]=C_static_string(C_heaptop,50,"C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[638]=C_static_string(C_heaptop,2,"){");
lf[639]=C_static_string(C_heaptop,10,") C_noret;");
lf[640]=C_static_string(C_heaptop,12,"static void ");
lf[641]=C_static_string(C_heaptop,37,"(C_word C_c,C_word C_self,C_word C_k,");
lf[642]=C_static_string(C_heaptop,12,") C_regparm;");
lf[643]=C_static_string(C_heaptop,32,"C_regparm static C_word C_fcall ");
lf[644]=C_static_string(C_heaptop,12,"static void ");
lf[645]=C_static_string(C_heaptop,37,"(C_word C_c,C_word C_self,C_word C_k,");
lf[646]=C_static_string(C_heaptop,22,"static C_word C_fcall ");
lf[647]=C_static_string(C_heaptop,34,"#define return(x) C_cblock C_r = (");
lf[648]=C_static_string(C_heaptop,33,"(x))); goto C_return; C_cblockend");
lf[649]=C_static_string(C_heaptop,8,"/* from ");
lf[650]=C_static_string(C_heaptop,3," */");
lf[651]=C_h_intern(&lf[651],21,"foreign-stub-callback");
lf[652]=C_h_intern(&lf[652],16,"foreign-stub-cps");
lf[653]=C_static_string(C_heaptop,3,"C_a");
lf[654]=C_h_intern(&lf[654],27,"foreign-stub-argument-names");
lf[655]=C_h_intern(&lf[655],17,"foreign-stub-body");
lf[656]=C_h_intern(&lf[656],17,"foreign-stub-name");
lf[657]=C_h_intern(&lf[657],24,"foreign-stub-return-type");
lf[658]=C_static_string(C_heaptop,12,"C_word C_buf");
lf[659]=C_static_string(C_heaptop,3,"C_a");
lf[660]=C_h_intern(&lf[660],27,"foreign-stub-argument-types");
lf[661]=C_h_intern(&lf[661],19,"\010compilerreal-name2");
lf[662]=C_h_intern(&lf[662],15,"foreign-stub-id");
lf[663]=C_static_lambda_info(C_heaptop,15,"(a5450 stub673)");
lf[664]=C_static_lambda_info(C_heaptop,50,"(##compiler#generate-foreign-stubs stubs671 db672)");
lf[665]=C_h_intern(&lf[665],5,"float");
lf[666]=C_static_string(C_heaptop,2,"+3");
lf[667]=C_h_intern(&lf[667],8,"c-string");
lf[668]=C_h_intern(&lf[668],9,"c-string*");
lf[669]=C_static_string(C_heaptop,4,"+2+(");
lf[670]=C_static_string(C_heaptop,33,"==NULL\0771:C_bytestowords(C_strlen(");
lf[671]=C_static_string(C_heaptop,3,")))");
lf[672]=C_h_intern(&lf[672],16,"nonnull-c-string");
lf[673]=C_static_string(C_heaptop,27,"+2+C_bytestowords(C_strlen(");
lf[674]=C_static_string(C_heaptop,2,"))");
lf[675]=C_h_intern(&lf[675],3,"ref");
lf[676]=C_static_string(C_heaptop,2,"+3");
lf[677]=C_h_intern(&lf[677],5,"const");
lf[678]=C_h_intern(&lf[678],7,"pointer");
lf[679]=C_h_intern(&lf[679],9,"c-pointer");
lf[680]=C_h_intern(&lf[680],15,"nonnull-pointer");
lf[681]=C_h_intern(&lf[681],8,"function");
lf[682]=C_h_intern(&lf[682],8,"instance");
lf[683]=C_h_intern(&lf[683],16,"nonnull-instance");
lf[684]=C_h_intern(&lf[684],12,"instance-ref");
lf[685]=C_h_intern(&lf[685],18,"\003syshash-table-ref");
lf[686]=C_h_intern(&lf[686],27,"\010compilerforeign-type-table");
lf[687]=C_h_intern(&lf[687],17,"nonnull-c-string*");
lf[688]=C_h_intern(&lf[688],6,"symbol");
lf[689]=C_h_intern(&lf[689],6,"double");
lf[690]=C_h_intern(&lf[690],16,"unsigned-integer");
lf[691]=C_h_intern(&lf[691],4,"long");
lf[692]=C_h_intern(&lf[692],7,"integer");
lf[693]=C_h_intern(&lf[693],13,"unsigned-long");
lf[694]=C_h_intern(&lf[694],17,"nonnull-c-pointer");
lf[695]=C_h_intern(&lf[695],6,"number");
lf[696]=C_h_intern(&lf[696],3,"int");
lf[697]=C_h_intern(&lf[697],5,"short");
lf[698]=C_h_intern(&lf[698],14,"unsigned-short");
lf[699]=C_h_intern(&lf[699],13,"scheme-object");
lf[700]=C_h_intern(&lf[700],13,"unsigned-char");
lf[701]=C_h_intern(&lf[701],12,"unsigned-int");
lf[702]=C_h_intern(&lf[702],4,"byte");
lf[703]=C_h_intern(&lf[703],13,"unsigned-byte");
lf[704]=C_static_lambda_info(C_heaptop,35,"(compute-size type720 var721 ns722)");
lf[705]=C_static_string(C_heaptop,2,";}");
lf[706]=C_static_string(C_heaptop,27,"C_callback_wrapper((void *)");
lf[707]=C_static_string(C_heaptop,7,"return ");
lf[708]=C_static_string(C_heaptop,2,"x=");
lf[709]=C_static_string(C_heaptop,2,");");
lf[710]=C_static_string(C_heaptop,10,"C_save(x);");
lf[711]=C_static_string(C_heaptop,1,"a");
lf[712]=C_static_lambda_info(C_heaptop,17,"(a6013 v787 t788)");
lf[713]=C_static_string(C_heaptop,34,"C_callback_adjust_stack_limits(a);");
lf[714]=C_static_string(C_heaptop,21,"C_word x, *a=C_alloc(");
lf[715]=C_static_string(C_heaptop,2,");");
lf[716]=C_static_string(C_heaptop,0,"");
lf[717]=C_static_string(C_heaptop,8,"/* from ");
lf[718]=C_static_string(C_heaptop,3," */");
lf[719]=C_static_string(C_heaptop,1,"0");
lf[720]=C_static_string(C_heaptop,1,"t");
lf[721]=C_h_intern(&lf[721],36,"foreign-callback-stub-argument-types");
lf[722]=C_h_intern(&lf[722],33,"foreign-callback-stub-return-type");
lf[723]=C_h_intern(&lf[723],24,"foreign-callback-stub-id");
lf[724]=C_static_lambda_info(C_heaptop,15,"(a5683 stub712)");
lf[725]=C_static_lambda_info(C_heaptop,48,"(generate-foreign-callback-stubs stubs710 db711)");
lf[726]=C_static_lambda_info(C_heaptop,19,"(a6060 vs807 ts808)");
lf[727]=C_static_string(C_heaptop,0,"");
lf[728]=C_static_string(C_heaptop,1,"t");
lf[729]=C_h_intern(&lf[729],32,"foreign-callback-stub-qualifiers");
lf[730]=C_h_intern(&lf[730],26,"foreign-callback-stub-name");
lf[731]=C_static_lambda_info(C_heaptop,60,"(##compiler#generate-foreign-callback-header cls799 stub800)");
lf[732]=C_h_intern(&lf[732],4,"quit");
lf[733]=C_static_string(C_heaptop,25,"illegal foreign type `~A\047");
lf[734]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[735]=C_static_string(C_heaptop,1," ");
lf[736]=C_static_lambda_info(C_heaptop,11,"(str ts816)");
lf[737]=C_static_string(C_heaptop,6,"C_word");
lf[738]=C_static_string(C_heaptop,4,"char");
lf[739]=C_static_string(C_heaptop,13,"unsigned char");
lf[740]=C_static_string(C_heaptop,12,"unsigned int");
lf[741]=C_static_string(C_heaptop,3,"int");
lf[742]=C_static_string(C_heaptop,5,"short");
lf[743]=C_static_string(C_heaptop,4,"long");
lf[744]=C_static_string(C_heaptop,14,"unsigned short");
lf[745]=C_static_string(C_heaptop,13,"unsigned long");
lf[746]=C_static_string(C_heaptop,5,"float");
lf[747]=C_static_string(C_heaptop,6,"double");
lf[748]=C_static_string(C_heaptop,12,"unsigned int");
lf[749]=C_static_string(C_heaptop,6,"void *");
lf[750]=C_h_intern(&lf[750],11,"byte-vector");
lf[751]=C_static_string(C_heaptop,15,"unsigned char *");
lf[752]=C_h_intern(&lf[752],9,"u16vector");
lf[753]=C_h_intern(&lf[753],17,"nonnull-u16vector");
lf[754]=C_static_string(C_heaptop,16,"unsigned short *");
lf[755]=C_h_intern(&lf[755],8,"s8vector");
lf[756]=C_h_intern(&lf[756],16,"nonnull-s8vector");
lf[757]=C_static_string(C_heaptop,6,"char *");
lf[758]=C_h_intern(&lf[758],9,"u32vector");
lf[759]=C_h_intern(&lf[759],17,"nonnull-u32vector");
lf[760]=C_static_string(C_heaptop,14,"unsigned int *");
lf[761]=C_h_intern(&lf[761],9,"s16vector");
lf[762]=C_h_intern(&lf[762],17,"nonnull-s16vector");
lf[763]=C_static_string(C_heaptop,7,"short *");
lf[764]=C_h_intern(&lf[764],9,"s32vector");
lf[765]=C_h_intern(&lf[765],17,"nonnull-s32vector");
lf[766]=C_static_string(C_heaptop,5,"int *");
lf[767]=C_h_intern(&lf[767],9,"f32vector");
lf[768]=C_h_intern(&lf[768],17,"nonnull-f32vector");
lf[769]=C_static_string(C_heaptop,7,"float *");
lf[770]=C_h_intern(&lf[770],9,"f64vector");
lf[771]=C_h_intern(&lf[771],17,"nonnull-f64vector");
lf[772]=C_static_string(C_heaptop,8,"double *");
lf[773]=C_static_string(C_heaptop,6,"char *");
lf[774]=C_static_string(C_heaptop,4,"void");
lf[775]=C_static_lambda_info(C_heaptop,6,"(g884)");
lf[776]=C_static_string(C_heaptop,1,"*");
lf[777]=C_static_lambda_info(C_heaptop,15,"(g881 cname889)");
lf[778]=C_static_string(C_heaptop,1,"*");
lf[779]=C_static_lambda_info(C_heaptop,15,"(g871 ptype891)");
lf[780]=C_static_string(C_heaptop,1,"&");
lf[781]=C_h_intern(&lf[781],8,"template");
lf[782]=C_static_string(C_heaptop,1,"<");
lf[783]=C_static_string(C_heaptop,2,"> ");
lf[784]=C_h_intern(&lf[784],18,"string-intersperse");
lf[785]=C_static_string(C_heaptop,1,",");
lf[786]=C_static_string(C_heaptop,0,"");
lf[787]=C_static_lambda_info(C_heaptop,15,"(a6640 g895896)");
lf[788]=C_static_string(C_heaptop,0,"");
lf[789]=C_static_string(C_heaptop,6,"const ");
lf[790]=C_h_intern(&lf[790],6,"struct");
lf[791]=C_static_string(C_heaptop,7,"struct ");
lf[792]=C_static_string(C_heaptop,1," ");
lf[793]=C_h_intern(&lf[793],5,"union");
lf[794]=C_static_string(C_heaptop,6,"union ");
lf[795]=C_static_string(C_heaptop,1," ");
lf[796]=C_h_intern(&lf[796],4,"enum");
lf[797]=C_static_string(C_heaptop,5,"enum ");
lf[798]=C_static_string(C_heaptop,1," ");
lf[799]=C_static_string(C_heaptop,1,"&");
lf[800]=C_static_string(C_heaptop,0,"");
lf[801]=C_static_string(C_heaptop,3," (*");
lf[802]=C_static_string(C_heaptop,2,")(");
lf[803]=C_static_string(C_heaptop,1,")");
lf[804]=C_static_string(C_heaptop,1,",");
lf[805]=C_h_intern(&lf[805],3,"...");
lf[806]=C_static_string(C_heaptop,3,"...");
lf[807]=C_static_string(C_heaptop,0,"");
lf[808]=C_static_lambda_info(C_heaptop,13,"(a6996 at909)");
lf[809]=C_static_string(C_heaptop,0,"");
lf[810]=C_h_intern(&lf[810],19,"nonnull-byte-vector");
lf[811]=C_h_intern(&lf[811],8,"u8vector");
lf[812]=C_h_intern(&lf[812],16,"nonnull-u8vector");
lf[813]=C_h_intern(&lf[813],14,"scheme-pointer");
lf[814]=C_h_intern(&lf[814],22,"nonnull-scheme-pointer");
lf[815]=C_static_lambda_info(C_heaptop,55,"(##compiler#foreign-type-declaration type812 target813)");
lf[816]=C_static_string(C_heaptop,34,"illegal foreign argument type `~A\047");
lf[817]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[818]=C_static_string(C_heaptop,1,"(");
lf[819]=C_static_string(C_heaptop,25,"C_character_code((C_word)");
lf[820]=C_static_string(C_heaptop,8,"C_unfix(");
lf[821]=C_static_string(C_heaptop,8,"C_unfix(");
lf[822]=C_static_string(C_heaptop,24,"(unsigned short)C_unfix(");
lf[823]=C_static_string(C_heaptop,23,"C_num_to_unsigned_long(");
lf[824]=C_static_string(C_heaptop,11,"C_c_double(");
lf[825]=C_static_string(C_heaptop,13,"C_num_to_int(");
lf[826]=C_static_string(C_heaptop,14,"C_num_to_long(");
lf[827]=C_static_string(C_heaptop,22,"C_num_to_unsigned_int(");
lf[828]=C_static_string(C_heaptop,23,"C_data_pointer_or_null(");
lf[829]=C_static_string(C_heaptop,15,"C_data_pointer(");
lf[830]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[831]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[832]=C_static_string(C_heaptop,23,"C_c_bytevector_or_null(");
lf[833]=C_static_string(C_heaptop,15,"C_c_bytevector(");
lf[834]=C_static_string(C_heaptop,21,"C_c_u8vector_or_null(");
lf[835]=C_static_string(C_heaptop,13,"C_c_u8vector(");
lf[836]=C_static_string(C_heaptop,22,"C_c_u16vector_or_null(");
lf[837]=C_static_string(C_heaptop,14,"C_c_u16vector(");
lf[838]=C_static_string(C_heaptop,22,"C_c_u32vector_or_null(");
lf[839]=C_static_string(C_heaptop,14,"C_c_u32vector(");
lf[840]=C_static_string(C_heaptop,21,"C_c_s8vector_or_null(");
lf[841]=C_static_string(C_heaptop,13,"C_c_s8vector(");
lf[842]=C_static_string(C_heaptop,22,"C_c_s16vector_or_null(");
lf[843]=C_static_string(C_heaptop,14,"C_c_s16vector(");
lf[844]=C_static_string(C_heaptop,22,"C_c_s32vector_or_null(");
lf[845]=C_static_string(C_heaptop,14,"C_c_s32vector(");
lf[846]=C_static_string(C_heaptop,22,"C_c_f32vector_or_null(");
lf[847]=C_static_string(C_heaptop,14,"C_c_f32vector(");
lf[848]=C_static_string(C_heaptop,22,"C_c_f64vector_or_null(");
lf[849]=C_static_string(C_heaptop,14,"C_c_f64vector(");
lf[850]=C_static_string(C_heaptop,17,"C_string_or_null(");
lf[851]=C_static_string(C_heaptop,11,"C_c_string(");
lf[852]=C_static_string(C_heaptop,8,"C_truep(");
lf[853]=C_static_lambda_info(C_heaptop,6,"(g949)");
lf[854]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[855]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[856]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[857]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[858]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[859]=C_static_string(C_heaptop,13,"C_num_to_int(");
lf[860]=C_static_string(C_heaptop,2,"*(");
lf[861]=C_static_string(C_heaptop,16,")C_c_pointer_nn(");
lf[862]=C_static_string(C_heaptop,1,"*");
lf[863]=C_static_string(C_heaptop,2,"*(");
lf[864]=C_static_string(C_heaptop,17,"*)C_c_pointer_nn(");
lf[865]=C_static_lambda_info(C_heaptop,48,"(##compiler#foreign-argument-conversion type910)");
lf[866]=C_static_string(C_heaptop,32,"illegal foreign return type `~A\047");
lf[867]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[868]=C_static_string(C_heaptop,25,"C_make_character((C_word)");
lf[869]=C_static_string(C_heaptop,14,"C_fix((C_word)");
lf[870]=C_static_string(C_heaptop,37,"C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[871]=C_static_string(C_heaptop,13,"C_fix((short)");
lf[872]=C_static_string(C_heaptop,21,"C_fix(0xffff&(C_word)");
lf[873]=C_static_string(C_heaptop,12,"C_fix((char)");
lf[874]=C_static_string(C_heaptop,19,"C_fix(0xff&(C_word)");
lf[875]=C_static_string(C_heaptop,13,"C_flonum(&~a,");
lf[876]=C_static_string(C_heaptop,13,"C_number(&~a,");
lf[877]=C_static_string(C_heaptop,22,"C_mpointer(&~a,(void*)");
lf[878]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~a,(void*)");
lf[879]=C_static_string(C_heaptop,17,"C_int_to_num(&~a,");
lf[880]=C_static_string(C_heaptop,26,"C_unsigned_int_to_num(&~a,");
lf[881]=C_static_string(C_heaptop,18,"C_long_to_num(&~a,");
lf[882]=C_static_string(C_heaptop,27,"C_unsigned_long_to_num(&~a,");
lf[883]=C_static_string(C_heaptop,10,"C_mk_bool(");
lf[884]=C_static_string(C_heaptop,9,"((C_word)");
lf[885]=C_static_lambda_info(C_heaptop,7,"(g1002)");
lf[886]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~a,(void*)");
lf[887]=C_static_lambda_info(C_heaptop,6,"(g999)");
lf[888]=C_static_string(C_heaptop,22,"C_mpointer(&~A,(void*)");
lf[889]=C_static_lambda_info(C_heaptop,6,"(g993)");
lf[890]=C_static_string(C_heaptop,23,"C_mpointer(&~A,(void*)&");
lf[891]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~A,(void*)");
lf[892]=C_static_string(C_heaptop,22,"C_mpointer(&~A,(void*)");
lf[893]=C_static_string(C_heaptop,23,"C_mpointer(&~A,(void*)&");
lf[894]=C_static_string(C_heaptop,22,"C_mpointer(&~a,(void*)");
lf[895]=C_static_string(C_heaptop,17,"C_int_to_num(&~a,");
lf[896]=C_static_lambda_info(C_heaptop,54,"(##compiler#foreign-result-conversion type968 dest969)");
lf[897]=C_h_intern(&lf[897],29,"\010compilerstring->c-identifier");
lf[898]=C_static_string(C_heaptop,8,"C_~X_~A_");
lf[899]=C_h_intern(&lf[899],6,"random");
lf[900]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,901);
t2=C_set_block_item(lf[0],0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=lf[6],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=lf[10],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8697,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8701,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  random */
t9=C_retrieve(lf[899]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8699 */
static void f_8701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 114  current-seconds */
t3=C_retrieve(lf[243]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8703 in k8699 */
static void f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  sprintf */
t2=C_retrieve(lf[425]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[898],((C_word*)t0)[2],t1);}

/* k8695 */
static void f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 113  ##compiler#string->c-identifier */
t2=C_retrieve(lf[897]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1086 */
static void f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=C_set_block_item(lf[14],0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1091,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=lf[599],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[578]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5255,a[2]=lf[602],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5344,a[2]=lf[606],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=lf[608],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[595]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5376,a[2]=lf[612],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=lf[616],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[593]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=lf[664],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[592]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=lf[725],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[613]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6031,a[2]=lf[731],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[182]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6096,a[2]=lf[815],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7217,a[2]=lf[865],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7990,a[2]=lf[896],tmp=(C_word)a,a+=3,tmp));
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_UNDEFINED);}

/* ##compiler#foreign-result-conversion in k1086 */
static void f_7990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7990,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7992,a[2]=t2,a[3]=lf[867],tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[38]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[700]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[868]);}
else{
t8=(C_word)C_eqp(t5,lf[696]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[869]);}
else{
t9=(C_word)C_eqp(t5,lf[701]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[870]);}
else{
t10=(C_word)C_eqp(t5,lf[697]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[871]);}
else{
t11=(C_word)C_eqp(t5,lf[698]);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[872]);}
else{
t12=(C_word)C_eqp(t5,lf[702]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[873]);}
else{
t13=(C_word)C_eqp(t5,lf[703]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[874]);}
else{
t14=(C_word)C_eqp(t5,lf[665]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[689]));
if(C_truep(t15)){
/* c-backend.scm: 1351 sprintf */
t16=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,lf[875],t3);}
else{
t16=(C_word)C_eqp(t5,lf[695]);
if(C_truep(t16)){
/* c-backend.scm: 1352 sprintf */
t17=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t1,lf[876],t3);}
else{
t17=(C_word)C_eqp(t5,lf[672]);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8071,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t17)){
t19=t18;
f_8071(t19,t17);}
else{
t19=(C_word)C_eqp(t5,lf[667]);
if(C_truep(t19)){
t20=t18;
f_8071(t20,t19);}
else{
t20=(C_word)C_eqp(t5,lf[694]);
if(C_truep(t20)){
t21=t18;
f_8071(t21,t20);}
else{
t21=(C_word)C_eqp(t5,lf[668]);
if(C_truep(t21)){
t22=t18;
f_8071(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[687]);
t23=t18;
f_8071(t23,(C_truep(t22)?t22:(C_word)C_eqp(t5,lf[688])));}}}}}}}}}}}}}}

/* k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8071,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1354 sprintf */
t2=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[877],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t2)){
/* c-backend.scm: 1355 sprintf */
t3=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[878],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t3)){
/* c-backend.scm: 1356 sprintf */
t4=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],lf[879],((C_word*)t0)[5]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[690]);
if(C_truep(t4)){
/* c-backend.scm: 1357 sprintf */
t5=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[880],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t5)){
/* c-backend.scm: 1358 sprintf */
t6=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[881],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[693]);
if(C_truep(t6)){
/* c-backend.scm: 1359 sprintf */
t7=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],lf[882],((C_word*)t0)[5]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[35]);
if(C_truep(t7)){
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[883]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[413]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[4],lf[699]));
if(C_truep(t9)){
t10=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[884]);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1363 ##sys#hash-table-ref */
t11=C_retrieve(lf[685]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve(lf[686]),((C_word*)t0)[3]);}
else{
t11=t10;
f_8137(2,t11,C_SCHEME_FALSE);}}}}}}}}}}

/* k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void f_8137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[72],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8137,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1365 ##compiler#foreign-result-conversion */
t4=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8160,a[2]=((C_word*)t0)[2],a[3]=lf[885],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8165,a[2]=((C_word*)t0)[4],a[3]=lf[887],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[4],a[3]=lf[889],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[680]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8192,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_8192(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_8192(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[694]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8228,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_8228(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_8228(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[675]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8264,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_8264(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_8264(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[682]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8299,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8299(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8299(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8299(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[683]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8347,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8347(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8347(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8347(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[684]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8395,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8395(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8395(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8395(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[677]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8443,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8443(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8443(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[678]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8478,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8478(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8478(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[679]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8514,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8514(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8514(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[681]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1367 sprintf */
t28=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[894],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1367 g1002 */
t26=t2;
f_8160(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8572,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[796]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8572(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8572(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8572(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1367 g1002 */
t5=t2;
f_8160(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1384 err */
t2=((C_word*)t0)[2];
f_7992(t2,((C_word*)t0)[5]);}}}

/* k8570 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 sprintf */
t3=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[895],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8512 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 g999 */
t3=((C_word*)t0)[4];
f_8165(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[3]);}}

/* k8476 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 g999 */
t3=((C_word*)t0)[4];
f_8165(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[3]);}}

/* k8441 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 ##compiler#foreign-result-conversion */
t3=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8393 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 sprintf */
t4=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[893],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8345 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 sprintf */
t4=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[892],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8297 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 sprintf */
t4=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[891],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8262 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1371 sprintf */
t3=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[890],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[4]);}}

/* k8226 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 g993 */
t3=((C_word*)t0)[4];
f_8170(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[3]);}}

/* k8190 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1367 g993 */
t3=((C_word*)t0)[4];
f_8170(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1367 g1002 */
t2=((C_word*)t0)[2];
f_8160(t2,((C_word*)t0)[3]);}}

/* g993 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8170,NULL,2,t0,t1);}
/* c-backend.scm: 1369 sprintf */
t2=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[888],((C_word*)t0)[2]);}

/* g999 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8165,NULL,2,t0,t1);}
/* c-backend.scm: 1380 sprintf */
t2=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[886],((C_word*)t0)[2]);}

/* g1002 in k8135 in k8069 in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_8160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8160,NULL,2,t0,t1);}
/* c-backend.scm: 1383 err */
t2=((C_word*)t0)[2];
f_7992(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1086 */
static void C_fcall f_7992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7992,NULL,2,t0,t1);}
/* c-backend.scm: 1342 quit */
t2=C_retrieve(lf[732]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[866],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1086 */
static void f_7217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7219,a[2]=t2,a[3]=lf[817],tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[699]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[818]);}
else{
t6=(C_word)C_eqp(t4,lf[38]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[700]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[819]);}
else{
t8=(C_word)C_eqp(t4,lf[702]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7247,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_7247(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[696]);
if(C_truep(t10)){
t11=t9;
f_7247(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[701]);
t12=t9;
f_7247(t12,(C_truep(t11)?t11:(C_word)C_eqp(t4,lf[703])));}}}}}

/* k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7247,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[820]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[821]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[822]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[693]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[823]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7274(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
t8=t6;
f_7274(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[665])));}}}}}}

/* k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7274,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[824]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[825]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[826]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[690]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[827]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[678]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[813]));
if(C_truep(t6)){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[828]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[814]));
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[829]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[830]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[831]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[750]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[832]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[810]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[833]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[811]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[834]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[812]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[835]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[752]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[836]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[753]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[837]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[758]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[838]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[759]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[839]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[755]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[840]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[756]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[841]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[761]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[842]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[762]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[843]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[764]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[844]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[765]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[845]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[767]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[846]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[768]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[847]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[770]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[848]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[771]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[849]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
t30=(C_truep(t29)?t29:(C_word)C_eqp(((C_word*)t0)[4],lf[668]));
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[850]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t31)){
t33=t32;
f_7448(t33,t31);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[687]);
t34=t32;
f_7448(t34,(C_truep(t33)?t33:(C_word)C_eqp(((C_word*)t0)[4],lf[688])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[851]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[35]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[852]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1321 ##sys#hash-table-ref */
t4=C_retrieve(lf[685]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[686]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7457(2,t4,C_SCHEME_FALSE);}}}}

/* k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7457,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1323 ##compiler#foreign-argument-conversion */
t4=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=lf[853],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[678]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7502,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7502(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7502(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[679]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7534,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7534(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7534(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[680]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7566(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7566(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[694]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7598,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7598(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7598(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[682]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7630,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7630(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7630(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7630(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[683]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7675,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7675(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7675(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7675(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[681]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[858]);}
else{
/* c-backend.scm: 1325 g949 */
t18=t2;
f_7480(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[677]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7745,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7745(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7745(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[796]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7780,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7780(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7780(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[675]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7812,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7812(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7812(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7845,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[684]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7845(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7845(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7845(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7845(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1325 g949 */
t3=t2;
f_7480(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1336 err */
t2=((C_word*)t0)[2];
f_7219(t2,((C_word*)t0)[4]);}}}

/* k7843 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1325 string-append */
t4=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[863],t2,lf[864]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7810 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7812,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7822,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1325 ##compiler#foreign-type-declaration */
t4=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[862]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7820 in k7810 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1325 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[860],t1,lf[861]);}

/* k7778 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[859]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7743 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1325 ##compiler#foreign-argument-conversion */
t3=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7673 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[857]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7628 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[856]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7596 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[855]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7564 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[855]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7532 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[854]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* k7500 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[854]);}
else{
/* c-backend.scm: 1325 g949 */
t2=((C_word*)t0)[2];
f_7480(t2,((C_word*)t0)[3]);}}

/* g949 in k7455 in k7446 in k7272 in k7245 in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7480,NULL,2,t0,t1);}
/* c-backend.scm: 1335 err */
t2=((C_word*)t0)[2];
f_7219(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1086 */
static void C_fcall f_7219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7219,NULL,2,t0,t1);}
/* c-backend.scm: 1283 quit */
t2=C_retrieve(lf[732]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[816],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1086 */
static void f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6096,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=t2,a[3]=lf[734],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6103,a[2]=t3,a[3]=lf[736],tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[699]);
if(C_truep(t7)){
/* c-backend.scm: 1211 str */
t8=t5;
f_6103(t8,t1,lf[737]);}
else{
t8=(C_word)C_eqp(t6,lf[38]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[702]));
if(C_truep(t9)){
/* c-backend.scm: 1212 str */
t10=t5;
f_6103(t10,t1,lf[738]);}
else{
t10=(C_word)C_eqp(t6,lf[700]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[703]));
if(C_truep(t11)){
/* c-backend.scm: 1213 str */
t12=t5;
f_6103(t12,t1,lf[739]);}
else{
t12=(C_word)C_eqp(t6,lf[701]);
if(C_truep(t12)){
/* c-backend.scm: 1214 str */
t13=t5;
f_6103(t13,t1,lf[740]);}
else{
t13=(C_word)C_eqp(t6,lf[696]);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6158,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t13)){
t15=t14;
f_6158(t15,t13);}
else{
t15=(C_word)C_eqp(t6,lf[692]);
t16=t14;
f_6158(t16,(C_truep(t15)?t15:(C_word)C_eqp(t6,lf[35])));}}}}}}

/* k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6158,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1215 str */
t2=((C_word*)t0)[7];
f_6103(t2,((C_word*)t0)[6],lf[741]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[697]);
if(C_truep(t2)){
/* c-backend.scm: 1216 str */
t3=((C_word*)t0)[7];
f_6103(t3,((C_word*)t0)[6],lf[742]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
if(C_truep(t3)){
/* c-backend.scm: 1217 str */
t4=((C_word*)t0)[7];
f_6103(t4,((C_word*)t0)[6],lf[743]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[698]);
if(C_truep(t4)){
/* c-backend.scm: 1218 str */
t5=((C_word*)t0)[7];
f_6103(t5,((C_word*)t0)[6],lf[744]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[693]);
if(C_truep(t5)){
/* c-backend.scm: 1219 str */
t6=((C_word*)t0)[7];
f_6103(t6,((C_word*)t0)[6],lf[745]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[665]);
if(C_truep(t6)){
/* c-backend.scm: 1220 str */
t7=((C_word*)t0)[7];
f_6103(t7,((C_word*)t0)[6],lf[746]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[689]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[5],lf[695]));
if(C_truep(t8)){
/* c-backend.scm: 1221 str */
t9=((C_word*)t0)[7];
f_6103(t9,((C_word*)t0)[6],lf[747]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[690]);
if(C_truep(t9)){
/* c-backend.scm: 1222 str */
t10=((C_word*)t0)[7];
f_6103(t10,((C_word*)t0)[6],lf[748]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[678]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t10)){
t12=t11;
f_6236(t12,t10);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[680]);
if(C_truep(t12)){
t13=t11;
f_6236(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
if(C_truep(t13)){
t14=t11;
f_6236(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
if(C_truep(t14)){
t15=t11;
f_6236(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[813]);
t16=t11;
f_6236(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[814])));}}}}}}}}}}}}}

/* k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6236,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1224 str */
t2=((C_word*)t0)[7];
f_6103(t2,((C_word*)t0)[6],lf[749]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[750]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6248(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[810]);
if(C_truep(t4)){
t5=t3;
f_6248(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[811]);
t6=t3;
f_6248(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[812])));}}}}

/* k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1225 str */
t2=((C_word*)t0)[7];
f_6103(t2,((C_word*)t0)[6],lf[751]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[752]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[753]));
if(C_truep(t3)){
/* c-backend.scm: 1226 str */
t4=((C_word*)t0)[7];
f_6103(t4,((C_word*)t0)[6],lf[754]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[755]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[756]));
if(C_truep(t5)){
/* c-backend.scm: 1227 str */
t6=((C_word*)t0)[7];
f_6103(t6,((C_word*)t0)[6],lf[757]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[758]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[759]));
if(C_truep(t7)){
/* c-backend.scm: 1228 str */
t8=((C_word*)t0)[7];
f_6103(t8,((C_word*)t0)[6],lf[760]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[761]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[762]));
if(C_truep(t9)){
/* c-backend.scm: 1229 str */
t10=((C_word*)t0)[7];
f_6103(t10,((C_word*)t0)[6],lf[763]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[764]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[765]));
if(C_truep(t11)){
/* c-backend.scm: 1230 str */
t12=((C_word*)t0)[7];
f_6103(t12,((C_word*)t0)[6],lf[766]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[767]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[768]));
if(C_truep(t13)){
/* c-backend.scm: 1231 str */
t14=((C_word*)t0)[7];
f_6103(t14,((C_word*)t0)[6],lf[769]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[770]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[771]));
if(C_truep(t15)){
/* c-backend.scm: 1232 str */
t16=((C_word*)t0)[7];
f_6103(t16,((C_word*)t0)[6],lf[772]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_6344(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[667]);
if(C_truep(t18)){
t19=t17;
f_6344(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[687]);
if(C_truep(t19)){
t20=t17;
f_6344(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[668]);
t21=t17;
f_6344(t21,(C_truep(t20)?t20:(C_word)C_eqp(((C_word*)t0)[5],lf[688])));}}}}}}}}}}}}

/* k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6344,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1233 str */
t2=((C_word*)t0)[7];
f_6103(t2,((C_word*)t0)[6],lf[773]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t2)){
/* c-backend.scm: 1234 str */
t3=((C_word*)t0)[7];
f_6103(t3,((C_word*)t0)[6],lf[774]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1236 ##sys#hash-table-ref */
t4=C_retrieve(lf[685]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[686]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6359(2,t4,C_SCHEME_FALSE);}}}}

/* k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1238 ##compiler#foreign-type-declaration */
t4=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1239 str */
t2=((C_word*)t0)[3];
f_6103(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[2],a[3]=lf[775],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[5],a[3]=lf[777],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[5],a[3]=lf[779],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[678]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6431,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6431(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6431(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[679]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6467,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6467(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6467(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[680]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6503,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6503(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6503(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[694]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6539,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6539(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6539(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[675]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6575,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6575(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6575(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[781]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6614,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6614(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6614(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[677]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6674,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6674(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6674(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[790]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6713,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6713(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6713(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[793]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6748,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6748(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6748(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[796]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6783,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6783(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6783(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[682]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6818,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6818(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6818(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6818(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[683]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6868,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6868(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6868(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6868(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[684]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6918,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6918(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6918(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6918(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6964,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[681]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6964(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6964(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6964(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1241 g884 */
t5=t2;
f_6391(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1277 err */
t2=((C_word*)t0)[2];
f_6098(t2,((C_word*)t0)[6]);}}}}

/* k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6964,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6980,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1241 ##compiler#foreign-type-declaration */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[809]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6978 in k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6984(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6984(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6984(t3,C_SCHEME_FALSE);}}

/* k6982 in k6978 in k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6984,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[800]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6995,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6997,a[2]=lf[808],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[432]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6996 in k6982 in k6978 in k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6997,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[805],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[806]);}
else{
/* c-backend.scm: 1241 ##compiler#foreign-type-declaration */
t4=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[807]);}}

/* k6993 in k6982 in k6978 in k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-intersperse */
t2=C_retrieve(lf[784]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[804]);}

/* k6989 in k6982 in k6978 in k6962 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[801],((C_word*)t0)[2],lf[802],t1,lf[803]);}

/* k6916 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1241 ->string */
t5=C_retrieve(lf[148]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6929 in k6916 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[799],((C_word*)t0)[2]);}

/* k6866 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g881 */
t4=((C_word*)t0)[4];
f_6396(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6816 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g881 */
t4=((C_word*)t0)[4];
f_6396(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6781 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 string-append */
t3=*((C_word*)lf[211]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[797],t2,lf[798],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6746 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 string-append */
t3=*((C_word*)lf[211]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[794],t2,lf[795],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6711 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 string-append */
t3=*((C_word*)lf[211]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[791],t2,lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6672 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6674,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1241 ##compiler#foreign-type-declaration */
t4=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6682 in k6672 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[789],t1);}

/* k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6614,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6631,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1241 ##compiler#foreign-type-declaration */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[788]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6629 in k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6635,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6641,a[2]=lf[787],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[432]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6640 in k6629 in k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6641,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[786]);}

/* k6637 in k6629 in k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-intersperse */
t2=C_retrieve(lf[784]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[785]);}

/* k6633 in k6629 in k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[782],t1,lf[783]);}

/* k6625 in k6612 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 str */
t2=((C_word*)t0)[3];
f_6103(t2,((C_word*)t0)[2],t1);}

/* k6573 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6585,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1245 string-append */
t4=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[780],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[4]);}}

/* k6583 in k6573 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1245 ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6537 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g871 */
t3=((C_word*)t0)[4];
f_6405(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6501 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g871 */
t3=((C_word*)t0)[4];
f_6405(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6465 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g871 */
t3=((C_word*)t0)[4];
f_6405(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* k6429 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1241 g871 */
t3=((C_word*)t0)[4];
f_6405(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1241 g884 */
t2=((C_word*)t0)[2];
f_6391(t2,((C_word*)t0)[3]);}}

/* g871 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6405,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6413,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1243 string-append */
t4=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[778],((C_word*)t0)[2]);}

/* k6411 in g871 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1243 ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g881 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6396,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1257 ->string */
t4=C_retrieve(lf[148]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6402 in g881 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1257 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[776],((C_word*)t0)[2]);}

/* g884 in k6357 in k6342 in k6246 in k6234 in k6156 in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6391,NULL,2,t0,t1);}
/* c-backend.scm: 1276 err */
t2=((C_word*)t0)[2];
f_6098(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6103,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1209 string-append */
t3=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[735],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1086 */
static void C_fcall f_6098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6098,NULL,2,t0,t1);}
/* c-backend.scm: 1208 quit */
t2=C_retrieve(lf[732]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[733],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1086 */
static void f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6031,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6035,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1190 foreign-callback-stub-name */
t5=C_retrieve(lf[730]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1191 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[729]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1192 foreign-callback-stub-return-type */
t3=C_retrieve(lf[722]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6044,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1193 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[721]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1195 ##compiler#make-argument-list */
t4=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[728]);}

/* k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1196 ##compiler#foreign-type-declaration */
t4=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[727]);}

/* k6092 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1196 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k6051 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6061,a[2]=lf[726],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1197 pair-for-each */
t4=C_retrieve(lf[208]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6060 in k6051 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6061,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6082,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1199 ##compiler#foreign-type-declaration */
t8=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k6080 in a6060 in k6051 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1199 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6063 in a6060 in k6051 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1200 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6054 in k6051 in k6048 in k6042 in k6039 in k6036 in k6033 in ##compiler#generate-foreign-callback-header in k1086 */
static void f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1202 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1086 */
static void f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=t3,a[3]=lf[724],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5684,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5688,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1141 foreign-callback-stub-id */
t4=C_retrieve(lf[723]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1142 ##compiler#real-name2 */
t3=C_retrieve(lf[661]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5694,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1143 foreign-callback-stub-return-type */
t3=C_retrieve(lf[722]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1144 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[721]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1146 ##compiler#make-argument-list */
t4=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[720]);}

/* k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5703,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5705,a[2]=t3,a[3]=lf[704],tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1169 fold */
t6=C_retrieve(lf[520]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[719],((C_word*)t0)[4],t1);}

/* k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1170 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1172 ##compiler#cleanup */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5972(2,t3,C_SCHEME_UNDEFINED);}}

/* k6027 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[717],t1,lf[718]);}

/* k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1173 ##compiler#generate-foreign-callback-header */
t3=C_retrieve(lf[613]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[716],((C_word*)t0)[2]);}

/* k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1174 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[714],((C_word*)t0)[2],lf[715]);}

/* k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1175 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[713]);}

/* k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6014,a[2]=lf[712],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1176 for-each */
t4=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6013 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_6014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6014,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1178 ##compiler#foreign-result-conversion */
t5=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[711]);}

/* k6020 in a6013 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1178 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[708],t1,((C_word*)t0)[2],lf[709],C_SCHEME_TRUE,lf[710]);}

/* k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[413],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5987(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1183 ##compiler#foreign-argument-conversion */
t5=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k6010 in k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1183 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[707],t1);}

/* k5985 in k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[706],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5988 in k5985 in k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[413],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5993(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1185 ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5991 in k5988 in k5985 in k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1186 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[705]);}

/* compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5705,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[38]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5715,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5715(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[696]);
if(C_truep(t8)){
t9=t7;
f_5715(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[697]);
if(C_truep(t9)){
t10=t7;
f_5715(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[35]);
if(C_truep(t10)){
t11=t7;
f_5715(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[413]);
if(C_truep(t11)){
t12=t7;
f_5715(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[698]);
if(C_truep(t12)){
t13=t7;
f_5715(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[699]);
if(C_truep(t13)){
t14=t7;
f_5715(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[700]);
if(C_truep(t14)){
t15=t7;
f_5715(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[701]);
if(C_truep(t15)){
t16=t7;
f_5715(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[702]);
t17=t7;
f_5715(t17,(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[703])));}}}}}}}}}}

/* k5713 in compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void C_fcall f_5715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5715,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[665]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5724(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[689]);
if(C_truep(t4)){
t5=t3;
f_5724(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
if(C_truep(t5)){
t6=t3;
f_5724(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[690]);
if(C_truep(t6)){
t7=t3;
f_5724(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
if(C_truep(t7)){
t8=t3;
f_5724(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[692]);
if(C_truep(t8)){
t9=t3;
f_5724(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[693]);
if(C_truep(t9)){
t10=t3;
f_5724(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
t11=t3;
f_5724(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[695])));}}}}}}}}}

/* k5722 in k5713 in compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void C_fcall f_5724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5724,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1152 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[666]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[667]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[668]));
if(C_truep(t3)){
/* c-backend.scm: 1154 string-append */
t4=*((C_word*)lf[211]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[7],((C_word*)t0)[6],lf[669],((C_word*)t0)[4],lf[670],((C_word*)t0)[4],lf[671]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_5748(t6,t4);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[687]);
t7=t5;
f_5748(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[688])));}}}}

/* k5746 in k5722 in k5713 in compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void C_fcall f_5748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5748,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1156 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[673],((C_word*)t0)[4],lf[674]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1158 ##sys#hash-table-ref */
t3=C_retrieve(lf[685]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[686]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5754(2,t3,C_SCHEME_FALSE);}}}

/* k5752 in k5746 in k5722 in k5713 in compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5754,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1160 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5705(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[675]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5788(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[678]);
if(C_truep(t5)){
t6=t4;
f_5788(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[679]);
if(C_truep(t6)){
t7=t4;
f_5788(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[680]);
if(C_truep(t7)){
t8=t4;
f_5788(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[681]);
if(C_truep(t8)){
t9=t4;
f_5788(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[682]);
if(C_truep(t9)){
t10=t4;
f_5788(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[683]);
t11=t4;
f_5788(t11,(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[684])));}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5786 in k5752 in k5746 in k5722 in k5713 in compute-size in k5701 in k5695 in k5692 in k5689 in k5686 in a5683 in generate-foreign-callback-stubs in k1086 */
static void C_fcall f_5788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1164 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[676]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1165 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5705(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1086 */
static void f_5445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5445,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5451,a[2]=t3,a[3]=lf[663],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5451,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1077 foreign-stub-id */
t4=C_retrieve(lf[662]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1078 ##compiler#real-name2 */
t3=C_retrieve(lf[661]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1079 foreign-stub-argument-types */
t3=C_retrieve(lf[660]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5676,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1081 ##compiler#make-variable-list */
t5=C_retrieve(lf[296]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[659]);}

/* k5674 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[658],t1);
/* c-backend.scm: 1081 intersperse */
t3=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1082 foreign-stub-return-type */
t3=C_retrieve(lf[657]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1083 foreign-stub-name */
t3=C_retrieve(lf[656]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1084 foreign-stub-body */
t3=C_retrieve(lf[655]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1085 foreign-stub-argument-names */
t3=C_retrieve(lf[654]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_5482(2,t3,t1);}
else{
/* c-backend.scm: 1085 make-list */
t3=C_retrieve(lf[258]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1086 ##compiler#foreign-result-conversion */
t3=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[653]);}

/* k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1087 foreign-stub-cps */
t3=C_retrieve(lf[652]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1088 foreign-stub-callback */
t3=C_retrieve(lf[651]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1089 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1091 ##compiler#cleanup */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5497(2,t3,C_SCHEME_UNDEFINED);}}

/* k5663 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1091 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[649],t1,lf[650]);}

/* k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1092 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[647],((C_word*)t0)[6],lf[648]);}
else{
t3=t2;
f_5500(2,t3,C_SCHEME_UNDEFINED);}}

/* k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1094 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[644],((C_word*)t0)[2],lf[645]);}
else{
/* c-backend.scm: 1095 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[646],((C_word*)t0)[2],C_make_character(40));}}

/* k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1098 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[639],C_SCHEME_TRUE,lf[640],((C_word*)t0)[2],lf[641]);}
else{
/* c-backend.scm: 1099 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[642],C_SCHEME_TRUE,lf[643],((C_word*)t0)[2],C_make_character(40));}}

/* k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1101 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[638]);}

/* k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1102 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[637]);}

/* k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5613,a[2]=lf[636],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1111 iota */
t5=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5641 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1103 for-each */
t2=*((C_word*)lf[82]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5612 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5613,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5621,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5633,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1108 symbol->string */
t7=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1108 sprintf */
t7=C_retrieve(lf[425]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[635],t3);}}

/* k5631 in a5612 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1106 ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5619 in a5612 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1109 ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[634]);}

/* k5623 in k5619 in a5612 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 ##compiler#foreign-argument-conversion */
t3=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5627 in k5623 in k5619 in a5612 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[631],((C_word*)t0)[3],C_make_character(41),t1,lf[632],((C_word*)t0)[2],lf[633]);}

/* k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1112 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[630]);}
else{
t3=t2;
f_5524(2,t3,C_SCHEME_UNDEFINED);}}

/* k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1114 ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[622]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t4)){
/* c-backend.scm: 1125 ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1124 ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[629],((C_word*)t0)[2]);}}}

/* k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1126 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5591,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5595,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1127 ##compiler#make-argument-list */
t5=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[628]);}

/* k5593 in k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1127 intersperse */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5589 in k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5558 in k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[413]);
if(C_truep(t3)){
t4=t2;
f_5563(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1128 ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5561 in k5558 in k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1129 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[627]);}

/* k5564 in k5561 in k5558 in k5555 in k5552 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1131 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[623],C_SCHEME_TRUE,lf[624]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1133 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[625]);}
else{
/* c-backend.scm: 1134 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[626]);}}}

/* k5531 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1116 ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[621],C_SCHEME_TRUE);}

/* k5534 in k5531 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1118 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[617],C_SCHEME_TRUE,lf[618]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1120 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[619]);}
else{
/* c-backend.scm: 1121 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[620]);}}}

/* k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5459 in k5456 in k5453 in a5450 in ##compiler#generate-foreign-stubs in k1086 */
static void f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1135 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1086 */
static void f_5427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5427,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5433,a[2]=lf[615],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a5432 in ##compiler#generate-foreign-callback-stub-prototypes in k1086 */
static void f_5433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5433,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5437,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1069 ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k5435 in a5432 in ##compiler#generate-foreign-callback-stub-prototypes in k1086 */
static void f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1070 ##compiler#generate-foreign-callback-header */
t3=C_retrieve(lf[613]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[614],((C_word*)t0)[2]);}

/* k5438 in k5435 in a5432 in ##compiler#generate-foreign-callback-stub-prototypes in k1086 */
static void f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1071 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1086 */
static void f_5376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5376,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5380,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1056 ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k5378 in ##compiler#generate-external-variables in k1086 */
static void f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5385,a[2]=lf[611],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5384 in k5378 in ##compiler#generate-external-variables in k1086 */
static void f_5385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5385,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5392,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_5392(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_5392(t4,C_SCHEME_FALSE);}}

/* k5390 in a5384 in k5378 in ##compiler#generate-external-variables in k1086 */
static void C_fcall f_5392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5392,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[609]:lf[610]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5412,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1060 ##compiler#foreign-type-declaration */
t7=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[241]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k5410 in k5390 in a5384 in k5378 in ##compiler#generate-external-variables in k1086 */
static void f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1060 ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1086 */
static void f_5360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5360,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5366,a[2]=t3,a[3]=lf[607],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1048 list-tabulate */
t5=C_retrieve(lf[605]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a5365 in ##compiler#make-argument-list in k1086 */
static void f_5366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5366,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5374,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1050 number->string */
C_number_to_string(3,0,t3,t2);}

/* k5372 in a5365 in ##compiler#make-argument-list in k1086 */
static void f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1050 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1086 */
static void f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5350,a[2]=t3,a[3]=lf[604],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1043 list-tabulate */
t5=C_retrieve(lf[605]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a5349 in ##compiler#make-variable-list in k1086 */
static void f_5350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1045 number->string */
C_number_to_string(3,0,t3,t2);}

/* k5356 in a5349 in ##compiler#make-variable-list in k1086 */
static void f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1045 string-append */
t2=*((C_word*)lf[211]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[603],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1086 */
static void f_5255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5255,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5264,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=lf[601],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5264(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1086 */
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5264,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5280,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5293,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5293(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_5293(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_5293(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_5293(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_5293(t10,C_SCHEME_FALSE);}}}}}

/* k5291 in loop in ##compiler#cleanup in k1086 */
static void C_fcall f_5293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5293,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_5296(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5303,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1034 string-copy */
t4=C_retrieve(lf[600]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_5280(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k5301 in k5291 in loop in ##compiler#cleanup in k1086 */
static void f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5296(t3,t2);}

/* k5294 in k5291 in loop in ##compiler#cleanup in k1086 */
static void C_fcall f_5296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_5280(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k5278 in loop in ##compiler#cleanup in k1086 */
static void C_fcall f_5280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 1037 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5264(t3,((C_word*)t0)[2],t2);}

/* ##compiler#generate-code in k1086 */
static void f_1153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[93],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1153,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t3,a[3]=lf[31],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t8,a[3]=lf[33],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1204,a[2]=t9,a[3]=t10,a[4]=lf[210],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2703,a[2]=t5,a[3]=lf[244],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2867,a[2]=t10,a[3]=t8,a[4]=t2,a[5]=lf[256],tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=t3,a[3]=t10,a[4]=t8,a[5]=lf[301],tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3226,a[2]=t3,a[3]=t10,a[4]=lf[348],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=lf[351],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=t16,a[3]=lf[357],tmp=(C_word)a,a+=4,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=lf[359],tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3818,a[2]=t18,a[3]=t22,a[4]=t20,a[5]=t17,a[6]=lf[415],tmp=(C_word)a,a+=7,tmp));
t24=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t20,a[3]=lf[424],tmp=(C_word)a,a+=4,tmp));
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3514,a[2]=t2,a[3]=t10,a[4]=t20,a[5]=lf[428],tmp=(C_word)a,a+=6,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3561,a[2]=t18,a[3]=t27,a[4]=lf[437],tmp=(C_word)a,a+=5,tmp));
t29=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4330,a[2]=t3,a[3]=t7,a[4]=t27,a[5]=t25,a[6]=t2,a[7]=t10,a[8]=t11,a[9]=t8,a[10]=lf[590],tmp=(C_word)a,a+=11,tmp);
t30=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5222,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t7,a[6]=t15,a[7]=t29,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1007 ##compiler#debugging */
t31=C_retrieve(lf[579]);
((C_proc4)C_retrieve_proc(t31))(4,t31,t30,lf[597],lf[598]);}

/* k5220 in ##compiler#generate-code in k1086 */
static void f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1009 header */
t4=((C_word*)t0)[2];
f_2703(t4,t3);}

/* k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1010 declarations */
t3=((C_word*)t0)[2];
f_2867(t3,t2);}

/* k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1011 ##compiler#generate-external-variables */
t3=C_retrieve(lf[595]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[596]));}

/* k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1012 ##compiler#generate-foreign-stubs */
t3=C_retrieve(lf[593]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[594]),((C_word*)t0)[3]);}

/* k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1013 prototypes */
t3=((C_word*)t0)[2];
f_2920(t3,t2);}

/* k5236 in k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1014 generate-foreign-callback-stubs */
t3=C_retrieve(lf[592]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[216]),((C_word*)t0)[2]);}

/* k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1015 trampolines */
t3=((C_word*)t0)[2];
f_3226(t3,t2);}

/* k5242 in k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1016 ##compiler#setup-quick-namespace-list */
t3=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5245 in k5242 in k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1017 procedures */
t3=((C_word*)t0)[2];
f_4330(t3,t2);}

/* k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5220 in ##compiler#generate-code in k1086 */
static void f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 516  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[591],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4330,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=lf[587],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5204,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[9],a[3]=lf[588],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1000 filter */
t5=C_retrieve(lf[589]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5205 in procedures in ##compiler#generate-code in k1086 */
static void f_5206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5210,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1002 lambda-literal-partition */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5208 in a5205 in procedures in ##compiler#generate-code in k1086 */
static void f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,t1));}}

/* k5202 in procedures in ##compiler#generate-code in k1086 */
static void f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4336,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 814  lambda-literal-argument-count */
t4=C_retrieve(lf[299]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 815  lambda-literal-id */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 816  lambda-literal-partition */
t3=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4352,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_4352(t4,t2);}
else{
t4=((C_word*)t0)[12];
t5=t1;
t6=t3;
f_4352(t6,(C_word)C_eqp(t4,t5));}}

/* k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4352,NULL,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[13]:C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[13])){
t4=((C_word*)t0)[13];
t5=((C_word*)t0)[2];
t6=(C_word)C_eqp(t4,t5);
t7=t3;
f_4358(t7,(C_word)C_i_not(t6));}
else{
t4=t3;
f_4358(t4,C_SCHEME_FALSE);}}

/* k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4358,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 820  ##compiler#real-name */
t3=C_retrieve(lf[586]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4364,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 821  lambda-literal-allocated */
t3=C_retrieve(lf[291]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 822  lambda-literal-rest-argument */
t3=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}

/* k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 823  lambda-literal-customizable */
t5=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[11]);}

/* k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 824  lambda-literal-closure-size */
t4=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}
else{
t3=t2;
f_4373(t3,C_SCHEME_FALSE);}}

/* k5188 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4373(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4373,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[16],t2);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 826  ##compiler#make-variable-list */
t5=C_retrieve(lf[296]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[16],lf[585]);}

/* k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4382,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 827  ##compiler#make-argument-list */
t3=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[16],lf[584]);}

/* k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4385,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 828  intersperse */
t4=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 829  intersperse */
t4=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 830  lambda-literal-external */
t3=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 831  lambda-literal-looping */
t3=C_retrieve(lf[130]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 832  lambda-literal-direct */
t3=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}

/* k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 833  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[293]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[18]);}

/* k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm: 834  lambda-literal-temporaries */
t3=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[19]);}

/* k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=t1,a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
if(C_truep(C_retrieve(lf[223]))){
/* c-backend.scm: 836  string-append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[223]),lf[582]);}
else{
t3=t2;
f_4406(2,t3,lf[583]);}}

/* k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[6])){
/* c-backend.scm: 838  ##compiler#debugging */
t3=C_retrieve(lf[579]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[580],lf[581],((C_word*)t0)[16]);}
else{
t3=t2;
f_4409(2,t3,C_SCHEME_UNDEFINED);}}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* c-backend.scm: 839  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 840  ##compiler#cleanup */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5157 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 840  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[576],t1,lf[577],C_SCHEME_TRUE);}

/* k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],tmp=(C_word)a,a+=24,tmp);
t3=(C_word)C_eqp(lf[272],((C_word*)t0)[16]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5142,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 849  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[569]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[16],a[5]=t2,a[6]=((C_word*)t0)[17],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 842  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[573]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 843  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[574]);}
else{
/* c-backend.scm: 844  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[575]);}}}}

/* k5105 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[571]:lf[572]);
/* c-backend.scm: 845  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5108 in k5105 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 846  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[570]);}
else{
t3=t2;
f_5113(2,t3,C_SCHEME_UNDEFINED);}}

/* k5111 in k5108 in k5105 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1198(((C_word*)t0)[4]);
/* c-backend.scm: 847  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5140 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[223]))){
t3=t2;
f_5145(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 851  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[568]);}}

/* k5143 in k5140 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 852  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc14)C_retrieve_proc(t2))(14,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[563],C_SCHEME_TRUE,lf[564],C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],lf[566],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[567],((C_word*)t0)[2]);}

/* k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 856  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_4424(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 857  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[562]);}}

/* k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5079,a[2]=t2,a[3]=((C_word*)t0)[16],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[18],C_fix(0));
t5=t3;
f_5079(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5079(t4,C_SCHEME_FALSE);}}

/* k5077 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_5079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5079,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 859  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[561]);}
else{
t2=((C_word*)t0)[2];
f_4427(2,t2,C_SCHEME_UNDEFINED);}}

/* k5080 in k5077 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 860  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4427(2,t2,C_SCHEME_UNDEFINED);}}

/* k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[16]);}

/* k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm: 862  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[560]);}
else{
t3=t2;
f_4433(2,t3,C_SCHEME_UNDEFINED);}}

/* k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 863  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[559]);}

/* k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[263]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_FALSE);
t5=t2;
f_4439(t5,t4);}
else{
t4=t2;
f_4439(t4,C_SCHEME_UNDEFINED);}}

/* k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4439,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 865  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[558]);}

/* k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm: 867  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[555],((C_word*)t0)[21],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[21]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[17],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t6,a[3]=lf[557],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5041(t8,t2,((C_word*)t0)[21],t4);}}

/* do503 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_5041(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5041,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5051,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 871  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[556],t2,C_make_character(59));}}

/* k5049 in do503 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5041(t4,((C_word*)t0)[2],t2,t3);}

/* k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],a[17]=((C_word*)t0)[23],tmp=(C_word)a,a+=18,tmp);
t3=(C_word)C_eqp(lf[272],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[15],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4815,a[2]=t6,a[3]=lf[522],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4815(t8,t4,C_fix(0),C_retrieve(lf[18]));}
else{
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[18],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 916  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[536]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[18],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4984(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[18];
t8=t5;
f_4984(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4982 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4984,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 930  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[546],C_SCHEME_TRUE,lf[547],C_SCHEME_TRUE,lf[548],((C_word*)t0)[3],lf[549]);}
else{
/* c-backend.scm: 933  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[550],((C_word*)t0)[3],lf[551]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4996(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 935  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[554]);}}}

/* k4994 in k4982 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 936  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[553]);}
else{
t3=t2;
f_4999(2,t3,C_SCHEME_UNDEFINED);}}

/* k4997 in k4994 in k4982 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[134]);
t4=t2;
f_5005(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[507]))));}
else{
t3=t2;
f_5005(t3,C_SCHEME_FALSE);}}

/* k5003 in k4997 in k4994 in k4982 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_5005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 938  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[552]);}
else{
t2=((C_word*)t0)[2];
f_4906(2,t2,C_SCHEME_UNDEFINED);}}

/* k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4909,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4948,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[134]);
if(C_truep(t4)){
t5=t3;
f_4948(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[530]);
t6=t3;
f_4948(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4948(t4,C_SCHEME_FALSE);}}

/* k4946 in k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[263]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 942  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[540],((C_word*)t0)[3],lf[541],((C_word*)t0)[3],lf[542]);}
else{
t4=((C_word*)t0)[2];
f_4909(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 943  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[543],((C_word*)t0)[3],lf[544],((C_word*)t0)[3],lf[545]);}}
else{
t2=((C_word*)t0)[2];
f_4909(2,t2,C_SCHEME_UNDEFINED);}}

/* k4907 in k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4915(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4915(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4915(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4913 in k4907 in k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4915,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[525]))){
/* c-backend.scm: 945  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[539]);}
else{
t3=t2;
f_4918(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_4448(2,t2,C_SCHEME_UNDEFINED);}}

/* k4916 in k4913 in k4907 in k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4924(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4924(t3,C_SCHEME_FALSE);}}

/* k4922 in k4916 in k4913 in k4907 in k4904 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 947  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[537]);}
else{
/* c-backend.scm: 948  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[538]);}}

/* k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 917  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[535]);}

/* k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 918  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[534]);}

/* k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 920  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 921  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[533]);}}

/* k4849 in k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 922  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[531],((C_word*)t0)[3],lf[532]);}

/* k4852 in k4849 in k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[134]);
if(C_truep(t4)){
t5=t3;
f_4869(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[530]);
if(C_truep(t5)){
t6=t3;
f_4869(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4869(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4867 in k4852 in k4849 in k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 924  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[527],((C_word*)t0)[2],lf[528],((C_word*)t0)[2],lf[529]);}
else{
t2=((C_word*)t0)[3];
f_4857(2,t2,C_SCHEME_UNDEFINED);}}

/* k4855 in k4852 in k4849 in k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[525]))){
/* c-backend.scm: 925  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_4860(2,t3,C_SCHEME_UNDEFINED);}}

/* k4858 in k4855 in k4852 in k4849 in k4846 in k4843 in k4840 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 926  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[523],((C_word*)t0)[2],lf[524]);}

/* do509 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4815,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4825,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 876  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,lf[521],t2,C_make_character(59));}}

/* k4823 in do509 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4815(t4,((C_word*)t0)[2],t2,t3);}

/* k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=lf[519],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 877  fold */
t4=C_retrieve(lf[520]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,C_fix(0),((C_word*)t0)[8]);}

/* a4804 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 877  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3561(3,t5,t4,t2);}

/* k4811 in a4804 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4690,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 879  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[515],C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE,lf[517],((C_word*)t0)[2],lf[518]);}

/* k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4770,a[2]=t4,a[3]=lf[514],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4770(t6,t2,C_fix(0),C_retrieve(lf[18]));}

/* do519 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4770(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4770,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4780,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4795,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 886  caar */
t6=*((C_word*)lf[513]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k4793 in do519 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4799,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4803,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 886  cdar */
t4=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4801 in k4793 in do519 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 886  ##compiler#compute-namespace-size */
t2=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4797 in k4793 in do519 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 885  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[509],((C_word*)t0)[3],lf[510],((C_word*)t0)[2],lf[511],t1,lf[512]);}

/* k4778 in do519 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4770(t4,((C_word*)t0)[2],t2,t3);}

/* k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[507]))){
/* c-backend.scm: 888  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[508]);}
else{
t3=t2;
f_4696(2,t3,C_SCHEME_UNDEFINED);}}

/* k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[223]))){
t3=t2;
f_4699(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[500]))){
/* c-backend.scm: 891  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[501],C_retrieve(lf[500]),lf[502]);}
else{
if(C_truep(C_retrieve(lf[503]))){
/* c-backend.scm: 893  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[504],C_retrieve(lf[503]),lf[505],C_SCHEME_TRUE,lf[506]);}
else{
t4=t3;
f_4738(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4736 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[498]))){
/* c-backend.scm: 896  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[499],C_retrieve(lf[498]),C_make_character(59));}
else{
t3=t2;
f_4741(2,t3,C_SCHEME_UNDEFINED);}}

/* k4739 in k4736 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[496]))){
/* c-backend.scm: 898  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[497],C_retrieve(lf[496]),C_make_character(59));}
else{
t3=t2;
f_4744(2,t3,C_SCHEME_UNDEFINED);}}

/* k4742 in k4739 in k4736 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[493]))){
/* c-backend.scm: 900  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[494],C_retrieve(lf[493]),lf[495]);}
else{
t2=((C_word*)t0)[2];
f_4699(2,t2,C_SCHEME_UNDEFINED);}}

/* k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 901  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[486],((C_word*)t0)[3],lf[487],C_SCHEME_TRUE,lf[488],((C_word*)t0)[3],lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* k4700 in k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 906  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[480],((C_word*)t0)[2],lf[481],C_SCHEME_TRUE,lf[482],C_SCHEME_TRUE,lf[483],((C_word*)t0)[2],lf[484],C_SCHEME_TRUE,lf[485]);}

/* k4703 in k4700 in k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 910  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[478],((C_word*)t0)[2],lf[479]);}

/* k4706 in k4703 in k4700 in k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_4448(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 912  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t3,C_SCHEME_TRUE,lf[475],t4,lf[476],((C_word*)t0)[5],lf[477]);}}

/* k4715 in k4706 in k4703 in k4700 in k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 913  literal-frame */
t3=((C_word*)t0)[2];
f_3514(t3,t2);}

/* k4718 in k4715 in k4706 in k4703 in k4700 in k4697 in k4694 in k4691 in k4688 in k4682 in k4679 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1198(((C_word*)t0)[4]);
/* c-backend.scm: 914  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[3],C_SCHEME_TRUE,lf[472],t2,lf[473],((C_word*)t0)[2],lf[474]);}

/* k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],a[11]=t2,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
t4=(C_word)C_eqp(lf[272],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_4471(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_4471(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t6)){
t7=t3;
f_4471(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_4471(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[12];
t8=t3;
f_4471(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4471,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[463]:lf[464]);
/* c-backend.scm: 959  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[465],((C_word*)t0)[10],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[469]:lf[470]);
/* c-backend.scm: 985  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[471]);}}
else{
t2=((C_word*)t0)[11];
f_4451(2,t2,C_SCHEME_UNDEFINED);}}

/* k4616 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 987  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[467]);}
else{
t3=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 988  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)t0)[2],lf[468],t3,((C_word*)t0)[4]);}}

/* k4619 in k4616 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 990  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4624(2,t3,C_SCHEME_UNDEFINED);}}

/* k4631 in k4619 in k4616 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k4622 in k4619 in k4616 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 992  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[466]);}

/* k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[345]);
if(C_truep(t3)){
/* c-backend.scm: 960  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4480(2,t4,C_SCHEME_UNDEFINED);}}

/* k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 961  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[461],t3,((C_word*)t0)[5],lf[462]);}

/* k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 963  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4486(2,t3,C_SCHEME_UNDEFINED);}}

/* k4593 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 965  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[457],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],((C_word*)t0)[7],lf[460]);}

/* k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[452]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 969  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[453],((C_word*)t0)[7],lf[454]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[345]);
if(C_truep(t5)){
/* c-backend.scm: 970  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[455],((C_word*)t0)[7],lf[456]);}
else{
t6=t2;
f_4492(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 971  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,C_SCHEME_TRUE,t3,((C_word*)t0)[2],lf[451]);}

/* k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4564,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 972  ##compiler#make-argument-list */
t5=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[6],lf[450]);}

/* k4562 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 972  intersperse */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4558 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 973  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[448],((C_word*)t0)[6],lf[449]);}

/* k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4504,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 975  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[446],t3,((C_word*)t0)[2],lf[447]);}

/* k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 977  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[444],((C_word*)t0)[3],lf[445]);}

/* k4508 in k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 978  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[443]);}

/* k4511 in k4508 in k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t5,a[3]=lf[442],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4531(t7,t2,t3,((C_word*)t0)[2]);}

/* do561 in k4511 in k4508 in k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4531,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 982  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[441],t2,C_make_character(59));}}

/* k4539 in do561 in k4511 in k4508 in k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4531(t4,((C_word*)t0)[2],t2,t3);}

/* k4514 in k4511 in k4508 in k4505 in k4502 in k4499 in k4496 in k4493 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4469 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 983  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
t3=((C_word*)t0)[2];
f_4451(2,t3,C_SCHEME_UNDEFINED);}}

/* k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 994  lambda-literal-body */
t4=C_retrieve(lf[438]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4459 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 993  expression */
t3=((C_word*)t0)[4];
f_1204(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4350 in k4344 in k4341 in k4338 in a4335 in procedures in ##compiler#generate-code in k1086 */
static void f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 999  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1086 */
static void f_3561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 678  ##compiler#immediate? */
t4=C_retrieve(lf[436]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[429]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 682  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3561(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3632,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 683  vector->list */
t6=*((C_word*)lf[433]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 684  ##compiler#block-variable-literal? */
t3=C_retrieve(lf[414]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3640 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 685  bad-literal */
f_3555(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 687  ##sys#bytevector? */
t3=*((C_word*)lf[412]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3658 in k3640 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_permanentp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* c-backend.scm: 690  ##compiler#words */
t4=C_retrieve(lf[434]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t2,a[6]=lf[435],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3695(t7,((C_word*)t0)[4],C_fix(0),t3);}
else{
/* c-backend.scm: 697  bad-literal */
f_3555(((C_word*)t0)[4],((C_word*)t0)[5]);}}}

/* loop in k3658 in k3640 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3695,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3717,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 696  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3561(3,t8,t6,t7);}}

/* k3715 in loop in k3658 in k3640 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 696  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3695(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3671 in k3658 in k3640 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3634 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[432]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3630 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 683  reduce */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[431]+1),C_fix(0),t1);}

/* k3626 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3597 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3603,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 682  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3561(3,t4,t2,t3);}

/* k3601 in k3597 in k3566 in literal-size in ##compiler#generate-code in k1086 */
static void f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1086 */
static void C_fcall f_3514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3514,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=lf[427],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3520(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do385 in literal-frame in ##compiler#generate-code in k1086 */
static void C_fcall f_3520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3520,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3530,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3549,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=f_1198(((C_word*)t0)[2]);
/* c-backend.scm: 672  sprintf */
t8=C_retrieve(lf[425]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,lf[426],t7,t2);}}

/* k3547 in do385 in literal-frame in ##compiler#generate-code in k1086 */
static void f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 672  gen-lit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3818(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3528 in do385 in literal-frame in ##compiler#generate-code in k1086 */
static void f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3520(t4,((C_word*)t0)[2],t2,t3);}

/* gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4259,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t7,a[5]=t4,a[6]=t2,a[7]=t5,a[8]=lf[423],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_4268(t9,t1,C_fix(0),t5);}

/* do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4268,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 804  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,C_SCHEME_TRUE,((C_word*)t0)[6],C_make_character(61),((C_word*)t0)[5],C_make_character(40),((C_word*)t0)[7]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4310,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 808  gen-lit */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3818(t7,t5,t6,lf[422],C_SCHEME_FALSE);}}

/* k4308 in do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 809  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[421]);}

/* k4311 in k4308 in do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4268(t4,((C_word*)t0)[2],t2,t3);}

/* k4276 in do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4287,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=lf[420],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4287(t6,((C_word*)t0)[2],t2);}

/* do463 in k4276 in do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4287,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* c-backend.scm: 806  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t1,lf[416],C_SCHEME_TRUE,lf[417],((C_word*)t0)[3],lf[418]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4300,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 807  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[419],t2,C_make_character(41));}}

/* k4298 in do463 in k4276 in do459 in gen-vector-like-lit in ##compiler#generate-code in k1086 */
static void f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4287(t3,((C_word*)t0)[2],t2);}

/* gen-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_3818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3818,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnump(t2))){
t5=(C_word)C_eqp(lf[360],C_retrieve(lf[361]));
if(C_truep(t5)){
/* c-backend.scm: 717  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t6))(7,t6,t1,C_SCHEME_TRUE,t3,lf[362],t2,lf[363]);}
else{
/* c-backend.scm: 718  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t6))(7,t6,t1,C_SCHEME_TRUE,t3,lf[364],t2,lf[365]);}}
else{
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 719  ##compiler#block-variable-literal? */
t6=C_retrieve(lf[414]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 720  void */
t3=*((C_word*)lf[413]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],t1);
if(C_truep(t2)){
/* c-backend.scm: 721  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],C_SCHEME_TRUE,((C_word*)t0)[7],lf[366]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[9]))){
t3=(C_word)C_eqp(lf[367],C_retrieve(lf[361]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 724  ##sys#flo2fix */
t5=C_retrieve(lf[372]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 728  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[9]))){
t3=(C_truep(((C_word*)t0)[9])?lf[377]:lf[378]);
/* c-backend.scm: 733  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[8],C_SCHEME_TRUE,((C_word*)t0)[7],C_make_character(61),t3,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* c-backend.scm: 735  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[8],C_SCHEME_TRUE,((C_word*)t0)[7],lf[379],t3,lf[380]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* c-backend.scm: 737  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],C_SCHEME_TRUE,((C_word*)t0)[7],lf[381]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* c-backend.scm: 738  gen-string-like-lit */
t3=((C_word*)t0)[6];
f_4155(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9],lf[382],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[9]))){
/* c-backend.scm: 739  gen-string-like-lit */
t3=((C_word*)t0)[6];
f_4155(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9],lf[383],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
t5=t3;
f_3964(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_3964(t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* c-backend.scm: 756  gen-vector-like-lit */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4259(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9],lf[397]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 759  ##compiler#c-ify-string */
t5=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[9]))){
/* c-backend.scm: 770  bad-literal */
f_3555(((C_word*)t0)[8],((C_word*)t0)[9]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 771  ##sys#bytevector? */
t4=*((C_word*)lf[412]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}}}}}}}}}}}}

/* k4123 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
/* c-backend.scm: 773  gen-string-like-lit */
t2=((C_word*)t0)[6];
f_4155(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],lf[409],C_SCHEME_FALSE);}
else{
/* c-backend.scm: 774  gen-string-like-lit */
t2=((C_word*)t0)[6];
f_4155(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],lf[410],C_SCHEME_TRUE);}}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[7]))){
/* c-backend.scm: 775  gen-vector-like-lit */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4259(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],lf[411]);}
else{
/* c-backend.scm: 776  bad-literal */
f_3555(((C_word*)t0)[5],((C_word*)t0)[7]);}}}

/* k4078 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4086,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 761  ##compiler#namespace-lookup */
t4=C_retrieve(lf[20]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4084 in k4078 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 762  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[4],lf[408]);}

/* k4087 in k4084 in k4078 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[7])){
if(C_truep(((C_word*)t0)[6])){
/* c-backend.scm: 765  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],lf[398],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[399],((C_word*)t0)[7],lf[400]);}
else{
/* c-backend.scm: 766  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[401],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[402],((C_word*)t0)[7],lf[403]);}}
else{
if(C_truep(((C_word*)t0)[6])){
/* c-backend.scm: 768  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[404],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[405]);}
else{
/* c-backend.scm: 769  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],lf[406],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[407]);}}}

/* k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_3964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3964,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=lf[392],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3969(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 752  gen-lit */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3818(t4,t2,t3,lf[396],C_SCHEME_FALSE);}}

/* k4030 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 753  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[395]);}

/* k4033 in k4030 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 754  gen-lit */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3818(t4,t2,t3,lf[394],C_SCHEME_FALSE);}

/* k4036 in k4033 in k4030 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 755  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],lf[393]);}

/* do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3979,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 745  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,((C_word*)t0)[4],lf[389],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 749  gen-lit */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3818(t6,t4,t5,lf[391],C_SCHEME_FALSE);}}

/* k4009 in do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 750  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[390]);}

/* k4012 in k4009 in do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3969(t4,((C_word*)t0)[2],t2,t3);}

/* k3977 in do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=lf[388],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3988(t6,((C_word*)t0)[2],t2);}

/* do413 in k3977 in do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3988,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* c-backend.scm: 747  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t1,lf[384],C_SCHEME_TRUE,lf[385],((C_word*)t0)[3],lf[386]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4001,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 748  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[387],t2,C_make_character(41));}}

/* k3999 in do413 in k3977 in do409 in k3962 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3988(t3,((C_word*)t0)[2],t2);}

/* k3874 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(t1,C_fix(1));
t5=t2;
f_3882(t5,(C_word)C_u_i_char_alphabeticp(t4));}
else{
t4=t2;
f_3882(t4,C_SCHEME_FALSE);}}

/* k3880 in k3874 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_3882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 730  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3],lf[373],((C_word*)t0)[2],lf[374]);}
else{
/* c-backend.scm: 731  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3],lf[375],((C_word*)t0)[2],lf[376]);}}

/* k3865 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 725  warning */
t3=C_retrieve(lf[370]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[371],((C_word*)t0)[2],t1);}

/* k3868 in k3865 in k4151 in k3838 in gen-lit in ##compiler#generate-code in k1086 */
static void f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 726  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3],lf[368],((C_word*)t0)[2],lf[369]);}

/* bad-literal in ##compiler#generate-code in k1086 */
static void C_fcall f_3555(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3555,NULL,2,t1,t2);}
/* c-backend.scm: 675  ##compiler#bomb */
t3=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[358],t2);}

/* gen-string-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4155,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t3);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4162,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 780  fx/ */
t8=*((C_word*)lf[356]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,C_fix(80));}

/* k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 781  modulo */
t3=*((C_word*)lf[355]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(80));}

/* k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 782  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),((C_word*)t0)[2],C_make_character(40));}

/* k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 783  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[354]);}
else{
t3=t2;
f_4171(2,t3,C_SCHEME_UNDEFINED);}}

/* k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 784  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_make_character(44));}

/* k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4179,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=lf[353],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4179(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4179,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4189,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4198(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t9=t7;
f_4198(t9,(C_word)C_i_not(t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4219,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 791  string-like-substring */
f_4247(t7,((C_word*)t0)[4],t3,t8);}}

/* k4236 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 791  ##compiler#c-ify-string */
t2=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4232 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 791  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4217 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4179(t4,((C_word*)t0)[2],t2,t3);}

/* k4196 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void C_fcall f_4198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4198,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 789  string-like-substring */
f_4247(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
f_4189(2,t2,C_SCHEME_UNDEFINED);}}

/* k4207 in k4196 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 789  ##compiler#c-ify-string */
t2=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4203 in k4196 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 789  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4187 in do437 in k4172 in k4169 in k4166 in k4163 in k4160 in gen-string-like-lit in ##compiler#generate-code in k1086 */
static void f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 790  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[352]);}

/* string-like-substring in ##compiler#generate-code in k1086 */
static void C_fcall f_4247(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4247,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4254,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 795  make-string */
t7=*((C_word*)lf[350]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k4252 in string-like-substring in ##compiler#generate-code in k1086 */
static void f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4257,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 796  ##sys#copy-bytes */
t3=C_retrieve(lf[349]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k4255 in k4252 in string-like-substring in ##compiler#generate-code in k1086 */
static void f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3226,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=lf[308],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t8,a[3]=lf[328],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3343,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3391,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,a[6]=((C_word*)t0)[3],a[7]=lf[347],tmp=(C_word)a,a+=8,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3391,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3395,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 633  lambda-literal-argument-count */
t4=C_retrieve(lf[299]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 634  lambda-literal-rest-argument */
t5=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 635  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[293]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 636  lambda-literal-id */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 637  lambda-literal-customizable */
t3=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3512,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 638  lambda-literal-closure-size */
t4=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3410(t3,C_SCHEME_FALSE);}}

/* k3510 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3410(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3410,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[11])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,t3);
t5=t2;
f_3413(t5,t4);}
else{
t3=t2;
f_3413(t3,C_SCHEME_UNDEFINED);}}

/* k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 640  lambda-literal-direct */
t3=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3419,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[12])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 642  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[343],((C_word*)t0)[9],lf[344]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3457(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 649  lambda-literal-allocated */
t4=C_retrieve(lf[291]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3499 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3457(2,t3,t2);}
else{
/* c-backend.scm: 649  lambda-literal-external */
t3=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3455 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[263]);
t4=t2;
f_3463(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3463(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3461 in k3455 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3463,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[345]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 652  lset-adjoin */
t4=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[288]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 653  lset-adjoin */
t4=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[288]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 654  lset-adjoin */
t3=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[288]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3479 in k3461 in k3455 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3475 in k3461 in k3455 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3471 in k3461 in k3455 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 643  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[341],((C_word*)t0)[3],lf[342]);}

/* k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 644  restore */
f_3229(t2,((C_word*)((C_word*)t0)[5])[1]);}

/* k3429 in k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 645  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,C_SCHEME_TRUE,t3,((C_word*)t0)[2],C_make_character(40));}

/* k3432 in k3429 in k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 646  ##compiler#make-argument-list */
t3=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[340]);}

/* k3435 in k3432 in k3429 in k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 647  intersperse */
t4=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3445 in k3435 in k3432 in k3429 in k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k3438 in k3435 in k3432 in k3429 in k3426 in k3423 in k3417 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in a3390 in trampolines in ##compiler#generate-code in k1086 */
static void f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 648  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[339]);}

/* k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],a[3]=lf[338],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 658  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t4))(9,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[335],t2,lf[336],t2,lf[337]);}

/* k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 659  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[332],((C_word*)t0)[3],lf[333],((C_word*)t0)[3],lf[334]);}

/* k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 660  restore */
f_3229(t2,((C_word*)t0)[3]);}

/* k3370 in k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 661  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[331],((C_word*)t0)[2],C_make_character(44));}

/* k3373 in k3370 in k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 662  ##compiler#make-argument-list */
t5=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[330]);}

/* k3387 in k3373 in k3370 in k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 662  intersperse */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3383 in k3373 in k3370 in k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k3376 in k3373 in k3370 in k3367 in k3364 in a3361 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 663  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[329]);}

/* k3344 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 665  emitter */
t4=((C_word*)t0)[3];
f_3265(t4,t3,C_SCHEME_FALSE);}

/* k3358 in k3344 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3347 in k3344 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 666  emitter */
t3=((C_word*)t0)[2];
f_3265(t3,t2,C_SCHEME_TRUE);}

/* k3354 in k3347 in k3344 in k3341 in trampolines in ##compiler#generate-code in k1086 */
static void f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3265,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[327],tmp=(C_word)a,a+=5,tmp));}

/* f_3267 in emitter in trampolines in ##compiler#generate-code in k1086 */
static void f_3267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3267,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 611  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[326],t2,C_make_character(114));}

/* k3269 */
static void f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 612  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3274(2,t3,C_SCHEME_UNDEFINED);}}

/* k3272 in k3269 */
static void f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 613  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[324],((C_word*)t0)[4],lf[325]);}

/* k3275 in k3272 in k3269 */
static void f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 614  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[4],C_make_character(114));}

/* k3278 in k3275 in k3272 in k3269 */
static void f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 615  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3283(2,t3,C_SCHEME_UNDEFINED);}}

/* k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 616  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[319],((C_word*)t0)[4],lf[320],C_SCHEME_TRUE,lf[321],C_SCHEME_TRUE,lf[322],((C_word*)t0)[4],C_make_character(59));}

/* k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 619  restore */
f_3229(t2,((C_word*)t0)[4]);}

/* k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 620  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[318]);}

/* k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 622  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[316]);}
else{
/* c-backend.scm: 623  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[317]);}}

/* k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 624  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[315]);}

/* k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 625  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[314]);}
else{
t3=t2;
f_3301(2,t3,C_SCHEME_UNDEFINED);}}

/* k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 626  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[313]);}

/* k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[312]);}

/* k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3317,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3321,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 628  ##compiler#make-argument-list */
t6=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[311]);}

/* k3319 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 628  intersperse */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3315 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 */
static void f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 629  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[309]);}

/* restore in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3229(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3229,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3233,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=t6,a[3]=lf[307],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3242(t8,t3,t4,C_fix(0));}

/* do333 in restore in trampolines in ##compiler#generate-code in k1086 */
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3242,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3252,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 606  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[304],t2,lf[305],t3,lf[306]);}}

/* k3250 in do333 in restore in trampolines in ##compiler#generate-code in k1086 */
static void f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3242(t4,((C_word*)t0)[2],t2,t3);}

/* k3231 in restore in trampolines in ##compiler#generate-code in k1086 */
static void f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 607  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[302],((C_word*)t0)[2],lf[303]);}

/* prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_2920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2920,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 534  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[300],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2952,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 537  lambda-literal-argument-count */
t4=C_retrieve(lf[299]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 538  lambda-literal-customizable */
t3=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 539  lambda-literal-closure-size */
t4=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2958(t3,C_SCHEME_FALSE);}}

/* k3222 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2958(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_2958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2958,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[6]):((C_word*)t0)[6]);
/* c-backend.scm: 540  ##compiler#make-variable-list */
t5=C_retrieve(lf[296]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[297]);}

/* k3208 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 540  intersperse */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 541  lambda-literal-id */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 542  lambda-literal-partition */
t3=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2973,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=t3;
f_2973(t4,t2);}
else{
t4=((C_word*)t0)[10];
t5=t1;
t6=t3;
f_2973(t6,(C_word)C_eqp(t4,t5));}}

/* k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_2973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2973,NULL,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[11]:C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[11])){
t4=((C_word*)t0)[11];
t5=((C_word*)t0)[2];
t6=(C_word)C_eqp(t4,t5);
t7=t3;
f_2979(t7,(C_word)C_i_not(t6));}
else{
t4=t3;
f_2979(t4,C_SCHEME_FALSE);}}

/* k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_2979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2979,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 546  lambda-literal-rest-argument */
t3=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 547  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[293]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 548  lambda-literal-direct */
t3=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 549  lambda-literal-allocated */
t3=C_retrieve(lf[291]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=((C_word*)t0)[12];
t4=C_retrieve(lf[286]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[12]);
/* c-backend.scm: 551  lset-adjoin */
t7=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[288]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2994(t5,C_SCHEME_UNDEFINED);}}

/* k3190 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2994(t3,t2);}

/* k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_2994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2994,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 552  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[3],a[3]=lf[289],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3185,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 557  lambda-literal-callee-signatures */
t5=C_retrieve(lf[290]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3183 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3165 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3166,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[286]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 556  lset-adjoin */
t7=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[288]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3175 in a3165 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_eqp(lf[272],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[279]))){
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=t5;
f_3148(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[3],C_fix(0))));}
else{
t6=t5;
f_3148(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 559  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[283]);}
else{
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 560  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[284]);}
else{
/* c-backend.scm: 561  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[285]);}}}}

/* k3089 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[281]:lf[282]);
/* c-backend.scm: 562  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3092 in k3089 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 563  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[280]);}
else{
t3=t2;
f_3097(2,t3,C_SCHEME_UNDEFINED);}}

/* k3095 in k3092 in k3089 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1198(((C_word*)t0)[4]);
/* c-backend.scm: 564  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3146 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_3148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 567  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[278],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_3126(2,t2,C_SCHEME_UNDEFINED);}}

/* k3124 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 568  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[276]);}
else{
/* c-backend.scm: 569  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[277]);}}

/* k3127 in k3124 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[223]))){
/* c-backend.scm: 570  string-append */
t3=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[223]),lf[274]);}
else{
t3=t2;
f_3136(2,t3,lf[275]);}}

/* k3134 in k3127 in k3124 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 570  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[273],t1);}

/* k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 571  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3009(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 572  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[271]);}}

/* k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3063,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3063(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3063(t4,C_SCHEME_FALSE);}}

/* k3061 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void C_fcall f_3063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3063,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 574  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[270]);}
else{
t2=((C_word*)t0)[2];
f_3012(2,t2,C_SCHEME_UNDEFINED);}}

/* k3064 in k3061 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 575  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3012(2,t2,C_SCHEME_UNDEFINED);}}

/* k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[5]);}

/* k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 578  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[268]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 585  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3049 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3054(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 587  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[269]);}}

/* k3052 in k3049 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 588  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3019 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[263]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 581  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t3,C_SCHEME_TRUE,lf[266],t4,((C_word*)t0)[2],lf[267]);}}

/* k3028 in k3019 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k3031 in k3028 in k3019 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2971 in k2965 in k2962 in k2959 in k2956 in k2953 in k2950 in a2947 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 583  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[264],t2,lf[265]);}

/* k2925 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=lf[262],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2931 in k2925 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2932,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 592  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[260],t2,lf[261]);}

/* k2934 in a2931 in k2925 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 593  make-list */
t4=C_retrieve(lf[258]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[259]);}

/* k2944 in k2934 in a2931 in k2925 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k2937 in k2934 in a2931 in k2925 in k2922 in prototypes in ##compiler#generate-code in k1086 */
static void f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 594  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[257]);}

/* declarations in ##compiler#generate-code in k1086 */
static void C_fcall f_2867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2867,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 520  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k2872 in declarations in ##compiler#generate-code in k1086 */
static void f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=lf[255],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[232]));}

/* a2913 in k2872 in declarations in ##compiler#generate-code in k1086 */
static void f_2914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2914,3,t0,t1,t2);}
/* c-backend.scm: 522  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,C_SCHEME_TRUE,lf[253],t2,lf[254]);}

/* k2875 in k2872 in declarations in ##compiler#generate-code in k1086 */
static void f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
if(C_truep(t4)){
t5=f_1198(((C_word*)t0)[2]);
/* c-backend.scm: 528  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t6))(9,t6,((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[245],t5,lf[246],((C_word*)t0)[5],lf[247]);}
else{
t5=f_1198(((C_word*)t0)[2]);
/* c-backend.scm: 530  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t6))(9,t6,((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[248],t5,lf[249],((C_word*)t0)[5],lf[250]);}}
else{
/* c-backend.scm: 526  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[251],((C_word*)t0)[5],lf[252]);}}}

/* header in ##compiler#generate-code in k1086 */
static void C_fcall f_2703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2703,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=lf[213],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2723,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2859,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 490  current-seconds */
t5=C_retrieve(lf[243]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2857 in header in ##compiler#generate-code in k1086 */
static void f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 490  ##sys#decode-seconds */
t2=C_retrieve(lf[242]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2721 in header in ##compiler#generate-code in k1086 */
static void f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2729(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2729(t3,C_SCHEME_FALSE);}}

/* k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void C_fcall f_2729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2729,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2822,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 493  pad0 */
f_2706(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[241]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2820 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 493  pad0 */
f_2706(t2,((C_word*)t0)[2]);}

/* k2824 in k2820 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 493  pad0 */
f_2706(t2,((C_word*)t0)[2]);}

/* k2828 in k2824 in k2820 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2834,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 493  pad0 */
f_2706(t2,((C_word*)t0)[2]);}

/* k2832 in k2828 in k2824 in k2820 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2838,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 494  chicken-version */
t3=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2836 in k2832 in k2828 in k2824 in k2820 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 492  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[235],((C_word*)t0)[7],lf[236],C_SCHEME_TRUE,lf[237],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,lf[238],t1,C_SCHEME_TRUE,lf[239]);}

/* k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 496  ##compiler#gen-list */
t3=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[234]));}

/* k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 497  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[223]))){
/* c-backend.scm: 498  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[231],C_retrieve(lf[223]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 500  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[233]);}}

/* k2809 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 501  ##compiler#gen-list */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[232]));}

/* k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[223]))){
t3=t2;
f_2759(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[228]);
t5=(C_truep(t4)?t4:lf[229]);
/* c-backend.scm: 503  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,C_SCHEME_TRUE,lf[230],t5,C_SCHEME_TRUE);}}

/* k2793 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 504  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[226],C_retrieve(lf[227]),C_SCHEME_TRUE);}

/* k2796 in k2793 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 505  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[224],C_retrieve(lf[225]));}

/* k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 506  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[219],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[220],C_retrieve(lf[221]),lf[222]);}

/* k2760 in k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[214]))){
/* c-backend.scm: 508  ##compiler#generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[216]));}
else{
t3=t2;
f_2765(2,t3,C_SCHEME_UNDEFINED);}}

/* k2763 in k2760 in k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[217])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 510  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2768(2,t3,C_SCHEME_UNDEFINED);}}

/* k2778 in k2763 in k2760 in k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=lf[218],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[217]));}

/* a2784 in k2778 in k2763 in k2760 in k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2785,3,t0,t1,t2);}
/* c-backend.scm: 511  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2748 in k2745 in k2727 in k2721 in header in ##compiler#generate-code in k1086 */
static void f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[214]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 513  ##compiler#generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[216]));}}

/* pad0 in header in ##compiler#generate-code in k1086 */
static void C_fcall f_2706(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2706,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 488  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2718 in pad0 in header in ##compiler#generate-code in k1086 */
static void f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 488  string-append */
t2=*((C_word*)lf[211]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[212],t1);}

/* expression in ##compiler#generate-code in k1086 */
static void C_fcall f_1204(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1204,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[3],a[7]=lf[206],tmp=(C_word)a,a+=8,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=t6,a[3]=lf[209],tmp=(C_word)a,a+=4,tmp));
/* c-backend.scm: 483  expr */
t11=((C_word*)t6)[1];
f_1207(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_2671(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2671,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2677,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[207],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 477  pair-for-each */
t5=C_retrieve(lf[208]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2676 in expr-args in expression in ##compiler#generate-code in k1086 */
static void f_2677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2681(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 479  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2679 in a2676 in expr-args in expression in ##compiler#generate-code in k1086 */
static void f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 480  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_1207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word ab[213],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1207,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[34]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[35]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[36]:lf[37]);
/* c-backend.scm: 166  ##compiler#gen */
t15=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[38]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 167  ##compiler#gen */
t16=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[39],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[40]);
if(C_truep(t14)){
/* c-backend.scm: 168  ##compiler#gen */
t15=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[41]);}
else{
t15=(C_word)C_eqp(t11,lf[42]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 169  ##compiler#gen */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[43],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[44]);
if(C_truep(t16)){
/* c-backend.scm: 170  ##compiler#gen */
t17=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[45]);}
else{
/* c-backend.scm: 171  ##compiler#bomb */
t17=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[46]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[47]);
if(C_truep(t11)){
t12=f_1198(((C_word*)t0)[6]);
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 173  ##compiler#gen */
t14=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t14))(6,t14,t1,t12,lf[48],t13,C_make_character(93));}
else{
t12=(C_word)C_eqp(t9,lf[49]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1319,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 176  ##compiler#gen */
t14=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[52]);}
else{
t13=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
t15=(C_word)C_i_pairp(t14);
t16=(C_truep(t15)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t17=(C_truep(t16)?lf[54]:f_1198(((C_word*)t0)[6]));
t18=(C_word)C_i_car(t7);
/* c-backend.scm: 185  ##compiler#gen */
t19=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t19))(5,t19,t1,lf[55],t17,t18);}
else{
t14=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[5],a[3]=t17,a[4]=lf[57],tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_1397(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[58]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1448,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 199  ##compiler#gen */
t17=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[60]);}
else{
t16=(C_word)C_eqp(t9,lf[61]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  ##compiler#gen */
t18=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[63]);}
else{
t17=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1494,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 209  ##compiler#gen */
t19=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[65]);}
else{
t18=(C_word)C_eqp(t9,lf[66]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1527,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 216  ##compiler#gen */
t20=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[69]);}
else{
t19=(C_word)C_eqp(t9,lf[70]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1564,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 223  ##compiler#gen */
t21=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[72]);}
else{
t20=(C_word)C_eqp(t9,lf[73]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1593,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 230  ##compiler#gen */
t22=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[75]);}
else{
t21=(C_word)C_eqp(t9,lf[76]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1625,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 238  ##compiler#gen */
t24=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[84],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1660,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 248  ##compiler#gen */
t24=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[87]);}
else{
t23=(C_word)C_eqp(t9,lf[88]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 252  ##compiler#gen */
t25=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[89]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1692,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 255  ##compiler#gen */
t27=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
t28=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 264  ##compiler#gen */
t29=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t29))(6,t29,t1,t28,lf[91],t26,lf[92]);}
else{
t28=f_1198(((C_word*)t0)[6]);
t29=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1742,a[2]=t26,a[3]=t28,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t31=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 265  symbol->string */
t32=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t31);}}
else{
if(C_truep(t27)){
t28=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 266  ##compiler#gen */
t29=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t29))(7,t29,t1,lf[98],t28,lf[99],t26,lf[100]);}
else{
t28=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 267  ##compiler#gen */
t29=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t29))(7,t29,t1,lf[101],t28,lf[102],t26,lf[103]);}}}
else{
t26=(C_word)C_eqp(t9,lf[104]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1782,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
t30=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 273  ##compiler#gen */
t31=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t31))(7,t31,t29,lf[105],t30,lf[106],t27,lf[107]);}
else{
t30=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 274  ##compiler#gen */
t31=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t31))(7,t31,t29,lf[108],t30,lf[109],t27,lf[110]);}}
else{
t27=(C_word)C_eqp(t9,lf[111]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1824,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t30=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 282  ##compiler#gen */
t31=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t31))(6,t31,t29,t30,lf[112],t28,lf[113]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t30=f_1198(((C_word*)t0)[6]);
/* c-backend.scm: 286  ##compiler#gen */
t31=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t31))(7,t31,t29,lf[114],t30,lf[115],t28,lf[116]);}}
else{
t28=(C_word)C_eqp(t9,lf[117]);
if(C_truep(t28)){
/* c-backend.scm: 290  ##compiler#gen */
t29=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[118]);}
else{
t29=(C_word)C_eqp(t9,lf[119]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=t36,a[4]=t32,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=t31,a[8]=t33,a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t35)){
t38=(C_word)C_i_cddr(t7);
t39=(C_word)C_i_pairp(t38);
t40=t37;
f_1888(t40,(C_truep(t39)?(C_word)C_i_caddr(t7):C_SCHEME_FALSE));}
else{
t38=t37;
f_1888(t38,C_SCHEME_FALSE);}}
else{
t30=(C_word)C_eqp(t9,lf[154]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2224,a[2]=t34,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=t32,a[7]=t5,a[8]=t3,a[9]=((C_word*)t0)[5],a[10]=t31,a[11]=t1,a[12]=t33,tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 360  lambda-literal-closure-size */
t36=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[160]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_cadr(t7);
t36=(C_word)C_i_caddr(t7);
t37=(C_word)C_i_cadddr(t7);
t38=(C_word)C_eqp(t37,C_fix(0));
t39=(C_word)C_i_not(t38);
t40=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2316,a[2]=t36,a[3]=((C_word*)t0)[6],a[4]=t37,a[5]=t39,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t32,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 388  find-lambda */
t42=((C_word*)t0)[2];
f_1156(t42,t41,t36);}
else{
t32=(C_word)C_eqp(t9,lf[162]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2339,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 405  ##compiler#gen */
t37=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[164],t36,lf[165],t34,lf[166]);}
else{
t33=(C_word)C_eqp(t9,lf[167]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2358,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 410  ##compiler#gen */
t35=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[169]);}
else{
t34=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2377,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 415  ##compiler#gen */
t37=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[171],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[172]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2396,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 420  ##compiler#gen */
t39=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[173],t37,lf[174],t38);}
else{
t36=(C_word)C_eqp(t9,lf[175]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2432,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 428  ##compiler#foreign-result-conversion */
t39=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[177]);}
else{
t37=(C_word)C_eqp(t9,lf[178]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2470,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 432  ##compiler#foreign-type-declaration */
t42=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[183]);}
else{
t38=(C_word)C_eqp(t9,lf[184]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2486,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 438  ##compiler#foreign-result-conversion */
t42=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[189]);}
else{
t39=(C_word)C_eqp(t9,lf[190]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2516,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2544,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 444  ##compiler#foreign-type-declaration */
t43=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[195]);}
else{
t40=(C_word)C_eqp(t9,lf[196]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2553,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 451  ##compiler#gen */
t42=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[201]);}
else{
t41=(C_word)C_eqp(t9,lf[202]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2636,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 466  ##compiler#gen */
t43=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[204]);}
else{
/* c-backend.scm: 474  ##compiler#bomb */
t42=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[205]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 467  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2637 in k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 468  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[203]);}

/* k2640 in k2637 in k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 469  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2643 in k2640 in k2637 in k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 470  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2646 in k2643 in k2640 in k2637 in k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 471  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2649 in k2646 in k2643 in k2640 in k2637 in k2634 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 472  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 452  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1207(t4,t2,t3,((C_word*)t0)[3]);}

/* k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 453  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[200]);}

/* k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2572,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[199],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2572(t7,((C_word*)t0)[2],t2,t3);}

/* do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2572,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 457  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[197]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 460  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[198]);}}

/* k2593 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 461  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2596 in k2593 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 462  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2599 in k2596 in k2593 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 463  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2602 in k2599 in k2596 in k2593 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2572(t4,((C_word*)t0)[2],t2,t3);}

/* k2580 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 458  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2583 in k2580 in do225 in k2557 in k2554 in k2551 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 459  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2542 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 444  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[193],t1,lf[194]);}

/* k2514 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 445  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1207(t4,t2,t3,((C_word*)t0)[3]);}

/* k2517 in k2514 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 446  ##compiler#foreign-argument-conversion */
t4=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2534 in k2517 in k2514 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 446  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[192],t1);}

/* k2520 in k2517 in k2514 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 447  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2523 in k2520 in k2517 in k2514 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 448  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[191]);}

/* k2498 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2504,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 438  ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[188]);}

/* k2502 in k2498 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 438  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[186],t1,lf[187]);}

/* k2484 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 439  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2487 in k2484 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 440  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[185]);}

/* k2468 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 432  ##compiler#foreign-argument-conversion */
t3=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2472 in k2468 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 432  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[180],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2450 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 433  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2453 in k2450 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 434  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[179]);}

/* k2430 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 428  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2394 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 423  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2399(2,t3,C_SCHEME_UNDEFINED);}}

/* k2406 in k2394 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 424  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2671(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2397 in k2394 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 425  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2375 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 416  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2378 in k2375 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 417  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2356 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k2359 in k2356 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 412  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[168]);}

/* k2337 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 406  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2340 in k2337 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[163]);}

/* k2318 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 388  lambda-literal-closure-size */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 390  ##compiler#gen */
t6=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],C_make_character(40));}

/* k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2293,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 392  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[161],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2263(2,t3,C_SCHEME_UNDEFINED);}}

/* k2291 in k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 393  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2263(2,t4,C_SCHEME_UNDEFINED);}}

/* k2261 in k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2266(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 395  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2279 in k2261 in k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 396  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2266(2,t2,C_SCHEME_UNDEFINED);}}

/* k2264 in k2261 in k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 397  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2671(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2269(2,t3,C_SCHEME_UNDEFINED);}}

/* k2267 in k2264 in k2261 in k2258 in k2314 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 398  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[12])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 362  lambda-literal-temporaries */
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2204,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t4=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 375  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],C_make_character(40));}}

/* k2202 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2207(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 376  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[159]);}}

/* k2205 in k2202 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 377  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2208 in k2205 in k2202 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 378  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 363  iota */
t4=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[158],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 364  for-each */
t4=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2186 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2187,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 366  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2189 in a2186 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 367  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2192 in k2189 in a2186 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 368  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2167 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2177,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 372  iota */
t5=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2183 in k2167 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 370  for-each */
t2=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2176 in k2167 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2177,4,t0,t1,t2,t3);}
/* c-backend.scm: 371  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[156],t2,C_make_character(59));}

/* k2170 in k2167 in k2164 in k2161 in k2222 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 373  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[155]);}

/* k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_1888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1888,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 301  find-lambda */
t6=((C_word*)t0)[2];
f_1156(t6,t5,t1);}
else{
t4=t3;
f_1894(t4,C_SCHEME_FALSE);}}

/* k2111 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  lambda-literal-closure-size */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2107 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1894(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_1894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1894,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_retrieve(lf[142]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 150  ->string */
t6=C_retrieve(lf[148]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 151  ->string */
t6=C_retrieve(lf[148]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}
else{
t4=t3;
f_1900(2,t4,C_SCHEME_UNDEFINED);}}

/* k1194 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 151  string-translate* */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[152]);}

/* k2100 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 306  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[149],t1,lf[150]);}

/* k1184 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 150  string-translate */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[146],lf[147]);}

/* k2093 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 305  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t3=(C_word)C_eqp(lf[53],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(t4):C_SCHEME_FALSE);
t9=(C_truep(t8)?lf[121]:f_1198(((C_word*)t0)[11]));
t10=(C_word)C_i_car(t4);
/* c-backend.scm: 309  ##compiler#gen */
t11=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t11))(8,t11,t5,C_SCHEME_TRUE,t9,t10,C_make_character(40),((C_word*)t0)[10],lf[122]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 318  lambda-literal-id */
t6=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 344  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 345  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1207(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 346  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[140],((C_word*)t0)[4],lf[141]);}

/* k2052 in k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[134]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2069(t5,t3);}
else{
t5=C_retrieve(lf[139]);
t6=t4;
f_2069(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k2067 in k2052 in k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_2069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 349  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[135],((C_word*)t0)[2],lf[136]);}
else{
/* c-backend.scm: 350  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[137],((C_word*)t0)[2],lf[138]);}}

/* k2055 in k2052 in k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 351  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[132],((C_word*)t0)[3],lf[133],((C_word*)t0)[2],C_make_character(44));}

/* k2058 in k2055 in k2052 in k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 352  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 353  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[131]);}

/* k2043 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 319  lambda-literal-looping */
t3=C_retrieve(lf[130]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1951(2,t3,C_SCHEME_FALSE);}}

/* k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 320  lambda-literal-temporaries */
t3=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[15],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=t2;
f_2001(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[11],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 335  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[5],C_make_character(61));}}}

/* k2027 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2030 in k2027 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1999 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=f_1198(((C_word*)t0)[3]);
/* c-backend.scm: 338  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,C_SCHEME_TRUE,t3,((C_word*)t0)[2],C_make_character(40));}

/* k2002 in k1999 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_2007(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 339  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k2005 in k2002 in k1999 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_2010(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 340  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k2008 in k2005 in k2002 in k1999 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 341  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2011 in k2008 in k2005 in k2002 in k1999 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 342  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[129]);}

/* k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 321  iota */
t4=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[127],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 322  for-each */
t4=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1983 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1984,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 324  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1986 in a1983 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 325  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1989 in k1986 in a1983 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 326  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1958 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=lf[126],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 330  iota */
t5=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1980 in k1958 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 328  for-each */
t2=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1973 in k1958 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1974,4,t0,t1,t2,t3);}
/* c-backend.scm: 329  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[125],t2,C_make_character(59));}

/* k1961 in k1958 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1966(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 331  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[124],((C_word*)t0)[2],C_make_character(59));}}

/* k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[123]);}

/* k1910 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 315  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2671(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1913 in k1910 in k1898 in k1892 in k1886 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 316  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[120]);}

/* k1839 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 287  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1842 in k1839 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 288  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1822 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 283  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1825 in k1822 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 284  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1780 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 275  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1783 in k1780 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 276  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1744 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  ##compiler#c-ify-string */
t2=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1740 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],lf[93],((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,C_make_character(41));}

/* k1690 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 256  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1658 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 249  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1661 in k1658 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 250  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[86]);}

/* k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[81],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 244  iota */
t5=C_retrieve(lf[83]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1649 in k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  for-each */
t2=*((C_word*)lf[82]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1636 in k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 241  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[79],t3,lf[80]);}

/* k1639 in a1636 in k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 242  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1207(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1642 in k1639 in a1636 in k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 243  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1626 in k1623 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 245  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[77],t2,lf[78]);}

/* k1591 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 231  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1594 in k1591 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 232  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[74]);}

/* k1597 in k1594 in k1591 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 233  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1600 in k1597 in k1594 in k1591 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 234  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1562 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 224  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1565 in k1562 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 225  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k1568 in k1565 in k1562 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 226  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1571 in k1568 in k1565 in k1562 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 227  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1525 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 217  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1207(t4,t2,t3,((C_word*)t0)[3]);}

/* k1528 in k1525 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 218  ##compiler#gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[67],t4,lf[68]);}

/* k1531 in k1528 in k1525 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 219  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1534 in k1531 in k1528 in k1525 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 220  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1492 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 210  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1207(t4,t2,t3,((C_word*)t0)[3]);}

/* k1495 in k1492 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 211  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1498 in k1495 in k1492 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1501 in k1498 in k1495 in k1492 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1473 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 205  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1476 in k1473 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[62]);}

/* k1446 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 200  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1449 in k1446 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 201  ##compiler#gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[59],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1086 */
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1397,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 192  ##compiler#gen */
t7=*((C_word*)lf[1]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 196  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1207(t7,t1,t6,t3);}}

/* k1405 in loop in expr in expression in ##compiler#generate-code in k1086 */
static void f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 193  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1207(t4,t2,t3,((C_word*)t0)[6]);}

/* k1408 in k1405 in loop in expr in expression in ##compiler#generate-code in k1086 */
static void f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 194  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1411 in k1408 in k1405 in loop in expr in expression in ##compiler#generate-code in k1086 */
static void f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 195  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1397(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 177  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1320 in k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 178  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1323 in k1320 in k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 179  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1326 in k1323 in k1320 in k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 180  ##compiler#gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[50]);}

/* k1329 in k1326 in k1323 in k1320 in k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 181  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1207(t4,t2,t3,((C_word*)t0)[2]);}

/* k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in expr in expression in ##compiler#generate-code in k1086 */
static void f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 182  ##compiler#gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* prefix-id in ##compiler#generate-code in k1086 */
static C_word C_fcall f_1198(C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_truep(((C_word*)t0)[2])?*((C_word*)lf[13]+1):lf[32]));}

/* find-lambda in ##compiler#generate-code in k1086 */
static void C_fcall f_1156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1156,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1160,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1168,a[2]=t2,a[3]=lf[29],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 147  find */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1167 in find-lambda in ##compiler#generate-code in k1086 */
static void f_1168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1168,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 147  lambda-literal-id */
t4=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1174 in a1167 in find-lambda in ##compiler#generate-code in k1086 */
static void f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1158 in find-lambda in ##compiler#generate-code in k1086 */
static void f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 148  ##compiler#bomb */
t2=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[27],((C_word*)t0)[2]);}}

/* ##compiler#namespace-lookup in k1086 */
static void f_1108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1108,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[14])))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1120,a[2]=t4,a[3]=t2,a[4]=lf[24],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1120(t6,t1,C_retrieve(lf[18]),C_fix(0));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in ##compiler#namespace-lookup in k1086 */
static void C_fcall f_1120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1120,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 134  ##compiler#bomb */
t4=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[22],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 135  cdar */
t5=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k1149 in loop in ##compiler#namespace-lookup in k1086 */
static void f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 136  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1120(t4,((C_word*)t0)[5],t2,t3);}}

/* ##compiler#setup-quick-namespace-list in k1086 */
static void f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=lf[17],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_retrieve(lf[18]));}

/* a1096 in ##compiler#setup-quick-namespace-list in k1086 */
static void f_1097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1097,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* c-backend.scm: 128  append */
t5=*((C_word*)lf[16]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[14]));}

/* k1100 in a1096 in ##compiler#setup-quick-namespace-list in k1086 */
static void f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[14]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#compute-namespace-size */
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1083,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(37));}

/* ##compiler#gen-list */
static void f_1067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1067,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1081,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 104  intersperse */
t5=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1079 in ##compiler#gen-list */
static void f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1072 in ##compiler#gen-list */
static void f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
/* c-backend.scm: 103  display */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[0]+1));}

/* ##compiler#gen */
static void f_1046(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1046r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1046r(t0,t1,t2);}}

static void f_1046r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=lf[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1051 in ##compiler#gen */
static void f_1052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1052,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 97   newline */
t4=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,*((C_word*)lf[0]+1));}
else{
/* c-backend.scm: 98   display */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,*((C_word*)lf[0]+1));}}
/* end of file */
