/* Generated from extras.scm by the Chicken compiler
   2005-09-24 22:21
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: extras.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file uextras.c -explicit-use
   unit: extras
*/

#include "chicken.h"

#define C_hashptr(x)   C_fix(x & C_MOST_POSITIVE_FIXNUM)
#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

#ifdef _WIN32
# define FGETS_INTO_BUFFER  0
static C_word fgets_into_buffer(C_word str, C_word port, C_word size) { return 0; }
#else
# define FGETS_INTO_BUFFER  1

static C_word fgets_into_buffer(C_word str, C_word port, C_word size)
{
  int len, n = C_unfix(size);
  char *buf = C_c_string(str);
  C_FILEPTR fp = C_port_file(port);

  if(C_fgets(buf, n, fp) == NULL) return C_fix(0);

  len = C_strlen(buf);

  if(len >= n - 1 && buf[ len - 1 ] != '\n') return C_SCHEME_FALSE;

  return C_fix(len);
}
#endif


static C_TLS C_word lf[243];


C_externexport void C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1362(C_word c,C_word t0,C_word t1) C_noret;
static void f_4537(C_word c,C_word t0,C_word t1) C_noret;
static void f_5714(C_word c,C_word t0,C_word t1) C_noret;
static void f_7726(C_word c,C_word t0,C_word t1) C_noret;
static void f_7935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7961(C_word c,C_word t0,C_word t1) C_noret;
static void f_7943(C_word c,C_word t0,C_word t1) C_noret;
static void f_7929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7883(C_word t0,C_word t1) C_noret;
static void f_7867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7836(C_word c,C_word t0,C_word t1) C_noret;
static void f_7777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_7789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7805(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7826(C_word c,C_word t0,C_word t1) C_noret;
static void f_7728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7740(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7750(C_word c,C_word t0,C_word t1) C_noret;
static void f_7663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7613(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7629(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7582(C_word c,C_word t0,C_word t1) C_noret;
static void f_7587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7585(C_word c,C_word t0,C_word t1) C_noret;
static void f_7508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7536(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7455(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7478(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7491(C_word c,C_word t0,C_word t1) C_noret;
static void f_7465(C_word c,C_word t0,C_word t1) C_noret;
static void f_7220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7236(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7324(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7327(C_word t0,C_word t1) C_noret;
static void C_fcall f_7253(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7272(C_word t0,C_word t1) C_noret;
static void f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7217(C_word c,C_word t0,C_word t1) C_noret;
static void f_7214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_7205(C_word c,C_word t0,C_word t1) C_noret;
static void f_6989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_6995(C_word t0,C_word t1) C_noret;
static void f_7011(C_word c,C_word t0,C_word t1) C_noret;
static void f_7189(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7119(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7153(C_word c,C_word t0,C_word t1) C_noret;
static void f_7160(C_word c,C_word t0,C_word t1) C_noret;
static void f_7144(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7058(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7099(C_word c,C_word t0,C_word t1) C_noret;
static void f_7083(C_word c,C_word t0,C_word t1) C_noret;
static void f_7036(C_word c,C_word t0,C_word t1) C_noret;
static void f_7023(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7399(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7415(C_word c,C_word t0,C_word t1) C_noret;
static void f_7386(C_word c,C_word t0,C_word t1) C_noret;
static void f_7026(C_word c,C_word t0,C_word t1) C_noret;
static void f_6956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6966(C_word t0,C_word t1) C_noret;
static void f_6942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6954(C_word c,C_word t0,C_word t1) C_noret;
static void f_6930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6936(C_word c,C_word t0,C_word t1) C_noret;
static void f_6807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_6807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_6817(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6880(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6899(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6838(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6920(C_word c,C_word t0,C_word t1) C_noret;
static void f_6801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6775(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6775r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_6779(C_word t0,C_word t1) C_noret;
static void f_6749(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6749r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_6753(C_word t0,C_word t1) C_noret;
static void f_6723(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6723r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_6727(C_word t0,C_word t1) C_noret;
static void f_6494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6721(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6659(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6694(C_word c,C_word t0,C_word t1) C_noret;
static void f_6637(C_word c,C_word t0,C_word t1) C_noret;
static void f_6624(C_word c,C_word t0,C_word t1) C_noret;
static void f_6616(C_word c,C_word t0,C_word t1) C_noret;
static void f_6595(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6497(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6507(C_word t0,C_word t1) C_noret;
static void f_6488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6400(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6447(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6468(C_word c,C_word t0,C_word t1) C_noret;
static void f_6441(C_word c,C_word t0,C_word t1) C_noret;
static void f_6309(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6309r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_6330(C_word t0,C_word t1) C_noret;
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6320(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6319(C_word c,C_word t0,C_word t1) C_noret;
static void f_6303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6297(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6220(C_word t0,C_word t1) C_noret;
static void C_fcall f_6234(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6244(C_word c,C_word t0,C_word t1) C_noret;
static void f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6214(C_word c,C_word t0,C_word t1) C_noret;
static void f_6207(C_word c,C_word t0,C_word t1) C_noret;
static void f_6203(C_word c,C_word t0,C_word t1) C_noret;
static void f_6056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6146(C_word c,C_word t0,C_word t1) C_noret;
static void f_6153(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6059(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6110(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6100(C_word t0,C_word t1) C_noret;
static void f_6069(C_word c,C_word t0,C_word t1) C_noret;
static void f_6072(C_word c,C_word t0,C_word t1) C_noret;
static void f_6078(C_word c,C_word t0,C_word t1) C_noret;
static void f_5924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6006(C_word c,C_word t0,C_word t1) C_noret;
static void f_6029(C_word c,C_word t0,C_word t1) C_noret;
static void f_6009(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5934(C_word c,C_word t0,C_word t1) C_noret;
static void f_5825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_5866(C_word c,C_word t0,C_word t1) C_noret;
static void f_5914(C_word c,C_word t0,C_word t1) C_noret;
static void f_5886(C_word c,C_word t0,C_word t1) C_noret;
static void f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5791(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5819(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5743(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5753(C_word c,C_word t0,C_word t1) C_noret;
static void f_5700(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5700r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5704(C_word c,C_word t0,C_word t1) C_noret;
static void f_5707(C_word c,C_word t0,C_word t1) C_noret;
static void f_5690(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5690r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5698(C_word c,C_word t0,C_word t1) C_noret;
static void f_5440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5440r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_5446(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_5664(C_word t0,C_word t1);
static void f_5591(C_word c,C_word t0,C_word t1) C_noret;
static void f_5574(C_word c,C_word t0,C_word t1) C_noret;
static void f_5557(C_word c,C_word t0,C_word t1) C_noret;
static void f_5489(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5456(C_word t0);
static C_word C_fcall f_5452(C_word t0);
static void f_5382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5422(C_word c,C_word t0,C_word t1) C_noret;
static void f_5426(C_word c,C_word t0,C_word t1) C_noret;
static void f_5411(C_word c,C_word t0,C_word t1) C_noret;
static void f_5266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5370(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5344(C_word t0,C_word t1) C_noret;
static void f_5300(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5290(C_word t0,C_word t1) C_noret;
static void f_5286(C_word c,C_word t0,C_word t1) C_noret;
static void f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5261(C_word c,C_word t0,C_word t1) C_noret;
static void f_5244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5113(C_word c,C_word t0,C_word t1) C_noret;
static void f_5116(C_word c,C_word t0,C_word t1) C_noret;
static void f_5125(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5149(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5079(C_word t0,C_word t1) C_noret;
static void f_5084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_5090(C_word t0,C_word t1);
static void f_4973(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4973r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4977(C_word t0,C_word t1) C_noret;
static void C_fcall f_4985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4995(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5000(C_word t0,C_word t1,C_word t2);
static void f_4844(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4844r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4879(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4945(C_word c,C_word t0,C_word t1) C_noret;
static void f_4889(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4874(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4866(C_word t0,C_word t1) C_noret;
static void f_4792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4805(C_word t0,C_word t1) C_noret;
static void f_4740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4753(C_word t0,C_word t1) C_noret;
static void f_4715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4671r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4652r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4614(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4639(C_word c,C_word t0,C_word t1) C_noret;
static void f_4604(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4604r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4612(C_word c,C_word t0,C_word t1) C_noret;
static void f_4568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4596(C_word c,C_word t0,C_word t1) C_noret;
static void f_4599(C_word c,C_word t0,C_word t1) C_noret;
static void f_4539(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4539r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4543(C_word c,C_word t0,C_word t1) C_noret;
static void f_4550(C_word c,C_word t0,C_word t1) C_noret;
static void f_4552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4556(C_word c,C_word t0,C_word t1) C_noret;
static void f_4546(C_word c,C_word t0,C_word t1) C_noret;
static void f_4458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4477(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4449(C_word c,C_word t0,C_word t1) C_noret;
static void f_4453(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4357(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4367(C_word t0,C_word t1) C_noret;
static void f_4348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4327(C_word t0,C_word t1) C_noret;
static void f_4314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4136(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_4282(C_word c,C_word t0,C_word t1) C_noret;
static void f_4234(C_word c,C_word t0,C_word t1) C_noret;
static void f_4264(C_word c,C_word t0,C_word t1) C_noret;
static void f_4249(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4166(C_word c,C_word t0,C_word t1) C_noret;
static void f_4162(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4207(C_word c,C_word t0,C_word t1) C_noret;
static void f_4203(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4059(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_4065(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4134(C_word c,C_word t0,C_word t1) C_noret;
static void f_4130(C_word c,C_word t0,C_word t1) C_noret;
static void f_4122(C_word c,C_word t0,C_word t1) C_noret;
static void f_4118(C_word c,C_word t0,C_word t1) C_noret;
static void f_4096(C_word c,C_word t0,C_word t1) C_noret;
static void f_4088(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4054(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4022(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4048(C_word c,C_word t0,C_word t1) C_noret;
static void f_4026(C_word c,C_word t0,C_word t1) C_noret;
static void f_3957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3964(C_word c,C_word t0,C_word t1) C_noret;
static void f_3991(C_word c,C_word t0,C_word t1) C_noret;
static void f_4017(C_word c,C_word t0,C_word t1) C_noret;
static void f_3975(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3870(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3883(C_word c,C_word t0,C_word t1) C_noret;
static void f_3921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3886(C_word c,C_word t0,C_word t1) C_noret;
static void f_3915(C_word c,C_word t0,C_word t1) C_noret;
static void f_3919(C_word c,C_word t0,C_word t1) C_noret;
static void f_3899(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3861(C_word c,C_word t0,C_word t1) C_noret;
static void f_3854(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3836(C_word c,C_word t0,C_word t1) C_noret;
static void f_3829(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3321(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3500(C_word c,C_word t0,C_word t1) C_noret;
static void f_3757(C_word c,C_word t0,C_word t1) C_noret;
static void f_3774(C_word c,C_word t0,C_word t1) C_noret;
static void f_3784(C_word c,C_word t0,C_word t1) C_noret;
static void f_3777(C_word c,C_word t0,C_word t1) C_noret;
static void f_3764(C_word c,C_word t0,C_word t1) C_noret;
static void f_3741(C_word c,C_word t0,C_word t1) C_noret;
static void f_3744(C_word c,C_word t0,C_word t1) C_noret;
static void f_3751(C_word c,C_word t0,C_word t1) C_noret;
static void f_3732(C_word c,C_word t0,C_word t1) C_noret;
static void f_3648(C_word c,C_word t0,C_word t1) C_noret;
static void f_3651(C_word c,C_word t0,C_word t1) C_noret;
static void f_3707(C_word c,C_word t0,C_word t1) C_noret;
static void f_3686(C_word c,C_word t0,C_word t1) C_noret;
static void f_3693(C_word c,C_word t0,C_word t1) C_noret;
static void f_3670(C_word c,C_word t0,C_word t1) C_noret;
static void f_3677(C_word c,C_word t0,C_word t1) C_noret;
static void f_3642(C_word c,C_word t0,C_word t1) C_noret;
static void f_3558(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3560(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3567(C_word t0,C_word t1) C_noret;
static void f_3619(C_word c,C_word t0,C_word t1) C_noret;
static void f_3615(C_word c,C_word t0,C_word t1) C_noret;
static void f_3598(C_word c,C_word t0,C_word t1) C_noret;
static void f_3594(C_word c,C_word t0,C_word t1) C_noret;
static void f_3590(C_word c,C_word t0,C_word t1) C_noret;
static void f_3539(C_word c,C_word t0,C_word t1) C_noret;
static void f_3516(C_word c,C_word t0,C_word t1) C_noret;
static void f_3519(C_word c,C_word t0,C_word t1) C_noret;
static void f_3526(C_word c,C_word t0,C_word t1) C_noret;
static void f_3507(C_word c,C_word t0,C_word t1) C_noret;
static void f_3477(C_word c,C_word t0,C_word t1) C_noret;
static void f_3481(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3331(C_word c,C_word t0,C_word t1) C_noret;
static void f_3342(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3351(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3434(C_word c,C_word t0,C_word t1) C_noret;
static void f_3369(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3423(C_word c,C_word t0,C_word t1) C_noret;
static void f_3419(C_word c,C_word t0,C_word t1) C_noret;
static void f_3403(C_word c,C_word t0,C_word t1) C_noret;
static void f_3395(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3312(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3269(C_word t0);
static C_word C_fcall f_3263(C_word t0);
static void C_fcall f_3211(C_word t0,C_word t1) C_noret;
static void C_fcall f_3243(C_word t0,C_word t1) C_noret;
static void f_3150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3163(C_word c,C_word t0,C_word t1) C_noret;
static void f_3193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3188(C_word c,C_word t0,C_word t1) C_noret;
static void f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3176(C_word c,C_word t0,C_word t1) C_noret;
static void f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_3069r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_3082(C_word c,C_word t0,C_word t1) C_noret;
static void f_3138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3133(C_word c,C_word t0,C_word t1) C_noret;
static void f_3108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3124(C_word c,C_word t0,C_word t1) C_noret;
static void f_3087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3045(C_word c,C_word t0,C_word t1) C_noret;
static void f_3064(C_word c,C_word t0,C_word t1) C_noret;
static void f_3055(C_word c,C_word t0,C_word t1) C_noret;
static void f_3059(C_word c,C_word t0,C_word t1) C_noret;
static void f_3050(C_word c,C_word t0,C_word t1) C_noret;
static void f_3016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3020(C_word c,C_word t0,C_word t1) C_noret;
static void f_3036(C_word c,C_word t0,C_word t1) C_noret;
static void f_3030(C_word c,C_word t0,C_word t1) C_noret;
static void f_3025(C_word c,C_word t0,C_word t1) C_noret;
static void f_3004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3008(C_word c,C_word t0,C_word t1) C_noret;
static void f_3011(C_word c,C_word t0,C_word t1) C_noret;
static void f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2999(C_word c,C_word t0,C_word t1) C_noret;
static void f_2973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2990(C_word c,C_word t0,C_word t1) C_noret;
static void f_2984(C_word c,C_word t0,C_word t1) C_noret;
static void f_2979(C_word c,C_word t0,C_word t1) C_noret;
static void f_2951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2968(C_word c,C_word t0,C_word t1) C_noret;
static void f_2962(C_word c,C_word t0,C_word t1) C_noret;
static void f_2957(C_word c,C_word t0,C_word t1) C_noret;
static void f_2929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2946(C_word c,C_word t0,C_word t1) C_noret;
static void f_2940(C_word c,C_word t0,C_word t1) C_noret;
static void f_2935(C_word c,C_word t0,C_word t1) C_noret;
static void f_2914(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2914r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2921(C_word c,C_word t0,C_word t1) C_noret;
static void f_2837(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2837r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2869(C_word t0,C_word t1) C_noret;
static void C_fcall f_2864(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2853(C_word t0,C_word t1) C_noret;
static void f_2850(C_word c,C_word t0,C_word t1) C_noret;
static void f_2774(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2774r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2778(C_word t0,C_word t1) C_noret;
static void f_2781(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2786(C_word t0,C_word t1) C_noret;
static void f_2790(C_word c,C_word t0,C_word t1) C_noret;
static void f_2796(C_word c,C_word t0,C_word t1) C_noret;
static void f_2806(C_word c,C_word t0,C_word t1) C_noret;
static void f_2799(C_word c,C_word t0,C_word t1) C_noret;
static void f_2671(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2671r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2729(C_word t0,C_word t1) C_noret;
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2677(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2685(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2689(C_word c,C_word t0,C_word t1) C_noret;
static void f_2695(C_word c,C_word t0,C_word t1) C_noret;
static void f_2707(C_word c,C_word t0,C_word t1) C_noret;
static void f_2582(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2582r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2602(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2628(C_word c,C_word t0,C_word t1) C_noret;
static void f_2356(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2356r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2366(C_word t0,C_word t1) C_noret;
static void f_2369(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2375(C_word t0,C_word t1) C_noret;
static void f_2449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2455(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2472(C_word c,C_word t0,C_word t1) C_noret;
static void f_2554(C_word c,C_word t0,C_word t1) C_noret;
static void f_2546(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2532(C_word t0,C_word t1) C_noret;
static void f_2509(C_word c,C_word t0,C_word t1) C_noret;
static void f_2522(C_word c,C_word t0,C_word t1) C_noret;
static void f_2500(C_word c,C_word t0,C_word t1) C_noret;
static void f_2469(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2407(C_word c,C_word t0,C_word t1) C_noret;
static void f_2415(C_word c,C_word t0,C_word t1) C_noret;
static void f_2411(C_word c,C_word t0,C_word t1) C_noret;
static void f_2433(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2330(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2341(C_word t0,C_word t1) C_noret;
static void f_2316(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2316r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2263r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2272(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2288(C_word c,C_word t0,C_word t1) C_noret;
static void f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2218(C_word t0,C_word t1) C_noret;
static void C_fcall f_2213(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2179(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2195(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2148(C_word t0,C_word t1) C_noret;
static void f_2151(C_word c,C_word t0,C_word t1) C_noret;
static void f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_2056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2101(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2117(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2063(C_word t0,C_word t1) C_noret;
static void f_2066(C_word c,C_word t0,C_word t1) C_noret;
static void f_2018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2054(C_word c,C_word t0,C_word t1) C_noret;
static void f_2030(C_word c,C_word t0,C_word t1) C_noret;
static void f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2026(C_word c,C_word t0,C_word t1) C_noret;
static void f_1955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1997(C_word c,C_word t0,C_word t1) C_noret;
static void f_1906(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1906r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1915(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1947(C_word c,C_word t0,C_word t1) C_noret;
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1863(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1877(C_word c,C_word t0,C_word t1) C_noret;
static void f_1881(C_word c,C_word t0,C_word t1) C_noret;
static void f_1786(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1786r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1792(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1831(C_word c,C_word t0,C_word t1) C_noret;
static void f_1824(C_word c,C_word t0,C_word t1) C_noret;
static void f_1757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1763(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1784(C_word c,C_word t0,C_word t1) C_noret;
static void f_1724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1755(C_word c,C_word t0,C_word t1) C_noret;
static void f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1708(C_word t0,C_word t1);
static void f_1696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1690(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1658(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1677(C_word c,C_word t0,C_word t1) C_noret;
static void f_1620(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1620r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1623(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1623r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1631(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1631r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1637(C_word c,C_word t0,C_word t1) C_noret;
static void f_1645(C_word c,C_word t0,C_word t1) C_noret;
static void f_1608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1610(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1610r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1618(C_word c,C_word t0,C_word t1) C_noret;
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1577(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1577r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1590(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1588(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1540(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1540r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1548(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1558(C_word c,C_word t0,C_word t1) C_noret;
static void f_1507(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1507r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1515(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1528(C_word c,C_word t0,C_word t1) C_noret;
static void f_1499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1501(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1501r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1364(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1364r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1436(C_word t0,C_word t1) C_noret;
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1419(C_word c,C_word t0,C_word t1) C_noret;
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1377(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1379(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1399(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7951(t0,t1,t2);}

static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7883(t0,t1);}

static void C_fcall trf_7789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7789(t0,t1,t2,t3);}

static void C_fcall trf_7805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7805(t0,t1,t2);}

static void C_fcall trf_7740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7740(t0,t1,t2);}

static void C_fcall trf_7675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7675(t0,t1,t2,t3);}

static void C_fcall trf_7691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7691(t0,t1,t2,t3);}

static void C_fcall trf_7613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7613(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7613(t0,t1,t2,t3);}

static void C_fcall trf_7629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7629(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7629(t0,t1,t2,t3);}

static void C_fcall trf_7520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7520(t0,t1,t2,t3);}

static void C_fcall trf_7536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7536(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7536(t0,t1,t2,t3);}

static void C_fcall trf_7455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7455(t0,t1,t2);}

static void C_fcall trf_7478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7478(t0,t1,t2);}

static void C_fcall trf_7308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7308(t0,t1,t2,t3);}

static void C_fcall trf_7327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7327(t0,t1);}

static void C_fcall trf_7253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7253(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7253(t0,t1,t2,t3);}

static void C_fcall trf_7272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7272(t0,t1);}

static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6995(t0,t1);}

static void C_fcall trf_7119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7119(t0,t1,t2);}

static void C_fcall trf_7058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7058(t0,t1,t2);}

static void C_fcall trf_7376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7376(t0,t1,t2);}

static void C_fcall trf_7399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7399(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7399(t0,t1,t2);}

static void C_fcall trf_6966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6966(t0,t1);}

static void C_fcall trf_6880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6880(t0,t1,t2);}

static void C_fcall trf_6838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6838(t0,t1,t2);}

static void C_fcall trf_6779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6779(t0,t1);}

static void C_fcall trf_6753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6753(t0,t1);}

static void C_fcall trf_6727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6727(t0,t1);}

static void C_fcall trf_6522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6522(t0,t1,t2,t3);}

static void C_fcall trf_6659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6659(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6659(t0,t1,t2,t3,t4);}

static void C_fcall trf_6497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6497(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6497(t0,t1,t2,t3);}

static void C_fcall trf_6507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6507(t0,t1);}

static void C_fcall trf_6405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6405(t0,t1,t2);}

static void C_fcall trf_6447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6447(t0,t1,t2);}

static void C_fcall trf_6330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6330(t0,t1);}

static void C_fcall trf_6325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6325(t0,t1,t2);}

static void C_fcall trf_6320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6320(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6320(t0,t1,t2,t3);}

static void C_fcall trf_6311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6311(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6311(t0,t1,t2,t3,t4);}

static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6220(t0,t1);}

static void C_fcall trf_6234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6234(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6234(t0,t1,t2,t3);}

static void C_fcall trf_6155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6155(t0,t1,t2,t3);}

static void C_fcall trf_6059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6059(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6059(t0,t1,t2);}

static void C_fcall trf_6100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6100(t0,t1);}

static void C_fcall trf_5927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5927(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5927(t0,t1,t2,t3,t4);}

static void C_fcall trf_5859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5859(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5859(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5791(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5791(t0,t1,t2,t3);}

static void C_fcall trf_5743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5743(t0,t1,t2);}

static void C_fcall trf_5446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5446(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5446(t0,t1,t2,t3);}

static void C_fcall trf_5479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5479(t0,t1,t2);}

static void C_fcall trf_5391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5391(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5391(t0,t1,t2,t3);}

static void C_fcall trf_5272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5272(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5272(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5305(t0,t1,t2);}

static void C_fcall trf_5344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5344(t0,t1);}

static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5290(t0,t1);}

static void C_fcall trf_5130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5130(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5130(t0,t1,t2,t3);}

static void C_fcall trf_5079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5079(t0,t1);}

static void C_fcall trf_4977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4977(t0,t1);}

static void C_fcall trf_4985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4985(t0,t1,t2,t3);}

static void C_fcall trf_4879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4879(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4879(t0,t1,t2,t3,t4);}

static void C_fcall trf_4906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4906(t0,t1,t2);}

static void C_fcall trf_4859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4859(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4859(t0,t1,t2,t3,t4);}

static void C_fcall trf_4866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4866(t0,t1);}

static void C_fcall trf_4805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4805(t0,t1);}

static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4753(t0,t1);}

static void C_fcall trf_4614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4614(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4614(t0,t1,t2,t3,t4);}

static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4626(t0,t1,t2,t3);}

static void C_fcall trf_4461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4461(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4461(t0,t1,t2,t3);}

static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4486(t0,t1,t2,t3);}

static void C_fcall trf_3208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3208(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3208(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3802(t0,t1,t2,t3);}

static void C_fcall trf_4357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4357(t0,t1,t2);}

static void C_fcall trf_4367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4367(t0,t1);}

static void C_fcall trf_4327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4327(t0,t1);}

static void C_fcall trf_4136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4136(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_4136(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall trf_4139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4139(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4139(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4180(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4180(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4221(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4221(t0,t1,t2,t3,t4);}

static void C_fcall trf_4059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4059(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4059(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_4065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4065(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4065(t0,t1,t2,t3);}

static void C_fcall trf_4050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4050(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4050(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4022(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4022(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3870(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3870(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3838(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3838(t0,t1,t2,t3);}

static void C_fcall trf_3805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3805(t0,t1,t2,t3);}

static void C_fcall trf_3321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3321(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3321(t0,t1,t2,t3);}

static void C_fcall trf_3560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3560(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3560(t0,t1,t2,t3,t4);}

static void C_fcall trf_3567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3567(t0,t1);}

static void C_fcall trf_3324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3324(t0,t1,t2,t3);}

static void C_fcall trf_3351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3351(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3351(t0,t1,t2,t3);}

static void C_fcall trf_3371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3371(t0,t1,t2,t3);}

static void C_fcall trf_3302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3302(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3302(t0,t1,t2,t3);}

static void C_fcall trf_3211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3211(t0,t1);}

static void C_fcall trf_3243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3243(t0,t1);}

static void C_fcall trf_2869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2869(t0,t1);}

static void C_fcall trf_2864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2864(t0,t1,t2);}

static void C_fcall trf_2839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2839(t0,t1,t2,t3);}

static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2853(t0,t1);}

static void C_fcall trf_2778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2778(t0,t1);}

static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2786(t0,t1);}

static void C_fcall trf_2729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2729(t0,t1);}

static void C_fcall trf_2724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2724(t0,t1,t2);}

static void C_fcall trf_2673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2673(t0,t1,t2,t3);}

static void C_fcall trf_2685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2685(t0,t1,t2);}

static void C_fcall trf_2608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2608(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2608(t0,t1,t2,t3,t4);}

static void C_fcall trf_2366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2366(t0,t1);}

static void C_fcall trf_2375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2375(t0,t1);}

static void C_fcall trf_2455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2455(t0,t1,t2);}

static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2532(t0,t1);}

static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2380(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2330(t0,t1,t2);}

static void C_fcall trf_2341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2341(t0,t1);}

static void C_fcall trf_2272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2272(t0,t1,t2);}

static void C_fcall trf_2218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2218(t0,t1);}

static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2213(t0,t1,t2);}

static void C_fcall trf_2144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2144(t0,t1,t2,t3);}

static void C_fcall trf_2179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2179(t0,t1,t2);}

static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2148(t0,t1);}

static void C_fcall trf_2101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2101(t0,t1,t2);}

static void C_fcall trf_2063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2063(t0,t1);}

static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1961(t0,t1,t2,t3);}

static void C_fcall trf_1915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1915(t0,t1,t2);}

static void C_fcall trf_1842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1842(t0,t1,t2,t3);}

static void C_fcall trf_1863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1863(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1863(t0,t1,t2,t3,t4);}

static void C_fcall trf_1792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1792(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1792(t0,t1,t2,t3);}

static void C_fcall trf_1763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1763(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1763(t0,t1,t2);}

static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1730(t0,t1,t2);}

static void C_fcall trf_1658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1658(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1658(t0,t1,t2);}

static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1548(t0,t1,t2);}

static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1515(t0,t1,t2);}

static void C_fcall trf_1436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1436(t0,t1);}

static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1431(t0,t1,t2);}

static void C_fcall trf_1426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1426(t0,t1,t2,t3);}

static void C_fcall trf_1366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1366(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1366(t0,t1,t2,t3,t4);}

static void C_fcall trf_1379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1379(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1379(t0,t1,t2,t3,t4);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1774)){
C_save(t1);
C_rereclaim2(1774*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,243);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],4,"read");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],20,"call-with-input-file");
lf[5]=C_h_intern(&lf[5],9,"read-file");
lf[6]=C_h_intern(&lf[6],5,"port\077");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-input");
lf[8]=C_h_intern(&lf[8],8,"identity");
lf[9]=C_h_intern(&lf[9],7,"project");
lf[10]=C_h_intern(&lf[10],7,"conjoin");
lf[11]=C_h_intern(&lf[11],7,"disjoin");
lf[12]=C_h_intern(&lf[12],10,"constantly");
lf[13]=C_h_intern(&lf[13],4,"flip");
lf[14]=C_h_intern(&lf[14],10,"complement");
lf[15]=C_h_intern(&lf[15],7,"compose");
lf[16]=C_h_intern(&lf[16],7,"list-of");
lf[17]=C_h_intern(&lf[17],4,"noop");
lf[18]=C_h_intern(&lf[18],4,"void");
lf[19]=C_h_intern(&lf[19],5,"atom\077");
lf[20]=C_h_intern(&lf[20],5,"tail\077");
lf[21]=C_h_intern(&lf[21],11,"intersperse");
lf[22]=C_h_intern(&lf[22],7,"butlast");
lf[23]=C_h_intern(&lf[23],7,"flatten");
lf[24]=C_h_intern(&lf[24],4,"chop");
lf[25]=C_h_intern(&lf[25],4,"join");
lf[26]=C_h_intern(&lf[26],10,"\003sysappend");
lf[27]=C_h_intern(&lf[27],8,"compress");
lf[28]=C_h_intern(&lf[28],7,"shuffle");
lf[29]=C_h_intern(&lf[29],7,"\003sysmap");
lf[30]=C_h_intern(&lf[30],3,"cdr");
lf[31]=C_h_intern(&lf[31],5,"sort!");
lf[32]=C_h_intern(&lf[32],6,"random");
lf[33]=C_h_intern(&lf[33],13,"alist-update!");
lf[34]=C_h_intern(&lf[34],4,"eqv\077");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"assq");
lf[37]=C_h_intern(&lf[37],4,"assv");
lf[38]=C_h_intern(&lf[38],6,"equal\077");
lf[39]=C_h_intern(&lf[39],5,"assoc");
lf[40]=C_h_intern(&lf[40],9,"alist-ref");
lf[41]=C_h_intern(&lf[41],6,"rassoc");
lf[42]=C_h_intern(&lf[42],9,"randomize");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],13,"\003syssubstring");
lf[45]=C_h_intern(&lf[45],9,"read-line");
lf[46]=C_h_intern(&lf[46],17,"\003sysstring-append");
lf[47]=C_static_string(C_heaptop,0,"");
lf[48]=C_h_intern(&lf[48],15,"\003sysread-char-0");
lf[49]=C_h_intern(&lf[49],6,"stream");
lf[50]=C_h_intern(&lf[50],10,"read-lines");
lf[51]=C_h_intern(&lf[51],18,"open-output-string");
lf[52]=C_h_intern(&lf[52],17,"get-output-string");
lf[53]=C_h_intern(&lf[53],11,"read-string");
lf[54]=C_h_intern(&lf[54],14,"\003syswrite-char");
lf[55]=C_h_intern(&lf[55],10,"read-token");
lf[56]=C_h_intern(&lf[56],16,"\003syswrite-char-0");
lf[57]=C_h_intern(&lf[57],15,"\003syspeek-char-0");
lf[58]=C_h_intern(&lf[58],7,"display");
lf[59]=C_h_intern(&lf[59],12,"write-string");
lf[60]=C_h_intern(&lf[60],19,"\003sysstandard-output");
lf[61]=C_h_intern(&lf[61],7,"newline");
lf[62]=C_h_intern(&lf[62],10,"write-line");
lf[63]=C_h_intern(&lf[63],20,"with-input-from-port");
lf[64]=C_h_intern(&lf[64],16,"\003sysdynamic-wind");
lf[65]=C_h_intern(&lf[65],19,"with-output-to-port");
lf[66]=C_h_intern(&lf[66],25,"with-error-output-to-port");
lf[67]=C_h_intern(&lf[67],18,"\003sysstandard-error");
lf[68]=C_h_intern(&lf[68],17,"open-input-string");
lf[69]=C_h_intern(&lf[69],22,"call-with-input-string");
lf[70]=C_h_intern(&lf[70],23,"call-with-output-string");
lf[71]=C_h_intern(&lf[71],22,"with-input-from-string");
lf[72]=C_h_intern(&lf[72],21,"with-output-to-string");
lf[73]=C_h_intern(&lf[73],15,"make-input-port");
lf[74]=C_h_intern(&lf[74],13,"\003sysmake-port");
lf[75]=C_static_string(C_heaptop,8,"(custom)");
lf[76]=C_h_intern(&lf[76],6,"custom");
lf[77]=C_h_intern(&lf[77],6,"string");
lf[78]=C_h_intern(&lf[78],16,"make-output-port");
lf[79]=C_static_string(C_heaptop,8,"(custom)");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_h_intern(&lf[82],10,"quasiquote");
lf[83]=C_h_intern(&lf[83],7,"unquote");
lf[84]=C_h_intern(&lf[84],16,"unquote-splicing");
lf[85]=C_static_string(C_heaptop,1,"\047");
lf[86]=C_static_string(C_heaptop,1,"`");
lf[87]=C_static_string(C_heaptop,1,",");
lf[88]=C_static_string(C_heaptop,2,",@");
lf[89]=C_static_string(C_heaptop,1," ");
lf[90]=C_static_string(C_heaptop,1,")");
lf[91]=C_static_string(C_heaptop,1,")");
lf[92]=C_static_string(C_heaptop,3," . ");
lf[93]=C_static_string(C_heaptop,1,"(");
lf[94]=C_static_string(C_heaptop,2,"()");
lf[95]=C_static_string(C_heaptop,6,"#<eof>");
lf[96]=C_static_string(C_heaptop,1,"#");
lf[97]=C_h_intern(&lf[97],12,"vector->list");
lf[98]=C_static_string(C_heaptop,2,"#t");
lf[99]=C_static_string(C_heaptop,2,"#f");
lf[100]=C_h_intern(&lf[100],18,"\003sysnumber->string");
lf[101]=C_h_intern(&lf[101],9,"\003sysprint");
lf[102]=C_h_intern(&lf[102],21,"\003sysprocedure->string");
lf[103]=C_static_string(C_heaptop,1,"\134");
lf[104]=C_static_string(C_heaptop,1,"\042");
lf[105]=C_static_string(C_heaptop,1,"\042");
lf[106]=C_static_string(C_heaptop,1,"x");
lf[107]=C_static_string(C_heaptop,1,"U");
lf[108]=C_static_string(C_heaptop,1,"u");
lf[109]=C_h_intern(&lf[109],9,"char-name");
lf[110]=C_static_string(C_heaptop,2,"#\134");
lf[111]=C_static_string(C_heaptop,6,"#<eof>");
lf[112]=C_static_string(C_heaptop,14,"#<unspecified>");
lf[113]=C_h_intern(&lf[113],19,"\003syspointer->string");
lf[114]=C_h_intern(&lf[114],19,"\003sysuser-print-hook");
lf[115]=C_h_intern(&lf[115],13,"string-append");
lf[116]=C_static_string(C_heaptop,7,"#<port ");
lf[117]=C_static_string(C_heaptop,1,">");
lf[118]=C_static_string(C_heaptop,2,"#>");
lf[119]=C_h_intern(&lf[119],23,"\003syslambda-info->string");
lf[120]=C_static_string(C_heaptop,14,"#<lambda info ");
lf[121]=C_h_intern(&lf[121],28,"\003sysarbitrary-unbound-symbol");
lf[122]=C_static_string(C_heaptop,16,"#<unbound value>");
lf[123]=C_static_string(C_heaptop,21,"#<unprintable object>");
lf[124]=C_h_intern(&lf[124],11,"\003sysnumber\077");
lf[125]=C_static_string(C_heaptop,8,"        ");
lf[126]=C_static_string(C_heaptop,8,"        ");
lf[127]=C_h_intern(&lf[127],28,"\006extrasreverse-string-append");
lf[128]=C_static_string(C_heaptop,1,"#");
lf[129]=C_h_intern(&lf[129],3,"max");
lf[130]=C_h_intern(&lf[130],28,"\003syssymbol->qualified-string");
lf[131]=C_static_string(C_heaptop,1,"(");
lf[132]=C_static_string(C_heaptop,1,"(");
lf[133]=C_static_string(C_heaptop,1,")");
lf[134]=C_static_string(C_heaptop,1,")");
lf[135]=C_static_string(C_heaptop,1,".");
lf[136]=C_static_string(C_heaptop,1," ");
lf[137]=C_static_string(C_heaptop,1,"(");
lf[138]=C_h_intern(&lf[138],6,"lambda");
lf[139]=C_h_intern(&lf[139],2,"if");
lf[140]=C_h_intern(&lf[140],4,"set!");
lf[141]=C_h_intern(&lf[141],4,"cond");
lf[142]=C_h_intern(&lf[142],4,"case");
lf[143]=C_h_intern(&lf[143],3,"and");
lf[144]=C_h_intern(&lf[144],2,"or");
lf[145]=C_h_intern(&lf[145],3,"let");
lf[146]=C_h_intern(&lf[146],5,"begin");
lf[147]=C_h_intern(&lf[147],2,"do");
lf[148]=C_h_intern(&lf[148],4,"let*");
lf[149]=C_h_intern(&lf[149],6,"letrec");
lf[150]=C_h_intern(&lf[150],6,"define");
lf[151]=C_h_intern(&lf[151],18,"pretty-print-width");
lf[152]=C_h_intern(&lf[152],12,"pretty-print");
lf[153]=C_h_intern(&lf[153],19,"current-output-port");
lf[154]=C_h_intern(&lf[154],2,"pp");
lf[155]=C_h_intern(&lf[155],8,"->string");
lf[156]=C_h_intern(&lf[156],14,"symbol->string");
lf[157]=C_h_intern(&lf[157],4,"conc");
lf[158]=C_h_intern(&lf[158],15,"substring-index");
lf[159]=C_h_intern(&lf[159],18,"substring-index-ci");
lf[160]=C_h_intern(&lf[160],15,"string-compare3");
lf[161]=C_h_intern(&lf[161],18,"string-compare3-ci");
lf[162]=C_h_intern(&lf[162],11,"substring=\077");
lf[163]=C_h_intern(&lf[163],14,"substring-ci=\077");
lf[164]=C_h_intern(&lf[164],12,"string-split");
lf[165]=C_static_string(C_heaptop,3,"\011\012 ");
lf[166]=C_h_intern(&lf[166],18,"string-intersperse");
lf[167]=C_static_string(C_heaptop,0,"");
lf[168]=C_h_intern(&lf[168],19,"\003sysallocate-vector");
lf[169]=C_h_intern(&lf[169],27,"\003sysnot-a-proper-list-error");
lf[170]=C_static_string(C_heaptop,1," ");
lf[171]=C_h_intern(&lf[171],12,"list->string");
lf[172]=C_h_intern(&lf[172],16,"string-translate");
lf[173]=C_h_intern(&lf[173],17,"string-translate*");
lf[174]=C_h_intern(&lf[174],21,"\003sysfragments->string");
lf[175]=C_h_intern(&lf[175],11,"string-chop");
lf[176]=C_h_intern(&lf[176],5,"write");
lf[177]=C_h_intern(&lf[177],7,"fprintf");
lf[178]=C_h_intern(&lf[178],16,"\003sysflush-output");
lf[179]=C_h_intern(&lf[179],9,"\003syserror");
lf[180]=C_static_string(C_heaptop,31,"illegal format-string character");
lf[181]=C_h_intern(&lf[181],6,"printf");
lf[182]=C_h_intern(&lf[182],7,"sprintf");
lf[183]=C_h_intern(&lf[183],6,"format");
lf[184]=C_h_intern(&lf[184],7,"sorted\077");
lf[185]=C_h_intern(&lf[185],5,"merge");
lf[186]=C_h_intern(&lf[186],6,"merge!");
lf[187]=C_h_intern(&lf[187],4,"sort");
lf[188]=C_h_intern(&lf[188],12,"list->vector");
lf[189]=C_h_intern(&lf[189],6,"append");
lf[190]=C_h_intern(&lf[190],13,"binary-search");
tmp=C_fix(307);
C_save(tmp);
tmp=C_fix(617);
C_save(tmp);
tmp=C_fix(1237);
C_save(tmp);
tmp=C_fix(2477);
C_save(tmp);
tmp=C_fix(4957);
C_save(tmp);
tmp=C_fix(9923);
C_save(tmp);
tmp=C_fix(19853);
C_save(tmp);
tmp=C_fix(39709);
C_save(tmp);
tmp=C_fix(79423);
C_save(tmp);
tmp=C_fix(158849);
C_save(tmp);
tmp=C_fix(317701);
C_save(tmp);
tmp=C_fix(635413);
C_save(tmp);
tmp=C_fix(1270849);
C_save(tmp);
tmp=C_fix(2541701);
C_save(tmp);
tmp=C_fix(5083423);
C_save(tmp);
tmp=C_fix(10166857);
C_save(tmp);
tmp=C_fix(20333759);
C_save(tmp);
tmp=C_fix(40667527);
C_save(tmp);
tmp=C_fix(81335063);
C_save(tmp);
tmp=C_fix(162670129);
C_save(tmp);
tmp=C_fix(325340273);
C_save(tmp);
tmp=C_fix(650680571);
C_save(tmp);
tmp=C_fix(1073741823);
C_save(tmp);
lf[192]=C_h_list(23,C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(23);
lf[193]=C_h_intern(&lf[193],11,"hash-table\077");
lf[194]=C_h_intern(&lf[194],10,"hash-table");
lf[195]=C_h_intern(&lf[195],11,"make-vector");
lf[196]=C_h_intern(&lf[196],15,"make-hash-table");
lf[198]=C_h_intern(&lf[198],15,"hash-table-copy");
lf[199]=C_h_intern(&lf[199],31,"hash-table-equivalence-function");
lf[200]=C_h_intern(&lf[200],24,"hash-table-hash-function");
lf[201]=C_h_intern(&lf[201],11,"input-port\077");
lf[202]=C_h_intern(&lf[202],4,"hash");
lf[203]=C_h_intern(&lf[203],16,"hash-by-identity");
lf[204]=C_h_intern(&lf[204],11,"string-hash");
lf[205]=C_h_intern(&lf[205],5,"limit");
lf[206]=C_h_intern(&lf[206],14,"string-ci-hash");
lf[207]=C_h_intern(&lf[207],15,"hash-table-size");
lf[208]=C_h_intern(&lf[208],14,"hash-table-ref");
lf[209]=C_static_string(C_heaptop,31,"hash-table does not contain key");
lf[210]=C_h_intern(&lf[210],22,"hash-table-ref/default");
lf[211]=C_h_intern(&lf[211],18,"hash-table-exists\077");
lf[212]=C_h_intern(&lf[212],16,"\003syshash-new-len");
lf[213]=C_h_intern(&lf[213],5,"floor");
lf[214]=C_h_intern(&lf[214],18,"hash-table-update!");
lf[215]=C_flonum(C_heaptop,0.5);
lf[216]=C_h_intern(&lf[216],26,"hash-table-update!/default");
lf[217]=C_h_intern(&lf[217],15,"hash-table-set!");
lf[218]=C_h_intern(&lf[218],18,"hash-table-delete!");
lf[219]=C_h_intern(&lf[219],17,"hash-table-merge!");
lf[220]=C_h_intern(&lf[220],17,"hash-table->alist");
lf[221]=C_h_intern(&lf[221],17,"alist->hash-table");
lf[222]=C_h_intern(&lf[222],12,"\003sysfor-each");
lf[223]=C_h_intern(&lf[223],15,"hash-table-keys");
lf[224]=C_h_intern(&lf[224],17,"hash-table-values");
lf[225]=C_h_intern(&lf[225],15,"hash-table-walk");
lf[226]=C_h_intern(&lf[226],15,"hash-table-fold");
lf[227]=C_h_intern(&lf[227],6,"bucket");
lf[228]=C_h_intern(&lf[228],10,"make-queue");
lf[229]=C_h_intern(&lf[229],5,"queue");
lf[230]=C_h_intern(&lf[230],6,"queue\077");
lf[231]=C_h_intern(&lf[231],12,"queue-empty\077");
lf[232]=C_h_intern(&lf[232],11,"queue-first");
lf[233]=C_h_intern(&lf[233],10,"queue-last");
lf[234]=C_h_intern(&lf[234],10,"queue-add!");
lf[235]=C_h_intern(&lf[235],13,"queue-remove!");
lf[236]=C_h_intern(&lf[236],11,"queue->list");
lf[237]=C_h_intern(&lf[237],11,"list->queue");
lf[238]=C_h_intern(&lf[238],17,"register-feature!");
lf[239]=C_h_intern(&lf[239],7,"srfi-69");
lf[240]=C_h_intern(&lf[240],7,"srfi-28");
lf[241]=C_h_intern(&lf[241],14,"make-parameter");
lf[242]=C_h_intern(&lf[242],6,"extras");
C_register_lf(lf,243);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 105  register-feature! */
t4=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[242]);}

/* k1360 */
static void f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1362,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=*((C_word*)lf[4]+1);
t5=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1364,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1496,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1499,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1507,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1540,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1577,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1600,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1608,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1620,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1650,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1690,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1696,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1699,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1724,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1757,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1786,tmp=(C_word)a,a+=2,tmp));
t21=*((C_word*)lf[3]+1);
t22=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1906,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1955,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2018,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2056,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2142,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2263,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2307,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2316,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[43]+1);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2330,tmp=(C_word)a,a+=2,tmp);
t33=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp));
t34=*((C_word*)lf[45]+1);
t35=*((C_word*)lf[4]+1);
t36=*((C_word*)lf[3]+1);
t37=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2582,a[2]=t35,a[3]=t34,a[4]=t36,tmp=(C_word)a,a+=5,tmp));
t38=*((C_word*)lf[51]+1);
t39=*((C_word*)lf[52]+1);
t40=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=t38,a[3]=t39,tmp=(C_word)a,a+=4,tmp));
t41=*((C_word*)lf[51]+1);
t42=*((C_word*)lf[52]+1);
t43=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t41,a[3]=t42,tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[58]+1);
t45=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=*((C_word*)lf[58]+1);
t47=*((C_word*)lf[61]+1);
t48=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t46,a[3]=t47,tmp=(C_word)a,a+=4,tmp));
t49=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2929,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2951,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2973,tmp=(C_word)a,a+=2,tmp));
t52=*((C_word*)lf[68]+1);
t53=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=*((C_word*)lf[51]+1);
t55=*((C_word*)lf[52]+1);
t56=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=t54,a[3]=t55,tmp=(C_word)a,a+=4,tmp));
t57=*((C_word*)lf[68]+1);
t58=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=t57,tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[51]+1);
t60=*((C_word*)lf[52]+1);
t61=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=t59,a[3]=t60,tmp=(C_word)a,a+=4,tmp));
t62=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3069,tmp=(C_word)a,a+=2,tmp));
t63=*((C_word*)lf[77]+1);
t64=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3150,a[2]=t63,tmp=(C_word)a,a+=3,tmp));
t65=*((C_word*)lf[51]+1);
t66=*((C_word*)lf[52]+1);
t67=C_mutate(&lf[80],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3208,a[2]=t65,a[3]=t66,tmp=(C_word)a,a+=4,tmp));
t68=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4458,tmp=(C_word)a,a+=2,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 887  make-parameter */
t70=*((C_word*)lf[241]+1);
((C_proc3)(void*)(*((C_word*)t70+1)))(3,t70,t69,C_fix(79));}

/* k4535 in k1360 */
static void f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=C_mutate((C_word*)lf[151]+1,t1);
t3=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4539,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[154]+1,*((C_word*)lf[152]+1));
t5=*((C_word*)lf[51]+1);
t6=*((C_word*)lf[58]+1);
t7=*((C_word*)lf[52]+1);
t8=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4568,a[2]=t5,a[3]=t6,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=*((C_word*)lf[115]+1);
t10=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4614,tmp=(C_word)a,a+=2,tmp);
t12=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[161]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4715,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4740,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4792,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4844,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4973,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[43]+1);
t21=*((C_word*)lf[171]+1);
t22=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5076,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5266,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5382,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[176]+1);
t26=*((C_word*)lf[61]+1);
t27=*((C_word*)lf[58]+1);
t28=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5440,a[2]=t26,a[3]=t27,a[4]=t25,tmp=(C_word)a,a+=5,tmp));
t29=*((C_word*)lf[177]+1);
t30=*((C_word*)lf[153]+1);
t31=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5690,a[2]=t30,a[3]=t29,tmp=(C_word)a,a+=4,tmp));
t32=*((C_word*)lf[51]+1);
t33=*((C_word*)lf[52]+1);
t34=*((C_word*)lf[177]+1);
t35=C_mutate((C_word*)lf[182]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5700,a[2]=t32,a[3]=t34,a[4]=t33,tmp=(C_word)a,a+=5,tmp));
t36=C_mutate((C_word*)lf[183]+1,*((C_word*)lf[182]+1));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1235 register-feature! */
t38=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t38+1)))(3,t38,t37,lf[240]);}

/* k5712 in k4535 in k1360 */
static void f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word ab[78],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5716,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5825,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[186]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5924,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6056,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6189,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[188]+1);
t8=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6216,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[191],lf[192]);
t10=C_mutate((C_word*)lf[193]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6303,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[195]+1);
t12=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[195]+1);
t14=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6482,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6488,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[197],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6494,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6723,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[203]+1,*((C_word*)lf[202]+1));
t20=C_mutate((C_word*)lf[204]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6749,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6775,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6801,tmp=(C_word)a,a+=2,tmp));
t23=*((C_word*)lf[35]+1);
t24=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[208]+1);
t26=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6930,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=(C_word)C_a_i_vector(&a,1,C_fix(42));
t28=*((C_word*)lf[208]+1);
t29=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6942,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6956,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[35]+1);
t32=*((C_word*)lf[213]+1);
t33=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6989,a[2]=t32,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t34=*((C_word*)lf[214]+1);
t35=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7199,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=*((C_word*)lf[214]+1);
t37=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=t36,tmp=(C_word)a,a+=3,tmp));
t38=*((C_word*)lf[35]+1);
t39=*((C_word*)lf[213]+1);
t40=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7220,a[2]=t38,tmp=(C_word)a,a+=3,tmp));
t41=*((C_word*)lf[217]+1);
t42=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7443,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7508,tmp=(C_word)a,a+=2,tmp));
t44=*((C_word*)lf[196]+1);
t45=*((C_word*)lf[217]+1);
t46=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7578,a[2]=t44,a[3]=t45,tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7601,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7663,tmp=(C_word)a,a+=2,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1762 register-feature! */
t50=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t50+1)))(3,t50,t49,lf[239]);}

/* k7724 in k5712 in k4535 in k1360 */
static void f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7726,2,t0,t1);}
t2=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7728,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7777,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7836,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7842,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7848,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7858,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7867,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7876,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7905,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[236]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7929,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7935,tmp=(C_word)a,a+=2,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* list->queue in k7724 in k5712 in k4535 in k1360 */
static void f_7935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7935,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7943,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t3;
f_7943(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7951,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7951(t8,t3,t2);}}

/* do1241 in list->queue in k7724 in k5712 in k4535 in k1360 */
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7951,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7961,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* extras.scm: 1875 ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[237]);}
else{
t8=t5;
f_7961(2,t8,C_SCHEME_UNDEFINED);}}}

/* k7959 in do1241 in list->queue in k7724 in k5712 in k4535 in k1360 */
static void f_7961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7951(t3,((C_word*)t0)[2],t2);}

/* k7941 in list->queue in k7724 in k5712 in k4535 in k1360 */
static void f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[229],((C_word*)t0)[2],t1));}

/* queue->list in k7724 in k5712 in k4535 in k1360 */
static void f_7929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7929,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k7724 in k5712 in k4535 in k1360 */
static void f_7905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7905,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_setslot(t2,C_fix(1),t4);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
t7=(C_truep(t6)?(C_word)C_i_set_i_slot(t2,C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t3,C_fix(0)));}

/* queue-add! in k7724 in k5712 in k4535 in k1360 */
static void f_7876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7876,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7883,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t6);
if(C_truep(t7)){
t8=t5;
f_7883(t8,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t8=(C_word)C_slot(t2,C_fix(2));
t9=t5;
f_7883(t9,(C_word)C_i_setslot(t8,C_fix(1),t4));}}

/* k7881 in queue-add! in k7724 in k5712 in k4535 in k1360 */
static void C_fcall f_7883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k7724 in k5712 in k4535 in k1360 */
static void f_7867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7867,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,C_fix(0)));}

/* queue-first in k7724 in k5712 in k4535 in k1360 */
static void f_7858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7858,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,C_fix(0)));}

/* queue-empty? in k7724 in k5712 in k4535 in k1360 */
static void f_7848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7848,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3));}

/* queue? in k7724 in k5712 in k4535 in k1360 */
static void f_7842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7842,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[229]));}

/* make-queue in k7724 in k5712 in k4535 in k1360 */
static void f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[229],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* hash-table-fold in k7724 in k5712 in k4535 in k1360 */
static void f_7777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7777,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7789,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7789(t10,t1,C_fix(0),t4);}

/* loop in hash-table-fold in k7724 in k5712 in k4535 in k1360 */
static void C_fcall f_7789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7789,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_7805(t8,t1,t4);}}

/* fold2 in loop in hash-table-fold in k7724 in k5712 in k4535 in k1360 */
static void C_fcall f_7805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7805,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1789 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_7789(t4,t1,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7826,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(*((C_word*)lf[227]+1),C_fix(0));
t5=(C_word)C_slot(*((C_word*)lf[227]+1),C_fix(1));
/* extras.scm: 1790 p */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,t5,((C_word*)t0)[4]);}}

/* k7824 in fold2 in loop in hash-table-fold in k7724 in k5712 in k4535 in k1360 */
static void f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1790 fold2 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7805(t2,((C_word*)t0)[2],t1);}

/* hash-table-walk in k7724 in k5712 in k4535 in k1360 */
static void f_7728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7728,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7740,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7740(t9,t1,C_fix(0));}

/* do1205 in hash-table-walk in k7724 in k5712 in k4535 in k1360 */
static void C_fcall f_7740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7740,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7750,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7759,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* extras.scm: 1774 ##sys#for-each */
t6=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a7758 in do1205 in hash-table-walk in k7724 in k5712 in k4535 in k1360 */
static void f_7759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7759,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1775 p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k7748 in do1205 in hash-table-walk in k7724 in k5712 in k4535 in k1360 */
static void f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7740(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k5712 in k4535 in k1360 */
static void f_7663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7663,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7675,a[2]=t6,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7675(t8,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k5712 in k4535 in k1360 */
static void C_fcall f_7675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7675,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7691,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7691(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k5712 in k4535 in k1360 */
static void C_fcall f_7691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7691,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1757 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7675(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1758 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k5712 in k4535 in k1360 */
static void f_7601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7601,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7613,a[2]=t6,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7613(t8,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k5712 in k4535 in k1360 */
static void C_fcall f_7613(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7613,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7629,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7629(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k5712 in k4535 in k1360 */
static void C_fcall f_7629(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7629,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1743 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7613(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1744 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k5712 in k4535 in k1360 */
static void f_7578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7578r(t0,t1,t2,t3);}}

static void f_7578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7582,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t3);}

/* k7580 in alist->hash-table in k5712 in k4535 in k1360 */
static void f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7585,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7586 in k7580 in alist->hash-table in k5712 in k4535 in k1360 */
static void f_7587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7587,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1731 hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* k7583 in k7580 in alist->hash-table in k5712 in k4535 in k1360 */
static void f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k5712 in k4535 in k1360 */
static void f_7508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7508,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7520,a[2]=t6,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7520(t8,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k5712 in k4535 in k1360 */
static void C_fcall f_7520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7520,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7536,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7536(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k5712 in k4535 in k1360 */
static void C_fcall f_7536(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7536,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1721 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7520(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* extras.scm: 1722 loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge! in k5712 in k4535 in k1360 */
static void f_7443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7443,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t7,a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_7455(t9,t1,C_fix(0));}

/* do1147 in hash-table-merge! in k5712 in k4535 in k1360 */
static void C_fcall f_7455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7455,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7465,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7478,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7478(t8,t3,t4);}}

/* do1150 in do1147 in hash-table-merge! in k5712 in k4535 in k1360 */
static void C_fcall f_7478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7478,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7491,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1707 hash-table-set! */
t7=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t5,t6);}}

/* k7489 in do1150 in do1147 in hash-table-merge! in k5712 in k4535 in k1360 */
static void f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7478(t3,((C_word*)t0)[2],t2);}

/* k7463 in do1147 in hash-table-merge! in k5712 in k4535 in k1360 */
static void f_7465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7455(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k5712 in k4535 in k1360 */
static void f_7220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7220,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(4));
t6=(C_word)C_block_size(t4);
t7=(C_word)C_slot(t2,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7236,a[2]=t1,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1649 hashf */
t9=t5;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7236,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[6],t1);
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7253,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_7253(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7308(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}}

/* loop in k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7308,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1672 test */
t7=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k7322 in loop in k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=t2;
f_7327(t4,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=t2;
f_7327(t4,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),t3));}}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1679 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7308(t3,((C_word*)t0)[7],((C_word*)t0)[5],t2);}}

/* k7325 in k7322 in loop in k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void C_fcall f_7327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* loop in k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void C_fcall f_7253(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7253,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7272,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_slot(t3,C_fix(1));
t9=t7;
f_7272(t9,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t8));}
else{
t8=(C_word)C_slot(t3,C_fix(1));
t9=t7;
f_7272(t9,(C_word)C_i_setslot(t2,C_fix(1),t8));}}
else{
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1666 loop */
t12=t1;
t13=t3;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k7270 in loop in k7234 in hash-table-delete! in k5712 in k4535 in k1360 */
static void C_fcall f_7272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* hash-table-set! in k5712 in k4535 in k1360 */
static void f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7208,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7214,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7217,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1638 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t5,t6);}

/* a7216 in hash-table-set! in k5712 in k4535 in k1360 */
static void f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a7213 in hash-table-set! in k5712 in k4535 in k1360 */
static void f_7214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7214,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* hash-table-update!/default in k5712 in k4535 in k1360 */
static void f_7199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7199,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1633 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a7204 in hash-table-update!/default in k5712 in k4535 in k1360 */
static void f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k5712 in k4535 in k1360 */
static void f_6989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6989,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_6995(t9,t1);}

/* restart in hash-table-update! in k5712 in k4535 in k1360 */
static void C_fcall f_6995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t4=(C_word)C_block_size(t2);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* extras.scm: 1597 hashf */
t7=t3;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[5],t4);}

/* k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(2));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[12],lf[215]);
/* extras.scm: 1599 floor */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7189,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[14],t2);
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(((C_word*)t0)[13],C_fix(1073741823)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7036,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_times(((C_word*)t0)[13],C_fix(2));
t8=(C_word)C_i_fixnum_min(C_fix(1073741823),t7);
/* extras.scm: 1602 ##sys#hash-new-len */
t9=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,lf[192],t8);}
else{
t5=(C_word)C_slot(((C_word*)t0)[9],((C_word*)t0)[7]);
t6=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7058,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=t5,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_7058(t10,((C_word*)t0)[10],t5);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7119,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=t5,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_7119(t10,((C_word*)t0)[10],t5);}}}

/* loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void C_fcall f_7119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7119,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7144,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 1622 init */
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7153,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1626 test */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[11],t6);}}

/* k7151 in loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7153,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1627 proc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1628 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7119(t3,((C_word*)t0)[6],t2);}}

/* k7158 in k7151 in loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* k7142 in loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void C_fcall f_7058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7058,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 1613 init */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[10],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 1618 proc */
t9=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1619 loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* k7097 in loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* k7081 in loop in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* k7034 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1601 make-vector */
t2=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7026,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=t1;
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7376,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_7376(t9,t2,C_fix(0));}

/* do1130 in k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7376,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7386,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7399(t8,t3,t4);}}

/* loop in do1130 in k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void C_fcall f_7399(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7399,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7415,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1691 hashf */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k7413 in loop in do1130 in k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7415,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1693 loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_7399(t8,((C_word*)t0)[2],t7);}

/* k7384 in do1130 in k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7376(t3,((C_word*)t0)[2],t2);}

/* k7024 in k7021 in k7187 in k7009 in restart in hash-table-update! in k5712 in k4535 in k1360 */
static void f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* extras.scm: 1607 restart */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6995(t3,((C_word*)t0)[2]);}

/* ##sys#hash-new-len in k5712 in k4535 in k1360 */
static void f_6956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6956,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_fixnum_greater_or_equal_p(t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6966,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_6966(t7,t5);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t6;
f_6966(t8,(C_word)C_eqp(t7,C_SCHEME_END_OF_LIST));}}

/* k6964 in ##sys#hash-new-len in k5712 in k4535 in k1360 */
static void C_fcall f_6966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1584 ##sys#hash-new-len */
t3=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* hash-table-exists? in k5712 in k4535 in k1360 */
static void f_6942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6942,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6954,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1578 ref */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,t3,((C_word*)t0)[3]);}

/* k6952 in hash-table-exists? in k5712 in k4535 in k1360 */
static void f_6954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k5712 in k4535 in k1360 */
static void f_6930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6936,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1571 hash-table-ref */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}

/* a6935 in hash-table-ref/default in k5712 in k4535 in k1360 */
static void f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6936,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-ref in k5712 in k4535 in k1360 */
static void f_6807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_6807r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_6807r(t0,t1,t2,t3,t4);}}

static void f_6807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6817,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_block_size(t5);
/* extras.scm: 1546 hashf */
t9=t6;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t3,t8);}

/* k6815 in hash-table-ref in k5712 in k4535 in k1360 */
static void f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6920,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6838,a[2]=t8,a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6838(t10,((C_word*)t0)[2],t6);}
else{
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6880(t10,((C_word*)t0)[2],t6);}}

/* loop in k6815 in hash-table-ref in k5712 in k4535 in k1360 */
static void C_fcall f_6880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6880,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1562 def */
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6899,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1564 test */
t7=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k6897 in loop in k6815 in hash-table-ref in k5712 in k4535 in k1360 */
static void f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1566 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6880(t3,((C_word*)t0)[5],t2);}}

/* loop in k6815 in hash-table-ref in k5712 in k4535 in k1360 */
static void C_fcall f_6838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6838,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1555 def */
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_slot(t4,C_fix(1)));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1559 loop */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* f_6920 in k6815 in hash-table-ref in k5712 in k4535 in k1360 */
static void f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
/* ##sys#error */
t2=*((C_word*)lf[179]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[208],lf[209],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-size in k5712 in k4535 in k1360 */
static void f_6801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6801,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* string-ci-hash in k5712 in k4535 in k1360 */
static void f_6775(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6775r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6775r(t0,t1,t2,t3);}}

static void f_6775r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6779,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6779(t5,C_fix(536870912));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_6779(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k6777 in string-ci-hash in k5712 in k4535 in k1360 */
static void C_fcall f_6779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_and(C_fix(16777215),(C_word)C_hash_string_ci(((C_word*)t0)[3]));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,*((C_word*)lf[205]+1)));}

/* string-hash in k5712 in k4535 in k1360 */
static void f_6749(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6749r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6749r(t0,t1,t2,t3);}}

static void f_6749r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6753,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6753(t5,C_fix(536870912));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_6753(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k6751 in string-hash in k5712 in k4535 in k1360 */
static void C_fcall f_6753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_and(C_fix(16777215),(C_word)C_hash_string(((C_word*)t0)[3]));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,*((C_word*)lf[205]+1)));}

/* hash in k5712 in k4535 in k1360 */
static void f_6723(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6723r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6723r(t0,t1,t2,t3);}}

static void f_6723r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6727(t5,C_fix(536870912));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_6727(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k6725 in hash in k5712 in k4535 in k1360 */
static void C_fcall f_6727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1517 %hash */
t2=lf[197];
f_6494(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* %hash in k5712 in k4535 in k1360 */
static void f_6494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6494,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6497,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6522,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6721,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1513 rechash */
t11=((C_word*)t7)[1];
f_6522(t11,t10,t2,C_fix(0));}

/* k6719 in %hash in k5712 in k4535 in k1360 */
static void f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_and(C_fix(16777215),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,((C_word*)t0)[2]));}

/* rechash in %hash in k5712 in k4535 in k1360 */
static void C_fcall f_6522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6522,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
case C_SCHEME_END_OF_LIST:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));
default:
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hashptr(t2));}
else{
if(C_truep((C_word)C_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6595,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1495 hash-with-test */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6497(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1497 hash-with-test */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6497(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1499 input-port? */
t5=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
t4=(C_word)C_block_size(t2);
t5=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t6=(C_truep((C_word)C_specialp(t2))?(C_word)C_peek_fixnum(t2,C_fix(0)):C_fix(0));
t7=(C_word)C_u_fixnum_plus(t4,t6);
t8=(C_word)C_fixnum_greaterp(t4,C_fix(4));
t9=(C_truep(t8)?C_fix(4):t4);
t10=(C_word)C_u_fixnum_difference(t9,t5);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6659,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6659(t14,t1,t7,t5,t10);}}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}

/* loop in rechash in %hash in k5712 in k4535 in k1360 */
static void C_fcall f_6659(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6659,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_times(t2,C_fix(16));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6694,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1509 rechash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6522(t10,t7,t8,t9);}}

/* k6692 in loop in rechash in %hash in k5712 in k4535 in k1360 */
static void f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_fix(t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t3);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1509 loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6659(t7,((C_word*)t0)[2],t4,t5,t6);}

/* k6635 in rechash in %hash in k5712 in k4535 in k1360 */
static void f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fix(260):C_fix(261)));}

/* k6622 in rechash in %hash in k5712 in k4535 in k1360 */
static void f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=(C_word)C_a_i_arithmetic_shift(&a,2,t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6616,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1498 hash-with-test */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6497(t5,t3,t4,((C_word*)t0)[2]);}

/* k6614 in k6622 in rechash in %hash in k5712 in k4535 in k1360 */
static void f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k6593 in rechash in %hash in k5712 in k4535 in k1360 */
static void f_6595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* hash-with-test in %hash in k5712 in k4535 in k1360 */
static void C_fcall f_6497(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6497,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6507,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_6507(t6,t4);}
else{
t6=(C_word)C_byteblockp(t2);
t7=t5;
f_6507(t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}

/* k6505 in hash-with-test in %hash in k5712 in k4535 in k1360 */
static void C_fcall f_6507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1482 rechash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6522(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* hash-table-hash-function in k5712 in k4535 in k1360 */
static void f_6488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6488,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k5712 in k4535 in k1360 */
static void f_6482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6482,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-copy in k5712 in k4535 in k1360 */
static void f_6390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6390,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6400,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1447 make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k6398 in hash-table-copy in k5712 in k4535 in k1360 */
static void f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6405(t5,((C_word*)t0)[2],C_fix(0));}

/* do982 in k6398 in hash-table-copy in k5712 in k4535 in k1360 */
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6405,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,5,lf[194],((C_word*)t0)[4],t3,t4,t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6441,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6447(t8,t3,t4);}}

/* copy in do982 in k6398 in hash-table-copy in k5712 in k4535 in k1360 */
static void C_fcall f_6447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6447,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6468,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1459 copy */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k6466 in copy in do982 in k6398 in hash-table-copy in k5712 in k4535 in k1360 */
static void f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6439 in do982 in k6398 in hash-table-copy in k5712 in k4535 in k1360 */
static void f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6405(t4,((C_word*)t0)[2],t3);}

/* make-hash-table in k5712 in k4535 in k1360 */
static void f_6309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_6309r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6309r(t0,t1,t2);}}

static void f_6309r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6320,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6325,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-test957970 */
t7=t6;
f_6330(t7,t1);}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-hashf958968 */
t9=t5;
f_6325(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-len959965 */
t11=t4;
f_6320(t11,t1,t7,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body955961 */
t13=t3;
f_6311(t13,t1,t7,t9,t11);}}}}

/* def-test957 in make-hash-table in k5712 in k4535 in k1360 */
static void C_fcall f_6330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6330,NULL,2,t0,t1);}
/* def-hashf958968 */
t2=((C_word*)t0)[2];
f_6325(t2,t1,*((C_word*)lf[38]+1));}

/* def-hashf958 in make-hash-table in k5712 in k4535 in k1360 */
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6325,NULL,3,t0,t1,t2);}
/* def-len959965 */
t3=((C_word*)t0)[2];
f_6320(t3,t1,t2,lf[197]);}

/* def-len959 in make-hash-table in k5712 in k4535 in k1360 */
static void C_fcall f_6320(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6320,NULL,4,t0,t1,t2,t3);}
/* body955961 */
t4=((C_word*)t0)[2];
f_6311(t4,t1,t2,t3,C_fix(307));}

/* body955 in make-hash-table in k5712 in k4535 in k1360 */
static void C_fcall f_6311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6311,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6319,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1439 make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k6317 in body955 in make-hash-table in k5712 in k4535 in k1360 */
static void f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6319,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,5,lf[194],t1,C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]));}

/* hash-table? in k5712 in k4535 in k1360 */
static void f_6303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6303,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[194]));}

/* binary-search in k5712 in k4535 in k1360 */
static void f_6216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6216,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6297,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1395 list->vector */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_6220(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[190]));}}

/* k6295 in binary-search in k5712 in k4535 in k1360 */
static void f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6220(t3,t2);}

/* k6218 in binary-search in k5712 in k4535 in k1360 */
static void C_fcall f_6220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6220,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6234(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k6218 in binary-search in k5712 in k4535 in k1360 */
static void C_fcall f_6234(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6234,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6244,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1403 proc */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}

/* k6242 in loop in k6218 in binary-search in k5712 in k4535 in k1360 */
static void f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1405 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6234(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1406 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6234(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k5712 in k4535 in k1360 */
static void f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6189,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6203,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1385 vector->list */
t6=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6214,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1386 append */
t5=*((C_word*)lf[189]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k6212 in sort in k5712 in k4535 in k1360 */
static void f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1386 sort! */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6205 in sort in k5712 in k4535 in k1360 */
static void f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1385 sort! */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6201 in sort in k5712 in k4535 in k1360 */
static void f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1385 list->vector */
t2=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k5712 in k4535 in k1360 */
static void f_6056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6056,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6059,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_fix((C_word)C_header_size(((C_word*)t4)[1]));
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6146,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1368 vector->list */
t11=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* extras.scm: 1374 step */
t9=((C_word*)t6)[1];
f_6059(t9,t1,t8);}}

/* k6144 in sort! in k5712 in k4535 in k1360 */
static void f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6146,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1369 step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6059(t4,t3,((C_word*)t0)[2]);}

/* k6151 in k6144 in sort! in k5712 in k4535 in k1360 */
static void f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6155,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6155(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do926 in k6151 in k6144 in sort! in k5712 in k4535 in k1360 */
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6155,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k5712 in k4535 in k1360 */
static void C_fcall f_6059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6059,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_u_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_u_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6100,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6110,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1353 less? */
t10=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_i_slot(t3,C_fix(1),C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k6108 in step in sort! in k5712 in k4535 in k1360 */
static void f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[3];
f_6100(t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6100(t2,C_SCHEME_UNDEFINED);}}

/* k6098 in step in sort! in k5712 in k4535 in k1360 */
static void C_fcall f_6100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k6067 in step in sort! in k5712 in k4535 in k1360 */
static void f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1344 step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6059(t3,t2,t1);}

/* k6070 in k6067 in step in sort! in k5712 in k4535 in k1360 */
static void f_6072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6072,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6078,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1346 step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6059(t4,t3,t2);}

/* k6076 in k6070 in k6067 in step in sort! in k5712 in k4535 in k1360 */
static void f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1347 merge! */
t2=*((C_word*)lf[186]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k5712 in k4535 in k1360 */
static void f_5924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5924,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5927,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6006,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t3);
t10=(C_word)C_u_i_car(t2);
/* extras.scm: 1321 less? */
t11=t4;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}}}

/* k6004 in merge! in k5712 in k4535 in k1360 */
static void f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_6009(2,t4,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1324 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5927(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_6029(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1329 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5927(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k6027 in k6004 in merge! in k5712 in k4535 in k1360 */
static void f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6007 in k6004 in merge! in k5712 in k4535 in k1360 */
static void f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k5712 in k4535 in k1360 */
static void C_fcall f_5927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5927,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_u_i_car(t3);
/* extras.scm: 1306 less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k5932 in loop in merge! in k5712 in k4535 in k1360 */
static void f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1311 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5927(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[5]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1317 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5927(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k5712 in k4535 in k1360 */
static void f_5825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5825,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5859,a[2]=t4,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_5859(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k5712 in k4535 in k1360 */
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5859,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1289 less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,t2);}

/* k5864 in loop in merge in k5712 in k4535 in k1360 */
static void f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1292 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5859(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1296 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5859(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k5912 in k5864 in loop in merge in k5712 in k4535 in k1360 */
static void f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5884 in k5864 in loop in merge in k5712 in k4535 in k1360 */
static void f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k5712 in k4535 in k1360 */
static void f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5716,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5743,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5743(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5791,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5791(t9,t1,t4,t5);}}}

/* loop in sorted? in k5712 in k4535 in k1360 */
static void C_fcall f_5791(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5791,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t3);
/* extras.scm: 1272 less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* k5817 in loop in sorted? in k5712 in k4535 in k1360 */
static void f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1273 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5791(t4,((C_word*)t0)[4],t2,t3);}}

/* do873 in sorted? in k5712 in k4535 in k1360 */
static void C_fcall f_5743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5743,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_5753(2,t5,t3);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* extras.scm: 1266 less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t5,t7);}}

/* k5751 in do873 in sorted? in k5712 in k4535 in k1360 */
static void f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5753,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_5743(t3,((C_word*)t0)[5],t2);}}

/* sprintf in k4535 in k1360 */
static void f_5700(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5700r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5700r(t0,t1,t2,t3);}}

static void f_5700r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5704,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1229 open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5702 in sprintf in k4535 in k1360 */
static void f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5707,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_apply(6,0,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5705 in k5702 in sprintf in k4535 in k1360 */
static void f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1231 get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* printf in k4535 in k1360 */
static void f_5690(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5690r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5690r(t0,t1,t2,t3);}}

static void f_5690r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5698,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1221 current-output-port */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5696 in printf in k4535 in k1360 */
static void f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fprintf in k4535 in k1360 */
static void f_5440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_5440r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5440r(t0,t1,t2,t3,t4);}}

static void f_5440r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5446(t8,t1,t3,t4);}

/* rec in fprintf in k4535 in k1360 */
static void C_fcall f_5446(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5446,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_block_size(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5456,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=f_5452(t8);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t9,a[8]=t12,a[9]=t8,a[10]=t7,a[11]=t6,tmp=(C_word)a,a+=12,tmp));
t14=((C_word*)t12)[1];
f_5479(t14,t1,t10);}

/* do835 in rec in fprintf in k4535 in k1360 */
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5479,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[10]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5489,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
if(C_truep(t4)){
t5=f_5452(((C_word*)t0)[9]);
t6=(C_word)C_u_i_char_upcase(t5);
switch(t6){
case C_make_character(83):
t7=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1192 write */
t8=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,((C_word*)t0)[5]);
case C_make_character(65):
t7=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1193 display */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,((C_word*)t0)[5]);
case C_make_character(67):
t7=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1194 ##sys#write-char-0 */
t8=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,((C_word*)t0)[5]);
case C_make_character(66):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1195 ##sys#number->string */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_fix(2));
case C_make_character(79):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1196 ##sys#number->string */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_fix(8));
case C_make_character(88):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5591,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1197 ##sys#number->string */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_fix(16));
case C_make_character(33):
/* extras.scm: 1198 ##sys#flush-output */
t7=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,((C_word*)t0)[5]);
case C_make_character(63):
t7=f_5456(((C_word*)t0)[7]);
t8=f_5456(((C_word*)t0)[7]);
/* extras.scm: 1203 rec */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5446(t9,t3,t7,t8);
case C_make_character(126):
/* extras.scm: 1204 ##sys#write-char-0 */
t7=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,C_make_character(126),((C_word*)t0)[5]);
case C_make_character(37):
/* extras.scm: 1205 newline */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,((C_word*)t0)[5]);
default:
t7=(C_word)C_eqp(t6,C_make_character(37));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(78)));
if(C_truep(t8)){
/* extras.scm: 1206 newline */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t5))){
t9=f_5452(((C_word*)t0)[9]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5664,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=t3;
f_5489(2,t11,f_5664(t10,t9));}
else{
/* extras.scm: 1213 ##sys#error */
t9=*((C_word*)lf[179]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t3,lf[177],lf[180],t5);}}}}
else{
/* extras.scm: 1214 ##sys#write-char-0 */
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[5]);}}}

/* skip in do835 in rec in fprintf in k4535 in k1360 */
static C_word C_fcall f_5664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_5452(((C_word*)t0)[3]);
t5=t2;
t1=t5;
goto loop;}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1)));
return(t2);}}

/* k5589 in do835 in rec in fprintf in k4535 in k1360 */
static void f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1197 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5572 in do835 in rec in fprintf in k4535 in k1360 */
static void f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1196 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5555 in do835 in rec in fprintf in k4535 in k1360 */
static void f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1195 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5487 in do835 in rec in fprintf in k4535 in k1360 */
static void f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_5452(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5479(t3,((C_word*)t0)[2],t2);}

/* next in rec in fprintf in k4535 in k1360 */
static C_word C_fcall f_5456(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fetch in rec in fprintf in k4535 in k1360 */
static C_word C_fcall f_5452(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1)));
return(t1);}

/* string-chop in k4535 in k1360 */
static void f_5382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5382,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5391,a[2]=t6,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5391(t8,t1,t4,C_fix(0));}

/* loop in string-chop in k4535 in k1360 */
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5391,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_fixnum_plus(t3,t2);
/* extras.scm: 1159 ##sys#substring */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
/* extras.scm: 1160 ##sys#substring */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k5420 in loop in string-chop in k4535 in k1360 */
static void f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5426,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* extras.scm: 1160 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5391(t5,t2,t3,t4);}

/* k5424 in k5420 in loop in string-chop in k4535 in k1360 */
static void f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5409 in loop in string-chop in k4535 in k1360 */
static void f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k4535 in k1360 */
static void f_5266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5266,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5272,a[2]=t3,a[3]=t6,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
/* extras.scm: 1148 collect */
t8=((C_word*)t6)[1];
f_5272(t8,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k4535 in k1360 */
static void C_fcall f_5272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5272,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5286,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5300,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1130 ##sys#substring */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_5290(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5305,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_5305(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k4535 in k1360 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5305,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1134 collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_5272(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5344,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5370,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1142 ##sys#substring */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_5344(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1147 loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k5368 in loop in collect in string-translate* in k4535 in k1360 */
static void f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5344(t4,t3);}

/* k5342 in loop in collect in string-translate* in k4535 in k1360 */
static void C_fcall f_5344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5344,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* extras.scm: 1143 collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5272(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k5298 in collect in string-translate* in k4535 in k1360 */
static void f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5300,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5290(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k5288 in collect in string-translate* in k4535 in k1360 */
static void C_fcall f_5290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1128 reverse */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5284 in collect in string-translate* in k4535 in k1360 */
static void f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1126 ##sys#fragments->string */
t2=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k4535 in k1360 */
static void f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_5076r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5076r(t0,t1,t2,t3,t4);}}

static void f_5076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5079,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_5113(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5244,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1084 list->string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
/* extras.scm: 1087 instring */
f_5079(t6,t3);}}}

/* k5259 in string-translate in k4535 in k1360 */
static void f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1084 instring */
f_5079(((C_word*)t0)[2],t1);}

/* f_5244 in string-translate in k4535 in k1360 */
static void f_5244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5244,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k5111 in string-translate in k4535 in k1360 */
static void f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_5116(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* extras.scm: 1092 list->string */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t4=t2;
f_5116(2,t4,t3);}}}
else{
t3=t2;
f_5116(2,t3,C_SCHEME_FALSE);}}

/* k5114 in k5111 in string-translate in k4535 in k1360 */
static void f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_block_size(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1099 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k5123 in k5114 in k5111 in string-translate in k4535 in k1360 */
static void f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5130(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k5123 in k5114 in k5111 in string-translate in k4535 in k1360 */
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5130,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* extras.scm: 1103 ##sys#substring */
t4=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[6],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[6]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[5],t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5149,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 1106 from */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k5147 in loop in k5123 in k5114 in k5111 in string-translate in k4535 in k1360 */
static void f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[8];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[8]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1113 loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5130(t7,((C_word*)t0)[3],t5,t6);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[7],((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[8],t1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1118 loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5130(t7,((C_word*)t0)[3],t5,t6);}}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1110 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5130(t5,((C_word*)t0)[3],t4,((C_word*)t0)[6]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1109 loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5130(t6,((C_word*)t0)[3],t4,t5);}}

/* instring in string-translate in k4535 in k1360 */
static void C_fcall f_5079(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5079,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5084,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_5084 in instring in string-translate in k4535 in k1360 */
static void f_5084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5090(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_5090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k4535 in k1360 */
static void f_4973(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4973r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4973r(t0,t1,t2,t3);}}

static void f_4973r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4977(t5,lf[170]);}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_4977(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k4975 in string-intersperse in k4535 in k1360 */
static void C_fcall f_4977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4977,NULL,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4985,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4985(t6,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k4975 in string-intersperse in k4535 in k1360 */
static void C_fcall f_4985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4985,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[167]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[3]);
/* extras.scm: 1047 ##sys#allocate-vector */
t6=*((C_word*)lf[168]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_block_size(t5);
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t3);
t9=(C_word)C_u_fixnum_plus(t7,t8);
/* extras.scm: 1062 loop1 */
t13=t1;
t14=t6;
t15=t9;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
/* extras.scm: 1064 ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k4993 in loop1 in k4975 in string-intersperse in k4535 in k1360 */
static void f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_5000(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k4993 in loop1 in k4975 in string-intersperse in k4535 in k1360 */
static C_word C_fcall f_5000(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_u_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_u_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k4535 in k1360 */
static void f_4844(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4844r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4844r(t0,t1,t2,t3);}}

static void f_4844r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(18);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[165]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_eqp(t6,C_fix(2));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t9=(C_word)C_block_size(t2);
t10=(C_word)C_block_size(t5);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4879,a[2]=t5,a[3]=t15,a[4]=t10,a[5]=t2,a[6]=t13,a[7]=t8,a[8]=t12,a[9]=t9,tmp=(C_word)a,a+=10,tmp));
t17=((C_word*)t15)[1];
f_4879(t17,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k4535 in k1360 */
static void C_fcall f_4879(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4879,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* extras.scm: 1023 add */
t8=((C_word*)t0)[6];
f_4859(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_4889(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4906,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_4906(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k4535 in k1360 */
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4906,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* extras.scm: 1028 loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_4879(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4945,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1032 add */
t8=((C_word*)t0)[3];
f_4859(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* extras.scm: 1033 loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_4879(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* extras.scm: 1034 scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k4943 in scan in loop in string-split in k4535 in k1360 */
static void f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1032 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4879(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k4887 in loop in string-split in k4535 in k1360 */
static void f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k4535 in k1360 */
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4859,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4874,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1016 ##sys#substring */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k4872 in add in string-split in k4535 in k1360 */
static void f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4866,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_4866(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_4866(t5,t4);}}

/* k4864 in k4872 in add in string-split in k4535 in k1360 */
static void C_fcall f_4866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k4535 in k1360 */
static void f_4792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4792r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4792r(t0,t1,t2,t3,t4);}}

static void f_4792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t5=(C_word)C_block_size(t4);
t6=(C_word)C_fixnum_greater_or_equal_p(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(C_word)C_fixnum_greater_or_equal_p(t5,C_fix(2));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4805,a[2]=t9,a[3]=t7,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t11=t10;
f_4805(t11,(C_word)C_slot(t4,C_fix(2)));}
else{
t11=(C_word)C_block_size(t2);
t12=(C_word)C_u_fixnum_difference(t11,t7);
t13=(C_word)C_block_size(t3);
t14=(C_word)C_u_fixnum_difference(t13,t9);
t15=t10;
f_4805(t15,(C_word)C_i_fixnum_min(t12,t14));}}

/* k4803 in substring-ci=? in k4535 in k1360 */
static void C_fcall f_4805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* substring=? in k4535 in k1360 */
static void f_4740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4740r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4740r(t0,t1,t2,t3,t4);}}

static void f_4740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t5=(C_word)C_block_size(t4);
t6=(C_word)C_fixnum_greater_or_equal_p(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(C_word)C_fixnum_greater_or_equal_p(t5,C_fix(2));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4753,a[2]=t9,a[3]=t7,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t11=t10;
f_4753(t11,(C_word)C_slot(t4,C_fix(2)));}
else{
t11=(C_word)C_block_size(t2);
t12=(C_word)C_u_fixnum_difference(t11,t7);
t13=(C_word)C_block_size(t3);
t14=(C_word)C_u_fixnum_difference(t13,t9);
t15=t10;
f_4753(t15,(C_word)C_i_fixnum_min(t12,t14));}}

/* k4751 in substring=? in k4535 in k1360 */
static void C_fcall f_4753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_substring_compare(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* string-compare3-ci in k4535 in k1360 */
static void f_4715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4715,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=(C_word)C_block_size(t3);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_lessp(t6,C_fix(0));
t8=(C_truep(t7)?t4:t5);
t9=(C_word)C_string_compare_case_insensitive(t2,t3,t8);
t10=(C_word)C_eqp(t9,C_fix(0));
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?t6:t9));}

/* string-compare3 in k4535 in k1360 */
static void f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4690,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=(C_word)C_block_size(t3);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_lessp(t6,C_fix(0));
t8=(C_truep(t7)?t4:t5);
t9=(C_word)C_mem_compare(t2,t3,t8);
t10=(C_word)C_eqp(t9,C_fix(0));
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?t6:t9));}

/* substring-index-ci in k4535 in k1360 */
static void f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4671r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4671r(t0,t1,t2,t3,t4);}}

static void f_4671r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4681,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 941  traverse */
f_4614(t1,t2,t3,t6,t7);}

/* a4680 in substring-index-ci in k4535 in k1360 */
static void f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4681,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* substring-index in k4535 in k1360 */
static void f_4652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4652r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4652r(t0,t1,t2,t3,t4);}}

static void f_4652r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4662,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 935  traverse */
f_4614(t1,t2,t3,t6,t7);}

/* a4661 in substring-index in k4535 in k1360 */
static void f_4662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4662,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k4535 in k1360 */
static void C_fcall f_4614(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4614,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t3);
t7=(C_word)C_block_size(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4626,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_4626(t11,t1,t4,t7);}

/* loop in traverse in k4535 in k1360 */
static void C_fcall f_4626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4626,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 929  test */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k4637 in loop in traverse in k4535 in k1360 */
static void f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 931  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4626(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k4535 in k1360 */
static void f_4604(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4604r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4604r(t0,t1,t2);}}

static void f_4604r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[155]+1),t2);}

/* k4610 in conc in k4535 in k1360 */
static void f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k4535 in k1360 */
static void f_4568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4568,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* extras.scm: 905  symbol->string */
t3=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* extras.scm: 906  ##sys#number->string */
t3=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4596,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 908  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}

/* k4594 in ->string in k4535 in k1360 */
static void f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4599,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 909  display */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k4597 in k4594 in ->string in k4535 in k1360 */
static void f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 910  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pretty-print in k4535 in k1360 */
static void f_4539(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4539r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4539r(t0,t1,t2,t3);}}

static void f_4539r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_4543(2,t5,(C_word)C_slot(t3,C_fix(0)));}
else{
/* extras.scm: 890  current-output-port */
t5=*((C_word*)lf[153]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4541 in pretty-print in k4535 in k1360 */
static void f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 891  pretty-print-width */
t4=*((C_word*)lf[151]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4548 in k4541 in pretty-print in k4535 in k1360 */
static void f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 891  ##extras#generic-write */
t3=lf[80];
f_3208(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a4551 in k4548 in k4541 in pretty-print in k4535 in k1360 */
static void f_4552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4552,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4556,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 891  display */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k4554 in a4551 in k4548 in k4541 in pretty-print in k4535 in k1360 */
static void f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k4544 in k4541 in pretty-print in k4535 in k1360 */
static void f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##extras#reverse-string-append in k1360 */
static void f_4458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4458,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
/* extras.scm: 882  rev-string-append */
t6=((C_word*)t4)[1];
f_4461(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##extras#reverse-string-append in k1360 */
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4461,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4477,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 873  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 880  make-string */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k4475 in rev-string-append in ##extras#reverse-string-append in k1360 */
static void f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4486,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4486(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k4475 in rev-string-append in ##extras#reverse-string-append in k1360 */
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4486,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 878  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* ##extras#generic-write in k1360 */
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3208,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3211,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3263,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3269,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3321,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,tmp=(C_word)a,a+=10,tmp));
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3802,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4449,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 862  make-string */
t15=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 863  wr */
t14=((C_word*)t11)[1];
f_3321(t14,t1,t2,C_fix(0));}}

/* k4447 in ##extras#generic-write in k1360 */
static void f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4453,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 862  pp */
t3=((C_word*)t0)[3];
f_3802(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4451 in k4447 in ##extras#generic-write in k1360 */
static void f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 862  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in ##extras#generic-write in k1360 */
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[133],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3802,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[8],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=((C_word*)t0)[8],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[8],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,tmp=(C_word)a,a+=7,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t11,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4302,a[2]=t21,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4308,a[2]=t21,a[3]=t11,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t11,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4320,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4357,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,tmp=(C_word)a,a+=10,tmp));
/* extras.scm: 859  pr */
t56=((C_word*)t9)[1];
f_3870(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4357,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[138]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_4367(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[148]);
if(C_truep(t5)){
t6=t4;
f_4367(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[149]);
t7=t4;
f_4367(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[150])));}}}

/* k4365 in style in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[139]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[140]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[141]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[142]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[143]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[144]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[145]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[146]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[147]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in ##extras#generic-write in k1360 */
static void f_4348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4348,5,t0,t1,t2,t3,t4);}
/* extras.scm: 837  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4136(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in ##extras#generic-write in k1360 */
static void f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4342,5,t0,t1,t2,t3,t4);}
/* extras.scm: 834  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4136(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in ##extras#generic-write in k1360 */
static void f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4320,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_u_i_car(t5);
t8=t6;
f_4327(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_4327(t7,C_SCHEME_FALSE);}}

/* k4325 in pp-let in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 831  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4136(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in ##extras#generic-write in k1360 */
static void f_4314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4314,5,t0,t1,t2,t3,t4);}
/* extras.scm: 826  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4022(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in ##extras#generic-write in k1360 */
static void f_4308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4308,5,t0,t1,t2,t3,t4);}
/* extras.scm: 823  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4136(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in ##extras#generic-write in k1360 */
static void f_4302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4302,5,t0,t1,t2,t3,t4);}
/* extras.scm: 820  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4022(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in ##extras#generic-write in k1360 */
static void f_4296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4296,5,t0,t1,t2,t3,t4);}
/* extras.scm: 817  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4136(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in ##extras#generic-write in k1360 */
static void f_4290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4290,5,t0,t1,t2,t3,t4);}
/* extras.scm: 814  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4136(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in ##extras#generic-write in k1360 */
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4284,5,t0,t1,t2,t3,t4);}
/* extras.scm: 811  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4050(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4136(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4136,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4221,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_car(t2);
t13=(C_word)C_slot(t2,C_fix(1));
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4282,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 802  out */
t16=((C_word*)t0)[2];
f_3302(t16,t15,lf[137],t3);}

/* k4280 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 802  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4232 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4249,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 806  out */
t7=((C_word*)t0)[2];
f_3302(t7,t6,lf[136],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 808  tail1 */
t5=((C_word*)t0)[5];
f_4139(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k4262 in k4232 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 806  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4247 in k4232 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 807  tail1 */
t4=((C_word*)t0)[4];
f_4139(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4139,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4162,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 786  indent */
t13=((C_word*)t0)[2];
f_3838(t13,t12,t5,t4);}
else{
/* extras.scm: 787  tail2 */
t7=((C_word*)t0)[4];
f_4180(t7,t1,t2,t3,t4,t5);}}

/* k4164 in tail1 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 786  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3870(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4160 in tail1 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 786  tail2 */
t2=((C_word*)t0)[6];
f_4180(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4180,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4203,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 794  indent */
t13=((C_word*)t0)[2];
f_3838(t13,t12,t5,t4);}
else{
/* extras.scm: 795  tail3 */
t7=((C_word*)t0)[4];
f_4221(t7,t1,t2,t3,t4);}}

/* k4205 in tail2 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 794  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3870(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4201 in tail2 in pp-general in pp in ##extras#generic-write in k1360 */
static void f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 794  tail3 */
t2=((C_word*)t0)[5];
f_4221(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4221,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 798  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4059(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4059(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4059,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4065(t10,t1,t2,t3);}

/* loop in pp-down in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4065(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4065,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_u_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 769  indent */
t10=((C_word*)t0)[4];
f_3838(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 771  out */
t4=((C_word*)t0)[2];
f_3302(t4,t1,lf[133],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4118,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 775  indent */
t8=((C_word*)t0)[4];
f_3838(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4132 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 775  out */
t2=((C_word*)t0)[3];
f_3302(t2,((C_word*)t0)[2],lf[135],t1);}

/* k4128 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 775  indent */
t2=((C_word*)t0)[4];
f_3838(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4120 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 774  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3870(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4116 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 773  out */
t2=((C_word*)t0)[3];
f_3302(t2,((C_word*)t0)[2],lf[134],t1);}

/* k4094 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 769  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3870(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4086 in loop in pp-down in pp in ##extras#generic-write in k1360 */
static void f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 768  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4065(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4050,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4054,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 759  out */
t7=((C_word*)t0)[2];
f_3302(t7,t6,lf[132],t3);}

/* k4052 in pp-list in pp in ##extras#generic-write in k1360 */
static void f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 760  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4059(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in ##extras#generic-write in k1360 */
static void C_fcall f_4022(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4022,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4026,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4048,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 751  out */
t9=((C_word*)t0)[2];
f_3302(t9,t8,lf[131],t3);}

/* k4046 in pp-call in pp in ##extras#generic-write in k1360 */
static void f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 751  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4024 in pp-call in pp in ##extras#generic-write in k1360 */
static void f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 753  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4059(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in ##extras#generic-write in k1360 */
static void f_3957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3957,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 731  read-macro? */
f_3211(t5,t2);}

/* k3962 in pp-expr in pp in ##extras#generic-write in k1360 */
static void f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
if(C_truep(t1)){
t2=f_3263(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_3269(((C_word*)t0)[13]);
/* extras.scm: 733  out */
t5=((C_word*)t0)[7];
f_3302(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3991,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 738  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4357(t4,t3,t2);}
else{
/* extras.scm: 745  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4050(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k3989 in k3962 in pp-expr in pp in ##extras#generic-write in k1360 */
static void f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 740  proc */
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 741  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4015 in k3989 in k3962 in pp-expr in pp in ##extras#generic-write in k1360 */
static void f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 743  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_4136(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 744  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4022(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k3973 in k3962 in pp-expr in pp in ##extras#generic-write in k1360 */
static void f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 732  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3870(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in ##extras#generic-write in k1360 */
static void C_fcall f_3870(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3870,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 717  max */
t14=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 728  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3321(t8,t1,t2,t3);}}

/* k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 718  ##extras#generic-write */
t6=lf[80];
f_3208(t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a3920 in k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3921,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k3884 in k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 724  ##extras#reverse-string-append */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 726  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 727  vector->list */
t3=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k3913 in k3884 in k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 727  out */
t3=((C_word*)t0)[3];
f_3302(t3,t2,lf[128],((C_word*)t0)[2]);}

/* k3917 in k3913 in k3884 in k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 727  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4050(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k3897 in k3884 in k3881 in pr in pp in ##extras#generic-write in k1360 */
static void f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 724  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in ##extras#generic-write in k1360 */
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3838,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3854,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3861,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 711  make-string */
t6=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 712  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3805(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3859 in indent in pp in ##extras#generic-write in k1360 */
static void f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 711  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3852 in indent in pp in ##extras#generic-write in k1360 */
static void f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 711  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3805(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in ##extras#generic-write in k1360 */
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3805,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3829,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 704  out */
t6=((C_word*)t0)[2];
f_3302(t6,t5,lf[125],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3836,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 705  ##sys#substring */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[126],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3834 in spaces in pp in ##extras#generic-write in k1360 */
static void f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 705  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3827 in spaces in pp in ##extras#generic-write in k1360 */
static void f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 704  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3805(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in ##extras#generic-write in k1360 */
static void C_fcall f_3321(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3321,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 643  wr-expr */
t6=t5;
f_3324(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 644  wr-lst */
t6=t4;
f_3351(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 645  out */
t6=((C_word*)t0)[8];
f_3302(t6,t1,lf[95],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3477,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 646  vector->list */
t7=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[98]:lf[99]);
/* extras.scm: 647  out */
t7=((C_word*)t0)[8];
f_3302(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 648  ##sys#number? */
t7=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k3498 in wr in ##extras#generic-write in k1360 */
static void f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3507,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 648  ##sys#number->string */
t3=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 650  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 653  ##sys#procedure->string */
t3=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 655  out */
t2=((C_word*)t0)[8];
f_3302(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 656  out */
t3=((C_word*)t0)[8];
f_3302(t3,t2,lf[105],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 670  make-string */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3648,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 672  out */
t4=((C_word*)t0)[8];
f_3302(t4,t3,lf[110],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 683  out */
t2=((C_word*)t0)[8];
f_3302(t2,((C_word*)t0)[7],lf[111],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 684  out */
t2=((C_word*)t0)[8];
f_3302(t2,((C_word*)t0)[7],lf[112],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3732,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 685  ##sys#pointer->string */
t3=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 687  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 690  port? */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}}}}}}}}}

/* k3755 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 690  string-append */
t4=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[116],t3,lf[117]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 692  out */
t3=((C_word*)t0)[5];
f_3302(t3,t2,lf[120],((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(lf[121],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
if(C_truep(t3)){
/* extras.scm: 696  out */
t4=((C_word*)t0)[5];
f_3302(t4,((C_word*)t0)[4],lf[122],((C_word*)t0)[3]);}
else{
/* extras.scm: 697  out */
t4=((C_word*)t0)[5];
f_3302(t4,((C_word*)t0)[4],lf[123],((C_word*)t0)[3]);}}}}

/* k3772 in k3755 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3784,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 693  ##sys#lambda-info->string */
t4=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3782 in k3772 in k3755 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 693  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3775 in k3772 in k3755 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 694  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],lf[118],((C_word*)t0)[2]);}

/* k3762 in k3755 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 690  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3739 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3744,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 688  ##sys#user-print-hook */
t3=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k3742 in k3739 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 689  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3749 in k3742 in k3739 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 689  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3730 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 685  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 673  char-name */
t3=*((C_word*)lf[109]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 675  out */
t3=((C_word*)t0)[6];
f_3302(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 677  out */
t3=((C_word*)t0)[6];
f_3302(t3,t2,lf[106],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[107]:lf[108]);
/* extras.scm: 680  out */
t5=((C_word*)t0)[6];
f_3302(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 682  make-string */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k3705 in k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 682  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3684 in k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 681  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k3691 in k3684 in k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 681  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3668 in k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 678  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k3675 in k3668 in k3649 in k3646 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 678  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3640 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 670  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3560(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void C_fcall f_3560(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3560,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3567,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t7=t5;
f_3567(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_3567(t6,C_SCHEME_FALSE);}}

/* k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void C_fcall f_3567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3567,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3590,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 664  ##sys#substring */
t9=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 666  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3560(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 668  ##sys#substring */
t4=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k3617 in k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 668  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3613 in k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 667  out */
t2=((C_word*)t0)[3];
f_3302(t2,((C_word*)t0)[2],lf[104],t1);}

/* k3596 in k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 664  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3592 in k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 663  out */
t2=((C_word*)t0)[3];
f_3302(t2,((C_word*)t0)[2],lf[103],t1);}

/* k3588 in k3565 in loop in k3556 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 661  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3560(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3537 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 653  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3514 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3519,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 651  ##sys#print */
t3=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k3517 in k3514 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 652  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3524 in k3517 in k3514 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 652  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3505 in k3498 in wr in ##extras#generic-write in k1360 */
static void f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 648  out */
t2=((C_word*)t0)[4];
f_3302(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3475 in wr in ##extras#generic-write in k1360 */
static void f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3481,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 646  out */
t3=((C_word*)t0)[3];
f_3302(t3,t2,lf[96],((C_word*)t0)[2]);}

/* k3479 in k3475 in wr in ##extras#generic-write in k1360 */
static void f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 646  wr-lst */
t2=((C_word*)t0)[4];
f_3351(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in ##extras#generic-write in k1360 */
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3324,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 628  read-macro? */
f_3211(t4,t2);}

/* k3329 in wr-expr in wr in ##extras#generic-write in k1360 */
static void f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
if(C_truep(t1)){
t2=f_3263(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3342,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_3269(((C_word*)t0)[8]);
/* extras.scm: 629  out */
t5=((C_word*)t0)[4];
f_3302(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 630  wr-lst */
t2=((C_word*)t0)[2];
f_3351(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k3340 in k3329 in wr-expr in wr in ##extras#generic-write in k1360 */
static void f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 629  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in ##extras#generic-write in k1360 */
static void C_fcall f_3351(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3351,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3369,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3434,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 635  out */
t8=((C_word*)t0)[2];
f_3302(t8,t7,lf[93],t3);}
else{
t6=t5;
f_3369(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 641  out */
t4=((C_word*)t0)[2];
f_3302(t4,t1,lf[94],t3);}}

/* k3432 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 635  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3371(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void C_fcall f_3371(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3371,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3395,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3403,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 638  out */
t9=((C_word*)t0)[2];
f_3302(t9,t8,lf[89],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 639  out */
t5=((C_word*)t0)[2];
f_3302(t5,t1,lf[90],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3423,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 640  out */
t7=((C_word*)t0)[2];
f_3302(t7,t6,lf[92],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k3421 in loop in k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 640  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3417 in loop in k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 640  out */
t2=((C_word*)t0)[3];
f_3302(t2,((C_word*)t0)[2],lf[91],t1);}

/* k3401 in loop in k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 638  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3321(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3393 in loop in k3367 in wr-lst in wr in ##extras#generic-write in k1360 */
static void f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 638  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in ##extras#generic-write in k1360 */
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3302,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 623  output */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3310 in out in ##extras#generic-write in k1360 */
static void f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in ##extras#generic-write in k1360 */
static C_word C_fcall f_3269(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t4)){
return(lf[85]);}
else{
t5=(C_word)C_eqp(t2,lf[82]);
if(C_truep(t5)){
return(lf[86]);}
else{
t6=(C_word)C_eqp(t2,lf[83]);
if(C_truep(t6)){
return(lf[87]);}
else{
t7=(C_word)C_eqp(t2,lf[84]);
return((C_truep(t7)?lf[88]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in ##extras#generic-write in k1360 */
static C_word C_fcall f_3263(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_u_i_cadr(t1));}

/* read-macro? in ##extras#generic-write in k1360 */
static void C_fcall f_3211(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3211,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(t3,lf[81]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_3243(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[82]);
if(C_truep(t7)){
t8=t6;
f_3243(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[83]);
t9=t6;
f_3243(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[84])));}}}

/* k3241 in read-macro? in ##extras#generic-write in k1360 */
static void C_fcall f_3243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-output-port in k1360 */
static void f_3150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+27)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3150r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3150r(t0,t1,t2,t3,t4);}}

static void f_3150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(27);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_vector(&a,7,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,t8,t9,t10,C_SCHEME_FALSE);
t12=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=t1,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 584  ##sys#make-port */
t14=*((C_word*)lf[74]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,C_SCHEME_FALSE,t11,lf[79],lf[76]);}

/* k3161 in make-output-port in k1360 */
static void f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3192 in make-output-port in k1360 */
static void f_3193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3193,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 581  flush */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a3183 in make-output-port in k1360 */
static void f_3184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3184,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3188,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 578  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3186 in a3183 in make-output-port in k1360 */
static void f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a3177 in make-output-port in k1360 */
static void f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3178,4,t0,t1,t2,t3);}
/* extras.scm: 576  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3167 in make-output-port in k1360 */
static void f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3168,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 574  string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3174 in a3167 in make-output-port in k1360 */
static void f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 574  write */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k1360 */
static void f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3069r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3069r(t0,t1,t2,t3,t4,t5);}}

static void f_3069r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_vector(&a,7,t8,t9,C_SCHEME_FALSE,C_SCHEME_FALSE,t10,C_SCHEME_FALSE,t11);
t13=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3082,a[2]=t1,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 561  ##sys#make-port */
t15=*((C_word*)lf[74]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,C_SCHEME_TRUE,t12,lf[75],lf[76]);}

/* k3080 in make-input-port in k1360 */
static void f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3137 in make-input-port in k1360 */
static void f_3138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3138,3,t0,t1,t2);}
/* extras.scm: 559  ready? */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3128 in make-input-port in k1360 */
static void f_3129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3129,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 555  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3131 in a3128 in make-input-port in k1360 */
static void f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a3107 in make-input-port in k1360 */
static void f_3108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3108,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 546  peek */
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 549  read */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

/* k3122 in a3107 in make-input-port in k1360 */
static void f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3086 in make-input-port in k1360 */
static void f_3087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3087,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 539  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=(C_word)C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* extras.scm: 543  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}}}

/* with-output-to-string in k1360 */
static void f_3041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3041,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3045,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 521  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3043 in with-output-to-string in k1360 */
static void f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3063 in k3043 in with-output-to-string in k1360 */
static void f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[60]+1));
t3=C_mutate((C_word*)lf[60]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3054 in k3043 in with-output-to-string in k1360 */
static void f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 522  thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3057 in a3054 in k3043 in with-output-to-string in k1360 */
static void f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 523  get-output-string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[60]+1));}

/* a3049 in k3043 in with-output-to-string in k1360 */
static void f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[60]+1));
t3=C_mutate((C_word*)lf[60]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-input-from-string in k1360 */
static void f_3016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3016,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 514  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3018 in with-input-from-string in k1360 */
static void f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3035 in k3018 in with-input-from-string in k1360 */
static void f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[7]+1));
t3=C_mutate((C_word*)lf[7]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a3029 in k3018 in with-input-from-string in k1360 */
static void f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
/* extras.scm: 515  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a3024 in k3018 in with-input-from-string in k1360 */
static void f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[7]+1));
t3=C_mutate((C_word*)lf[7]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* call-with-output-string in k1360 */
static void f_3004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3008,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 507  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3006 in call-with-output-string in k1360 */
static void f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 508  proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3009 in k3006 in call-with-output-string in k1360 */
static void f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 509  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k1360 */
static void f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2995,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 500  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2997 in call-with-input-string in k1360 */
static void f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 501  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k1360 */
static void f_2973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2973,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 491  ##sys#dynamic-wind */
t11=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,t8,t9,t10);}

/* a2989 in with-error-output-to-port in k1360 */
static void f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[67]+1));
t3=C_mutate((C_word*)lf[67]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a2983 in with-error-output-to-port in k1360 */
static void f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
/* extras.scm: 492  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2978 in with-error-output-to-port in k1360 */
static void f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[67]+1));
t3=C_mutate((C_word*)lf[67]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-output-to-port in k1360 */
static void f_2951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2951,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2968,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 486  ##sys#dynamic-wind */
t11=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,t8,t9,t10);}

/* a2967 in with-output-to-port in k1360 */
static void f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[60]+1));
t3=C_mutate((C_word*)lf[60]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a2961 in with-output-to-port in k1360 */
static void f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
/* extras.scm: 487  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2956 in with-output-to-port in k1360 */
static void f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[60]+1));
t3=C_mutate((C_word*)lf[60]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* with-input-from-port in k1360 */
static void f_2929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2929,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 481  ##sys#dynamic-wind */
t11=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,t8,t9,t10);}

/* a2945 in with-input-from-port in k1360 */
static void f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[7]+1));
t3=C_mutate((C_word*)lf[7]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a2939 in with-input-from-port in k1360 */
static void f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
/* extras.scm: 482  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2934 in with-input-from-port in k1360 */
static void f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[7]+1));
t3=C_mutate((C_word*)lf[7]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* write-line in k1360 */
static void f_2914(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2914r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2914r(t0,t1,t2,t3);}}

static void f_2914r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[60]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2921,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 473  display */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t4);}

/* k2919 in write-line in k1360 */
static void f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 474  newline */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1360 */
static void f_2837(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2837r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2837r(t0,t1,t2,t3);}}

static void f_2837r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2869,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* extras.scm: 455  def-n293 */
t7=t6;
f_2869(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* extras.scm: 455  def-port294 */
t9=t5;
f_2864(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* extras.scm: 455  body291 */
t11=t4;
f_2839(t11,t1,t7,t9);}}}

/* def-n293 in write-string in k1360 */
static void C_fcall f_2869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2869,NULL,2,t0,t1);}
/* extras.scm: 455  def-port294 */
t2=((C_word*)t0)[2];
f_2864(t2,t1,C_SCHEME_FALSE);}

/* def-port294 in write-string in k1360 */
static void C_fcall f_2864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2864,NULL,3,t0,t1,t2);}
/* extras.scm: 455  body291 */
t3=((C_word*)t0)[2];
f_2839(t3,t1,t2,*((C_word*)lf[60]+1));}

/* body291 in write-string in k1360 */
static void C_fcall f_2839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2839,NULL,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?C_SCHEME_UNDEFINED:C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t7=(C_word)C_block_size(((C_word*)t0)[2]);
t8=t6;
f_2853(t8,(C_word)C_fixnum_lessp(t2,t7));}
else{
t7=t6;
f_2853(t7,C_SCHEME_FALSE);}}

/* k2851 in body291 in write-string in k1360 */
static void C_fcall f_2853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 460  ##sys#substring */
t2=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2850(2,t2,((C_word*)t0)[3]);}}

/* k2848 in body291 in write-string in k1360 */
static void f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 458  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1360 */
static void f_2774(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2774r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2774r(t0,t1,t2,t3);}}

static void f_2774r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2778(t5,*((C_word*)lf[7]+1));}
else{
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_nullp(t5);
t7=t4;
f_2778(t7,(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k2776 in read-token in k1360 */
static void C_fcall f_2778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2778,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 442  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2779 in k2776 in read-token in k1360 */
static void f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2786(t5,((C_word*)t0)[2]);}

/* loop in k2779 in k2776 in read-token in k1360 */
static void C_fcall f_2786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 444  ##sys#peek-char-0 */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2788 in loop in k2779 in k2776 in read-token in k1360 */
static void f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_2796(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 445  pred */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k2794 in k2788 in loop in k2779 in k2776 in read-token in k1360 */
static void f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 447  ##sys#read-char-0 */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 449  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k2804 in k2794 in k2788 in loop in k2779 in k2776 in read-token in k1360 */
static void f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 447  ##sys#write-char-0 */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2797 in k2794 in k2788 in loop in k2779 in k2776 in read-token in k1360 */
static void f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 448  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2786(t2,((C_word*)t0)[2]);}

/* read-string in k1360 */
static void f_2671(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_2671r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2671r(t0,t1,t2);}}

static void f_2671r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2729,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n252269 */
t6=t5;
f_2729(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p253267 */
t8=t4;
f_2724(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body250255 */
t10=t3;
f_2673(t10,t1,t6,t8);}}}

/* def-n252 in read-string in k1360 */
static void C_fcall f_2729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2729,NULL,2,t0,t1);}
/* def-p253267 */
t2=((C_word*)t0)[2];
f_2724(t2,t1,C_SCHEME_FALSE);}

/* def-p253 in read-string in k1360 */
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2724,NULL,3,t0,t1,t2);}
/* body250255 */
t3=((C_word*)t0)[2];
f_2673(t3,t1,t2,*((C_word*)lf[7]+1));}

/* body250 in read-string in k1360 */
static void C_fcall f_2673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2673,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2677,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 424  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2675 in body250 in read-string in k1360 */
static void f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?C_SCHEME_UNDEFINED:C_SCHEME_UNDEFINED);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2685(t6,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* loop in k2675 in body250 in read-string in k1360 */
static void C_fcall f_2685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2685,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 428  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_2689(2,t5,C_SCHEME_FALSE);}}

/* k2687 in loop in k2675 in body250 in read-string in k1360 */
static void f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 429  ##sys#read-char-0 */
t3=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2693 in k2687 in loop in k2675 in body250 in read-string in k1360 */
static void f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 431  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 433  ##sys#write-char */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k2705 in k2693 in k2687 in loop in k2675 in body250 in read-string in k1360 */
static void f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 434  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2685(t3,((C_word*)t0)[2],t2);}

/* read-lines in k1360 */
static void f_2582(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2582r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2582r(t0,t1,t2);}}

static void f_2582r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[7]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 413  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t9);}
else{
/* extras.scm: 416  doread */
t10=t9;
f_2594(3,t10,t1,t4);}}

/* doread in read-lines in k1360 */
static void f_2594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2594,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2602,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 408  read-line */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2600 in doread in read-lines in k1360 */
static void f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?((C_word*)t0)[6]:C_fix(1000000));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2608(t6,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,t2);}

/* do234 in k2600 in doread in read-lines in k1360 */
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2608,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_fix(0)));
if(C_truep(t6)){
/* extras.scm: 411  reverse */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2628,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 408  read-line */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2626 in do234 in k2600 in doread in read-lines in k1360 */
static void f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2608(t4,((C_word*)t0)[2],t1,t2,t3);}

/* read-line in k1360 */
static void f_2356(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2356r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2356r(t0,t1,t2);}}

static void f_2356r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_car(t2):*((C_word*)lf[7]+1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2366,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_2366(t8,(C_truep(t7)?(C_word)C_u_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_2366(t6,C_SCHEME_FALSE);}}

/* k2364 in read-line in k1360 */
static void C_fcall f_2366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2366,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2369,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 360  make-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2367 in k2364 in read-line in k1360 */
static void f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(256);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2375,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_mk_bool(FGETS_INTO_BUFFER))){
t7=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t8=t6;
f_2375(t8,(C_word)C_eqp(lf[49],t7));}
else{
t7=t6;
f_2375(t7,C_SCHEME_FALSE);}}

/* k2373 in k2367 in k2364 in read-line in k1360 */
static void C_fcall f_2375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2380(t5,((C_word*)t0)[5],C_fix(256),((C_word*)((C_word*)t0)[4])[1],lf[47],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 373  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[5],t2);}}

/* a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2449,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2455(t6,t1,C_fix(0));}

/* loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void C_fcall f_2455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2455,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[8])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 377  ##sys#substring */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 378  ##sys#read-char-0 */
t5=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}

/* k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[9],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 382  ##sys#substring */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_fix(0),((C_word*)t0)[9]);}}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 384  ##sys#substring */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)((C_word*)t0)[7])[1],C_fix(0),((C_word*)t0)[9]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 386  ##sys#read-char-0 */
t3=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[9],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2546,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 394  make-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_2532(t3,C_SCHEME_UNDEFINED);}}}}

/* k2552 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 394  ##sys#string-append */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2544 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2532(t5,t4);}

/* k2530 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void C_fcall f_2532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 397  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2455(t4,((C_word*)t0)[2],t3);}

/* k2507 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 388  ##sys#substring */
t4=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}
else{
t3=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],t1);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 391  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2455(t5,((C_word*)t0)[5],t4);}}

/* k2520 in k2507 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 388  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2498 in k2470 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 384  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2467 in loop in a2448 in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 377  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* loop in k2373 in k2367 in k2364 in read-line in k1360 */
static void C_fcall f_2380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)fgets_into_buffer(t3,((C_word*)t0)[5],t2);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t5)?t4:C_SCHEME_END_OF_FILE));}
else{
if(C_truep(t6)){
if(C_truep(t5)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2433,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_fixnum_difference(t6,C_fix(1));
/* extras.scm: 371  fixup */
f_2330(t8,t3,t9);}
else{
t8=(C_word)C_u_fixnum_difference(t6,C_fix(1));
/* extras.scm: 372  fixup */
f_2330(t1,t3,t8);}}
else{
t8=(C_word)C_fixnum_times(t2,C_fix(2));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2407,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_fixnum_times(t2,C_fix(2));
/* extras.scm: 368  make-string */
t11=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}}}

/* k2405 in loop in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2411,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 369  ##sys#substring */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],C_fix(0),t4);}

/* k2413 in k2405 in loop in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 369  ##sys#string-append */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2409 in k2405 in loop in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 368  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2380(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2431 in loop in k2373 in k2367 in k2364 in read-line in k1360 */
static void f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 371  ##sys#string-append */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fixup in k1360 */
static void C_fcall f_2330(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2330,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
t5=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t6=(C_word)C_subchar(t2,t5);
t7=t4;
f_2341(t7,(C_word)C_eqp(C_make_character(13),t6));}
else{
t5=t4;
f_2341(t5,C_SCHEME_FALSE);}}

/* k2339 in fixup in k1360 */
static void C_fcall f_2341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1)):((C_word*)t0)[4]);
/* extras.scm: 351  ##sys#substring */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}

/* randomize in k1360 */
static void f_2316(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2316r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2316r(t0,t1,t2);}}

static void f_2316r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))?(C_word)C_fudge(C_fix(2)):(C_word)C_slot(t2,C_fix(0)));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_randomize(t3));}

/* random in k1360 */
static void f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* rassoc in k1360 */
static void f_2263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2263r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2263r(t0,t1,t2,t3,t4);}}

static void f_2263r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):*((C_word*)lf[34]+1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=t2,a[3]=t6,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2272(t10,t1,t3);}

/* loop in rassoc in k1360 */
static void C_fcall f_2272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2272,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 320  tst */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2286 in loop in rassoc in k1360 */
static void f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 322  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2272(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1360 */
static void f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2142r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2142r(t0,t1,t2,t3,t4);}}

static void f_2142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp163179 */
t8=t7;
f_2218(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default164177 */
t10=t6;
f_2213(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body161166 */
t12=t5;
f_2144(t12,t1,t8,t10);}}}

/* def-cmp163 in alist-ref in k1360 */
static void C_fcall f_2218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2218,NULL,2,t0,t1);}
/* def-default164177 */
t2=((C_word*)t0)[2];
f_2213(t2,t1,*((C_word*)lf[34]+1));}

/* def-default164 in alist-ref in k1360 */
static void C_fcall f_2213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,3,t0,t1,t2);}
/* body161166 */
t3=((C_word*)t0)[2];
f_2144(t3,t1,t2,C_SCHEME_FALSE);}

/* body161 in alist-ref in k1360 */
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2144,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[35]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2148(t6,*((C_word*)lf[36]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[34]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2148(t7,*((C_word*)lf[37]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[38]+1),t2);
t8=t4;
f_2148(t8,(C_truep(t7)?*((C_word*)lf[39]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2173 in body161 in alist-ref in k1360 */
static void f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2173,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2179,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2179(t7,t1,t3);}

/* loop */
static void C_fcall f_2179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2179,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 305  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2195(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2193 in loop */
static void f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2179(t3,((C_word*)t0)[5],t2);}}

/* k2146 in body161 in alist-ref in k1360 */
static void C_fcall f_2148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 308  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2149 in k2146 in body161 in alist-ref in k1360 */
static void f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1360 */
static void f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2056r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2056r(t0,t1,t2,t3,t4,t5);}}

static void f_2056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):*((C_word*)lf[34]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2063,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[35]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2063(t10,*((C_word*)lf[36]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[34]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2063(t11,*((C_word*)lf[37]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[38]+1),t7);
t12=t8;
f_2063(t12,(C_truep(t11)?*((C_word*)lf[39]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=t7,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2095 in alist-update! in k1360 */
static void f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2095,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2101,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2101(t7,t1,t3);}

/* loop */
static void C_fcall f_2101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2101,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 286  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2117(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2115 in loop */
static void f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2101(t3,((C_word*)t0)[5],t2);}}

/* k2061 in alist-update! in k1360 */
static void C_fcall f_2063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2063,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 289  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2064 in k2061 in alist-update! in k1360 */
static void f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1360 */
static void f_2018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2018,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2046,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2045 in shuffle in k1360 */
static void f_2046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2054,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 270  random */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(10000));}

/* k2052 in a2045 in shuffle in k1360 */
static void f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2028 in shuffle in k1360 */
static void f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2032,tmp=(C_word)a,a+=2,tmp);
/* extras.scm: 270  sort! */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2031 in k2028 in shuffle in k1360 */
static void f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2032,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2024 in shuffle in k1360 */
static void f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[30]+1),t1);}

/* compress in k1360 */
static void f_1955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1955,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_1961(t7,t1,t2,t3);}

/* loop in compress in k1360 */
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1961,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 263  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 264  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k1995 in loop in compress in k1360 */
static void f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1360 */
static void f_1906(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1906r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1906r(t0,t1,t2,t3);}}

static void f_1906r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1915,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1915(t9,t1,t2);}

/* loop in join in k1360 */
static void C_fcall f_1915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1915,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 251  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}}

/* k1945 in loop in join in k1360 */
static void f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 251  ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1360 */
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1833,4,t0,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1842(t8,t1,t2,t4);}

/* loop in chop in k1360 */
static void C_fcall f_1842(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1842,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1863,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1863(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do115 in loop in chop in k1360 */
static void C_fcall f_1863(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1863,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1877,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 237  reverse */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k1875 in do115 in loop in chop in k1360 */
static void f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* extras.scm: 237  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1842(t4,t2,((C_word*)t0)[2],t3);}

/* k1879 in k1875 in do115 in loop in chop in k1360 */
static void f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1360 */
static void f_1786(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1786r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1786r(t0,t1,t2);}}

static void f_1786r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1792(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1360 */
static void C_fcall f_1792(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1792,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1824,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 218  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 219  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k1829 in loop in flatten in k1360 */
static void f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1822 in loop in flatten in k1360 */
static void f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 218  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1792(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1360 */
static void f_1757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1757,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1763,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1763(t6,t1,t2);}

/* loop in butlast in k1360 */
static void C_fcall f_1763(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1763,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1784,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 206  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k1782 in loop in butlast in k1360 */
static void f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1360 */
static void f_1724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1724,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1730(t7,t1,t2);}

/* loop in intersperse in k1360 */
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1730,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1755,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 199  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k1753 in loop in intersperse in k1360 */
static void f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1360 */
static void f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1699,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_1708(t5,t3));}}

/* loop in tail? in k1360 */
static C_word C_fcall f_1708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1360 */
static void f_1696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1696,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_atomp(t2));}

/* noop in k1360 */
static void f_1690(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
/* extras.scm: 176  void */
t2=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* list-of in k1360 */
static void f_1650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1650,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1652 in list-of in k1360 */
static void f_1652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1652,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1658(t6,t1,t2);}

/* loop */
static void C_fcall f_1658(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1658,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1677,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 173  pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* k1675 in loop */
static void f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1658(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* compose in k1360 */
static void f_1620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1620r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1620r(t0,t1,t2);}}

static void f_1620r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
C_apply(4,0,t1,((C_word*)t4)[1],t2);}

/* rec in compose in k1360 */
static void f_1623(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1623r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1623r(t0,t1,t2,t3);}}

static void f_1623r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp)));}

/* f_1631 in rec in compose in k1360 */
static void f_1631(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1631r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1631r(t0,t1,t2);}}

static void f_1631r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 163  call-with-values */
C_u_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a1636 */
static void f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1643 in a1636 */
static void f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1360 */
static void f_1608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1608,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1610 in complement in k1360 */
static void f_1610(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1610r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1610r(t0,t1,t2);}}

static void f_1610r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k1616 */
static void f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1360 */
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1600,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1602 in flip in k1360 */
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1602,4,t0,t1,t2,t3);}
/* extras.scm: 152  proc */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* constantly in k1360 */
static void f_1577(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1577r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1577r(t0,t1,t2);}}

static void f_1577r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}}

/* f_1590 in constantly in k1360 */
static void f_1590(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1588 in constantly in k1360 */
static void f_1588(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1360 */
static void f_1540(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1540r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1540r(t0,t1,t2);}}

static void f_1540r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1542 in disjoin in k1360 */
static void f_1542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1542,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1548(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,((C_word*)t0)[2]);}}

/* k1556 in loop */
static void f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 144  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1548(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1360 */
static void f_1507(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1507r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1507r(t0,t1,t2);}}

static void f_1507r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1509 in conjoin in k1360 */
static void f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1515(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1528,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k1526 in loop */
static void f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 137  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1515(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1360 */
static void f_1499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1499,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1501 in project in k1360 */
static void f_1501(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1501r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1501r(t0,t1,t2);}}

static void f_1501r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,((C_word*)t0)[2]));}

/* identity in k1360 */
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1496,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* read-file in k1360 */
static void f_1364(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr2r,(void*)f_1364r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1364r(t0,t1,t2);}}

static void f_1364r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1436,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port1236 */
t7=t6;
f_1436(t7,t1);}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader1334 */
t9=t5;
f_1431(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max1431 */
t11=t4;
f_1426(t11,t1,t7,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body1016 */
t13=t3;
f_1366(t13,t1,t7,t9,t11);}}}}

/* def-port12 in read-file in k1360 */
static void C_fcall f_1436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1436,NULL,2,t0,t1);}
/* def-reader1334 */
t2=((C_word*)t0)[2];
f_1431(t2,t1,*((C_word*)lf[7]+1));}

/* def-reader13 in read-file in k1360 */
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1431,NULL,3,t0,t1,t2);}
/* def-max1431 */
t3=((C_word*)t0)[3];
f_1426(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max14 in read-file in k1360 */
static void C_fcall f_1426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1426,NULL,4,t0,t1,t2,t3);}
/* body1016 */
t4=((C_word*)t0)[2];
f_1366(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body10 in read-file in k1360 */
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1366,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 120  port? */
t7=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1417 in body10 in read-file in k1360 */
static void f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 121  slurp */
t2=((C_word*)t0)[5];
f_1369(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 122  call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body10 in read-file in k1360 */
static void f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1377,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 116  read */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1375 in slurp in body10 in read-file in k1360 */
static void f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1379(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* do22 in k1375 in slurp in body10 in read-file in k1360 */
static void C_fcall f_1379(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1379,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 119  reverse */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1399,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 116  reader */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}}

/* k1397 in do22 in k1375 in slurp in body10 in read-file in k1360 */
static void f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1379(t4,((C_word*)t0)[2],t1,t2,t3);}
/* end of file */
