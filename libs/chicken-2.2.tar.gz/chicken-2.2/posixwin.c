/* Generated from posixwin.scm by the Chicken compiler
   2005-09-10 23:31
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file posixwin.c -explicit-use
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>

#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX 256
#define PIPE_BUF 512

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;
/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

static C_TLS char C_hostname[256];
static C_TLS char C_osver[16];
static C_TLS char C_osrel[16];
static C_TLS char C_processor[16];

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR *opendir(const char *name);
static int closedir(DIR *dir);
static struct dirent *readdir(DIR *dir);

static DIR *opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}
static int closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}
static struct dirent *readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)   	(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name),	C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid            getpid
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d)           C_fix(_pipe(C_pipefds, PIPE_BUF, O_BINARY))
#define C_close(fd)         C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);				       
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}

static void C_fcall C_set_exec_arg(int i, char *a, int len);
void C_fcall C_set_exec_arg(int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  C_exec_args[ i ] = ptr;
}

static void C_fcall C_free_exec_args();
void C_fcall C_free_exec_args() {
  char **a = C_exec_args;
  while((*a) != NULL) C_free(*(a++));
}

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), C_exec_args))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )

/* mapping from Win32 error codes to errno */
typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;
static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,      EINVAL},
    {ERROR_FILE_NOT_FOUND,        ENOENT},
    {ERROR_PATH_NOT_FOUND,        ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,   EMFILE},
    {ERROR_ACCESS_DENIED,         EACCES},
    {ERROR_INVALID_HANDLE,        EBADF},
    {ERROR_ARENA_TRASHED,         ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,     ENOMEM},
    {ERROR_INVALID_BLOCK,         ENOMEM},
    {ERROR_BAD_ENVIRONMENT,       E2BIG},
    {ERROR_BAD_FORMAT,            ENOEXEC},
    {ERROR_INVALID_ACCESS,        EINVAL},
    {ERROR_INVALID_DATA,          EINVAL},
    {ERROR_INVALID_DRIVE,         ENOENT},
    {ERROR_CURRENT_DIRECTORY,     EACCES},
    {ERROR_NOT_SAME_DEVICE,       EXDEV},
    {ERROR_NO_MORE_FILES,         ENOENT},
    {ERROR_LOCK_VIOLATION,        EACCES},
    {ERROR_BAD_NETPATH,           ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,          ENOENT},
    {ERROR_FILE_EXISTS,           EEXIST},
    {ERROR_CANNOT_MAKE,           EACCES},
    {ERROR_FAIL_I24,              EACCES},
    {ERROR_INVALID_PARAMETER,     EINVAL},
    {ERROR_NO_PROC_SLOTS,         EAGAIN},
    {ERROR_DRIVE_LOCKED,          EACCES},
    {ERROR_BROKEN_PIPE,           EPIPE},
    {ERROR_DISK_FULL,             ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,        EINVAL},
    {ERROR_WAIT_NO_CHILDREN,      ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,    ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,         EINVAL},
    {ERROR_SEEK_ON_DEVICE,        EACCES},
    {ERROR_DIR_NOT_EMPTY,         ENOTEMPTY},
    {ERROR_NOT_LOCKED,            EACCES},
    {ERROR_BAD_PATHNAME,          ENOENT},
    {ERROR_MAX_THRDS_REACHED,     EAGAIN},
    {ERROR_LOCK_FAILED,           EACCES},
    {ERROR_ALREADY_EXISTS,        EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,   EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,      ENOMEM},
    {0, 0}
};

static void set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

/* functions for creating process with redirected I/O */
static int zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}
static int close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}
static int redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_errno(GetLastError());
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}
static int run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
    {
	set_errno(GetLastError());
	return 0;
    }
}
static int pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
    {
	set_errno(GetLastError());
	return 0;
    }
}
static int pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    set_errno(GetLastError());
    return 0;
}
static int pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else 
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

int process_wait(int h, int t)
{   
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    set_errno(GetLastError());
    return 0;
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

int get_hostname()
{
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
    {
	int nok = gethostname(C_hostname, 256);
	WSACleanup();
	return !nok;
    }
    return 0;
}

int sysinfo()
{
    OSVERSIONINFO ovf;
    ZeroMemory(&ovf, sizeof(ovf));
    ovf.dwOSVersionInfoSize = sizeof(ovf);
    if (get_hostname() && GetVersionEx(&ovf))
    {
	SYSTEM_INFO si;
	_snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d", 
			   ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	switch (ovf.dwPlatformId)
	{
	case VER_PLATFORM_WIN32s:
	    strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
	    break;
	case VER_PLATFORM_WIN32_WINDOWS:
	    strncpy(C_osrel, "Win9x", sizeof(C_osrel) - 1);
	    break;
	case VER_PLATFORM_WIN32_NT:
	default:
	    strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
	    break;
	}
	GetSystemInfo(&si);
	switch (si.wProcessorArchitecture)
	{
    	case PROCESSOR_ARCHITECTURE_INTEL:
	    strncpy(C_processor, "Intel", sizeof(C_processor) - 1);
	    break;
    	case PROCESSOR_ARCHITECTURE_UNKNOWN:
	default:
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    break;
	}
	return 1;
    }
    set_errno(GetLastError());
    return 0;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)


C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[355];


/* from close-handle in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall stub443(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub443(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from get-shell in k691 in k688 in k685 in k682 in k679 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub434(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub434(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
    char *ret = getenv("COMSPEC");
    if (ret)
	return (ret);
    else
    {
	OSVERSIONINFO ovf;
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (GetVersionEx(&ovf) && (ovf.dwPlatformId == VER_PLATFORM_WIN32_NT))
	    return ("cmd.exe");
	else
	    return ("command.com");
    }
C_return:
#undef return

return C_r;}

/* from current-process-id in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall stub432(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub432(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeargs */
static C_word C_fcall stub408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k2405 */
static C_word C_fcall stub401(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub401(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub356(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub356(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k2242 */
static C_word C_fcall stub349(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub349(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k2041 */
static C_word C_fcall stub300(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub300(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from asctime */
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k1990 */
static C_word C_fcall stub280(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub280(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k1897 */
static C_word C_fcall stub263(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub263(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

C_externexport void C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_681(C_word c,C_word t0,C_word t1) C_noret;
static void f_684(C_word c,C_word t0,C_word t1) C_noret;
static void f_687(C_word c,C_word t0,C_word t1) C_noret;
static void f_690(C_word c,C_word t0,C_word t1) C_noret;
static void f_693(C_word c,C_word t0,C_word t1) C_noret;
static void f_2786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2937(C_word t0,C_word t1) C_noret;
static void f_2943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2927(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2788(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2914(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2922(C_word c,C_word t0,C_word t1,...) C_noret;
static void C_fcall f_2795(C_word t0,C_word t1) C_noret;
static void f_2902(C_word c,C_word t0,C_word t1) C_noret;
static void f_2805(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2826(C_word c,C_word t0,C_word t1) C_noret;
static void f_2888(C_word c,C_word t0,C_word t1) C_noret;
static void f_2895(C_word c,C_word t0,C_word t1) C_noret;
static void f_2882(C_word c,C_word t0,C_word t1) C_noret;
static void f_2841(C_word c,C_word t0,C_word t1) C_noret;
static void f_2872(C_word c,C_word t0,C_word t1) C_noret;
static void f_2858(C_word c,C_word t0,C_word t1) C_noret;
static void f_2870(C_word c,C_word t0,C_word t1) C_noret;
static void f_2866(C_word c,C_word t0,C_word t1) C_noret;
static void f_2853(C_word c,C_word t0,C_word t1) C_noret;
static void f_2851(C_word c,C_word t0,C_word t1) C_noret;
static void f_2906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2755(C_word c,C_word t0,C_word t1) C_noret;
static void f_2781(C_word c,C_word t0,C_word t1) C_noret;
static void f_2766(C_word c,C_word t0,C_word t1) C_noret;
static void f_2770(C_word c,C_word t0,C_word t1) C_noret;
static void f_2774(C_word c,C_word t0,C_word t1) C_noret;
static void f_2778(C_word c,C_word t0,C_word t1) C_noret;
static void f_2743(C_word c,C_word t0,C_word t1) C_noret;
static void f_2740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2698(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2698r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2720(C_word c,C_word t0,C_word t1) C_noret;
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2547r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2650(C_word t0,C_word t1) C_noret;
static void C_fcall f_2645(C_word t0,C_word t1) C_noret;
static void C_fcall f_2549(C_word t0,C_word t1) C_noret;
static void f_2641(C_word c,C_word t0,C_word t1) C_noret;
static void f_2556(C_word c,C_word t0,C_word t1) C_noret;
static void f_2628(C_word c,C_word t0,C_word t1) C_noret;
static void f_2631(C_word c,C_word t0,C_word t1) C_noret;
static void f_2634(C_word c,C_word t0,C_word t1) C_noret;
static void f_2621(C_word c,C_word t0,C_word t1) C_noret;
static void f_2618(C_word c,C_word t0,C_word t1) C_noret;
static void f_2594(C_word c,C_word t0,C_word t1) C_noret;
static void f_2569(C_word c,C_word t0,C_word t1) C_noret;
static void f_2588(C_word c,C_word t0,C_word t1) C_noret;
static void f_2575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2573(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2544(C_word t0);
static void f_2515(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2515r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2532(C_word c,C_word t0,C_word t1) C_noret;
static void f_2509(C_word c,C_word t0,C_word t1) C_noret;
static void f_2506(C_word c,C_word t0,C_word t1) C_noret;
static void f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2413r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2429(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2437(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2470(C_word c,C_word t0,C_word t1) C_noret;
static void f_2451(C_word c,C_word t0,C_word t1) C_noret;
static void f_2454(C_word c,C_word t0,C_word t1) C_noret;
static void f_2457(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2394(C_word t0,C_word t1,C_word t2);
static void f_2250(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2250r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2346(C_word t0,C_word t1) C_noret;
static void C_fcall f_2341(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2252(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2265(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2273(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2306(C_word c,C_word t0,C_word t1) C_noret;
static void f_2287(C_word c,C_word t0,C_word t1) C_noret;
static void f_2290(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2231(C_word t0,C_word t1,C_word t2);
static void f_2122(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2122r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2128(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2220(C_word c,C_word t0,C_word t1) C_noret;
static void f_2153(C_word c,C_word t0,C_word t1) C_noret;
static void f_2160(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2162(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2179(C_word c,C_word t0,C_word t1) C_noret;
static void f_2189(C_word c,C_word t0,C_word t1) C_noret;
static void f_2193(C_word c,C_word t0,C_word t1) C_noret;
static void f_2143(C_word c,C_word t0,C_word t1) C_noret;
static void f_2063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2063r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2067(C_word c,C_word t0,C_word t1) C_noret;
static void f_2073(C_word c,C_word t0,C_word t1) C_noret;
static void f_2044(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2044r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_2010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2017(C_word c,C_word t0,C_word t1) C_noret;
static void f_2020(C_word c,C_word t0,C_word t1) C_noret;
static void f_2023(C_word c,C_word t0,C_word t1) C_noret;
static void f_1993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1997(C_word c,C_word t0,C_word t1) C_noret;
static void f_2000(C_word c,C_word t0,C_word t1) C_noret;
static void f_1974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1900(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1906(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1910(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1944(C_word c,C_word t0,C_word t1) C_noret;
static void f_1948(C_word c,C_word t0,C_word t1) C_noret;
static void f_1936(C_word c,C_word t0,C_word t1) C_noret;
static void f_1880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1) C_noret;
static void f_1863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1874(C_word c,C_word t0,C_word t1) C_noret;
static void f_1878(C_word c,C_word t0,C_word t1) C_noret;
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1833r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
static void f_1849(C_word c,C_word t0,C_word t1) C_noret;
static void f_1843(C_word c,C_word t0,C_word t1) C_noret;
static void f_1798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1802(C_word c,C_word t0,C_word t1) C_noret;
static void f_1831(C_word c,C_word t0,C_word t1) C_noret;
static void f_1817(C_word c,C_word t0,C_word t1) C_noret;
static void f_1811(C_word c,C_word t0,C_word t1) C_noret;
static void f_1784(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1784r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1796(C_word c,C_word t0,C_word t1) C_noret;
static void f_1770(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1770r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1782(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1756(C_word c,C_word t0,C_word t1) C_noret;
static void f_1768(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1723(C_word c,C_word t0,C_word t1) C_noret;
static void f_1706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1692(C_word c,C_word t0,C_word t1) C_noret;
static void f_1688(C_word c,C_word t0,C_word t1) C_noret;
static void f_1680(C_word c,C_word t0,C_word t1) C_noret;
static void f_1640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1668(C_word c,C_word t0,C_word t1) C_noret;
static void f_1664(C_word c,C_word t0,C_word t1) C_noret;
static void f_1656(C_word c,C_word t0,C_word t1) C_noret;
static void f_1584(C_word c,C_word t0,C_word t1) C_noret;
static void f_1597(C_word c,C_word t0,C_word t1) C_noret;
static void f_1588(C_word c,C_word t0,C_word t1) C_noret;
static void f_1564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1564r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1568(C_word c,C_word t0,C_word t1) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1574r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1) C_noret;
static void f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1544r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1548(C_word c,C_word t0,C_word t1) C_noret;
static void f_1554(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1554r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1558(C_word c,C_word t0,C_word t1) C_noret;
static void f_1520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1524(C_word c,C_word t0,C_word t1) C_noret;
static void f_1535(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1535r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1539(C_word c,C_word t0,C_word t1) C_noret;
static void f_1529(C_word c,C_word t0,C_word t1) C_noret;
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1496r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1500(C_word c,C_word t0,C_word t1) C_noret;
static void f_1511(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1511r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1515(C_word c,C_word t0,C_word t1) C_noret;
static void f_1505(C_word c,C_word t0,C_word t1) C_noret;
static void f_1477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1481(C_word c,C_word t0,C_word t1) C_noret;
static void f_1484(C_word c,C_word t0,C_word t1) C_noret;
static void f_1441(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1441r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1472(C_word c,C_word t0,C_word t1) C_noret;
static void f_1462(C_word c,C_word t0,C_word t1) C_noret;
static void f_1455(C_word c,C_word t0,C_word t1) C_noret;
static void f_1405(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1405r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1436(C_word c,C_word t0,C_word t1) C_noret;
static void f_1426(C_word c,C_word t0,C_word t1) C_noret;
static void f_1419(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1391(C_word c,C_word t0,C_word t1) C_noret;
static void f_1403(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1381(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1369(C_word t0);
static void f_1323(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1323r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1327(C_word c,C_word t0,C_word t1) C_noret;
static void f_1336(C_word c,C_word t0,C_word t1) C_noret;
static void f_1339(C_word c,C_word t0,C_word t1) C_noret;
static void f_1300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1321(C_word c,C_word t0,C_word t1) C_noret;
static void f_1307(C_word c,C_word t0,C_word t1) C_noret;
static void f_1243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1250(C_word c,C_word t0,C_word t1) C_noret;
static void f_1253(C_word c,C_word t0,C_word t1) C_noret;
static void f_1256(C_word c,C_word t0,C_word t1) C_noret;
static void f_1298(C_word c,C_word t0,C_word t1) C_noret;
static void f_1260(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1277(C_word t0,C_word t1) C_noret;
static void f_1287(C_word c,C_word t0,C_word t1) C_noret;
static void f_1294(C_word c,C_word t0,C_word t1) C_noret;
static void f_1269(C_word c,C_word t0,C_word t1) C_noret;
static void f_1216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1241(C_word c,C_word t0,C_word t1) C_noret;
static void f_1237(C_word c,C_word t0,C_word t1) C_noret;
static void f_1229(C_word c,C_word t0,C_word t1) C_noret;
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1214(C_word c,C_word t0,C_word t1) C_noret;
static void f_1210(C_word c,C_word t0,C_word t1) C_noret;
static void f_1202(C_word c,C_word t0,C_word t1) C_noret;
static void f_1162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1187(C_word c,C_word t0,C_word t1) C_noret;
static void f_1183(C_word c,C_word t0,C_word t1) C_noret;
static void f_1175(C_word c,C_word t0,C_word t1) C_noret;
static void f_1101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1114(C_word c,C_word t0,C_word t1) C_noret;
static void f_1129(C_word c,C_word t0,C_word t1) C_noret;
static void f_1120(C_word c,C_word t0,C_word t1) C_noret;
static void f_1123(C_word c,C_word t0,C_word t1) C_noret;
static void f_1061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1080(C_word c,C_word t0,C_word t1) C_noret;
static void f_1065(C_word c,C_word t0,C_word t1) C_noret;
static void f_1074(C_word c,C_word t0,C_word t1) C_noret;
static void f_1068(C_word c,C_word t0,C_word t1) C_noret;
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1053(C_word c,C_word t0,C_word t1) C_noret;
static void f_1039(C_word c,C_word t0,C_word t1) C_noret;
static void f_1026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1030(C_word c,C_word t0,C_word t1) C_noret;
static void f_1020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1024(C_word c,C_word t0,C_word t1) C_noret;
static void f_1014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1018(C_word c,C_word t0,C_word t1) C_noret;
static void f_1008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1012(C_word c,C_word t0,C_word t1) C_noret;
static void f_1002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1006(C_word c,C_word t0,C_word t1) C_noret;
static void f_996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1000(C_word c,C_word t0,C_word t1) C_noret;
static void f_965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_969(C_word c,C_word t0,C_word t1) C_noret;
static void f_972(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_927(C_word t0,C_word t1) C_noret;
static void f_960(C_word c,C_word t0,C_word t1) C_noret;
static void f_956(C_word c,C_word t0,C_word t1) C_noret;
static void f_931(C_word c,C_word t0,C_word t1) C_noret;
static void f_940(C_word c,C_word t0,C_word t1) C_noret;
static void f_889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_896(C_word c,C_word t0,C_word t1) C_noret;
static void f_899(C_word c,C_word t0,C_word t1) C_noret;
static void f_919(C_word c,C_word t0,C_word t1) C_noret;
static void f_902(C_word c,C_word t0,C_word t1) C_noret;
static void f_909(C_word c,C_word t0,C_word t1) C_noret;
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_847r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_854(C_word c,C_word t0,C_word t1) C_noret;
static void f_869(C_word c,C_word t0,C_word t1) C_noret;
static void f_863(C_word c,C_word t0,C_word t1) C_noret;
static void f_802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_802r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static void f_815(C_word c,C_word t0,C_word t1) C_noret;
static void f_827(C_word c,C_word t0,C_word t1) C_noret;
static void f_818(C_word c,C_word t0,C_word t1) C_noret;
static void f_784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_797(C_word c,C_word t0,C_word t1) C_noret;
static void f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_776(C_word c,C_word t0,C_word t1) C_noret;
static void f_760(C_word c,C_word t0,C_word t1) C_noret;
static void f_769(C_word c,C_word t0,C_word t1) C_noret;
static void f_763(C_word c,C_word t0,C_word t1) C_noret;
static void f_695(C_word c,C_word t0,C_word t1) C_noret;
static void f_701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_710(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_2937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2937(t0,t1);}

static void C_fcall trf_2932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2932(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2932(t0,t1,t2);}

static void C_fcall trf_2927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2927(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2927(t0,t1,t2,t3);}

static void C_fcall trf_2788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2788(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2788(t0,t1,t2,t3,t4);}

static void C_fcall trf_2795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2795(t0,t1);}

static void C_fcall trf_2807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2807(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2807(t0,t1,t2,t3);}

static void C_fcall trf_2650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2650(t0,t1);}

static void C_fcall trf_2645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2645(t0,t1);}

static void C_fcall trf_2549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2549(t0,t1);}

static void C_fcall trf_2437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2437(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2437(t0,t1,t2,t3);}

static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2346(t0,t1);}

static void C_fcall trf_2341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2341(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2341(t0,t1,t2);}

static void C_fcall trf_2252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2252(t0,t1,t2);}

static void C_fcall trf_2273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2273(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2273(t0,t1,t2,t3);}

static void C_fcall trf_2128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2128(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2128(t0,t1,t2);}

static void C_fcall trf_2162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2162(t0,t1,t2);}

static void C_fcall trf_1906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1906(t0,t1,t2);}

static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1918(t0,t1,t2);}

static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1752(t0,t1,t2,t3);}

static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1715(t0,t1,t2);}

static void C_fcall trf_1670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1670(t0,t1,t2,t3);}

static void C_fcall trf_1387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1387(t0,t1,t2,t3);}

static void C_fcall trf_1381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1381(t0,t1);}

static void C_fcall trf_1277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1277(t0,t1);}

static void C_fcall trf_927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_927(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1629)){
C_save(t1);
C_rereclaim2(1629*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,355);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_h_intern(&lf[3],18,"\003syscurrent-thread");
lf[4]=C_static_lambda_info(C_heaptop,6,"(a709)");
lf[5]=C_h_intern(&lf[5],12,"\003sysschedule");
lf[6]=C_static_lambda_info(C_heaptop,14,"(a700 return2)");
lf[7]=C_static_lambda_info(C_heaptop,7,"(yield)");
lf[8]=C_h_intern(&lf[8],8,"pipe/buf");
lf[9]=C_h_intern(&lf[9],11,"open/rdonly");
lf[10]=C_h_intern(&lf[10],11,"open/wronly");
lf[11]=C_h_intern(&lf[11],9,"open/rdwr");
lf[12]=C_h_intern(&lf[12],9,"open/read");
lf[13]=C_h_intern(&lf[13],10,"open/write");
lf[14]=C_h_intern(&lf[14],10,"open/creat");
lf[15]=C_h_intern(&lf[15],11,"open/append");
lf[16]=C_h_intern(&lf[16],9,"open/excl");
lf[17]=C_h_intern(&lf[17],10,"open/trunc");
lf[18]=C_h_intern(&lf[18],11,"open/binary");
lf[19]=C_h_intern(&lf[19],9,"open/text");
lf[20]=C_h_intern(&lf[20],10,"perm/irusr");
lf[21]=C_h_intern(&lf[21],10,"perm/iwusr");
lf[22]=C_h_intern(&lf[22],10,"perm/ixusr");
lf[23]=C_h_intern(&lf[23],10,"perm/irgrp");
lf[24]=C_h_intern(&lf[24],10,"perm/iwgrp");
lf[25]=C_h_intern(&lf[25],10,"perm/ixgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iroth");
lf[27]=C_h_intern(&lf[27],10,"perm/iwoth");
lf[28]=C_h_intern(&lf[28],10,"perm/ixoth");
lf[29]=C_h_intern(&lf[29],10,"perm/irwxu");
lf[30]=C_h_intern(&lf[30],10,"perm/irwxg");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxo");
lf[32]=C_h_intern(&lf[32],9,"file-open");
lf[33]=C_h_intern(&lf[33],15,"\003syssignal-hook");
lf[34]=C_h_intern(&lf[34],11,"\000file-error");
lf[35]=C_static_string(C_heaptop,17,"can not open file");
lf[36]=C_h_intern(&lf[36],16,"\003sysupdate-errno");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_static_lambda_info(C_heaptop,36,"(file-open filename6 flags7 . mode8)");
lf[40]=C_h_intern(&lf[40],10,"file-close");
lf[41]=C_static_string(C_heaptop,18,"can not close file");
lf[42]=C_static_lambda_info(C_heaptop,17,"(file-close fd16)");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_static_string(C_heaptop,22,"can not read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[48]=C_static_lambda_info(C_heaptop,34,"(file-read fd20 size21 . buffer22)");
lf[49]=C_h_intern(&lf[49],10,"file-write");
lf[50]=C_static_string(C_heaptop,21,"can not write to file");
lf[51]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[52]=C_static_lambda_info(C_heaptop,35,"(file-write fd30 buffer31 . size32)");
lf[53]=C_h_intern(&lf[53],13,"string-length");
lf[54]=C_h_intern(&lf[54],12,"file-mkstemp");
lf[55]=C_h_intern(&lf[55],13,"\003syssubstring");
lf[56]=C_static_string(C_heaptop,29,"can not create temporary file");
lf[57]=C_static_lambda_info(C_heaptop,25,"(file-mkstemp template41)");
lf[58]=C_h_intern(&lf[58],8,"seek/set");
lf[59]=C_h_intern(&lf[59],8,"seek/end");
lf[60]=C_h_intern(&lf[60],8,"seek/cur");
lf[62]=C_static_string(C_heaptop,19,"can not access file");
lf[63]=C_static_string(C_heaptop,42,"bad argument type - not a fixnum or string");
lf[64]=C_static_lambda_info(C_heaptop,19,"(##sys#stat file48)");
lf[65]=C_h_intern(&lf[65],9,"file-stat");
lf[66]=C_h_intern(&lf[66],9,"\003syserror");
lf[67]=C_static_lambda_info(C_heaptop,23,"(file-stat f52 . g5153)");
lf[68]=C_h_intern(&lf[68],9,"file-size");
lf[69]=C_static_lambda_info(C_heaptop,15,"(file-size f59)");
lf[70]=C_h_intern(&lf[70],22,"file-modification-time");
lf[71]=C_static_lambda_info(C_heaptop,28,"(file-modification-time f61)");
lf[72]=C_h_intern(&lf[72],16,"file-access-time");
lf[73]=C_static_lambda_info(C_heaptop,22,"(file-access-time f63)");
lf[74]=C_h_intern(&lf[74],16,"file-change-time");
lf[75]=C_static_lambda_info(C_heaptop,22,"(file-change-time f65)");
lf[76]=C_h_intern(&lf[76],10,"file-owner");
lf[77]=C_static_lambda_info(C_heaptop,16,"(file-owner f67)");
lf[78]=C_h_intern(&lf[78],16,"file-permissions");
lf[79]=C_static_lambda_info(C_heaptop,22,"(file-permissions f69)");
lf[80]=C_h_intern(&lf[80],13,"regular-file\077");
lf[81]=C_h_intern(&lf[81],13,"\003sysfile-info");
lf[82]=C_static_lambda_info(C_heaptop,23,"(regular-file\077 fname71)");
lf[83]=C_h_intern(&lf[83],14,"symbolic-link\077");
lf[84]=C_static_lambda_info(C_heaptop,24,"(symbolic-link\077 fname74)");
lf[85]=C_h_intern(&lf[85],13,"file-position");
lf[86]=C_static_string(C_heaptop,38,"can not retrieve file position of port");
lf[87]=C_h_intern(&lf[87],6,"stream");
lf[88]=C_static_string(C_heaptop,12,"invalid file");
lf[89]=C_h_intern(&lf[89],5,"port\077");
lf[90]=C_static_lambda_info(C_heaptop,22,"(file-position port76)");
lf[91]=C_h_intern(&lf[91],18,"set-file-position!");
lf[92]=C_static_string(C_heaptop,25,"can not set file position");
lf[93]=C_static_string(C_heaptop,12,"invalid file");
lf[94]=C_h_intern(&lf[94],13,"\000bounds-error");
lf[95]=C_static_string(C_heaptop,30,"invalid negative port position");
lf[96]=C_static_lambda_info(C_heaptop,44,"(set-file-position! port80 pos81 . whence82)");
lf[97]=C_h_intern(&lf[97],16,"create-directory");
lf[98]=C_static_string(C_heaptop,24,"can not create directory");
lf[99]=C_static_lambda_info(C_heaptop,25,"(create-directory name88)");
lf[100]=C_h_intern(&lf[100],16,"change-directory");
lf[101]=C_static_string(C_heaptop,32,"can not change current directory");
lf[102]=C_static_lambda_info(C_heaptop,25,"(change-directory name91)");
lf[103]=C_h_intern(&lf[103],16,"delete-directory");
lf[104]=C_static_string(C_heaptop,24,"can not delete directory");
lf[105]=C_static_lambda_info(C_heaptop,25,"(delete-directory name94)");
lf[106]=C_h_intern(&lf[106],13,"string-append");
lf[107]=C_h_intern(&lf[107],6,"string");
lf[108]=C_h_intern(&lf[108],9,"substring");
lf[109]=C_h_intern(&lf[109],9,"directory");
lf[110]=C_static_string(C_heaptop,22,"can not open directory");
lf[111]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[112]=C_h_intern(&lf[112],16,"\003sysmake-pointer");
lf[113]=C_static_lambda_info(C_heaptop,19,"(directory spec101)");
lf[114]=C_h_intern(&lf[114],10,"directory\077");
lf[115]=C_static_lambda_info(C_heaptop,21,"(directory\077 fname114)");
lf[116]=C_h_intern(&lf[116],17,"current-directory");
lf[117]=C_static_string(C_heaptop,34,"can not retrieve current directory");
lf[118]=C_static_lambda_info(C_heaptop,29,"(current-directory . g119120)");
lf[119]=C_h_intern(&lf[119],5,"\000text");
lf[120]=C_static_lambda_info(C_heaptop,6,"(mode)");
lf[121]=C_static_string(C_heaptop,35,"illegal input/output mode specifier");
lf[122]=C_static_lambda_info(C_heaptop,14,"(badmode m131)");
lf[123]=C_static_string(C_heaptop,17,"can not open pipe");
lf[124]=C_h_intern(&lf[124],13,"\003sysmake-port");
lf[125]=C_h_intern(&lf[125],21,"\003sysstream-port-class");
lf[126]=C_static_string(C_heaptop,6,"(pipe)");
lf[127]=C_static_lambda_info(C_heaptop,26,"(check cmd132 inp133 r134)");
lf[128]=C_h_intern(&lf[128],15,"open-input-pipe");
lf[129]=C_h_intern(&lf[129],7,"\000binary");
lf[130]=C_static_lambda_info(C_heaptop,31,"(open-input-pipe cmd138 . m139)");
lf[131]=C_h_intern(&lf[131],16,"open-output-pipe");
lf[132]=C_static_lambda_info(C_heaptop,32,"(open-output-pipe cmd144 . m145)");
lf[133]=C_h_intern(&lf[133],16,"close-input-pipe");
lf[134]=C_static_string(C_heaptop,24,"error while closing pipe");
lf[135]=C_h_intern(&lf[135],14,"\003syscheck-port");
lf[136]=C_static_lambda_info(C_heaptop,26,"(close-input-pipe port150)");
lf[137]=C_h_intern(&lf[137],17,"close-output-pipe");
lf[138]=C_h_intern(&lf[138],20,"call-with-input-pipe");
lf[139]=C_static_lambda_info(C_heaptop,7,"(a1504)");
lf[140]=C_static_lambda_info(C_heaptop,20,"(a1510 . results168)");
lf[141]=C_static_lambda_info(C_heaptop,47,"(call-with-input-pipe cmd164 proc165 . mode166)");
lf[142]=C_h_intern(&lf[142],21,"call-with-output-pipe");
lf[143]=C_static_lambda_info(C_heaptop,7,"(a1528)");
lf[144]=C_static_lambda_info(C_heaptop,20,"(a1534 . results174)");
lf[145]=C_static_lambda_info(C_heaptop,48,"(call-with-output-pipe cmd170 proc171 . mode172)");
lf[146]=C_h_intern(&lf[146],20,"with-input-from-pipe");
lf[147]=C_h_intern(&lf[147],18,"\003sysstandard-input");
lf[148]=C_static_lambda_info(C_heaptop,20,"(a1553 . results181)");
lf[149]=C_static_lambda_info(C_heaptop,48,"(with-input-from-pipe cmd176 thunk177 . mode178)");
lf[150]=C_h_intern(&lf[150],19,"with-output-to-pipe");
lf[151]=C_h_intern(&lf[151],19,"\003sysstandard-output");
lf[152]=C_static_lambda_info(C_heaptop,20,"(a1573 . results190)");
lf[153]=C_static_lambda_info(C_heaptop,47,"(with-output-to-pipe cmd185 thunk186 . mode187)");
lf[154]=C_h_intern(&lf[154],11,"create-pipe");
lf[155]=C_static_string(C_heaptop,19,"can not create pipe");
lf[156]=C_static_lambda_info(C_heaptop,13,"(create-pipe)");
lf[157]=C_h_intern(&lf[157],10,"errno/perm");
lf[158]=C_h_intern(&lf[158],11,"errno/noent");
lf[159]=C_h_intern(&lf[159],10,"errno/srch");
lf[160]=C_h_intern(&lf[160],10,"errno/intr");
lf[161]=C_h_intern(&lf[161],8,"errno/io");
lf[162]=C_h_intern(&lf[162],12,"errno/noexec");
lf[163]=C_h_intern(&lf[163],10,"errno/badf");
lf[164]=C_h_intern(&lf[164],11,"errno/child");
lf[165]=C_h_intern(&lf[165],11,"errno/nomem");
lf[166]=C_h_intern(&lf[166],11,"errno/acces");
lf[167]=C_h_intern(&lf[167],11,"errno/fault");
lf[168]=C_h_intern(&lf[168],10,"errno/busy");
lf[169]=C_h_intern(&lf[169],11,"errno/exist");
lf[170]=C_h_intern(&lf[170],12,"errno/notdir");
lf[171]=C_h_intern(&lf[171],11,"errno/isdir");
lf[172]=C_h_intern(&lf[172],11,"errno/inval");
lf[173]=C_h_intern(&lf[173],11,"errno/mfile");
lf[174]=C_h_intern(&lf[174],11,"errno/nospc");
lf[175]=C_h_intern(&lf[175],11,"errno/spipe");
lf[176]=C_h_intern(&lf[176],10,"errno/pipe");
lf[177]=C_h_intern(&lf[177],11,"errno/again");
lf[178]=C_h_intern(&lf[178],10,"errno/rofs");
lf[179]=C_h_intern(&lf[179],10,"errno/nxio");
lf[180]=C_h_intern(&lf[180],10,"errno/2big");
lf[181]=C_h_intern(&lf[181],10,"errno/xdev");
lf[182]=C_h_intern(&lf[182],11,"errno/nodev");
lf[183]=C_h_intern(&lf[183],11,"errno/nfile");
lf[184]=C_h_intern(&lf[184],11,"errno/notty");
lf[185]=C_h_intern(&lf[185],10,"errno/fbig");
lf[186]=C_h_intern(&lf[186],11,"errno/mlink");
lf[187]=C_h_intern(&lf[187],9,"errno/dom");
lf[188]=C_h_intern(&lf[188],11,"errno/range");
lf[189]=C_h_intern(&lf[189],12,"errno/deadlk");
lf[190]=C_h_intern(&lf[190],17,"errno/nametoolong");
lf[191]=C_h_intern(&lf[191],11,"errno/nolck");
lf[192]=C_h_intern(&lf[192],11,"errno/nosys");
lf[193]=C_h_intern(&lf[193],14,"errno/notempty");
lf[194]=C_h_intern(&lf[194],11,"errno/ilseq");
lf[195]=C_h_intern(&lf[195],16,"change-file-mode");
lf[196]=C_static_string(C_heaptop,24,"can not change file mode");
lf[197]=C_static_lambda_info(C_heaptop,32,"(change-file-mode fname199 m200)");
lf[198]=C_static_lambda_info(C_heaptop,33,"(check filename205 acc206 loc207)");
lf[199]=C_h_intern(&lf[199],17,"file-read-access\077");
lf[200]=C_static_lambda_info(C_heaptop,31,"(file-read-access\077 filename211)");
lf[201]=C_h_intern(&lf[201],18,"file-write-access\077");
lf[202]=C_static_lambda_info(C_heaptop,32,"(file-write-access\077 filename212)");
lf[203]=C_h_intern(&lf[203],20,"file-execute-access\077");
lf[204]=C_static_lambda_info(C_heaptop,34,"(file-execute-access\077 filename213)");
lf[205]=C_h_intern(&lf[205],12,"fileno/stdin");
lf[206]=C_h_intern(&lf[206],13,"fileno/stdout");
lf[207]=C_h_intern(&lf[207],13,"fileno/stderr");
lf[208]=C_h_intern(&lf[208],7,"\000append");
lf[209]=C_static_string(C_heaptop,27,"invalid mode for input file");
lf[210]=C_static_string(C_heaptop,1,"a");
lf[211]=C_static_string(C_heaptop,21,"invalid mode argument");
lf[212]=C_static_string(C_heaptop,1,"r");
lf[213]=C_static_string(C_heaptop,1,"w");
lf[214]=C_static_lambda_info(C_heaptop,18,"(mode inp219 m220)");
lf[215]=C_static_string(C_heaptop,17,"can not open file");
lf[216]=C_static_string(C_heaptop,8,"(fdport)");
lf[217]=C_static_lambda_info(C_heaptop,25,"(check fd224 inp225 r226)");
lf[218]=C_h_intern(&lf[218],16,"open-input-file*");
lf[219]=C_static_lambda_info(C_heaptop,31,"(open-input-file* fd230 . m231)");
lf[220]=C_h_intern(&lf[220],17,"open-output-file*");
lf[221]=C_static_lambda_info(C_heaptop,32,"(open-output-file* fd233 . m234)");
lf[222]=C_h_intern(&lf[222],12,"port->fileno");
lf[223]=C_static_string(C_heaptop,25,"port has no attached file");
lf[224]=C_static_string(C_heaptop,38,"can not access file-descriptor of port");
lf[225]=C_h_intern(&lf[225],25,"\003syspeek-unsigned-integer");
lf[226]=C_static_lambda_info(C_heaptop,22,"(port->fileno port239)");
lf[227]=C_h_intern(&lf[227],16,"duplicate-fileno");
lf[228]=C_static_string(C_heaptop,33,"can not duplicate file descriptor");
lf[229]=C_static_lambda_info(C_heaptop,34,"(duplicate-fileno old244 . new245)");
lf[230]=C_h_intern(&lf[230],6,"setenv");
lf[231]=C_static_lambda_info(C_heaptop,22,"(setenv var252 val253)");
lf[232]=C_h_intern(&lf[232],8,"unsetenv");
lf[233]=C_static_lambda_info(C_heaptop,17,"(unsetenv var257)");
lf[234]=C_h_intern(&lf[234],19,"current-environment");
lf[235]=C_static_lambda_info(C_heaptop,11,"(scan j271)");
lf[236]=C_h_intern(&lf[236],17,"\003syspeek-c-string");
lf[237]=C_static_lambda_info(C_heaptop,11,"(loop i268)");
lf[238]=C_static_lambda_info(C_heaptop,21,"(current-environment)");
lf[239]=C_h_intern(&lf[239],19,"seconds->local-time");
lf[240]=C_h_intern(&lf[240],18,"\003sysdecode-seconds");
lf[241]=C_static_lambda_info(C_heaptop,29,"(seconds->local-time secs274)");
lf[242]=C_h_intern(&lf[242],17,"seconds->utc-time");
lf[243]=C_static_lambda_info(C_heaptop,27,"(seconds->utc-time secs276)");
lf[244]=C_h_intern(&lf[244],15,"seconds->string");
lf[245]=C_static_string(C_heaptop,33,"can not convert seconds to string");
lf[246]=C_static_lambda_info(C_heaptop,25,"(seconds->string secs284)");
lf[247]=C_h_intern(&lf[247],12,"time->string");
lf[248]=C_static_string(C_heaptop,29,"can not time vector to string");
lf[249]=C_static_string(C_heaptop,21,"time vector too short");
lf[250]=C_static_lambda_info(C_heaptop,20,"(time->string tm293)");
lf[251]=C_h_intern(&lf[251],5,"_exit");
lf[252]=C_h_intern(&lf[252],23,"\003syscleanup-before-exit");
lf[253]=C_static_lambda_info(C_heaptop,17,"(_exit . code303)");
lf[254]=C_h_intern(&lf[254],19,"set-buffering-mode!");
lf[255]=C_static_string(C_heaptop,26,"can not set buffering mode");
lf[256]=C_h_intern(&lf[256],5,"\000full");
lf[257]=C_h_intern(&lf[257],5,"\000line");
lf[258]=C_h_intern(&lf[258],5,"\000none");
lf[259]=C_static_string(C_heaptop,22,"invalid buffering-mode");
lf[260]=C_static_lambda_info(C_heaptop,47,"(set-buffering-mode! port305 mode306 . size307)");
lf[261]=C_h_intern(&lf[261],12,"glob->regexp");
lf[262]=C_h_intern(&lf[262],13,"make-pathname");
lf[263]=C_h_intern(&lf[263],18,"decompose-pathname");
lf[264]=C_h_intern(&lf[264],4,"glob");
lf[265]=C_static_lambda_info(C_heaptop,7,"(a2142)");
lf[266]=C_h_intern(&lf[266],12,"string-match");
lf[267]=C_static_lambda_info(C_heaptop,11,"(loop f335)");
lf[268]=C_static_string(C_heaptop,1,".");
lf[269]=C_static_string(C_heaptop,1,"*");
lf[270]=C_static_lambda_info(C_heaptop,38,"(a2148 dir322325 file323326 ext324327)");
lf[271]=C_static_lambda_info(C_heaptop,15,"(conc paths320)");
lf[272]=C_static_lambda_info(C_heaptop,17,"(glob . paths318)");
lf[273]=C_h_intern(&lf[273],13,"spawn/overlay");
lf[274]=C_h_intern(&lf[274],10,"spawn/wait");
lf[275]=C_h_intern(&lf[275],12,"spawn/nowait");
lf[276]=C_h_intern(&lf[276],13,"spawn/nowaito");
lf[277]=C_h_intern(&lf[277],12,"spawn/detach");
lf[278]=C_static_lambda_info(C_heaptop,24,"(setarg a347353 a346354)");
lf[279]=C_h_intern(&lf[279],24,"pathname-strip-directory");
lf[280]=C_h_intern(&lf[280],15,"process-execute");
lf[281]=C_static_string(C_heaptop,23,"can not execute process");
lf[282]=C_static_lambda_info(C_heaptop,18,"(do373 al375 i376)");
lf[283]=C_static_lambda_info(C_heaptop,20,"(body363 arglist369)");
lf[284]=C_static_lambda_info(C_heaptop,31,"(def-envlist366 %arglist361389)");
lf[285]=C_static_lambda_info(C_heaptop,16,"(def-arglist365)");
lf[286]=C_static_lambda_info(C_heaptop,39,"(process-execute filename359 . g358360)");
lf[287]=C_static_lambda_info(C_heaptop,24,"(setarg a399405 a398406)");
lf[288]=C_h_intern(&lf[288],13,"process-spawn");
lf[289]=C_static_string(C_heaptop,23,"can not execute process");
lf[290]=C_static_lambda_info(C_heaptop,18,"(do415 al417 i418)");
lf[291]=C_static_lambda_info(C_heaptop,48,"(process-spawn mode410 filename411 . arglist412)");
lf[292]=C_h_intern(&lf[292],18,"current-process-id");
lf[293]=C_static_lambda_info(C_heaptop,20,"(current-process-id)");
lf[294]=C_h_intern(&lf[294],9,"get-shell");
lf[295]=C_static_lambda_info(C_heaptop,11,"(get-shell)");
lf[296]=C_h_intern(&lf[296],6,"getenv");
lf[297]=C_h_intern(&lf[297],11,"process-run");
lf[298]=C_static_string(C_heaptop,2,"/c");
lf[299]=C_static_lambda_info(C_heaptop,28,"(process-run f439 . args440)");
lf[301]=C_static_lambda_info(C_heaptop,14,"(close-handle)");
lf[302]=C_h_intern(&lf[302],15,"make-input-port");
lf[303]=C_h_intern(&lf[303],16,"make-output-port");
lf[304]=C_h_intern(&lf[304],7,"process");
lf[305]=C_static_string(C_heaptop,23,"could not write to pipe");
lf[306]=C_static_lambda_info(C_heaptop,12,"(a2574 s467)");
lf[307]=C_static_lambda_info(C_heaptop,7,"(a2587)");
lf[308]=C_static_string(C_heaptop,24,"could not read from pipe");
lf[309]=C_static_lambda_info(C_heaptop,7,"(a2593)");
lf[310]=C_static_lambda_info(C_heaptop,7,"(a2617)");
lf[311]=C_static_lambda_info(C_heaptop,7,"(a2620)");
lf[312]=C_static_string(C_heaptop,24,"could not create process");
lf[313]=C_h_intern(&lf[313],14,"C_close_handle");
lf[314]=C_static_string(C_heaptop,4," /c ");
lf[315]=C_static_string(C_heaptop,1,"\000");
lf[316]=C_static_string(C_heaptop,22,"could not redirect I/O");
lf[317]=C_static_lambda_info(C_heaptop,9,"(body453)");
lf[318]=C_static_lambda_info(C_heaptop,12,"(def-env456)");
lf[319]=C_static_lambda_info(C_heaptop,13,"(def-args455)");
lf[320]=C_static_lambda_info(C_heaptop,26,"(process cmd449 . g448450)");
lf[321]=C_h_intern(&lf[321],12,"process-wait");
lf[322]=C_static_lambda_info(C_heaptop,31,"(process-wait pid478 . args479)");
lf[323]=C_h_intern(&lf[323],5,"sleep");
lf[324]=C_static_lambda_info(C_heaptop,12,"(sleep t486)");
lf[325]=C_h_intern(&lf[325],13,"get-host-name");
lf[326]=C_static_string(C_heaptop,26,"can not retrieve host-name");
lf[327]=C_static_lambda_info(C_heaptop,15,"(get-host-name)");
lf[328]=C_h_intern(&lf[328],18,"system-information");
lf[329]=C_static_string(C_heaptop,7,"windows");
lf[330]=C_static_string(C_heaptop,35,"can not retrieve system-information");
lf[331]=C_static_lambda_info(C_heaptop,20,"(system-information)");
lf[332]=C_h_intern(&lf[332],10,"find-files");
lf[333]=C_static_lambda_info(C_heaptop,13,"(f_2906 x514)");
lf[334]=C_static_string(C_heaptop,1,".");
lf[335]=C_static_string(C_heaptop,2,"..");
lf[336]=C_static_lambda_info(C_heaptop,7,"(a2852)");
lf[337]=C_static_string(C_heaptop,1,"*");
lf[338]=C_static_lambda_info(C_heaptop,7,"(a2857)");
lf[339]=C_static_lambda_info(C_heaptop,7,"(a2871)");
lf[340]=C_h_intern(&lf[340],16,"\003sysdynamic-wind");
lf[341]=C_h_intern(&lf[341],13,"pathname-file");
lf[342]=C_static_lambda_info(C_heaptop,17,"(loop fs516 r517)");
lf[343]=C_static_string(C_heaptop,1,"*");
lf[344]=C_static_lambda_info(C_heaptop,15,"(f_2922 . _512)");
lf[345]=C_static_lambda_info(C_heaptop,15,"(f_2914 . _511)");
lf[346]=C_static_lambda_info(C_heaptop,34,"(body499 action506 id507 limit508)");
lf[347]=C_static_lambda_info(C_heaptop,38,"(def-limit503 %action496529 %id497530)");
lf[348]=C_static_lambda_info(C_heaptop,25,"(def-id502 %action496532)");
lf[349]=C_static_lambda_info(C_heaptop,17,"(a2942 x534 y535)");
lf[350]=C_static_lambda_info(C_heaptop,15,"(def-action501)");
lf[351]=C_static_lambda_info(C_heaptop,48,"(find-files dir493 pred494 . action-id-limit495)");
lf[352]=C_h_intern(&lf[352],17,"register-feature!");
lf[353]=C_h_intern(&lf[353],5,"posix");
lf[354]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,355);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_681,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k679 */
static void f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k682 in k679 */
static void f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k685 in k682 in k679 */
static void f_687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k688 in k685 in k682 in k679 */
static void f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 597  register-feature! */
t3=*((C_word*)lf[352]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[353]);}

/* k691 in k688 in k685 in k682 in k679 */
static void f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word ab[258],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=lf[7],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[8]+1,C_fix((C_word)PIPE_BUF));
t4=C_mutate((C_word*)lf[9]+1,C_fix((C_word)O_RDONLY));
t5=C_mutate((C_word*)lf[10]+1,C_fix((C_word)O_WRONLY));
t6=C_mutate((C_word*)lf[11]+1,C_fix((C_word)O_RDWR));
t7=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDWR));
t8=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t9=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_CREAT));
t10=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_APPEND));
t11=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_EXCL));
t12=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_TRUNC));
t13=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_BINARY));
t14=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_TEXT));
t15=C_mutate((C_word*)lf[20]+1,C_fix((C_word)S_IREAD));
t16=C_mutate((C_word*)lf[21]+1,C_fix((C_word)S_IWRITE));
t17=C_mutate((C_word*)lf[22]+1,C_fix((C_word)S_IEXEC));
t18=C_mutate((C_word*)lf[23]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t25=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t26=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t27=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t28=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t27);
t29=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=t28,a[3]=lf[39],tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_784,a[2]=lf[42],tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[43]+1);
t32=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_802,a[2]=t31,a[3]=lf[48],tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[53]+1);
t35=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_889,a[2]=t34,a[3]=lf[57],tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[58]+1,C_fix((C_word)SEEK_SET));
t37=C_mutate((C_word*)lf[59]+1,C_fix((C_word)SEEK_END));
t38=C_mutate((C_word*)lf[60]+1,C_fix((C_word)SEEK_CUR));
t39=C_mutate(&lf[61],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_927,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=lf[69],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=lf[73],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=lf[77],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=lf[79],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=lf[90],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=lf[96],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1162,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t54=*((C_word*)lf[106]+1);
t55=*((C_word*)lf[43]+1);
t56=*((C_word*)lf[107]+1);
t57=*((C_word*)lf[108]+1);
t58=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=t55,a[3]=t57,a[4]=lf[113],tmp=(C_word)a,a+=5,tmp));
t59=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=lf[115],tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[43]+1);
t61=*((C_word*)lf[108]+1);
t62=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=t60,a[3]=t61,a[4]=lf[118],tmp=(C_word)a,a+=5,tmp));
t63=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=lf[120],tmp=(C_word)a,a+=3,tmp);
t64=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=lf[122],tmp=(C_word)a,a+=3,tmp);
t65=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp);
t66=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1405,a[2]=t64,a[3]=t65,a[4]=t63,a[5]=lf[130],tmp=(C_word)a,a+=6,tmp));
t67=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1441,a[2]=t64,a[3]=t65,a[4]=t63,a[5]=lf[132],tmp=(C_word)a,a+=6,tmp));
t68=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=lf[136],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[137]+1,*((C_word*)lf[133]+1));
t70=*((C_word*)lf[128]+1);
t71=*((C_word*)lf[131]+1);
t72=*((C_word*)lf[133]+1);
t73=*((C_word*)lf[137]+1);
t74=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=t70,a[3]=t72,a[4]=lf[141],tmp=(C_word)a,a+=5,tmp));
t75=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1520,a[2]=t71,a[3]=t73,a[4]=lf[145],tmp=(C_word)a,a+=5,tmp));
t76=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1544,a[2]=t70,a[3]=t72,a[4]=lf[149],tmp=(C_word)a,a+=5,tmp));
t77=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1564,a[2]=t71,a[3]=t73,a[4]=lf[153],tmp=(C_word)a,a+=5,tmp));
t78=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=lf[156],tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[157]+1,C_fix((C_word)EPERM));
t80=C_mutate((C_word*)lf[158]+1,C_fix((C_word)ENOENT));
t81=C_mutate((C_word*)lf[159]+1,C_fix((C_word)ESRCH));
t82=C_mutate((C_word*)lf[160]+1,C_fix((C_word)EINTR));
t83=C_mutate((C_word*)lf[161]+1,C_fix((C_word)EIO));
t84=C_mutate((C_word*)lf[162]+1,C_fix((C_word)ENOEXEC));
t85=C_mutate((C_word*)lf[163]+1,C_fix((C_word)EBADF));
t86=C_mutate((C_word*)lf[164]+1,C_fix((C_word)ECHILD));
t87=C_mutate((C_word*)lf[165]+1,C_fix((C_word)ENOMEM));
t88=C_mutate((C_word*)lf[166]+1,C_fix((C_word)EACCES));
t89=C_mutate((C_word*)lf[167]+1,C_fix((C_word)EFAULT));
t90=C_mutate((C_word*)lf[168]+1,C_fix((C_word)EBUSY));
t91=C_mutate((C_word*)lf[169]+1,C_fix((C_word)EEXIST));
t92=C_mutate((C_word*)lf[170]+1,C_fix((C_word)ENOTDIR));
t93=C_mutate((C_word*)lf[171]+1,C_fix((C_word)EISDIR));
t94=C_mutate((C_word*)lf[172]+1,C_fix((C_word)EINVAL));
t95=C_mutate((C_word*)lf[173]+1,C_fix((C_word)EMFILE));
t96=C_mutate((C_word*)lf[174]+1,C_fix((C_word)ENOSPC));
t97=C_mutate((C_word*)lf[175]+1,C_fix((C_word)ESPIPE));
t98=C_mutate((C_word*)lf[176]+1,C_fix((C_word)EPIPE));
t99=C_mutate((C_word*)lf[177]+1,C_fix((C_word)EAGAIN));
t100=C_mutate((C_word*)lf[178]+1,C_fix((C_word)EROFS));
t101=C_mutate((C_word*)lf[179]+1,C_fix((C_word)ENXIO));
t102=C_mutate((C_word*)lf[180]+1,C_fix((C_word)E2BIG));
t103=C_mutate((C_word*)lf[181]+1,C_fix((C_word)EXDEV));
t104=C_mutate((C_word*)lf[182]+1,C_fix((C_word)ENODEV));
t105=C_mutate((C_word*)lf[183]+1,C_fix((C_word)ENFILE));
t106=C_mutate((C_word*)lf[184]+1,C_fix((C_word)ENOTTY));
t107=C_mutate((C_word*)lf[185]+1,C_fix((C_word)EFBIG));
t108=C_mutate((C_word*)lf[186]+1,C_fix((C_word)EMLINK));
t109=C_mutate((C_word*)lf[187]+1,C_fix((C_word)EDOM));
t110=C_mutate((C_word*)lf[188]+1,C_fix((C_word)ERANGE));
t111=C_mutate((C_word*)lf[189]+1,C_fix((C_word)EDEADLK));
t112=C_mutate((C_word*)lf[190]+1,C_fix((C_word)ENAMETOOLONG));
t113=C_mutate((C_word*)lf[191]+1,C_fix((C_word)ENOLCK));
t114=C_mutate((C_word*)lf[192]+1,C_fix((C_word)ENOSYS));
t115=C_mutate((C_word*)lf[193]+1,C_fix((C_word)ENOTEMPTY));
t116=C_mutate((C_word*)lf[194]+1,C_fix((C_word)EILSEQ));
t117=C_mutate((C_word*)lf[195]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=lf[197],tmp=(C_word)a,a+=3,tmp));
t118=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=lf[198],tmp=(C_word)a,a+=3,tmp);
t119=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1694,a[2]=t118,a[3]=lf[200],tmp=(C_word)a,a+=4,tmp));
t120=C_mutate((C_word*)lf[201]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t118,a[3]=lf[202],tmp=(C_word)a,a+=4,tmp));
t121=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=t118,a[3]=lf[204],tmp=(C_word)a,a+=4,tmp));
t122=C_mutate((C_word*)lf[205]+1,C_fix((C_word)0));
t123=C_mutate((C_word*)lf[206]+1,C_fix((C_word)1));
t124=C_mutate((C_word*)lf[207]+1,C_fix((C_word)2));
t125=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=lf[214],tmp=(C_word)a,a+=3,tmp);
t126=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1752,a[2]=lf[217],tmp=(C_word)a,a+=3,tmp);
t127=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1770,a[2]=t125,a[3]=t126,a[4]=lf[219],tmp=(C_word)a,a+=5,tmp));
t128=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1784,a[2]=t125,a[3]=t126,a[4]=lf[221],tmp=(C_word)a,a+=5,tmp));
t129=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=lf[226],tmp=(C_word)a,a+=3,tmp));
t130=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=lf[229],tmp=(C_word)a,a+=3,tmp));
t131=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1863,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp));
t132=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=lf[233],tmp=(C_word)a,a+=3,tmp));
t133=*((C_word*)lf[108]+1);
t134=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t133,a[3]=lf[238],tmp=(C_word)a,a+=4,tmp));
t135=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1965,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t136=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=lf[243],tmp=(C_word)a,a+=3,tmp));
t137=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1993,a[2]=lf[246],tmp=(C_word)a,a+=3,tmp));
t138=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=lf[250],tmp=(C_word)a,a+=3,tmp));
t139=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp));
t140=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2063,a[2]=lf[260],tmp=(C_word)a,a+=3,tmp));
t141=*((C_word*)lf[261]+1);
t142=*((C_word*)lf[109]+1);
t143=*((C_word*)lf[262]+1);
t144=*((C_word*)lf[263]+1);
t145=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2122,a[2]=t141,a[3]=t142,a[4]=t143,a[5]=t144,a[6]=lf[272],tmp=(C_word)a,a+=7,tmp));
t146=C_mutate((C_word*)lf[273]+1,C_fix((C_word)P_OVERLAY));
t147=C_mutate((C_word*)lf[274]+1,C_fix((C_word)P_WAIT));
t148=C_mutate((C_word*)lf[275]+1,C_fix((C_word)P_NOWAIT));
t149=C_mutate((C_word*)lf[276]+1,C_fix((C_word)P_NOWAITO));
t150=C_mutate((C_word*)lf[277]+1,C_fix((C_word)P_DETACH));
t151=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=lf[278],tmp=(C_word)a,a+=3,tmp);
t152=*((C_word*)lf[279]+1);
t153=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=t152,a[3]=t151,a[4]=lf[286],tmp=(C_word)a,a+=5,tmp));
t154=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=lf[287],tmp=(C_word)a,a+=3,tmp);
t155=*((C_word*)lf[279]+1);
t156=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2413,a[2]=t155,a[3]=t154,a[4]=lf[291],tmp=(C_word)a,a+=5,tmp));
t157=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=lf[293],tmp=(C_word)a,a+=3,tmp));
t158=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=lf[295],tmp=(C_word)a,a+=3,tmp));
t159=*((C_word*)lf[288]+1);
t160=*((C_word*)lf[296]+1);
t161=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=t159,a[3]=lf[299],tmp=(C_word)a,a+=4,tmp));
t162=C_mutate(&lf[300],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2544,a[2]=lf[301],tmp=(C_word)a,a+=3,tmp));
t163=*((C_word*)lf[302]+1);
t164=*((C_word*)lf[303]+1);
t165=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2547,a[2]=t163,a[3]=t164,a[4]=lf[320],tmp=(C_word)a,a+=5,tmp));
t166=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=lf[322],tmp=(C_word)a,a+=3,tmp));
t167=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=lf[324],tmp=(C_word)a,a+=3,tmp));
t168=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=lf[327],tmp=(C_word)a,a+=3,tmp));
t169=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=lf[331],tmp=(C_word)a,a+=3,tmp));
t170=*((C_word*)lf[264]+1);
t171=*((C_word*)lf[266]+1);
t172=*((C_word*)lf[262]+1);
t173=*((C_word*)lf[114]+1);
t174=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2786,a[2]=t173,a[3]=t172,a[4]=t170,a[5]=t171,a[6]=lf[351],tmp=(C_word)a,a+=7,tmp));
t175=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t175+1)))(2,t175,C_SCHEME_UNDEFINED);}

/* find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_2786r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2786r(t0,t1,t2,t3,t4);}}

static void f_2786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=lf[346],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t5,a[3]=lf[347],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2932,a[2]=t6,a[3]=lf[348],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2937,a[2]=t7,a[3]=lf[350],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action501533 */
t9=t8;
f_2937(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id502531 */
t11=t7;
f_2932(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit503528 */
t13=t6;
f_2927(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body499505 */
t15=t5;
f_2788(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action501 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2937,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=lf[349],tmp=(C_word)a,a+=3,tmp);
/* def-id502531 */
t3=((C_word*)t0)[2];
f_2932(t3,t1,t2);}

/* a2942 in def-action501 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2943,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id502 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2932,NULL,3,t0,t1,t2);}
/* def-limit503528 */
t3=((C_word*)t0)[2];
f_2927(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit503 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2927(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2927,NULL,4,t0,t1,t2,t3);}
/* body499505 */
t4=((C_word*)t0)[2];
f_2788(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2788(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2788,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[332]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_2795(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2922,a[2]=t4,a[3]=t7,a[4]=lf[344],tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_2795(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=lf[345],tmp=(C_word)a,a+=3,tmp));}}

/* f_2914 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2914(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_2922 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2922(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2795,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=lf[333],tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1429 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[343]);}

/* k2900 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1429 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=lf[342],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_2807(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2807,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1435 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1436 pathname-file */
t3=*((C_word*)lf[341]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1442 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k2886 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1442 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1443 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2807(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2893 in k2886 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2807(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[334]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[335]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 1436 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_2807(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1437 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2853,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=lf[336],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=lf[338],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2872,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=lf[339],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1439 ##sys#dynamic-wind */
t11=*((C_word*)lf[340]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 1441 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2807(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a2871 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a2857 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1440 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[337]);}

/* k2868 in a2857 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1440 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2864 in a2857 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1440 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2807(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a2852 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2849 in k2839 in k2880 in k2824 in loop in k2803 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1438 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2807(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_2906 in k2793 in body499 in find-files in k691 in k688 in k685 in k682 in k679 */
static void f_2906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2906,3,t0,t1,t2);}
/* posixwin.scm: 1427 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2755,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1404 ##sys#update-errno */
t3=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2779 in system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1405 ##sys#error */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[328],lf[330]);}

/* k2764 in system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k2768 in k2764 in system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2774,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k2772 in k2768 in k2764 in system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2778,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k2776 in k2772 in k2768 in k2764 in system-information in k691 in k688 in k685 in k682 in k679 */
static void f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1402 values */
C_values(7,0,((C_word*)t0)[5],lf[329],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* get-host-name in k691 in k688 in k685 in k682 in k679 */
static void f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1397 ##sys#error */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[325],lf[326]);}}

/* sleep in k691 in k688 in k685 in k682 in k679 */
static void f_2740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2740,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k691 in k688 in k685 in k682 in k679 */
static void f_2698(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_2698r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2698r(t0,t1,t2,t3);}}

static void f_2698r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
if(C_truep((C_word)C_process_wait(t2,t5))){
/* posixwin.scm: 1378 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1380 ##sys#update-errno */
t9=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
/* ##sys#error */
t8=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[0],t7);}}

/* k2718 in process-wait in k691 in k688 in k685 in k682 in k679 */
static void f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1381 values */
C_values(5,0,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* process in k691 in k688 in k685 in k682 in k679 */
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2547r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2547r(t0,t1,t2,t3);}}

static void f_2547r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2549,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[317],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2645,a[2]=t4,a[3]=lf[318],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=t5,a[3]=lf[319],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args455473 */
t7=t6;
f_2650(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env456471 */
t9=t5;
f_2645(t9,t1);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body453458 */
t11=t4;
f_2549(t11,t1);}
else{
/* ##sys#error */
t11=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args455 in process in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2650,NULL,2,t0,t1);}
/* def-env456471 */
t2=((C_word*)t0)[2];
f_2645(t2,t1);}

/* def-env456 in process in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2645,NULL,2,t0,t1);}
/* body453458 */
t2=((C_word*)t0)[2];
f_2549(t2,t1);}

/* body453 in process in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2549,NULL,2,t0,t1);}
if(C_truep((C_word)C_redir_io())){
t2=C_fix((C_word)C_wr0_);
t3=C_fix((C_word)C_rd1_);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1339 get-shell */
t6=*((C_word*)lf[294]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
/* posixwin.scm: 1370 ##sys#error */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[304],lf[316]);}}

/* k2639 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1339 string-append */
t2=*((C_word*)lf[106]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],t1,lf[314],((C_word*)t0)[2],lf[315]);}

/* k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(C_word)C_run_process(t1);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[3],a[3]=lf[309],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[3],a[3]=lf[310],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[3],a[3]=lf[311],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1343 make-input-port */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1365 ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2626 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1366 C_close_handle */
t3=*((C_word*)lf[313]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2629 in k2626 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1367 C_close_handle */
t3=*((C_word*)lf[313]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2632 in k2629 in k2626 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1368 ##sys#error */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[304],lf[312]);}

/* a2620 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
/* posixwin.scm: 1352 close-handle */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2544(((C_word*)t0)[2]));}

/* a2617 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pipe_ready(((C_word*)t0)[2]));}

/* a2593 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(C_word)C_pipe_read(((C_word*)t0)[2]);
switch(t2){
case C_fix(-1):
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_FILE);
case C_fix(0):
/* posixwin.scm: 1347 ##sys#error */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[304],lf[308]);
default:
t3=(C_word)C_eqp(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_make_character((C_word)C_rdbuf):C_SCHEME_UNDEFINED));}}

/* k2567 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[3],a[3]=lf[306],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[3],a[3]=lf[307],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1356 make-output-port */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}

/* a2587 in k2567 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2588,2,t0,t1);}
/* posixwin.scm: 1361 close-handle */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2544(((C_word*)t0)[2]));}

/* a2574 in k2567 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2575,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
if(C_truep((C_word)C_pipe_write(((C_word*)t0)[2],t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1359 ##sys#error */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[304],lf[305]);}}

/* k2571 in k2567 in k2554 in body453 in process in k691 in k688 in k685 in k682 in k679 */
static void f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1342 values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* close-handle in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall f_2544(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub443(C_SCHEME_UNDEFINED,t1));}

/* process-run in k691 in k688 in k685 in k682 in k679 */
static void f_2515(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2515r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2515r(t0,t1,t2,t3);}}

static void f_2515r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1321 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[275]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2532,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1322 get-shell */
t7=*((C_word*)lf[294]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k2530 in process-run in k691 in k688 in k685 in k682 in k679 */
static void f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[298],((C_word*)t0)[4]);
/* posixwin.scm: 1322 process-spawn */
t3=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],*((C_word*)lf[275]+1),t1,t2);}

/* get-shell in k691 in k688 in k685 in k682 in k679 */
static void f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub434(t2),C_fix(0));}

/* current-process-id in k691 in k688 in k685 in k682 in k679 */
static void f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub432(C_SCHEME_UNDEFINED));}

/* process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2413r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2413r(t0,t1,t2,t3,t4);}}

static void f_2413r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_exact_2(t2,lf[288]);
t6=(C_word)C_i_check_string_2(t3,lf[288]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_END_OF_LIST);
t9=(C_word)C_i_check_list_2(t8,lf[288]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2429,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1280 pathname-strip-directory */
t11=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t3);}

/* k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2429,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_2394(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2437,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[290],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2437(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do415 in k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2437(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2437,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_2394(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1287 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[288]);
t6=(C_word)C_block_size(t4);
t7=f_2394(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t14=t1;
t15=t8;
t16=t9;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}

/* k2468 in do415 in k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1287 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2449 in do415 in k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(C_word)C_spawnvp(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1288 ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2452 in k2449 in do415 in k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub408(C_SCHEME_UNDEFINED);
/* posixwin.scm: 1291 ##sys#error */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[288],lf[289],((C_word*)t0)[2]);}
else{
t4=t2;
f_2457(2,t4,C_SCHEME_UNDEFINED);}}

/* k2455 in k2452 in k2449 in do415 in k2427 in process-spawn in k691 in k688 in k685 in k682 in k679 */
static void f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setarg in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall f_2394(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub401(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-execute in k691 in k688 in k685 in k682 in k679 */
static void f_2250(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2250r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2250r(t0,t1,t2,t3);}}

static void f_2250r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=lf[283],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=t4,a[3]=lf[284],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=t5,a[3]=lf[285],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist365390 */
t7=t6;
f_2346(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist366388 */
t9=t5;
f_2341(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body363368 */
t11=t4;
f_2252(t11,t1,t7);}
else{
/* ##sys#error */
t11=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist365 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2346,NULL,2,t0,t1);}
/* def-envlist366388 */
t2=((C_word*)t0)[2];
f_2341(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist366 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2341,NULL,3,t0,t1,t2);}
/* body363368 */
t3=((C_word*)t0)[2];
f_2252(t3,t1,t2);}

/* body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2252,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[280]);
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[280]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2265,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1256 pathname-strip-directory */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[4]);}

/* k2263 in body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_2231(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2273,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[282],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2273(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do373 in k2263 in body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2273(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2273,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_2231(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1262 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[280]);
t6=(C_word)C_block_size(t4);
t7=f_2231(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t14=t1;
t15=t8;
t16=t9;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}

/* k2304 in do373 in k2263 in body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1262 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2285 in do373 in k2263 in body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
t2=(C_word)C_execvp(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1263 ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2288 in k2285 in do373 in k2263 in body363 in process-execute in k691 in k688 in k685 in k682 in k679 */
static void f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(-1));
if(C_truep(t2)){
t3=(C_word)stub356(C_SCHEME_UNDEFINED);
/* posixwin.scm: 1266 ##sys#error */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[280],lf[281],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* setarg in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall f_2231(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub349(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* glob in k691 in k688 in k685 in k682 in k679 */
static void f_2122(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_2122r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2122r(t0,t1,t2);}}

static void f_2122r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(10);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=lf[271],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2128(t6,t1,t2);}

/* conc in glob in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2128(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2128,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[265],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=lf[270],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2149,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[269]);
/* posixwin.scm: 1226 make-pathname */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k2218 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1226 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:lf[268]);
/* posixwin.scm: 1227 directory */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2158 in k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=lf[267],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2162(t5,((C_word*)t0)[2],t1);}

/* loop in k2158 in k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_2162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2162,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* posixwin.scm: 1228 conc */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2128(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1229 string-match */
t5=*((C_word*)lf[266]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k2177 in loop in k2158 in k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1230 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1231 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2162(t3,((C_word*)t0)[6],t2);}}

/* k2187 in k2177 in loop in k2158 in k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1230 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2162(t4,t2,t3);}

/* k2191 in k2187 in k2177 in loop in k2158 in k2151 in a2148 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a2142 in conc in glob in k691 in k688 in k685 in k682 in k679 */
static void f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
/* posixwin.scm: 1225 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k691 in k688 in k685 in k682 in k679 */
static void f_2063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2063r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2063r(t0,t1,t2,t3,t4);}}

static void f_2063r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2067,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1199 ##sys#check-port */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[254]);}

/* k2065 in set-buffering-mode! in k691 in k688 in k685 in k682 in k679 */
static void f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[256]);
if(C_truep(t6)){
t7=t5;
f_2073(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[257]);
if(C_truep(t7)){
t8=t5;
f_2073(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[258]);
if(C_truep(t8)){
t9=t5;
f_2073(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1205 ##sys#error */
t9=*((C_word*)lf[66]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[254],lf[259],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k2071 in k2065 in set-buffering-mode! in k691 in k688 in k685 in k682 in k679 */
static void f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[254]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[87],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1211 ##sys#error */
t6=*((C_word*)lf[66]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[254],lf[255],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k691 in k688 in k685 in k682 in k679 */
static void f_2044(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2044r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2044r(t0,t1,t2);}}

static void f_2044r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1189 ##sys#cleanup-before-exit */
t4=*((C_word*)lf[252]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2046 in _exit in k691 in k688 in k685 in k682 in k679 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
t4=((C_word*)t0)[2];
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub300(C_SCHEME_UNDEFINED,t5));}

/* time->string in k691 in k688 in k685 in k682 in k679 */
static void f_2010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2010,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[247]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1178 ##sys#error */
t6=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[247],lf[249],t2);}
else{
t6=t4;
f_2017(2,t6,C_SCHEME_UNDEFINED);}}

/* k2015 in time->string in k691 in k688 in k685 in k682 in k679 */
static void f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub289(t4,t3),C_fix(0));}

/* k2018 in k2015 in time->string in k691 in k688 in k685 in k682 in k679 */
static void f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2023(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1180 ##sys#error */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[247],lf[248],((C_word*)t0)[2]);}}

/* k2021 in k2018 in k2015 in time->string in k691 in k688 in k685 in k682 in k679 */
static void f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->string in k691 in k688 in k685 in k682 in k679 */
static void f_1993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1993,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub280(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k1995 in seconds->string in k691 in k688 in k685 in k682 in k679 */
static void f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2000(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1171 ##sys#error */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[244],lf[245],((C_word*)t0)[2]);}}

/* k1998 in k1995 in seconds->string in k691 in k688 in k685 in k682 in k679 */
static void f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->utc-time in k691 in k688 in k685 in k682 in k679 */
static void f_1974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1974,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[242]);
/* posixwin.scm: 1165 ##sys#decode-seconds */
t4=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k691 in k688 in k685 in k682 in k679 */
static void f_1965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1965,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[239]);
/* posixwin.scm: 1161 ##sys#decode-seconds */
t4=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k691 in k688 in k685 in k682 in k679 */
static void f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=lf[237],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1906(t5,t1,C_fix(0));}

/* loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1906,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1910,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub263(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k1908 in loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1918,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[235],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1918(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k1908 in loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1918,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1153 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1154 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k1942 in scan in k1908 in loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1153 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k1946 in k1942 in scan in k1908 in loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1153 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1906(t5,t3,t4);}

/* k1934 in k1946 in k1942 in scan in k1908 in loop in current-environment in k691 in k688 in k685 in k682 in k679 */
static void f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k691 in k688 in k685 in k682 in k679 */
static void f_1880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1880,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[232]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1141 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1886 in unsetenv in k691 in k688 in k685 in k682 in k679 */
static void f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k691 in k688 in k685 in k682 in k679 */
static void f_1863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1863,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[230]);
t5=(C_word)C_i_check_string_2(t3,lf[230]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1136 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1872 in setenv in k691 in k688 in k685 in k682 in k679 */
static void f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1136 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1876 in k1872 in setenv in k691 in k688 in k685 in k682 in k679 */
static void f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1833r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1833r(t0,t1,t2,t3);}}

static void f_1833r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[227]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_1840(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[227]);
t8=t5;
f_1840(t8,(C_word)C_dup2(t2,t6));}}

/* k1838 in duplicate-fileno in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1126 ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1843(2,t3,C_SCHEME_UNDEFINED);}}

/* k1847 in k1838 in duplicate-fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1127 ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[227],lf[228],((C_word*)t0)[2]);}

/* k1841 in k1838 in duplicate-fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1798,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1802,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1108 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[222]);}

/* k1800 in port->fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1109 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1829 in k1800 in port->fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1115 ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[222],lf[223],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1811,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1112 ##sys#update-errno */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_1811(2,t4,C_SCHEME_UNDEFINED);}}}

/* k1815 in k1829 in k1800 in port->fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1113 ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[222],lf[224],((C_word*)t0)[2]);}

/* k1809 in k1829 in k1800 in port->fileno in k691 in k688 in k685 in k682 in k679 */
static void f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k691 in k688 in k685 in k682 in k679 */
static void f_1784(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1784r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1784r(t0,t1,t2,t3);}}

static void f_1784r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[220]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1796,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1104 mode */
f_1715(t5,C_SCHEME_FALSE,t3);}

/* k1794 in open-output-file* in k691 in k688 in k685 in k682 in k679 */
static void f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1104 check */
f_1752(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k691 in k688 in k685 in k682 in k679 */
static void f_1770(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1770r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1770r(t0,t1,t2,t3);}}

static void f_1770r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[218]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1782,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1100 mode */
f_1715(t5,C_SCHEME_TRUE,t3);}

/* k1780 in open-input-file* in k691 in k688 in k685 in k682 in k679 */
static void f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1100 check */
f_1752(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1752(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1756,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1091 ##sys#update-errno */
t6=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1754 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1093 ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[34],lf[215],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1094 ##sys#make-port */
t3=*((C_word*)lf[124]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[125]+1),lf[216],lf[87]);}}

/* k1766 in k1754 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1715(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[208]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1086 ##sys#error */
t8=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[209],t5);}
else{
t8=t4;
f_1723(2,t8,lf[210]);}}
else{
/* posixwin.scm: 1087 ##sys#error */
t7=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[211],t5);}}
else{
t5=t4;
f_1723(2,t5,(C_truep(t2)?lf[212]:lf[213]));}}

/* k1721 in mode in k691 in k688 in k685 in k682 in k679 */
static void f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1082 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k691 in k688 in k685 in k682 in k679 */
static void f_1706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1706,3,t0,t1,t2);}
/* posixwin.scm: 1066 check */
f_1670(t1,t2,C_fix((C_word)2),lf[203]);}

/* file-write-access? in k691 in k688 in k685 in k682 in k679 */
static void f_1700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1700,3,t0,t1,t2);}
/* posixwin.scm: 1065 check */
f_1670(t1,t2,C_fix((C_word)4),lf[201]);}

/* file-read-access? in k691 in k688 in k685 in k682 in k679 */
static void f_1694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1694,3,t0,t1,t2);}
/* posixwin.scm: 1064 check */
f_1670(t1,t2,C_fix((C_word)2),lf[199]);}

/* check in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1670(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1670,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1061 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k1690 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1061 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1686 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1680(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1062 ##sys#update-errno */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1678 in k1686 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k691 in k688 in k685 in k682 in k679 */
static void f_1640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1640,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[195]);
t5=(C_word)C_i_check_exact_2(t3,lf[195]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1664,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1050 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k1666 in change-file-mode in k691 in k688 in k685 in k682 in k679 */
static void f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1050 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1662 in change-file-mode in k691 in k688 in k685 in k682 in k679 */
static void f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1051 ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1654 in k1662 in change-file-mode in k691 in k688 in k685 in k682 in k679 */
static void f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1052 ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[34],lf[195],lf[196],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 958  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1588(2,t3,C_SCHEME_UNDEFINED);}}

/* k1595 in create-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 959  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[34],lf[154],lf[155]);}

/* k1586 in create-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 960  values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1564r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1564r(t0,t1,t2,t3,t4);}}

static void f_1564r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[151]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1568,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k1566 in with-output-to-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=C_mutate((C_word*)lf[151]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1574,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[152],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 943  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1573 in k1566 in with-output-to-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1574(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1574r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1574r(t0,t1,t2);}}

static void f_1574r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1578,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 945  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1576 in a1573 in k1566 in with-output-to-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[151]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1544r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1544r(t0,t1,t2,t3,t4);}}

static void f_1544r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[147]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1548,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k1546 in with-input-from-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=C_mutate((C_word*)lf[147]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1554,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[148],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 933  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1553 in k1546 in with-input-from-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1554(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1554r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1554r(t0,t1,t2);}}

static void f_1554r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1558,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 935  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1556 in a1553 in k1546 in with-input-from-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[147]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1520r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1520r(t0,t1,t2,t3,t4);}}

static void f_1520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1522 in call-with-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1529,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[143],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1535,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[144],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 923  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1534 in k1522 in call-with-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1535(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1535r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1535r(t0,t1,t2);}}

static void f_1535r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1539,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 926  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1537 in a1534 in k1522 in call-with-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1528 in k1522 in call-with-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
/* posixwin.scm: 924  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1496r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1496r(t0,t1,t2,t3,t4);}}

static void f_1496r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1500,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1498 in call-with-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[139],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1511,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[140],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 915  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1510 in k1498 in call-with-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1511(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1511r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1511r(t0,t1,t2);}}

static void f_1511r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 918  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1513 in a1510 in k1498 in call-with-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1504 in k1498 in call-with-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
/* posixwin.scm: 916  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1481,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 902  ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[133]);}

/* k1479 in close-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 904  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1482 in k1479 in close-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 905  ##sys#signal-hook */
t3=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[34],lf[133],lf[134],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1441(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1441r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1441r(t0,t1,t2,t3);}}

static void f_1441r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[131]);
t5=f_1369(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1455,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[119]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1462,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 897  ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[129]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 898  ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 899  badmode */
f_1381(t6,t5);}}}

/* k1470 in open-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1455(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1460 in open-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1455(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1453 in open-output-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 894  check */
f_1387(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1405(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1405r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1405r(t0,t1,t2,t3);}}

static void f_1405r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[128]);
t5=f_1369(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1419,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[119]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 887  ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[129]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1436,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 888  ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 889  badmode */
f_1381(t6,t5);}}}

/* k1434 in open-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1419(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1424 in open-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1419(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1417 in open-input-pipe in k691 in k688 in k685 in k682 in k679 */
static void f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 884  check */
f_1387(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1387(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1387,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1391,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 874  ##sys#update-errno */
t6=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1389 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 876  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[34],lf[123],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 877  ##sys#make-port */
t3=*((C_word*)lf[124]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[125]+1),lf[126],lf[87]);}}

/* k1401 in k1389 in check in k691 in k688 in k685 in k682 in k679 */
static void f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1381(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1381,NULL,2,t1,t2);}
/* posixwin.scm: 872  ##sys#error */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[121],t2);}

/* mode in k691 in k688 in k685 in k682 in k679 */
static C_word C_fcall f_1369(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[119]));}

/* current-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1323(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1323r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1323r(t0,t1,t2);}}

static void f_1323r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1327(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1327(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1325 in current-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 859  change-directory */
t2=*((C_word*)lf[100]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 860  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k1334 in k1325 in current-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1339,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 862  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1337 in k1334 in k1325 in current-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 864  substring */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[5]);}
else{
/* posixwin.scm: 865  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[34],lf[116],lf[117]);}}

/* directory? in k691 in k688 in k685 in k682 in k679 */
static void f_1300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1300,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 851  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1319 in directory? in k691 in k688 in k685 in k682 in k679 */
static void f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 851  ##sys#file-info */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1305 in directory? in k691 in k688 in k685 in k682 in k679 */
static void f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k691 in k688 in k685 in k682 in k679 */
static void f_1243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1243,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[109]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1250,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 831  make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_fix(256));}

/* k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 832  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 833  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 834  ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1296 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 834  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1258 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 837  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=lf[111],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1277(t6,((C_word*)t0)[6]);}}

/* loop in k1258 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_1277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1277,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 846  substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1285 in loop in k1258 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 847  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1277(t3,t2);}

/* k1292 in k1285 in loop in k1258 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1267 in k1258 in k1254 in k1251 in k1248 in directory in k691 in k688 in k685 in k682 in k679 */
static void f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 838  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[109],lf[110],((C_word*)t0)[2]);}

/* delete-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1216,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1241,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 820  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1239 in delete-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 820  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1235 in delete-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 821  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1227 in k1235 in delete-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 822  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[103],lf[104],((C_word*)t0)[2]);}

/* change-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1189,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 813  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1212 in change-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 813  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1208 in change-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 814  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1200 in k1208 in change-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 815  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[100],lf[101],((C_word*)t0)[2]);}

/* create-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1162,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 806  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1185 in create-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 806  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1181 in create-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 807  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1173 in k1181 in create-directory in k691 in k688 in k685 in k682 in k679 */
static void f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 808  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[97],lf[98],((C_word*)t0)[2]);}

/* set-file-position! in k691 in k688 in k685 in k682 in k679 */
static void f_1101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1101r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1101r(t0,t1,t2,t3,t4);}}

static void f_1101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[91]);
t8=(C_word)C_i_check_exact_2(t6,lf[91]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1114,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 791  ##sys#signal-hook */
t10=*((C_word*)lf[33]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[94],lf[91],lf[95],t3,t2);}
else{
t10=t9;
f_1114(2,t10,C_SCHEME_UNDEFINED);}}

/* k1112 in set-file-position! in k691 in k688 in k685 in k682 in k679 */
static void f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 792  port? */
t4=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1127 in k1112 in set-file-position! in k691 in k688 in k685 in k682 in k679 */
static void f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[87]);
t4=((C_word*)t0)[4];
f_1120(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1120(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 796  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[91],lf[93],((C_word*)t0)[5]);}}}

/* k1118 in k1112 in set-file-position! in k691 in k688 in k685 in k682 in k679 */
static void f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 797  ##sys#update-errno */
t3=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1121 in k1118 in k1112 in set-file-position! in k691 in k688 in k685 in k682 in k679 */
static void f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 798  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[34],lf[91],lf[92],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k691 in k688 in k685 in k682 in k679 */
static void f_1061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1061,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1065,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1080,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 775  port? */
t5=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1078 in file-position in k691 in k688 in k685 in k682 in k679 */
static void f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[87]);
t4=((C_word*)t0)[2];
f_1065(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1065(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 780  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[85],lf[88],((C_word*)t0)[3]);}}}

/* k1063 in file-position in k691 in k688 in k685 in k682 in k679 */
static void f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 782  ##sys#update-errno */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1068(2,t3,C_SCHEME_UNDEFINED);}}

/* k1072 in k1063 in file-position in k691 in k688 in k685 in k682 in k679 */
static void f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 783  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[85],lf[86],((C_word*)t0)[2]);}

/* k1066 in k1063 in file-position in k691 in k688 in k685 in k682 in k679 */
static void f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k691 in k688 in k685 in k682 in k679 */
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1055,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k691 in k688 in k685 in k682 in k679 */
static void f_1032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1032,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[80]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 766  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1051 in regular-file? in k691 in k688 in k685 in k682 in k679 */
static void f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 766  ##sys#file-info */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1037 in regular-file? in k691 in k688 in k685 in k682 in k679 */
static void f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k691 in k688 in k685 in k682 in k679 */
static void f_1026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1026,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 762  ##sys#stat */
f_927(t3,t2);}

/* k1028 in file-permissions in k691 in k688 in k685 in k682 in k679 */
static void f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k691 in k688 in k685 in k682 in k679 */
static void f_1020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1020,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 761  ##sys#stat */
f_927(t3,t2);}

/* k1022 in file-owner in k691 in k688 in k685 in k682 in k679 */
static void f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k691 in k688 in k685 in k682 in k679 */
static void f_1014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1014,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 760  ##sys#stat */
f_927(t3,t2);}

/* k1016 in file-change-time in k691 in k688 in k685 in k682 in k679 */
static void f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k691 in k688 in k685 in k682 in k679 */
static void f_1008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1008,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 759  ##sys#stat */
f_927(t3,t2);}

/* k1010 in file-access-time in k691 in k688 in k685 in k682 in k679 */
static void f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k691 in k688 in k685 in k682 in k679 */
static void f_1002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1002,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 758  ##sys#stat */
f_927(t3,t2);}

/* k1004 in file-modification-time in k691 in k688 in k685 in k682 in k679 */
static void f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k691 in k688 in k685 in k682 in k679 */
static void f_996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 757  ##sys#stat */
f_927(t3,t2);}

/* k998 in file-size in k691 in k688 in k685 in k682 in k679 */
static void f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k691 in k688 in k685 in k682 in k679 */
static void f_965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_965r(t0,t1,t2,t3);}}

static void f_965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_969,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_969(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_969(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k967 in file-stat in k691 in k688 in k685 in k682 in k679 */
static void f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 752  ##sys#stat */
f_927(t2,((C_word*)t0)[2]);}

/* k970 in k967 in file-stat in k691 in k688 in k685 in k682 in k679 */
static void f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime)));}

/* ##sys#stat in k691 in k688 in k685 in k682 in k679 */
static void C_fcall f_927(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_927,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_931,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_931(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 745  ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 746  ##sys#signal-hook */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[63],t2);}}}

/* k958 in ##sys#stat in k691 in k688 in k685 in k682 in k679 */
static void f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 745  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k954 in ##sys#stat in k691 in k688 in k685 in k682 in k679 */
static void f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_931(2,t2,(C_word)C_stat(t1));}

/* k929 in ##sys#stat in k691 in k688 in k685 in k682 in k679 */
static void f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 748  ##sys#update-errno */
t3=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k938 in k929 in ##sys#stat in k691 in k688 in k685 in k682 in k679 */
static void f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 749  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[34],lf[62],((C_word*)t0)[2]);}

/* file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_889,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[54]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 714  ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k894 in file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 716  string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k897 in k894 in file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_919,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 718  ##sys#update-errno */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_902(2,t4,C_SCHEME_UNDEFINED);}}

/* k917 in k897 in k894 in file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 719  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[54],lf[56],((C_word*)t0)[2]);}

/* k900 in k897 in k894 in file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 720  ##sys#substring */
t4=*((C_word*)lf[55]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k907 in k900 in k897 in k894 in file-mkstemp in k691 in k688 in k685 in k682 in k679 */
static void f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 720  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k691 in k688 in k685 in k682 in k679 */
static void f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_847r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_847r(t0,t1,t2,t3,t4);}}

static void f_847r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[49]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_854,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_854(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 701  ##sys#signal-hook */
t8=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[49],lf[51],t3);}}

/* k852 in file-write in k691 in k688 in k685 in k682 in k679 */
static void f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[49]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_869,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 706  ##sys#update-errno */
t9=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_863(2,t8,C_SCHEME_UNDEFINED);}}

/* k867 in k852 in file-write in k691 in k688 in k685 in k682 in k679 */
static void f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 707  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[34],lf[49],lf[50],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k861 in k852 in file-write in k691 in k688 in k685 in k682 in k679 */
static void f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k691 in k688 in k685 in k682 in k679 */
static void f_802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_802r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_802r(t0,t1,t2,t3,t4);}}

static void f_802r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_812,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_812(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 688  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k810 in file-read in k691 in k688 in k685 in k682 in k679 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_815(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 690  ##sys#signal-hook */
t4=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k813 in k810 in file-read in k691 in k688 in k685 in k682 in k679 */
static void f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_818,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 693  ##sys#update-errno */
t6=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_818(2,t5,C_SCHEME_UNDEFINED);}}

/* k825 in k813 in k810 in file-read in k691 in k688 in k685 in k682 in k679 */
static void f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 694  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[34],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k816 in k813 in k810 in file-read in k691 in k688 in k685 in k682 in k679 */
static void f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k691 in k688 in k685 in k682 in k679 */
static void f_784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_784,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[40]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_797,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 680  ##sys#update-errno */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k795 in file-close in k691 in k688 in k685 in k682 in k679 */
static void f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 681  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[40],lf[41],((C_word*)t0)[2]);}

/* file-open in k691 in k688 in k685 in k682 in k679 */
static void f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_743r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_743r(t0,t1,t2,t3,t4);}}

static void f_743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[32]);
t8=(C_word)C_i_check_exact_2(t3,lf[32]);
t9=(C_word)C_i_check_exact_2(t6,lf[32]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_760,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_776,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 670  ##sys#expand-home-path */
t12=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k774 in file-open in k691 in k688 in k685 in k682 in k679 */
static void f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 670  ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k758 in file-open in k691 in k688 in k685 in k682 in k679 */
static void f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_760,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_763,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 672  ##sys#update-errno */
t6=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_763(2,t5,C_SCHEME_UNDEFINED);}}

/* k767 in k758 in file-open in k691 in k688 in k685 in k682 in k679 */
static void f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 673  ##sys#signal-hook */
t2=*((C_word*)lf[33]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[34],lf[32],lf[35],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k761 in k758 in file-open in k691 in k688 in k685 in k682 in k679 */
static void f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* yield in k691 in k688 in k685 in k682 in k679 */
static void f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=lf[6],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 602  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a700 in yield in k691 in k688 in k685 in k682 in k679 */
static void f_701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_701,3,t0,t1,t2);}
t3=*((C_word*)lf[3]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t2,a[3]=lf[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* posixwin.scm: 606  ##sys#schedule */
t6=*((C_word*)lf[5]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t1);}

/* a709 in a700 in yield in k691 in k688 in k685 in k682 in k679 */
static void f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
/* posixwin.scm: 605  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}
/* end of file */
