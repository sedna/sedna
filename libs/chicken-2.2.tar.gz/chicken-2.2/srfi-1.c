/* Generated from srfi-1.scm by the Chicken compiler
   2005-08-24 19:37
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-1.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file srfi-1.c -explicit-use
   unit: srfi_1
*/

#include "chicken.h"


static C_TLS C_word lf[411];


C_externexport void C_srfi_1_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_935(C_word c,C_word t0,C_word t1) C_noret;
static void f_5509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5509r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5516(C_word c,C_word t0,C_word t1) C_noret;
static void f_5533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5541(C_word c,C_word t0,C_word t1) C_noret;
static void f_5469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5476(C_word c,C_word t0,C_word t1) C_noret;
static void f_5493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5501(C_word c,C_word t0,C_word t1) C_noret;
static void f_5411(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5411r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5460(C_word c,C_word t0,C_word t1) C_noret;
static void f_5423(C_word c,C_word t0,C_word t1) C_noret;
static void f_5357(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5357r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5406(C_word c,C_word t0,C_word t1) C_noret;
static void f_5369(C_word c,C_word t0,C_word t1) C_noret;
static void f_5320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5320r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5324(C_word c,C_word t0,C_word t1) C_noret;
static void f_5341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5355(C_word c,C_word t0,C_word t1) C_noret;
static void f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5283r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5287(C_word c,C_word t0,C_word t1) C_noret;
static void f_5304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5318(C_word c,C_word t0,C_word t1) C_noret;
static void f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5250r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5254(C_word c,C_word t0,C_word t1) C_noret;
static void f_5260(C_word c,C_word t0,C_word t1) C_noret;
static void f_5271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5221(C_word c,C_word t0,C_word t1) C_noret;
static void f_5227(C_word c,C_word t0,C_word t1) C_noret;
static void f_5238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5166(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5166r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5206(C_word c,C_word t0,C_word t1) C_noret;
static void f_5118(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5118r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5155(C_word c,C_word t0,C_word t1) C_noret;
static void f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_5100r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_5106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5113(C_word c,C_word t0,C_word t1) C_noret;
static void f_5036(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5036r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_5056(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5087(C_word c,C_word t0,C_word t1) C_noret;
static void f_5078(C_word c,C_word t0,C_word t1) C_noret;
static void f_4978(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4978r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4998(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5020(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4966(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_4948(C_word t0,C_word t1);
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4921(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4871(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4896(C_word c,C_word t0,C_word t1) C_noret;
static void f_4877(C_word c,C_word t0,C_word t1) C_noret;
static void f_4738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4738r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4826(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4842(C_word c,C_word t0,C_word t1) C_noret;
static void f_4760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4797(C_word c,C_word t0,C_word t1) C_noret;
static void f_4778(C_word c,C_word t0,C_word t1) C_noret;
static void f_4750(C_word c,C_word t0,C_word t1) C_noret;
static void f_4621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4621r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4718(C_word c,C_word t0,C_word t1) C_noret;
static void f_4643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4677(C_word c,C_word t0,C_word t1) C_noret;
static void f_4661(C_word c,C_word t0,C_word t1) C_noret;
static void f_4633(C_word c,C_word t0,C_word t1) C_noret;
static void f_4605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4619(C_word c,C_word t0,C_word t1) C_noret;
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4603(C_word c,C_word t0,C_word t1) C_noret;
static void f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4583(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4535(C_word t0,C_word t1) C_noret;
static void C_fcall f_4550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4566(C_word c,C_word t0,C_word t1) C_noret;
static void f_4541(C_word c,C_word t0,C_word t1) C_noret;
static void f_4472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4497(C_word c,C_word t0,C_word t1) C_noret;
static void f_4512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4502(C_word c,C_word t0,C_word t1) C_noret;
static void f_4414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4466(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4424(C_word t0,C_word t1) C_noret;
static void C_fcall f_4433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4449(C_word c,C_word t0,C_word t1) C_noret;
static void f_4427(C_word c,C_word t0,C_word t1) C_noret;
static void f_4382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4401(C_word c,C_word t0,C_word t1) C_noret;
static void f_4347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4369(C_word c,C_word t0,C_word t1) C_noret;
static void f_4376(C_word c,C_word t0,C_word t1) C_noret;
static void f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4317(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4330(C_word c,C_word t0,C_word t1) C_noret;
static void f_4299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4303(C_word c,C_word t0,C_word t1) C_noret;
static void f_4270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4287(C_word c,C_word t0,C_word t1) C_noret;
static void f_4241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4241r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4258(C_word c,C_word t0,C_word t1) C_noret;
static void f_4221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4140r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4178(C_word c,C_word t0,C_word t1) C_noret;
static void f_4165(C_word c,C_word t0,C_word t1) C_noret;
static void f_4094(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4094r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4132(C_word c,C_word t0,C_word t1) C_noret;
static void f_4119(C_word c,C_word t0,C_word t1) C_noret;
static void f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4073r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4048r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4065(C_word c,C_word t0,C_word t1) C_noret;
static void f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4023r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4040(C_word c,C_word t0,C_word t1) C_noret;
static void f_4007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4021(C_word c,C_word t0,C_word t1) C_noret;
static void f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4005(C_word c,C_word t0,C_word t1) C_noret;
static void f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3885(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3960(C_word c,C_word t0,C_word t1) C_noret;
static void f_3963(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3894(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3910(C_word c,C_word t0,C_word t1) C_noret;
static void f_3920(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3836(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3855(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3791(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3797(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3810(C_word c,C_word t0,C_word t1) C_noret;
static void f_3711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3717(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3751(C_word c,C_word t0,C_word t1) C_noret;
static void f_3738(C_word c,C_word t0,C_word t1) C_noret;
static void f_3590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3705(C_word c,C_word t0,C_word t1) C_noret;
static void f_3697(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3657(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3670(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3631(C_word c,C_word t0,C_word t1) C_noret;
static void f_3548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3554(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3573(C_word c,C_word t0,C_word t1) C_noret;
static void f_3576(C_word c,C_word t0,C_word t1) C_noret;
static void f_3471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3534(C_word c,C_word t0,C_word t1) C_noret;
static void f_3541(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3509(C_word c,C_word t0,C_word t1) C_noret;
static void f_3516(C_word c,C_word t0,C_word t1) C_noret;
static void f_3493(C_word c,C_word t0,C_word t1) C_noret;
static void f_3386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3386r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3452(C_word c,C_word t0,C_word t1) C_noret;
static void f_3455(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3402(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3424(C_word c,C_word t0,C_word t1) C_noret;
static void f_3434(C_word c,C_word t0,C_word t1) C_noret;
static void f_3408(C_word c,C_word t0,C_word t1) C_noret;
static void f_3314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3314r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3380(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3326(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3359(C_word c,C_word t0,C_word t1) C_noret;
static void f_3338(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2529(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2565(C_word c,C_word t0,C_word t1) C_noret;
static void f_2553(C_word c,C_word t0,C_word t1) C_noret;
static void f_2541(C_word c,C_word t0,C_word t1) C_noret;
static void f_3318(C_word c,C_word t0,C_word t1) C_noret;
static void f_3255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3255r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_3292(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3305(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3275(C_word c,C_word t0,C_word t1) C_noret;
static void f_3284(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3146(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3228(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3232(C_word c,C_word t0,C_word t1) C_noret;
static void f_3245(C_word c,C_word t0,C_word t1) C_noret;
static void f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3184(C_word c,C_word t0,C_word t1) C_noret;
static void f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3209(C_word c,C_word t0,C_word t1) C_noret;
static void f_3189(C_word c,C_word t0,C_word t1) C_noret;
static void f_3158(C_word c,C_word t0,C_word t1) C_noret;
static void f_3140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3110(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3124(C_word c,C_word t0,C_word t1) C_noret;
static void f_3070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_3005r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3068(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3021(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3025(C_word c,C_word t0,C_word t1) C_noret;
static void f_3042(C_word c,C_word t0,C_word t1) C_noret;
static void f_3038(C_word c,C_word t0,C_word t1) C_noret;
static void f_2939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_2939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2999(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2959(C_word c,C_word t0,C_word t1) C_noret;
static void f_2980(C_word c,C_word t0,C_word t1) C_noret;
static void f_2972(C_word c,C_word t0,C_word t1) C_noret;
static void f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_2874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_2916(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2933(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2894(C_word c,C_word t0,C_word t1) C_noret;
static void f_2911(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2346(C_word c,C_word t0,C_word t1) C_noret;
static void f_2350(C_word c,C_word t0,C_word t1) C_noret;
static void f_2907(C_word c,C_word t0,C_word t1) C_noret;
static void f_2803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_2803r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_2850(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2868(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2845(C_word c,C_word t0,C_word t1) C_noret;
static void f_2825(C_word c,C_word t0,C_word t1) C_noret;
static void f_2445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2451(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2496(C_word c,C_word t0,C_word t1) C_noret;
static void f_2484(C_word c,C_word t0,C_word t1) C_noret;
static void f_2463(C_word c,C_word t0,C_word t1) C_noret;
static void f_2721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_2721r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void C_fcall f_2779(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2786(C_word c,C_word t0,C_word t1) C_noret;
static void f_2793(C_word c,C_word t0,C_word t1) C_noret;
static void f_2801(C_word c,C_word t0,C_word t1) C_noret;
static void f_2797(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2752(C_word c,C_word t0,C_word t1) C_noret;
static void f_2762(C_word c,C_word t0,C_word t1) C_noret;
static void f_2770(C_word c,C_word t0,C_word t1) C_noret;
static void f_2766(C_word c,C_word t0,C_word t1) C_noret;
static void f_2681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_2681r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2698(C_word c,C_word t0,C_word t1) C_noret;
static void f_2705(C_word c,C_word t0,C_word t1) C_noret;
static void f_2713(C_word c,C_word t0,C_word t1) C_noret;
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2588r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2672(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2639(C_word c,C_word t0,C_word t1) C_noret;
static void f_2612(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2359(C_word t0,C_word t1) C_noret;
static void f_2365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2416(C_word c,C_word t0,C_word t1) C_noret;
static void f_2404(C_word c,C_word t0,C_word t1) C_noret;
static void f_2383(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2278(C_word t0,C_word t1) C_noret;
static void f_2284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2290(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2320(C_word c,C_word t0,C_word t1) C_noret;
static void f_2272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_2248(C_word t0,C_word t1);
static void f_2212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2218(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2136(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2136r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2171(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2173(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2196(C_word c,C_word t0,C_word t1) C_noret;
static void f_2052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2058(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2076(C_word c,C_word t0,C_word t1) C_noret;
static void f_1980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1986(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2004(C_word c,C_word t0,C_word t1) C_noret;
static void f_1916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1940(C_word c,C_word t0,C_word t1) C_noret;
static void f_1860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1866(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1884(C_word c,C_word t0,C_word t1) C_noret;
static void f_1854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1839(C_word t0);
static void f_1823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1831(C_word c,C_word t0,C_word t1) C_noret;
static void f_1792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1808(C_word c,C_word t0,C_word t1) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1749(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1764(C_word c,C_word t0,C_word t1) C_noret;
static void f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1702(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1717(C_word t0,C_word t1,C_word t2);
static void f_1660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1668(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1688(C_word c,C_word t0,C_word t1) C_noret;
static void f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1638(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1640(C_word t0,C_word t1);
static void f_1607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1624(C_word c,C_word t0,C_word t1) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1587(C_word t0,C_word t1);
static void f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1568(C_word c,C_word t0,C_word t1) C_noret;
static void f_1524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1446(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1446r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1403(C_word t0,C_word t1,C_word t2);
static void f_1297(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1297r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1317(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1372(C_word c,C_word t0,C_word t1) C_noret;
static void f_1294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1258(C_word t0,C_word t1);
static void f_1195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_1201(C_word t0,C_word t1);
static void f_1181(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1181r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1192(C_word c,C_word t0,C_word t1) C_noret;
static void f_1095(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1095r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1102(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1108(C_word t0,C_word t1) C_noret;
static void C_fcall f_1122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1071(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1089(C_word c,C_word t0,C_word t1) C_noret;
static void f_1035(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1035r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1055(C_word c,C_word t0,C_word t1) C_noret;
static void f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1033(C_word c,C_word t0,C_word t1) C_noret;
static void f_943(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_943r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_950(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

static void C_fcall trf_5056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5056(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5056(t0,t1,t2,t3);}

static void C_fcall trf_4998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4998(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4998(t0,t1,t2,t3);}

static void C_fcall trf_4966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4966(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4966(t0,t1,t2,t3);}

static void C_fcall trf_4908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4908(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4908(t0,t1,t2,t3);}

static void C_fcall trf_4871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4871(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4871(t0,t1,t2,t3);}

static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4826(t0,t1,t2,t3);}

static void C_fcall trf_4772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4772(t0,t1,t2,t3);}

static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4705(t0,t1,t2,t3);}

static void C_fcall trf_4655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4655(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4655(t0,t1,t2,t3);}

static void C_fcall trf_4535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4535(t0,t1);}

static void C_fcall trf_4550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4550(t0,t1,t2,t3);}

static void C_fcall trf_4478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4478(t0,t1,t2);}

static void C_fcall trf_4424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4424(t0,t1);}

static void C_fcall trf_4433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4433(t0,t1,t2,t3);}

static void C_fcall trf_4388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4388(t0,t1,t2);}

static void C_fcall trf_4353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4353(t0,t1,t2);}

static void C_fcall trf_4317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4317(t0,t1,t2);}

static void C_fcall trf_4149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4149(t0,t1,t2);}

static void C_fcall trf_4103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4103(t0,t1,t2);}

static void C_fcall trf_3944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3944(t0,t1,t2,t3);}

static void C_fcall trf_3894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3894(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3894(t0,t1,t2,t3);}

static void C_fcall trf_3836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3836(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3836(t0,t1,t2,t3,t4);}

static void C_fcall trf_3842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3842(t0,t1,t2,t3);}

static void C_fcall trf_3791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3791(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3791(t0,t1,t2,t3,t4);}

static void C_fcall trf_3797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3797(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3797(t0,t1,t2,t3);}

static void C_fcall trf_3717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3717(t0,t1,t2);}

static void C_fcall trf_3596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3596(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3596(t0,t1,t2);}

static void C_fcall trf_3651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3651(t0,t1,t2,t3);}

static void C_fcall trf_3657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3657(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3657(t0,t1,t2);}

static void C_fcall trf_3618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3618(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3618(t0,t1,t2,t3);}

static void C_fcall trf_3554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3554(t0,t1,t2);}

static void C_fcall trf_3521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3521(t0,t1,t2);}

static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3487(t0,t1,t2);}

static void C_fcall trf_3442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3442(t0,t1,t2);}

static void C_fcall trf_3402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3402(t0,t1,t2);}

static void C_fcall trf_3326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3326(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3326(t0,t1,t2,t3);}

static void C_fcall trf_2529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2529(t0,t1,t2);}

static void C_fcall trf_3292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3292(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3292(t0,t1,t2);}

static void C_fcall trf_3271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3271(t0,t1,t2);}

static void C_fcall trf_3146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3146(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3146(t0,t1,t2,t3,t4);}

static void C_fcall trf_3228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3228(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3228(t0,t1,t2,t3);}

static void C_fcall trf_3180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3180(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3180(t0,t1,t2,t3);}

static void C_fcall trf_3110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3110(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3110(t0,t1,t2,t3);}

static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3051(t0,t1,t2,t3);}

static void C_fcall trf_3021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3021(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3021(t0,t1,t2,t3);}

static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2985(t0,t1,t2);}

static void C_fcall trf_2955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2955(t0,t1,t2);}

static void C_fcall trf_2916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2916(t0,t1,t2);}

static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2890(t0,t1,t2);}

static void C_fcall trf_2332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2332(t0,t1,t2);}

static void C_fcall trf_2850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2850(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2850(t0,t1,t2,t3);}

static void C_fcall trf_2819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2819(t0,t1,t2,t3);}

static void C_fcall trf_2451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2451(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2451(t0,t1,t2);}

static void C_fcall trf_2779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2779(t0,t1,t2);}

static void C_fcall trf_2745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2745(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2745(t0,t1,t2);}

static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2691(t0,t1,t2,t3);}

static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2651(t0,t1,t2,t3);}

static void C_fcall trf_2600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2600(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2600(t0,t1,t2,t3,t4);}

static void C_fcall trf_2359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2359(t0,t1);}

static void C_fcall trf_2371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2371(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2371(t0,t1,t2);}

static void C_fcall trf_2278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2278(t0,t1);}

static void C_fcall trf_2290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2290(t0,t1,t2);}

static void C_fcall trf_2218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2218(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2218(t0,t1,t2,t3);}

static void C_fcall trf_2142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2142(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2142(t0,t1,t2,t3);}

static void C_fcall trf_2173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2173(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2173(t0,t1,t2,t3);}

static void C_fcall trf_2058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2058(t0,t1,t2);}

static void C_fcall trf_1986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1986(t0,t1,t2);}

static void C_fcall trf_1922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1922(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1922(t0,t1,t2);}

static void C_fcall trf_1866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1866(t0,t1,t2);}

static void C_fcall trf_1749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1749(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1749(t0,t1,t2,t3);}

static void C_fcall trf_1670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1670(t0,t1,t2,t3);}

static void C_fcall trf_1550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1550(t0,t1,t2,t3);}

static void C_fcall trf_1317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1317(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1317(t0,t1,t2,t3);}

static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1344(t0,t1,t2,t3);}

static void C_fcall trf_1108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1108(t0,t1);}

static void C_fcall trf_1122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1122(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1122(t0,t1,t2,t3,t4);}

static void C_fcall trf_1071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1071(t0,t1,t2);}

static void C_fcall trf_1041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1041(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1041(t0,t1,t2,t3);}

static void C_fcall trf_1011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1011(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1011(t0,t1,t2,t3);}

static void C_fcall trf_955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_955(t0,t1,t2,t3);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr6rv(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6rv(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n+1);
t6=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_1_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_1_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1080)){
C_save(t1);
C_rereclaim2(1080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,411);
lf[0]=C_h_intern(&lf[0],5,"xcons");
lf[1]=C_static_lambda_info(C_heaptop,13,"(xcons d2 a3)");
lf[2]=C_h_intern(&lf[2],9,"make-list");
lf[3]=C_static_lambda_info(C_heaptop,14,"(do7 i9 ans10)");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_static_string(C_heaptop,31,"Too many arguments to MAKE-LIST");
lf[6]=C_static_lambda_info(C_heaptop,29,"(make-list len4 . maybe-elt5)");
lf[7]=C_h_intern(&lf[7],13,"list-tabulate");
lf[8]=C_static_lambda_info(C_heaptop,16,"(do15 i17 ans18)");
lf[9]=C_static_lambda_info(C_heaptop,28,"(list-tabulate len13 proc14)");
lf[10]=C_h_intern(&lf[10],5,"cons*");
lf[11]=C_static_lambda_info(C_heaptop,18,"(recur x24 rest25)");
lf[12]=C_static_lambda_info(C_heaptop,24,"(cons* first21 . rest22)");
lf[13]=C_h_intern(&lf[13],9,"list-copy");
lf[14]=C_static_lambda_info(C_heaptop,13,"(recur lis29)");
lf[15]=C_static_lambda_info(C_heaptop,17,"(list-copy lis27)");
lf[16]=C_h_intern(&lf[16],4,"iota");
lf[17]=C_static_lambda_info(C_heaptop,26,"(do40 count42 val43 ans44)");
lf[18]=C_static_string(C_heaptop,19,"Negative step count");
lf[19]=C_static_lambda_info(C_heaptop,35,"(iota count31 . maybe-start+step32)");
lf[20]=C_h_intern(&lf[20],13,"circular-list");
lf[21]=C_h_intern(&lf[21],9,"last-pair");
lf[22]=C_static_lambda_info(C_heaptop,31,"(circular-list val150 . vals51)");
lf[23]=C_h_intern(&lf[23],12,"proper-list\077");
lf[24]=C_h_intern(&lf[24],5,"list\077");
lf[25]=C_h_intern(&lf[25],12,"dotted-list\077");
lf[26]=C_static_lambda_info(C_heaptop,10,"(lp lag57)");
lf[27]=C_static_lambda_info(C_heaptop,18,"(dotted-list\077 x54)");
lf[28]=C_h_intern(&lf[28],14,"circular-list\077");
lf[29]=C_static_lambda_info(C_heaptop,10,"(lp lag65)");
lf[30]=C_static_lambda_info(C_heaptop,20,"(circular-list\077 x62)");
lf[31]=C_h_intern(&lf[31],9,"not-pair\077");
lf[32]=C_static_lambda_info(C_heaptop,15,"(not-pair\077 x72)");
lf[33]=C_h_intern(&lf[33],10,"null-list\077");
lf[34]=C_static_lambda_info(C_heaptop,16,"(null-list\077 l73)");
lf[35]=C_h_intern(&lf[35],5,"list=");
lf[36]=C_static_lambda_info(C_heaptop,23,"(lp2 list-a86 list-b87)");
lf[37]=C_static_lambda_info(C_heaptop,23,"(lp1 list-a79 others80)");
lf[38]=C_static_lambda_info(C_heaptop,21,"(list= =74 . lists75)");
lf[39]=C_h_intern(&lf[39],7,"length+");
lf[40]=C_static_lambda_info(C_heaptop,16,"(lp lag93 len94)");
lf[41]=C_static_lambda_info(C_heaptop,13,"(length+ x90)");
lf[42]=C_h_intern(&lf[42],3,"zip");
lf[43]=C_h_intern(&lf[43],3,"map");
lf[44]=C_h_intern(&lf[44],4,"list");
lf[45]=C_static_lambda_info(C_heaptop,30,"(zip list1101 . more-lists102)");
lf[46]=C_h_intern(&lf[46],5,"first");
lf[47]=C_h_intern(&lf[47],3,"car");
lf[48]=C_h_intern(&lf[48],6,"second");
lf[49]=C_h_intern(&lf[49],4,"cadr");
lf[50]=C_h_intern(&lf[50],5,"third");
lf[51]=C_h_intern(&lf[51],5,"caddr");
lf[52]=C_h_intern(&lf[52],6,"fourth");
lf[53]=C_h_intern(&lf[53],6,"cadddr");
lf[54]=C_h_intern(&lf[54],5,"fifth");
lf[55]=C_static_lambda_info(C_heaptop,12,"(fifth x103)");
lf[56]=C_h_intern(&lf[56],5,"sixth");
lf[57]=C_static_lambda_info(C_heaptop,12,"(sixth x104)");
lf[58]=C_h_intern(&lf[58],7,"seventh");
lf[59]=C_static_lambda_info(C_heaptop,14,"(seventh x105)");
lf[60]=C_h_intern(&lf[60],6,"eighth");
lf[61]=C_static_lambda_info(C_heaptop,13,"(eighth x106)");
lf[62]=C_h_intern(&lf[62],5,"ninth");
lf[63]=C_static_lambda_info(C_heaptop,12,"(ninth x107)");
lf[64]=C_h_intern(&lf[64],5,"tenth");
lf[65]=C_static_lambda_info(C_heaptop,12,"(tenth x108)");
lf[66]=C_h_intern(&lf[66],7,"car+cdr");
lf[67]=C_static_lambda_info(C_heaptop,17,"(car+cdr pair109)");
lf[68]=C_h_intern(&lf[68],4,"take");
lf[69]=C_static_lambda_info(C_heaptop,19,"(recur lis114 k115)");
lf[70]=C_static_lambda_info(C_heaptop,18,"(take lis111 k112)");
lf[71]=C_h_intern(&lf[71],4,"drop");
lf[72]=C_static_lambda_info(C_heaptop,11,"(iter k122)");
lf[73]=C_static_lambda_info(C_heaptop,18,"(drop lis118 k119)");
lf[74]=C_h_intern(&lf[74],5,"take!");
lf[75]=C_static_lambda_info(C_heaptop,19,"(take! lis125 k126)");
lf[76]=C_h_intern(&lf[76],10,"take-right");
lf[77]=C_static_lambda_info(C_heaptop,12,"(lp lead133)");
lf[78]=C_static_lambda_info(C_heaptop,24,"(take-right lis129 k130)");
lf[79]=C_h_intern(&lf[79],10,"drop-right");
lf[80]=C_static_lambda_info(C_heaptop,22,"(recur lag138 lead139)");
lf[81]=C_static_lambda_info(C_heaptop,24,"(drop-right lis135 k136)");
lf[82]=C_h_intern(&lf[82],11,"drop-right!");
lf[83]=C_static_lambda_info(C_heaptop,12,"(lp lead146)");
lf[84]=C_static_lambda_info(C_heaptop,25,"(drop-right! lis141 k142)");
lf[85]=C_h_intern(&lf[85],8,"split-at");
lf[86]=C_static_lambda_info(C_heaptop,7,"(a1763)");
lf[87]=C_static_lambda_info(C_heaptop,27,"(a1777 prefix154 suffix155)");
lf[88]=C_static_lambda_info(C_heaptop,19,"(recur lis152 k153)");
lf[89]=C_static_lambda_info(C_heaptop,20,"(split-at x149 k150)");
lf[90]=C_h_intern(&lf[90],9,"split-at!");
lf[91]=C_static_lambda_info(C_heaptop,21,"(split-at! x158 k159)");
lf[92]=C_h_intern(&lf[92],4,"last");
lf[93]=C_static_lambda_info(C_heaptop,13,"(last lis164)");
lf[94]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[95]=C_static_lambda_info(C_heaptop,18,"(last-pair lis165)");
lf[96]=C_h_intern(&lf[96],6,"unzip1");
lf[97]=C_h_intern(&lf[97],7,"\003sysmap");
lf[98]=C_static_lambda_info(C_heaptop,15,"(unzip1 lis170)");
lf[99]=C_h_intern(&lf[99],6,"unzip2");
lf[100]=C_static_lambda_info(C_heaptop,7,"(a1883)");
lf[101]=C_static_lambda_info(C_heaptop,17,"(a1893 a175 b176)");
lf[102]=C_static_lambda_info(C_heaptop,14,"(recur lis173)");
lf[103]=C_static_lambda_info(C_heaptop,15,"(unzip2 lis171)");
lf[104]=C_h_intern(&lf[104],6,"unzip3");
lf[105]=C_static_lambda_info(C_heaptop,7,"(a1939)");
lf[106]=C_static_lambda_info(C_heaptop,22,"(a1949 a182 b183 c184)");
lf[107]=C_static_lambda_info(C_heaptop,14,"(recur lis180)");
lf[108]=C_static_lambda_info(C_heaptop,15,"(unzip3 lis178)");
lf[109]=C_h_intern(&lf[109],6,"unzip4");
lf[110]=C_static_lambda_info(C_heaptop,7,"(a2003)");
lf[111]=C_static_lambda_info(C_heaptop,27,"(a2013 a190 b191 c192 d193)");
lf[112]=C_static_lambda_info(C_heaptop,14,"(recur lis188)");
lf[113]=C_static_lambda_info(C_heaptop,15,"(unzip4 lis186)");
lf[114]=C_h_intern(&lf[114],6,"unzip5");
lf[115]=C_static_lambda_info(C_heaptop,7,"(a2075)");
lf[116]=C_static_lambda_info(C_heaptop,32,"(a2085 a199 b200 c201 d202 e203)");
lf[117]=C_static_lambda_info(C_heaptop,14,"(recur lis197)");
lf[118]=C_static_lambda_info(C_heaptop,15,"(unzip5 lis195)");
lf[119]=C_h_intern(&lf[119],7,"append!");
lf[120]=C_static_lambda_info(C_heaptop,26,"(lp2 tail-cons212 rest213)");
lf[121]=C_static_lambda_info(C_heaptop,21,"(lp lists207 prev208)");
lf[122]=C_static_lambda_info(C_heaptop,20,"(append! . lists205)");
lf[123]=C_h_intern(&lf[123],14,"append-reverse");
lf[124]=C_static_lambda_info(C_heaptop,24,"(lp rev-head222 tail223)");
lf[125]=C_static_lambda_info(C_heaptop,36,"(append-reverse rev-head219 tail220)");
lf[126]=C_h_intern(&lf[126],15,"append-reverse!");
lf[127]=C_static_lambda_info(C_heaptop,12,"(lp tail229)");
lf[128]=C_static_lambda_info(C_heaptop,37,"(append-reverse! rev-head225 tail226)");
lf[129]=C_h_intern(&lf[129],11,"concatenate");
lf[130]=C_h_intern(&lf[130],12,"reduce-right");
lf[131]=C_h_intern(&lf[131],6,"append");
lf[132]=C_static_lambda_info(C_heaptop,22,"(concatenate lists233)");
lf[133]=C_h_intern(&lf[133],12,"concatenate!");
lf[134]=C_static_lambda_info(C_heaptop,23,"(concatenate! lists234)");
lf[136]=C_static_lambda_info(C_heaptop,16,"(recur lists238)");
lf[137]=C_static_lambda_info(C_heaptop,16,"(a2283 abort236)");
lf[138]=C_static_lambda_info(C_heaptop,23,"(##srfi1#cdrs lists235)");
lf[140]=C_static_lambda_info(C_heaptop,7,"(a2382)");
lf[141]=C_static_lambda_info(C_heaptop,7,"(a2403)");
lf[142]=C_static_lambda_info(C_heaptop,7,"(a2415)");
lf[143]=C_static_lambda_info(C_heaptop,23,"(a2421 cars254 cdrs255)");
lf[144]=C_static_lambda_info(C_heaptop,17,"(a2409 a252 d253)");
lf[145]=C_static_lambda_info(C_heaptop,30,"(a2388 list250 other-lists251)");
lf[146]=C_static_lambda_info(C_heaptop,16,"(recur lists249)");
lf[147]=C_static_lambda_info(C_heaptop,16,"(a2364 abort247)");
lf[148]=C_static_lambda_info(C_heaptop,28,"(##srfi1#cars+cdrs lists246)");
lf[149]=C_h_intern(&lf[149],5,"count");
lf[150]=C_static_lambda_info(C_heaptop,7,"(a2611)");
lf[151]=C_static_lambda_info(C_heaptop,19,"(a2617 as286 ds287)");
lf[152]=C_static_lambda_info(C_heaptop,27,"(lp list1283 lists284 i285)");
lf[153]=C_static_lambda_info(C_heaptop,16,"(lp lis290 i291)");
lf[154]=C_static_lambda_info(C_heaptop,35,"(count pred279 list1280 . lists281)");
lf[155]=C_h_intern(&lf[155],12,"unfold-right");
lf[156]=C_static_lambda_info(C_heaptop,19,"(lp seed299 ans300)");
lf[157]=C_static_lambda_info(C_heaptop,53,"(unfold-right p293 f294 g295 seed296 . maybe-tail297)");
lf[158]=C_h_intern(&lf[158],6,"unfold");
lf[159]=C_h_intern(&lf[159],5,"error");
lf[160]=C_static_string(C_heaptop,18,"Too many arguments");
lf[161]=C_static_lambda_info(C_heaptop,15,"(recur seed311)");
lf[162]=C_static_lambda_info(C_heaptop,15,"(recur seed314)");
lf[163]=C_static_lambda_info(C_heaptop,51,"(unfold p304 f305 g306 seed307 . maybe-tail-gen308)");
lf[164]=C_h_intern(&lf[164],4,"fold");
lf[165]=C_static_lambda_info(C_heaptop,7,"(a2462)");
lf[166]=C_static_lambda_info(C_heaptop,7,"(a2483)");
lf[167]=C_static_lambda_info(C_heaptop,7,"(a2495)");
lf[168]=C_static_lambda_info(C_heaptop,23,"(a2501 cars266 cdrs267)");
lf[169]=C_static_lambda_info(C_heaptop,17,"(a2489 a264 d265)");
lf[170]=C_static_lambda_info(C_heaptop,30,"(a2468 list262 other-lists263)");
lf[171]=C_static_lambda_info(C_heaptop,16,"(recur lists261)");
lf[172]=C_static_lambda_info(C_heaptop,16,"(a2444 abort259)");
lf[173]=C_static_lambda_info(C_heaptop,7,"(a2824)");
lf[174]=C_static_lambda_info(C_heaptop,27,"(a2830 cars+ans323 cdrs324)");
lf[175]=C_static_lambda_info(C_heaptop,20,"(lp lists321 ans322)");
lf[176]=C_static_lambda_info(C_heaptop,18,"(lp lis327 ans328)");
lf[177]=C_static_lambda_info(C_heaptop,41,"(fold kons316 knil317 lis1318 . lists319)");
lf[178]=C_h_intern(&lf[178],10,"fold-right");
lf[179]=C_h_intern(&lf[179],4,"caar");
lf[180]=C_static_lambda_info(C_heaptop,16,"(recur lists244)");
lf[181]=C_static_lambda_info(C_heaptop,16,"(recur lists335)");
lf[182]=C_static_lambda_info(C_heaptop,14,"(recur lis339)");
lf[183]=C_static_lambda_info(C_heaptop,47,"(fold-right kons330 knil331 lis1332 . lists333)");
lf[184]=C_h_intern(&lf[184],15,"pair-fold-right");
lf[185]=C_static_lambda_info(C_heaptop,16,"(recur lists347)");
lf[186]=C_static_lambda_info(C_heaptop,14,"(recur lis351)");
lf[187]=C_static_lambda_info(C_heaptop,49,"(pair-fold-right f342 zero343 lis1344 . lists345)");
lf[188]=C_h_intern(&lf[188],9,"pair-fold");
lf[189]=C_static_lambda_info(C_heaptop,20,"(lp lists358 ans359)");
lf[190]=C_static_lambda_info(C_heaptop,18,"(lp lis363 ans364)");
lf[191]=C_static_lambda_info(C_heaptop,43,"(pair-fold f353 zero354 lis1355 . lists356)");
lf[192]=C_h_intern(&lf[192],6,"reduce");
lf[193]=C_static_lambda_info(C_heaptop,33,"(reduce f367 ridentity368 lis369)");
lf[194]=C_static_lambda_info(C_heaptop,22,"(recur head374 lis375)");
lf[195]=C_static_lambda_info(C_heaptop,39,"(reduce-right f370 ridentity371 lis372)");
lf[196]=C_h_intern(&lf[196],10,"append-map");
lf[198]=C_static_lambda_info(C_heaptop,36,"(append-map f377 lis1378 . lists379)");
lf[199]=C_h_intern(&lf[199],11,"append-map!");
lf[200]=C_static_lambda_info(C_heaptop,37,"(append-map! f380 lis1381 . lists382)");
lf[201]=C_static_lambda_info(C_heaptop,7,"(a3157)");
lf[202]=C_static_lambda_info(C_heaptop,7,"(a3188)");
lf[203]=C_static_lambda_info(C_heaptop,25,"(a3194 cars2394 cdrs2395)");
lf[204]=C_static_lambda_info(C_heaptop,23,"(recur cars391 cdrs392)");
lf[205]=C_static_lambda_info(C_heaptop,23,"(a3167 cars388 cdrs389)");
lf[206]=C_static_lambda_info(C_heaptop,22,"(recur elt398 rest399)");
lf[207]=C_static_lambda_info(C_heaptop,61,"(##srfi1#really-append-map appender384 f385 lis1386 lists387)");
lf[208]=C_h_intern(&lf[208],13,"pair-for-each");
lf[209]=C_static_lambda_info(C_heaptop,13,"(lp lists406)");
lf[210]=C_static_lambda_info(C_heaptop,11,"(lp lis411)");
lf[211]=C_static_lambda_info(C_heaptop,42,"(pair-for-each proc402 lis1403 . lists404)");
lf[212]=C_h_intern(&lf[212],4,"map!");
lf[213]=C_static_lambda_info(C_heaptop,7,"(a2540)");
lf[214]=C_static_lambda_info(C_heaptop,7,"(a2552)");
lf[215]=C_static_lambda_info(C_heaptop,7,"(a2564)");
lf[216]=C_static_lambda_info(C_heaptop,23,"(a2570 cars276 cdrs277)");
lf[217]=C_static_lambda_info(C_heaptop,17,"(a2558 a274 d275)");
lf[218]=C_static_lambda_info(C_heaptop,30,"(a2546 list272 other-lists273)");
lf[219]=C_static_lambda_info(C_heaptop,16,"(recur lists271)");
lf[220]=C_static_lambda_info(C_heaptop,7,"(a3337)");
lf[221]=C_static_lambda_info(C_heaptop,25,"(a3343 heads421 tails422)");
lf[222]=C_static_lambda_info(C_heaptop,21,"(lp lis1419 lists420)");
lf[223]=C_static_lambda_info(C_heaptop,15,"(a3371 pair425)");
lf[224]=C_static_lambda_info(C_heaptop,30,"(map! f415 lis1416 . lists417)");
lf[225]=C_h_intern(&lf[225],10,"filter-map");
lf[226]=C_static_lambda_info(C_heaptop,7,"(a3407)");
lf[227]=C_static_lambda_info(C_heaptop,23,"(a3413 cars432 cdrs433)");
lf[228]=C_static_lambda_info(C_heaptop,16,"(recur lists431)");
lf[229]=C_static_lambda_info(C_heaptop,14,"(recur lis439)");
lf[230]=C_static_lambda_info(C_heaptop,36,"(filter-map f427 lis1428 . lists429)");
lf[231]=C_h_intern(&lf[231],12,"map-in-order");
lf[232]=C_static_lambda_info(C_heaptop,7,"(a3492)");
lf[233]=C_static_lambda_info(C_heaptop,23,"(a3498 cars450 cdrs451)");
lf[234]=C_static_lambda_info(C_heaptop,16,"(recur lists449)");
lf[235]=C_static_lambda_info(C_heaptop,14,"(recur lis455)");
lf[236]=C_static_lambda_info(C_heaptop,38,"(map-in-order f445 lis1446 . lists447)");
lf[237]=C_h_intern(&lf[237],6,"filter");
lf[238]=C_static_lambda_info(C_heaptop,14,"(recur lis462)");
lf[239]=C_static_lambda_info(C_heaptop,23,"(filter pred459 lis460)");
lf[240]=C_h_intern(&lf[240],7,"filter!");
lf[241]=C_static_lambda_info(C_heaptop,24,"(scan-in prev473 lis474)");
lf[242]=C_static_lambda_info(C_heaptop,11,"(lp lis478)");
lf[243]=C_static_lambda_info(C_heaptop,25,"(scan-out prev475 lis476)");
lf[244]=C_static_lambda_info(C_heaptop,11,"(lp ans470)");
lf[245]=C_static_lambda_info(C_heaptop,24,"(filter! pred467 lis468)");
lf[246]=C_h_intern(&lf[246],9,"partition");
lf[247]=C_static_lambda_info(C_heaptop,7,"(a3737)");
lf[248]=C_static_lambda_info(C_heaptop,20,"(a3743 in491 out492)");
lf[249]=C_static_lambda_info(C_heaptop,14,"(recur lis488)");
lf[250]=C_static_lambda_info(C_heaptop,26,"(partition pred485 lis486)");
lf[251]=C_h_intern(&lf[251],10,"partition!");
lf[252]=C_static_lambda_info(C_heaptop,22,"(lp in-prev502 lis503)");
lf[253]=C_static_lambda_info(C_heaptop,39,"(scan-in in-prev498 out-prev499 lis500)");
lf[254]=C_static_lambda_info(C_heaptop,23,"(lp out-prev510 lis511)");
lf[255]=C_static_lambda_info(C_heaptop,40,"(scan-out in-prev506 out-prev507 lis508)");
lf[256]=C_static_lambda_info(C_heaptop,19,"(lp prev-l515 l516)");
lf[257]=C_static_lambda_info(C_heaptop,19,"(lp prev-l520 l521)");
lf[258]=C_static_lambda_info(C_heaptop,27,"(partition! pred494 lis495)");
lf[259]=C_h_intern(&lf[259],6,"remove");
lf[260]=C_static_lambda_info(C_heaptop,12,"(a3996 x528)");
lf[261]=C_static_lambda_info(C_heaptop,21,"(remove pred526 l527)");
lf[262]=C_h_intern(&lf[262],7,"remove!");
lf[263]=C_static_lambda_info(C_heaptop,12,"(a4012 x531)");
lf[264]=C_static_lambda_info(C_heaptop,22,"(remove! pred529 l530)");
lf[265]=C_h_intern(&lf[265],6,"delete");
lf[266]=C_h_intern(&lf[266],6,"equal\077");
lf[267]=C_static_lambda_info(C_heaptop,12,"(a4031 y538)");
lf[268]=C_static_lambda_info(C_heaptop,33,"(delete x532 lis533 . maybe-=534)");
lf[269]=C_h_intern(&lf[269],7,"delete!");
lf[270]=C_static_lambda_info(C_heaptop,12,"(a4056 y545)");
lf[271]=C_static_lambda_info(C_heaptop,34,"(delete! x539 lis540 . maybe-=541)");
lf[272]=C_h_intern(&lf[272],6,"member");
lf[273]=C_static_lambda_info(C_heaptop,12,"(a4081 y552)");
lf[274]=C_h_intern(&lf[274],9,"find-tail");
lf[275]=C_static_lambda_info(C_heaptop,33,"(member x546 lis547 . maybe-=548)");
lf[276]=C_h_intern(&lf[276],17,"delete-duplicates");
lf[277]=C_static_lambda_info(C_heaptop,14,"(recur lis559)");
lf[278]=C_static_lambda_info(C_heaptop,39,"(delete-duplicates lis553 . maybe-=554)");
lf[279]=C_h_intern(&lf[279],18,"delete-duplicates!");
lf[280]=C_static_lambda_info(C_heaptop,14,"(recur lis570)");
lf[281]=C_static_lambda_info(C_heaptop,40,"(delete-duplicates! lis564 . maybe-=565)");
lf[282]=C_h_intern(&lf[282],5,"assoc");
lf[283]=C_static_lambda_info(C_heaptop,16,"(a4194 entry581)");
lf[284]=C_h_intern(&lf[284],4,"find");
lf[285]=C_static_lambda_info(C_heaptop,32,"(assoc x575 lis576 . maybe-=577)");
lf[286]=C_h_intern(&lf[286],10,"alist-cons");
lf[287]=C_static_lambda_info(C_heaptop,37,"(alist-cons key582 datum583 alist584)");
lf[288]=C_h_intern(&lf[288],10,"alist-copy");
lf[289]=C_static_lambda_info(C_heaptop,14,"(a4226 elt586)");
lf[290]=C_static_lambda_info(C_heaptop,21,"(alist-copy alist585)");
lf[291]=C_h_intern(&lf[291],12,"alist-delete");
lf[292]=C_static_lambda_info(C_heaptop,14,"(a4249 elt593)");
lf[293]=C_static_lambda_info(C_heaptop,43,"(alist-delete key587 alist588 . maybe-=589)");
lf[294]=C_h_intern(&lf[294],13,"alist-delete!");
lf[295]=C_static_lambda_info(C_heaptop,14,"(a4278 elt600)");
lf[296]=C_static_lambda_info(C_heaptop,44,"(alist-delete! key594 alist595 . maybe-=596)");
lf[297]=C_static_lambda_info(C_heaptop,22,"(find pred601 list602)");
lf[298]=C_static_lambda_info(C_heaptop,12,"(lp list608)");
lf[299]=C_static_lambda_info(C_heaptop,27,"(find-tail pred605 list606)");
lf[300]=C_h_intern(&lf[300],10,"take-while");
lf[301]=C_static_lambda_info(C_heaptop,14,"(recur lis613)");
lf[302]=C_static_lambda_info(C_heaptop,27,"(take-while pred610 lis611)");
lf[303]=C_h_intern(&lf[303],10,"drop-while");
lf[304]=C_static_lambda_info(C_heaptop,11,"(lp lis619)");
lf[305]=C_static_lambda_info(C_heaptop,27,"(drop-while pred616 lis617)");
lf[306]=C_h_intern(&lf[306],11,"take-while!");
lf[307]=C_static_lambda_info(C_heaptop,20,"(lp prev626 rest627)");
lf[308]=C_static_lambda_info(C_heaptop,28,"(take-while! pred621 lis622)");
lf[309]=C_h_intern(&lf[309],4,"span");
lf[310]=C_static_lambda_info(C_heaptop,7,"(a4501)");
lf[311]=C_static_lambda_info(C_heaptop,27,"(a4511 prefix636 suffix637)");
lf[312]=C_static_lambda_info(C_heaptop,14,"(recur lis634)");
lf[313]=C_static_lambda_info(C_heaptop,21,"(span pred631 lis632)");
lf[314]=C_h_intern(&lf[314],5,"span!");
lf[315]=C_static_lambda_info(C_heaptop,20,"(lp prev645 rest646)");
lf[316]=C_static_lambda_info(C_heaptop,22,"(span! pred639 lis640)");
lf[317]=C_h_intern(&lf[317],5,"break");
lf[318]=C_static_lambda_info(C_heaptop,12,"(a4594 x652)");
lf[319]=C_static_lambda_info(C_heaptop,22,"(break pred650 lis651)");
lf[320]=C_h_intern(&lf[320],6,"break!");
lf[321]=C_static_lambda_info(C_heaptop,12,"(a4610 x655)");
lf[322]=C_static_lambda_info(C_heaptop,23,"(break! pred653 lis654)");
lf[323]=C_h_intern(&lf[323],3,"any");
lf[324]=C_static_lambda_info(C_heaptop,7,"(a4632)");
lf[325]=C_static_lambda_info(C_heaptop,7,"(a4660)");
lf[326]=C_static_lambda_info(C_heaptop,35,"(a4666 next-heads664 next-tails665)");
lf[327]=C_static_lambda_info(C_heaptop,22,"(lp heads662 tails663)");
lf[328]=C_static_lambda_info(C_heaptop,25,"(a4642 heads659 tails660)");
lf[329]=C_static_lambda_info(C_heaptop,20,"(lp head670 tail671)");
lf[330]=C_static_lambda_info(C_heaptop,32,"(any pred656 lis1657 . lists658)");
lf[331]=C_h_intern(&lf[331],5,"every");
lf[332]=C_static_lambda_info(C_heaptop,7,"(a4749)");
lf[333]=C_static_lambda_info(C_heaptop,7,"(a4777)");
lf[334]=C_static_lambda_info(C_heaptop,35,"(a4783 next-heads685 next-tails686)");
lf[335]=C_static_lambda_info(C_heaptop,22,"(lp heads683 tails684)");
lf[336]=C_static_lambda_info(C_heaptop,25,"(a4759 heads678 tails679)");
lf[337]=C_static_lambda_info(C_heaptop,20,"(lp head691 tail692)");
lf[338]=C_static_lambda_info(C_heaptop,34,"(every pred675 lis1676 . lists677)");
lf[339]=C_h_intern(&lf[339],10,"list-index");
lf[340]=C_static_lambda_info(C_heaptop,7,"(a4876)");
lf[341]=C_static_lambda_info(C_heaptop,25,"(a4882 heads700 tails701)");
lf[342]=C_static_lambda_info(C_heaptop,18,"(lp lists698 n699)");
lf[343]=C_static_lambda_info(C_heaptop,16,"(lp lis704 n705)");
lf[344]=C_static_lambda_info(C_heaptop,39,"(list-index pred694 lis1695 . lists696)");
lf[345]=C_h_intern(&lf[345],8,"reverse!");
lf[346]=C_static_lambda_info(C_heaptop,11,"(lp ans710)");
lf[347]=C_static_lambda_info(C_heaptop,17,"(reverse! lis707)");
lf[349]=C_static_lambda_info(C_heaptop,12,"(a4971 x717)");
lf[350]=C_static_lambda_info(C_heaptop,38,"(##srfi1#lset2<= =714 lis1715 lis2716)");
lf[351]=C_h_intern(&lf[351],6,"lset<=");
lf[352]=C_static_lambda_info(C_heaptop,18,"(lp s1723 rest724)");
lf[353]=C_static_lambda_info(C_heaptop,24,"(lset<= =718 . lists719)");
lf[354]=C_h_intern(&lf[354],5,"lset=");
lf[355]=C_static_lambda_info(C_heaptop,18,"(lp s1737 rest738)");
lf[356]=C_static_lambda_info(C_heaptop,23,"(lset= =732 . lists733)");
lf[357]=C_h_intern(&lf[357],11,"lset-adjoin");
lf[358]=C_static_lambda_info(C_heaptop,21,"(a5105 elt749 ans750)");
lf[359]=C_static_lambda_info(C_heaptop,35,"(lset-adjoin =746 lis747 . elts748)");
lf[360]=C_h_intern(&lf[360],10,"lset-union");
lf[361]=C_static_lambda_info(C_heaptop,12,"(a5159 x757)");
lf[362]=C_static_lambda_info(C_heaptop,21,"(a5147 elt755 ans756)");
lf[363]=C_static_lambda_info(C_heaptop,21,"(a5123 lis753 ans754)");
lf[364]=C_static_lambda_info(C_heaptop,28,"(lset-union =751 . lists752)");
lf[365]=C_h_intern(&lf[365],11,"lset-union!");
lf[366]=C_static_lambda_info(C_heaptop,12,"(a5210 x765)");
lf[367]=C_static_lambda_info(C_heaptop,22,"(a5195 pair762 ans763)");
lf[368]=C_static_lambda_info(C_heaptop,21,"(a5171 lis760 ans761)");
lf[369]=C_static_lambda_info(C_heaptop,29,"(lset-union! =758 . lists759)");
lf[370]=C_h_intern(&lf[370],17,"lset-intersection");
lf[371]=C_static_lambda_info(C_heaptop,14,"(a5243 lis772)");
lf[372]=C_static_lambda_info(C_heaptop,12,"(a5237 x771)");
lf[373]=C_h_intern(&lf[373],3,"eq\077");
lf[374]=C_static_lambda_info(C_heaptop,43,"(lset-intersection =767 lis1768 . lists769)");
lf[375]=C_h_intern(&lf[375],18,"lset-intersection!");
lf[376]=C_static_lambda_info(C_heaptop,14,"(a5276 lis778)");
lf[377]=C_static_lambda_info(C_heaptop,12,"(a5270 x777)");
lf[378]=C_static_lambda_info(C_heaptop,44,"(lset-intersection! =773 lis1774 . lists775)");
lf[379]=C_h_intern(&lf[379],15,"lset-difference");
lf[380]=C_static_lambda_info(C_heaptop,14,"(a5309 lis784)");
lf[381]=C_static_lambda_info(C_heaptop,12,"(a5303 x783)");
lf[382]=C_h_intern(&lf[382],5,"pair\077");
lf[383]=C_static_lambda_info(C_heaptop,41,"(lset-difference =779 lis1780 . lists781)");
lf[384]=C_h_intern(&lf[384],16,"lset-difference!");
lf[385]=C_static_lambda_info(C_heaptop,14,"(a5346 lis790)");
lf[386]=C_static_lambda_info(C_heaptop,12,"(a5340 x789)");
lf[387]=C_static_lambda_info(C_heaptop,42,"(lset-difference! =785 lis1786 . lists787)");
lf[388]=C_h_intern(&lf[388],8,"lset-xor");
lf[389]=C_h_intern(&lf[389],22,"lset-diff+intersection");
lf[390]=C_static_lambda_info(C_heaptop,7,"(a5368)");
lf[391]=C_static_lambda_info(C_heaptop,20,"(a5398 xb797 ans798)");
lf[392]=C_static_lambda_info(C_heaptop,25,"(a5374 a-b795 a-int-b796)");
lf[393]=C_static_lambda_info(C_heaptop,17,"(a5362 b793 a794)");
lf[394]=C_static_lambda_info(C_heaptop,26,"(lset-xor =791 . lists792)");
lf[395]=C_h_intern(&lf[395],9,"lset-xor!");
lf[396]=C_h_intern(&lf[396],23,"lset-diff+intersection!");
lf[397]=C_static_lambda_info(C_heaptop,7,"(a5422)");
lf[398]=C_static_lambda_info(C_heaptop,24,"(a5452 b-pair805 ans806)");
lf[399]=C_static_lambda_info(C_heaptop,25,"(a5428 a-b803 a-int-b804)");
lf[400]=C_static_lambda_info(C_heaptop,17,"(a5416 b801 a802)");
lf[401]=C_static_lambda_info(C_heaptop,27,"(lset-xor! =799 . lists800)");
lf[402]=C_static_lambda_info(C_heaptop,14,"(a5502 lis812)");
lf[403]=C_static_lambda_info(C_heaptop,14,"(a5492 elt811)");
lf[404]=C_static_lambda_info(C_heaptop,48,"(lset-diff+intersection =808 lis1809 . lists810)");
lf[405]=C_static_lambda_info(C_heaptop,14,"(a5542 lis817)");
lf[406]=C_static_lambda_info(C_heaptop,14,"(a5532 elt816)");
lf[407]=C_static_lambda_info(C_heaptop,49,"(lset-diff+intersection! =813 lis1814 . lists815)");
lf[408]=C_h_intern(&lf[408],17,"register-feature!");
lf[409]=C_h_intern(&lf[409],6,"srfi-1");
lf[410]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,411);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[408]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[409]);}

/* k933 */
static void f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[306],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_937,a[2]=lf[1],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=lf[6],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=lf[9],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=lf[15],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=lf[22],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[23]+1,*((C_word*)lf[24]+1));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=lf[27],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1252,a[2]=lf[30],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=lf[32],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=lf[34],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=lf[45],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[46]+1,*((C_word*)lf[47]+1));
t18=C_mutate((C_word*)lf[48]+1,*((C_word*)lf[49]+1));
t19=C_mutate((C_word*)lf[50]+1,*((C_word*)lf[51]+1));
t20=C_mutate((C_word*)lf[52]+1,*((C_word*)lf[53]+1));
t21=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=lf[59],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=lf[61],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1496,a[2]=lf[63],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1510,a[2]=lf[65],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=lf[73],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=lf[81],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=lf[89],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=lf[91],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1823,a[2]=lf[93],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=lf[95],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=lf[98],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=lf[103],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=lf[113],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=lf[118],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=lf[122],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2212,a[2]=lf[125],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=lf[128],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=lf[132],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=lf[134],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate(&lf[135],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=lf[138],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate(&lf[139],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=lf[148],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2588,a[2]=lf[154],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=lf[177],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=lf[183],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=lf[187],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=lf[191],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=lf[195],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3134,a[2]=lf[198],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3140,a[2]=lf[200],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate(&lf[197],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=lf[207],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3255,a[2]=lf[211],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=lf[224],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=lf[230],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3471,a[2]=lf[236],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[43]+1,*((C_word*)lf[231]+1));
t67=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3548,a[2]=lf[239],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3590,a[2]=lf[245],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3711,a[2]=lf[250],tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3779,a[2]=lf[258],tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3991,a[2]=lf[261],tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=lf[264],tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=lf[268],tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=lf[271],tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=lf[275],tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=lf[278],tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4140,a[2]=lf[281],tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4186,a[2]=lf[285],tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[286]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4211,a[2]=lf[287],tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4221,a[2]=lf[290],tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[291]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4241,a[2]=lf[293],tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4270,a[2]=lf[296],tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=lf[297],tmp=(C_word)a,a+=3,tmp));
t84=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=lf[299],tmp=(C_word)a,a+=3,tmp));
t85=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4347,a[2]=lf[302],tmp=(C_word)a,a+=3,tmp));
t86=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4382,a[2]=lf[305],tmp=(C_word)a,a+=3,tmp));
t87=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4414,a[2]=lf[308],tmp=(C_word)a,a+=3,tmp));
t88=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=lf[313],tmp=(C_word)a,a+=3,tmp));
t89=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=lf[316],tmp=(C_word)a,a+=3,tmp));
t90=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=lf[319],tmp=(C_word)a,a+=3,tmp));
t91=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=lf[322],tmp=(C_word)a,a+=3,tmp));
t92=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4621,a[2]=lf[330],tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4738,a[2]=lf[338],tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=lf[344],tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4942,a[2]=lf[347],tmp=(C_word)a,a+=3,tmp));
t96=C_mutate(&lf[348],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4966,a[2]=lf[350],tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=lf[353],tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5036,a[2]=lf[356],tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[357]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=lf[359],tmp=(C_word)a,a+=3,tmp));
t100=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5118,a[2]=lf[364],tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5166,a[2]=lf[369],tmp=(C_word)a,a+=3,tmp));
t102=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5217,a[2]=lf[374],tmp=(C_word)a,a+=3,tmp));
t103=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5250,a[2]=lf[378],tmp=(C_word)a,a+=3,tmp));
t104=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5283,a[2]=lf[383],tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=lf[387],tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5357,a[2]=lf[394],tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=lf[401],tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=lf[404],tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[396]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=lf[407],tmp=(C_word)a,a+=3,tmp));
t110=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t110+1)))(2,t110,C_SCHEME_UNDEFINED);}

/* lset-diff+intersection! in k933 */
static void f_5509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5509r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5509r(t0,t1,t2,t3,t4);}}

static void f_5509r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5516,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,*((C_word*)lf[33]+1),t4);}

/* k5514 in lset-diff+intersection! in k933 */
static void f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
if(C_truep(t1)){
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[406],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[251]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a5532 in k5514 in lset-diff+intersection! in k933 */
static void f_5533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5533,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[405],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5542 in a5532 in k5514 in lset-diff+intersection! in k933 */
static void f_5543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5543,3,t0,t1,t2);}
t3=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5539 in a5532 in k5514 in lset-diff+intersection! in k933 */
static void f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-diff+intersection in k933 */
static void f_5469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5469r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5469r(t0,t1,t2,t3,t4);}}

static void f_5469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5476,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,*((C_word*)lf[33]+1),t4);}

/* k5474 in lset-diff+intersection in k933 */
static void f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
if(C_truep(t1)){
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[403],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[246]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a5492 in k5474 in lset-diff+intersection in k933 */
static void f_5493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5493,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[402],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5502 in a5492 in k5474 in lset-diff+intersection in k933 */
static void f_5503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5503,3,t0,t1,t2);}
t3=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5499 in a5492 in k5474 in lset-diff+intersection in k933 */
static void f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-xor! in k933 */
static void f_5411(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5411r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5411r(t0,t1,t2,t3);}}

static void f_5411r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t2,a[3]=lf[400],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[192]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5416 in lset-xor! in k933 */
static void f_5417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5417,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5423,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[397],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5429,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=lf[399],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a5428 in a5416 in lset-xor! in k933 */
static void f_5429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5429,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=*((C_word*)lf[384]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=*((C_word*)lf[119]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=lf[398],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[188]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a5452 in a5428 in a5416 in lset-xor! in k933 */
static void f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5453,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5460,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5458 in a5452 in a5428 in a5416 in lset-xor! in k933 */
static void f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* a5422 in a5416 in lset-xor! in k933 */
static void f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=*((C_word*)lf[396]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-xor in k933 */
static void f_5357(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5357r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5357r(t0,t1,t2,t3);}}

static void f_5357r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5363,a[2]=t2,a[3]=lf[393],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[192]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5362 in lset-xor in k933 */
static void f_5363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5363,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5369,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[390],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5375,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=lf[392],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a5374 in a5362 in lset-xor in k933 */
static void f_5375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5375,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=*((C_word*)lf[379]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=lf[391],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[164]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a5398 in a5374 in a5362 in lset-xor in k933 */
static void f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5399,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5406,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5404 in a5398 in a5374 in a5362 in lset-xor in k933 */
static void f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* a5368 in a5362 in lset-xor in k933 */
static void f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=*((C_word*)lf[389]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-difference! in k933 */
static void f_5320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5320r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5320r(t0,t1,t2,t3,t4);}}

static void f_5320r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5324,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,*((C_word*)lf[382]+1),t4);}

/* k5322 in lset-difference! in k933 */
static void f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5341,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[386],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}}}

/* a5340 in k5322 in lset-difference! in k933 */
static void f_5341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5341,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[385],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5346 in a5340 in k5322 in lset-difference! in k933 */
static void f_5347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5347,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5355,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5353 in a5346 in a5340 in k5322 in lset-difference! in k933 */
static void f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-difference in k933 */
static void f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5283r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5283r(t0,t1,t2,t3,t4);}}

static void f_5283r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5287,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,*((C_word*)lf[382]+1),t4);}

/* k5285 in lset-difference in k933 */
static void f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5287,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5304,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[381],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}}}

/* a5303 in k5285 in lset-difference in k933 */
static void f_5304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[380],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5309 in a5303 in k5285 in lset-difference in k933 */
static void f_5310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5318,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5316 in a5309 in a5303 in k5285 in lset-difference in k933 */
static void f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-intersection! in k933 */
static void f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5250r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5250r(t0,t1,t2,t3,t4);}}

static void f_5250r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5254,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[265]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t3,t4,*((C_word*)lf[373]+1));}

/* k5252 in lset-intersection! in k933 */
static void f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,*((C_word*)lf[33]+1),t1);}

/* k5258 in k5252 in lset-intersection! in k933 */
static void f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=lf[377],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a5270 in k5258 in k5252 in lset-intersection! in k933 */
static void f_5271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[376],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5276 in a5270 in k5258 in k5252 in lset-intersection! in k933 */
static void f_5277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5277,3,t0,t1,t2);}
t3=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-intersection in k933 */
static void f_5217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5217r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5217r(t0,t1,t2,t3,t4);}}

static void f_5217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5221,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[265]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t3,t4,*((C_word*)lf[373]+1));}

/* k5219 in lset-intersection in k933 */
static void f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,*((C_word*)lf[33]+1),t1);}

/* k5225 in k5219 in lset-intersection in k933 */
static void f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5227,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=lf[372],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a5237 in k5225 in k5219 in lset-intersection in k933 */
static void f_5238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[371],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5243 in a5237 in k5225 in k5219 in lset-intersection in k933 */
static void f_5244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5244,3,t0,t1,t2);}
t3=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-union! in k933 */
static void f_5166(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5166r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5166r(t0,t1,t2,t3);}}

static void f_5166r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=t2,a[3]=lf[368],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[192]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5171 in lset-union! in k933 */
static void f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5172,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5196,a[2]=((C_word*)t0)[2],a[3]=lf[367],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[188]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,t3,t2);}}}}

/* a5195 in a5171 in lset-union! in k933 */
static void f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5196,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5206,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5211,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=lf[366],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t3);}

/* a5210 in a5195 in a5171 in lset-union! in k933 */
static void f_5211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5211,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5204 in a5195 in a5171 in lset-union! in k933 */
static void f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* lset-union in k933 */
static void f_5118(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5118r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5118r(t0,t1,t2,t3);}}

static void f_5118r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5124,a[2]=t2,a[3]=lf[363],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[192]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5123 in lset-union in k933 */
static void f_5124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5124,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=lf[362],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[164]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,t3,t2);}}}}

/* a5147 in a5123 in lset-union in k933 */
static void f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5148,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5155,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5160,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[361],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[323]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t3);}

/* a5159 in a5147 in a5123 in lset-union in k933 */
static void f_5160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5160,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5153 in a5147 in a5123 in lset-union in k933 */
static void f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* lset-adjoin in k933 */
static void f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5100r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5100r(t0,t1,t2,t3,t4);}}

static void f_5100r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t2,a[3]=lf[358],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[164]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,t3,t4);}

/* a5105 in lset-adjoin in k933 */
static void f_5106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5106,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5113,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t2,t3,((C_word*)t0)[2]);}

/* k5111 in a5105 in lset-adjoin in k933 */
static void f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* lset= in k933 */
static void f_5036(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5036r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5036r(t0,t1,t2,t3);}}

static void f_5036r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5056,a[2]=t2,a[3]=t9,a[4]=lf[355],tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5056(t11,t1,t6,t7);}}

/* lp in lset= in k933 */
static void C_fcall f_5056(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5056,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(C_word)C_eqp(t2,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5078,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_5078(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5087,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
f_4966(t10,((C_word*)t0)[2],t2,t6);}}}

/* k5085 in lp in lset= in k933 */
static void f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
f_4966(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_5078(2,t2,C_SCHEME_FALSE);}}

/* k5076 in lp in lset= in k933 */
static void f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
f_5056(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lset<= in k933 */
static void f_4978(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4978r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4978r(t0,t1,t2,t3);}}

static void f_4978r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4998,a[2]=t2,a[3]=t9,a[4]=lf[352],tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4998(t11,t1,t6,t7);}}

/* lp in lset<= in k933 */
static void C_fcall f_4998(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4998,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(C_word)C_eqp(t6,t2);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5020,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_5020(2,t10,t8);}
else{
f_4966(t9,((C_word*)t0)[2],t2,t6);}}}

/* k5018 in lp in lset<= in k933 */
static void f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
f_4998(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##srfi1#lset2<= in k933 */
static void C_fcall f_4966(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4966,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4972,a[2]=t2,a[3]=t4,a[4]=lf[349],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[331]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t3);}

/* a4971 in ##srfi1#lset2<= in k933 */
static void f_4972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4972,3,t0,t1,t2);}
t3=*((C_word*)lf[272]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* reverse! in k933 */
static void f_4942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4948,a[2]=lf[346],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_4948(t2,C_SCHEME_END_OF_LIST));}

/* lp in reverse! in k933 */
static C_word C_fcall f_4948(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_null_list_p(t1))){
return(t2);}
else{
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_set_cdr(t1,t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}

/* list-index in k933 */
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_4855r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4855r(t0,t1,t2,t3,t4);}}

static void f_4855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4871,a[2]=t2,a[3]=t7,a[4]=lf[342],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4871(t9,t1,t5,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4908,a[2]=t2,a[3]=t6,a[4]=lf[343],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4908(t8,t1,t3,C_fix(0));}}

/* lp in list-index in k933 */
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4908,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k4919 in lp in list-index in k933 */
static void f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_4908(t4,((C_word*)t0)[5],t2,t3);}}

/* lp in list-index in k933 */
static void C_fcall f_4871(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4871,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=t2,a[3]=lf[340],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=lf[341],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a4882 in lp in list-index in k933 */
static void f_4883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4883,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4896,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4894 in a4882 in lp in list-index in k933 */
static void f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4871(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* a4876 in lp in list-index in k933 */
static void f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* every in k933 */
static void f_4738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4738r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4738r(t0,t1,t2,t3,t4);}}

static void f_4738r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4750,a[2]=t4,a[3]=t3,a[4]=lf[332],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=t2,a[3]=lf[336],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=(C_word)C_i_null_list_p(t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4826,a[2]=t9,a[3]=t2,a[4]=lf[337],tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4826(t11,t1,t6,t7);}}}

/* lp in every in k933 */
static void C_fcall f_4826(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4826,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k4840 in lp in every in k933 */
static void f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4826(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4759 in every in k933 */
static void f_4760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4760,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=lf[335],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4772(t9,t1,t2,t3);}}

/* lp in a4759 in every in k933 */
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4772,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4778,a[2]=t3,a[3]=lf[333],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4784,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[334],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a4783 in lp in a4759 in every in k933 */
static void f_4784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4784,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4797,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4795 in a4783 in lp in a4759 in every in k933 */
static void f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
f_4772(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4777 in lp in a4759 in every in k933 */
static void f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* a4749 in every in k933 */
static void f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
f_2359(t1,t2);}

/* any in k933 */
static void f_4621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4621r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4621r(t0,t1,t2,t3,t4);}}

static void f_4621r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=t4,a[3]=t3,a[4]=lf[324],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4643,a[2]=t2,a[3]=lf[328],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t5,t6);}
else{
if(C_truep((C_word)C_i_null_list_p(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_cdr(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4705,a[2]=t8,a[3]=t2,a[4]=lf[329],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4705(t10,t1,t5,t6);}}}

/* lp in any in k933 */
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k4716 in lp in any in k933 */
static void f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_4705(t4,((C_word*)t0)[4],t2,t3);}}

/* a4642 in any in k933 */
static void f_4643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4643,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=lf[327],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4655(t7,t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in a4642 in any in k933 */
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4655,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4661,a[2]=t3,a[3]=lf[325],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4667,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[326],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a4666 in lp in a4642 in any in k933 */
static void f_4667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4667,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4677,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4675 in a4666 in lp in a4642 in any in k933 */
static void f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
f_4655(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a4660 in lp in a4642 in any in k933 */
static void f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* a4632 in any in k933 */
static void f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
f_2359(t1,t2);}

/* break! in k933 */
static void f_4605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4605,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4611,a[2]=t2,a[3]=lf[321],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a4610 in break! in k933 */
static void f_4611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4617 in a4610 in break! in k933 */
static void f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* break in k933 */
static void f_4589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4589,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=t2,a[3]=lf[318],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[309]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a4594 in break in k933 */
static void f_4595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4595,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4603,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4601 in a4594 in break in k933 */
static void f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* span! in k933 */
static void f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4525,4,t0,t1,t2,t3);}
t4=(C_word)C_i_null_list_p(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4535,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4535(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t3);
t8=t2;
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}}

/* k4581 in span! in k933 */
static void f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4535(t2,(C_word)C_i_not(t1));}

/* k4533 in span! in k933 */
static void C_fcall f_4535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4535,NULL,2,t0,t1);}
if(C_truep(t1)){
C_values(4,0,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=lf[315],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4550(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k4533 in span! in k933 */
static void C_fcall f_4550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4550,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4566,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k4564 in lp in k4533 in span! in k933 */
static void f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_4550(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}}

/* k4539 in k4533 in span! in k933 */
static void f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* span in k933 */
static void f_4472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4472,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4478,a[2]=t2,a[3]=t5,a[4]=lf[312],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4478(t7,t1,t3);}

/* recur in span in k933 */
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4478,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4497,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k4495 in recur in span in k933 */
static void f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[310],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=lf[311],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);}}

/* a4511 in k4495 in recur in span in k933 */
static void f_4512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4512,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
C_values(4,0,t1,t4,t3);}

/* a4501 in k4495 in recur in span in k933 */
static void f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_4478(t3,t1,t2);}

/* take-while! in k933 */
static void f_4414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4414,4,t0,t1,t2,t3);}
t4=(C_word)C_i_null_list_p(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4424,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4424(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t3);
t8=t2;
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}}

/* k4464 in take-while! in k933 */
static void f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4424(t2,(C_word)C_i_not(t1));}

/* k4422 in take-while! in k933 */
static void C_fcall f_4424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4424,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=lf[307],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4433(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k4422 in take-while! in k933 */
static void C_fcall f_4433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4433,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4449,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k4447 in lp in k4422 in take-while! in k933 */
static void f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_4433(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}}

/* k4425 in k4422 in take-while! in k933 */
static void f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* drop-while in k933 */
static void f_4382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4382,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=t2,a[3]=t5,a[4]=lf[304],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4388(t7,t1,t3);}

/* lp in drop-while in k933 */
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4401,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4399 in lp in drop-while in k933 */
static void f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4388(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* take-while in k933 */
static void f_4347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4347,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4353,a[2]=t2,a[3]=t5,a[4]=lf[301],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4353(t7,t1,t3);}

/* recur in take-while in k933 */
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4353,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k4367 in recur in take-while in k933 */
static void f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_4353(t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4374 in k4367 in recur in take-while in k933 */
static void f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* find-tail in k933 */
static void f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4311,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=t2,a[3]=t5,a[4]=lf[298],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4317(t7,t1,t3);}

/* lp in find-tail in k933 */
static void C_fcall f_4317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4317,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4328 in lp in find-tail in k933 */
static void f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_4317(t3,((C_word*)t0)[4],t2);}}

/* find in k933 */
static void f_4299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4299,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4303,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[274]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k4301 in find in k933 */
static void f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(t1):C_SCHEME_FALSE));}

/* alist-delete! in k933 */
static void f_4270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4270r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4270r(t0,t1,t2,t3,t4);}}

static void f_4270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4279,a[2]=t2,a[3]=t6,a[4]=lf[295],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4278 in alist-delete! in k933 */
static void f_4279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4279,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4285 in a4278 in alist-delete! in k933 */
static void f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-delete in k933 */
static void f_4241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4241r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4241r(t0,t1,t2,t3,t4);}}

static void f_4241r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=t2,a[3]=t6,a[4]=lf[292],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4249 in alist-delete in k933 */
static void f_4250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4250,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4256 in a4249 in alist-delete in k933 */
static void f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-copy in k933 */
static void f_4221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=lf[289],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4226 in alist-copy in k933 */
static void f_4227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4227,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* alist-cons in k933 */
static void f_4211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4211,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}

/* assoc in k933 */
static void f_4186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4186r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4186r(t0,t1,t2,t3,t4);}}

static void f_4186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4195,a[2]=t2,a[3]=t6,a[4]=lf[283],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4194 in assoc in k933 */
static void f_4195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4195,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* delete-duplicates! in k933 */
static void f_4140(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4140r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4140r(t0,t1,t2,t3);}}

static void f_4140r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4149,a[2]=t5,a[3]=t7,a[4]=lf[280],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4149(t9,t1,t2);}

/* recur in delete-duplicates! in k933 */
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4149,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4165,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[269]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4176 in recur in delete-duplicates! in k933 */
static void f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4149(t2,((C_word*)t0)[2],t1);}

/* k4163 in recur in delete-duplicates! in k933 */
static void f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* delete-duplicates in k933 */
static void f_4094(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4094r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4094r(t0,t1,t2,t3);}}

static void f_4094r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4103,a[2]=t5,a[3]=t7,a[4]=lf[277],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4103(t9,t1,t2);}

/* recur in delete-duplicates in k933 */
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4103,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4119,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[265]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4130 in recur in delete-duplicates in k933 */
static void f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4103(t2,((C_word*)t0)[2],t1);}

/* k4117 in recur in delete-duplicates in k933 */
static void f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* member in k933 */
static void f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4073r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4073r(t0,t1,t2,t3,t4);}}

static void f_4073r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4082,a[2]=t2,a[3]=t6,a[4]=lf[273],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[274]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4081 in member in k933 */
static void f_4082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4082,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* delete! in k933 */
static void f_4048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4048r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4048r(t0,t1,t2,t3,t4);}}

static void f_4048r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=t2,a[3]=t6,a[4]=lf[270],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4056 in delete! in k933 */
static void f_4057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k4063 in a4056 in delete! in k933 */
static void f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* delete in k933 */
static void f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4023r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4023r(t0,t1,t2,t3,t4);}}

static void f_4023r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[266]+1):(C_word)C_i_vector_ref(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4032,a[2]=t2,a[3]=t6,a[4]=lf[267],tmp=(C_word)a,a+=5,tmp);
t8=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,t7,t3);}

/* a4031 in delete in k933 */
static void f_4032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4032,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4040,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k4038 in a4031 in delete in k933 */
static void f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove! in k933 */
static void f_4007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4007,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4013,a[2]=t2,a[3]=lf[263],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a4012 in remove! in k933 */
static void f_4013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4013,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4019 in a4012 in remove! in k933 */
static void f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove in k933 */
static void f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3991,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=t2,a[3]=lf[260],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[237]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a3996 in remove in k933 */
static void f_3997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4003 in a3996 in remove in k933 */
static void f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* partition! in k933 */
static void f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3779,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t3))){
C_values(4,0,t1,t3,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3791,a[2]=t2,a[3]=t7,a[4]=lf[253],tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3836,a[2]=t2,a[3]=t5,a[4]=lf[255],tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3885,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t11=(C_word)C_i_car(t3);
t12=t2;
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}

/* k3883 in partition! in k933 */
static void f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=lf[256],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3894(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=lf[257],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3944(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}}

/* lp in k3883 in partition! in k933 */
static void C_fcall f_3944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3944,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
C_values(4,0,t1,t3,((C_word*)t0)[5]);}}

/* k3958 in lp in k3883 in partition! in k933 */
static void f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_3791(t4,t2,((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_3944(t3,((C_word*)t0)[7],((C_word*)t0)[6],t2);}}

/* k3961 in k3958 in lp in k3883 in partition! in k933 */
static void f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k3883 in partition! in k933 */
static void C_fcall f_3894(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3894,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3910,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
C_values(4,0,t1,((C_word*)t0)[4],t3);}}

/* k3908 in lp in k3883 in partition! in k933 */
static void f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=((C_word*)((C_word*)t0)[6])[1];
f_3894(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3836(t4,t2,((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* k3918 in k3908 in lp in k3883 in partition! in k933 */
static void f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* scan-out in partition! in k933 */
static void C_fcall f_3836(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3836,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=lf[254],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3842(t8,t1,t3,t4);}

/* lp in scan-out in partition! in k933 */
static void C_fcall f_3842(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3842,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],t3));}}

/* k3853 in lp in scan-out in partition! in k933 */
static void f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=((C_word*)((C_word*)t0)[5])[1];
f_3791(t4,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_3842(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}}

/* scan-in in partition! in k933 */
static void C_fcall f_3791(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3791,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=lf[252],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3797(t8,t1,t2,t4);}

/* lp in scan-in in partition! in k933 */
static void C_fcall f_3797(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3797,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3810,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],t3));}}

/* k3808 in lp in scan-in in partition! in k933 */
static void f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=((C_word*)((C_word*)t0)[6])[1];
f_3797(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3836(t4,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* partition in k933 */
static void f_3711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3711,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3717,a[2]=t2,a[3]=t5,a[4]=lf[249],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3717(t7,t1,t3);}

/* recur in partition in k933 */
static void C_fcall f_3717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3717,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3738,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=lf[247],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=lf[248],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t5,t6);}}

/* a3743 in recur in partition in k933 */
static void f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3744,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3751,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k3749 in a3743 in recur in partition in k933 */
static void f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]):((C_word*)t0)[3]);
C_values(4,0,((C_word*)t0)[2],t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]):((C_word*)t0)[3]);
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t3);}}

/* a3737 in recur in partition in k933 */
static void f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
f_3717(t2,t1,((C_word*)t0)[2]);}

/* filter! in k933 */
static void f_3590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3590,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3596,a[2]=t5,a[3]=t2,a[4]=lf[244],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3596(t7,t1,t3);}

/* lp in filter! in k933 */
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3596,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k3703 in lp in filter! in k933 */
static void f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t3,a[5]=lf[241],tmp=(C_word)a,a+=6,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=lf[243],tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
t10=((C_word*)t3)[1];
f_3618(t10,t8,((C_word*)t0)[3],t9);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_3596(t3,((C_word*)t0)[4],t2);}}

/* k3695 in k3703 in lp in filter! in k933 */
static void f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* scan-out in k3703 in lp in filter! in k933 */
static void C_fcall f_3651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3651,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=lf[242],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3657(t7,t1,t3);}

/* lp in scan-out in k3703 in lp in filter! in k933 */
static void C_fcall f_3657(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3657,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(((C_word*)t0)[5],t2));}}

/* k3668 in lp in scan-out in k3703 in lp in filter! in k933 */
static void f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_3618(t4,((C_word*)t0)[3],((C_word*)t0)[5],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_3657(t3,((C_word*)t0)[3],t2);}}

/* scan-in in k3703 in lp in filter! in k933 */
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3618,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3631,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3629 in scan-in in k3703 in lp in filter! in k933 */
static void f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_3618(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3651(t3,((C_word*)t0)[4],((C_word*)t0)[2],t2);}}

/* filter in k933 */
static void f_3548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3548,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3554,a[2]=t2,a[3]=t5,a[4]=lf[238],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3554(t7,t1,t3);}

/* recur in filter in k933 */
static void C_fcall f_3554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3554,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k3571 in recur in filter in k933 */
static void f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
f_3554(t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
f_3554(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k3574 in k3571 in recur in filter in k933 */
static void f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* map-in-order in k933 */
static void f_3471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3471r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3471r(t0,t1,t2,t3,t4);}}

static void f_3471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3487,a[2]=t2,a[3]=t7,a[4]=lf[234],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3487(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=t2,a[3]=t6,a[4]=lf[235],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3521(t8,t1,t3);}}

/* recur in map-in-order in k933 */
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k3532 in recur in map-in-order in k933 */
static void f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3521(t3,t2,((C_word*)t0)[2]);}

/* k3539 in k3532 in recur in map-in-order in k933 */
static void f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in map-in-order in k933 */
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=t2,a[3]=lf[232],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[233],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t3,t4);}

/* a3498 in recur in map-in-order in k933 */
static void f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3499,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3509,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k3507 in a3498 in recur in map-in-order in k933 */
static void f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3487(t3,t2,((C_word*)t0)[2]);}

/* k3514 in k3507 in a3498 in recur in map-in-order in k933 */
static void f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3492 in recur in map-in-order in k933 */
static void f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* filter-map in k933 */
static void f_3386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3386r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3386r(t0,t1,t2,t3,t4);}}

static void f_3386r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3402,a[2]=t2,a[3]=t7,a[4]=lf[228],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3402(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3442,a[2]=t6,a[3]=t2,a[4]=lf[229],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3442(t8,t1,t3);}}

/* recur in filter-map in k933 */
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3442,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(t2);
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3450 in recur in filter-map in k933 */
static void f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3453 in k3450 in recur in filter-map in k933 */
static void f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* recur in filter-map in k933 */
static void C_fcall f_3402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3402,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3408,a[2]=t2,a[3]=lf[226],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[227],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t3,t4);}

/* a3413 in recur in filter-map in k933 */
static void f_3414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3414,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3424,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k3422 in a3413 in recur in filter-map in k933 */
static void f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3402(t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
f_3402(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k3432 in k3422 in a3413 in recur in filter-map in k933 */
static void f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3407 in recur in filter-map in k933 */
static void f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* map! in k933 */
static void f_3314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3314r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3314r(t0,t1,t2,t3,t4);}}

static void f_3314r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3318,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3326,a[2]=t2,a[3]=t7,a[4]=lf[222],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3326(t9,t5,t3,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3372,a[2]=t2,a[3]=lf[223],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[208]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t3);}}

/* a3371 in map! in k933 */
static void f_3372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3372,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k3378 in a3371 in map! in k933 */
static void f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_car(((C_word*)t0)[2],t1));}

/* lp in map! in k933 */
static void C_fcall f_3326(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3326,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3338,a[2]=t3,a[3]=lf[220],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=lf[221],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a3343 in lp in map! in k933 */
static void f_3344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3359,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
C_apply(5,0,t4,((C_word*)t0)[2],t5,t2);}

/* k3357 in a3343 in lp in map! in k933 */
static void f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_3326(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* a3337 in lp in map! in k933 */
static void f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2529,a[2]=t4,a[3]=lf[219],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2529(t6,t1,t2);}

/* recur in a3337 in lp in map! in k933 */
static void C_fcall f_2529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2529,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2541,a[2]=t2,a[3]=lf[213],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=lf[218],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t3,t4);}
else{
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a2546 in recur in a3337 in lp in map! in k933 */
static void f_2547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2547,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2553,a[2]=t2,a[3]=lf[214],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2559,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[217],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a2558 in a2546 in recur in a3337 in lp in map! in k933 */
static void f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2559,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[215],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2571,a[2]=t3,a[3]=t2,a[4]=lf[216],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a2570 in a2558 in a2546 in recur in a3337 in lp in map! in k933 */
static void f_2571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2571,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
C_values(4,0,t1,t4,t5);}

/* a2564 in a2558 in a2546 in recur in a3337 in lp in map! in k933 */
static void f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
f_2529(t2,t1,((C_word*)t0)[2]);}

/* a2552 in a2546 in recur in a3337 in lp in map! in k933 */
static void f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a2540 in recur in a3337 in lp in map! in k933 */
static void f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k3316 in map! in k933 */
static void f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pair-for-each in k933 */
static void f_3255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3255r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3255r(t0,t1,t2,t3,t4);}}

static void f_3255r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3271,a[2]=t2,a[3]=t7,a[4]=lf[209],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3271(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3292,a[2]=t2,a[3]=t6,a[4]=lf[210],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3292(t8,t1,t3);}}

/* lp in pair-for-each in k933 */
static void C_fcall f_3292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3292,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3305,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3303 in lp in pair-for-each in k933 */
static void f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_3292(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in pair-for-each in k933 */
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3271,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3275,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
f_2278(t3,t2);}

/* k3273 in lp in pair-for-each in k933 */
static void f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3282 in k3273 in lp in pair-for-each in k933 */
static void f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_3271(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi1#really-append-map in k933 */
static void C_fcall f_3146(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3146,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3158,a[2]=t5,a[3]=t4,a[4]=lf[201],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3168,a[2]=t3,a[3]=t2,a[4]=lf[205],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t6,t7);}
else{
if(C_truep((C_word)C_i_null_list_p(t4))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_cdr(t4);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=t3,a[3]=t9,a[4]=t2,a[5]=lf[206],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3228(t11,t1,t6,t7);}}}

/* recur in ##srfi1#really-append-map in k933 */
static void C_fcall f_3228(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3228,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3230 in recur in ##srfi1#really-append-map in k933 */
static void f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
if(C_truep((C_word)C_i_null_list_p(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=((C_word*)((C_word*)t0)[2])[1];
f_3228(t5,t2,t3,t4);}}

/* k3243 in k3230 in recur in ##srfi1#really-append-map in k933 */
static void f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3167 in ##srfi1#really-append-map in k933 */
static void f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3168,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=lf[204],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3180(t7,t1,t2,t3);}}

/* recur in a3167 in ##srfi1#really-append-map in k933 */
static void C_fcall f_3180(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3180,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}

/* k3182 in recur in a3167 in ##srfi1#really-append-map in k933 */
static void f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[5],a[3]=lf[202],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=lf[203],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3194 in k3182 in recur in a3167 in ##srfi1#really-append-map in k933 */
static void f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3195,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_3180(t5,t4,t2,t3);}}

/* k3207 in a3194 in k3182 in recur in a3167 in ##srfi1#really-append-map in k933 */
static void f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3188 in k3182 in recur in a3167 in ##srfi1#really-append-map in k933 */
static void f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* a3157 in ##srfi1#really-append-map in k933 */
static void f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
f_2359(t1,t2);}

/* append-map! in k933 */
static void f_3140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3140r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3140r(t0,t1,t2,t3,t4);}}

static void f_3140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
f_3146(t1,*((C_word*)lf[119]+1),t2,t3,t4);}

/* append-map in k933 */
static void f_3134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3134r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3134r(t0,t1,t2,t3,t4);}}

static void f_3134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
f_3146(t1,*((C_word*)lf[131]+1),t2,t3,t4);}

/* reduce-right in k933 */
static void f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3090,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_null_list_p(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_i_car(t4);
t6=(C_word)C_i_cdr(t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3110,a[2]=t8,a[3]=t2,a[4]=lf[194],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3110(t10,t1,t5,t6);}}

/* recur in reduce-right in k933 */
static void C_fcall f_3110(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3110,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3124,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_cdr(t3);
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k3122 in recur in reduce-right in k933 */
static void f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* reduce in k933 */
static void f_3070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3070,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_null_list_p(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_i_car(t4);
t6=(C_word)C_i_cdr(t4);
t7=*((C_word*)lf[164]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t1,t2,t5,t6);}}

/* pair-fold in k933 */
static void f_3005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr5r,(void*)f_3005r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3005r(t0,t1,t2,t3,t4,t5);}}

static void f_3005r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3021,a[2]=t2,a[3]=t8,a[4]=lf[189],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3021(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3051,a[2]=t2,a[3]=t7,a[4]=lf[190],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3051(t9,t1,t4,t3);}}

/* lp in pair-fold in k933 */
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3068,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}}

/* k3066 in lp in pair-fold in k933 */
static void f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_3051(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in pair-fold in k933 */
static void C_fcall f_3021(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3021,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3025,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_2278(t4,t2);}

/* k3023 in lp in pair-fold in k933 */
static void f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3038,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=*((C_word*)lf[119]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3040 in k3023 in lp in pair-fold in k933 */
static void f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3036 in k3023 in lp in pair-fold in k933 */
static void f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_3021(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pair-fold-right in k933 */
static void f_2939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_2939r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2939r(t0,t1,t2,t3,t4,t5);}}

static void f_2939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(19);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2955,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=lf[185],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2955(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2985,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[186],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2985(t9,t1,t4);}}

/* recur in pair-fold-right in k933 */
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2985,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2999,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(t2);
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k2997 in recur in pair-fold-right in k933 */
static void f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in pair-fold-right in k933 */
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2955,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_2278(t3,t2);}

/* k2957 in recur in pair-fold-right in k933 */
static void f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
f_2955(t4,t3,t1);}}

/* k2978 in k2957 in recur in pair-fold-right in k933 */
static void f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[119]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2970 in k2957 in recur in pair-fold-right in k933 */
static void f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold-right in k933 */
static void f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_2874r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2874r(t0,t1,t2,t3,t4,t5);}}

static void f_2874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(19);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=lf[181],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2890(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2916,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[182],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2916(t9,t1,t4);}}

/* recur in fold-right in k933 */
static void C_fcall f_2916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2916,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2933,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k2931 in recur in fold-right in k933 */
static void f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in fold-right in k933 */
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_2278(t3,t2);}

/* k2892 in recur in fold-right in k933 */
static void f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2911,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
f_2890(t4,t3,t1);}}

/* k2909 in k2892 in recur in fold-right in k933 */
static void f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=t1,a[3]=t4,a[4]=lf[180],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2332(t6,((C_word*)t0)[2],t2);}

/* recur in k2909 in k2892 in recur in fold-right in k933 */
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[179]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* k2344 in recur in k2909 in k2892 in recur in fold-right in k933 */
static void f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_2332(t4,t2,t3);}

/* k2348 in k2344 in recur in k2909 in k2892 in recur in fold-right in k933 */
static void f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2905 in k2892 in recur in fold-right in k933 */
static void f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k933 */
static void f_2803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr5r,(void*)f_2803r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2803r(t0,t1,t2,t3,t4,t5);}}

static void f_2803r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(17);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2819,a[2]=t2,a[3]=t8,a[4]=lf[175],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2819(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=t2,a[3]=t7,a[4]=lf[176],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2850(t9,t1,t4,t3);}}

/* lp in fold in k933 */
static void C_fcall f_2850(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2850,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t3);}}

/* k2866 in lp in fold in k933 */
static void f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2850(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in fold in k933 */
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2819,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2825,a[2]=t3,a[3]=t2,a[4]=lf[173],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=lf[174],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a2830 in lp in fold in k933 */
static void f_2831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2831,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2845,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}}

/* k2843 in a2830 in lp in fold in k933 */
static void f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2819(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2824 in lp in fold in k933 */
static void f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2445,a[2]=t2,a[3]=t3,a[4]=lf[172],tmp=(C_word)a,a+=5,tmp);
C_call_cc(3,0,t1,t4);}

/* a2444 in a2824 in lp in fold in k933 */
static void f_2445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2445,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=lf[171],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2451(t6,t1,((C_word*)t0)[2]);}

/* recur in a2444 in a2824 in lp in fold in k933 */
static void C_fcall f_2451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2451,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2463,a[2]=t2,a[3]=lf[165],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[170],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_values(4,0,t1,t3,C_SCHEME_END_OF_LIST);}}

/* a2468 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2469,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2484,a[2]=t2,a[3]=lf[166],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2490,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[169],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a2489 in a2468 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2490,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[167],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2502,a[2]=t3,a[3]=t2,a[4]=lf[168],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a2501 in a2489 in a2468 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2502,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
C_values(4,0,t1,t4,t5);}

/* a2495 in a2489 in a2468 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
f_2451(t2,t1,((C_word*)t0)[2]);}

/* a2483 in a2468 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a2462 in recur in a2444 in a2824 in lp in fold in k933 */
static void f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* unfold in k933 */
static void f_2721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr6r,(void*)f_2721r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2721r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_2721r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(19);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(C_word)C_i_cdr(t6);
if(C_truep((C_word)C_i_pairp(t8))){
C_apply(10,0,t1,*((C_word*)lf[159]+1),lf[160],*((C_word*)lf[158]+1),t2,t3,t4,t5,t6);}
else{
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2745,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t10,a[6]=t7,a[7]=lf[161],tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_2745(t12,t1,t5);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2779,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=lf[162],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2779(t10,t1,t5);}}

/* recur in unfold in k933 */
static void C_fcall f_2779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2779,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2784 in recur in unfold in k933 */
static void f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k2791 in k2784 in recur in unfold in k933 */
static void f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2797,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2801,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2799 in k2791 in k2784 in recur in unfold in k933 */
static void f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2779(t2,((C_word*)t0)[2],t1);}

/* k2795 in k2791 in k2784 in recur in unfold in k933 */
static void f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in unfold in k933 */
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2745,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2750 in recur in unfold in k933 */
static void f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k2760 in k2750 in recur in unfold in k933 */
static void f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2768 in k2760 in k2750 in recur in unfold in k933 */
static void f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2745(t2,((C_word*)t0)[2],t1);}

/* k2764 in k2760 in k2750 in recur in unfold in k933 */
static void f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unfold-right in k933 */
static void f_2681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6rv,(void*)f_2681r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest_vector(a,C_rest_count(0));
f_2681r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_2681r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t7=(C_word)C_vemptyp(t6);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_vector_ref(t6,C_fix(0)));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2691,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t10,a[6]=lf[156],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2691(t12,t1,t5,t8);}

/* lp in unfold-right in k933 */
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2691,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2696 in lp in unfold-right in k933 */
static void f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k2703 in k2696 in lp in unfold-right in k933 */
static void f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2713,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2711 in k2703 in k2696 in lp in unfold-right in k933 */
static void f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_2691(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* count in k933 */
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_2588r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2588r(t0,t1,t2,t3,t4);}}

static void f_2588r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(14);
if(C_truep((C_word)C_i_pairp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=t2,a[3]=t6,a[4]=lf[152],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2600(t8,t1,t3,t4,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2651,a[2]=t2,a[3]=t6,a[4]=lf[153],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2651(t8,t1,t3,C_fix(0));}}

/* lp in count in k933 */
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2651,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2672,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2670 in lp in count in k933 */
static void f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_2651(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* lp in count in k933 */
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2600,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=t3,a[3]=lf[150],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=lf[151],tmp=(C_word)a,a+=7,tmp);
C_call_with_values(4,0,t1,t5,t6);}}

/* a2617 in lp in count in k933 */
static void f_2618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2618,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2639,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
C_apply(5,0,t5,((C_word*)t0)[2],t6,t2);}}

/* k2637 in a2617 in lp in count in k933 */
static void f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1)):((C_word*)t0)[6]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_2600(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a2611 in lp in count in k933 */
static void f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
f_2359(t1,((C_word*)t0)[2]);}

/* ##srfi1#cars+cdrs in k933 */
static void C_fcall f_2359(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2359,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=t2,a[3]=lf[147],tmp=(C_word)a,a+=4,tmp);
C_call_cc(3,0,t1,t3);}

/* a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2365,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=t4,a[3]=t2,a[4]=lf[146],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2371(t6,t1,((C_word*)t0)[2]);}

/* recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2371,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=t2,a[3]=lf[140],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[145],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t3,t4);}
else{
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a2388 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2389,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t2,a[3]=lf[141],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2410,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[144],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a2409 in a2388 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2410,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[142],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2422,a[2]=t3,a[3]=t2,a[4]=lf[143],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a2421 in a2409 in a2388 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2422,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
C_values(4,0,t1,t4,t5);}

/* a2415 in a2409 in a2388 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
f_2371(t2,t1,((C_word*)t0)[2]);}

/* a2403 in a2388 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a2382 in recur in a2364 in ##srfi1#cars+cdrs in k933 */
static void f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##srfi1#cdrs in k933 */
static void C_fcall f_2278(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2278,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=t2,a[3]=lf[137],tmp=(C_word)a,a+=4,tmp);
C_call_cc(3,0,t1,t3);}

/* a2283 in ##srfi1#cdrs in k933 */
static void f_2284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2284,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2290,a[2]=t4,a[3]=t2,a[4]=lf[136],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2290(t6,t1,((C_word*)t0)[2]);}

/* recur in a2283 in ##srfi1#cdrs in k933 */
static void C_fcall f_2290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2290,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cdr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2320,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}

/* k2318 in recur in a2283 in ##srfi1#cdrs in k933 */
static void f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2320,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* concatenate! in k933 */
static void f_2272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2272,3,t0,t1,t2);}
t3=*((C_word*)lf[130]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[119]+1),C_SCHEME_END_OF_LIST,t2);}

/* concatenate in k933 */
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2266,3,t0,t1,t2);}
t3=*((C_word*)lf[130]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[131]+1),C_SCHEME_END_OF_LIST,t2);}

/* append-reverse! in k933 */
static void f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2242,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2248(t2,t3));}

/* lp in append-reverse! in k933 */
static C_word C_fcall f_2248(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_null_list_p(t1))){
return(t2);}
else{
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_set_cdr(t1,t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}

/* append-reverse in k933 */
static void f_2212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2212,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2218,a[2]=t5,a[3]=lf[124],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2218(t7,t1,t2,t3);}

/* lp in append-reverse in k933 */
static void C_fcall f_2218(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2218,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* append! in k933 */
static void f_2136(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2136r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2136r(t0,t1,t2);}}

static void f_2136r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t4,a[3]=lf[121],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2142(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in append! in k933 */
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2142,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2171,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t8=t1;
t9=t5;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2169 in lp in append! in k933 */
static void f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=lf[120],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2173(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp2 in k2169 in lp in append! in k933 */
static void C_fcall f_2173(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2173,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_set_cdr(t2,t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2196,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t8=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t8=t7;
f_2196(2,t8,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}

/* k2194 in lp2 in k2169 in lp in append! in k933 */
static void f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2173(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unzip5 in k933 */
static void f_2052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2052,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=t4,a[3]=lf[117],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2058(t6,t1,t2);}

/* recur in unzip5 in k933 */
static void C_fcall f_2058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2058,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(7,0,t1,t2,t2,t2,t2,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[115],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2086,a[2]=t3,a[3]=lf[116],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a2085 in recur in unzip5 in k933 */
static void f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=7) C_bad_argc(c,7);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2086,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t2);
t9=(C_word)C_i_cadr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
t11=(C_word)C_i_caddr(((C_word*)t0)[2]);
t12=(C_word)C_a_i_cons(&a,2,t11,t4);
t13=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
t15=(C_word)C_i_cddddr(((C_word*)t0)[2]);
t16=(C_word)C_i_car(t15);
t17=(C_word)C_a_i_cons(&a,2,t16,t6);
C_values(7,0,t1,t8,t10,t12,t14,t17);}

/* a2075 in recur in unzip5 in k933 */
static void f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_2058(t3,t1,t2);}

/* unzip4 in k933 */
static void f_1980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1980,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t4,a[3]=lf[112],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1986(t6,t1,t2);}

/* recur in unzip4 in k933 */
static void C_fcall f_1986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1986,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(6,0,t1,t2,t2,t2,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[110],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t3,a[3]=lf[111],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a2013 in recur in unzip4 in k933 */
static void f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2014,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
t12=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t13=(C_word)C_a_i_cons(&a,2,t12,t5);
C_values(6,0,t1,t7,t9,t11,t13);}

/* a2003 in recur in unzip4 in k933 */
static void f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_1986(t3,t1,t2);}

/* unzip3 in k933 */
static void f_1916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1916,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=t4,a[3]=lf[107],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1922(t6,t1,t2);}

/* recur in unzip3 in k933 */
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1922,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(5,0,t1,t2,t2,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[105],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t3,a[3]=lf[106],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a1949 in recur in unzip3 in k933 */
static void f_1950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1950,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,t2);
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_i_caddr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t4);
C_values(5,0,t1,t6,t8,t10);}

/* a1939 in recur in unzip3 in k933 */
static void f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_1922(t3,t1,t2);}

/* unzip2 in k933 */
static void f_1860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1860,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1866,a[2]=t4,a[3]=lf[102],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1866(t6,t1,t2);}

/* recur in unzip2 in k933 */
static void C_fcall f_1866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1866,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_null_list_p(t2))){
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[100],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t3,a[3]=lf[101],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t4,t5);}}

/* a1893 in recur in unzip2 in k933 */
static void f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1894,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
C_values(4,0,t1,t5,t7);}

/* a1883 in recur in unzip2 in k933 */
static void f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_1866(t3,t1,t2);}

/* unzip1 in k933 */
static void f_1854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1854,3,t0,t1,t2);}
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,*((C_word*)lf[47]+1),t2);}

/* last-pair in k933 */
static void f_1833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1833,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1839(t2));}

/* lp in last-pair in k933 */
static C_word C_fcall f_1839(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t2;
t1=t4;
goto loop;}
else{
return(t1);}}

/* last in k933 */
static void f_1823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1823,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1829 in last in k933 */
static void f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* split-at! in k933 */
static void f_1792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1792,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[90]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1808,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(t3,C_fix(1));
t8=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t2,t7);}}

/* k1806 in split-at! in k933 */
static void f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_set_cdr(t1,C_SCHEME_END_OF_LIST);
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* split-at in k933 */
static void f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1740,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[85]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1749,a[2]=t6,a[3]=lf[88],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1749(t8,t1,t2,t3);}

/* recur in split-at in k933 */
static void C_fcall f_1749(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1749,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=lf[86],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=t2,a[3]=lf[87],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t5,t6);}}

/* a1777 in recur in split-at in k933 */
static void f_1778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1778,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
C_values(4,0,t1,t5,t3);}

/* a1763 in recur in split-at in k933 */
static void f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_1749(t4,t1,t2,t3);}

/* drop-right! in k933 */
static void f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1698,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1700 in drop-right! in k933 */
static void f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[3],a[3]=lf[83],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1717(t3,((C_word*)t0)[3],t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* lp in k1700 in drop-right! in k933 */
static C_word C_fcall f_1717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_cdr(t2);
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_i_set_cdr(t1,C_SCHEME_END_OF_LIST);
return(((C_word*)t0)[2]);}}

/* drop-right in k933 */
static void f_1660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1660,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1668,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1666 in drop-right in k933 */
static void f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1670,a[2]=t3,a[3]=lf[80],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1670(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in k1666 in drop-right in k933 */
static void C_fcall f_1670(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1670,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
t9=t5;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1686 in recur in k1666 in drop-right in k933 */
static void f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* take-right in k933 */
static void f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1630,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1636 in take-right in k933 */
static void f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=lf[77],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1640(((C_word*)t0)[2],t1));}

/* lp in k1636 in take-right in k933 */
static C_word C_fcall f_1640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_cdr(t2);
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(t1);}}

/* take! in k933 */
static void f_1607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1607,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[74]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1624,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(t3,C_fix(1));
t8=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t2,t7);}}

/* k1622 in take! in k933 */
static void f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_set_cdr(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* drop in k933 */
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1578,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[71]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1587,a[2]=lf[72],tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_1587(t2,t3));}

/* iter in drop in k933 */
static C_word C_fcall f_1587(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* take in k933 */
static void f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1541,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[68]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t6,a[3]=lf[69],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1550(t8,t1,t2,t3);}

/* recur in take in k933 */
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1550,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_fixnum_difference(t3,C_fix(1));
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k1566 in recur in take in k933 */
static void f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* car+cdr in k933 */
static void f_1524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1524,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[66]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
C_values(4,0,t1,t4,t5);}

/* tenth in k933 */
static void f_1510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1510,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=(C_word)C_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(t4));}

/* ninth in k933 */
static void f_1496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1496,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=(C_word)C_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(t4));}

/* eighth in k933 */
static void f_1486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1486,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadddr(t3));}

/* seventh in k933 */
static void f_1476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1476,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t3));}

/* sixth in k933 */
static void f_1466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1466,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t3));}

/* fifth in k933 */
static void f_1456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1456,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t3));}

/* zip in k933 */
static void f_1446(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1446r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1446r(t0,t1,t2,t3);}}

static void f_1446r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_apply(6,0,t1,*((C_word*)lf[43]+1),*((C_word*)lf[44]+1),t2,t3);}

/* length+ in k933 */
static void f_1397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1397,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=lf[40],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1403(t2,t2,C_fix(0)));}

/* lp in length+ in k933 */
static C_word C_fcall f_1403(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_fixnum_plus(t5,C_fix(1));
t9=(C_word)C_eqp(t6,t7);
if(C_truep(t9)){
return(C_SCHEME_FALSE);}
else{
t11=t6;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
return(t5);}}
else{
return(t3);}}

/* list= in k933 */
static void f_1297(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1297r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1297r(t0,t1,t2,t3);}}

static void f_1297r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_cdr(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1317,a[2]=t2,a[3]=t8,a[4]=lf[37],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1317(t10,t1,t5,t6);}}

/* lp1 in list= in k933 */
static void C_fcall f_1317(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1317,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_cdr(t3);
t7=(C_word)C_eqp(t2,t5);
if(C_truep(t7)){
t12=t1;
t13=t5;
t14=t6;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=lf[36],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_1344(t11,t1,t2,t5);}}}

/* lp2 in lp1 in list= in k933 */
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1344,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_null_list_p(t2))){
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=((C_word*)((C_word*)t0)[5])[1];
f_1317(t4,t1,t3,((C_word*)t0)[4]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_null_list_p(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1372,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}}

/* k1370 in lp2 in lp1 in list= in k933 */
static void f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1344(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* null-list? in k933 */
static void f_1294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1294,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_null_list_p(t2));}

/* not-pair? in k933 */
static void f_1291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1291,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* circular-list? in k933 */
static void f_1252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1258(t2,t2));}

/* lp in circular-list? in k933 */
static C_word C_fcall f_1258(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(t6);}
else{
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* dotted-list? in k933 */
static void f_1195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1201,a[2]=lf[26],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1201(t2,t2));}

/* lp in dotted-list? in k933 */
static C_word C_fcall f_1201(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(C_SCHEME_FALSE);}
else{
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=(C_word)C_i_nullp(t3);
return((C_word)C_i_not(t4));}}
else{
t3=(C_word)C_i_nullp(t1);
return((C_word)C_i_not(t3));}}

/* circular-list in k933 */
static void f_1181(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1181r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1181r(t0,t1,t2,t3);}}

static void f_1181r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1192,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k1190 in circular-list in k933 */
static void f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_set_cdr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}

/* iota in k933 */
static void f_1095(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1095r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1095r(t0,t1,t2,t3);}}

static void f_1095r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_number_2(t2,lf[16]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1102,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_lessp(t2,C_fix(0)))){
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[16],lf[18],*((C_word*)lf[16]+1),t2);}
else{
t6=t5;
f_1102(2,t6,C_SCHEME_UNDEFINED);}}

/* k1100 in iota in k933 */
static void f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_fix(0):(C_word)C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_1108(t8,(C_truep(t7)?C_fix(1):(C_word)C_i_car(t6)));}
else{
t6=t5;
f_1108(t6,C_fix(1));}}

/* k1106 in k1100 in iota in k933 */
static void C_fcall f_1108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1108,NULL,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[4],lf[16]);
t3=(C_word)C_i_check_number_2(t1,lf[16]);
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_a_i_times(&a,2,t4,t1);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1122,a[2]=t8,a[3]=t1,a[4]=lf[17],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1122(t10,((C_word*)t0)[2],((C_word*)t0)[3],t6,C_SCHEME_END_OF_LIST);}

/* do40 in k1106 in k1100 in iota in k933 */
static void C_fcall f_1122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1122,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t3,t4);
t9=t1;
t10=t5;
t11=t6;
t12=t7;
t1=t9;
t2=t10;
t3=t11;
t4=t12;
goto loop;}}

/* list-copy in k933 */
static void f_1065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1065,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1071,a[2]=t4,a[3]=lf[14],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1071(t6,t1,t2);}

/* recur in list-copy in k933 */
static void C_fcall f_1071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1071,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1087 in recur in list-copy in k933 */
static void f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* cons* in k933 */
static void f_1035(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1035r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1035r(t0,t1,t2,t3);}}

static void f_1035r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1041,a[2]=t5,a[3]=lf[11],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1041(t7,t1,t2,t3);}

/* recur in cons* in k933 */
static void C_fcall f_1041(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1041,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1055,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_cdr(t3);
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k1053 in recur in cons* in k933 */
static void f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* list-tabulate in k933 */
static void f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_998,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[7]);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1011,a[2]=t3,a[3]=t7,a[4]=lf[8],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1011(t9,t1,t5,C_SCHEME_END_OF_LIST);}

/* do15 in list-tabulate in k933 */
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1011,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1033,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k1031 in do15 in list-tabulate in k933 */
static void f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1011(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* make-list in k933 */
static void f_943(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_943r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_943r(t0,t1,t2,t3);}}

static void f_943r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_exact_2(t2,lf[2]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_950(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_950(2,t7,(C_word)C_i_car(t3));}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[2],lf[5],t7);}}}

/* k948 in make-list in k933 */
static void f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_955,a[2]=t3,a[3]=t1,a[4]=lf[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_955(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* do7 in k948 in make-list in k933 */
static void C_fcall f_955(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_955,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}}

/* xcons in k933 */
static void f_937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_937,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,t2));}
/* end of file */
