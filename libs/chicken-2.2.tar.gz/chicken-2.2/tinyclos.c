/* Generated from tinyclos.scm by the Chicken compiler
   2005-09-10 23:08
   Version 2, Build 111 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: tinyclos.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file tinyclos.c -explicit-use
   unit: tinyclos
*/

#include "chicken.h"

#define C_METHOD_CACHE_SIZE 8

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[430];


/* from ##tinyclos#hash-arg-list */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word args=(C_word )(C_a0);
C_word svector=(C_word )(C_a1);

    C_word tag, h, x;
    int n, i, j, len = 0;
    for(i = 0; args != C_SCHEME_END_OF_LIST; args = C_block_item(args, 1)) {
      x = C_block_item(args, 0);
      if(C_immediatep(x)) {
        switch(x) {
          case C_SCHEME_END_OF_LIST: i += 1; break;
          case C_SCHEME_TRUE:
          case C_SCHEME_FALSE: i += 3; break;
          case C_SCHEME_END_OF_FILE: i += 7; break;
          case C_SCHEME_UNDEFINED: i += 5; break;
          default:
            if(x & C_FIXNUM_BIT) i += 2;
            else i += 4;
        }
      }
      else {
        h = C_header_bits(x);
        switch(h) {
        case C_STRUCTURE_TYPE:
          tag = C_block_item(x, 0);
          if(tag == C_block_item(svector, 0)) { /* instance */
            if((tag = C_block_item(C_block_item(x, 1), 2)) != C_SCHEME_FALSE) i += C_unfix(tag);
            else i += C_header_size(x) << 4;
          }
          else i += 17;
          break;
        case C_CLOSURE_TYPE:
          n = C_header_size(x);
          if(n > 3 && C_block_item(svector, 1) == C_block_item(x, n - 1)) {
            if((tag = C_block_item(C_block_item(C_block_item(x, n - 2), 2), 2)) != C_SCHEME_FALSE) i += C_unfix(tag);
            else i += 13;
          }
          break;
        case C_SYMBOL_TYPE: i += 8; break;
        case C_BYTEVECTOR_TYPE: i += 16; break;
        case C_VECTOR_TYPE: i += 9; break;
        case C_PAIR_TYPE: i += 10; break;
        case C_FLONUM_TYPE: i += 11; break;
        case C_STRING_TYPE: i += 12; break;
        case C_PORT_TYPE: i += C_block_item(x, 1) ? 15 : 14; break;
        default: i += 255;
        }
      }
      ++len;
    }
    return((i + len) & (C_METHOD_CACHE_SIZE - 1));
C_return:
#undef return

return C_r;}

/* from ##tinyclos#method-cache-lookup */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub81(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word mcache=(C_word )(C_a0);
C_word hash=(C_word )(C_a1);
C_word classes=(C_word )(C_a2);

    C_word v = C_block_item(mcache, 1);
    C_word clist, x, y;
    int free_index = -1;
    int i = ((C_unfix(hash) & (C_METHOD_CACHE_SIZE - 1)) << 1) & 0xffff,
        i0, i2;
    for(i0 = i;; i = i2) {
      clist = C_block_item(v, i);
      if(clist != C_SCHEME_FALSE) {
        x = classes;
        y = clist;
        while(x != C_SCHEME_END_OF_LIST && y != C_SCHEME_END_OF_LIST) {
          if(C_block_item(x, 0) != C_block_item(y, 0)) goto mismatch;
          else {
            x = C_block_item(x, 1);
            y = C_block_item(y, 1);
          }
        }
        if (x == C_SCHEME_END_OF_LIST && y == C_SCHEME_END_OF_LIST)
          return(C_block_item(v, i + 1));
        else
          goto mismatch;
      }
      else if(free_index == -1) free_index = i;
    mismatch:
      i2 = (i + 2) & ((C_METHOD_CACHE_SIZE << 1) - 1);
      if(i2 == i0) return(free_index == -1 ? C_SCHEME_FALSE : C_fix(free_index));
    }
C_return:
#undef return

return C_r;}

/* from ##tinyclos#quick-getl in k809 in k786 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub63(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub63(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word initargs=(C_word )(C_a0);
C_word name=(C_word )(C_a1);
C_word def=(C_word )(C_a2);

    while(initargs != C_SCHEME_END_OF_LIST) {
      if(name == C_block_item(initargs, 0)) {
        if((initargs = C_block_item(initargs, 1)) == C_SCHEME_END_OF_LIST) return(def);
        else return(C_block_item(initargs, 0));
      }
      initargs = C_block_item(initargs, 1);
    }
    return(def);
C_return:
#undef return

return C_r;}

C_externexport void C_tinyclos_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_788(C_word c,C_word t0,C_word t1) C_noret;
static void f_811(C_word c,C_word t0,C_word t1) C_noret;
static void f_4653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1331(C_word c,C_word t0,C_word t1) C_noret;
static void f_1335(C_word c,C_word t0,C_word t1) C_noret;
static void f_4647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1421(C_word c,C_word t0,C_word t1) C_noret;
static void f_1855(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4609(C_word c,C_word t0,C_word t1) C_noret;
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2260(C_word c,C_word t0,C_word t1) C_noret;
static void f_2264(C_word c,C_word t0,C_word t1) C_noret;
static void f_2271(C_word c,C_word t0,C_word t1) C_noret;
static void f_2275(C_word c,C_word t0,C_word t1) C_noret;
static void f_2284(C_word c,C_word t0,C_word t1) C_noret;
static void f_2296(C_word c,C_word t0,C_word t1) C_noret;
static void f_4558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4560(C_word c,C_word t0,C_word t1) C_noret;
static void f_2308(C_word c,C_word t0,C_word t1) C_noret;
static void f_2324(C_word c,C_word t0,C_word t1) C_noret;
static void f_2328(C_word c,C_word t0,C_word t1) C_noret;
static void f_2332(C_word c,C_word t0,C_word t1) C_noret;
static void f_2336(C_word c,C_word t0,C_word t1) C_noret;
static void f_2381(C_word c,C_word t0,C_word t1) C_noret;
static void f_2385(C_word c,C_word t0,C_word t1) C_noret;
static void f_2389(C_word c,C_word t0,C_word t1) C_noret;
static void f_2393(C_word c,C_word t0,C_word t1) C_noret;
static void f_2397(C_word c,C_word t0,C_word t1) C_noret;
static void f_2401(C_word c,C_word t0,C_word t1) C_noret;
static void f_2405(C_word c,C_word t0,C_word t1) C_noret;
static void f_2409(C_word c,C_word t0,C_word t1) C_noret;
static void f_2413(C_word c,C_word t0,C_word t1) C_noret;
static void f_4312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4314(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4314r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_4466(C_word t0,C_word t1) C_noret;
static void f_982(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4321(C_word t0,C_word t1) C_noret;
static void f_4324(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4327(C_word t0,C_word t1) C_noret;
static void C_fcall f_4330(C_word t0,C_word t1) C_noret;
static void C_fcall f_4367(C_word t0,C_word t1) C_noret;
static void f_4426(C_word c,C_word t0,C_word t1) C_noret;
static void f_4437(C_word c,C_word t0,C_word t1) C_noret;
static void f_4429(C_word c,C_word t0,C_word t1) C_noret;
static void f_4430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4383(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4385(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4419(C_word c,C_word t0,C_word t1) C_noret;
static void f_4379(C_word c,C_word t0,C_word t1) C_noret;
static void f_4370(C_word c,C_word t0,C_word t1) C_noret;
static void f_4371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4342(C_word t0,C_word t1) C_noret;
static void C_fcall f_4345(C_word t0,C_word t1) C_noret;
static void f_4306(C_word c,C_word t0,C_word t1) C_noret;
static void f_2613(C_word c,C_word t0,C_word t1) C_noret;
static void f_4214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4302(C_word c,C_word t0,C_word t1) C_noret;
static void f_4250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4258(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4260(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2636(C_word c,C_word t0,C_word t1) C_noret;
static void f_2632(C_word c,C_word t0,C_word t1) C_noret;
static void f_4220(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4229(C_word t0,C_word t1) C_noret;
static void f_4232(C_word c,C_word t0,C_word t1) C_noret;
static void f_4237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4208(C_word c,C_word t0,C_word t1) C_noret;
static void f_2616(C_word c,C_word t0,C_word t1) C_noret;
static void f_4118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4128(C_word c,C_word t0,C_word t1) C_noret;
static void f_4132(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2654(C_word c,C_word t0,C_word t1) C_noret;
static void f_2650(C_word c,C_word t0,C_word t1) C_noret;
static void f_4112(C_word c,C_word t0,C_word t1) C_noret;
static void f_2619(C_word c,C_word t0,C_word t1) C_noret;
static void f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4108(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4071(C_word t0,C_word t1,C_word t2) C_noret;
static void f_4073(C_word c,C_word t0,C_word t1) C_noret;
static void f_4077(C_word c,C_word t0,C_word t1) C_noret;
static void f_4084(C_word c,C_word t0,C_word t1) C_noret;
static void f_4088(C_word c,C_word t0,C_word t1) C_noret;
static void f_4060(C_word c,C_word t0,C_word t1) C_noret;
static void f_2622(C_word c,C_word t0,C_word t1) C_noret;
static void f_4052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4046(C_word c,C_word t0,C_word t1) C_noret;
static void f_2657(C_word c,C_word t0,C_word t1) C_noret;
static void f_4041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4035(C_word c,C_word t0,C_word t1) C_noret;
static void f_2660(C_word c,C_word t0,C_word t1) C_noret;
static void f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3850(C_word c,C_word t0,C_word t1) C_noret;
static void f_3853(C_word c,C_word t0,C_word t1) C_noret;
static void f_4013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3856(C_word c,C_word t0,C_word t1) C_noret;
static void f_3862(C_word c,C_word t0,C_word t1) C_noret;
static void f_3868(C_word c,C_word t0,C_word t1) C_noret;
static void f_3996(C_word c,C_word t0,C_word t1) C_noret;
static void f_3871(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3961(C_word t0,C_word t1) C_noret;
static void f_3958(C_word c,C_word t0,C_word t1) C_noret;
static void f_3874(C_word c,C_word t0,C_word t1) C_noret;
static void f_3877(C_word c,C_word t0,C_word t1) C_noret;
static void f_3880(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3883(C_word t0,C_word t1) C_noret;
static void f_3926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3940(C_word c,C_word t0,C_word t1) C_noret;
static void f_3938(C_word c,C_word t0,C_word t1) C_noret;
static void f_3911(C_word c,C_word t0,C_word t1) C_noret;
static void f_3914(C_word c,C_word t0,C_word t1) C_noret;
static void f_3924(C_word c,C_word t0,C_word t1) C_noret;
static void f_3917(C_word c,C_word t0,C_word t1) C_noret;
static void f_3884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3840(C_word c,C_word t0,C_word t1) C_noret;
static void f_2663(C_word c,C_word t0,C_word t1) C_noret;
static void f_3791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3795(C_word c,C_word t0,C_word t1) C_noret;
static void f_3798(C_word c,C_word t0,C_word t1) C_noret;
static void f_3805(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3785(C_word c,C_word t0,C_word t1) C_noret;
static void f_2666(C_word c,C_word t0,C_word t1) C_noret;
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3767(C_word c,C_word t0,C_word t1) C_noret;
static void f_3781(C_word c,C_word t0,C_word t1) C_noret;
static void f_3770(C_word c,C_word t0,C_word t1) C_noret;
static void f_3777(C_word c,C_word t0,C_word t1) C_noret;
static void f_3757(C_word c,C_word t0,C_word t1) C_noret;
static void f_2669(C_word c,C_word t0,C_word t1) C_noret;
static void f_3702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3706(C_word c,C_word t0,C_word t1) C_noret;
static void f_3709(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3724(C_word c,C_word t0,C_word t1) C_noret;
static void f_3696(C_word c,C_word t0,C_word t1) C_noret;
static void f_2672(C_word c,C_word t0,C_word t1) C_noret;
static void f_3629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3633(C_word c,C_word t0,C_word t1) C_noret;
static void f_3636(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3641(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3651(C_word c,C_word t0,C_word t1) C_noret;
static void f_3623(C_word c,C_word t0,C_word t1) C_noret;
static void f_2675(C_word c,C_word t0,C_word t1) C_noret;
static void f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3609(C_word c,C_word t0,C_word t1) C_noret;
static void f_2678(C_word c,C_word t0,C_word t1) C_noret;
static void f_3522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3605(C_word c,C_word t0,C_word t1) C_noret;
static void f_3601(C_word c,C_word t0,C_word t1) C_noret;
static void f_3530(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3532(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3551(C_word c,C_word t0,C_word t1) C_noret;
static void f_3572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3570(C_word c,C_word t0,C_word t1) C_noret;
static void f_3566(C_word c,C_word t0,C_word t1) C_noret;
static void f_3562(C_word c,C_word t0,C_word t1) C_noret;
static void f_3516(C_word c,C_word t0,C_word t1) C_noret;
static void f_2681(C_word c,C_word t0,C_word t1) C_noret;
static void f_3505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3511(C_word c,C_word t0,C_word t1) C_noret;
static void f_3499(C_word c,C_word t0,C_word t1) C_noret;
static void f_2684(C_word c,C_word t0,C_word t1) C_noret;
static void f_2697(C_word c,C_word t0,C_word t1) C_noret;
static void f_2701(C_word c,C_word t0,C_word t1) C_noret;
static void f_3486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3480(C_word c,C_word t0,C_word t1) C_noret;
static void f_2720(C_word c,C_word t0,C_word t1) C_noret;
static void f_2724(C_word c,C_word t0,C_word t1) C_noret;
static void f_2728(C_word c,C_word t0,C_word t1) C_noret;
static void f_2732(C_word c,C_word t0,C_word t1) C_noret;
static void f_2736(C_word c,C_word t0,C_word t1) C_noret;
static void f_2740(C_word c,C_word t0,C_word t1) C_noret;
static void f_2744(C_word c,C_word t0,C_word t1) C_noret;
static void f_2748(C_word c,C_word t0,C_word t1) C_noret;
static void f_2752(C_word c,C_word t0,C_word t1) C_noret;
static void f_2756(C_word c,C_word t0,C_word t1) C_noret;
static void f_2760(C_word c,C_word t0,C_word t1) C_noret;
static void f_2764(C_word c,C_word t0,C_word t1) C_noret;
static void f_2768(C_word c,C_word t0,C_word t1) C_noret;
static void f_2772(C_word c,C_word t0,C_word t1) C_noret;
static void f_2776(C_word c,C_word t0,C_word t1) C_noret;
static void f_2780(C_word c,C_word t0,C_word t1) C_noret;
static void f_2784(C_word c,C_word t0,C_word t1) C_noret;
static void f_2788(C_word c,C_word t0,C_word t1) C_noret;
static void f_2792(C_word c,C_word t0,C_word t1) C_noret;
static void f_2796(C_word c,C_word t0,C_word t1) C_noret;
static void f_2800(C_word c,C_word t0,C_word t1) C_noret;
static void f_2804(C_word c,C_word t0,C_word t1) C_noret;
static void f_2808(C_word c,C_word t0,C_word t1) C_noret;
static void f_2812(C_word c,C_word t0,C_word t1) C_noret;
static void f_2816(C_word c,C_word t0,C_word t1) C_noret;
static void f_2820(C_word c,C_word t0,C_word t1) C_noret;
static void f_2824(C_word c,C_word t0,C_word t1) C_noret;
static void f_2828(C_word c,C_word t0,C_word t1) C_noret;
static void f_2832(C_word c,C_word t0,C_word t1) C_noret;
static void f_2836(C_word c,C_word t0,C_word t1) C_noret;
static void f_2840(C_word c,C_word t0,C_word t1) C_noret;
static void f_2844(C_word c,C_word t0,C_word t1) C_noret;
static void f_2848(C_word c,C_word t0,C_word t1) C_noret;
static void f_2852(C_word c,C_word t0,C_word t1) C_noret;
static void f_2856(C_word c,C_word t0,C_word t1) C_noret;
static void f_2860(C_word c,C_word t0,C_word t1) C_noret;
static void f_2864(C_word c,C_word t0,C_word t1) C_noret;
static void f_2868(C_word c,C_word t0,C_word t1) C_noret;
static void f_2872(C_word c,C_word t0,C_word t1) C_noret;
static void f_2876(C_word c,C_word t0,C_word t1) C_noret;
static void f_2880(C_word c,C_word t0,C_word t1) C_noret;
static void f_2884(C_word c,C_word t0,C_word t1) C_noret;
static void f_2888(C_word c,C_word t0,C_word t1) C_noret;
static void f_2892(C_word c,C_word t0,C_word t1) C_noret;
static void f_2897(C_word c,C_word t0,C_word t1) C_noret;
static void f_2935(C_word c,C_word t0,C_word t1) C_noret;
static void f_2939(C_word c,C_word t0,C_word t1) C_noret;
static void f_3429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3437(C_word c,C_word t0,C_word t1) C_noret;
static void f_3445(C_word c,C_word t0,C_word t1) C_noret;
static void f_3441(C_word c,C_word t0,C_word t1) C_noret;
static void f_3423(C_word c,C_word t0,C_word t1) C_noret;
static void f_2942(C_word c,C_word t0,C_word t1) C_noret;
static void f_3392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3392r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3400(C_word c,C_word t0,C_word t1) C_noret;
static void f_3386(C_word c,C_word t0,C_word t1) C_noret;
static void f_2945(C_word c,C_word t0,C_word t1) C_noret;
static void f_3351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3351r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3359(C_word c,C_word t0,C_word t1) C_noret;
static void f_3363(C_word c,C_word t0,C_word t1) C_noret;
static void f_3345(C_word c,C_word t0,C_word t1) C_noret;
static void f_2948(C_word c,C_word t0,C_word t1) C_noret;
static void f_3298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3306(C_word c,C_word t0,C_word t1) C_noret;
static void f_3292(C_word c,C_word t0,C_word t1) C_noret;
static void f_2951(C_word c,C_word t0,C_word t1) C_noret;
static void f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3235r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3239(C_word c,C_word t0,C_word t1) C_noret;
static void f_3242(C_word c,C_word t0,C_word t1) C_noret;
static void f_3269(C_word c,C_word t0,C_word t1) C_noret;
static void f_3245(C_word c,C_word t0,C_word t1) C_noret;
static void f_3265(C_word c,C_word t0,C_word t1) C_noret;
static void f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3261(C_word c,C_word t0,C_word t1) C_noret;
static void f_3229(C_word c,C_word t0,C_word t1) C_noret;
static void f_2954(C_word c,C_word t0,C_word t1) C_noret;
static void f_3194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3194r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3202(C_word c,C_word t0,C_word t1) C_noret;
static void f_3206(C_word c,C_word t0,C_word t1) C_noret;
static void f_3188(C_word c,C_word t0,C_word t1) C_noret;
static void f_2957(C_word c,C_word t0,C_word t1) C_noret;
static void f_3141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3141r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3149(C_word c,C_word t0,C_word t1) C_noret;
static void f_3135(C_word c,C_word t0,C_word t1) C_noret;
static void f_2960(C_word c,C_word t0,C_word t1) C_noret;
static void f_3107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3114(C_word t0,C_word t1) C_noret;
static void f_3101(C_word c,C_word t0,C_word t1) C_noret;
static void f_3097(C_word c,C_word t0,C_word t1) C_noret;
static void f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3066(C_word c,C_word t0,C_word t1) C_noret;
static void f_3049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3060(C_word c,C_word t0,C_word t1) C_noret;
static void f_3014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3005(C_word c,C_word t0,C_word t1) C_noret;
static void f_3012(C_word c,C_word t0,C_word t1) C_noret;
static void f_3008(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2969(C_word t0,C_word t1) C_noret;
static void f_2976(C_word c,C_word t0,C_word t1) C_noret;
static void f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2931(C_word c,C_word t0,C_word t1) C_noret;
static void f_2927(C_word c,C_word t0,C_word t1) C_noret;
static void f_2907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2703(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2686(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2686r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2690(C_word c,C_word t0,C_word t1) C_noret;
static void f_2693(C_word c,C_word t0,C_word t1) C_noret;
static void f_2589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2591(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2591r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2607(C_word c,C_word t0,C_word t1) C_noret;
static void f_2599(C_word c,C_word t0,C_word t1) C_noret;
static void f_2419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2470(C_word c,C_word t0,C_word t1) C_noret;
static void f_2480(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2498(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2570(C_word c,C_word t0,C_word t1) C_noret;
static void f_2514(C_word c,C_word t0,C_word t1) C_noret;
static void f_2476(C_word c,C_word t0,C_word t1) C_noret;
static void f_2423(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2426(C_word t0,C_word t1) C_noret;
static void f_2429(C_word c,C_word t0,C_word t1) C_noret;
static void f_2373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2344(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2344r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2352(C_word c,C_word t0,C_word t1) C_noret;
static void f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2245(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2182(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2186(C_word c,C_word t0,C_word t1) C_noret;
static void f_2164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2178(C_word c,C_word t0,C_word t1) C_noret;
static void f_2168(C_word c,C_word t0,C_word t1) C_noret;
static void f_2078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2085(C_word t0,C_word t1) C_noret;
static void f_2156(C_word c,C_word t0,C_word t1) C_noret;
static void f_2146(C_word c,C_word t0,C_word t1) C_noret;
static void f_2088(C_word c,C_word t0,C_word t1) C_noret;
static void f_1857(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1857r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2073(C_word c,C_word t0,C_word t1) C_noret;
static void f_2051(C_word c,C_word t0,C_word t1) C_noret;
static void f_2065(C_word c,C_word t0,C_word t1) C_noret;
static void f_2054(C_word c,C_word t0,C_word t1) C_noret;
static void f_2061(C_word c,C_word t0,C_word t1) C_noret;
static void f_2057(C_word c,C_word t0,C_word t1) C_noret;
static void f_2042(C_word c,C_word t0,C_word t1) C_noret;
static void f_2027(C_word c,C_word t0,C_word t1) C_noret;
static void f_2030(C_word c,C_word t0,C_word t1) C_noret;
static void f_1870(C_word c,C_word t0,C_word t1) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1) C_noret;
static void f_1879(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1998(C_word c,C_word t0,C_word t1) C_noret;
static void f_1882(C_word c,C_word t0,C_word t1) C_noret;
static void f_1971(C_word c,C_word t0,C_word t1) C_noret;
static void f_1885(C_word c,C_word t0,C_word t1) C_noret;
static void f_1946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1960(C_word c,C_word t0,C_word t1) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1) C_noret;
static void f_1958(C_word c,C_word t0,C_word t1) C_noret;
static void f_1913(C_word c,C_word t0,C_word t1) C_noret;
static void f_1916(C_word c,C_word t0,C_word t1) C_noret;
static void f_1919(C_word c,C_word t0,C_word t1) C_noret;
static void f_1922(C_word c,C_word t0,C_word t1) C_noret;
static void f_1925(C_word c,C_word t0,C_word t1) C_noret;
static void f_1928(C_word c,C_word t0,C_word t1) C_noret;
static void f_1944(C_word c,C_word t0,C_word t1) C_noret;
static void f_1931(C_word c,C_word t0,C_word t1) C_noret;
static void f_1934(C_word c,C_word t0,C_word t1) C_noret;
static void f_1937(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1787(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1807(C_word t0,C_word t1) C_noret;
static void C_fcall f_1720(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1740(C_word t0,C_word t1) C_noret;
static void f_1430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1482(C_word t0,C_word t1) C_noret;
static void f_1545(C_word c,C_word t0,C_word t1) C_noret;
static void f_1569(C_word c,C_word t0,C_word t1) C_noret;
static void f_1551(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1347(C_word c,C_word t0,C_word t1) C_noret;
static void f_1378(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1383(C_word t0,C_word t1);
static void f_1349(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1349r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1336(C_word c,C_word t0,C_word t1,...) C_noret;
static void C_fcall f_1314(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1318(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1172(C_word t0,C_word t1) C_noret;
static void f_1174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1222(C_word c,C_word t0,C_word t1) C_noret;
static void f_1218(C_word c,C_word t0,C_word t1) C_noret;
static void f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1013(C_word c,C_word t0,C_word t1) C_noret;
static void f_999(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1230(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1312(C_word c,C_word t0,C_word t1) C_noret;
static void f_1238(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1240(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_1250(C_word t0,C_word t1) C_noret;
static void f_1275(C_word c,C_word t0,C_word t1) C_noret;
static void f_1003(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_819(C_word t0,C_word t1);
static C_word C_fcall f_1089(C_word t0,C_word t1);
static void f_1031(C_word c,C_word t0,C_word t1) C_noret;
static void f_1043(C_word c,C_word t0,C_word t1) C_noret;
static void f_1060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1050(C_word c,C_word t0,C_word t1) C_noret;
static void f_1054(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1123(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1125(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1132(C_word c,C_word t0,C_word t1) C_noret;
static void f_1166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1135(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_941(C_word t0,C_word t1,C_word t2) C_noret;
static void f_960(C_word c,C_word t0,C_word t1) C_noret;
static void f_967(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_894(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_897(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_891(C_word t0,C_word t1,C_word t2);
static void f_845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_870(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_4591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4591(t0,t1,t2,t3);}

static void C_fcall trf_4466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4466(t0,t1);}

static void C_fcall trf_4321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4321(t0,t1);}

static void C_fcall trf_4327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4327(t0,t1);}

static void C_fcall trf_4330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4330(t0,t1);}

static void C_fcall trf_4367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4367(t0,t1);}

static void C_fcall trf_4385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4385(t0,t1,t2);}

static void C_fcall trf_4342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4342(t0,t1);}

static void C_fcall trf_4345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4345(t0,t1);}

static void C_fcall trf_4260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4260(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4260(t0,t1,t2,t3);}

static void C_fcall trf_4229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4229(t0,t1);}

static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4134(t0,t1,t2,t3,t4);}

static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4071(t0,t1,t2);}

static void C_fcall trf_3961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3961(t0,t1);}

static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3883(t0,t1);}

static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3714(t0,t1,t2,t3);}

static void C_fcall trf_3641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3641(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3641(t0,t1,t2,t3);}

static void C_fcall trf_3532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3532(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3532(t0,t1,t2,t3);}

static void C_fcall trf_3114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3114(t0,t1);}

static void C_fcall trf_2962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2962(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2962(t0,t1,t2,t3);}

static void C_fcall trf_2969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2969(t0,t1);}

static void C_fcall trf_2703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2703(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2703(t0,t1,t2);}

static void C_fcall trf_2482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2482(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2482(t0,t1,t2);}

static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2532(t0,t1,t2,t3);}

static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2426(t0,t1);}

static void C_fcall trf_2182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2182(t0,t1,t2);}

static void C_fcall trf_2085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2085(t0,t1);}

static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1981(t0,t1,t2,t3);}

static void C_fcall trf_1886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1886(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1886(t0,t1,t2);}

static void C_fcall trf_1787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1787(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1787(t0,t1,t2,t3);}

static void C_fcall trf_1807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1807(t0,t1);}

static void C_fcall trf_1720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1720(t0,t1,t2);}

static void C_fcall trf_1740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1740(t0,t1);}

static void C_fcall trf_1482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1482(t0,t1);}

static void C_fcall trf_1342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1342(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1342(t0,t1,t2,t3,t4);}

static void C_fcall trf_1314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1314(t0,t1,t2);}

static void C_fcall trf_1172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1172(t0,t1);}

static void C_fcall trf_1184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1184(t0,t1,t2,t3);}

static void C_fcall trf_1230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1230(t0,t1,t2);}

static void C_fcall trf_1240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1240(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1240(t0,t1,t2,t3,t4);}

static void C_fcall trf_1250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1250(t0,t1);}

static void C_fcall trf_1021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1021(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1021(t0,t1,t2,t3,t4);}

static void C_fcall trf_1115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1115(t0,t1,t2,t3);}

static void C_fcall trf_1125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1125(t0,t1,t2);}

static void C_fcall trf_941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_941(t0,t1,t2);}

static void C_fcall trf_894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_894(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_894(t0,t1,t2,t3);}

static void C_fcall trf_897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_897(t0,t1,t2);}

static void C_fcall trf_851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_851(t0,t1,t2,t3);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tinyclos_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_tinyclos_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tinyclos_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1878)){
C_save(t1);
C_rereclaim2(1878*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,430);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[11]=C_h_pair(C_restore,tmp);
lf[13]=C_static_string(C_heaptop,6,".dylib");
lf[15]=C_static_string(C_heaptop,4,".dll");
lf[17]=C_static_string(C_heaptop,3,".sl");
lf[19]=C_static_string(C_heaptop,3,".so");
lf[21]=C_static_string(C_heaptop,4,".scm");
lf[23]=C_static_string(C_heaptop,6,".setup");
lf[25]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[27]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[29]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[31]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[33]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[35]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[37]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[39]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[41]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[43]=C_static_lambda_info(C_heaptop,22,"(loop list153 list254)");
lf[44]=C_static_lambda_info(C_heaptop,42,"(##tinyclos#every2 test49 list150 list251)");
lf[46]=C_static_lambda_info(C_heaptop,35,"(##tinyclos#quick-getl a6166 a6067)");
lf[48]=C_h_intern(&lf[48],9,"\003syserror");
lf[49]=C_h_intern(&lf[49],13,"\010tinyclosgetl");
lf[50]=C_static_string(C_heaptop,18,"couldn\047t find item");
lf[51]=C_static_lambda_info(C_heaptop,13,"(scan tail72)");
lf[52]=C_static_lambda_info(C_heaptop,47,"(##tinyclos#getl initargs68 name69 not-found70)");
lf[54]=C_static_lambda_info(C_heaptop,30,"(##tinyclos#filter-in f74 l75)");
lf[57]=C_h_intern(&lf[57],24,"\010tinycloscompute-std-cpl");
lf[58]=C_h_intern(&lf[58],24,"\010tinyclosstd-tie-breaker");
lf[59]=C_static_string(C_heaptop,13,"nothing valid");
lf[60]=C_static_lambda_info(C_heaptop,12,"(a1165 x111)");
lf[61]=C_static_lambda_info(C_heaptop,14,"(loop pcpl107)");
lf[62]=C_h_intern(&lf[62],7,"reverse");
lf[63]=C_static_lambda_info(C_heaptop,35,"(f_1115 partial-cpl104 min-elts105)");
lf[64]=C_h_intern(&lf[64],17,"\010tinyclostop-sort");
lf[65]=C_static_string(C_heaptop,19,"invalid constraints");
lf[66]=C_h_intern(&lf[66],6,"append");
lf[67]=C_static_lambda_info(C_heaptop,12,"(a1059 x101)");
lf[68]=C_static_lambda_info(C_heaptop,7,"(a1088)");
lf[69]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[70]=C_static_lambda_info(C_heaptop,11,"(a1082 x96)");
lf[71]=C_static_lambda_info(C_heaptop,40,"(loop elements92 constraints93 result94)");
lf[72]=C_static_lambda_info(C_heaptop,40,"(loop elements123 this-one124 result125)");
lf[74]=C_static_lambda_info(C_heaptop,13,"(f_1230 x121)");
lf[75]=C_static_lambda_info(C_heaptop,52,"(##tinyclos#compute-std-cpl c86 get-direct-supers87)");
lf[76]=C_static_lambda_info(C_heaptop,28,"(track result116 pending117)");
lf[77]=C_static_lambda_info(C_heaptop,13,"(f_1174 x114)");
lf[78]=C_static_lambda_info(C_heaptop,55,"(##tinyclos#build-transitive-closure get-follow-ons113)");
lf[80]=C_h_intern(&lf[80],8,"instance");
lf[81]=C_h_intern(&lf[81],11,"make-vector");
lf[82]=C_static_lambda_info(C_heaptop,51,"(##tinyclos#%allocate-instance class129 nfields130)");
lf[83]=C_h_intern(&lf[83],19,"\010tinyclosentity-tag");
lf[84]=C_h_intern(&lf[84],25,"\010tinyclos%allocate-entity");
lf[85]=C_static_string(C_heaptop,40,"called entity without first setting proc");
lf[86]=C_static_lambda_info(C_heaptop,24,"(default-proc . args150)");
lf[88]=C_static_lambda_info(C_heaptop,18,"(f_1349 . args156)");
lf[89]=C_h_intern(&lf[89],6,"entity");
lf[90]=C_static_lambda_info(C_heaptop,7,"(do160)");
lf[91]=C_static_lambda_info(C_heaptop,57,"(##tinyclos#%allocate-entity class151 nfields152 name153)");
lf[93]=C_h_intern(&lf[93],8,"class-of");
lf[94]=C_h_intern(&lf[94],6,"<null>");
lf[95]=C_h_intern(&lf[95],7,"<exact>");
lf[96]=C_h_intern(&lf[96],9,"<boolean>");
lf[97]=C_h_intern(&lf[97],6,"<char>");
lf[98]=C_h_intern(&lf[98],6,"<void>");
lf[99]=C_h_intern(&lf[99],13,"<end-of-file>");
lf[100]=C_h_intern(&lf[100],8,"<symbol>");
lf[101]=C_h_intern(&lf[101],8,"<vector>");
lf[102]=C_h_intern(&lf[102],6,"<pair>");
lf[103]=C_h_intern(&lf[103],9,"<integer>");
lf[104]=C_h_intern(&lf[104],9,"<inexact>");
lf[105]=C_h_intern(&lf[105],8,"<string>");
lf[106]=C_h_intern(&lf[106],11,"<procedure>");
lf[107]=C_h_intern(&lf[107],12,"<input-port>");
lf[108]=C_h_intern(&lf[108],13,"<output-port>");
lf[109]=C_h_intern(&lf[109],11,"input-port\077");
lf[110]=C_h_intern(&lf[110],9,"<pointer>");
lf[111]=C_h_intern(&lf[111],16,"<tagged-pointer>");
lf[112]=C_h_intern(&lf[112],14,"<swig-pointer>");
lf[113]=C_h_intern(&lf[113],10,"<locative>");
lf[114]=C_h_intern(&lf[114],13,"<byte-vector>");
lf[115]=C_h_intern(&lf[115],17,"dummy-environment");
lf[116]=C_h_intern(&lf[116],13,"<environment>");
lf[117]=C_h_intern(&lf[117],5,"array");
lf[118]=C_h_intern(&lf[118],7,"<array>");
lf[119]=C_h_intern(&lf[119],10,"hash-table");
lf[120]=C_h_intern(&lf[120],12,"<hash-table>");
lf[121]=C_h_intern(&lf[121],5,"queue");
lf[122]=C_h_intern(&lf[122],7,"<queue>");
lf[123]=C_h_intern(&lf[123],9,"condition");
lf[124]=C_h_intern(&lf[124],11,"<condition>");
lf[125]=C_h_intern(&lf[125],8,"char-set");
lf[126]=C_h_intern(&lf[126],10,"<char-set>");
lf[127]=C_h_intern(&lf[127],4,"time");
lf[128]=C_h_intern(&lf[128],6,"<time>");
lf[129]=C_h_intern(&lf[129],4,"lock");
lf[130]=C_h_intern(&lf[130],6,"<lock>");
lf[131]=C_h_intern(&lf[131],4,"mmap");
lf[132]=C_h_intern(&lf[132],6,"<mmap>");
lf[133]=C_h_intern(&lf[133],7,"promise");
lf[134]=C_h_intern(&lf[134],9,"<promise>");
lf[135]=C_h_intern(&lf[135],8,"u8vector");
lf[136]=C_h_intern(&lf[136],10,"<u8vector>");
lf[137]=C_h_intern(&lf[137],8,"s8vector");
lf[138]=C_h_intern(&lf[138],10,"<s8vector>");
lf[139]=C_h_intern(&lf[139],9,"u16vector");
lf[140]=C_h_intern(&lf[140],11,"<u16vector>");
lf[141]=C_h_intern(&lf[141],9,"s16vector");
lf[142]=C_h_intern(&lf[142],11,"<s16vector>");
lf[143]=C_h_intern(&lf[143],9,"u32vector");
lf[144]=C_h_intern(&lf[144],11,"<u32vector>");
lf[145]=C_h_intern(&lf[145],9,"s32vector");
lf[146]=C_h_intern(&lf[146],11,"<s32vector>");
lf[147]=C_h_intern(&lf[147],9,"f32vector");
lf[148]=C_h_intern(&lf[148],11,"<f32vector>");
lf[149]=C_h_intern(&lf[149],9,"f64vector");
lf[150]=C_h_intern(&lf[150],11,"<f64vector>");
lf[151]=C_h_intern(&lf[151],12,"tcp-listener");
lf[152]=C_h_intern(&lf[152],14,"<tcp-listener>");
lf[153]=C_h_intern(&lf[153],11,"<structure>");
lf[154]=C_static_string(C_heaptop,41,"can not compute class of primitive object");
lf[155]=C_h_intern(&lf[155],15,"\003sysbytevector\077");
lf[156]=C_h_intern(&lf[156],5,"port\077");
lf[157]=C_static_lambda_info(C_heaptop,15,"(class-of x200)");
lf[159]=C_h_intern(&lf[159],15,"\003syssignal-hook");
lf[160]=C_h_intern(&lf[160],11,"\000type-error");
lf[161]=C_h_intern(&lf[161],18,"\010tinyclosget-field");
lf[162]=C_static_string(C_heaptop,44,"can only get-field of instances and entities");
lf[163]=C_static_lambda_info(C_heaptop,41,"(##tinyclos#get-field object208 field209)");
lf[165]=C_h_intern(&lf[165],19,"\010tinyclosset-field!");
lf[166]=C_static_string(C_heaptop,45,"can only set-field! of instances and entities");
lf[167]=C_static_lambda_info(C_heaptop,55,"(##tinyclos#set-field! object217 field218 new-value219)");
lf[168]=C_h_intern(&lf[168],4,"make");
lf[169]=C_h_intern(&lf[169],7,"<class>");
lf[170]=C_h_intern(&lf[170],14,"<entity-class>");
lf[171]=C_h_intern(&lf[171],13,"direct-supers");
lf[172]=C_h_intern(&lf[172],4,"name");
lf[173]=C_static_string(C_heaptop,11,"(anonymous)");
lf[174]=C_static_lambda_info(C_heaptop,12,"(a1899 o248)");
lf[175]=C_static_lambda_info(C_heaptop,17,"(a1905 o249 n250)");
lf[176]=C_static_lambda_info(C_heaptop,19,"(allocator init246)");
lf[178]=C_h_intern(&lf[178],17,"getters-n-setters");
lf[179]=C_h_intern(&lf[179],18,"field-initializers");
lf[180]=C_h_intern(&lf[180],7,"nfields");
lf[181]=C_h_intern(&lf[181],5,"slots");
lf[182]=C_h_intern(&lf[182],3,"cpl");
lf[183]=C_h_intern(&lf[183],12,"direct-slots");
lf[184]=C_static_lambda_info(C_heaptop,7,"(a1965)");
lf[185]=C_static_lambda_info(C_heaptop,7,"(a1959)");
lf[186]=C_h_intern(&lf[186],4,"cons");
lf[187]=C_static_lambda_info(C_heaptop,12,"(a1945 s254)");
lf[188]=C_h_intern(&lf[188],7,"\003sysmap");
lf[189]=C_h_intern(&lf[189],18,"class-direct-slots");
lf[190]=C_h_intern(&lf[190],19,"class-direct-supers");
lf[191]=C_static_lambda_info(C_heaptop,24,"(loop sups239 so-far240)");
lf[192]=C_h_intern(&lf[192],4,"list");
lf[194]=C_h_intern(&lf[194],9,"<generic>");
lf[195]=C_h_intern(&lf[195],7,"methods");
lf[196]=C_static_string(C_heaptop,9,"(unnamed)");
lf[197]=C_h_intern(&lf[197],11,"class-slots");
lf[198]=C_h_intern(&lf[198],8,"<method>");
lf[199]=C_h_intern(&lf[199],9,"procedure");
lf[200]=C_h_intern(&lf[200],12,"specializers");
lf[201]=C_static_lambda_info(C_heaptop,31,"(f_1857 class229 . initargs230)");
lf[203]=C_static_string(C_heaptop,4,"huh\077");
lf[205]=C_static_lambda_info(C_heaptop,44,"(##tinyclos#slot-ref object271 slot-name272)");
lf[206]=C_static_lambda_info(C_heaptop,58,"(##tinyclos#slot-set! object281 slot-name282 new-value283)");
lf[207]=C_h_intern(&lf[207],8,"slot-ref");
lf[208]=C_h_intern(&lf[208],9,"slot-set!");
lf[209]=C_static_string(C_heaptop,29,"no slot in instances of class");
lf[211]=C_static_lambda_info(C_heaptop,51,"(##tinyclos#lookup-slot-info class286 slot-name287)");
lf[212]=C_static_lambda_info(C_heaptop,29,"(class-direct-slots class290)");
lf[213]=C_static_lambda_info(C_heaptop,30,"(class-direct-supers class291)");
lf[214]=C_static_lambda_info(C_heaptop,22,"(class-slots class292)");
lf[215]=C_h_intern(&lf[215],10,"class-name");
lf[216]=C_static_lambda_info(C_heaptop,21,"(class-name class293)");
lf[217]=C_h_intern(&lf[217],15,"generic-methods");
lf[218]=C_static_lambda_info(C_heaptop,28,"(generic-methods generic294)");
lf[219]=C_h_intern(&lf[219],19,"method-specializers");
lf[220]=C_static_lambda_info(C_heaptop,31,"(method-specializers method295)");
lf[221]=C_h_intern(&lf[221],16,"method-procedure");
lf[222]=C_static_lambda_info(C_heaptop,28,"(method-procedure method296)");
lf[223]=C_h_intern(&lf[223],9,"class-cpl");
lf[224]=C_static_lambda_info(C_heaptop,20,"(class-cpl class297)");
tmp=C_intern(C_heaptop,13,"direct-supers");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"direct-slots");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cpl");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"slots");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"nfields");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"field-initializers");
C_save(tmp);
tmp=C_intern(C_heaptop,17,"getters-n-setters");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"name");
C_save(tmp);
lf[225]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[226]=C_h_intern(&lf[226],5,"<top>");
lf[227]=C_h_intern(&lf[227],8,"<object>");
lf[228]=C_h_intern(&lf[228],5,"class");
lf[229]=C_h_intern(&lf[229],17,"<procedure-class>");
lf[230]=C_h_intern(&lf[230],10,"make-class");
lf[231]=C_static_string(C_heaptop,11,"(anonymous)");
lf[232]=C_static_lambda_info(C_heaptop,45,"(make-class direct-supers339 direct-slots340)");
lf[233]=C_h_intern(&lf[233],12,"make-generic");
lf[234]=C_static_string(C_heaptop,9,"(unnamed)");
lf[235]=C_static_lambda_info(C_heaptop,24,"(make-generic . name341)");
lf[236]=C_h_intern(&lf[236],11,"make-method");
lf[237]=C_static_lambda_info(C_heaptop,42,"(make-method specializers345 procedure346)");
lf[238]=C_h_intern(&lf[238],10,"initialize");
lf[239]=C_h_intern(&lf[239],17,"allocate-instance");
lf[240]=C_h_intern(&lf[240],25,"compute-getter-and-setter");
lf[241]=C_h_intern(&lf[241],11,"compute-cpl");
lf[242]=C_h_intern(&lf[242],13,"compute-slots");
lf[243]=C_h_intern(&lf[243],21,"compute-apply-generic");
lf[244]=C_h_intern(&lf[244],15,"compute-methods");
lf[245]=C_h_intern(&lf[245],29,"compute-method-more-specific\077");
lf[246]=C_h_intern(&lf[246],21,"compute-apply-methods");
lf[247]=C_h_intern(&lf[247],36,"\010tinyclosgeneric-invocation-generics");
lf[248]=C_h_intern(&lf[248],10,"add-method");
lf[249]=C_static_lambda_info(C_heaptop,28,"(check-method ms1357 ms2358)");
lf[250]=C_static_lambda_info(C_heaptop,29,"(filter-in-method methods352)");
lf[251]=C_static_lambda_info(C_heaptop,33,"(add-method generic347 method348)");
lf[252]=C_static_lambda_info(C_heaptop,18,"(f_2591 . args370)");
lf[253]=C_static_lambda_info(C_heaptop,20,"(proc180 generic369)");
lf[254]=C_static_lambda_info(C_heaptop,29,"(make class534 . initargs535)");
lf[255]=C_h_intern(&lf[255],17,"<primitive-class>");
lf[256]=C_h_intern(&lf[256],11,"<primitive>");
lf[258]=C_static_lambda_info(C_heaptop,53,"(##tinyclos#make-primitive-class name538 sclasses539)");
lf[259]=C_h_intern(&lf[259],8,"<number>");
lf[260]=C_h_intern(&lf[260],6,"<port>");
lf[261]=C_h_intern(&lf[261],12,"<c++-object>");
lf[262]=C_h_intern(&lf[262],16,"initialize-slots");
lf[263]=C_static_lambda_info(C_heaptop,15,"(a2906 slot546)");
lf[264]=C_h_intern(&lf[264],12,"\003sysfor-each");
lf[265]=C_static_lambda_info(C_heaptop,40,"(initialize-slots object544 initargs545)");
lf[266]=C_h_intern(&lf[266],12,"print-object");
lf[267]=C_h_intern(&lf[267],15,"describe-object");
lf[269]=C_h_intern(&lf[269],18,"\003syssymbol->string");
lf[270]=C_static_lambda_info(C_heaptop,39,"(##tinyclos#ensure-generic x593 sym594)");
lf[271]=C_h_intern(&lf[271],26,"\010tinyclosadd-global-method");
lf[272]=C_static_lambda_info(C_heaptop,68,"(##tinyclos#add-global-method val599 sym600 specializers601 proc602)");
lf[273]=C_h_intern(&lf[273],9,"instance\077");
lf[274]=C_static_lambda_info(C_heaptop,16,"(instance\077 x605)");
lf[275]=C_h_intern(&lf[275],9,"subclass\077");
lf[276]=C_static_lambda_info(C_heaptop,21,"(subclass\077 x611 y612)");
lf[277]=C_h_intern(&lf[277],12,"instance-of\077");
lf[278]=C_static_lambda_info(C_heaptop,28,"(instance-of\077 x613 class614)");
lf[279]=C_h_intern(&lf[279],35,"\010tinyclosmake-instance-from-pointer");
lf[280]=C_h_intern(&lf[280],4,"this");
lf[281]=C_static_lambda_info(C_heaptop,53,"(##tinyclos#make-instance-from-pointer ptr618 cls619)");
lf[282]=C_static_lambda_info(C_heaptop,46,"(a3106 call-next-method620 obj621 initargs622)");
lf[283]=C_h_intern(&lf[283],7,"fprintf");
lf[284]=C_static_string(C_heaptop,12,"generic ~A~%");
lf[285]=C_h_intern(&lf[285],19,"\003sysstandard-output");
lf[286]=C_static_lambda_info(C_heaptop,42,"(a3140 call-next-method586 x587 . port588)");
lf[287]=C_static_string(C_heaptop,10,"class ~A~%");
lf[288]=C_static_lambda_info(C_heaptop,42,"(a3193 call-next-method581 x582 . port583)");
lf[289]=C_static_string(C_heaptop,11," ~S\011-> ~S~%");
lf[290]=C_static_lambda_info(C_heaptop,12,"(a3249 s578)");
lf[291]=C_static_string(C_heaptop,23,"instance of class ~A:~%");
lf[292]=C_static_lambda_info(C_heaptop,42,"(a3234 call-next-method571 x572 . port573)");
lf[293]=C_static_string(C_heaptop,13,"#<generic ~A>");
lf[294]=C_static_lambda_info(C_heaptop,42,"(a3297 call-next-method565 x566 . port567)");
lf[295]=C_static_string(C_heaptop,11,"#<class ~A>");
lf[296]=C_static_lambda_info(C_heaptop,42,"(a3350 call-next-method560 x561 . port562)");
lf[297]=C_h_intern(&lf[297],5,"write");
lf[298]=C_static_lambda_info(C_heaptop,42,"(a3391 call-next-method555 x556 . port557)");
lf[299]=C_static_string(C_heaptop,5,"#<~A>");
lf[300]=C_static_lambda_info(C_heaptop,42,"(a3428 call-next-method550 x551 . port552)");
lf[301]=C_static_string(C_heaptop,15,"describe-object");
lf[302]=C_static_string(C_heaptop,12,"print-object");
lf[303]=C_h_intern(&lf[303],6,"gensym");
lf[304]=C_static_string(C_heaptop,10,"c++-object");
tmp=C_intern(C_heaptop,4,"this");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[305]=C_h_pair(C_restore,tmp);
lf[306]=C_static_string(C_heaptop,12,"tcp-listener");
lf[307]=C_static_string(C_heaptop,8,"locative");
lf[308]=C_static_string(C_heaptop,12,"swig-pointer");
lf[309]=C_static_string(C_heaptop,14,"tagged-pointer");
lf[310]=C_static_string(C_heaptop,7,"pointer");
lf[311]=C_static_string(C_heaptop,9,"f64vector");
lf[312]=C_static_string(C_heaptop,9,"f32vector");
lf[313]=C_static_string(C_heaptop,9,"s32vector");
lf[314]=C_static_string(C_heaptop,9,"u32vector");
lf[315]=C_static_string(C_heaptop,9,"s16vector");
lf[316]=C_static_string(C_heaptop,9,"u16vector");
lf[317]=C_static_string(C_heaptop,8,"s8vector");
lf[318]=C_static_string(C_heaptop,8,"u8vector");
lf[319]=C_static_string(C_heaptop,5,"array");
lf[320]=C_static_string(C_heaptop,4,"mmap");
lf[321]=C_static_string(C_heaptop,4,"lock");
lf[322]=C_static_string(C_heaptop,4,"time");
lf[323]=C_static_string(C_heaptop,8,"char-set");
lf[324]=C_static_string(C_heaptop,9,"condition");
lf[325]=C_static_string(C_heaptop,5,"queue");
lf[326]=C_static_string(C_heaptop,7,"promise");
lf[327]=C_static_string(C_heaptop,10,"hash-table");
lf[328]=C_static_string(C_heaptop,11,"environment");
lf[329]=C_static_string(C_heaptop,11,"end-of-file");
lf[330]=C_static_string(C_heaptop,9,"procedure");
lf[331]=C_static_string(C_heaptop,9,"structure");
lf[332]=C_static_string(C_heaptop,11,"byte-vector");
lf[333]=C_static_string(C_heaptop,11,"output-port");
lf[334]=C_static_string(C_heaptop,10,"input-port");
lf[335]=C_static_string(C_heaptop,4,"port");
lf[336]=C_static_string(C_heaptop,6,"string");
lf[337]=C_static_string(C_heaptop,7,"inexact");
lf[338]=C_static_string(C_heaptop,5,"exact");
lf[339]=C_static_string(C_heaptop,7,"integer");
lf[340]=C_static_string(C_heaptop,6,"number");
lf[341]=C_static_string(C_heaptop,4,"pair");
lf[342]=C_static_string(C_heaptop,6,"vector");
lf[343]=C_static_string(C_heaptop,4,"char");
lf[344]=C_static_string(C_heaptop,6,"symbol");
lf[345]=C_static_string(C_heaptop,7,"boolean");
lf[346]=C_static_string(C_heaptop,4,"null");
lf[347]=C_static_string(C_heaptop,4,"void");
lf[348]=C_static_lambda_info(C_heaptop,49,"(a3485 call-next-method540 object541 initargs542)");
lf[349]=C_static_string(C_heaptop,9,"primitive");
lf[350]=C_static_string(C_heaptop,15,"primitive-class");
lf[351]=C_static_lambda_info(C_heaptop,7,"(a3510)");
lf[352]=C_static_lambda_info(C_heaptop,57,"(a3504 call-next-method530 class531 slot532 allocator533)");
lf[353]=C_static_lambda_info(C_heaptop,12,"(a3571 x528)");
lf[354]=C_static_lambda_info(C_heaptop,12,"(a3577 o526)");
lf[355]=C_static_lambda_info(C_heaptop,33,"(collect to-process520 result521)");
lf[356]=C_static_lambda_info(C_heaptop,36,"(a3521 call-next-method517 class518)");
lf[357]=C_static_lambda_info(C_heaptop,36,"(a3614 call-next-method515 class516)");
lf[358]=C_static_lambda_info(C_heaptop,20,"(loop n508 inits509)");
lf[359]=C_static_string(C_heaptop,9,"(unnamed)");
lf[360]=C_static_lambda_info(C_heaptop,36,"(a3628 call-next-method503 class504)");
lf[361]=C_static_lambda_info(C_heaptop,20,"(loop n496 inits497)");
lf[362]=C_static_lambda_info(C_heaptop,36,"(a3701 call-next-method491 class492)");
lf[363]=C_static_lambda_info(C_heaptop,49,"(a3762 call-next-method486 method487 initargs488)");
lf[364]=C_static_string(C_heaptop,9,"(unnamed)");
lf[365]=C_static_string(C_heaptop,14,"has no methods");
lf[366]=C_static_lambda_info(C_heaptop,19,"(proc180 . args482)");
lf[367]=C_static_lambda_info(C_heaptop,50,"(a3790 call-next-method475 generic476 initargs477)");
lf[368]=C_static_string(C_heaptop,11,"(anonymous)");
lf[369]=C_static_lambda_info(C_heaptop,12,"(a3897 o459)");
lf[370]=C_static_lambda_info(C_heaptop,17,"(a3903 o460 n461)");
lf[371]=C_static_lambda_info(C_heaptop,19,"(allocator init457)");
lf[372]=C_static_lambda_info(C_heaptop,7,"(a3939)");
lf[373]=C_static_lambda_info(C_heaptop,15,"(a3925 slot465)");
lf[374]=C_h_intern(&lf[374],9,"substring");
lf[375]=C_static_string(C_heaptop,18,"invalid class name");
lf[376]=C_static_lambda_info(C_heaptop,12,"(a4012 s447)");
lf[377]=C_static_lambda_info(C_heaptop,48,"(a3845 call-next-method443 class444 initargs445)");
lf[378]=C_static_lambda_info(C_heaptop,49,"(a4040 call-next-method440 object441 initargs442)");
lf[379]=C_static_string(C_heaptop,25,"can not initialize object");
lf[380]=C_static_lambda_info(C_heaptop,49,"(a4051 call-next-method437 object438 initargs439)");
lf[381]=C_static_string(C_heaptop,33,"call-next-method: no methods left");
lf[382]=C_static_lambda_info(C_heaptop,8,"(f_4073)");
lf[383]=C_static_lambda_info(C_heaptop,18,"(one-step tail429)");
lf[384]=C_static_lambda_info(C_heaptop,27,"(f_4068 methods426 args427)");
lf[385]=C_static_lambda_info(C_heaptop,38,"(a4065 call-next-method424 generic425)");
lf[386]=C_static_string(C_heaptop,32,"two methods are equally specific");
lf[387]=C_static_string(C_heaptop,33,"fewer arguments than specializers");
lf[388]=C_static_lambda_info(C_heaptop,36,"(loop specls1417 specls2418 args419)");
lf[389]=C_static_lambda_info(C_heaptop,28,"(f_4120 m1413 m2414 args415)");
lf[390]=C_static_lambda_info(C_heaptop,38,"(a4117 call-next-method411 generic412)");
lf[391]=C_static_lambda_info(C_heaptop,19,"(a4236 m1409 m2410)");
lf[392]=C_h_intern(&lf[392],4,"sort");
lf[393]=C_static_lambda_info(C_heaptop,36,"(check-applicable list1403 list2404)");
lf[394]=C_static_lambda_info(C_heaptop,17,"(a4249 method401)");
lf[395]=C_static_lambda_info(C_heaptop,16,"(f_4216 args399)");
lf[396]=C_static_lambda_info(C_heaptop,38,"(a4213 call-next-method397 generic398)");
lf[397]=C_static_lambda_info(C_heaptop,16,"(f_4371 args389)");
lf[398]=C_static_string(C_heaptop,45,"Unable to find original compute-apply-generic");
lf[399]=C_static_lambda_info(C_heaptop,11,"(lp lis387)");
lf[400]=C_static_lambda_info(C_heaptop,16,"(f_4430 args392)");
lf[401]=C_static_lambda_info(C_heaptop,18,"(f_4314 . args373)");
lf[402]=C_static_lambda_info(C_heaptop,38,"(a4311 call-next-method371 generic372)");
lf[403]=C_static_string(C_heaptop,21,"compute-apply-methods");
lf[404]=C_static_string(C_heaptop,29,"compute-method-more-specific\077");
lf[405]=C_static_string(C_heaptop,15,"compute-methods");
lf[406]=C_static_string(C_heaptop,21,"compute-apply-generic");
lf[407]=C_static_string(C_heaptop,13,"compute-slots");
lf[408]=C_static_string(C_heaptop,11,"compute-cpl");
lf[409]=C_static_string(C_heaptop,25,"compute-getter-and-setter");
lf[410]=C_static_string(C_heaptop,17,"allocate-instance");
lf[411]=C_static_string(C_heaptop,10,"initialize");
lf[412]=C_static_string(C_heaptop,6,"method");
lf[413]=C_static_string(C_heaptop,7,"generic");
lf[414]=C_static_string(C_heaptop,12,"entity-class");
lf[415]=C_static_string(C_heaptop,15,"procedure-class");
lf[416]=C_static_lambda_info(C_heaptop,8,"(f_4560)");
lf[417]=C_static_lambda_info(C_heaptop,12,"(a4557 s330)");
lf[418]=C_static_string(C_heaptop,6,"object");
lf[419]=C_static_string(C_heaptop,3,"top");
lf[420]=C_static_lambda_info(C_heaptop,12,"(a4626 o301)");
lf[421]=C_static_lambda_info(C_heaptop,17,"(a4636 o304 n305)");
lf[422]=C_static_lambda_info(C_heaptop,18,"(loop lst299 i300)");
lf[423]=C_h_intern(&lf[423],9,"randomize");
lf[424]=C_static_lambda_info(C_heaptop,19,"(a4646 x192 out193)");
lf[425]=C_h_intern(&lf[425],27,"\003sysregister-record-printer");
lf[426]=C_static_lambda_info(C_heaptop,19,"(a4652 x147 out148)");
lf[427]=C_h_intern(&lf[427],17,"register-feature!");
lf[428]=C_h_intern(&lf[428],8,"tinyclos");
lf[429]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,430);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_788,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k786 */
static void f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_788,2,t0,t1);}
t2=C_mutate(&lf[2],lf[3]);
t3=C_mutate(&lf[4],lf[5]);
t4=C_mutate(&lf[6],lf[7]);
t5=C_mutate(&lf[8],lf[9]);
t6=C_mutate(&lf[10],lf[11]);
t7=C_mutate(&lf[12],lf[13]);
t8=C_mutate(&lf[14],lf[15]);
t9=C_mutate(&lf[16],lf[17]);
t10=C_mutate(&lf[18],lf[19]);
t11=C_mutate(&lf[20],lf[21]);
t12=C_mutate(&lf[22],lf[23]);
t13=C_mutate(&lf[24],lf[25]);
t14=C_mutate(&lf[26],lf[27]);
t15=C_mutate(&lf[28],lf[29]);
t16=C_mutate(&lf[30],lf[31]);
t17=C_mutate(&lf[32],lf[33]);
t18=C_mutate(&lf[34],lf[35]);
t19=C_mutate(&lf[36],lf[37]);
t20=C_mutate(&lf[38],lf[39]);
t21=C_mutate(&lf[40],lf[41]);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[427]+1);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,lf[428]);}

/* k809 in k786 */
static void f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=lf[44],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[45],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_891,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[47],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_894,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[53],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp));
t6=lf[55]=C_SCHEME_FALSE;;
t7=lf[56]=C_SCHEME_FALSE;;
t8=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1172,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[79],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=lf[426],tmp=(C_word)a,a+=3,tmp);
t13=*((C_word*)lf[425]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,lf[80],t12);}

/* a4652 in k809 in k786 */
static void f_4653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4653,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[266]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k1329 in k809 in k786 */
static void f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[303]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1333 in k1329 in k809 in k786 */
static void f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=lf[86],tmp=(C_word)a,a+=3,tmp);
t4=C_mutate(&lf[87],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1342,a[2]=t3,a[3]=lf[91],tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4647,a[2]=lf[424],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[425]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,lf[89],t6);}

/* a4646 in k1333 in k1329 in k809 in k786 */
static void f_4647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4647,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[266]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k1419 in k1333 in k1329 in k809 in k786 */
static void f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,lf[80],*((C_word*)lf[83]+1));
t3=C_mutate(&lf[92],t2);
t4=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[158],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[164],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=lf[167],tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[423]+1);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}

/* k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=lf[201],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[202],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=lf[205],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[177],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=lf[206],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[207]+1,lf[202]);
t6=C_mutate((C_word*)lf[208]+1,lf[177]);
t7=C_mutate(&lf[204],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=lf[211],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=lf[212],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2215,a[2]=lf[213],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=lf[214],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2227,a[2]=lf[216],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=lf[218],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=lf[220],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2245,a[2]=lf[222],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=lf[224],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[193],lf[225]);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=t19,a[3]=lf[422],tmp=(C_word)a,a+=4,tmp));
t21=((C_word*)t19)[1];
f_4591(t21,t17,lf[193],C_fix(0));}

/* loop in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4591,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=t3,a[3]=lf[420],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4637,a[2]=t3,a[3]=lf[421],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4609,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
t11=(C_word)C_fixnum_increase(t3);
t13=t9;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k4607 in loop in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4636 in loop in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4637,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
t5=(C_word)C_fixnum_plus(t4,C_fix(3));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t2,t5,t3));}

/* a4626 in loop in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4627,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=(C_word)C_fixnum_plus(t3,C_fix(3));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_slot(t2,t4));}

/* k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=C_mutate(&lf[210],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_length(lf[193]);
f_1314(t3,C_SCHEME_FALSE,t4);}

/* k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1,t1);
t3=*((C_word*)lf[169]+1);
t4=*((C_word*)lf[169]+1);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t7))(9,t7,t6,*((C_word*)lf[169]+1),lf[172],lf[419],lf[171],C_SCHEME_END_OF_LIST,lf[183],C_SCHEME_END_OF_LIST);}

/* k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=C_mutate((C_word*)lf[226]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[226]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[418],lf[171],t4,lf[183],C_SCHEME_END_OF_LIST);}

/* k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
t2=C_mutate((C_word*)lf[227]+1,t1);
t3=*((C_word*)lf[169]+1);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=(C_word)C_i_setslot(t3,C_fix(3),t4);
t6=*((C_word*)lf[169]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[192]+1),lf[193]);}

/* k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(4),t1);
t3=*((C_word*)lf[169]+1);
t4=(C_word)C_a_i_list(&a,3,*((C_word*)lf[169]+1),*((C_word*)lf[227]+1),*((C_word*)lf[226]+1));
t5=(C_word)C_i_setslot(t3,C_fix(5),t4);
t6=*((C_word*)lf[169]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[192]+1),lf[193]);}

/* k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(6),t1);
t3=*((C_word*)lf[169]+1);
t4=(C_word)C_i_length(lf[193]);
t5=(C_word)C_i_setslot(t3,C_fix(7),t4);
t6=*((C_word*)lf[169]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4558,a[2]=lf[417],tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[193]);}

/* a4557 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4558,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=lf[416],tmp=(C_word)a,a+=3,tmp));}

/* f_4560 in a4557 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2308,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(8),t1);
t3=*((C_word*)lf[169]+1);
t4=(C_word)C_i_set_i_slot(t3,C_fix(9),C_SCHEME_END_OF_LIST);
t5=*((C_word*)lf[169]+1);
t6=(C_word)C_i_setslot(t5,C_fix(10),lf[228]);
t7=*((C_word*)lf[169]+1);
t8=(C_word)C_random_fixnum(C_fix(65536));
t9=(C_word)C_i_setslot(t7,C_fix(2),t8);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t12=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t12))(9,t12,t10,*((C_word*)lf[169]+1),lf[172],lf[415],lf[171],t11,lf[183],C_SCHEME_END_OF_LIST);}

/* k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[229]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[414],lf[171],t4,lf[183],C_SCHEME_END_OF_LIST);}

/* k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=C_mutate((C_word*)lf[170]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=(C_word)C_a_i_list(&a,1,lf[195]);
t6=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t6))(9,t6,t3,*((C_word*)lf[170]+1),lf[172],lf[413],lf[171],t4,lf[183],t5);}

/* k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=C_mutate((C_word*)lf[194]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=(C_word)C_a_i_list(&a,2,lf[200],lf[199]);
t6=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t6))(9,t6,t3,*((C_word*)lf[169]+1),lf[172],lf[412],lf[171],t4,lf[183],t5);}

/* k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=C_mutate((C_word*)lf[198]+1,t1);
t3=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=lf[232],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2344,a[2]=lf[235],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[236]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2373,a[2]=lf[237],tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[411]);}

/* k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=C_mutate((C_word*)lf[238]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[410]);}

/* k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=C_mutate((C_word*)lf[239]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[409]);}

/* k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=C_mutate((C_word*)lf[240]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[408]);}

/* k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=C_mutate((C_word*)lf[241]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[407]);}

/* k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=C_mutate((C_word*)lf[242]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[406]);}

/* k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=C_mutate((C_word*)lf[243]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[405]);}

/* k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=C_mutate((C_word*)lf[244]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[404]);}

/* k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=C_mutate((C_word*)lf[245]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[403]);}

/* k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=C_mutate((C_word*)lf[246]+1,t1);
t3=(C_word)C_a_i_list(&a,4,*((C_word*)lf[243]+1),*((C_word*)lf[244]+1),*((C_word*)lf[245]+1),*((C_word*)lf[246]+1));
t4=C_mutate((C_word*)lf[247]+1,t3);
t5=C_mutate((C_word*)lf[248]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=lf[251],tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[243]+1);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_block_size(t6);
t9=(C_word)C_fixnum_difference(t8,C_fix(2));
t10=(C_word)C_slot(t6,t9);
t11=(C_word)C_i_setslot(t10,C_fix(1),t7);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=lf[402],tmp=(C_word)a,a+=3,tmp);
t16=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t16))(4,t16,t13,t14,t15);}

/* a4311 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4312,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t3,a[3]=lf[401],tmp=(C_word)a,a+=4,tmp));}

/* f_4314 in a4311 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4314(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4314r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4314r(t0,t1,t2);}}

static void f_4314r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t3=((C_word*)t0)[2];
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(2));
t6=(C_word)C_slot(t3,t5);
t7=(C_word)C_slot(t6,C_fix(4));
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_not(((C_word*)t9)[1]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4466,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t11)){
t13=t12;
f_4466(t13,t11);}
else{
t13=(C_word)C_slot(((C_word*)t9)[1],C_fix(0));
t14=(C_word)C_eqp(lf[56],t13);
t15=t12;
f_4466(t15,(C_word)C_i_not(t14));}}

/* k4464 */
static void C_fcall f_4466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4466,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_fixnum_shift_left(C_fix((C_word)C_METHOD_CACHE_SIZE),C_fix(1));
t4=*((C_word*)lf[81]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
f_4321(t2,C_SCHEME_UNDEFINED);}}

/* k980 in k4464 */
static void f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[56],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
t5=((C_word*)((C_word*)t0)[4])[1];
t6=(C_word)C_block_size(t4);
t7=(C_word)C_fixnum_difference(t6,C_fix(2));
t8=(C_word)C_slot(t4,t7);
t9=((C_word*)t0)[2];
f_4321(t9,(C_word)C_i_setslot(t8,C_fix(4),t5));}

/* k4319 */
static void C_fcall f_4321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4321,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(lf[55])){
t3=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[93]+1),((C_word*)t0)[4]);}
else{
t3=t2;
f_4324(2,t3,C_SCHEME_FALSE);}}

/* k4322 in k4319 */
static void f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[4];
t4=t2;
f_4327(t4,(C_word)stub196(C_SCHEME_UNDEFINED,t3,lf[92]));}
else{
t3=t2;
f_4327(t3,C_SCHEME_FALSE);}}

/* k4325 in k4322 in k4319 */
static void C_fcall f_4327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4327,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)((C_word*)t0)[4])[1];
t4=((C_word*)t0)[3];
t5=t2;
f_4330(t5,(C_word)stub81(C_SCHEME_UNDEFINED,t3,t1,t4));}
else{
t3=t2;
f_4330(t3,C_SCHEME_FALSE);}}

/* k4328 in k4325 in k4322 in k4319 */
static void C_fcall f_4330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4330,NULL,2,t0,t1);}
if(C_truep((C_word)C_immp(t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[2],*((C_word*)lf[247]+1)))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t3;
f_4367(t5,(C_word)C_i_memq(t4,*((C_word*)lf[247]+1)));}
else{
t4=t3;
f_4367(t4,C_SCHEME_FALSE);}}
else{
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k4365 in k4328 in k4325 in k4322 in k4319 */
static void C_fcall f_4367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4367,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4383,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=lf[202];
f_2078(4,t5,t4,((C_word*)t0)[3],lf[195]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[246]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k4424 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4429,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[244]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4435 in k4424 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4427 in k4424 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4342(t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4430,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[400],tmp=(C_word)a,a+=5,tmp));}

/* f_4430 in k4427 in k4424 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4430,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k4381 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=t3,a[3]=lf[399],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4385(t5,((C_word*)t0)[2],t1);}

/* lp in k4381 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void C_fcall f_4385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4385,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,lf[398]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=lf[202];
f_2078(4,t5,t3,t4,lf[200]);}}

/* k4417 in lp in k4381 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(t2,C_fix(1));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[2])[1];
f_4385(t5,((C_word*)t0)[4],t4);}}

/* k4377 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[202];
f_2078(4,t2,((C_word*)t0)[2],t1,lf[199]);}

/* k4368 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4342(t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=t1,a[3]=lf[397],tmp=(C_word)a,a+=4,tmp));}

/* f_4371 in k4368 in k4365 in k4328 in k4325 in k4322 in k4319 */
static void f_4371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4371,3,t0,t1,t2);}
C_apply(5,0,t1,((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4340 in k4328 in k4325 in k4322 in k4319 */
static void C_fcall f_4342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4342,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[4])?lf[55]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=(C_word)C_i_setslot(t4,((C_word*)t0)[4],((C_word*)t0)[2]);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t7=t2;
f_4345(t7,(C_word)C_i_setslot(t4,t6,t1));}
else{
t4=t2;
f_4345(t4,C_SCHEME_UNDEFINED);}}

/* k4343 in k4340 in k4328 in k4325 in k4322 in k4319 */
static void C_fcall f_4345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4304 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[243]+1),t1);}

/* k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=lf[396],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a4213 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4214,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=t3,a[3]=lf[395],tmp=(C_word)a,a+=4,tmp));}

/* f_4216 in a4213 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=t2,a[3]=lf[394],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4302,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=lf[202];
f_2078(4,t6,t5,((C_word*)t0)[2],lf[195]);}

/* k4300 */
static void f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_941(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4249 */
static void f_4250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4250,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=lf[202];
f_2078(4,t4,t3,t2,lf[200]);}

/* k4256 in a4249 */
static void f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=t3,a[3]=lf[393],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4260(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* check-applicable in k4256 in a4249 */
static void C_fcall f_4260(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4260,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2632,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t5);}}}

/* k2634 in check-applicable in k4256 in a4249 */
static void f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[202];
f_2078(4,t2,((C_word*)t0)[2],t1,lf[182]);}

/* k2630 in check-applicable in k4256 in a4249 */
static void f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],t1))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4260(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4218 */
static void f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(C_word)C_i_nullp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_4229(t4,t2);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t5=t3;
f_4229(t5,(C_word)C_i_nullp(t4));}}

/* k4227 in k4218 */
static void C_fcall f_4229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4229,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[245]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4230 in k4227 in k4218 */
static void f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=lf[391],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[392]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4236 in k4230 in k4227 in k4218 */
static void f_4237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4237,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,t3,((C_word*)t0)[2]);}

/* k4206 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[244]+1),t1);}

/* k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=lf[390],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a4117 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4118,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4120,a[2]=t3,a[3]=lf[389],tmp=(C_word)a,a+=4,tmp));}

/* f_4120 in a4117 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4120,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4128,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=lf[202];
f_2078(4,t6,t5,t2,lf[200]);}

/* k4126 */
static void f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=lf[202];
f_2078(4,t3,t2,((C_word*)t0)[2],lf[200]);}

/* k4130 in k4126 */
static void f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4134,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=lf[388],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4134(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k4130 in k4126 */
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4134,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?(C_word)C_i_nullp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[386],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t4))){
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[387],((C_word*)t0)[3]);}
else{
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t3,C_fix(0));
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_eqp(t7,t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_slot(t3,C_fix(1));
t13=(C_word)C_slot(t4,C_fix(1));
t18=t1;
t19=t11;
t20=t12;
t21=t13;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t11=t1;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2650,a[2]=t8,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2654,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t9);}}}}}}

/* k2652 in loop in k4130 in k4126 */
static void f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[202];
f_2078(4,t2,((C_word*)t0)[2],t1,lf[182]);}

/* k2648 in loop in k4130 in k4126 */
static void f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_memq(((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(((C_word*)t0)[2],t2));}

/* k4110 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[245]+1),t1);}

/* k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=lf[385],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a4065 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4066,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4068,a[2]=t3,a[3]=lf[384],tmp=(C_word)a,a+=4,tmp));}

/* f_4068 in a4065 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4068,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=lf[383],tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=((C_word*)t5)[1];
f_4071(t8,t7,t2);}

/* k4106 */
static void f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* one-step */
static void C_fcall f_4071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4071,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=lf[382],tmp=(C_word)a,a+=7,tmp));}

/* f_4073 in one-step */
static void f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[381],((C_word*)t0)[2]);}
else{
t3=t2;
f_4077(2,t3,C_SCHEME_UNDEFINED);}}

/* k4075 */
static void f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=lf[202];
f_2078(4,t4,t2,t3,lf[199]);}

/* k4082 in k4075 */
static void f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_4071(t4,t2,t3);}

/* k4086 in k4082 in k4075 */
static void f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4058 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[246]+1),t1);}

/* k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[226]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4052,a[2]=lf[380],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a4051 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4052,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[379],t3);}

/* k4044 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4041,a[2]=lf[378],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a4040 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4041,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4033 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3846,a[2]=lf[377],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3846,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3850,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=t2;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=f_891(((C_word*)t0)[4],lf[171],C_SCHEME_END_OF_LIST);
t4=lf[177];
f_2164(5,t4,t2,((C_word*)t0)[2],lf[171],t3);}

/* k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=lf[376],tmp=(C_word)a,a+=3,tmp);
t4=f_891(((C_word*)t0)[4],lf[183],C_SCHEME_END_OF_LIST);
t5=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a4012 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_4013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4013,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2)));}

/* k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=f_891(((C_word*)t0)[4],lf[172],lf[368]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3862,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=t3;
f_3862(2,t4,t2);}
else{
t4=*((C_word*)lf[159]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[160],lf[238],lf[375],t2);}}}

/* k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3868,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=lf[177];
f_2164(5,t4,t3,((C_word*)t0)[3],lf[183],((C_word*)t0)[2]);}

/* k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3994 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1);}

/* k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],C_fix(0));
t6=(C_word)C_eqp(C_make_character(60),t5);
if(C_truep(t6)){
t7=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t7);
t9=t4;
f_3961(t9,(C_word)C_eqp(C_make_character(62),t8));}
else{
t7=t4;
f_3961(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3961(t5,C_SCHEME_FALSE);}}

/* k3959 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=*((C_word*)lf[374]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t2);}
else{
t2=((C_word*)t0)[3];
f_3958(2,t2,((C_word*)t0)[2]);}}

/* k3956 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[172],t1);}

/* k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[242]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3880,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[2],lf[181],t1);}

/* k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_eqp(C_fix(11),t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=(C_word)C_random_fixnum(C_fix(65536));
t7=t2;
f_3883(t7,(C_word)C_i_setslot(t5,C_fix(2),t6));}
else{
t5=t2;
f_3883(t5,C_SCHEME_UNDEFINED);}}

/* k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3883,NULL,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=t5,a[3]=t3,a[4]=lf[371],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3926,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=lf[373],tmp=(C_word)a,a+=5,tmp);
t9=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a3925 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3926,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3938,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=lf[372],tmp=(C_word)a,a+=6,tmp);
C_call_with_values(4,0,t4,t5,*((C_word*)lf[186]+1));}

/* a3939 in a3925 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=*((C_word*)lf[240]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3936 in a3925 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3909 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[4],lf[180],((C_word*)((C_word*)t0)[2])[1]);}

/* k3912 in k3909 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3922 in k3912 in k3909 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[179],t1);}

/* k3915 in k3912 in k3909 in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[178],((C_word*)t0)[2]);}

/* allocator in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3884,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3898,a[2]=t3,a[3]=lf[369],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3904,a[2]=t3,a[3]=lf[370],tmp=(C_word)a,a+=4,tmp);
C_values(4,0,t1,t8,t9);}

/* a3903 in allocator in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3904,4,t0,t1,t2,t3);}
f_1787(t1,t2,((C_word*)t0)[2],t3);}

/* a3897 in allocator in k3881 in k3878 in k3875 in k3872 in k3869 in k3866 in k3860 in k3854 in k3851 in k3848 in a3845 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3898,3,t0,t1,t2);}
f_1720(t1,t2,((C_word*)t0)[2]);}

/* k3838 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3785,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3791,a[2]=lf[367],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3790 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3791,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3795,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=t2;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3793 in a3790 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[4],lf[195],C_SCHEME_END_OF_LIST);}

/* k3796 in k3793 in a3790 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=f_891(((C_word*)t0)[3],lf[172],lf[364]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(2));
t6=(C_word)C_slot(t2,t5);
t7=(C_word)C_i_setslot(t6,C_fix(3),t3);
t8=((C_word*)t0)[4];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[4],a[3]=lf[366],tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_block_size(t8);
t11=(C_word)C_fixnum_difference(t10,C_fix(2));
t12=(C_word)C_slot(t8,t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_i_setslot(t12,C_fix(1),t9));}

/* proc180 in k3796 in k3793 in a3790 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3805(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],((C_word*)t0)[2]);}

/* k3783 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[198]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=lf[363],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3762 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3763,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3767,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=t2;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3765 in a3762 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_894(t3,((C_word*)t0)[2],lf[200],C_SCHEME_END_OF_LIST);}

/* k3779 in k3765 in a3762 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[200],t1);}

/* k3768 in k3765 in a3762 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_894(t2,((C_word*)t0)[2],lf[199],C_SCHEME_END_OF_LIST);}

/* k3775 in k3768 in k3765 in a3762 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[199],t1);}

/* k3755 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=lf[362],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3701 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3702,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=lf[202];
f_2078(4,t5,t4,t3,lf[179]);}

/* k3704 in a3701 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
f_1314(t2,((C_word*)t0)[2],t3);}

/* k3707 in k3704 in a3701 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=t3,a[3]=t1,a[4]=lf[361],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3714(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* loop in k3707 in k3704 in a3701 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=t2;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3724,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t3,C_fix(0));
t7=t6;
((C_proc2)C_retrieve_proc(t7))(2,t7,t5);}}

/* k3722 in loop in k3707 in k3704 in a3701 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_setslot(((C_word*)t0)[6],t2,t1);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_3714(t6,((C_word*)t0)[2],t4,t5);}

/* k3694 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[239]+1),t1);}

/* k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[170]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=lf[360],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3628 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3629,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3633,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=lf[202];
f_2078(4,t5,t4,t3,lf[179]);}

/* k3631 in a3628 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
t4=lf[87];
f_1342(t4,t2,((C_word*)t0)[2],t3,lf[359]);}

/* k3634 in k3631 in a3628 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3641,a[2]=t3,a[3]=t1,a[4]=lf[358],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3641(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* loop in k3634 in k3631 in a3628 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3641(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3641,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=t2;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3651,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t3,C_fix(0));
t7=t6;
((C_proc2)C_retrieve_proc(t7))(2,t7,t5);}}

/* k3649 in loop in k3634 in k3631 in a3628 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_difference(t2,C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(5));
t6=(C_word)C_i_setslot(t4,t5,t1);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t9=((C_word*)((C_word*)t0)[3])[1];
f_3641(t9,((C_word*)t0)[2],t7,t8);}

/* k3621 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[239]+1),t1);}

/* k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=lf[357],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3614 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3615,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,*((C_word*)lf[190]+1));}

/* k3607 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[241]+1),t1);}

/* k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3522,a[2]=lf[356],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3522,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3530,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=lf[202];
f_2078(4,t7,t6,t3,lf[182]);}

/* k3603 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[189]+1),t1);}

/* k3599 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[66]+1),t1);}

/* k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=t3,a[3]=lf[355],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3532(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3532(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3532,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3551,a[2]=t7,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3578,a[2]=t7,a[3]=t5,a[4]=lf[354],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
f_941(t8,t9,t10);}}

/* a3577 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3578,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}

/* k3549 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3562,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=lf[353],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[2])[1]);}

/* a3571 in k3549 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3572,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3568 in k3549 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[66]+1),t1);}

/* k3564 in k3549 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3560 in k3549 in collect in k3528 in a3521 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3532(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3514 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[242]+1),t1);}

/* k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=lf[352],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3504 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3505,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=lf[351],tmp=(C_word)a,a+=3,tmp);
t7=t5;
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t6);}

/* a3510 in a3504 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k3497 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[240]+1),t1);}

/* k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=lf[254],tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[350],lf[171],t4,lf[183],C_SCHEME_END_OF_LIST);}

/* k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=C_mutate((C_word*)lf[255]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[226]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[171],t4,lf[183],C_SCHEME_END_OF_LIST,lf[172],lf[349]);}

/* k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=C_mutate((C_word*)lf[256]+1,t1);
t3=C_mutate(&lf[257],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2703,a[2]=lf[258],tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_list(&a,1,*((C_word*)lf[256]+1));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=lf[348],tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* a3485 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3486,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k3478 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t2,lf[347],C_SCHEME_END_OF_LIST);}

/* k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=C_mutate((C_word*)lf[98]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[346],C_SCHEME_END_OF_LIST);}

/* k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[345],C_SCHEME_END_OF_LIST);}

/* k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[344],C_SCHEME_END_OF_LIST);}

/* k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[343],C_SCHEME_END_OF_LIST);}

/* k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[342],C_SCHEME_END_OF_LIST);}

/* k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[341],C_SCHEME_END_OF_LIST);}

/* k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
t2=C_mutate((C_word*)lf[102]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[340],C_SCHEME_END_OF_LIST);}

/* k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
t2=C_mutate((C_word*)lf[259]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[339],(C_word)C_a_i_list(&a,1,*((C_word*)lf[259]+1)));}

/* k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[338],(C_word)C_a_i_list(&a,1,*((C_word*)lf[103]+1)));}

/* k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[337],(C_word)C_a_i_list(&a,1,*((C_word*)lf[259]+1)));}

/* k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[336],C_SCHEME_END_OF_LIST);}

/* k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[335],C_SCHEME_END_OF_LIST);}

/* k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=C_mutate((C_word*)lf[260]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[260]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[334],lf[171],t4,lf[183],C_SCHEME_END_OF_LIST);}

/* k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[260]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[333],lf[171],t4,lf[183],C_SCHEME_END_OF_LIST);}

/* k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[332],C_SCHEME_END_OF_LIST);}

/* k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[331],C_SCHEME_END_OF_LIST);}

/* k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=C_mutate((C_word*)lf[153]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[330],(C_word)C_a_i_list(&a,1,*((C_word*)lf[229]+1)));}

/* k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[329],C_SCHEME_END_OF_LIST);}

/* k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=C_mutate((C_word*)lf[99]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[328],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[327],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[326],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[325],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[324],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[323],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[322],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[321],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[320],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[319],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[318],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[317],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2844,2,t0,t1);}
t2=C_mutate((C_word*)lf[138]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[316],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=C_mutate((C_word*)lf[140]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[315],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[314],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=C_mutate((C_word*)lf[144]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[313],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[312],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[311],(C_word)C_a_i_list(&a,1,*((C_word*)lf[114]+1)));}

/* k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[310],C_SCHEME_END_OF_LIST);}

/* k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[309],(C_word)C_a_i_list(&a,1,*((C_word*)lf[110]+1)));}

/* k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[308],(C_word)C_a_i_list(&a,1,*((C_word*)lf[110]+1)));}

/* k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[307],C_SCHEME_END_OF_LIST);}

/* k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
f_2703(t3,lf[306],(C_word)C_a_i_list(&a,1,*((C_word*)lf[153]+1)));}

/* k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=C_mutate((C_word*)lf[152]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,t3,*((C_word*)lf[169]+1),lf[172],lf[304],lf[171],t4,lf[183],lf[305]);}

/* k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=C_mutate((C_word*)lf[261]+1,t1);
t3=lf[55]=C_SCHEME_TRUE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[303]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2898,a[2]=t1,a[3]=lf[265],tmp=(C_word)a,a+=4,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[302]);}

/* k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[233]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[301]);}

/* k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=C_mutate((C_word*)lf[267]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=lf[300],tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a3428 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3429r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3429r(t0,t1,t2,t3,t4);}}

static void f_3429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3437(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3437(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3435 in a3428 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3443 in k3435 in a3428 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[202];
f_2078(4,t2,((C_word*)t0)[2],t1,lf[172]);}

/* k3439 in k3435 in a3428 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[299],t1);}

/* k3421 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[266]+1),t1);}

/* k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[256]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=lf[298],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3391 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3392r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3392r(t0,t1,t2,t3,t4);}}

static void f_3392r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3400,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3400(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3400(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3398 in a3391 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[297]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3384 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[266]+1),t1);}

/* k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3351,a[2]=lf[296],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3350 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3351r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3351r(t0,t1,t2,t3,t4);}}

static void f_3351r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3359(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3359(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3357 in a3350 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3363,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=lf[202];
f_2078(4,t3,t2,((C_word*)t0)[2],lf[172]);}

/* k3361 in k3357 in a3350 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[295],t1);}

/* k3343 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[266]+1),t1);}

/* k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=lf[294],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3297 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3298r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3298r(t0,t1,t2,t3,t4);}}

static void f_3298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3306(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3306(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3304 in a3297 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_block_size(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(2));
t5=(C_word)C_slot(t2,t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,((C_word*)t0)[2],t1,lf[293],t6);}

/* k3290 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[266]+1),t1);}

/* k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[227]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=lf[292],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3235r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3235r(t0,t1,t2,t3,t4);}}

static void f_3235r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3239,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3242(2,t4,*((C_word*)lf[285]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3242(2,t5,(C_word)C_i_car(t2));}
else{
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3269,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[202];
f_2078(4,t4,t3,((C_word*)t0)[2],lf[172]);}

/* k3267 in k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[291],t1);}

/* k3243 in k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[290],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=lf[202];
f_2078(4,t4,t3,((C_word*)t0)[2],lf[181]);}

/* k3263 in k3243 in k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[264]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3249 in k3243 in k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3261,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[207]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}

/* k3259 in a3249 in k3243 in k3240 in k3237 in a3234 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[283]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[289],((C_word*)t0)[2],t1);}

/* k3227 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[267]+1),t1);}

/* k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[169]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3194,a[2]=lf[288],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3193 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3194r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3194r(t0,t1,t2,t3,t4);}}

static void f_3194r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3202(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3202(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3200 in a3193 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3206,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=lf[202];
f_2078(4,t3,t2,((C_word*)t0)[2],lf[172]);}

/* k3204 in k3200 in a3193 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[287],t1);}

/* k3186 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[267]+1),t1);}

/* k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,*((C_word*)lf[194]+1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3141,a[2]=lf[286],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a3140 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3141r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3141r(t0,t1,t2,t3,t4);}}

static void f_3141r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3149,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3149(2,t6,*((C_word*)lf[285]+1));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3149(2,t7,(C_word)C_i_car(t4));}
else{
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3147 in a3140 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_block_size(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(2));
t5=(C_word)C_slot(t2,t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=*((C_word*)lf[283]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,((C_word*)t0)[2],t1,lf[284],t6);}

/* k3133 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[267]+1),t1);}

/* k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=*((C_word*)lf[233]+1);
t3=C_mutate(&lf[268],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2962,a[2]=t2,a[3]=lf[270],tmp=(C_word)a,a+=4,tmp));
t4=*((C_word*)lf[236]+1);
t5=*((C_word*)lf[248]+1);
t6=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=t4,a[3]=t5,a[4]=lf[272],tmp=(C_word)a,a+=5,tmp));
t7=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3014,a[2]=lf[274],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=lf[276],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=lf[278],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=lf[281],tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,*((C_word*)lf[261]+1));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3107,a[2]=lf[282],tmp=(C_word)a,a+=3,tmp);
t15=*((C_word*)lf[236]+1);
((C_proc4)C_retrieve_proc(t15))(4,t15,t12,t13,t14);}

/* a3106 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3107,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3114,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=t5;
f_3114(t7,(C_word)C_eqp(lf[280],t6));}
else{
t6=t5;
f_3114(t6,C_SCHEME_FALSE);}}

/* k3112 in a3106 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_3114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=lf[177];
f_2164(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[280],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3099 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[248]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[238]+1),t1);}

/* k3095 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##tinyclos#make-instance-from-pointer in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3077,4,t0,t1,t2,t3);}
if(C_truep(t2)){
if(C_truep((C_word)C_null_pointerp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=*((C_word*)lf[168]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,lf[280],t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* instance-of? in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3062,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3064 in instance-of? in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=*((C_word*)lf[275]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}}

/* subclass? in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3049,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3058 in subclass? in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_memq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* instance? in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3014,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_i_structurep(t3,lf[80]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
if(C_truep((C_word)C_i_closurep(t5))){
t6=(C_word)C_block_size(t5);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(3)))){
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=(C_word)C_slot(t5,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(*((C_word*)lf[83]+1),t8));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* ##tinyclos#add-global-method in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3001,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3005,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=lf[268];
f_2962(t7,t6,t2,t3);}

/* k3003 in ##tinyclos#add-global-method in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3008,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3012,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3010 in k3003 in ##tinyclos#add-global-method in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3006 in k3003 in ##tinyclos#add-global-method in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##tinyclos#ensure-generic in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2962,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2969,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_closurep(t4))){
t6=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(3)))){
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=(C_word)C_slot(t4,t7);
t9=t5;
f_2969(t9,(C_word)C_eqp(*((C_word*)lf[83]+1),t8));}
else{
t7=t5;
f_2969(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_2969(t6,C_SCHEME_FALSE);}}

/* k2967 in ##tinyclos#ensure-generic in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2969,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2974 in k2967 in ##tinyclos#ensure-generic in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2933 in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* initialize-slots in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2898,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[262]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2907,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[263],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2931,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2929 in initialize-slots in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[202];
f_2078(4,t2,((C_word*)t0)[2],t1,lf[181]);}

/* k2925 in initialize-slots in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[264]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2906 in initialize-slots in k2895 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2774 in k2770 in k2766 in k2762 in k2758 in k2754 in k2750 in k2746 in k2742 in k2738 in k2734 in k2730 in k2726 in k2722 in k2718 in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2907,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=f_891(((C_word*)t0)[4],t3,((C_word*)t0)[3]);
t5=(C_word)C_eqp(t4,((C_word*)t0)[3]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[208]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[2],t3,t4);}}

/* ##tinyclos#make-primitive-class in k2699 in k2695 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2703(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2703,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?(C_word)C_a_i_list(&a,1,*((C_word*)lf[256]+1)):t3);
t6=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t6))(9,t6,t1,*((C_word*)lf[255]+1),lf[171],t5,lf[183],C_SCHEME_END_OF_LIST,lf[172],t2);}

/* make in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2686(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2686r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2686r(t0,t1,t2,t3);}}

static void f_2686r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2690,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[239]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2688 in make in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[238]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2691 in k2688 in make in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2620 in k2617 in k2614 in k2611 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* proc180 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2589,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t2,a[3]=lf[252],tmp=(C_word)a,a+=4,tmp));}

/* f_2591 in proc180 in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2591(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2591r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2591r(t0,t1,t2);}}

static void f_2591r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2607,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=lf[202];
f_2078(4,t5,t4,((C_word*)t0)[2],lf[195]);}

/* k2605 */
static void f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=lf[202];
f_2078(4,t3,((C_word*)t0)[2],t2,lf[199]);}

/* k2597 */
static void f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2419,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2470,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=lf[202];
f_2078(4,t6,t5,t3,lf[200]);}

/* k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2480,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=lf[202];
f_2078(4,t5,t4,((C_word*)t0)[3],lf[195]);}

/* k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[250],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2482(t5,((C_word*)t0)[2],t1);}

/* filter-in-method in k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2482,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t5=lf[202];
f_2078(4,t5,t4,t3,lf[200]);}}

/* k2496 in filter-in-method in k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2498,2,t0,t1);}
t2=(C_word)C_i_length(t1);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_2482(t5,t3,t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[8],t2))){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=lf[249],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2532(t6,((C_word*)t0)[7],((C_word*)t0)[2],t1);}}}

/* check-method in k2496 in filter-in-method in k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2532,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(C_truep(t4)?(C_word)C_i_nullp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6));}
else{
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t3,C_fix(0));
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_slot(t3,C_fix(1));
t15=t1;
t16=t9;
t17=t10;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t11=((C_word*)((C_word*)t0)[2])[1];
f_2482(t11,t9,t10);}}}

/* k2568 in check-method in k2496 in filter-in-method in k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2512 in k2496 in filter-in-method in k2478 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2474 in k2468 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[195],t1);}

/* k2421 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],*((C_word*)lf[247]+1)))){
t3=(C_word)C_a_i_vector(&a,0);
t4=C_mutate(&lf[56],t3);
t5=t2;
f_2426(t5,t4);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(2));
t6=(C_word)C_slot(t3,t5);
t7=t2;
f_2426(t7,(C_word)C_i_set_i_slot(t6,C_fix(4),C_SCHEME_FALSE));}}

/* k2424 in k2421 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[243]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2427 in k2424 in k2421 in add-method in k2411 in k2407 in k2403 in k2399 in k2395 in k2391 in k2387 in k2383 in k2379 in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_difference(t2,C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t4,C_fix(1),t1));}

/* make-method in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2373,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[168]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t1,*((C_word*)lf[198]+1),lf[200],t2,lf[199],t3);}

/* make-generic in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2344(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2344r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2344r(t0,t1,t2);}}

static void f_2344r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2352(2,t4,lf[234]);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2352(2,t5,(C_word)C_i_car(t2));}
else{
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2350 in make-generic in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[168]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[194]+1),lf[172],t1);}

/* make-class in k2334 in k2330 in k2326 in k2322 in k2306 in k2294 in k2282 in k2273 in k2269 in k2262 in k2258 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2338,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[168]+1);
((C_proc9)C_retrieve_proc(t4))(9,t4,t1,*((C_word*)lf[169]+1),lf[172],lf[231],lf[171],t2,lf[183],t3);}

/* class-cpl in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2251,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[182]);}

/* method-procedure in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2245(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2245,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[199]);}

/* method-specializers in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[200]);}

/* generic-methods in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2233,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[195]);}

/* class-name in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2227,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[172]);}

/* class-slots in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2221,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[181]);}

/* class-direct-supers in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2215,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[171]);}

/* class-direct-slots in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2209,3,t0,t1,t2);}
t3=lf[202];
f_2078(4,t3,t1,t2,lf[183]);}

/* ##tinyclos#lookup-slot-info in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2182(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2182,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2186,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[169]+1));
if(C_truep(t5)){
t6=t4;
f_2186(2,t6,lf[210]);}
else{
t6=lf[202];
f_2078(4,t6,t4,t2,lf[178]);}}

/* k2184 in ##tinyclos#lookup-slot-info in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t3=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[209],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* ##tinyclos#slot-set! in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2164,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2168,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k2176 in ##tinyclos#slot-set! in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2182(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2166 in ##tinyclos#slot-set! in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##tinyclos#slot-ref in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2078,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2085,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
if(C_truep((C_word)C_i_structurep(t5,lf[80]))){
t6=t2;
t7=t4;
f_2085(t7,(C_word)C_slot(t6,C_fix(2)));}
else{
t6=t4;
f_2085(t6,C_SCHEME_FALSE);}}

/* k2083 in ##tinyclos#slot-ref in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_2085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2085,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[178]);
if(C_truep(t5)){
t6=t4;
f_2088(2,t6,C_fix(6));}
else{
t6=(C_word)C_eqp(t3,lf[171]);
if(C_truep(t6)){
t7=t4;
f_2088(2,t7,C_fix(0));}
else{
t7=(C_word)C_eqp(t3,lf[183]);
if(C_truep(t7)){
t8=t4;
f_2088(2,t8,C_fix(1));}
else{
t8=(C_word)C_eqp(t3,lf[182]);
if(C_truep(t8)){
t9=t4;
f_2088(2,t9,C_fix(2));}
else{
t9=(C_word)C_eqp(t3,lf[181]);
if(C_truep(t9)){
t10=t4;
f_2088(2,t10,C_fix(3));}
else{
t10=(C_word)C_eqp(t3,lf[180]);
if(C_truep(t10)){
t11=t4;
f_2088(2,t11,C_fix(4));}
else{
t11=(C_word)C_eqp(t3,lf[179]);
if(C_truep(t11)){
t12=t4;
f_2088(2,t12,C_fix(5));}
else{
t12=(C_word)C_eqp(t3,lf[172]);
if(C_truep(t12)){
t13=t4;
f_2088(2,t13,C_fix(7));}
else{
t13=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t4,lf[203],((C_word*)t0)[3]);}}}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}}

/* k2154 in k2083 in ##tinyclos#slot-ref in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2182(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2144 in k2083 in ##tinyclos#slot-ref in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(0));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2086 in k2083 in ##tinyclos#slot-ref in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,C_fix(3));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* f_1857 in k1853 in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1857(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3r,(void*)f_1857r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1857r(t0,t1,t2,t3);}}

static void f_1857r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(20);
t4=(C_word)C_eqp(t2,*((C_word*)lf[169]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,*((C_word*)lf[170]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_length(lf[193]);
f_1314(t6,t2,t7);}
else{
t6=(C_word)C_eqp(t2,*((C_word*)lf[194]+1));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2027,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2042,a[2]=t2,a[3]=t7,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=*((C_word*)lf[197]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}
else{
t7=(C_word)C_eqp(t2,*((C_word*)lf[198]+1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=*((C_word*)lf[197]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}}}

/* k2071 */
static void f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(t1);
f_1314(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2049 */
static void f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_894(t3,((C_word*)t0)[2],lf[200],C_SCHEME_END_OF_LIST);}

/* k2063 in k2049 */
static void f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[200],t1);}

/* k2052 in k2049 */
static void f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_894(t3,((C_word*)t0)[2],lf[199],C_SCHEME_END_OF_LIST);}

/* k2059 in k2052 in k2049 */
static void f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[199],t1);}

/* k2055 in k2052 in k2049 */
static void f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2040 */
static void f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=f_891(((C_word*)t0)[4],lf[172],lf[196]);
t4=lf[87];
f_1342(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k2025 */
static void f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2030,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=lf[177];
f_2164(5,t3,t2,t1,lf[195],C_SCHEME_END_OF_LIST);}

/* k2028 in k2025 */
static void f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1868 */
static void f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=f_891(((C_word*)t0)[3],lf[171],C_SCHEME_END_OF_LIST);
t3=f_891(((C_word*)t0)[3],lf[172],lf[173]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1879,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_894(t5,((C_word*)t0)[3],lf[183],(C_word)C_a_i_list(&a,1,C_SCHEME_END_OF_LIST));}

/* k2012 in k1868 */
static void f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[192]+1),t1);}

/* k1877 in k1868 */
static void f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1981,a[2]=t5,a[3]=lf[191],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1981(t7,t2,((C_word*)t0)[2],t3);}

/* loop in k1877 in k1868 */
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1981,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1998,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=*((C_word*)lf[190]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k1996 in loop in k1877 in k1868 */
static void f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1981(t4,((C_word*)t0)[2],t1,t3);}

/* k1880 in k1877 in k1868 */
static void f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[189]+1),t4);}

/* k1969 in k1880 in k1877 in k1868 */
static void f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[66]+1),((C_word*)t0)[2],t1);}

/* k1883 in k1880 in k1877 in k1868 */
static void f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1886,a[2]=t5,a[3]=t3,a[4]=lf[176],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=t6,a[3]=lf[187],tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t1);}

/* a1945 in k1883 in k1880 in k1877 in k1868 */
static void f_1946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1946,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],a[3]=lf[185],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t4,t5,*((C_word*)lf[186]+1));}

/* a1959 in a1945 in k1883 in k1880 in k1877 in k1868 */
static void f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1966,a[2]=lf[184],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
f_1886(t3,t1,t2);}

/* a1965 in a1959 in a1945 in k1883 in k1880 in k1877 in k1868 */
static void f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k1956 in a1945 in k1883 in k1880 in k1877 in k1868 */
static void f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[10],lf[171],((C_word*)t0)[2]);}

/* k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[10],lf[183],((C_word*)t0)[2]);}

/* k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[9],lf[182],((C_word*)t0)[2]);}

/* k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[8],lf[181],((C_word*)t0)[2]);}

/* k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[7],lf[180],((C_word*)((C_word*)t0)[2])[1]);}

/* k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1942 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[177];
f_2164(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[179],t1);}

/* k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[5],lf[178],((C_word*)t0)[2]);}

/* k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=lf[177];
f_2164(5,t3,t2,((C_word*)t0)[4],lf[172],((C_word*)t0)[2]);}

/* k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1883 in k1880 in k1877 in k1868 */
static void f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_random_fixnum(C_fix(65536));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* allocator in k1883 in k1880 in k1877 in k1868 */
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1886,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t3,a[3]=lf[174],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1906,a[2]=t3,a[3]=lf[175],tmp=(C_word)a,a+=4,tmp);
C_values(4,0,t1,t8,t9);}

/* a1905 in allocator in k1883 in k1880 in k1877 in k1868 */
static void f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1906,4,t0,t1,t2,t3);}
f_1787(t1,t2,((C_word*)t0)[2],t3);}

/* a1899 in allocator in k1883 in k1880 in k1877 in k1868 */
static void f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
f_1720(t1,t2,((C_word*)t0)[2]);}

/* ##tinyclos#set-field! in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1787(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1787,NULL,4,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_i_structurep(t5,lf[80]))){
t6=t2;
t7=t3;
t8=t4;
t9=(C_word)C_fixnum_plus(t7,C_fix(3));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_setslot(t6,t9,t8));}
else{
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1807,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_closurep(t6))){
t8=(C_word)C_block_size(t6);
if(C_truep((C_word)C_fixnum_greaterp(t8,C_fix(3)))){
t9=(C_word)C_fixnum_difference(t8,C_fix(1));
t10=(C_word)C_slot(t6,t9);
t11=t7;
f_1807(t11,(C_word)C_eqp(*((C_word*)lf[83]+1),t10));}
else{
t9=t7;
f_1807(t9,C_SCHEME_FALSE);}}
else{
t8=t7;
f_1807(t8,C_SCHEME_FALSE);}}}

/* k1805 in ##tinyclos#set-field! in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_block_size(t2);
t6=(C_word)C_fixnum_difference(t5,C_fix(2));
t7=(C_word)C_slot(t2,t6);
t8=(C_word)C_fixnum_plus(t3,C_fix(5));
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_i_setslot(t7,t8,t4));}
else{
t2=*((C_word*)lf[159]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[160],lf[165],lf[166],((C_word*)t0)[5]);}}

/* ##tinyclos#get-field in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1720(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1720,NULL,3,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_i_structurep(t4,lf[80]))){
t5=t2;
t6=t3;
t7=(C_word)C_fixnum_plus(t6,C_fix(3));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t5,t7));}
else{
t5=t2;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1740,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_closurep(t5))){
t7=(C_word)C_block_size(t5);
if(C_truep((C_word)C_fixnum_greaterp(t7,C_fix(3)))){
t8=(C_word)C_fixnum_difference(t7,C_fix(1));
t9=(C_word)C_slot(t5,t8);
t10=t6;
f_1740(t10,(C_word)C_eqp(*((C_word*)lf[83]+1),t9));}
else{
t8=t6;
f_1740(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1740(t7,C_SCHEME_FALSE);}}}

/* k1738 in ##tinyclos#get-field in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_block_size(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(2));
t6=(C_word)C_slot(t2,t5);
t7=(C_word)C_fixnum_plus(t3,C_fix(5));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t6,t7));}
else{
t2=*((C_word*)lf[159]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[160],lf[161],lf[162],((C_word*)t0)[4]);}}

/* class-of in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1430,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[94]+1));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[95]+1));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[96]+1));}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[97]+1));}
else{
t3=(C_word)C_eqp(t2,C_SCHEME_UNDEFINED);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[98]+1));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[99]+1));}
else{
t4=t2;
if(C_truep((C_word)C_i_structurep(t4,lf[80]))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t5,C_fix(1)));}
else{
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t5))){
t7=(C_word)C_block_size(t5);
if(C_truep((C_word)C_fixnum_greaterp(t7,C_fix(3)))){
t8=(C_word)C_fixnum_difference(t7,C_fix(1));
t9=(C_word)C_slot(t5,t8);
t10=t6;
f_1482(t10,(C_word)C_eqp(*((C_word*)lf[83]+1),t9));}
else{
t8=t6;
f_1482(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1482(t7,C_SCHEME_FALSE);}}}}}}}}}

/* k1480 in class-of in k1419 in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1482,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(C_word)C_block_size(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(2));
t5=(C_word)C_slot(t2,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t5,C_fix(2)));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[100]+1));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[101]+1));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[102]+1));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_i_integerp(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?*((C_word*)lf[103]+1):*((C_word*)lf[104]+1)));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[105]+1));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[106]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[156]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}}}}}}

/* k1543 in k1480 in class-of in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[109]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[110]+1));}
else{
if(C_truep((C_word)C_taggedpointerp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[111]+1));}
else{
if(C_truep((C_word)C_swigpointerp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[112]+1));}
else{
if(C_truep((C_word)C_locativep(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[113]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[155]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}}}}}

/* k1567 in k1543 in k1480 in class-of in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[114]+1));}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[2]))){
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_eqp(t2,lf[115]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[116]+1));}
else{
t4=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,*((C_word*)lf[118]+1));}
else{
t5=(C_word)C_eqp(t2,lf[119]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[120]+1));}
else{
t6=(C_word)C_eqp(t2,lf[121]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,*((C_word*)lf[122]+1));}
else{
t7=(C_word)C_eqp(t2,lf[123]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,*((C_word*)lf[124]+1));}
else{
t8=(C_word)C_eqp(t2,lf[125]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,*((C_word*)lf[126]+1));}
else{
t9=(C_word)C_eqp(t2,lf[127]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[128]+1));}
else{
t10=(C_word)C_eqp(t2,lf[129]);
if(C_truep(t10)){
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,*((C_word*)lf[130]+1));}
else{
t11=(C_word)C_eqp(t2,lf[131]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,*((C_word*)lf[132]+1));}
else{
t12=(C_word)C_eqp(t2,lf[133]);
if(C_truep(t12)){
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,*((C_word*)lf[134]+1));}
else{
t13=(C_word)C_eqp(t2,lf[135]);
if(C_truep(t13)){
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,*((C_word*)lf[136]+1));}
else{
t14=(C_word)C_eqp(t2,lf[137]);
if(C_truep(t14)){
t15=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,*((C_word*)lf[138]+1));}
else{
t15=(C_word)C_eqp(t2,lf[139]);
if(C_truep(t15)){
t16=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,*((C_word*)lf[140]+1));}
else{
t16=(C_word)C_eqp(t2,lf[141]);
if(C_truep(t16)){
t17=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,*((C_word*)lf[142]+1));}
else{
t17=(C_word)C_eqp(t2,lf[143]);
if(C_truep(t17)){
t18=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,*((C_word*)lf[144]+1));}
else{
t18=(C_word)C_eqp(t2,lf[145]);
if(C_truep(t18)){
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,*((C_word*)lf[146]+1));}
else{
t19=(C_word)C_eqp(t2,lf[147]);
if(C_truep(t19)){
t20=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,*((C_word*)lf[148]+1));}
else{
t20=(C_word)C_eqp(t2,lf[149]);
if(C_truep(t20)){
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,*((C_word*)lf[150]+1));}
else{
t21=(C_word)C_eqp(t2,lf[151]);
t22=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_truep(t21)?*((C_word*)lf[152]+1):*((C_word*)lf[153]+1)));}}}}}}}}}}}}}}}}}}}
else{
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[93],lf[154],((C_word*)t0)[2]);}}}

/* k1549 in k1543 in k1480 in class-of in k1419 in k1333 in k1329 in k809 in k786 */
static void f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?*((C_word*)lf[107]+1):*((C_word*)lf[108]+1)));}

/* ##tinyclos#%allocate-entity in k1333 in k1329 in k809 in k786 */
static void C_fcall f_1342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1342,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1347,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_fixnum_plus(t3,C_fix(5));
t11=*((C_word*)lf[81]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_SCHEME_FALSE);}

/* k1345 in ##tinyclos#%allocate-entity in k1333 in k1329 in k809 in k786 */
static void f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[7],a[3]=lf[88],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_vector_to_structure(((C_word*)((C_word*)t0)[7])[1]);
t5=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(0),lf[89]);
t6=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),((C_word*)t0)[5]);
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(2),((C_word*)t0)[4]);
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(3),((C_word*)t0)[3]);
t9=(C_word)C_block_size(((C_word*)((C_word*)t0)[6])[1]);
t10=(C_word)C_fixnum_plus(t9,C_fix(2));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t12=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t10);}

/* k1376 in k1345 in ##tinyclos#%allocate-entity in k1333 in k1329 in k809 in k786 */
static void f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=lf[90],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1383(t2,C_fix(1)));}

/* do160 in k1376 in k1345 in ##tinyclos#%allocate-entity in k1333 in k1329 in k809 in k786 */
static C_word C_fcall f_1383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=(C_word)C_i_setslot(((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_fixnum_increase(t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],t4,*((C_word*)lf[83]+1));
t6=(C_word)C_vector_to_closure(((C_word*)t0)[4]);
t7=(C_word)C_copy_pointer(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[4]);
return(((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],t1);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],t1,t3);
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t12=t5;
t1=t12;
goto loop;}}

/* f_1349 in k1345 in ##tinyclos#%allocate-entity in k1333 in k1329 in k809 in k786 */
static void f_1349(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1349r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1349r(t0,t1,t2);}}

static void f_1349r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
C_apply(4,0,t1,t3,t2);}

/* default-proc in k1333 in k1329 in k809 in k786 */
static void f_1336(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[84],lf[85]);}

/* ##tinyclos#%allocate-instance in k809 in k786 */
static void C_fcall f_1314(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1314,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_plus(t3,C_fix(3));
t6=*((C_word*)lf[81]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,C_SCHEME_FALSE);}

/* k1316 in ##tinyclos#%allocate-instance in k809 in k786 */
static void f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_vector_to_structure(t1);
t3=(C_word)C_i_setslot(t1,C_fix(0),lf[80]);
t4=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##tinyclos#build-transitive-closure in k809 in k786 */
static void C_fcall f_1172(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1172,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1174,a[2]=t2,a[3]=lf[77],tmp=(C_word)a,a+=4,tmp));}

/* f_1174 in ##tinyclos#build-transitive-closure in k809 in k786 */
static void f_1174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1174,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=lf[76],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1184(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* track */
static void C_fcall f_1184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1184,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_memq(t4,t2))){
t5=(C_word)C_i_cdr(t3);
t10=t1;
t11=t2;
t12=t5;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1222,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}

/* k1220 in track */
static void f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k1216 in track */
static void f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1184(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_991,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_999,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1013,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_1172(t5,t3);}

/* k1011 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1230,a[2]=t3,a[3]=lf[74],tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_1230(t5,t2,((C_word*)t0)[2]);}

/* f_1230 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void C_fcall f_1230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1230,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1238,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1312,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
f_1172(t4,((C_word*)t0)[2]);}

/* k1310 */
static void f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1236 */
static void f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[72],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1240(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1236 */
static void C_fcall f_1240(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1240,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1250,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_1250(t7,t5);}
else{
t7=(C_word)C_i_cdr(t3);
t8=t6;
f_1250(t8,(C_word)C_i_nullp(t7));}}

/* k1248 in loop in k1236 */
static void C_fcall f_1250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1250,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
t7=((C_word*)((C_word*)t0)[4])[1];
f_1240(t7,((C_word*)t0)[6],((C_word*)t0)[7],t2,t6);}}

/* k1273 in k1248 in loop in k1236 */
static void f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=((C_word*)((C_word*)t0)[5])[1];
f_1240(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1115,a[2]=t2,a[3]=lf[63],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1021,a[2]=t3,a[3]=t7,a[4]=lf[71],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1021(t9,t4,t5,t1,C_SCHEME_END_OF_LIST);}

/* loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void C_fcall f_1021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1021,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1083,a[2]=t3,a[3]=t4,a[4]=lf[70],tmp=(C_word)a,a+=5,tmp);
f_941(t5,t6,t2);}}

/* a1082 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1083,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[68],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_819,a[2]=t3,a[3]=lf[69],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_819(t5,t4));}

/* loop in a1082 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static C_word C_fcall f_819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=f_1089(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a1088 in a1082 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static C_word C_fcall f_1089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t5,((C_word*)t0)[2]));}}

/* k1029 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[64],lf[65]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_1043(2,t4,(C_word)C_i_car(t1));}
else{
t4=((C_word*)t0)[2];
f_1115(t4,t2,((C_word*)t0)[4],t1);}}}

/* k1041 in k1029 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1060,a[2]=t1,a[3]=lf[67],tmp=(C_word)a,a+=4,tmp);
f_941(t2,t3,((C_word*)t0)[2]);}

/* a1059 in k1041 in k1029 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1060,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}

/* k1048 in k1041 in k1029 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=*((C_word*)lf[66]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1052 in k1048 in k1041 in k1029 in loop in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_1021(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_1115 in k1001 in k997 in ##tinyclos#compute-std-cpl in k809 in k786 */
static void C_fcall f_1115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1115,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1123,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1121 */
static void f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=lf[61],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1125(t5,((C_word*)t0)[2],t1);}

/* loop in k1121 */
static void C_fcall f_1125(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1125,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1130 in loop in k1121 */
static void f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1166,a[2]=t1,a[3]=lf[60],tmp=(C_word)a,a+=4,tmp);
f_941(t2,t3,((C_word*)t0)[2]);}

/* a1165 in k1130 in loop in k1121 */
static void f_1166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1166,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,((C_word*)t0)[2]));}

/* k1133 in k1130 in loop in k1121 */
static void f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[58],lf[59]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_1125(t4,((C_word*)t0)[3],t3);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}}

/* ##tinyclos#filter-in in k809 in k786 */
static void C_fcall f_941(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_941,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_960,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=t2;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k958 in ##tinyclos#filter-in in k809 in k786 */
static void f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
f_941(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
f_941(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k965 in k958 in ##tinyclos#filter-in in k809 in k786 */
static void f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##tinyclos#getl in k809 in k786 */
static void C_fcall f_894(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_894,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_897,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=lf[51],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_897(t8,t1,t2);}

/* scan in ##tinyclos#getl in k809 in k786 */
static void C_fcall f_897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_897,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(((C_word*)t0)[5]));}
else{
t3=*((C_word*)lf[48]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[49],lf[50],((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(t2));}
else{
t5=(C_word)C_i_cddr(t2);
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}

/* ##tinyclos#quick-getl in k809 in k786 */
static C_word C_fcall f_891(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)stub63(C_SCHEME_UNDEFINED,t1,t2,t3));}

/* ##tinyclos#every2 in k809 in k786 */
static void f_845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_845,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_851,a[2]=t2,a[3]=t6,a[4]=lf[43],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_851(t8,t1,t3,t4);}

/* loop in ##tinyclos#every2 in k809 in k786 */
static void C_fcall f_851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_851,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_nullp(t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t3,C_fix(0));
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}}

/* k868 in loop in ##tinyclos#every2 in k809 in k786 */
static void f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_851(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
/* end of file */
