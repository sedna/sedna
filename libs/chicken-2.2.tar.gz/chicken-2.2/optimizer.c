/* Generated from optimizer.scm by the Chicken compiler
   2005-09-10 23:15
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: optimizer.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file optimizer.c -explicit-use
   unit: optimizer
*/

#include "chicken.h"

#define C_METHOD_CACHE_SIZE 8


static C_TLS C_word lf[451];


C_externexport void C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1667(C_word c,C_word t0,C_word t1) C_noret;
static void f_9270(C_word c,C_word t0,C_word t1) C_noret;
static void f_9262(C_word c,C_word t0,C_word t1) C_noret;
static void f_9258(C_word c,C_word t0,C_word t1) C_noret;
static void f_9207(C_word c,C_word t0,C_word t1) C_noret;
static void f_9213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_9221(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9226(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9250(C_word c,C_word t0,C_word t1) C_noret;
static void f_9254(C_word c,C_word t0,C_word t1) C_noret;
static void f_9236(C_word c,C_word t0,C_word t1) C_noret;
static void f_3442(C_word c,C_word t0,C_word t1) C_noret;
static void f_9002(C_word c,C_word t0,C_word t1) C_noret;
static void f_8994(C_word c,C_word t0,C_word t1) C_noret;
static void f_8990(C_word c,C_word t0,C_word t1) C_noret;
static void f_8631(C_word c,C_word t0,C_word t1) C_noret;
static void f_8615(C_word c,C_word t0,C_word t1) C_noret;
static void f_8569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_8603(C_word c,C_word t0,C_word t1) C_noret;
static void f_8645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_8655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8722(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8874(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8767(C_word t0,C_word t1) C_noret;
static void f_8814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8804(C_word c,C_word t0,C_word t1) C_noret;
static void f_8812(C_word c,C_word t0,C_word t1) C_noret;
static void f_8916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
static void f_8935(C_word c,C_word t0,C_word t1) C_noret;
static void f_8970(C_word c,C_word t0,C_word t1) C_noret;
static void f_8954(C_word c,C_word t0,C_word t1) C_noret;
static void f_8958(C_word c,C_word t0,C_word t1) C_noret;
static void f_8947(C_word c,C_word t0,C_word t1) C_noret;
static void f_9044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
static void f_9063(C_word c,C_word t0,C_word t1) C_noret;
static void f_9069(C_word c,C_word t0,C_word t1) C_noret;
static void f_9115(C_word c,C_word t0,C_word t1) C_noret;
static void f_9107(C_word c,C_word t0,C_word t1) C_noret;
static void f_9091(C_word c,C_word t0,C_word t1) C_noret;
static void f_9095(C_word c,C_word t0,C_word t1) C_noret;
static void f_9099(C_word c,C_word t0,C_word t1) C_noret;
static void f_3445(C_word c,C_word t0,C_word t1) C_noret;
static void f_8387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_8409(C_word c,C_word t0,C_word t1) C_noret;
static void f_8464(C_word c,C_word t0,C_word t1) C_noret;
static void f_8434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8456(C_word c,C_word t0,C_word t1) C_noret;
static void f_8460(C_word c,C_word t0,C_word t1) C_noret;
static void f_8452(C_word c,C_word t0,C_word t1) C_noret;
static void f_8432(C_word c,C_word t0,C_word t1) C_noret;
static void f_8498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
static void f_8512(C_word c,C_word t0,C_word t1) C_noret;
static void f_3448(C_word c,C_word t0,C_word t1) C_noret;
static void f_3776(C_word c,C_word t0,C_word t1) C_noret;
static void f_6727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8274(C_word c,C_word t0,C_word t1) C_noret;
static void f_8277(C_word c,C_word t0,C_word t1) C_noret;
static void f_8280(C_word c,C_word t0,C_word t1) C_noret;
static void f_8283(C_word c,C_word t0,C_word t1) C_noret;
static void f_8286(C_word c,C_word t0,C_word t1) C_noret;
static void f_8289(C_word c,C_word t0,C_word t1) C_noret;
static void f_8366(C_word c,C_word t0,C_word t1) C_noret;
static void f_8292(C_word c,C_word t0,C_word t1) C_noret;
static void f_8295(C_word c,C_word t0,C_word t1) C_noret;
static void f_8298(C_word c,C_word t0,C_word t1) C_noret;
static void f_8360(C_word c,C_word t0,C_word t1) C_noret;
static void f_8301(C_word c,C_word t0,C_word t1) C_noret;
static void f_8304(C_word c,C_word t0,C_word t1) C_noret;
static void f_8357(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7336(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7340(C_word c,C_word t0,C_word t1) C_noret;
static void f_8307(C_word c,C_word t0,C_word t1) C_noret;
static void f_8349(C_word c,C_word t0,C_word t1) C_noret;
static void f_8347(C_word c,C_word t0,C_word t1) C_noret;
static void f_8310(C_word c,C_word t0,C_word t1) C_noret;
static void f_8313(C_word c,C_word t0,C_word t1) C_noret;
static void f_8316(C_word c,C_word t0,C_word t1) C_noret;
static void f_8340(C_word c,C_word t0,C_word t1) C_noret;
static void f_8319(C_word c,C_word t0,C_word t1) C_noret;
static void f_8322(C_word c,C_word t0,C_word t1) C_noret;
static void f_8325(C_word c,C_word t0,C_word t1) C_noret;
static void f_8328(C_word c,C_word t0,C_word t1) C_noret;
static void f_8331(C_word c,C_word t0,C_word t1) C_noret;
static void f_8334(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8127(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8245(C_word c,C_word t0,C_word t1) C_noret;
static void f_8254(C_word c,C_word t0,C_word t1) C_noret;
static void f_8257(C_word c,C_word t0,C_word t1) C_noret;
static void f_8152(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_8198(C_word t0,C_word t1) C_noret;
static void f_8195(C_word c,C_word t0,C_word t1) C_noret;
static void f_8180(C_word c,C_word t0,C_word t1) C_noret;
static void f_8191(C_word c,C_word t0,C_word t1) C_noret;
static void f_8187(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8102(C_word c,C_word t0,C_word t1) C_noret;
static void f_8098(C_word c,C_word t0,C_word t1) C_noret;
static void f_8068(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7790(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7811(C_word c,C_word t0,C_word t1) C_noret;
static void f_7824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7831(C_word c,C_word t0,C_word t1) C_noret;
static void f_7834(C_word c,C_word t0,C_word t1) C_noret;
static void f_7930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8035(C_word c,C_word t0,C_word t1) C_noret;
static void f_8031(C_word c,C_word t0,C_word t1) C_noret;
static void f_7997(C_word c,C_word t0,C_word t1) C_noret;
static void f_7986(C_word c,C_word t0,C_word t1) C_noret;
static void f_7973(C_word c,C_word t0,C_word t1) C_noret;
static void f_7956(C_word c,C_word t0,C_word t1) C_noret;
static void f_7949(C_word c,C_word t0,C_word t1) C_noret;
static void f_7915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7837(C_word c,C_word t0,C_word t1) C_noret;
static void f_7886(C_word c,C_word t0,C_word t1) C_noret;
static void f_7874(C_word c,C_word t0,C_word t1) C_noret;
static void f_7870(C_word c,C_word t0,C_word t1) C_noret;
static void f_7802(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7589(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7654(C_word c,C_word t0,C_word t1) C_noret;
static void f_7731(C_word c,C_word t0,C_word t1) C_noret;
static void f_7736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7774(C_word c,C_word t0,C_word t1) C_noret;
static void f_7598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7641(C_word c,C_word t0,C_word t1) C_noret;
static void f_7618(C_word c,C_word t0,C_word t1) C_noret;
static void f_7596(C_word c,C_word t0,C_word t1) C_noret;
static void f_7766(C_word c,C_word t0,C_word t1) C_noret;
static void f_7752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7750(C_word c,C_word t0,C_word t1) C_noret;
static void f_7656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7722(C_word c,C_word t0,C_word t1) C_noret;
static void f_7710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7676(C_word c,C_word t0,C_word t1) C_noret;
static void f_7700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7698(C_word c,C_word t0,C_word t1) C_noret;
static void f_7694(C_word c,C_word t0,C_word t1) C_noret;
static void f_7686(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7370(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7395(C_word t0,C_word t1) C_noret;
static void f_7562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7538(C_word c,C_word t0,C_word t1) C_noret;
static void f_7542(C_word c,C_word t0,C_word t1) C_noret;
static void f_7528(C_word c,C_word t0,C_word t1) C_noret;
static void f_7481(C_word c,C_word t0,C_word t1) C_noret;
static void f_7486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7469(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7406(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7427(C_word c,C_word t0,C_word t1) C_noret;
static void f_7424(C_word c,C_word t0,C_word t1) C_noret;
static void f_7374(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7126(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7151(C_word t0,C_word t1) C_noret;
static void f_7253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7244(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7210(C_word t0,C_word t1) C_noret;
static void f_7219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7231(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7183(C_word c,C_word t0,C_word t1) C_noret;
static void f_7180(C_word c,C_word t0,C_word t1) C_noret;
static void f_7130(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7077(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7089(C_word c,C_word t0,C_word t1) C_noret;
static void f_7116(C_word c,C_word t0,C_word t1) C_noret;
static void f_7112(C_word c,C_word t0,C_word t1) C_noret;
static void f_7104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7102(C_word c,C_word t0,C_word t1) C_noret;
static void f_7067(C_word c,C_word t0,C_word t1) C_noret;
static void f_7045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7052(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6999(C_word c,C_word t0,C_word t1) C_noret;
static void f_7003(C_word c,C_word t0,C_word t1) C_noret;
static void f_6982(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6967(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6925(C_word c,C_word t0,C_word t1) C_noret;
static void f_6919(C_word c,C_word t0,C_word t1) C_noret;
static void f_6883(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6858(C_word t0,C_word t1) C_noret;
static void C_fcall f_6861(C_word t0,C_word t1) C_noret;
static void f_6866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6730(C_word t0,C_word t1) C_noret;
static void f_6736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6767(C_word t0,C_word t1) C_noret;
static void f_6771(C_word c,C_word t0,C_word t1) C_noret;
static void f_6775(C_word c,C_word t0,C_word t1) C_noret;
static void f_6734(C_word c,C_word t0,C_word t1) C_noret;
static void f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6722(C_word c,C_word t0,C_word t1) C_noret;
static void f_6725(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5731(C_word c,C_word t0,C_word t1) C_noret;
static void f_5705(C_word c,C_word t0,C_word t1) C_noret;
static void f_5651(C_word c,C_word t0,C_word t1) C_noret;
static void f_5657(C_word c,C_word t0,C_word t1) C_noret;
static void f_5663(C_word c,C_word t0,C_word t1) C_noret;
static void f_5620(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_6167(C_word c,C_word t0,C_word t1) C_noret;
static void f_6174(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_6154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6130(C_word c,C_word t0,C_word t1) C_noret;
static void f_6141(C_word c,C_word t0,C_word t1) C_noret;
static void f_6097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6036(C_word t0,C_word t1) C_noret;
static void C_fcall f_6008(C_word t0,C_word t1) C_noret;
static void f_6013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5955(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5961(C_word t0,C_word t1) C_noret;
static void f_5966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5914(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5920(C_word t0,C_word t1) C_noret;
static void f_5925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5898(C_word c,C_word t0,C_word t1) C_noret;
static void f_5894(C_word c,C_word t0,C_word t1) C_noret;
static void f_5864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5843(C_word c,C_word t0,C_word t1) C_noret;
static void f_5809(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
static void f_6712(C_word c,C_word t0,C_word t1) C_noret;
static void f_6710(C_word c,C_word t0,C_word t1) C_noret;
static void f_6180(C_word c,C_word t0,C_word t1) C_noret;
static void f_6190(C_word c,C_word t0,C_word t1) C_noret;
static void f_6684(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6196(C_word t0,C_word t1) C_noret;
static void f_6202(C_word c,C_word t0,C_word t1) C_noret;
static void f_6205(C_word c,C_word t0,C_word t1) C_noret;
static void f_6211(C_word c,C_word t0,C_word t1) C_noret;
static void f_6387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6609(C_word c,C_word t0,C_word t1) C_noret;
static void f_6612(C_word c,C_word t0,C_word t1) C_noret;
static void f_6562(C_word c,C_word t0,C_word t1) C_noret;
static void f_6565(C_word c,C_word t0,C_word t1) C_noret;
static void f_6431(C_word c,C_word t0,C_word t1) C_noret;
static void f_6486(C_word c,C_word t0,C_word t1) C_noret;
static void f_6489(C_word c,C_word t0,C_word t1) C_noret;
static void f_6516(C_word c,C_word t0,C_word t1) C_noret;
static void f_6492(C_word c,C_word t0,C_word t1) C_noret;
static void f_6495(C_word c,C_word t0,C_word t1) C_noret;
static void f_6440(C_word c,C_word t0,C_word t1) C_noret;
static void f_6443(C_word c,C_word t0,C_word t1) C_noret;
static void f_6446(C_word c,C_word t0,C_word t1) C_noret;
static void f_6214(C_word c,C_word t0,C_word t1) C_noret;
static void f_6369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6367(C_word c,C_word t0,C_word t1) C_noret;
static void f_6310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6320(C_word c,C_word t0,C_word t1) C_noret;
static void f_6217(C_word c,C_word t0,C_word t1) C_noret;
static void f_6229(C_word c,C_word t0,C_word t1) C_noret;
static void f_6268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6232(C_word c,C_word t0,C_word t1) C_noret;
static void f_6235(C_word c,C_word t0,C_word t1) C_noret;
static void f_6240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6266(C_word c,C_word t0,C_word t1) C_noret;
static void f_6247(C_word c,C_word t0,C_word t1) C_noret;
static void f_3798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
static void f_5539(C_word c,C_word t0,C_word t1) C_noret;
static void f_5542(C_word c,C_word t0,C_word t1) C_noret;
static void f_5574(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5561(C_word t0,C_word t1) C_noret;
static void f_5385(C_word c,C_word t0,C_word t1) C_noret;
static void f_5388(C_word c,C_word t0,C_word t1) C_noret;
static void f_5394(C_word c,C_word t0,C_word t1) C_noret;
static void f_5478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5403(C_word c,C_word t0,C_word t1) C_noret;
static void f_5447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5445(C_word c,C_word t0,C_word t1) C_noret;
static void f_5419(C_word c,C_word t0,C_word t1) C_noret;
static void f_5312(C_word c,C_word t0,C_word t1) C_noret;
static void f_5315(C_word c,C_word t0,C_word t1) C_noret;
static void f_5343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5355(C_word c,C_word t0,C_word t1) C_noret;
static void f_5333(C_word c,C_word t0,C_word t1) C_noret;
static void f_5328(C_word c,C_word t0,C_word t1) C_noret;
static void f_5164(C_word c,C_word t0,C_word t1) C_noret;
static void f_5167(C_word c,C_word t0,C_word t1) C_noret;
static void f_5248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5176(C_word c,C_word t0,C_word t1) C_noret;
static void f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5227(C_word c,C_word t0,C_word t1) C_noret;
static void f_5192(C_word c,C_word t0,C_word t1) C_noret;
static void f_5129(C_word c,C_word t0,C_word t1) C_noret;
static void f_5132(C_word c,C_word t0,C_word t1) C_noret;
static void f_5142(C_word c,C_word t0,C_word t1) C_noret;
static void f_5061(C_word c,C_word t0,C_word t1) C_noret;
static void f_5064(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5084(C_word t0,C_word t1) C_noret;
static void f_4982(C_word c,C_word t0,C_word t1) C_noret;
static void f_4985(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5015(C_word t0,C_word t1) C_noret;
static void f_4889(C_word c,C_word t0,C_word t1) C_noret;
static void f_4892(C_word c,C_word t0,C_word t1) C_noret;
static void f_4911(C_word c,C_word t0,C_word t1) C_noret;
static void f_4904(C_word c,C_word t0,C_word t1) C_noret;
static void f_4806(C_word c,C_word t0,C_word t1) C_noret;
static void f_4809(C_word c,C_word t0,C_word t1) C_noret;
static void f_4741(C_word c,C_word t0,C_word t1) C_noret;
static void f_4744(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4759(C_word t0,C_word t1) C_noret;
static void f_4762(C_word c,C_word t0,C_word t1) C_noret;
static void f_4665(C_word c,C_word t0,C_word t1) C_noret;
static void f_4668(C_word c,C_word t0,C_word t1) C_noret;
static void f_4711(C_word c,C_word t0,C_word t1) C_noret;
static void f_4704(C_word c,C_word t0,C_word t1) C_noret;
static void f_4600(C_word c,C_word t0,C_word t1) C_noret;
static void f_4603(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4615(C_word t0,C_word t1) C_noret;
static void f_4628(C_word c,C_word t0,C_word t1) C_noret;
static void f_4621(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1) C_noret;
static void f_4535(C_word c,C_word t0,C_word t1) C_noret;
static void f_4543(C_word c,C_word t0,C_word t1) C_noret;
static void f_4547(C_word c,C_word t0,C_word t1) C_noret;
static void f_4369(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4391(C_word t0,C_word t1) C_noret;
static void C_fcall f_4394(C_word t0,C_word t1) C_noret;
static void f_4453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4397(C_word c,C_word t0,C_word t1) C_noret;
static void f_4400(C_word c,C_word t0,C_word t1) C_noret;
static void f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4429(C_word c,C_word t0,C_word t1) C_noret;
static void f_4405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4385(C_word c,C_word t0,C_word t1) C_noret;
static void f_4342(C_word c,C_word t0,C_word t1) C_noret;
static void f_4345(C_word c,C_word t0,C_word t1) C_noret;
static void f_4281(C_word c,C_word t0,C_word t1) C_noret;
static void f_4284(C_word c,C_word t0,C_word t1) C_noret;
static void f_4308(C_word c,C_word t0,C_word t1) C_noret;
static void f_4297(C_word c,C_word t0,C_word t1) C_noret;
static void f_4216(C_word c,C_word t0,C_word t1) C_noret;
static void f_4123(C_word c,C_word t0,C_word t1) C_noret;
static void f_4126(C_word c,C_word t0,C_word t1) C_noret;
static void f_4168(C_word c,C_word t0,C_word t1) C_noret;
static void f_4067(C_word c,C_word t0,C_word t1) C_noret;
static void f_4080(C_word c,C_word t0,C_word t1) C_noret;
static void f_4088(C_word c,C_word t0,C_word t1) C_noret;
static void f_4029(C_word c,C_word t0,C_word t1) C_noret;
static void f_4039(C_word c,C_word t0,C_word t1) C_noret;
static void f_3925(C_word c,C_word t0,C_word t1) C_noret;
static void f_3928(C_word c,C_word t0,C_word t1) C_noret;
static void f_3985(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3956(C_word t0,C_word t1) C_noret;
static void C_fcall f_3953(C_word t0,C_word t1) C_noret;
static void f_3817(C_word c,C_word t0,C_word t1) C_noret;
static void f_3880(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3820(C_word t0,C_word t1) C_noret;
static void C_fcall f_3801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3778(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3778r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3782(C_word c,C_word t0,C_word t1) C_noret;
static void f_3792(C_word c,C_word t0,C_word t1) C_noret;
static void f_3450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3454(C_word c,C_word t0,C_word t1) C_noret;
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3772(C_word c,C_word t0,C_word t1) C_noret;
static void f_3768(C_word c,C_word t0,C_word t1) C_noret;
static void f_3501(C_word c,C_word t0,C_word t1) C_noret;
static void f_3705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3750(C_word c,C_word t0,C_word t1) C_noret;
static void f_3715(C_word c,C_word t0,C_word t1) C_noret;
static void f_3731(C_word c,C_word t0,C_word t1) C_noret;
static void f_3719(C_word c,C_word t0,C_word t1) C_noret;
static void f_3723(C_word c,C_word t0,C_word t1) C_noret;
static void f_3504(C_word c,C_word t0,C_word t1) C_noret;
static void f_3646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3653(C_word c,C_word t0,C_word t1) C_noret;
static void f_3663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3676(C_word c,C_word t0,C_word t1) C_noret;
static void f_3661(C_word c,C_word t0,C_word t1) C_noret;
static void f_3657(C_word c,C_word t0,C_word t1) C_noret;
static void f_3507(C_word c,C_word t0,C_word t1) C_noret;
static void f_3510(C_word c,C_word t0,C_word t1) C_noret;
static void f_3530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3543(C_word t0,C_word t1) C_noret;
static void f_3586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3618(C_word c,C_word t0,C_word t1) C_noret;
static void f_3584(C_word c,C_word t0,C_word t1) C_noret;
static void f_3566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3513(C_word c,C_word t0,C_word t1) C_noret;
static void f_3522(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3456(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2988(C_word c,C_word t0,C_word t1) C_noret;
static void f_3223(C_word c,C_word t0,C_word t1) C_noret;
static void f_3430(C_word c,C_word t0,C_word t1) C_noret;
static void f_3228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3419(C_word c,C_word t0,C_word t1) C_noret;
static void f_3241(C_word c,C_word t0,C_word t1) C_noret;
static void f_3244(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3250(C_word t0,C_word t1) C_noret;
static void C_fcall f_3265(C_word t0,C_word t1) C_noret;
static void f_3271(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3277(C_word t0,C_word t1) C_noret;
static void C_fcall f_3286(C_word t0,C_word t1) C_noret;
static void f_3293(C_word c,C_word t0,C_word t1) C_noret;
static void f_3296(C_word c,C_word t0,C_word t1) C_noret;
static void f_3314(C_word c,C_word t0,C_word t1) C_noret;
static void f_3299(C_word c,C_word t0,C_word t1) C_noret;
static void f_2991(C_word c,C_word t0,C_word t1) C_noret;
static void f_3005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3012(C_word c,C_word t0,C_word t1) C_noret;
static void f_3217(C_word c,C_word t0,C_word t1) C_noret;
static void f_3017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3030(C_word c,C_word t0,C_word t1) C_noret;
static void f_3206(C_word c,C_word t0,C_word t1) C_noret;
static void f_3033(C_word c,C_word t0,C_word t1) C_noret;
static void f_3180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3178(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3039(C_word t0,C_word t1) C_noret;
static void C_fcall f_3051(C_word t0,C_word t1) C_noret;
static void f_3057(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3066(C_word t0,C_word t1) C_noret;
static void f_3072(C_word c,C_word t0,C_word t1) C_noret;
static void f_3075(C_word c,C_word t0,C_word t1) C_noret;
static void f_3093(C_word c,C_word t0,C_word t1) C_noret;
static void f_3078(C_word c,C_word t0,C_word t1) C_noret;
static void f_2994(C_word c,C_word t0,C_word t1) C_noret;
static void f_2997(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_2977(C_word t0);
static void f_1669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2921(C_word c,C_word t0,C_word t1) C_noret;
static void f_2927(C_word c,C_word t0,C_word t1) C_noret;
static void f_2930(C_word c,C_word t0,C_word t1) C_noret;
static void f_2933(C_word c,C_word t0,C_word t1) C_noret;
static void f_2936(C_word c,C_word t0,C_word t1) C_noret;
static void f_2939(C_word c,C_word t0,C_word t1) C_noret;
static void f_2942(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2906(C_word c,C_word t0,C_word t1) C_noret;
static void f_2912(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2809(C_word c,C_word t0,C_word t1) C_noret;
static void f_2812(C_word c,C_word t0,C_word t1) C_noret;
static void f_2894(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2853(C_word t0,C_word t1) C_noret;
static void f_2874(C_word c,C_word t0,C_word t1) C_noret;
static void f_2866(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2824(C_word t0,C_word t1) C_noret;
static void f_2843(C_word c,C_word t0,C_word t1) C_noret;
static void f_2830(C_word c,C_word t0,C_word t1) C_noret;
static void f_2784(C_word c,C_word t0,C_word t1) C_noret;
static void f_2759(C_word c,C_word t0,C_word t1) C_noret;
static void f_2355(C_word c,C_word t0,C_word t1) C_noret;
static void f_2364(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2400(C_word t0,C_word t1) C_noret;
static void f_2411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1) C_noret;
static void f_2716(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2421(C_word t0,C_word t1) C_noret;
static void f_2458(C_word c,C_word t0,C_word t1) C_noret;
static void f_2700(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2617(C_word t0,C_word t1) C_noret;
static void f_2632(C_word c,C_word t0,C_word t1) C_noret;
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2670(C_word c,C_word t0,C_word t1) C_noret;
static void f_2662(C_word c,C_word t0,C_word t1) C_noret;
static void f_2647(C_word c,C_word t0,C_word t1) C_noret;
static void f_2637(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2505(C_word c,C_word t0,C_word t1) C_noret;
static void f_2511(C_word c,C_word t0,C_word t1) C_noret;
static void f_2517(C_word c,C_word t0,C_word t1) C_noret;
static void f_2554(C_word c,C_word t0,C_word t1) C_noret;
static void f_2530(C_word c,C_word t0,C_word t1) C_noret;
static void f_2534(C_word c,C_word t0,C_word t1) C_noret;
static void f_2499(C_word c,C_word t0,C_word t1) C_noret;
static void f_2488(C_word c,C_word t0,C_word t1) C_noret;
static void f_2424(C_word c,C_word t0,C_word t1) C_noret;
static void f_2427(C_word c,C_word t0,C_word t1) C_noret;
static void f_2430(C_word c,C_word t0,C_word t1) C_noret;
static void f_2440(C_word c,C_word t0,C_word t1) C_noret;
static void f_2373(C_word c,C_word t0,C_word t1) C_noret;
static void f_2376(C_word c,C_word t0,C_word t1) C_noret;
static void f_2386(C_word c,C_word t0,C_word t1) C_noret;
static void f_2176(C_word c,C_word t0,C_word t1) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2280(C_word c,C_word t0,C_word t1) C_noret;
static void f_2309(C_word c,C_word t0,C_word t1) C_noret;
static void f_2293(C_word c,C_word t0,C_word t1) C_noret;
static void f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2206(C_word c,C_word t0,C_word t1) C_noret;
static void f_2242(C_word c,C_word t0,C_word t1) C_noret;
static void f_2245(C_word c,C_word t0,C_word t1) C_noret;
static void f_2235(C_word c,C_word t0,C_word t1) C_noret;
static void f_2219(C_word c,C_word t0,C_word t1) C_noret;
static void f_2187(C_word c,C_word t0,C_word t1) C_noret;
static void f_2193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2119(C_word c,C_word t0,C_word t1) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1) C_noret;
static void f_2154(C_word c,C_word t0,C_word t1) C_noret;
static void f_2161(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2122(C_word t0,C_word t1) C_noret;
static void f_2139(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2044(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_2060(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2083(C_word t0,C_word t1) C_noret;
static void f_2066(C_word c,C_word t0,C_word t1) C_noret;
static void f_2077(C_word c,C_word t0,C_word t1) C_noret;
static void f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1814(C_word c,C_word t0,C_word t1) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1) C_noret;
static void f_1987(C_word c,C_word t0,C_word t1) C_noret;
static void f_1993(C_word c,C_word t0,C_word t1) C_noret;
static void f_1884(C_word c,C_word t0,C_word t1) C_noret;
static void f_1966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1964(C_word c,C_word t0,C_word t1) C_noret;
static void f_1895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1918(C_word c,C_word t0,C_word t1) C_noret;
static void f_1950(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1950r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1956(C_word c,C_word t0,C_word t1) C_noret;
static void f_1924(C_word c,C_word t0,C_word t1) C_noret;
static void f_1928(C_word c,C_word t0,C_word t1) C_noret;
static void f_1931(C_word c,C_word t0,C_word t1) C_noret;
static void f_1948(C_word c,C_word t0,C_word t1) C_noret;
static void f_1901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1907(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1911(C_word t0,C_word t1) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1) C_noret;
static void f_1893(C_word c,C_word t0,C_word t1) C_noret;
static void f_1832(C_word c,C_word t0,C_word t1) C_noret;
static void f_1823(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1702(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1712(C_word c,C_word t0,C_word t1) C_noret;
static void f_1723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1733(C_word c,C_word t0,C_word t1) C_noret;
static void f_1782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1780(C_word c,C_word t0,C_word t1) C_noret;
static void f_1739(C_word c,C_word t0,C_word t1) C_noret;
static void f_1745(C_word c,C_word t0,C_word t1) C_noret;
static void f_1772(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1751(C_word t0,C_word t1) C_noret;
static void f_1715(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1698(C_word t0);
static C_word C_fcall f_1688(C_word t0);
static void f_1678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1485(C_word c,C_word t0,C_word t1) C_noret;
static void f_1497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1564(C_word t0,C_word t1) C_noret;
static void f_1583(C_word c,C_word t0,C_word t1) C_noret;
static void f_1594(C_word c,C_word t0,C_word t1) C_noret;
static void f_1567(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1537(C_word t0,C_word t1) C_noret;
static void C_fcall f_1500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1488(C_word c,C_word t0,C_word t1) C_noret;
static void f_1491(C_word c,C_word t0,C_word t1) C_noret;
static void f_1495(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1467(C_word *a,C_word t0,C_word t1);

static void C_fcall trf_9226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9226(t0,t1,t2);}

static void C_fcall trf_8655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8655(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8655(t0,t1,t2,t3);}

static void C_fcall trf_8751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8751(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8751(t0,t1,t2,t3,t4);}

static void C_fcall trf_8767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8767(t0,t1);}

static void C_fcall trf_7336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7336(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7336(t0,t1,t2,t3);}

static void C_fcall trf_8127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8127(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8127(t0,t1,t2);}

static void C_fcall trf_8157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8157(t0,t1,t2,t3);}

static void C_fcall trf_8198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8198(t0,t1);}

static void C_fcall trf_8040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8040(t0,t1,t2);}

static void C_fcall trf_7790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7790(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7790(t0,t1,t2,t3);}

static void C_fcall trf_7589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7589(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7589(t0,t1,t2);}

static void C_fcall trf_7370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7370(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7370(t0,t1,t2);}

static void C_fcall trf_7376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7376(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7376(t0,t1,t2,t3);}

static void C_fcall trf_7395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7395(t0,t1);}

static void C_fcall trf_7406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7406(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7406(t0,t1,t2,t3);}

static void C_fcall trf_7126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7126(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7126(t0,t1,t2);}

static void C_fcall trf_7132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7132(t0,t1,t2,t3);}

static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7151(t0,t1);}

static void C_fcall trf_7210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7210(t0,t1);}

static void C_fcall trf_7162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7162(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7162(t0,t1,t2,t3);}

static void C_fcall trf_7027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7027(t0,t1,t2,t3);}

static void C_fcall trf_7082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7082(t0,t1,t2,t3);}

static void C_fcall trf_6830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6830(t0,t1,t2);}

static void C_fcall trf_6833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6833(t0,t1,t2,t3);}

static void C_fcall trf_6901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6901(t0,t1,t2,t3);}

static void C_fcall trf_6858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6858(t0,t1);}

static void C_fcall trf_6861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6861(t0,t1);}

static void C_fcall trf_6730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6730(t0,t1);}

static void C_fcall trf_6767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6767(t0,t1);}

static void C_fcall trf_5595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5595(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5595(t0,t1,t2,t3,t4);}

static void C_fcall trf_5757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5757(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5757(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_5760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5760(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5760(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_6036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6036(t0,t1);}

static void C_fcall trf_6008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6008(t0,t1);}

static void C_fcall trf_5961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5961(t0,t1);}

static void C_fcall trf_5920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5920(t0,t1);}

static void C_fcall trf_6176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6176(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6176(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall trf_6196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6196(t0,t1);}

static void C_fcall trf_5561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5561(t0,t1);}

static void C_fcall trf_5084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5084(t0,t1);}

static void C_fcall trf_5015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5015(t0,t1);}

static void C_fcall trf_4759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4759(t0,t1);}

static void C_fcall trf_4615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4615(t0,t1);}

static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4391(t0,t1);}

static void C_fcall trf_4394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4394(t0,t1);}

static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3956(t0,t1);}

static void C_fcall trf_3953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3953(t0,t1);}

static void C_fcall trf_3820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3820(t0,t1);}

static void C_fcall trf_3801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3801(t0,t1,t2,t3);}

static void C_fcall trf_3543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3543(t0,t1);}

static void C_fcall trf_3456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3456(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3456(t0,t1,t2,t3);}

static void C_fcall trf_3462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3462(t0,t1,t2,t3);}

static void C_fcall trf_3250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3250(t0,t1);}

static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3265(t0,t1);}

static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3277(t0,t1);}

static void C_fcall trf_3286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3286(t0,t1);}

static void C_fcall trf_3039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3039(t0,t1);}

static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3051(t0,t1);}

static void C_fcall trf_3066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3066(t0,t1);}

static void C_fcall trf_2981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2981(t0,t1,t2,t3);}

static void C_fcall trf_2902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2902(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2902(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2019(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2019(t0,t1,t2);}

static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2853(t0,t1);}

static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2824(t0,t1);}

static void C_fcall trf_2400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2400(t0,t1);}

static void C_fcall trf_2421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2421(t0,t1);}

static void C_fcall trf_2617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2617(t0,t1);}

static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2472(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2122(t0,t1);}

static void C_fcall trf_2044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2044(t0,t1,t2);}

static void C_fcall trf_2083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2083(t0,t1);}

static void C_fcall trf_1911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1911(t0,t1);}

static void C_fcall trf_1702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1702(t0,t1,t2);}

static void C_fcall trf_1751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1751(t0,t1);}

static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1672(t0,t1,t2,t3);}

static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1512(t0,t1,t2,t3);}

static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1564(t0,t1);}

static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1537(t0,t1);}

static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1500(t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(6);
if(!C_demand(6)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2121)){
C_save(t1);
C_rereclaim2(2121*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(6);
C_initialize_lf(lf,451);
lf[1]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[3]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
lf[11]=C_static_string(C_heaptop,6,".dylib");
lf[13]=C_static_string(C_heaptop,4,".dll");
lf[15]=C_static_string(C_heaptop,3,".sl");
lf[17]=C_static_string(C_heaptop,3,".so");
lf[19]=C_static_string(C_heaptop,4,".scm");
lf[21]=C_static_string(C_heaptop,6,".setup");
lf[23]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[25]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[27]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[29]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[31]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[33]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[35]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[37]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[39]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[40]=C_h_intern(&lf[40],34,"\010compilerscan-toplevel-assignments");
lf[41]=C_static_lambda_info(C_heaptop,6,"(mark)");
lf[42]=C_h_intern(&lf[42],12,"always-bound");
lf[43]=C_h_intern(&lf[43],6,"append");
lf[44]=C_h_intern(&lf[44],18,"\010compilerdebugging");
lf[45]=C_h_intern(&lf[45],1,"o");
lf[46]=C_static_string(C_heaptop,12,"safe globals");
lf[47]=C_static_lambda_info(C_heaptop,11,"(a1505 n58)");
lf[48]=C_h_intern(&lf[48],12,"\003sysfor-each");
lf[49]=C_static_lambda_info(C_heaptop,20,"(scan-each ns56 e57)");
lf[50]=C_h_intern(&lf[50],13,"\004corevariable");
lf[51]=C_h_intern(&lf[51],2,"if");
lf[52]=C_h_intern(&lf[52],3,"let");
lf[53]=C_h_intern(&lf[53],6,"lambda");
lf[54]=C_h_intern(&lf[54],13,"\004corecallunit");
lf[55]=C_h_intern(&lf[55],9,"\004corecall");
lf[56]=C_h_intern(&lf[56],4,"set!");
lf[57]=C_h_intern(&lf[57],9,"\004corecond");
lf[58]=C_h_intern(&lf[58],11,"\004coreswitch");
lf[59]=C_static_lambda_info(C_heaptop,14,"(scan n59 e60)");
lf[60]=C_static_lambda_info(C_heaptop,16,"(a1496 return53)");
lf[61]=C_h_intern(&lf[61],30,"call-with-current-continuation");
lf[62]=C_h_intern(&lf[62],1,"p");
lf[63]=C_static_string(C_heaptop,32,"scanning toplevel assignments...");
lf[64]=C_static_lambda_info(C_heaptop,45,"(##compiler#scan-toplevel-assignments node48)");
lf[65]=C_h_intern(&lf[65],24,"\010compilersimplifications");
lf[66]=C_h_intern(&lf[66],41,"\010compilerperform-high-level-optimizations");
lf[67]=C_h_intern(&lf[67],12,"\010compilerget");
lf[68]=C_static_lambda_info(C_heaptop,21,"(test sym101 item102)");
lf[69]=C_h_intern(&lf[69],5,"quote");
lf[70]=C_static_lambda_info(C_heaptop,21,"(constant-node\077 n103)");
lf[71]=C_static_lambda_info(C_heaptop,12,"(node-value)");
lf[72]=C_static_lambda_info(C_heaptop,7,"(touch)");
lf[73]=C_h_intern(&lf[73],21,"apply-simplifications");
lf[74]=C_h_intern(&lf[74],26,"\010compilercompiler-features");
lf[75]=C_h_intern(&lf[75],10,"alist-cons");
lf[76]=C_h_intern(&lf[76],4,"caar");
lf[77]=C_static_lambda_info(C_heaptop,12,"(a1781 v116)");
lf[78]=C_h_intern(&lf[78],7,"\003sysmap");
lf[79]=C_h_intern(&lf[79],19,"\010compilermatch-node");
lf[80]=C_static_lambda_info(C_heaptop,12,"(a1722 s112)");
lf[81]=C_h_intern(&lf[81],3,"any");
lf[82]=C_h_intern(&lf[82],18,"\003syshash-table-ref");
lf[83]=C_static_lambda_info(C_heaptop,15,"(simplify n107)");
lf[84]=C_h_intern(&lf[84],30,"\010compilerbroken-constant-nodes");
lf[85]=C_h_intern(&lf[85],11,"lset-adjoin");
lf[86]=C_h_intern(&lf[86],3,"eq\077");
lf[87]=C_static_lambda_info(C_heaptop,7,"(a1906)");
lf[88]=C_static_lambda_info(C_heaptop,13,"(a1900 ex141)");
lf[89]=C_h_intern(&lf[89],4,"node");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[90]=C_h_pair(C_restore,tmp);
lf[91]=C_h_intern(&lf[91],14,"\010compilerqnode");
lf[92]=C_static_string(C_heaptop,27,"folding constant expression");
lf[93]=C_h_intern(&lf[93],4,"eval");
lf[94]=C_static_lambda_info(C_heaptop,7,"(a1923)");
lf[95]=C_static_lambda_info(C_heaptop,7,"(a1955)");
lf[96]=C_static_lambda_info(C_heaptop,17,"(a1949 . g139150)");
lf[97]=C_static_lambda_info(C_heaptop,7,"(a1917)");
lf[98]=C_h_intern(&lf[98],22,"with-exception-handler");
lf[99]=C_static_lambda_info(C_heaptop,15,"(a1894 g138140)");
lf[100]=C_static_lambda_info(C_heaptop,14,"(a1965 arg137)");
lf[101]=C_h_intern(&lf[101],19,"\010compilertry-harder");
lf[102]=C_h_intern(&lf[102],5,"every");
lf[103]=C_h_intern(&lf[103],8,"foldable");
lf[104]=C_h_intern(&lf[104],16,"extended-binding");
lf[105]=C_h_intern(&lf[105],16,"standard-binding");
lf[106]=C_static_lambda_info(C_heaptop,11,"(walk n121)");
lf[107]=C_h_intern(&lf[107],5,"value");
lf[108]=C_static_string(C_heaptop,29,"substituted constant variable");
lf[109]=C_h_intern(&lf[109],16,"\010compilervarnode");
lf[110]=C_h_intern(&lf[110],11,"collapsable");
lf[111]=C_h_intern(&lf[111],10,"replacable");
lf[112]=C_static_lambda_info(C_heaptop,16,"(replace var161)");
lf[113]=C_h_intern(&lf[113],9,"replacing");
lf[114]=C_h_intern(&lf[114],12,"contractable");
lf[115]=C_h_intern(&lf[115],9,"removable");
lf[116]=C_h_intern(&lf[116],11,"\004corelambda");
lf[117]=C_h_intern(&lf[117],6,"unused");
lf[118]=C_static_lambda_info(C_heaptop,12,"(a2192 v184)");
lf[119]=C_h_intern(&lf[119],9,"partition");
lf[120]=C_static_lambda_info(C_heaptop,7,"(a2186)");
lf[121]=C_h_intern(&lf[121],26,"\010compilerbuild-lambda-list");
lf[122]=C_static_string(C_heaptop,39,"merged explicitly consed rest parameter");
lf[123]=C_h_intern(&lf[123],13,"explicit-rest");
lf[124]=C_static_string(C_heaptop,32,"removed unused formal parameters");
lf[125]=C_static_lambda_info(C_heaptop,25,"(a2198 unused185 used186)");
lf[126]=C_static_lambda_info(C_heaptop,31,"(a2180 vars181 argc182 rest183)");
lf[127]=C_h_intern(&lf[127],30,"\010compilerdecompose-lambda-list");
lf[128]=C_static_string(C_heaptop,39,"merged explicitly consed rest parameter");
lf[129]=C_static_lambda_info(C_heaptop,31,"(a2272 vars193 argc194 rest195)");
lf[130]=C_h_intern(&lf[130],21,"has-unused-parameters");
lf[131]=C_h_intern(&lf[131],31,"\010compilerinline-lambda-bindings");
lf[132]=C_static_string(C_heaptop,20,"contracted procedure");
lf[133]=C_h_intern(&lf[133],24,"\010compilercheck-signature");
lf[134]=C_static_string(C_heaptop,18,"inlining procedure");
lf[135]=C_h_intern(&lf[135],1,"i");
lf[136]=C_static_string(C_heaptop,19,"procedure inlinable");
lf[137]=C_h_intern(&lf[137],14,"append-reverse");
lf[138]=C_h_intern(&lf[138],6,"gensym");
lf[139]=C_h_intern(&lf[139],1,"t");
lf[140]=C_h_intern(&lf[140],37,"\010compilerexpression-has-side-effects\077");
lf[141]=C_static_string(C_heaptop,43,"removed unused parameter to known procedure");
lf[142]=C_static_lambda_info(C_heaptop,38,"(loop vars233 argc234 args235 used236)");
lf[143]=C_h_intern(&lf[143],8,"split-at");
lf[144]=C_static_lambda_info(C_heaptop,7,"(a2636)");
lf[145]=C_static_string(C_heaptop,10,"C_a_i_list");
lf[146]=C_h_intern(&lf[146],20,"\004coreinline_allocate");
lf[147]=C_static_lambda_info(C_heaptop,30,"(a2642 args250252 rargs251253)");
lf[148]=C_static_string(C_heaptop,34,"consed rest parameter at call site");
lf[149]=C_h_intern(&lf[149],24,"\010compilernot-inline-list");
lf[150]=C_h_intern(&lf[150],20,"\010compilerinline-list");
lf[151]=C_h_intern(&lf[151],24,"\010compilerinline-max-size");
lf[152]=C_h_intern(&lf[152],9,"inlinable");
lf[153]=C_h_intern(&lf[153],6,"simple");
lf[154]=C_static_lambda_info(C_heaptop,31,"(a2410 vars221 argc222 rest223)");
lf[155]=C_h_intern(&lf[155],7,"unknown");
lf[156]=C_h_intern(&lf[156],14,"\004coreundefined");
lf[157]=C_static_string(C_heaptop,54,"removed side-effect free assignment to unused variable");
lf[158]=C_h_intern(&lf[158],10,"references");
lf[159]=C_h_intern(&lf[159],26,"\010compilerblock-compilation");
lf[160]=C_h_intern(&lf[160],20,"\010compilerexport-list");
lf[161]=C_h_intern(&lf[161],6,"global");
lf[162]=C_static_lambda_info(C_heaptop,12,"(walk1 n151)");
lf[163]=C_static_lambda_info(C_heaptop,46,"(walk-generic n287 class288 params289 subs290)");
lf[164]=C_static_string(C_heaptop,25,"removed conditional forms");
lf[165]=C_static_string(C_heaptop,21,"removed binding forms");
lf[166]=C_static_string(C_heaptop,18,"replaced variables");
lf[167]=C_static_string(C_heaptop,15,"simplifications");
lf[168]=C_static_string(C_heaptop,18,"traversal phase...");
lf[169]=C_h_intern(&lf[169],34,"\010compilerperform-pre-optimization!");
lf[170]=C_static_lambda_info(C_heaptop,57,"(##compiler#perform-high-level-optimizations node85 db86)");
lf[171]=C_static_lambda_info(C_heaptop,7,"(touch)");
lf[172]=C_static_lambda_info(C_heaptop,21,"(test sym316 prop317)");
lf[173]=C_static_string(C_heaptop,19,"Removed `not\047 forms");
lf[174]=C_h_intern(&lf[174],24,"node-subexpressions-set!");
lf[175]=C_h_intern(&lf[175],20,"node-parameters-set!");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[176]=C_h_pair(C_restore,tmp);
lf[177]=C_static_string(C_heaptop,28,"removed call in test-context");
lf[178]=C_static_lambda_info(C_heaptop,13,"(a3179 sn356)");
lf[179]=C_static_lambda_info(C_heaptop,15,"(a3016 site347)");
lf[180]=C_h_intern(&lf[180],10,"call-sites");
lf[181]=C_static_lambda_info(C_heaptop,18,"(a3004 varname346)");
lf[182]=C_h_intern(&lf[182],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[183]=C_h_intern(&lf[183],7,"reverse");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[184]=C_h_pair(C_restore,tmp);
lf[185]=C_static_lambda_info(C_heaptop,15,"(a3227 site318)");
lf[186]=C_h_intern(&lf[186],3,"not");
lf[187]=C_static_string(C_heaptop,25,"pre-optimization phase...");
lf[188]=C_static_lambda_info(C_heaptop,52,"(##compiler#perform-pre-optimization! node309 db310)");
lf[189]=C_h_intern(&lf[189],24,"register-simplifications");
lf[190]=C_h_intern(&lf[190],19,"\003syshash-table-set!");
lf[191]=C_static_lambda_info(C_heaptop,43,"(register-simplifications class381 . ss382)");
lf[192]=C_h_intern(&lf[192],38,"\010compilerreorganize-recursive-bindings");
lf[193]=C_static_lambda_info(C_heaptop,12,"(a3485 v526)");
lf[194]=C_static_lambda_info(C_heaptop,26,"(find var520 traversed521)");
lf[195]=C_static_lambda_info(C_heaptop,27,"(find-path var1517 var2518)");
lf[196]=C_static_string(C_heaptop,22,"eliminated assignments");
lf[197]=C_static_lambda_info(C_heaptop,22,"(a3565 var554 rest555)");
lf[198]=C_h_intern(&lf[198],10,"fold-right");
lf[199]=C_static_lambda_info(C_heaptop,22,"(a3585 var562 rest563)");
lf[200]=C_static_lambda_info(C_heaptop,21,"(a3529 gn546 body547)");
lf[201]=C_h_intern(&lf[201],4,"fold");
lf[202]=C_h_intern(&lf[202],25,"\010compilertopological-sort");
lf[203]=C_h_intern(&lf[203],6,"lset<=");
lf[204]=C_static_lambda_info(C_heaptop,13,"(a3662 g2542)");
lf[205]=C_h_intern(&lf[205],10,"filter-map");
lf[206]=C_static_lambda_info(C_heaptop,12,"(a3694 v541)");
lf[207]=C_h_intern(&lf[207],6,"filter");
lf[208]=C_static_lambda_info(C_heaptop,14,"(a3688 var540)");
lf[209]=C_h_intern(&lf[209],10,"append-map");
lf[210]=C_static_lambda_info(C_heaptop,12,"(a3645 g537)");
lf[211]=C_static_lambda_info(C_heaptop,12,"(a3736 v534)");
lf[212]=C_static_lambda_info(C_heaptop,14,"(a3704 var532)");
lf[213]=C_h_intern(&lf[213],28,"\010compilerscan-used-variables");
lf[214]=C_static_lambda_info(C_heaptop,21,"(a3762 var528 val529)");
lf[215]=C_h_intern(&lf[215],8,"for-each");
lf[216]=C_h_intern(&lf[216],3,"map");
lf[217]=C_h_intern(&lf[217],4,"cons");
lf[218]=C_static_lambda_info(C_heaptop,66,"(##compiler#reorganize-recursive-bindings vars511 vals512 body513)");
lf[219]=C_h_intern(&lf[219],27,"\010compilersubstitution-table");
lf[220]=C_h_intern(&lf[220],16,"\010compilerrewrite");
lf[221]=C_static_lambda_info(C_heaptop,48,"(##compiler#rewrite name575 . class-and-args576)");
lf[222]=C_h_intern(&lf[222],28,"\010compilersimplify-named-call");
lf[223]=C_static_lambda_info(C_heaptop,21,"(test sym589 prop590)");
lf[224]=C_h_intern(&lf[224],37,"\010compilerinline-substitutions-enabled");
lf[225]=C_h_intern(&lf[225],11,"\004coreinline");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[226]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[227]=C_h_pair(C_restore,tmp);
lf[228]=C_h_intern(&lf[228],6,"unsafe");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[229]=C_h_pair(C_restore,tmp);
lf[230]=C_h_intern(&lf[230],6,"vector");
lf[231]=C_h_intern(&lf[231],14,"rest-parameter");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[232]=C_h_pair(C_restore,tmp);
lf[233]=C_h_intern(&lf[233],11,"number-type");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[234]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[235]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[236]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[237]=C_h_pair(C_restore,tmp);
lf[238]=C_static_lambda_info(C_heaptop,22,"(a4404 x676 n677 y678)");
lf[239]=C_h_intern(&lf[239],6,"fixnum");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[240]=C_h_pair(C_restore,tmp);
lf[241]=C_static_lambda_info(C_heaptop,17,"(a4430 x686 y687)");
lf[242]=C_h_intern(&lf[242],21,"\010compilerfold-boolean");
lf[243]=C_static_lambda_info(C_heaptop,12,"(a4452 z674)");
lf[244]=C_h_intern(&lf[244],6,"flonum");
lf[245]=C_h_intern(&lf[245],7,"generic");
lf[246]=C_h_intern(&lf[246],5,"cons*");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[247]=C_h_pair(C_restore,tmp);
lf[248]=C_h_intern(&lf[248],9,"\004coreproc");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[249]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[250]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[251]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[252]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[253]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[254]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[255]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[256]=C_h_pair(C_restore,tmp);
lf[257]=C_static_lambda_info(C_heaptop,17,"(a5228 x798 y799)");
lf[258]=C_h_intern(&lf[258],19,"\010compilerfold-inner");
lf[259]=C_static_lambda_info(C_heaptop,12,"(a5247 x784)");
lf[260]=C_h_intern(&lf[260],6,"remove");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[261]=C_h_pair(C_restore,tmp);
lf[262]=C_static_lambda_info(C_heaptop,7,"(a5332)");
lf[263]=C_static_lambda_info(C_heaptop,29,"(a5342 head814816 tail815817)");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[264]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[265]=C_h_pair(C_restore,tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[266]=C_h_pair(C_restore,tmp);
lf[267]=C_static_lambda_info(C_heaptop,17,"(a5446 x839 y840)");
lf[268]=C_static_lambda_info(C_heaptop,12,"(a5477 x827)");
lf[269]=C_h_intern(&lf[269],5,"fifth");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[270]=C_h_pair(C_restore,tmp);
lf[271]=C_h_intern(&lf[271],13,"\010compilerbomb");
lf[272]=C_static_string(C_heaptop,19,"bad type (optimize)");
lf[273]=C_static_lambda_info(C_heaptop,98,"(##compiler#simplify-named-call db580 params581 name582 cont583 class584 classar"
"gs585 callargs586)");
lf[274]=C_h_intern(&lf[274],34,"\010compilertransform-direct-lambdas!");
lf[275]=C_static_lambda_info(C_heaptop,13,"(a6239 h1043)");
lf[276]=C_h_intern(&lf[276],19,"\010compilercopy-node!");
lf[277]=C_static_lambda_info(C_heaptop,22,"(a6267 h1030 rest1031)");
lf[278]=C_h_intern(&lf[278],16,"\004coredirect_call");
lf[279]=C_h_intern(&lf[279],7,"warning");
lf[280]=C_static_string(C_heaptop,59,"known procedure called with wrong number of arguments: `~A\047");
lf[281]=C_static_lambda_info(C_heaptop,16,"(a6309 site1015)");
lf[282]=C_static_lambda_info(C_heaptop,21,"(a6368 s11023 s21024)");
lf[283]=C_h_intern(&lf[283],15,"lset-difference");
lf[284]=C_h_intern(&lf[284],15,"node-class-set!");
lf[285]=C_h_intern(&lf[285],12,"\004corerecurse");
lf[286]=C_static_string(C_heaptop,71,"known procedure called recursively with wrong number of arguments: `~A\047");
lf[287]=C_h_intern(&lf[287],4,"take");
lf[288]=C_static_string(C_heaptop,71,"known procedure called recursively with wrong number of arguments: `~A\047");
lf[289]=C_static_string(C_heaptop,12,"missing kvar");
lf[290]=C_h_intern(&lf[290],11,"\004corereturn");
lf[291]=C_static_string(C_heaptop,15,"bad call (leaf)");
lf[292]=C_static_lambda_info(C_heaptop,10,"(rec n974)");
lf[293]=C_h_intern(&lf[293],18,"\004coredirect_lambda");
lf[294]=C_h_intern(&lf[294],6,"cdaddr");
lf[295]=C_h_intern(&lf[295],6,"caaddr");
lf[296]=C_static_string(C_heaptop,22,"invalid parameter list");
lf[297]=C_static_string(C_heaptop,54,"direct leaf routine with hoistable closures/allocation");
lf[298]=C_h_intern(&lf[298],6,"unzip1");
lf[299]=C_static_lambda_info(C_heaptop,7,"(a6711)");
lf[300]=C_h_intern(&lf[300],16,"\003sysmake-promise");
lf[301]=C_static_string(C_heaptop,30,"direct leaf routine/allocation");
lf[302]=C_static_lambda_info(C_heaptop,66,"(transform n951 fnvar952 ks953 hoistable954 destn955 allocated956)");
lf[303]=C_h_intern(&lf[303],5,"boxed");
lf[304]=C_static_lambda_info(C_heaptop,31,"(a5826 vars914 argc915 rest916)");
lf[305]=C_static_lambda_info(C_heaptop,12,"(a5863 x918)");
lf[306]=C_h_intern(&lf[306],15,"\004coreinline_ref");
lf[307]=C_static_lambda_info(C_heaptop,12,"(a5924 x925)");
lf[308]=C_h_intern(&lf[308],37,"\010compilerestimate-foreign-result-size");
lf[309]=C_h_intern(&lf[309],19,"\004coreinline_loc_ref");
lf[310]=C_static_lambda_info(C_heaptop,12,"(a5965 x930)");
lf[311]=C_static_lambda_info(C_heaptop,12,"(a6012 x940)");
lf[312]=C_static_lambda_info(C_heaptop,12,"(a6096 x944)");
lf[313]=C_static_lambda_info(C_heaptop,12,"(a6153 x946)");
lf[314]=C_static_lambda_info(C_heaptop,26,"(rec n897 v898 vn899 e900)");
lf[315]=C_h_intern(&lf[315],5,"lset=");
lf[316]=C_h_intern(&lf[316],6,"delete");
lf[317]=C_static_lambda_info(C_heaptop,44,"(scan n889 kvar890 fnvar891 destn892 env893)");
lf[318]=C_static_lambda_info(C_heaptop,12,"(a5750 x888)");
lf[319]=C_static_lambda_info(C_heaptop,22,"(walk d873 n874 dn875)");
lf[320]=C_static_string(C_heaptop,40,"direct leaf routine optimization pass...");
lf[321]=C_static_lambda_info(C_heaptop,52,"(##compiler#transform-direct-lambdas! node864 db865)");
lf[322]=C_h_intern(&lf[322],32,"\010compilerperform-lambda-lifting!");
lf[323]=C_static_lambda_info(C_heaptop,25,"(a6735 sym1081 plist1082)");
lf[324]=C_h_intern(&lf[324],23,"\003syshash-table-for-each");
lf[325]=C_static_lambda_info(C_heaptop,25,"(find-lifting-candidates)");
lf[326]=C_static_lambda_info(C_heaptop,13,"(a6865 n1110)");
lf[327]=C_static_lambda_info(C_heaptop,24,"(loop vars1114 vals1115)");
lf[328]=C_static_lambda_info(C_heaptop,34,"(a6954 vars1119 argc1120 rest1121)");
lf[329]=C_static_lambda_info(C_heaptop,13,"(a6971 n1122)");
lf[330]=C_static_lambda_info(C_heaptop,20,"(walk n1095 env1096)");
lf[331]=C_static_lambda_info(C_heaptop,33,"(a7008 vars1128 arg1129 rest1130)");
lf[332]=C_static_lambda_info(C_heaptop,14,"(a6983 cs1123)");
lf[333]=C_static_lambda_info(C_heaptop,25,"(build-call-graph cs1090)");
lf[334]=C_h_intern(&lf[334],8,"assigned");
lf[335]=C_static_lambda_info(C_heaptop,13,"(a7044 v1142)");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_static_lambda_info(C_heaptop,13,"(a7103 c1153)");
lf[338]=C_h_intern(&lf[338],17,"delete-duplicates");
lf[339]=C_static_lambda_info(C_heaptop,24,"(count n1147 walked1148)");
lf[340]=C_static_lambda_info(C_heaptop,14,"(a7032 gn1139)");
lf[341]=C_static_lambda_info(C_heaptop,28,"(eliminate cs1137 graph1138)");
lf[342]=C_static_lambda_info(C_heaptop,25,"(loop vars21177 vals1178)");
lf[343]=C_static_lambda_info(C_heaptop,35,"(a7218 vars21183 argc1184 rest1185)");
lf[344]=C_static_lambda_info(C_heaptop,13,"(a7252 n1187)");
lf[345]=C_h_intern(&lf[345],14,"\004coreprimitive");
lf[346]=C_static_lambda_info(C_heaptop,21,"(walk n1158 vars1159)");
lf[347]=C_static_lambda_info(C_heaptop,31,"(collect-accessibles graph1155)");
lf[348]=C_static_lambda_info(C_heaptop,25,"(loop vars21226 vals1227)");
lf[349]=C_static_lambda_info(C_heaptop,35,"(a7456 vars21230 argc1231 rest1232)");
lf[350]=C_static_lambda_info(C_heaptop,13,"(a7485 n1245)");
lf[351]=C_h_intern(&lf[351],7,"delete!");
lf[352]=C_static_lambda_info(C_heaptop,15,"(loop name1238)");
lf[353]=C_static_lambda_info(C_heaptop,18,"(a7491 return1234)");
lf[354]=C_static_lambda_info(C_heaptop,13,"(a7561 n1247)");
lf[355]=C_static_lambda_info(C_heaptop,21,"(walk n1207 vars1208)");
lf[356]=C_static_lambda_info(C_heaptop,22,"(eliminate4 graph1205)");
lf[357]=C_h_intern(&lf[357],11,"concatenate");
lf[358]=C_static_lambda_info(C_heaptop,14,"(a7699 n21282)");
lf[359]=C_static_lambda_info(C_heaptop,13,"(a7709 c1280)");
lf[360]=C_static_lambda_info(C_heaptop,17,"(a7723 g12771278)");
lf[361]=C_h_intern(&lf[361],5,"count");
lf[362]=C_static_lambda_info(C_heaptop,13,"(walk gn1275)");
lf[363]=C_static_lambda_info(C_heaptop,13,"(a7751 v1288)");
lf[364]=C_static_lambda_info(C_heaptop,34,"(a7635 vars1265 argc1266 rest1267)");
lf[365]=C_static_lambda_info(C_heaptop,12,"(walk n1255)");
lf[366]=C_static_lambda_info(C_heaptop,14,"(a7735 xt1285)");
lf[367]=C_static_lambda_info(C_heaptop,14,"(a7775 gn1273)");
lf[368]=C_static_lambda_info(C_heaptop,35,"(compute-extra-variables graph1250)");
lf[369]=C_h_intern(&lf[369],22,"\010compilerblock-globals");
lf[370]=C_static_lambda_info(C_heaptop,14,"(rename v1324)");
lf[371]=C_static_lambda_info(C_heaptop,34,"(a8015 vars1338 argc1339 rest1340)");
lf[372]=C_static_lambda_info(C_heaptop,12,"(walk n1327)");
lf[373]=C_static_lambda_info(C_heaptop,34,"(a7823 vars1301 argc1302 rest1303)");
lf[374]=C_static_lambda_info(C_heaptop,23,"(a7803 gn1296 body1297)");
lf[375]=C_static_lambda_info(C_heaptop,34,"(reconstruct! graph1294 extra1295)");
lf[376]=C_static_lambda_info(C_heaptop,12,"(walk n1346)");
lf[377]=C_static_lambda_info(C_heaptop,30,"(extend-call-sites! extra1344)");
lf[378]=C_static_lambda_info(C_heaptop,26,"(do1377 vars1379 vals1380)");
lf[379]=C_static_lambda_info(C_heaptop,12,"(walk n1365)");
lf[380]=C_static_lambda_info(C_heaptop,34,"(remove-local-bindings! graph1363)");
lf[381]=C_static_string(C_heaptop,31,"moving liftables to toplevel...");
lf[382]=C_static_string(C_heaptop,26,"removing local bindings...");
lf[383]=C_static_string(C_heaptop,22,"changing call sites...");
lf[384]=C_h_intern(&lf[384],12,"pretty-print");
lf[385]=C_h_intern(&lf[385],1,"l");
lf[386]=C_static_string(C_heaptop,22,"additional parameters:");
lf[387]=C_static_string(C_heaptop,29,"gathering extra parameters...");
lf[388]=C_static_string(C_heaptop,25,"liftable local procedures");
lf[389]=C_static_lambda_info(C_heaptop,7,"(a8348)");
lf[390]=C_static_lambda_info(C_heaptop,13,"(a7359 n1202)");
lf[391]=C_static_lambda_info(C_heaptop,14,"(a7353 gn1201)");
lf[392]=C_static_lambda_info(C_heaptop,22,"(loop graph1198 n1199)");
lf[393]=C_static_string(C_heaptop,65,"eliminating liftables by access-lists and non-liftable callees...");
lf[394]=C_static_string(C_heaptop,12,"accessibles:");
lf[395]=C_static_string(C_heaptop,25,"computing access-lists...");
lf[396]=C_static_string(C_heaptop,11,"call-graph:");
lf[397]=C_static_string(C_heaptop,28,"eliminating non-liftables...");
lf[398]=C_static_string(C_heaptop,22,"building call graph...");
lf[399]=C_static_string(C_heaptop,22,"gathering liftables...");
lf[400]=C_static_lambda_info(C_heaptop,52,"(##compiler#perform-lambda-lifting! node1063 db1064)");
lf[401]=C_h_intern(&lf[401],11,"make-vector");
lf[402]=C_h_intern(&lf[402],3,"var");
lf[403]=C_h_intern(&lf[403],2,"d2");
lf[404]=C_h_intern(&lf[404],1,"y");
lf[405]=C_h_intern(&lf[405],2,"d3");
lf[406]=C_h_intern(&lf[406],1,"z");
lf[407]=C_h_intern(&lf[407],2,"d1");
lf[408]=C_h_intern(&lf[408],1,"x");
lf[409]=C_static_lambda_info(C_heaptop,53,"(a8497 db473 d1474 d2475 d3476 x477 y478 z479 var480)");
lf[410]=C_h_intern(&lf[410],2,"op");
lf[411]=C_h_intern(&lf[411],5,"clist");
lf[412]=C_h_intern(&lf[412],34,"\010compilermembership-test-operators");
lf[413]=C_h_intern(&lf[413],32,"\010compilermembership-unfold-limit");
lf[414]=C_static_lambda_info(C_heaptop,20,"(a8433 c503 rest504)");
lf[415]=C_static_lambda_info(C_heaptop,49,"(a8386 db487 d1488 op489 x490 clist491 y492 z493)");
lf[416]=C_h_intern(&lf[416],4,"var1");
lf[417]=C_h_intern(&lf[417],4,"var0");
lf[418]=C_h_intern(&lf[418],6,"const1");
lf[419]=C_h_intern(&lf[419],4,"var2");
lf[420]=C_h_intern(&lf[420],6,"const2");
lf[421]=C_h_intern(&lf[421],5,"body2");
lf[422]=C_h_intern(&lf[422],4,"rest");
lf[423]=C_h_intern(&lf[423],5,"body1");
lf[424]=C_h_intern(&lf[424],27,"\010compilereq-inline-operator");
lf[425]=C_h_intern(&lf[425],17,"target-has-switch");
tmp=C_fix(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[426]=C_h_pair(C_restore,tmp);
lf[427]=C_h_intern(&lf[427],19,"\010compilerimmediate\077");
lf[428]=C_static_lambda_info(C_heaptop,101,"(a9043 db395 var0396 var1397 var2398 op399 const1400 const2401 body1402 body2403"
" d1404 d2405 rest406)");
lf[429]=C_h_intern(&lf[429],5,"const");
lf[430]=C_h_intern(&lf[430],1,"d");
lf[431]=C_h_intern(&lf[431],4,"body");
lf[432]=C_h_intern(&lf[432],1,"n");
lf[433]=C_h_intern(&lf[433],7,"clauses");
lf[434]=C_static_lambda_info(C_heaptop,72,"(a8915 db410 var411 op412 var0413 const414 d415 body416 n417 clauses418)");
lf[435]=C_h_intern(&lf[435],4,"more");
lf[436]=C_static_lambda_info(C_heaptop,7,"(a8803)");
lf[437]=C_static_lambda_info(C_heaptop,24,"(a8813 n456 progress457)");
lf[438]=C_static_lambda_info(C_heaptop,31,"(loop2 vals444 vars445 body446)");
lf[439]=C_static_lambda_info(C_heaptop,23,"(loop1 vars426 body427)");
lf[440]=C_static_lambda_info(C_heaptop,29,"(a8644 db422 var1423 more424)");
lf[441]=C_h_intern(&lf[441],4,"args");
lf[442]=C_static_lambda_info(C_heaptop,49,"(a8568 db460 var461 op462 args463 d464 x465 y466)");
lf[443]=C_h_intern(&lf[443],8,"\003syscons");
lf[444]=C_h_intern(&lf[444],1,"a");
lf[445]=C_h_intern(&lf[445],1,"b");
lf[446]=C_h_intern(&lf[446],1,"c");
lf[447]=C_h_intern(&lf[447],4,"cdar");
lf[448]=C_static_lambda_info(C_heaptop,17,"(loop entries389)");
lf[449]=C_static_lambda_info(C_heaptop,33,"(a9212 db383 a384 b385 c386 d387)");
lf[450]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,451);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t24=*((C_word*)lf[401]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t23,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1665 */
static void f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=lf[170],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=lf[188],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3435,a[2]=lf[191],tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9207,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9258,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9262,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_a_i_list(&a,1,lf[444]);
t11=(C_word)C_a_i_list(&a,2,lf[50],t10);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9270,a[2]=t11,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t13=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,lf[445],lf[446]);}

/* k9268 in k1665 */
static void f_9270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9260 in k1665 */
static void f_9262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[430],t1);}

/* k9256 in k1665 */
static void f_9258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[55],t1);}

/* k9205 in k1665 */
static void f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9207,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[444],lf[445],lf[446],lf[430]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9213,a[2]=lf[449],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,3,t1,t2,t3);
t5=C_retrieve(lf[189]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[55],t4);}

/* a9212 in k9205 in k1665 */
static void f_9213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc(c,7);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9213,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9221,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t6,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=C_retrieve(lf[82]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[219]),t3);}

/* k9219 in a9212 in k9205 in k1665 */
static void f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9221,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=lf[448],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_9226(t6,((C_word*)t0)[2],t2);}

/* loop in k9219 in a9212 in k9205 in k1665 */
static void C_fcall f_9226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9226,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9236,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9250,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k9248 in loop in k9219 in a9212 in k9205 in k1665 */
static void f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9254,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=*((C_word*)lf[447]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9252 in k9248 in loop in k9219 in a9212 in k9205 in k1665 */
static void f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[222]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9234 in loop in k9219 in a9212 in k9205 in k1665 */
static void f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_9226(t3,((C_word*)t0)[4],t2);}}

/* k3440 in k1665 */
static void f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[263],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[416]);
t4=(C_word)C_a_i_list(&a,1,lf[410]);
t5=(C_word)C_a_i_list(&a,1,lf[417]);
t6=(C_word)C_a_i_list(&a,2,lf[50],t5);
t7=(C_word)C_a_i_list(&a,1,lf[418]);
t8=(C_word)C_a_i_list(&a,2,lf[69],t7);
t9=(C_word)C_a_i_list(&a,4,lf[225],t4,t6,t8);
t10=(C_word)C_a_i_list(&a,1,lf[416]);
t11=(C_word)C_a_i_list(&a,2,lf[50],t10);
t12=(C_word)C_a_i_list(&a,1,lf[419]);
t13=(C_word)C_a_i_list(&a,1,lf[410]);
t14=(C_word)C_a_i_list(&a,1,lf[417]);
t15=(C_word)C_a_i_list(&a,2,lf[50],t14);
t16=(C_word)C_a_i_list(&a,1,lf[420]);
t17=(C_word)C_a_i_list(&a,2,lf[69],t16);
t18=(C_word)C_a_i_list(&a,4,lf[225],t13,t15,t17);
t19=(C_word)C_a_i_list(&a,1,lf[419]);
t20=(C_word)C_a_i_list(&a,2,lf[50],t19);
t21=(C_word)C_a_i_list(&a,5,lf[51],lf[403],t20,lf[421],lf[422]);
t22=(C_word)C_a_i_list(&a,4,lf[52],t12,t18,t21);
t23=(C_word)C_a_i_list(&a,5,lf[51],lf[407],t11,lf[423],t22);
t24=(C_word)C_a_i_list(&a,4,lf[52],t3,t9,t23);
t25=(C_word)C_a_i_list(&a,11,lf[417],lf[416],lf[419],lf[410],lf[418],lf[420],lf[423],lf[421],lf[407],lf[403],lf[422]);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9044,a[2]=lf[428],tmp=(C_word)a,a+=3,tmp);
t27=(C_word)C_a_i_list(&a,3,t24,t25,t26);
t28=(C_word)C_a_i_list(&a,1,lf[402]);
t29=(C_word)C_a_i_list(&a,1,lf[410]);
t30=(C_word)C_a_i_list(&a,1,lf[417]);
t31=(C_word)C_a_i_list(&a,2,lf[50],t30);
t32=(C_word)C_a_i_list(&a,1,lf[429]);
t33=(C_word)C_a_i_list(&a,2,lf[69],t32);
t34=(C_word)C_a_i_list(&a,4,lf[225],t29,t31,t33);
t35=(C_word)C_a_i_list(&a,1,lf[402]);
t36=(C_word)C_a_i_list(&a,2,lf[50],t35);
t37=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8990,a[2]=t27,a[3]=t2,a[4]=t34,a[5]=t28,a[6]=t36,tmp=(C_word)a,a+=7,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8994,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(C_word)C_a_i_list(&a,1,lf[432]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9002,a[2]=t39,a[3]=t38,tmp=(C_word)a,a+=4,tmp);
t41=(C_word)C_a_i_list(&a,1,lf[417]);
t42=(C_word)C_a_i_list(&a,2,lf[50],t41);
t43=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t43+1)))(4,t43,t40,t42,lf[433]);}

/* k9000 in k3440 in k1665 */
static void f_9002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8992 in k3440 in k1665 */
static void f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k8988 in k3440 in k1665 */
static void f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[118],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,lf[51],lf[430],((C_word*)t0)[6],lf[431],t1);
t3=(C_word)C_a_i_list(&a,4,lf[52],((C_word*)t0)[5],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,8,lf[402],lf[410],lf[417],lf[429],lf[430],lf[431],lf[432],lf[433]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8916,a[2]=lf[434],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_list(&a,3,t3,t4,t5);
t7=(C_word)C_a_i_list(&a,1,lf[416]);
t8=(C_word)C_a_i_list(&a,2,lf[156],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_list(&a,4,lf[52],t7,t8,lf[435]);
t10=(C_word)C_a_i_list(&a,2,lf[416],lf[435]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8645,a[2]=lf[440],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,3,t9,t10,t11);
t13=(C_word)C_a_i_list(&a,1,lf[402]);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8615,a[2]=t12,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8631,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_a_i_list(&a,1,lf[410]);
t17=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,t16,lf[441]);}

/* k8629 in k8988 in k3440 in k1665 */
static void f_8631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[225],t1);}

/* k8613 in k8988 in k3440 in k1665 */
static void f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8615,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[402]);
t3=(C_word)C_a_i_list(&a,2,lf[50],t2);
t4=(C_word)C_a_i_list(&a,5,lf[51],lf[430],t3,lf[408],lf[404]);
t5=(C_word)C_a_i_list(&a,4,lf[52],((C_word*)t0)[6],t1,t4);
t6=(C_word)C_a_i_list(&a,6,lf[402],lf[410],lf[441],lf[430],lf[408],lf[404]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8569,a[2]=lf[442],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,3,t5,t6,t7);
t9=C_retrieve(lf[189]);
((C_proc7)C_retrieve_proc(t9))(7,t9,((C_word*)t0)[5],lf[52],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* a8568 in k8613 in k8988 in k3440 in k1665 */
static void f_8569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8569,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[424])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8603,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t10=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[158]);}}

/* k8601 in a8568 in k8613 in k8988 in k3440 in k1665 */
static void f_8603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8603,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[89],lf[51],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a8644 in k8988 in k3440 in k1665 */
static void f_8645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8645,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8655,a[2]=t2,a[3]=t7,a[4]=lf[439],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_8655(t9,t1,t5,t4);}

/* loop1 in a8644 in k8988 in k3440 in k1665 */
static void C_fcall f_8655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8655,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
if(C_truep(C_retrieve(lf[101]))){
t10=(C_word)C_eqp(t5,lf[52]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[156]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[56]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8722,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t19=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8722,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,a[5]=lf[438],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8751(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void C_fcall f_8751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8751,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8767,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[52]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8874,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
t16=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t14,((C_word*)t0)[2],t15,lf[158]);}
else{
t14=t11;
f_8767(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_8767(t13,C_SCHEME_FALSE);}}

/* k8872 in loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8767(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[56],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_8767(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_8767(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_8767(t2,C_SCHEME_FALSE);}}}

/* k8765 in loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void C_fcall f_8767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
t8=((C_word*)((C_word*)t0)[5])[1];
f_8751(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[436],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8814,a[2]=lf[437],tmp=(C_word)a,a+=3,tmp);
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a8813 in k8765 in loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void f_8814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8814,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a8803 in k8765 in loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8810 in a8803 in k8765 in loop2 in k8720 in loop1 in a8644 in k8988 in k3440 in k1665 */
static void f_8812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8915 in k8988 in k3440 in k1665 */
static void f_8916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc(c,11);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_8916,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[424])))){
if(C_truep((C_word)C_i_memq(lf[425],C_retrieve(lf[74])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8935,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t12=C_retrieve(lf[427]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k8933 in a8915 in k8988 in k3440 in k1665 */
static void f_8935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8935,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8970,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[158]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8968 in k8933 in a8915 in k8988 in k3440 in k1665 */
static void f_8970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8970,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8947,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8952 in k8968 in k8933 in a8915 in k8988 in k3440 in k1665 */
static void f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8956 in k8952 in k8968 in k8933 in a8915 in k8988 in k3440 in k1665 */
static void f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[246]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8945 in k8968 in k8933 in a8915 in k8988 in k3440 in k1665 */
static void f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8947,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[58],((C_word*)t0)[2],t1));}

/* a9043 in k3440 in k1665 */
static void f_9044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc(c,14);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_9044,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[424])))){
if(C_truep((C_word)C_i_memq(lf[425],C_retrieve(lf[74])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9063,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t15=C_retrieve(lf[427]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k9061 in a9043 in k3440 in k1665 */
static void f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=C_retrieve(lf[427]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9069,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[158]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9113 in k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9115,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t5=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[158]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9105 in k9113 in k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9089 in k9105 in k9113 in k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9093 in k9089 in k9105 in k9113 in k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9097 in k9093 in k9089 in k9105 in k9113 in k9067 in k9061 in a9043 in k3440 in k1665 */
static void f_9099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9099,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[58],lf[426],t2));}

/* k3443 in k3440 in k1665 */
static void f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[162],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[402]);
t4=(C_word)C_a_i_list(&a,2,lf[50],t3);
t5=(C_word)C_a_i_list(&a,4,lf[55],lf[403],t4,lf[404]);
t6=(C_word)C_a_i_list(&a,1,lf[402]);
t7=(C_word)C_a_i_list(&a,2,lf[50],t6);
t8=(C_word)C_a_i_list(&a,4,lf[55],lf[405],t7,lf[406]);
t9=(C_word)C_a_i_list(&a,5,lf[51],lf[407],lf[408],t5,t8);
t10=(C_word)C_a_i_list(&a,7,lf[407],lf[403],lf[405],lf[408],lf[404],lf[406],lf[402]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8498,a[2]=lf[409],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,3,t9,t10,t11);
t13=(C_word)C_a_i_list(&a,1,lf[410]);
t14=(C_word)C_a_i_list(&a,1,lf[411]);
t15=(C_word)C_a_i_list(&a,2,lf[69],t14);
t16=(C_word)C_a_i_list(&a,4,lf[225],t13,lf[408],t15);
t17=(C_word)C_a_i_list(&a,5,lf[51],lf[407],t16,lf[404],lf[406]);
t18=(C_word)C_a_i_list(&a,6,lf[407],lf[410],lf[408],lf[411],lf[404],lf[406]);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=lf[415],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_a_i_list(&a,3,t17,t18,t19);
t21=C_retrieve(lf[189]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t2,lf[51],t12,t20);}

/* a8386 in k3443 in k3440 in k1665 */
static void f_8387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8387,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[412]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[413]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8409,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
t13=C_retrieve(lf[138]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8409,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8432,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8434,a[2]=t1,a[3]=t3,a[4]=lf[414],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k8462 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8433 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8434,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8456,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8454 in a8433 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8458 in k8454 in a8433 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8460,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[225],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k8450 in k8458 in k8454 in a8433 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8452,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[57],C_SCHEME_END_OF_LIST,t2));}

/* k8430 in k8407 in a8386 in k3443 in k3440 in k1665 */
static void f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8432,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[51],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[52],((C_word*)t0)[2],t4));}

/* a8497 in k3443 in k3440 in k1665 */
static void f_8498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc(c,10);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_8498,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8512,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t11=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8510 in a8497 in k3443 in k3440 in k1665 */
static void f_8512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8512,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[57],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t4));}

/* k3446 in k3443 in k3440 in k1665 */
static void f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=lf[218],tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[401]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3776,2,t0,t1);}
t2=C_mutate((C_word*)lf[219]+1,t1);
t3=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=lf[221],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=lf[273],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5592,a[2]=lf[321],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6727,a[2]=lf[400],tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[53],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6727,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6730,a[2]=t3,a[3]=t5,a[4]=lf[325],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6830,a[2]=t3,a[3]=lf[333],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7027,a[2]=t3,a[3]=lf[341],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7126,a[2]=t2,a[3]=t5,a[4]=lf[347],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7370,a[2]=t2,a[3]=lf[356],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=t3,a[3]=lf[368],tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7790,a[2]=t3,a[3]=t2,a[4]=lf[375],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8040,a[2]=t2,a[3]=lf[377],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8127,a[2]=t2,a[3]=lf[380],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8274,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
t16=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[62],lf[399]);}

/* k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[2];
f_6730(t3,t2);}

/* k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8280,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[398]);}

/* k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[2];
f_6830(t3,t2,((C_word*)t0)[3]);}

/* k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8286,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[397]);}

/* k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[4];
f_7027(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8292,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8366,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[385],lf[396]);}

/* k8364 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8292(2,t2,C_SCHEME_UNDEFINED);}}

/* k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[395]);}

/* k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
f_7126(t3,t2,((C_word*)t0)[3]);}

/* k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8360,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[385],lf[394]);}

/* k8358 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8301(2,t2,C_SCHEME_UNDEFINED);}}

/* k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[393]);}

/* k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[3];
f_7370(t4,t3,((C_word*)t0)[2]);}

/* k8355 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8357,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7336,a[2]=t4,a[3]=lf[392],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7336(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8355 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7336(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7336,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7354,a[2]=t2,a[3]=lf[391],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a7353 in loop in k8355 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7360,a[2]=((C_word*)t0)[2],a[3]=lf[390],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
t5=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a7359 in a7353 in loop in k8355 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7360,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k7338 in loop in k8355 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
f_7336(t5,((C_word*)t0)[3],t1,t2);}}

/* k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8347,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8349,a[2]=t1,a[3]=lf[389],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[300]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8348 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k8345 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[45],lf[388],t1);}

/* k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[387]);}

/* k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
f_7589(t3,t2,((C_word*)t0)[5]);}

/* k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8340,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[385],lf[386]);}

/* k8338 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8319(2,t2,C_SCHEME_UNDEFINED);}}

/* k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[383]);}

/* k8320 in k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
f_8040(t3,t2,((C_word*)t0)[4]);}

/* k8323 in k8320 in k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[382]);}

/* k8326 in k8323 in k8320 in k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
f_8127(t3,t2,((C_word*)t0)[4]);}

/* k8329 in k8326 in k8323 in k8320 in k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[381]);}

/* k8332 in k8329 in k8326 in k8323 in k8320 in k8317 in k8314 in k8311 in k8308 in k8305 in k8302 in k8299 in k8296 in k8293 in k8290 in k8287 in k8284 in k8281 in k8278 in k8275 in k8272 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
f_7790(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_8127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8127,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8133,a[2]=t4,a[3]=t2,a[4]=lf[379],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8133(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8133,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[52]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8152,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
t13=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[56]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8245,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
t14=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k8243 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8245,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[156]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8252 in k8243 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8255 in k8252 in k8243 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8152,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=lf[378],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_8157(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8157,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8180,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8195,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8198,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_8198(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_8198(t12,t11);}}}

/* k8196 in do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_8198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_8157(t4,((C_word*)t0)[2],t2,t3);}

/* k8193 in do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8178 in do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8187,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k8189 in k8178 in do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8185 in k8178 in do1377 in k8150 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8040,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8046,a[2]=t2,a[3]=t4,a[4]=lf[376],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8046(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8046,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[55]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8068,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[50],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8098,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8102,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
t21=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[109]),t20);}
else{
t17=t11;
f_8068(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_8068(2,t14,C_SCHEME_UNDEFINED);}}
else{
t10=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k8100 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k8096 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8066 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7790(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7790,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=lf[374],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,t2);}

/* a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7804,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7811,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[107]);}

/* k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_retrieve(lf[369]));
t3=C_mutate((C_word*)lf[369]+1,t2);
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[373],tmp=(C_word)a,a+=7,tmp);
t7=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7824,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7831,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[138]),t6);}

/* k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7834,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=*((C_word*)lf[216]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[217]+1),((C_word*)t0)[5],t1);}

/* k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7915,a[2]=t1,a[3]=lf[370],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7930,a[2]=t5,a[3]=t7,a[4]=lf[372],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7930(3,t9,t2,t4);}

/* walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[29],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7930,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[52]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7949,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[50]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7973,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
t13=((C_word*)t0)[2];
f_7915(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[56]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7986,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7997,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
t15=((C_word*)t0)[2];
f_7915(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[53]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,a[6]=lf[371],tmp=(C_word)a,a+=7,tmp);
t15=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,t13,t14);}
else{
t13=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a8015 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8016,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8031,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8035,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k8033 in a8015 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8029 in a8015 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_8031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7930(3,t4,((C_word*)t0)[2],t3);}

/* k7995 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7997,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7984 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7971 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7954 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7947 in walk in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7915,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k7835 in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[139]);}

/* k7884 in k7835 in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7886,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7870,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7874,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7872 in k7884 in k7835 in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
t4=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k7868 in k7884 in k7835 in k7832 in k7829 in a7823 in k7809 in a7803 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[89],lf[53],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[89],lf[56],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[89],lf[52],((C_word*)t0)[2],t7));}

/* k7800 in reconstruct! in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7589,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7654,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7776,a[2]=lf[367],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a7775 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7776,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7654,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7656,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=lf[362],tmp=(C_word)a,a+=7,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7731,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[366],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7736,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7774,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[107]);}

/* k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7774,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7598,a[2]=t6,a[3]=t3,a[4]=lf[365],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7598(3,t8,t4,t1);}

/* walk in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7598,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[52]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7618,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t11=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[53]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=lf[364],tmp=(C_word)a,a+=6,tmp);
t13=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t13))(4,t13,t1,t11,t12);}
else{
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a7635 in walk in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7636,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7641,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7639 in a7635 in walk in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7598(3,t4,((C_word*)t0)[2],t3);}

/* k7616 in walk in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7594 in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7752,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=lf[363],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7766,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=C_retrieve(lf[338]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[86]+1));}

/* k7764 in k7594 in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[260]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7751 in k7594 in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7752,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k7748 in k7594 in k7772 in a7735 in k7729 in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7656,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7724,a[2]=t3,a[3]=lf[360],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[361]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a7723 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7724,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7722,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7676,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[359],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a7709 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7710,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_7656(3,t4,t1,t3);}

/* k7674 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7676,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7686,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7694,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7698,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[4],a[3]=lf[358],tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a7699 in k7674 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7700,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k7696 in k7674 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[357]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7692 in k7674 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7684 in k7674 in k7720 in walk in k7652 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7370(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7370,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7374,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7376,a[2]=t3,a[3]=t6,a[4]=lf[355],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7376(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7376,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[50]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7395,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_7395(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t12)){
t13=t11;
f_7395(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[156]);
if(C_truep(t13)){
t14=t11;
f_7395(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[345]);
t15=t11;
f_7395(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[248])));}}}}

/* k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[52]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7406,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[348],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_7406(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[53]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=lf[349],tmp=(C_word)a,a+=6,tmp);
t6=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[55]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[353],tmp=(C_word)a,a+=6,tmp);
t8=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7562,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=lf[354],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a7561 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7562,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_7376(t3,t1,t2,((C_word*)t0)[2]);}

/* a7491 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7492,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[50],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=lf[352],tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_7508(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a7491 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7508,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7538,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
t9=C_retrieve(lf[203]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[86]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k7536 in loop in a7491 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7538,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_7528(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_retrieve(lf[351]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[86]+1));}}

/* k7540 in k7536 in loop in a7491 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7526 in loop in a7491 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7479 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[350],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7485 in k7479 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7486,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_7376(t3,t1,t2,((C_word*)t0)[2]);}

/* a7456 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7457,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7469,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7467 in a7456 in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7406(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7406,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7424,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7427,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)((C_word*)t0)[5])[1];
f_7376(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7425 in loop in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7406(t4,((C_word*)t0)[2],t2,t3);}

/* k7422 in loop in k7393 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7372 in eliminate4 in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7126(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7126,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7130,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7132,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=lf[346],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_7132(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7132,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[50]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_7151(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t12)){
t13=t11;
f_7151(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[156]);
if(C_truep(t13)){
t14=t11;
f_7151(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[345]);
t15=t11;
f_7151(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[248])));}}}}

/* k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[52]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7162,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=lf[342],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_7162(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[53]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7210,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7244,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
t9=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_7210(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_7210(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=lf[344],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a7252 in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7253,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_7132(t3,t1,t2,((C_word*)t0)[2]);}

/* k7242 in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7210(t3,t2);}

/* k7208 in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7210,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[343],tmp=(C_word)a,a+=6,tmp);
t4=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a7218 in k7208 in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7219,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7231,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7229 in a7218 in k7208 in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7132(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7162,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7180,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=((C_word*)((C_word*)t0)[5])[1];
f_7132(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7181 in loop in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7162(t4,((C_word*)t0)[2],t2,t3);}

/* k7178 in loop in k7149 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7132(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7128 in collect-accessibles in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7027,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7033,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[340],tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[260]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7033,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7067,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7077,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7082,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=lf[339],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7082(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_7082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7082,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7089,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
t7=C_retrieve(lf[283]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[86]+1),t6,t3,((C_word*)t0)[2]);}

/* k7087 in count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=C_retrieve(lf[338]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[86]+1));}

/* k7114 in k7087 in count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7110 in k7114 in k7087 in count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7104,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=lf[337],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7103 in k7110 in k7114 in k7087 in count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7104,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_7082(t3,t1,t2,((C_word*)t0)[2]);}

/* k7100 in k7110 in k7114 in k7087 in count in k7075 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[201]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[336]+1),((C_word*)t0)[2],t1);}

/* k7065 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[335],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a7044 in k7065 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7045,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7052,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[334]);}

/* k7050 in a7044 in k7065 in a7032 in eliminate in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6830,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6833,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,a[7]=lf[330],tmp=(C_word)a,a+=8,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6982,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6984,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,a[6]=lf[332],tmp=(C_word)a,a+=7,tmp);
t14=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a6983 in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6984,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6999,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[331],tmp=(C_word)a,a+=5,tmp);
t11=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t6,t10);}

/* a7008 in a6983 in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7009,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
t7=((C_word*)((C_word*)t0)[2])[1];
f_6833(t7,t1,t6,t2);}

/* k6997 in a6983 in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k7001 in k6997 in a6983 in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6980 in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6833,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[50]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[56]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_6883(2,t16,t14);}
else{
t16=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,((C_word*)t0)[2],t12,lf[161]);}}
else{
t12=(C_word)C_eqp(t5,lf[52]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6901,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],a[6]=lf[327],tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_6901(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[53]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6955,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=lf[328],tmp=(C_word)a,a+=6,tmp);
t16=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6972,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[329],tmp=(C_word)a,a+=5,tmp);
t15=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a6971 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6972,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_6833(t3,t1,t2,((C_word*)t0)[2]);}

/* a6954 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6955,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6967,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k6965 in a6954 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_6833(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6901,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6919,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6925,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
t7=((C_word*)((C_word*)t0)[5])[1];
f_6833(t7,t5,t6,((C_word*)t0)[3]);}}

/* k6923 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_6901(t4,((C_word*)t0)[2],t2,t3);}

/* k6917 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_6833(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6881 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6858(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_6858(t4,t3);}}

/* k6856 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6858,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6861,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_6861(t5,t4);}
else{
t3=t2;
f_6861(t3,C_SCHEME_UNDEFINED);}}

/* k6859 in k6856 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6861,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[326],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6865 in k6859 in k6856 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6866,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_6833(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6730,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6734,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6736,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[323],tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[324]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6735 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6736,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[107],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[158],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[180],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6767,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[155],t3))){
t10=t9;
f_6767(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[53],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[161],t3))){
t13=t9;
f_6767(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_6767(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_6767(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6765 in a6735 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k6769 in k6765 in a6735 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k6773 in k6769 in k6765 in a6735 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6732 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[38],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5592,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6176,a[2]=t3,a[3]=t5,a[4]=lf[302],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5757,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,a[6]=lf[317],tmp=(C_word)a,a+=7,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5595,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,a[9]=lf[319],tmp=(C_word)a,a+=10,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6722,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t18=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[62],lf[320]);}

/* k6720 in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5595(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6723 in k6720 in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(31);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5595,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[116]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
t15=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[2],t2,lf[155]);}
else{
t14=t13;
f_5620(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_5620(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[56]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[52]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5731,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5751,a[2]=((C_word*)t0)[4],a[3]=lf[318],tmp=(C_word)a,a+=4,tmp);
t15=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a5750 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5751,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[2])[1];
f_5595(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k5729 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5595(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k5703 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_5620(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[107]);}
else{
t2=((C_word*)t0)[9];
f_5620(2,t2,C_SCHEME_FALSE);}}}

/* k5649 in k5703 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[158]);}
else{
t2=((C_word*)t0)[4];
f_5620(2,t2,C_SCHEME_FALSE);}}

/* k5655 in k5649 in k5703 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5657,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[180]);}
else{
t2=((C_word*)t0)[4];
f_5620(2,t2,C_SCHEME_FALSE);}}

/* k5661 in k5655 in k5649 in k5703 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t9=((C_word*)t0)[4];
f_5757(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_5620(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5620(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5620(2,t2,C_SCHEME_FALSE);}}

/* k5618 in walk in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_6176(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[2])[1];
f_5595(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5757,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5760,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,a[13]=lf[314],tmp=(C_word)a,a+=14,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t18=((C_word*)t12)[1];
f_5760(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k6165 in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[316]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[86]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6172 in k6165 in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[315]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[86]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(72);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5760,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[50]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t15=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[9],t13,lf[303]);}
else{
t13=(C_word)C_eqp(t11,lf[116]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5827,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=lf[304],tmp=(C_word)a,a+=8,tmp);
t16=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[146]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=lf[305],tmp=(C_word)a,a+=5,tmp);
t20=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t20))(4,t20,t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[293]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5898,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
t18=C_retrieve(lf[213]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[306]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
t19=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[309]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
t20=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[55]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[50],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6008,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6036,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[50],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_6036(t35,t34);}
else{
t31=t28;
f_6036(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_6008(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_6008(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[278]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6097,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=lf[312],tmp=(C_word)a,a+=5,tmp);
t26=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[56]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[52]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6130,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6154,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=lf[313],tmp=(C_word)a,a+=5,tmp);
t23=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t1,t22,t9);}}}}}}}}}}}

/* a6153 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6154,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6128 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6130,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6139 in k6128 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_5760(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a6096 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6097,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6034 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_6008(t3,C_SCHEME_TRUE);}

/* k6006 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[311],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6012 in k6006 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6013,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5953 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5955,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_5961(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_5961(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_5961(t7,C_SCHEME_TRUE);}}}

/* k5959 in k5953 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5961,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[310],tmp=(C_word)a,a+=5,tmp);
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5965 in k5959 in k5953 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5966,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5912 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_5920(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_5920(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_5920(t7,C_SCHEME_TRUE);}}}

/* k5918 in k5912 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[307],tmp=(C_word)a,a+=5,tmp);
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5924 in k5918 in k5912 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5925,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5896 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5892 in k5896 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a5863 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5864,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_5760(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a5826 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5827,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5843,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k5841 in a5826 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_5760(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k5807 in rec in scan in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6176,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6710,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6712,a[2]=t5,a[3]=lf[299],tmp=(C_word)a,a+=4,tmp);
t11=*((C_word*)lf[300]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t9=C_retrieve(lf[44]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[45],lf[301],t3,t7);}}

/* a6711 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6708 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[44]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[45],lf[297],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t10=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[180]);}

/* k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6190,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6684,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[294]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[11]);}
else{
t8=t4;
f_6196(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6196(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_6196(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_6196(t5,C_SCHEME_FALSE);}}

/* k6682 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_listp(t1))){
t2=(C_word)C_i_cdddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_6196(t4,(C_word)C_i_nullp(t3));}
else{
t3=((C_word*)t0)[2];
f_6196(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_6196(t2,C_SCHEME_FALSE);}}

/* k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_6196(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6196,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=*((C_word*)lf[295]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
t2=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[296],((C_word*)t0)[13]);}}

/* k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t3=*((C_word*)lf[294]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[293]);}

/* k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6214,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],a[10]=lf[292],tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_6387(3,t9,t2,t5);}

/* rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6387,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[55]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[50],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t19=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t19))(5,t19,t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6562,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t21=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t21))(4,t21,t20,t2,lf[290]);}
else{
t20=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t1,lf[291]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[52]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6609,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t14=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k6607 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6609,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k6610 in k6607 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_6387(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6560 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6563 in k6560 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_6440(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[286],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6486,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_6486(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,lf[288],((C_word*)t0)[4]);}}
else{
t7=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[289],((C_word*)t0)[11]);}}}

/* k6484 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[52]);}

/* k6487 in k6484 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6516,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=C_retrieve(lf[287]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t5,C_fix(1));}

/* k6514 in k6487 in k6484 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6490 in k6487 in k6484 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[89],lf[285],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
t7=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[2],t6);}

/* k6493 in k6490 in k6487 in k6484 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_6387(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6438 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[285]);}

/* k6441 in k6438 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
t4=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k6444 in k6441 in k6438 in k6429 in rec in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6217,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[281],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6367,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=lf[282],tmp=(C_word)a,a+=3,tmp);
t6=C_retrieve(lf[283]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a6368 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6369,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k6365 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6309 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6310,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6320,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_6320(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[280],((C_word*)t0)[2]);}}

/* k6318 in a6309 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[89],lf[278],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
t9=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[89],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6229,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6268,a[2]=lf[277],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6267 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6268,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[89],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[89],lf[52],t5,t13));}

/* k6230 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6233 in k6230 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6240,a[2]=lf[275],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6239 in k6233 in k6230 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6240,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6247,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6266,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[138]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6264 in a6239 in k6233 in k6230 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6266,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6245 in a6239 in k6233 in k6230 in k6227 in k6215 in k6212 in k6209 in k6203 in k6200 in k6194 in k6188 in k6178 in transform in ##compiler#transform-direct-lambdas! in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6247,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[156],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[173],*a=ab;
if(c!=9) C_bad_argc(c,9);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_3798,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3801,a[2]=t2,a[3]=lf[223],tmp=(C_word)a,a+=4,tmp);
switch(t6){
case C_fix(1):
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);
case C_fix(2):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3925,a[2]=t4,a[3]=t9,a[4]=t2,a[5]=t1,a[6]=t5,a[7]=t8,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t14=t9;
f_3801(t14,t13,t4,lf[104]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[224]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[224]))){
if(C_truep(C_retrieve(lf[228]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4067,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t9;
f_3801(t13,t12,t4,lf[105]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4123,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[104]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(6):
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[228]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[224]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4216,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t15=t9;
f_3801(t15,t14,t4,lf[105]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(7):
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[228]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[224]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t12,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4281,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t16=t9;
f_3801(t16,t15,t4,lf[105]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4342,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t2,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4369,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[228]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4513,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=t9;
f_3801(t13,t12,t4,lf[105]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[228]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4600,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t13=t9;
f_3801(t13,t12,t4,lf[105]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4665,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4741,a[2]=t4,a[3]=t9,a[4]=t3,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[104]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_cadr(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4806,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t14=t9;
f_3801(t14,t13,t4,lf[104]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(1),t10);
if(C_truep(t11)){
t12=C_retrieve(lf[228]);
t13=(C_truep(t12)?t12:(C_word)C_i_cadddr(t7));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4889,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t15=t9;
f_3801(t15,t14,t4,lf[104]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(16):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[224]))){
t13=(C_word)C_i_not(t10);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,t10));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4982,a[2]=t4,a[3]=t9,a[4]=t11,a[5]=t12,a[6]=t1,a[7]=t5,a[8]=t8,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t16=t9;
f_3801(t16,t15,t4,lf[104]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[224]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5061,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t14=t9;
f_3801(t14,t13,t4,lf[104]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[224]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5129,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[104]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5164,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(20):
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
t12=(C_truep(t11)?t11:C_retrieve(lf[228]));
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[224]))){
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t10,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5312,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t10,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t16=t9;
f_3801(t16,t15,t4,lf[105]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[224]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5385,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t11=t9;
f_3801(t11,t10,t4,lf[105]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(22):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[224]))){
t13=(C_word)C_eqp(t11,t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5539,a[2]=t4,a[3]=t9,a[4]=t12,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t15=t9;
f_3801(t15,t14,t4,lf[104]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
default:
t10=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t1,lf[272]);}}

/* k5537 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5542(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k5540 in k5537 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[228]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5561,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[233]),lf[239]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5574,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_5561(t9,(C_word)C_a_i_record(&a,4,lf[89],lf[146],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5572 in k5540 in k5537 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_5561(t4,(C_word)C_a_i_record(&a,4,lf[89],lf[225],t2,t3));}

/* k5559 in k5540 in k5537 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5561,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[270],t2));}

/* k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5388(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[228]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5403,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[3],a[3]=lf[268],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[260]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a5477 in k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5478,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[69],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5401 in k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5403,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[265],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[267],tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[258]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a5446 in k5401 in k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5447,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[233]),lf[239]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[225],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[146],t5,t6));}}

/* k5443 in k5401 in k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[266],t2));}

/* k5417 in k5401 in k5392 in k5386 in k5383 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[264],t2));}

/* k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5315(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k5313 in k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[262],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[6],a[3]=lf[263],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5342 in k5313 in k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5343,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5355,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5353 in a5342 in k5313 in k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[43]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5332 in k5313 in k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
t3=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k5326 in k5313 in k5310 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[89],lf[225],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[261],t3));}

/* k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5167(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[228]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5176,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=t2,a[3]=lf[259],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[260]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5247 in k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5248,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[69],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5174 in k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5176,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[255],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[233]),lf[239]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[2],a[3]=lf[257],tmp=(C_word)a,a+=4,tmp);
t7=C_retrieve(lf[258]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a5228 in k5174 in k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5229,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[89],lf[225],t4,t5));}

/* k5225 in k5174 in k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[256],t2));}

/* k5190 in k5174 in k5165 in k5162 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[254],t2));}

/* k5127 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_5132(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k5130 in k5127 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5140 in k5130 in k5127 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[253],t2));}

/* k5059 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5064(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k5062 in k5059 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[228]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_5084(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_5084(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5082 in k5062 in k5059 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5084,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[252],t6));}

/* k4980 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4985(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k4983 in k4980 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[228]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_5015(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_5015(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_5015(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5013 in k4983 in k4980 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_5015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5015,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[89],lf[146],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[251],t5));}

/* k4887 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4892(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k4890 in k4887 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[233]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4904,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
t9=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[233]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[250],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4909 in k4890 in k4887 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[246]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4902 in k4890 in k4887 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k4804 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4809(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k4807 in k4804 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[233]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[228]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[228]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[249],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4739 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4744(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k4742 in k4739 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[228]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_4759(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_4759(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4757 in k4742 in k4739 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_4759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4759,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4762,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[89],lf[248],t3,C_SCHEME_END_OF_LIST);
t5=C_retrieve(lf[246]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4760 in k4757 in k4742 in k4739 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k4663 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4668(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k4666 in k4663 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[228]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[247],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
t12=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4709 in k4666 in k4663 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[246]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4702 in k4666 in k4663 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k4598 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4603(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k4601 in k4598 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_4615(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_4615(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4613 in k4601 in k4598 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_4615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4626 in k4613 in k4601 in k4598 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[246]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4619 in k4613 in k4601 in k4598 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k4511 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4533 in k4511 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4541 in k4533 in k4511 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_4547(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k4545 in k4541 in k4533 in k4511 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t2));}

/* k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[228]))){
t4=(C_word)C_eqp(C_retrieve(lf[233]),lf[245]);
t5=t3;
f_4391(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4391(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_4391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4391,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4394(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[233]),lf[239]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_4394(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[233]),lf[244]);
t6=t2;
f_4394(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_4394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4394,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=lf[243],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4452 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4453,3,t0,t1,t2);}
t3=C_retrieve(lf[138]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4395 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4400,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[109]),t1);}

/* k4398 in k4395 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4405,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[233]),lf[239]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4431,a[2]=t5,a[3]=lf[241],tmp=(C_word)a,a+=4,tmp);
t8=C_retrieve(lf[242]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t1);}

/* a4430 in k4398 in k4395 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4431,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[225],((C_word*)t0)[2],t4));}

/* k4427 in k4398 in k4395 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[240],t2);
t4=C_retrieve(lf[198]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4404 in k4398 in k4395 in k4392 in k4389 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4405,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[52],t5,t6));}

/* k4383 in k4367 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[237],t2));}

/* k4340 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4345(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k4343 in k4340 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4279 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4284(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k4282 in k4279 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4306 in k4282 in k4279 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4295 in k4282 in k4279 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[89],lf[225],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[236],t3));}

/* k4214 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[235],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4121 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4126(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k4124 in k4121 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[233])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
t12=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4166 in k4124 in k4121 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[89],lf[225],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[234],t4));}

/* k4065 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4078 in k4065 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4086 in k4078 in k4065 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t3));}

/* k4027 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4037 in k4027 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[232],t2));}

/* k3923 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_3928(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_3801(t3,t2,((C_word*)t0)[2],lf[105]);}}

/* k3926 in k3923 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[228]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[50],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t13))(5,t13,t10,((C_word*)t0)[2],t12,lf[231]);}
else{
t10=t7;
f_3956(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_3956(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3983 in k3926 in k3923 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3956(t2,(C_word)C_eqp(lf[230],t1));}

/* k3954 in k3926 in k3923 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_3953(t4,(C_word)C_a_i_record(&a,4,lf[89],lf[225],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_3953(t5,(C_word)C_a_i_record(&a,4,lf[89],lf[225],t3,t4));}}

/* k3951 in k3926 in k3923 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3953,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[229],t2));}

/* k3815 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[50],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[50],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3880,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_3820(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_3820(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_3820(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_3820(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3878 in k3815 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_3820(t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[227],t2));}

/* k3818 in k3815 in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3820,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[224]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[89],lf[225],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[226],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* test in ##compiler#simplify-named-call in k3774 in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3801,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#rewrite in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3778(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3778r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3778r(t0,t1,t2,t3);}}

static void f_3778r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3782,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[82]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[219]),t2);}

/* k3780 in ##compiler#rewrite in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k3790 in k3780 in ##compiler#rewrite in k3774 in k3446 in k3443 in k3440 in k1665 */
static void f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[219]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3450,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3454,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=*((C_word*)lf[216]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[217]+1),t2,t3);}

/* k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[6],a[3]=lf[195],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=lf[214],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[215]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3762 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3763,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3768,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[213]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k3770 in a3762 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3766 in a3762 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=lf[212],tmp=(C_word)a,a+=7,tmp);
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3705,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3715,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[211],tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a3736 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3737,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
f_3456(t5,t4,((C_word*)t0)[3],t2);}}

/* k3748 in a3736 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3456(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3713 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3719,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=C_retrieve(lf[138]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3729 in k3713 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3717 in k3713 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=*((C_word*)lf[43]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k3721 in k3717 in k3713 in a3704 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3507,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=lf[210],tmp=(C_word)a,a+=7,tmp);
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3646,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[208],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
t7=C_retrieve(lf[209]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a3688 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3689,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3695,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=lf[206],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a3694 in a3688 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3695,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
f_3456(t3,t1,((C_word*)t0)[2],t2);}

/* k3651 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3663,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[204],tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a3662 in k3651 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3663,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
t6=C_retrieve(lf[203]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[86]+1),t5,((C_word*)t0)[2]);}}

/* k3674 in a3662 in k3651 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k3659 in k3651 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3655 in k3651 in a3645 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve(lf[202]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[86]+1));}

/* k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3510,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=lf[200],tmp=(C_word)a,a+=7,tmp);
t6=C_retrieve(lf[201]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3530,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3543,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_3543(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_3543(t9,C_SCHEME_FALSE);}}

/* k3541 in a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[52],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=lf[197],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[5],a[3]=lf[199],tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a3585 in k3541 in a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3586,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3618,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_retrieve(lf[138]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3616 in a3585 in k3541 in a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[89],lf[56],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[89],lf[52],t2,t8));}

/* k3582 in k3541 in a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3565 in k3541 in a3529 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3566,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[89],lf[156],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[89],lf[52],t4,t6));}

/* k3511 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[196],((C_word*)((C_word*)t0)[3])[1]);}
else{
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k3520 in k3511 in k3508 in k3505 in k3502 in k3499 in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3456(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3456,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3462,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[194],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3462(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void C_fcall f_3462(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3462,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3486,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=lf[193],tmp=(C_word)a,a+=5,tmp);
t9=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a3485 in find in find-path in k3452 in ##compiler#reorganize-recursive-bindings in k3446 in k3443 in k3440 in k1665 */
static void f_3486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3486,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_3462(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k1665 */
static void f_3435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3435r(t0,t1,t2,t3);}}

static void f_3435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
t4=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,*((C_word*)lf[65]+1),t2,t3);}

/* ##compiler#perform-pre-optimization! in k1665 */
static void f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2974,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2977,a[2]=t5,a[3]=lf[171],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=t3,a[3]=lf[172],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2988,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[62],lf[187]);}

/* k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3223,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[3];
f_2981(t4,t3,lf[186],lf[105]);}

/* k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[185],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3430,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
f_2981(t4,t3,lf[186],lf[180]);}
else{
t2=((C_word*)t0)[2];
f_2991(2,t2,C_SCHEME_UNDEFINED);}}

/* k3428 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3228,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3241,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3419,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
f_2981(t10,t9,t7,lf[155]);}

/* k3417 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3241(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[3];
f_2981(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[107]);}}

/* k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
f_2981(t3,t2,((C_word*)t0)[2],lf[158]);}

/* k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_3250(t8,(C_word)C_eqp(lf[116],t7));}
else{
t7=t2;
f_3250(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3250(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3250(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3250(t3,C_SCHEME_FALSE);}}

/* k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3250,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_3265(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_3265(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3265,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3271,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=((C_word*)t0)[2];
f_2981(t4,t3,t2,lf[158]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_3277(t6,(C_word)C_eqp(lf[51],t5));}
else{
t5=t2;
f_3277(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3277(t3,C_SCHEME_FALSE);}}

/* k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[50],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_3286(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_3286(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3284 in k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3286,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[184]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3291 in k3284 in k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3294 in k3291 in k3284 in k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k3312 in k3294 in k3291 in k3284 in k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3297 in k3294 in k3291 in k3284 in k3275 in k3269 in k3263 in k3248 in k3242 in k3239 in a3227 in k3221 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2977(((C_word*)t0)[2]));}

/* k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[181],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[182]));}

/* a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3012,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[3];
f_2981(t4,t3,t2,lf[105]);}

/* k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[179],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
f_2981(t4,t3,((C_word*)t0)[5],lf[180]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3215 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3017,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3030,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t9=((C_word*)t0)[3];
f_2981(t9,t8,t7,lf[158]);}

/* k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
f_2981(t4,t3,((C_word*)t0)[2],lf[155]);}

/* k3204 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3033(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[3];
f_2981(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[107]);}}

/* k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(lf[116],t3);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],a[3]=lf[178],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[7]);
t10=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t7=t2;
f_3039(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3039(t5,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3039(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3039(t3,C_SCHEME_FALSE);}}

/* a3179 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3180,3,t0,t1,t2);}
t3=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k3176 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3039(t2,(C_word)C_i_not(t1));}

/* k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_slot(t5,C_fix(1));
t9=t6;
f_3051(t9,(C_word)C_eqp(lf[51],t8));}
else{
t8=t6;
f_3051(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3051(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3057,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[2];
f_2981(t4,t3,t2,lf[158]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_length(t1);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(lf[50],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(2));
t10=(C_word)C_i_car(t9);
t11=t4;
f_3066(t11,(C_word)C_eqp(((C_word*)t0)[2],t10));}
else{
t9=t4;
f_3066(t9,C_SCHEME_FALSE);}}
else{
t7=t4;
f_3066(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3066(t5,C_SCHEME_FALSE);}}

/* k3064 in k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_3066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3066,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[45],lf[177],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3070 in k3064 in k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[176]);}

/* k3073 in k3070 in k3064 in k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k3091 in k3073 in k3070 in k3064 in k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3076 in k3073 in k3070 in k3064 in k3055 in k3049 in k3037 in k3031 in k3028 in a3016 in k3010 in a3004 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2977(((C_word*)t0)[2]));}

/* k2992 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[45],lf[173],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_2997(2,t4,C_SCHEME_UNDEFINED);}}

/* k2995 in k2992 in k2989 in k2986 in ##compiler#perform-pre-optimization! in k1665 */
static void f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k1665 */
static void C_fcall f_2981(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2981,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k1665 */
static C_word C_fcall f_2977(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k1665 */
static void f_1669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[78],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1669,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t3,a[3]=lf[68],tmp=(C_word)a,a+=4,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=t15,a[3]=lf[72],tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1702,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,a[6]=lf[83],tmp=(C_word)a,a+=7,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1800,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t24,a[6]=t18,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,a[11]=lf[106],tmp=(C_word)a,a+=12,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2019,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,a[10]=lf[162],tmp=(C_word)a,a+=11,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t24,a[3]=lf[163],tmp=(C_word)a,a+=4,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2921,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[101]))){
t33=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}
else{
t33=t32;
f_2921(2,t33,C_SCHEME_FALSE);}}

/* k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
if(C_truep(t1)){
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[62],lf[168]);}}

/* k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1800(3,t3,t2,((C_word*)t0)[2]);}

/* k2928 in k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[167],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_2933(2,t3,C_SCHEME_UNDEFINED);}}

/* k2931 in k2928 in k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[45],lf[166],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_2936(2,t4,C_SCHEME_UNDEFINED);}}

/* k2934 in k2931 in k2928 in k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[45],lf[165],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_2939(2,t4,C_SCHEME_UNDEFINED);}}

/* k2937 in k2934 in k2931 in k2928 in k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[45],lf[164],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_2942(2,t4,C_SCHEME_UNDEFINED);}}

/* k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2919 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2902,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2906,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k2904 in walk-generic in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2912,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve(lf[102]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[86]+1),((C_word*)t0)[2],t1);}

/* k2910 in k2904 in walk-generic in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[89],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2019,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[50]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,a[7]=lf[112],tmp=(C_word)a,a+=8,tmp));
t14=((C_word*)t12)[1];
f_2044(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[52]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2119,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t13=((C_word*)t0)[8];
f_1672(t13,t12,t11,lf[111]);}
else{
t11=(C_word)C_eqp(t8,lf[116]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2176,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
t15=((C_word*)t0)[8];
f_1672(t15,t13,t14,lf[130]);}
else{
t12=(C_word)C_eqp(t8,lf[55]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[50]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=t13,a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2759,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
t20=((C_word*)t0)[8];
f_1672(t20,t19,t17,lf[155]);}
else{
t16=(C_word)C_eqp(t14,lf[116]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
t17=((C_word*)((C_word*)t0)[4])[1];
f_2902(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t20=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t17=((C_word*)((C_word*)t0)[4])[1];
f_2902(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[56]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t16=((C_word*)t0)[8];
f_1672(t16,t15,t14,lf[114]);}
else{
t14=((C_word*)((C_word*)t0)[4])[1];
f_2902(t14,t1,t2,t8,t6,t4);}}}}}}

/* k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_2812(2,t3,t1);}
else{
t3=((C_word*)t0)[2];
f_1672(t3,t2,((C_word*)t0)[7],lf[111]);}}

/* k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[156],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
f_1672(t4,t3,((C_word*)t0)[7],lf[161]);}}

/* k2892 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2853(t4,t2);}
else{
t4=C_retrieve(lf[159]);
if(C_truep(t4)){
t5=t3;
f_2853(t5,t4);}
else{
if(C_truep(C_retrieve(lf[101]))){
if(C_truep(C_retrieve(lf[160]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[160]));
t6=t3;
f_2853(t6,(C_word)C_i_not(t5));}
else{
t5=t3;
f_2853(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_2853(t5,C_SCHEME_FALSE);}}}}

/* k2851 in k2892 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[158]);}
else{
t2=((C_word*)t0)[6];
f_2824(t2,C_SCHEME_FALSE);}}

/* k2872 in k2851 in k2892 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2824(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k2864 in k2872 in k2851 in k2892 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2824(t2,(C_word)C_i_not(t1));}

/* k2822 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[45],lf[157],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[2])[1];
f_1800(3,t4,t2,t3);}}

/* k2841 in k2822 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[56],((C_word*)t0)[2],t2));}

/* k2828 in k2822 in k2810 in k2807 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[156],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k2782 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k2757 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2355(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[3];
f_1672(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[107]);}}

/* k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[3];
f_1672(t4,t3,((C_word*)t0)[10],lf[114]);}

/* k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
t5=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_2400(t4,(C_word)C_eqp(lf[116],t3));}
else{
t3=t2;
f_2400(t3,C_SCHEME_FALSE);}}}

/* k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2400(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2400,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=lf[154],tmp=(C_word)a,a+=19,tmp);
t5=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)((C_word*)t0)[11])[1];
f_2902(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2411,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[17],a[4]=t6,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t8=((C_word*)t0)[3];
f_1672(t8,t7,t5,lf[153]);}

/* k2708 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
f_1672(t3,t2,((C_word*)t0)[5],lf[152]);}
else{
t2=((C_word*)t0)[4];
f_2421(t2,C_SCHEME_FALSE);}}

/* k2714 in k2708 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[149])))){
t2=((C_word*)t0)[3];
f_2421(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[150]));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_2421(t3,t2);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t4=C_retrieve(lf[151]);
t5=((C_word*)t0)[3];
f_2421(t5,(C_word)C_fixnum_lessp(t3,t4));}}}
else{
t2=((C_word*)t0)[3];
f_2421(t2,C_SCHEME_FALSE);}}

/* k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2421,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[14]);
t4=C_retrieve(lf[44]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[135],lf[136],((C_word*)t0)[15],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
t3=((C_word*)t0)[4];
f_1672(t3,t2,((C_word*)t0)[13],lf[130]);}}

/* k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=((C_word*)((C_word*)t0)[17])[1];
f_2902(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=lf[142],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2472(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2700,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[6];
f_1672(t4,t3,((C_word*)t0)[2],lf[123]);}}

/* k2698 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_2617(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2617(t2,C_SCHEME_FALSE);}}

/* k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
t4=((C_word*)((C_word*)t0)[11])[1];
f_2902(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=C_retrieve(lf[44]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[45],lf[148],((C_word*)t0)[3],t2);}}
else{
t2=((C_word*)((C_word*)t0)[11])[1];
f_2902(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[144],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[147],tmp=(C_word)a,a+=7,tmp);
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2642 in k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2647,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[145],t8);
t10=t6;
f_2670(2,t10,(C_word)C_a_i_record(&a,4,lf[89],lf[146],t9,t3));}}

/* k2668 in a2642 in k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2660 in a2642 in k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2645 in a2642 in k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2636 in k2630 in k2615 in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2472,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_1698(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t11=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
t10=((C_word*)t0)[2];
f_1672(t10,t8,t9,lf[117]);}}

/* k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_retrieve(lf[44]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[45],lf[141],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
t7=((C_word*)((C_word*)t0)[6])[1];
f_2472(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k2509 in k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=C_retrieve(lf[140]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k2515 in k2509 in k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[139]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=((C_word*)((C_word*)t0)[4])[1];
f_2472(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k2552 in k2515 in k2509 in k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=((C_word*)((C_word*)t0)[2])[1];
f_1800(3,t5,t3,t4);}

/* k2528 in k2552 in k2515 in k2509 in k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=((C_word*)((C_word*)t0)[3])[1];
f_2472(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k2532 in k2528 in k2552 in k2515 in k2509 in k2503 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[52],((C_word*)t0)[2],t2));}

/* k2497 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2486 in loop in k2456 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[55],((C_word*)t0)[2],t1));}

/* k2422 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2425 in k2422 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[134],((C_word*)t0)[2]);}

/* k2428 in k2425 in k2422 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=f_1698(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_retrieve(lf[131]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k2438 in k2428 in k2425 in k2422 in k2419 in a2410 in k2398 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1800(3,t2,((C_word*)t0)[2],t1);}

/* k2371 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[132],((C_word*)t0)[2]);}

/* k2374 in k2371 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=f_1698(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_retrieve(lf[131]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2384 in k2374 in k2371 in k2362 in k2353 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1800(3,t2,((C_word*)t0)[2],t1);}

/* k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=lf[126],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_retrieve(lf[101]))){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=((C_word*)t0)[11];
f_1672(t4,t2,t3,lf[123]);}
else{
t3=t2;
f_2268(2,t3,C_SCHEME_FALSE);}}}

/* k2266 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=lf[129],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
f_2902(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a2272 in k2266 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2273,5,t0,t1,t2,t3,t4);}
t5=f_1698(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2280,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[45],lf[128],t4);}

/* k2278 in a2272 in k2266 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2307 in k2278 in a2272 in k2266 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=((C_word*)((C_word*)t0)[2])[1];
f_1800(3,t6,t4,t5);}

/* k2291 in k2307 in k2278 in a2272 in k2266 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2293,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[116],((C_word*)t0)[2],t2));}

/* a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2181,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=lf[120],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=lf[125],tmp=(C_word)a,a+=10,tmp);
C_call_with_values(4,0,t1,t5,t6);}

/* a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2199,4,t0,t1,t2,t3);}
t4=f_1698(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t6=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[45],lf[124],t2);}

/* k2204 in a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=((C_word*)t0)[2];
f_1672(t7,t5,t6,lf[123]);}
else{
t6=t5;
f_2242(2,t6,C_SCHEME_FALSE);}}

/* k2240 in k2204 in a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[122],((C_word*)t0)[2]);}
else{
t2=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2243 in k2240 in k2204 in a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k2233 in k2204 in a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2219,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=((C_word*)((C_word*)t0)[2])[1];
f_1800(3,t6,t4,t5);}

/* k2217 in k2233 in k2204 in a2198 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[116],((C_word*)t0)[2],t2));}

/* a2186 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[3],a[3]=lf[118],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[119]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2192 in a2186 in a2180 in k2174 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2193,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_1672(t3,t1,t2,lf[117]);}

/* k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2122(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
f_1672(t4,t3,((C_word*)t0)[2],lf[115]);}}

/* k2143 in k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2122(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[114]);}}

/* k2152 in k2143 in k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[113]);}
else{
t2=((C_word*)t0)[4];
f_2122(t2,C_SCHEME_FALSE);}}

/* k2159 in k2152 in k2143 in k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2122(t2,(C_word)C_i_not(t1));}

/* k2120 in k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2122,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=((C_word*)((C_word*)t0)[4])[1];
f_1800(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k2137 in k2120 in k2117 in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[89],lf[52],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2044,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[4];
f_1672(t4,t3,t2,lf[111]);}

/* k2046 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[8])[1];
f_2044(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[5];
f_1672(t3,t2,((C_word*)t0)[4],lf[110]);}}

/* k2058 in k2046 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[45],lf[108],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_2083(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_1698(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_2083(t8,t7);}}}

/* k2081 in k2058 in k2046 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_2083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2064 in k2058 in k2046 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[107]);}

/* k2075 in k2064 in k2058 in k2046 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1665 */
static void f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
t4=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[84])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
f_2019(t5,t4,t2);}}

/* k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[51]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1832,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t2);
t8=((C_word*)t0)[5];
f_1678(3,t8,t6,t7);}
else{
t6=(C_word)C_eqp(t3,lf[55]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[50],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=t4,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[101]))){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1984,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t13,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t15=((C_word*)t0)[2];
f_1672(t15,t14,t12,lf[105]);}
else{
t14=t13;
f_1884(2,t14,C_SCHEME_FALSE);}}
else{
t10=t4;
f_1823(2,t10,t1);}}
else{
t7=t4;
f_1823(2,t7,t1);}}}

/* k1982 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1987(2,t3,t1);}
else{
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[104]);}}

/* k1985 in k1982 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
f_1672(t3,t2,((C_word*)t0)[2],lf[103]);}
else{
t2=((C_word*)t0)[5];
f_1884(2,t2,C_SCHEME_FALSE);}}

/* k1991 in k1985 in k1982 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1884(2,t2,C_SCHEME_FALSE);}}

/* k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=lf[100],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_1823(2,t2,((C_word*)t0)[7]);}}

/* a1965 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1966,3,t0,t1,t2);}
t3=f_1688(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[69],t3));}

/* k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1895,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=lf[99],tmp=(C_word)a,a+=9,tmp);
t5=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1901,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[88],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1918,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[97],tmp=(C_word)a,a+=7,tmp);
t5=C_retrieve(lf[98]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[94],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[2],a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
C_call_with_values(4,0,t1,t2,t3);}

/* a1949 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1950r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1950r(t0,t1,t2);}}

static void f_1950r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1956,a[2]=t2,a[3]=lf[95],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1955 in a1949 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1956,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1923 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1926 in a1923 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1931,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[92],((C_word*)t0)[2]);}

/* k1929 in k1926 in a1923 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=f_1698(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1946 in k1929 in k1926 in a1923 in a1917 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[89],lf[55],lf[90],t2));}

/* a1900 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1901,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[87],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1906 in a1900 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1911(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_1911(t4,t3);}}

/* k1909 in a1906 in a1900 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_1911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1911,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[85]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[86]+1),C_retrieve(lf[84]),((C_word*)t0)[2]);}

/* k1913 in k1909 in a1906 in a1900 in a1894 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k1891 in k1962 in k1882 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1830 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_1698(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=f_1688(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[6]):(C_word)C_i_caddr(((C_word*)t0)[6]));
t8=((C_word*)((C_word*)t0)[4])[1];
f_1800(3,t8,((C_word*)t0)[3],t7);}
else{
t2=((C_word*)t0)[3];
f_1823(2,t2,((C_word*)t0)[2]);}}

/* k1821 in k1812 in walk in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1702(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_1702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1702,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(lf[73],C_retrieve(lf[74])))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=C_retrieve(lf[82]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[65]+1),t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[80],tmp=(C_word)a,a+=8,tmp);
t4=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_1715(2,t3,C_SCHEME_FALSE);}}

/* a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1723,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1733,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
t6=C_retrieve(lf[79]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t1,a[3]=lf[77],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1781 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1782,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1778 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1737 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1745,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1743 in k1737 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_1751(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[75]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k1770 in k1743 in k1737 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1751(t3,t2);}

/* k1749 in k1743 in k1737 in k1731 in a1722 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_1751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1698(((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1702(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1713 in k1710 in simplify in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k1665 */
static C_word C_fcall f_1698(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k1665 */
static C_word C_fcall f_1688(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(2));
return((C_word)C_i_car(t2));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k1665 */
static void f_1678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1678,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[69],t3));}

/* test in ##compiler#perform-high-level-optimizations in k1665 */
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments */
static void f_1464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1464,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1467,a[2]=t4,a[3]=t6,a[4]=lf[41],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1485,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t9=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[62],lf[63]);}

/* k1483 in ##compiler#scan-toplevel-assignments */
static void f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=lf[60],tmp=(C_word)a,a+=7,tmp);
t4=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1497,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t6,a[3]=lf[49],tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1512,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=lf[59],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t6)[1];
f_1512(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1537,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_1537(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_1537(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[51]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_1564(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[57]);
t14=t12;
f_1564(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[58])));}}}

/* k1562 in scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void C_fcall f_1564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=((C_word*)((C_word*)t0)[7])[1];
f_1512(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[52]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=((C_word*)((C_word*)t0)[7])[1];
f_1512(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[53]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[54]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[55]);
if(C_truep(t5)){
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[56]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_1467(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
t10=((C_word*)((C_word*)t0)[7])[1];
f_1512(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
t7=((C_word*)((C_word*)t0)[2])[1];
f_1500(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k1581 in k1562 in scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1592 in k1581 in k1562 in scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1512(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1565 in k1562 in scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1535 in scan in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void C_fcall f_1500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1506,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[47],tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1505 in scan-each in a1496 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1506,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[3])[1];
f_1512(t3,t1,t2,((C_word*)t0)[2]);}

/* k1486 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[44]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[45],lf[46],((C_word*)((C_word*)t0)[2])[1]);}

/* k1489 in k1486 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],C_retrieve(lf[42]));}

/* k1493 in k1489 in k1486 in k1483 in ##compiler#scan-toplevel-assignments */
static void f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments */
static C_word C_fcall f_1467(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}
/* end of file */
