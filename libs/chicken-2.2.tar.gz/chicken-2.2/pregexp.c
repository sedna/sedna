/* Generated from pregexp.scm by the Chicken compiler
   2005-09-10 23:31
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: pregexp.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file pregexp.c -explicit-use
   unit: regex
*/

#include "chicken.h"


static C_TLS C_word lf[261];


C_externexport void C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_678(C_word c,C_word t0,C_word t1) C_noret;
static void f_5546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5553(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5561(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5593(C_word c,C_word t0,C_word t1) C_noret;
static void f_5580(C_word c,C_word t0,C_word t1) C_noret;
static void f_5583(C_word c,C_word t0,C_word t1) C_noret;
static void f_5506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5515(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5534(C_word c,C_word t0,C_word t1) C_noret;
static void f_5541(C_word c,C_word t0,C_word t1) C_noret;
static void f_5414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5429(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5501(C_word c,C_word t0,C_word t1) C_noret;
static void f_5497(C_word c,C_word t0,C_word t1) C_noret;
static void f_5490(C_word c,C_word t0,C_word t1) C_noret;
static void f_5474(C_word c,C_word t0,C_word t1) C_noret;
static void f_5461(C_word c,C_word t0,C_word t1) C_noret;
static void f_5457(C_word c,C_word t0,C_word t1) C_noret;
static void f_5425(C_word c,C_word t0,C_word t1) C_noret;
static void f_5261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_5306(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5336(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5345(C_word t0,C_word t1) C_noret;
static void C_fcall f_5392(C_word t0,C_word t1) C_noret;
static void f_5377(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5351(C_word t0,C_word t1) C_noret;
static void f_5301(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5291(C_word t0,C_word t1) C_noret;
static void f_5287(C_word c,C_word t0,C_word t1) C_noret;
static void f_5010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_5010r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_5175(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5179(C_word c,C_word t0,C_word t1) C_noret;
static void f_5249(C_word c,C_word t0,C_word t1) C_noret;
static void f_5245(C_word c,C_word t0,C_word t1) C_noret;
static void f_5228(C_word c,C_word t0,C_word t1) C_noret;
static void f_5210(C_word c,C_word t0,C_word t1) C_noret;
static void f_5203(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5137(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5141(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5146(C_word t0,C_word t1,C_word t2);
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5113(C_word c,C_word t0,C_word t1) C_noret;
static void f_5101(C_word c,C_word t0,C_word t1) C_noret;
static void f_5060(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5025(C_word *a,C_word t0,C_word t1);
static void f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4991(C_word c,C_word t0,C_word t1) C_noret;
static void f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4851(C_word t0,C_word t1) C_noret;
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4863(C_word c,C_word t0,C_word t1) C_noret;
static void f_4924(C_word c,C_word t0,C_word t1) C_noret;
static void f_4905(C_word c,C_word t0,C_word t1) C_noret;
static void f_4939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4806r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4810(C_word c,C_word t0,C_word t1) C_noret;
static void f_4818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4800r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4774r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4778(C_word c,C_word t0,C_word t1) C_noret;
static void f_4786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4768r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4762(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4743(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4751(C_word c,C_word t0,C_word t1) C_noret;
static void f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4687(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4702(C_word c,C_word t0,C_word t1) C_noret;
static void f_4735(C_word c,C_word t0,C_word t1) C_noret;
static void f_4712(C_word c,C_word t0,C_word t1) C_noret;
static void f_4728(C_word c,C_word t0,C_word t1) C_noret;
static void f_4720(C_word c,C_word t0,C_word t1) C_noret;
static void f_4724(C_word c,C_word t0,C_word t1) C_noret;
static void f_4716(C_word c,C_word t0,C_word t1) C_noret;
static void f_4644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4651(C_word c,C_word t0,C_word t1) C_noret;
static void f_4663(C_word c,C_word t0,C_word t1) C_noret;
static void f_4666(C_word c,C_word t0,C_word t1) C_noret;
static void f_4673(C_word c,C_word t0,C_word t1) C_noret;
static void f_4677(C_word c,C_word t0,C_word t1) C_noret;
static void f_4681(C_word c,C_word t0,C_word t1) C_noret;
static void f_4549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4571(C_word c,C_word t0,C_word t1) C_noret;
static void f_4642(C_word c,C_word t0,C_word t1) C_noret;
static void f_4628(C_word c,C_word t0,C_word t1) C_noret;
static void f_4604(C_word c,C_word t0,C_word t1) C_noret;
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4524(C_word c,C_word t0,C_word t1) C_noret;
static void f_4532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4455r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4459(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4462(C_word t0,C_word t1) C_noret;
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_2943(C_word t0,C_word t1) C_noret;
static void C_fcall f_2972(C_word t0,C_word t1) C_noret;
static void C_fcall f_2998(C_word t0,C_word t1) C_noret;
static void C_fcall f_3526(C_word t0,C_word t1) C_noret;
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3588(C_word t0,C_word t1) C_noret;
static void f_3616(C_word c,C_word t0,C_word t1) C_noret;
static void f_3624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3603(C_word c,C_word t0,C_word t1) C_noret;
static void f_3561(C_word c,C_word t0,C_word t1) C_noret;
static void f_3569(C_word c,C_word t0,C_word t1) C_noret;
static void f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3496(C_word c,C_word t0,C_word t1) C_noret;
static void f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3466(C_word c,C_word t0,C_word t1) C_noret;
static void f_3443(C_word c,C_word t0,C_word t1) C_noret;
static void f_3429(C_word c,C_word t0,C_word t1) C_noret;
static void f_3413(C_word c,C_word t0,C_word t1) C_noret;
static void f_3398(C_word c,C_word t0,C_word t1) C_noret;
static void f_3382(C_word c,C_word t0,C_word t1) C_noret;
static void f_3371(C_word c,C_word t0,C_word t1) C_noret;
static void f_3356(C_word c,C_word t0,C_word t1) C_noret;
static void f_3346(C_word c,C_word t0,C_word t1) C_noret;
static void f_3331(C_word c,C_word t0,C_word t1) C_noret;
static void f_3302(C_word c,C_word t0,C_word t1) C_noret;
static void f_3311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3259(C_word c,C_word t0,C_word t1) C_noret;
static void f_3269(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3207(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3242(C_word c,C_word t0,C_word t1) C_noret;
static void f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3230(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3142(C_word c,C_word t0,C_word t1) C_noret;
static void f_3136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3104(C_word c,C_word t0,C_word t1) C_noret;
static void f_3023(C_word c,C_word t0,C_word t1) C_noret;
static void f_3010(C_word c,C_word t0,C_word t1) C_noret;
static void f_2978(C_word c,C_word t0,C_word t1) C_noret;
static void f_2949(C_word c,C_word t0,C_word t1) C_noret;
static void f_2931(C_word c,C_word t0,C_word t1) C_noret;
static void f_2913(C_word c,C_word t0,C_word t1) C_noret;
static void f_2852(C_word c,C_word t0,C_word t1) C_noret;
static void f_4480(C_word c,C_word t0,C_word t1) C_noret;
static void f_4439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4380(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4380r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4394(C_word c,C_word t0,C_word t1) C_noret;
static void f_4406(C_word c,C_word t0,C_word t1) C_noret;
static void f_4388(C_word c,C_word t0,C_word t1) C_noret;
static void f_4361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4374(C_word c,C_word t0,C_word t1) C_noret;
static void f_3957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4348(C_word c,C_word t0,C_word t1) C_noret;
static void f_4344(C_word c,C_word t0,C_word t1) C_noret;
static void f_4263(C_word c,C_word t0,C_word t1) C_noret;
static void f_4259(C_word c,C_word t0,C_word t1) C_noret;
static void f_4255(C_word c,C_word t0,C_word t1) C_noret;
static void f_4240(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3992(C_word t0,C_word t1) C_noret;
static void f_4018(C_word c,C_word t0,C_word t1) C_noret;
static void f_3977(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4091(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4127(C_word t0,C_word t1) C_noret;
static void f_4191(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4139(C_word t0,C_word t1) C_noret;
static void f_4161(C_word c,C_word t0,C_word t1) C_noret;
static void f_4165(C_word c,C_word t0,C_word t1) C_noret;
static void f_4157(C_word c,C_word t0,C_word t1) C_noret;
static void f_4115(C_word c,C_word t0,C_word t1) C_noret;
static void f_4111(C_word c,C_word t0,C_word t1) C_noret;
static void f_3868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3878(C_word c,C_word t0,C_word t1) C_noret;
static void f_3907(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3909(C_word t0,C_word t1,C_word t2);
static void f_3862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3708(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3838(C_word c,C_word t0,C_word t1) C_noret;
static void f_3834(C_word c,C_word t0,C_word t1) C_noret;
static void f_3733(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3736(C_word t0,C_word t1) C_noret;
static void f_3769(C_word c,C_word t0,C_word t1) C_noret;
static void f_3759(C_word c,C_word t0,C_word t1) C_noret;
static void f_3776(C_word c,C_word t0,C_word t1) C_noret;
static void f_3786(C_word c,C_word t0,C_word t1) C_noret;
static void f_3779(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_2817(C_word t0,C_word t1,C_word t2);
static void C_fcall f_2546(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2776(C_word c,C_word t0,C_word t1) C_noret;
static void f_2782(C_word c,C_word t0,C_word t1) C_noret;
static void f_2788(C_word c,C_word t0,C_word t1) C_noret;
static void f_2794(C_word c,C_word t0,C_word t1) C_noret;
static void f_2800(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2522(C_word c,C_word t0,C_word t1) C_noret;
static void f_2525(C_word c,C_word t0,C_word t1) C_noret;
static void f_2482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2209(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1410(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
static void f_1497(C_word c,C_word t0,C_word t1) C_noret;
static void f_1493(C_word c,C_word t0,C_word t1) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void f_2364(C_word c,C_word t0,C_word t1) C_noret;
static void f_2266(C_word c,C_word t0,C_word t1) C_noret;
static void f_2199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1792(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1824(C_word t0,C_word t1) C_noret;
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2061(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2117(C_word t0,C_word t1) C_noret;
static void f_2179(C_word c,C_word t0,C_word t1) C_noret;
static void f_2175(C_word c,C_word t0,C_word t1) C_noret;
static void f_2133(C_word c,C_word t0,C_word t1) C_noret;
static void f_2171(C_word c,C_word t0,C_word t1) C_noret;
static void f_2167(C_word c,C_word t0,C_word t1) C_noret;
static void f_2136(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2142(C_word t0,C_word t1) C_noret;
static void f_1989(C_word c,C_word t0,C_word t1) C_noret;
static void f_1992(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1833(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1842(C_word t0,C_word t1);
static C_word C_fcall f_1230(C_word *a,C_word t0,C_word t1,C_word t2);
static void C_fcall f_1134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1163(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1220(C_word c,C_word t0,C_word t1) C_noret;
static void f_1216(C_word c,C_word t0,C_word t1) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1) C_noret;
static void f_1185(C_word c,C_word t0,C_word t1) C_noret;
static void f_1181(C_word c,C_word t0,C_word t1) C_noret;
static void f_1177(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_711(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_744(C_word t0,C_word t1) C_noret;
static void C_fcall f_802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1039(C_word t0,C_word t1) C_noret;
static void C_fcall f_1055(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_995(C_word c,C_word t0,C_word t1) C_noret;
static void f_998(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1605(C_word c,C_word t0,C_word t1) C_noret;
static void f_1707(C_word c,C_word t0,C_word t1) C_noret;
static void f_1716(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1729(C_word t0,C_word t1) C_noret;
static void C_fcall f_1742(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1736(C_word c,C_word t0,C_word t1) C_noret;
static void f_978(C_word c,C_word t0,C_word t1) C_noret;
static void f_935(C_word c,C_word t0,C_word t1) C_noret;
static void f_929(C_word c,C_word t0,C_word t1) C_noret;
static void f_846(C_word c,C_word t0,C_word t1) C_noret;
static void f_843(C_word c,C_word t0,C_word t1) C_noret;
static void f_820(C_word c,C_word t0,C_word t1) C_noret;
static void f_758(C_word c,C_word t0,C_word t1) C_noret;
static void f_755(C_word c,C_word t0,C_word t1) C_noret;
static void f_705(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_705r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_681(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_687(C_word t0,C_word t1);

static void C_fcall trf_5561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5561(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5561(t0,t1,t2);}

static void C_fcall trf_5515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5515(t0,t1,t2);}

static void C_fcall trf_5431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5431(t0,t1,t2);}

static void C_fcall trf_5273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5273(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5273(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5306(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5306(t0,t1,t2,t3);}

static void C_fcall trf_5345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5345(t0,t1);}

static void C_fcall trf_5392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5392(t0,t1);}

static void C_fcall trf_5351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5351(t0,t1);}

static void C_fcall trf_5291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5291(t0,t1);}

static void C_fcall trf_5175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5175(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5175(t0,t1,t2,t3);}

static void C_fcall trf_5137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5137(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5137(t0,t1,t2);}

static void C_fcall trf_5040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5040(t0,t1,t2);}

static void C_fcall trf_5046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5046(t0,t1,t2,t3);}

static void C_fcall trf_4851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4851(t0,t1);}

static void C_fcall trf_4859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4859(t0,t1,t2,t3);}

static void C_fcall trf_4762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4762(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4762(t0,t1,t2,t3,t4);}

static void C_fcall trf_4743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4743(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4743(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4698(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4698(t0,t1,t2,t3);}

static void C_fcall trf_4558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4558(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4558(t0,t1,t2,t3,t4);}

static void C_fcall trf_4462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4462(t0,t1);}

static void C_fcall trf_4470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4470(t0,t1,t2);}

static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2855(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2943(t0,t1);}

static void C_fcall trf_2972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2972(t0,t1);}

static void C_fcall trf_2998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2998(t0,t1);}

static void C_fcall trf_3526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3526(t0,t1);}

static void C_fcall trf_3531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3531(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3531(t0,t1,t2,t3,t4);}

static void C_fcall trf_3559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3559(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3559(t0,t1,t2,t3,t4);}

static void C_fcall trf_3588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3588(t0,t1);}

static void C_fcall trf_2433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2433(t0,t1,t2,t3);}

static void C_fcall trf_3271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3271(t0,t1,t2);}

static void C_fcall trf_3207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3207(t0,t1,t2);}

static void C_fcall trf_3165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3165(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3165(t0,t1,t2,t3,t4);}

static void C_fcall trf_3085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3085(t0,t1,t2);}

static void C_fcall trf_4203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4203(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4203(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3963(t0,t1,t2,t3);}

static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3992(t0,t1);}

static void C_fcall trf_4091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4091(t0,t1,t2);}

static void C_fcall trf_4097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4097(t0,t1,t2,t3);}

static void C_fcall trf_4127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4127(t0,t1);}

static void C_fcall trf_4139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4139(t0,t1);}

static void C_fcall trf_3708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3708(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3708(t0,t1,t2,t3,t4);}

static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3714(t0,t1,t2,t3);}

static void C_fcall trf_3736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3736(t0,t1);}

static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2811(t0,t1,t2);}

static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2546(t0,t1,t2);}

static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2500(t0,t1,t2,t3);}

static void C_fcall trf_2209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2209(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2209(t0,t1,t2,t3);}

static void C_fcall trf_2215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2215(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2215(t0,t1,t2,t3);}

static void C_fcall trf_1410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1410(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1410(t0,t1,t2,t3);}

static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

static void C_fcall trf_1779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1779(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1779(t0,t1,t2,t3);}

static void C_fcall trf_1792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1792(t0,t1,t2);}

static void C_fcall trf_1824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1824(t0,t1);}

static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2057(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2117(t0,t1);}

static void C_fcall trf_2142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2142(t0,t1);}

static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1833(t0,t1);}

static void C_fcall trf_1134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1134(t0,t1,t2,t3);}

static void C_fcall trf_1163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1163(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1163(t0,t1,t2,t3);}

static void C_fcall trf_711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_711(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_711(t0,t1,t2,t3);}

static void C_fcall trf_734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_734(t0,t1,t2,t3);}

static void C_fcall trf_744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_744(t0,t1);}

static void C_fcall trf_802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_802(t0,t1,t2,t3);}

static void C_fcall trf_1039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1039(t0,t1);}

static void C_fcall trf_1055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1055(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1055(t0,t1,t2,t3);}

static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1630(t0,t1,t2,t3,t4);}

static void C_fcall trf_1729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1729(t0,t1);}

static void C_fcall trf_1742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1742(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1742(t0,t1,t2,t3);}

static void C_fcall trf_681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_681(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1469)){
C_save(t1);
C_rereclaim2(1469*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,261);
lf[0]=C_h_intern(&lf[0],26,"*pregexp-space-sensitive\077*");
lf[2]=C_static_lambda_info(C_heaptop,9,"(loop r5)");
lf[3]=C_static_lambda_info(C_heaptop,21,"(pregexp-reverse! s2)");
lf[4]=C_h_intern(&lf[4],13,"pregexp-error");
lf[5]=C_h_intern(&lf[5],9,"\003syserror");
lf[6]=C_static_string(C_heaptop,15,"pregexp-error: ");
lf[7]=C_static_lambda_info(C_heaptop,23,"(pregexp-error . args9)");
lf[9]=C_h_intern(&lf[9],4,":seq");
lf[10]=C_h_intern(&lf[10],3,":or");
lf[11]=C_h_intern(&lf[11],4,":bos");
lf[12]=C_h_intern(&lf[12],4,":eos");
lf[13]=C_h_intern(&lf[13],4,":any");
lf[15]=C_h_intern(&lf[15],9,":neg-char");
lf[17]=C_static_lambda_info(C_heaptop,20,"(loop ctyp112 re113)");
lf[18]=C_h_intern(&lf[18],23,"pregexp-read-subpattern");
tmp=C_intern(C_heaptop,10,":lookahead");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[19]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,":neg-lookahead");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[20]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,13,":no-backtrack");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[21]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,11,":lookbehind");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[22]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,15,":neg-lookbehind");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[23]=C_h_pair(C_restore,tmp);
lf[24]=C_h_intern(&lf[24],25,"pregexp-read-cluster-type");
lf[25]=C_h_intern(&lf[25],15,":case-sensitive");
lf[26]=C_h_intern(&lf[26],17,":case-insensitive");
lf[27]=C_static_lambda_info(C_heaptop,21,"(loop i93 r94 inv\07795)");
tmp=C_intern(C_heaptop,4,":sub");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[28]=C_h_pair(C_restore,tmp);
lf[29]=C_h_intern(&lf[29],8,":backref");
lf[31]=C_h_intern(&lf[31],18,"pregexp-read-piece");
lf[32]=C_static_string(C_heaptop,9,"backslash");
lf[34]=C_h_intern(&lf[34],6,":empty");
lf[35]=C_static_lambda_info(C_heaptop,24,"(loop i49 in-comment\07750)");
lf[36]=C_static_lambda_info(C_heaptop,19,"(loop pieces24 i25)");
lf[37]=C_static_lambda_info(C_heaptop,21,"(loop branches14 i15)");
lf[38]=C_static_lambda_info(C_heaptop,34,"(pregexp-read-pattern s10 i11 n12)");
lf[39]=C_h_intern(&lf[39],12,"list->string");
lf[40]=C_static_lambda_info(C_heaptop,14,"(loop i58 r59)");
lf[41]=C_static_lambda_info(C_heaptop,41,"(pregexp-read-escaped-number s53 i54 n55)");
lf[42]=C_h_intern(&lf[42],6,":wbdry");
lf[43]=C_h_intern(&lf[43],10,":not-wbdry");
lf[44]=C_h_intern(&lf[44],6,":digit");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,6,":digit");
C_save(tmp);
lf[45]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[46]=C_h_intern(&lf[46],6,":space");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,6,":space");
C_save(tmp);
lf[47]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[48]=C_h_intern(&lf[48],5,":word");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,5,":word");
C_save(tmp);
lf[49]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[50]=C_static_lambda_info(C_heaptop,35,"(pregexp-read-escaped-char i63 n64)");
lf[51]=C_h_intern(&lf[51],8,":between");
lf[52]=C_h_intern(&lf[52],8,"minimal\077");
lf[53]=C_h_intern(&lf[53],8,"at-least");
lf[54]=C_h_intern(&lf[54],7,"at-most");
lf[55]=C_h_intern(&lf[55],6,"next-i");
lf[56]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[57]=C_h_intern(&lf[57],30,"pregexp-wrap-quantifier-if-any");
lf[58]=C_static_string(C_heaptop,39,"left bracket must be followed by number");
lf[59]=C_h_intern(&lf[59],17,"pregexp-read-nums");
lf[60]=C_static_lambda_info(C_heaptop,32,"(loop p156 q157 k158 reading159)");
lf[61]=C_static_lambda_info(C_heaptop,11,"(loop i121)");
lf[62]=C_static_lambda_info(C_heaptop,48,"(pregexp-wrap-quantifier-if-any vv116 s117 n118)");
lf[64]=C_h_intern(&lf[64],14,":none-of-chars");
lf[65]=C_static_lambda_info(C_heaptop,32,"(pregexp-invert-char-list vv165)");
lf[66]=C_h_intern(&lf[66],22,"pregexp-read-char-list");
lf[67]=C_static_string(C_heaptop,30,"character class ended too soon");
lf[68]=C_h_intern(&lf[68],13,":one-of-chars");
lf[69]=C_static_string(C_heaptop,9,"backslash");
lf[70]=C_h_intern(&lf[70],11,":char-range");
lf[71]=C_h_intern(&lf[71],29,"pregexp-read-posix-char-class");
lf[72]=C_h_intern(&lf[72],14,"string->symbol");
lf[73]=C_static_lambda_info(C_heaptop,14,"(loop i73 r74)");
lf[74]=C_static_lambda_info(C_heaptop,16,"(loop r171 i172)");
lf[75]=C_static_lambda_info(C_heaptop,39,"(pregexp-read-char-list s167 i168 n169)");
lf[77]=C_static_lambda_info(C_heaptop,25,"(pregexp-char-word\077 c191)");
lf[80]=C_static_lambda_info(C_heaptop,42,"(pregexp-at-word-boundary\077 s196 i197 n198)");
lf[81]=C_h_intern(&lf[81],6,":alnum");
lf[82]=C_h_intern(&lf[82],6,":alpha");
lf[83]=C_h_intern(&lf[83],6,":ascii");
lf[84]=C_h_intern(&lf[84],6,":blank");
lf[85]=C_h_intern(&lf[85],6,":cntrl");
lf[86]=C_h_intern(&lf[86],6,":graph");
lf[87]=C_h_intern(&lf[87],6,":lower");
lf[88]=C_h_intern(&lf[88],6,":print");
lf[89]=C_h_intern(&lf[89],6,":punct");
lf[90]=C_h_intern(&lf[90],6,":upper");
lf[91]=C_h_intern(&lf[91],7,":xdigit");
lf[92]=C_h_intern(&lf[92],9,"char-ci=\077");
lf[93]=C_h_intern(&lf[93],31,"pregexp-check-if-in-char-class\077");
lf[94]=C_static_lambda_info(C_heaptop,52,"(pregexp-check-if-in-char-class\077 c209 char-class210)");
lf[96]=C_static_lambda_info(C_heaptop,11,"(loop k237)");
lf[97]=C_static_lambda_info(C_heaptop,28,"(pregexp-list-ref s233 i234)");
lf[99]=C_h_intern(&lf[99],13,"string-append");
lf[100]=C_h_intern(&lf[100],9,"substring");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_static_lambda_info(C_heaptop,16,"(loop i333 r334)");
lf[103]=C_static_string(C_heaptop,0,"");
lf[104]=C_static_lambda_info(C_heaptop,52,"(pregexp-replace-aux str328 ins329 n330 backrefs331)");
lf[105]=C_h_intern(&lf[105],17,"extract-bit-field");
lf[106]=C_static_lambda_info(C_heaptop,44,"(extract-bit-field size342 position343 n344)");
lf[107]=C_h_intern(&lf[107],23,"utf8-start-byte->length");
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[108]=C_h_vector(256,C_pick(255),C_pick(254),C_pick(253),C_pick(252),C_pick(251),C_pick(250),C_pick(249),C_pick(248),C_pick(247),C_pick(246),C_pick(245),C_pick(244),C_pick(243),C_pick(242),C_pick(241),C_pick(240),C_pick(239),C_pick(238),C_pick(237),C_pick(236),C_pick(235),C_pick(234),C_pick(233),C_pick(232),C_pick(231),C_pick(230),C_pick(229),C_pick(228),C_pick(227),C_pick(226),C_pick(225),C_pick(224),C_pick(223),C_pick(222),C_pick(221),C_pick(220),C_pick(219),C_pick(218),C_pick(217),C_pick(216),C_pick(215),C_pick(214),C_pick(213),C_pick(212),C_pick(211),C_pick(210),C_pick(209),C_pick(208),C_pick(207),C_pick(206),C_pick(205),C_pick(204),C_pick(203),C_pick(202),C_pick(201),C_pick(200),C_pick(199),C_pick(198),C_pick(197),C_pick(196),C_pick(195),C_pick(194),C_pick(193),C_pick(192),C_pick(191),C_pick(190),C_pick(189),C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(256);
lf[109]=C_static_lambda_info(C_heaptop,30,"(utf8-start-byte->length i346)");
lf[110]=C_h_intern(&lf[110],18,"string-ref-at-byte");
lf[111]=C_h_intern(&lf[111],6,"regexp");
lf[112]=C_static_string(C_heaptop,27,"utf8 trailing char overflow");
lf[113]=C_static_lambda_info(C_heaptop,13,"(loop res355)");
lf[114]=C_static_lambda_info(C_heaptop,33,"(string-ref-at-byte s347 byte348)");
tmp=C_make_character(41);
C_save(tmp);
tmp=C_make_character(125);
C_save(tmp);
tmp=C_make_character(50);
C_save(tmp);
tmp=C_make_character(123);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(127);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(1);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(58);
C_save(tmp);
tmp=C_make_character(63);
C_save(tmp);
tmp=C_make_character(40);
C_save(tmp);
lf[116]=C_h_list(34,C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(34);
lf[117]=C_h_intern(&lf[117],26,"utf8-pattern->byte-pattern");
lf[118]=C_h_intern(&lf[118],12,"string->list");
lf[119]=C_static_string(C_heaptop,3,"(\077:");
lf[120]=C_static_string(C_heaptop,1,")");
lf[121]=C_h_intern(&lf[121],18,"string-intersperse");
lf[122]=C_static_string(C_heaptop,1,"|");
lf[123]=C_static_string(C_heaptop,34,"full unicode classes not supported");
lf[124]=C_static_string(C_heaptop,1,"[");
lf[125]=C_static_string(C_heaptop,1,"-");
lf[126]=C_static_string(C_heaptop,1,"]");
lf[127]=C_h_intern(&lf[127],12,"char->string");
lf[128]=C_static_lambda_info(C_heaptop,19,"(loop ls370 acc371)");
lf[129]=C_static_lambda_info(C_heaptop,20,"(class->group ls368)");
lf[130]=C_h_intern(&lf[130],7,"reverse");
lf[131]=C_h_intern(&lf[131],6,"append");
lf[132]=C_static_lambda_info(C_heaptop,18,"(scan i363 res364)");
lf[133]=C_static_string(C_heaptop,26,"incomplete character class");
lf[134]=C_static_lambda_info(C_heaptop,36,"(class i378 acc379 ascii\077380 res381)");
lf[135]=C_static_lambda_info(C_heaptop,33,"(utf8-pattern->byte-pattern s358)");
lf[136]=C_h_intern(&lf[136],8,"%pregexp");
lf[137]=C_h_intern(&lf[137],4,":sub");
lf[138]=C_static_lambda_info(C_heaptop,15,"(%pregexp s389)");
lf[139]=C_h_intern(&lf[139],7,"pregexp");
lf[140]=C_static_string(C_heaptop,4,"(\077x:");
lf[141]=C_static_string(C_heaptop,1,")");
lf[142]=C_static_string(C_heaptop,4,"(\077i:");
lf[143]=C_static_string(C_heaptop,1,")");
lf[144]=C_static_lambda_info(C_heaptop,21,"(pregexp s391 . o392)");
lf[145]=C_h_intern(&lf[145],7,"regexp\077");
lf[146]=C_static_lambda_info(C_heaptop,14,"(regexp\077 x397)");
lf[148]=C_static_lambda_info(C_heaptop,7,"(a2851)");
lf[149]=C_h_intern(&lf[149],6,"char=\077");
lf[150]=C_h_intern(&lf[150],7,"char<=\077");
lf[151]=C_h_intern(&lf[151],10,"char-ci<=\077");
lf[152]=C_h_intern(&lf[152],27,"pregexp-match-positions-aux");
lf[153]=C_static_lambda_info(C_heaptop,7,"(a3103)");
lf[154]=C_static_lambda_info(C_heaptop,28,"(loup-one-of-chars chars256)");
lf[155]=C_static_lambda_info(C_heaptop,26,"(a3135 i1258 backrefs1259)");
lf[156]=C_static_lambda_info(C_heaptop,7,"(a3141)");
lf[157]=C_static_lambda_info(C_heaptop,26,"(a3183 i1264 backrefs1265)");
lf[158]=C_static_lambda_info(C_heaptop,34,"(loup-seq res261 i262 backrefs263)");
lf[159]=C_static_lambda_info(C_heaptop,26,"(a3225 i1269 backrefs1270)");
lf[160]=C_static_lambda_info(C_heaptop,7,"(a3241)");
lf[161]=C_static_lambda_info(C_heaptop,16,"(loup-or res268)");
lf[162]=C_static_lambda_info(C_heaptop,12,"(a3270 i275)");
lf[163]=C_static_lambda_info(C_heaptop,16,"(loop j188 k189)");
lf[164]=C_static_lambda_info(C_heaptop,26,"(a3310 i1278 backrefs1279)");
lf[165]=C_h_intern(&lf[165],10,":lookahead");
lf[166]=C_static_lambda_info(C_heaptop,7,"(a3345)");
lf[167]=C_h_intern(&lf[167],4,"list");
lf[168]=C_h_intern(&lf[168],14,":neg-lookahead");
lf[169]=C_static_lambda_info(C_heaptop,7,"(a3370)");
lf[170]=C_h_intern(&lf[170],11,":lookbehind");
tmp=C_intern(C_heaptop,8,":between");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_intern(C_heaptop,4,":any");
C_save(tmp);
lf[171]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[172]=C_static_lambda_info(C_heaptop,7,"(a3397)");
lf[173]=C_h_intern(&lf[173],15,":neg-lookbehind");
tmp=C_intern(C_heaptop,8,":between");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_intern(C_heaptop,4,":any");
C_save(tmp);
lf[174]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[175]=C_static_lambda_info(C_heaptop,7,"(a3428)");
lf[176]=C_h_intern(&lf[176],13,":no-backtrack");
lf[177]=C_static_lambda_info(C_heaptop,7,"(a3465)");
lf[178]=C_static_lambda_info(C_heaptop,26,"(a3488 i1295 backrefs1296)");
lf[179]=C_static_lambda_info(C_heaptop,7,"(a3495)");
lf[180]=C_static_lambda_info(C_heaptop,26,"(a3542 i1309 backrefs1310)");
lf[181]=C_h_intern(&lf[181],12,"no-match-yet");
lf[182]=C_static_lambda_info(C_heaptop,4,"(fk)");
lf[183]=C_static_lambda_info(C_heaptop,26,"(a3598 i1317 backrefs1318)");
lf[184]=C_static_lambda_info(C_heaptop,26,"(a3623 i1323 backrefs1324)");
lf[185]=C_static_lambda_info(C_heaptop,31,"(loup-q k313 i314 cbackrefs315)");
lf[186]=C_static_lambda_info(C_heaptop,31,"(loup-p k306 i307 cbackrefs308)");
lf[187]=C_static_lambda_info(C_heaptop,40,"(sub re246 i247 backrefs248 sk249 fk250)");
lf[188]=C_static_lambda_info(C_heaptop,11,"(loop i407)");
lf[189]=C_static_lambda_info(C_heaptop,53,"(pregexp-match-positions pat398 str399 . opt-args400)");
lf[191]=C_static_lambda_info(C_heaptop,16,"(a4531 ix-pr414)");
lf[192]=C_h_intern(&lf[192],7,"\003sysmap");
lf[193]=C_static_lambda_info(C_heaptop,43,"(pregexp-match pat410 str411 . opt-args412)");
lf[195]=C_static_lambda_info(C_heaptop,51,"(loop i419 r420 picked-up-one-undelimited-char\077421)");
lf[196]=C_static_lambda_info(C_heaptop,29,"(pregexp-split pat415 str416)");
lf[198]=C_h_intern(&lf[198],4,"cdar");
lf[199]=C_h_intern(&lf[199],4,"caar");
lf[200]=C_static_lambda_info(C_heaptop,38,"(pregexp-replace pat429 str430 ins431)");
lf[202]=C_static_lambda_info(C_heaptop,16,"(loop i444 r445)");
lf[203]=C_static_string(C_heaptop,0,"");
lf[204]=C_static_lambda_info(C_heaptop,39,"(pregexp-replace* pat437 str438 ins439)");
lf[205]=C_static_string(C_heaptop,1,"^");
lf[206]=C_static_string(C_heaptop,1,"$");
lf[207]=C_static_lambda_info(C_heaptop,34,"(prep op451 rx452 str453 start454)");
lf[208]=C_static_lambda_info(C_heaptop,35,"(prep2 op455 rx456 str457 start458)");
lf[209]=C_h_intern(&lf[209],12,"string-match");
lf[210]=C_static_lambda_info(C_heaptop,38,"(string-match rx459 str460 . start461)");
lf[211]=C_h_intern(&lf[211],22,"string-match-positions");
lf[212]=C_static_lambda_info(C_heaptop,12,"(a4785 p466)");
lf[213]=C_static_lambda_info(C_heaptop,48,"(string-match-positions rx462 str463 . start464)");
lf[214]=C_h_intern(&lf[214],13,"string-search");
lf[215]=C_static_lambda_info(C_heaptop,39,"(string-search rx467 str468 . start469)");
lf[216]=C_h_intern(&lf[216],23,"string-search-positions");
lf[217]=C_static_lambda_info(C_heaptop,12,"(a4817 p474)");
lf[218]=C_static_lambda_info(C_heaptop,49,"(string-search-positions rx470 str471 . start472)");
lf[219]=C_h_intern(&lf[219],19,"string-split-fields");
lf[220]=C_h_intern(&lf[220],6,"\000infix");
lf[221]=C_h_intern(&lf[221],7,"\000suffix");
lf[222]=C_static_lambda_info(C_heaptop,31,"(f_4934 start504 from505 to506)");
lf[223]=C_static_lambda_info(C_heaptop,31,"(f_4939 start507 from508 to509)");
lf[224]=C_static_lambda_info(C_heaptop,21,"(loop ms511 start512)");
lf[225]=C_static_string(C_heaptop,31,"record does not end with suffix");
lf[226]=C_static_lambda_info(C_heaptop,23,"(f_4950 ms493 start494)");
lf[227]=C_static_lambda_info(C_heaptop,23,"(f_4970 ms495 start496)");
lf[228]=C_static_lambda_info(C_heaptop,23,"(f_4992 ms497 start498)");
lf[229]=C_static_lambda_info(C_heaptop,58,"(string-split-fields regexp483 str484 . mode-and-start485)");
lf[230]=C_h_intern(&lf[230],11,"make-string");
lf[231]=C_h_intern(&lf[231],17,"string-substitute");
lf[232]=C_static_lambda_info(C_heaptop,6,"(push)");
lf[233]=C_static_lambda_info(C_heaptop,24,"(loop start539 index540)");
lf[234]=C_static_lambda_info(C_heaptop,23,"(substitute matches537)");
lf[235]=C_static_lambda_info(C_heaptop,15,"(loop index552)");
lf[236]=C_static_lambda_info(C_heaptop,21,"(concatenate strs548)");
lf[237]=C_static_lambda_info(C_heaptop,24,"(loop index558 count559)");
lf[238]=C_static_lambda_info(C_heaptop,57,"(string-substitute regex523 subst524 string525 . flag526)");
lf[239]=C_h_intern(&lf[239],18,"string-substitute*");
lf[240]=C_h_intern(&lf[240],21,"\003sysfragments->string");
lf[241]=C_h_intern(&lf[241],13,"\003syssubstring");
lf[242]=C_static_lambda_info(C_heaptop,21,"(loop smap584 pos585)");
lf[243]=C_static_lambda_info(C_heaptop,37,"(collect i579 from580 total581 fs582)");
lf[244]=C_static_lambda_info(C_heaptop,35,"(string-substitute* str575 smap576)");
lf[245]=C_h_intern(&lf[245],12,"glob->regexp");
lf[246]=C_h_intern(&lf[246],8,"\003syscons");
lf[247]=C_static_lambda_info(C_heaptop,12,"(loop cs601)");
lf[248]=C_static_lambda_info(C_heaptop,19,"(glob->regexp s599)");
lf[249]=C_h_intern(&lf[249],4,"grep");
lf[250]=C_static_lambda_info(C_heaptop,13,"(loop lst612)");
lf[251]=C_static_lambda_info(C_heaptop,19,"(grep rx609 lst610)");
lf[252]=C_h_intern(&lf[252],18,"open-output-string");
lf[253]=C_h_intern(&lf[253],17,"get-output-string");
lf[254]=C_h_intern(&lf[254],13,"regexp-escape");
lf[255]=C_h_intern(&lf[255],16,"\003syswrite-char-0");
lf[256]=C_static_lambda_info(C_heaptop,11,"(loop i623)");
lf[257]=C_static_lambda_info(C_heaptop,22,"(regexp-escape str619)");
lf[258]=C_h_intern(&lf[258],17,"register-feature!");
lf[259]=C_h_intern(&lf[259],5,"regex");
lf[260]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,261);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_678,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 51   register-feature! */
t3=*((C_word*)lf[258]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[259],lf[139]);}

/* k676 */
static void f_678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[129],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_678,2,t0,t1);}
t2=C_set_block_item(lf[0],0,C_SCHEME_TRUE);
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_681,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_705,a[2]=lf[7],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_711,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[33],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[30],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1230,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[14],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=lf[62],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[63],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2199,a[2]=lf[65],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[76],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=lf[77],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[78],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2500,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[79],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[95],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2811,a[2]=lf[97],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[98],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=lf[106],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3862,a[2]=lf[109],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[115],lf[116]);
t20=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3957,a[2]=lf[135],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4361,a[2]=lf[138],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=lf[144],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[111]+1,*((C_word*)lf[139]+1));
t24=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=lf[146],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate(&lf[147],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4455,a[2]=lf[189],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[190],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4520,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[194],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4549,a[2]=lf[196],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate(&lf[197],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4644,a[2]=lf[200],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[201],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=lf[204],tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[99]+1);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=t30,a[3]=lf[207],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4762,a[2]=lf[208],tmp=(C_word)a,a+=3,tmp);
t33=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4768,a[2]=t31,a[3]=lf[210],tmp=(C_word)a,a+=4,tmp));
t34=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4774,a[2]=t31,a[3]=lf[213],tmp=(C_word)a,a+=4,tmp));
t35=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4800,a[2]=t32,a[3]=lf[215],tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4806,a[2]=t32,a[3]=lf[218],tmp=(C_word)a,a+=4,tmp));
t37=*((C_word*)lf[130]+1);
t38=*((C_word*)lf[100]+1);
t39=*((C_word*)lf[216]+1);
t40=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4832,a[2]=t37,a[3]=t39,a[4]=t38,a[5]=lf[229],tmp=(C_word)a,a+=6,tmp));
t41=*((C_word*)lf[100]+1);
t42=*((C_word*)lf[130]+1);
t43=*((C_word*)lf[230]+1);
t44=*((C_word*)lf[216]+1);
t45=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5010,a[2]=t44,a[3]=t42,a[4]=t43,a[5]=t41,a[6]=lf[238],tmp=(C_word)a,a+=7,tmp));
t46=*((C_word*)lf[216]+1);
t47=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t46,a[3]=lf[244],tmp=(C_word)a,a+=4,tmp));
t48=*((C_word*)lf[39]+1);
t49=*((C_word*)lf[118]+1);
t50=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5414,a[2]=t49,a[3]=t48,a[4]=lf[248],tmp=(C_word)a,a+=5,tmp));
t51=*((C_word*)lf[214]+1);
t52=C_mutate((C_word*)lf[249]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=t51,a[3]=lf[251],tmp=(C_word)a,a+=4,tmp));
t53=*((C_word*)lf[252]+1);
t54=*((C_word*)lf[253]+1);
t55=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5546,a[2]=t53,a[3]=t54,a[4]=lf[257],tmp=(C_word)a,a+=5,tmp));
t56=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t56+1)))(2,t56,C_SCHEME_UNDEFINED);}

/* regexp-escape in k676 */
static void f_5546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5546,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[254]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5553,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1038 open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5551 in regexp-escape in k676 */
static void f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5561,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=lf[256],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5561(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k5551 in regexp-escape in k676 */
static void C_fcall f_5561(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5561,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* pregexp.scm: 1041 get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 1043 ##sys#write-char-0 */
t5=*((C_word*)lf[255]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5593,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1047 ##sys#write-char-0 */
t5=*((C_word*)lf[255]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k5591 in loop in k5551 in regexp-escape in k676 */
static void f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 1048 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5561(t3,((C_word*)t0)[2],t2);}

/* k5578 in loop in k5551 in regexp-escape in k676 */
static void f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1044 ##sys#write-char-0 */
t3=*((C_word*)lf[255]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k5581 in k5578 in loop in k5551 in regexp-escape in k676 */
static void f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 1045 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5561(t3,((C_word*)t0)[2],t2);}

/* grep in k676 */
static void f_5506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5506,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[249]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5515,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=lf[250],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5515(t8,t1,t3);}

/* loop in grep in k676 */
static void C_fcall f_5515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5515,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5534,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 1026 string-search */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k5532 in loop in grep in k676 */
static void f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1027 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5515(t3,t2,((C_word*)t0)[2]);}
else{
/* pregexp.scm: 1028 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5515(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5539 in k5532 in loop in grep in k676 */
static void f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k676 */
static void f_5414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5414,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[245]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5425,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1007 string->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k5427 in glob->regexp in k676 */
static void f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5431,a[2]=t3,a[3]=lf[247],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5431(t5,((C_word*)t0)[2],t1);}

/* loop in k5427 in glob->regexp in k676 */
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5431,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5461,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1012 loop */
t14=t6;
t15=t4;
t1=t14;
t2=t15;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5474,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1013 loop */
t14=t5;
t15=t4;
t1=t14;
t2=t15;
goto loop;
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5490,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1014 loop */
t14=t7;
t15=t4;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5501,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1015 loop */
t14=t8;
t15=t4;
t1=t14;
t2=t15;
goto loop;}}}}

/* k5499 in loop in k5427 in glob->regexp in k676 */
static void f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5495 in loop in k5427 in glob->regexp in k676 */
static void f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(92),t1);}

/* k5488 in loop in k5427 in glob->regexp in k676 */
static void f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5472 in loop in k5427 in glob->regexp in k676 */
static void f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k5459 in loop in k5427 in glob->regexp in k676 */
static void f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(42),t1);}

/* k5455 in loop in k5427 in glob->regexp in k676 */
static void f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(46),t1);}

/* k5423 in glob->regexp in k676 */
static void f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1006 list->string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-substitute* in k676 */
static void f_5261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5261,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[239]);
t5=(C_word)C_i_check_list_2(t3,lf[239]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5273,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=t2,a[6]=t6,a[7]=lf[243],tmp=(C_word)a,a+=8,tmp));
/* pregexp.scm: 996  collect */
t10=((C_word*)t8)[1];
f_5273(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-substitute* in k676 */
static void C_fcall f_5273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5273,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5287,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5291,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 973  ##sys#substring */
t10=*((C_word*)lf[241]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[5],t3,t2);}
else{
t9=t8;
f_5291(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t2,a[10]=lf[242],tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_5306(t10,t1,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* loop in collect in string-substitute* in k676 */
static void C_fcall f_5306(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5306,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_difference(t3,((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[8],t4);
/* pregexp.scm: 977  collect */
t6=((C_word*)((C_word*)t0)[7])[1];
f_5273(t6,t1,t3,((C_word*)t0)[6],t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t4);
t6=(C_word)C_i_cdr(t4);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5336,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[8],a[12]=t6,tmp=(C_word)a,a+=13,tmp);
/* pregexp.scm: 981  string-search-positions */
t8=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t5,((C_word*)t0)[4],((C_word*)t0)[9]);}}

/* k5334 in loop in collect in string-substitute* in k676 */
static void f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_slot(t1,C_fix(0)):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_5345(t5,(C_word)C_eqp(((C_word*)t0)[7],t4));}
else{
t4=t3;
f_5345(t4,C_SCHEME_FALSE);}}

/* k5343 in k5334 in loop in collect in string-substitute* in k676 */
static void C_fcall f_5345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5345,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5351,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5377,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 987  ##sys#substring */
t6=*((C_word*)lf[241]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t5=t4;
f_5351(t5,C_SCHEME_UNDEFINED);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5392,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_slot(((C_word*)t0)[13],C_fix(0));
t5=t3;
f_5392(t5,(C_word)C_i_fixnum_min(((C_word*)t0)[2],t4));}
else{
t4=t3;
f_5392(t4,((C_word*)t0)[2]);}}}

/* k5390 in k5343 in k5334 in loop in collect in string-substitute* in k676 */
static void C_fcall f_5392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 992  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5306(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5375 in k5343 in k5334 in loop in collect in string-substitute* in k676 */
static void f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5351(t4,t3);}

/* k5349 in k5343 in k5334 in loop in collect in string-substitute* in k676 */
static void C_fcall f_5351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5351,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* pregexp.scm: 988  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5273(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k5299 in collect in string-substitute* in k676 */
static void f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5291(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k5289 in collect in string-substitute* in k676 */
static void C_fcall f_5291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 971  reverse */
t2=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5285 in collect in string-substitute* in k676 */
static void f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 969  ##sys#fragments->string */
t2=*((C_word*)lf[240]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-substitute in k676 */
static void f_5010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr5rv,(void*)f_5010r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_5010r(t0,t1,t2,t3,t4,t5);}}

static void f_5010r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(39);
t6=(C_word)C_i_check_string_2(t3,lf[231]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=t14,a[3]=t12,a[4]=lf[232],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5040,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t15,a[7]=t10,a[8]=lf[234],tmp=(C_word)a,a+=9,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5137,a[2]=t14,a[3]=((C_word*)t0)[4],a[4]=lf[236],tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5175,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=((C_word*)t0)[3],a[6]=t17,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t16,a[10]=t19,a[11]=t15,a[12]=t8,a[13]=lf[237],tmp=(C_word)a,a+=14,tmp));
t21=((C_word*)t19)[1];
f_5175(t21,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k676 */
static void C_fcall f_5175(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5175,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* pregexp.scm: 946  string-search-positions */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k5177 in loop in string-substitute in k676 */
static void f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5179,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_fixnump(((C_word*)t0)[13]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[12],((C_word*)t0)[13]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5210,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_car(t2);
/* pregexp.scm: 951  substring */
t9=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)t0)[6],((C_word*)t0)[5],t8);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5228,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 955  substring */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* pregexp.scm: 958  substring */
t4=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k5247 in k5177 in loop in string-substitute in k676 */
static void f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5249,2,t0,t1);}
t2=f_5025(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 959  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k5243 in k5247 in k5177 in loop in string-substitute in k676 */
static void f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 959  concatenate */
t2=((C_word*)t0)[3];
f_5137(t2,((C_word*)t0)[2],t1);}

/* k5226 in k5177 in loop in string-substitute in k676 */
static void f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=f_5025(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* pregexp.scm: 956  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5175(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5208 in k5177 in loop in string-substitute in k676 */
static void f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=f_5025(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 952  substitute */
t4=((C_word*)t0)[3];
f_5040(t4,t3,((C_word*)t0)[2]);}

/* k5201 in k5208 in k5177 in loop in string-substitute in k676 */
static void f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 953  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5175(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* concatenate in string-substitute in k676 */
static void C_fcall f_5137(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5137,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5141,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 936  make-string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k5139 in concatenate in string-substitute in k676 */
static void f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5146,a[2]=t1,a[3]=lf[235],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_5146(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop in k5139 in concatenate in string-substitute in k676 */
static C_word C_fcall f_5146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_block_size(t3);
t5=(C_word)C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t4,t2);
t6=(C_word)C_i_cdr(t1);
t7=(C_word)C_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* substitute in string-substitute in k676 */
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5040,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=lf[233],tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_5046(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k676 */
static void C_fcall f_5046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5046,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_5060(2,t6,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 922  substring */
t6=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(t5,C_fix(1));
/* pregexp.scm: 932  loop */
t17=t1;
t18=t2;
t19=t9;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t9=(C_word)C_fix((C_word)C_character_code(t7));
t10=(C_word)C_fixnum_difference(t9,C_fix(48));
t11=(C_word)C_i_list_ref(((C_word*)t0)[3],t10);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 929  substring */
t13=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,((C_word*)t0)[7],t2,t3);}}
else{
/* pregexp.scm: 933  loop */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k5111 in loop in substitute in string-substitute in k676 */
static void f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
t2=f_5025(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 930  substring */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k5099 in k5111 in loop in substitute in string-substitute in k676 */
static void f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5101,2,t0,t1);}
t2=f_5025(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* pregexp.scm: 931  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5046(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5058 in loop in substitute in string-substitute in k676 */
static void f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
/* pregexp.scm: 922  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5025(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k676 */
static C_word C_fcall f_5025(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k676 */
static void f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4832r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4832r(t0,t1,t2,t3,t4);}}

static void f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t5=(C_word)C_i_check_string_2(t3,lf[219]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4851,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[221]);
if(C_truep(t13)){
t14=t12;
f_4851(t14,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,a[6]=lf[226],tmp=(C_word)a,a+=7,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[220]);
t15=t12;
f_4851(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4970,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=lf[227],tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],a[3]=lf[228],tmp=(C_word)a,a+=4,tmp)));}}

/* f_4992 in string-split-fields in k676 */
static void f_4992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4992,4,t0,t1,t2,t3);}
/* pregexp.scm: 882  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* f_4970 in string-split-fields in k676 */
static void f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4970,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* pregexp.scm: 880  reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4991,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 881  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k4989 */
static void f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* pregexp.scm: 881  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* f_4950 in string-split-fields in k676 */
static void f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4950,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* pregexp.scm: 875  ##sys#error */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[219],lf[225],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 876  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k4849 in string-split-fields in k676 */
static void C_fcall f_4851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4851,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[220]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[221]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[222],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[223],tmp=(C_word)a,a+=5,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=lf[224],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_4859(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4849 in string-split-fields in k676 */
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4859,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 887  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4861 in loop in k4849 in string-split-fields in k676 */
static void f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* pregexp.scm: 894  fini */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4905,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_fixnum_plus(t4,C_fix(2));
/* pregexp.scm: 895  fetch */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4924,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 896  fetch */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* pregexp.scm: 897  fini */
t2=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k4922 in k4861 in loop in k4849 in string-split-fields in k676 */
static void f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 896  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4859(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4903 in k4861 in loop in k4849 in string-split-fields in k676 */
static void f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 895  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4859(t4,((C_word*)t0)[2],t2,t3);}

/* f_4939 in k4849 in string-split-fields in k676 */
static void f_4939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4939,5,t0,t1,t2,t3,t4);}
/* pregexp.scm: 885  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_4934 in k4849 in string-split-fields in k676 */
static void f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4934,5,t0,t1,t2,t3,t4);}
/* pregexp.scm: 884  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k676 */
static void f_4806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_4806r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4806r(t0,t1,t2,t3,t4);}}

static void f_4806r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 855  prep2 */
f_4762(t5,lf[147],t2,t3,t4);}

/* k4808 in string-search-positions in k676 */
static void f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4818,a[2]=lf[217],tmp=(C_word)a,a+=3,tmp);
/* map */
t3=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4817 in k4808 in string-search-positions in k676 */
static void f_4818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4818,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* string-search in k676 */
static void f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4800r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4800r(t0,t1,t2,t3,t4);}}

static void f_4800r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* pregexp.scm: 852  prep2 */
f_4762(t1,lf[190],t2,t3,t4);}

/* string-match-positions in k676 */
static void f_4774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_4774r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4774r(t0,t1,t2,t3,t4);}}

static void f_4774r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4778,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 850  prep */
t6=((C_word*)t0)[2];
f_4743(t6,t5,lf[147],t2,t3,t4);}

/* k4776 in string-match-positions in k676 */
static void f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4786,a[2]=lf[212],tmp=(C_word)a,a+=3,tmp);
/* map */
t3=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4785 in k4776 in string-match-positions in k676 */
static void f_4786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4786,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* string-match in k676 */
static void f_4768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4768r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4768r(t0,t1,t2,t3,t4);}}

static void f_4768r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* pregexp.scm: 847  prep */
t5=((C_word*)t0)[2];
f_4743(t5,t1,lf[190],t2,t3,t4);}

/* prep2 in k676 */
static void C_fcall f_4762(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4762,NULL,5,t1,t2,t3,t4,t5);}
C_apply(6,0,t1,t2,t3,t4,t5);}

/* prep in k676 */
static void C_fcall f_4743(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4743,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4751,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
/* pregexp.scm: 842  string-append */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[205],t3,lf[206]);}
else{
t7=t6;
f_4751(2,t7,(C_word)C_a_i_list(&a,4,lf[9],lf[11],t3,lf[12]));}}

/* k4749 in prep in k676 */
static void f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pregexp-replace* in k676 */
static void f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4683,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4687,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* pregexp.scm: 821  pregexp */
t6=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t6=t5;
f_4687(2,t6,t2);}}

/* k4685 in pregexp-replace* in k676 */
static void f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=(C_word)C_i_string_length(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4698,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=lf[202],tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4698(t7,((C_word*)t0)[2],C_fix(0),lf[203]);}

/* loop in k4685 in pregexp-replace* in k676 */
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4698,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 825  pregexp-match-positions */
t5=lf[147];
f_4455(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[6],t2,((C_word*)t0)[3]);}

/* k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 827  cdar */
t3=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 832  substring */
t3=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4733 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 831  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4710 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4716,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 829  caar */
t5=*((C_word*)lf[199]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}

/* k4726 in k4710 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 829  substring */
t2=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4718 in k4710 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 830  pregexp-replace-aux */
f_3708(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4722 in k4718 in k4710 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 828  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4714 in k4710 in k4700 in loop in k4685 in pregexp-replace* in k676 */
static void f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 827  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4698(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-replace in k676 */
static void f_4644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4644,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_string_length(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4651,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 809  pregexp-match-positions */
t7=lf[147];
f_4455(6,t7,t6,t2,t3,C_fix(0),t5);}

/* k4649 in pregexp-replace in k676 */
static void f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_i_string_length(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4663,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* pregexp.scm: 812  caar */
t5=*((C_word*)lf[199]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k4661 in k4649 in pregexp-replace in k676 */
static void f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4666,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 813  cdar */
t3=*((C_word*)lf[198]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4664 in k4661 in k4649 in pregexp-replace in k676 */
static void f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 815  substring */
t3=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],C_fix(0),((C_word*)t0)[2]);}

/* k4671 in k4664 in k4661 in k4649 in pregexp-replace in k676 */
static void f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 816  pregexp-replace-aux */
f_3708(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4675 in k4671 in k4664 in k4661 in k4649 in pregexp-replace in k676 */
static void f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4681,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 817  substring */
t3=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4679 in k4675 in k4671 in k4664 in k4661 in k4649 in pregexp-replace in k676 */
static void f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 814  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-split in k676 */
static void f_4549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4549,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4558,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t4,a[6]=lf[195],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4558(t8,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in pregexp-split in k676 */
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4558,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,((C_word*)t0)[5]))){
/* pregexp.scm: 788  pregexp-reverse! */
f_681(t1,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 789  pregexp-match-positions */
t7=lf[147];
f_4455(6,t7,t6,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* k4569 in loop in pregexp-split in k676 */
static void f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_fixnum_plus(t4,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4604,a[2]=t6,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 798  substring */
t9=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)t0)[5],((C_word*)t0)[4],t8);}
else{
t6=((C_word*)t0)[4];
t7=(C_word)C_eqp(t3,t6);
t8=(C_truep(t7)?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t8)){
/* pregexp.scm: 800  loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_4558(t9,((C_word*)t0)[6],t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4628,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 803  substring */
t10=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[5],((C_word*)t0)[4],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 804  substring */
t3=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4640 in k4569 in loop in pregexp-split in k676 */
static void f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 804  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4558(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4626 in k4569 in loop in pregexp-split in k676 */
static void f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 803  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4558(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4602 in k4569 in loop in pregexp-split in k676 */
static void f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 797  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4558(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* pregexp-match in k676 */
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4520r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4520r(t0,t1,t2,t3,t4);}}

static void f_4520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4524,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,lf[147],t2,t3,t4);}

/* k4522 in pregexp-match in k676 */
static void f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[3],a[3]=lf[191],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4531 in k4522 in pregexp-match in k676 */
static void f_4532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4532,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* pregexp.scm: 780  substring */
t5=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pregexp-match-positions in k676 */
static void f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4455r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4455r(t0,t1,t2,t3,t4);}}

static void f_4455r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4459,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* pregexp.scm: 759  pregexp */
t7=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_4459(2,t7,t2);}}

/* k4457 in pregexp-match-positions in k676 */
static void f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
f_4462(t3,C_fix(0));}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t2;
f_4462(t6,t3);}}

/* k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_4462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4462,NULL,2,t0,t1);}
t2=(C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]);
t3=(C_truep(t2)?(C_word)C_i_string_length(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4470,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t3,a[7]=lf[188],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4470(t7,((C_word*)t0)[2],t1);}

/* loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4470,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[6]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=((C_word*)t0)[6];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=t2;
t11=C_SCHEME_TRUE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2852,a[2]=lf[148],tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2855,a[2]=t15,a[3]=t12,a[4]=t6,a[5]=t9,a[6]=t7,a[7]=lf[187],tmp=(C_word)a,a+=8,tmp));
t17=((C_word*)t15)[1];
f_2855(t17,t4,t5,t10,C_SCHEME_END_OF_LIST,*((C_word*)lf[167]+1),t13);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t7)){
t8=t3;
t9=(C_word)C_eqp(t8,((C_word*)t0)[6]);
if(C_truep(t9)){
/* pregexp.scm: 453  sk */
t10=t5;
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t3,t4);}
else{
/* pregexp.scm: 453  fk */
t10=t6;
((C_proc2)C_retrieve_proc(t10))(2,t10,t1);}}
else{
t8=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t8)){
t9=t3;
t10=((C_word*)((C_word*)t0)[5])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t9,t10))){
/* pregexp.scm: 455  sk */
t11=t5;
((C_proc4)C_retrieve_proc(t11))(4,t11,t1,t3,t4);}
else{
/* pregexp.scm: 455  fk */
t11=t6;
((C_proc2)C_retrieve_proc(t11))(2,t11,t1);}}
else{
t9=(C_word)C_eqp(t2,lf[34]);
if(C_truep(t9)){
/* pregexp.scm: 457  sk */
t10=t5;
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t3,t4);}
else{
t10=(C_word)C_eqp(t2,lf[42]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2913,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 459  pregexp-at-word-boundary? */
f_2500(t11,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t11=(C_word)C_eqp(t2,lf[43]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2931,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 463  pregexp-at-word-boundary? */
f_2500(t12,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,a[8]=t4,a[9]=t1,a[10]=t5,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_charp(t2))){
t13=t3;
t14=((C_word*)((C_word*)t0)[5])[1];
t15=t12;
f_2943(t15,(C_word)C_fixnum_lessp(t13,t14));}
else{
t13=t12;
f_2943(t13,C_SCHEME_FALSE);}}}}}}}

/* k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_2943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2943,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_ref(((C_word*)t0)[6],((C_word*)t0)[11]);
t4=(C_truep(((C_word*)((C_word*)t0)[5])[1])?*((C_word*)lf[149]+1):*((C_word*)lf[92]+1));
t5=t4;
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=t2;
f_2972(t3,C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[11];
t4=((C_word*)((C_word*)t0)[3])[1];
t5=t2;
f_2972(t5,(C_word)C_fixnum_lessp(t3,t4));}}}

/* k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_2972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2972,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_ref(((C_word*)t0)[6],((C_word*)t0)[11]);
/* pregexp.scm: 471  pregexp-check-if-in-char-class? */
f_2546(t2,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[70]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
t6=((C_word*)((C_word*)t0)[3])[1];
t7=t2;
f_2998(t7,(C_word)C_fixnum_lessp(t5,t6));}
else{
t5=t2;
f_2998(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2998(t3,C_SCHEME_FALSE);}}}

/* k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_2998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word ab[178],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_truep(((C_word*)((C_word*)t0)[9])[1])?*((C_word*)lf[150]+1):*((C_word*)lf[151]+1));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3023,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 477  c< */
t7=t3;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[70]);
if(C_truep(t3)){
t4=((C_word*)t0)[10];
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* pregexp.scm: 483  fk */
t6=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t6))(2,t6,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 483  pregexp-error */
t6=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[7],lf[152]);}}
else{
t4=(C_word)C_eqp(t2,lf[68]);
if(C_truep(t4)){
t5=((C_word*)t0)[10];
t6=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
/* pregexp.scm: 485  fk */
t7=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t7))(2,t7,((C_word*)t0)[7]);}
else{
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=t9,a[7]=((C_word*)t0)[5],a[8]=lf[154],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3085(t11,((C_word*)t0)[7],t7);}}
else{
t5=(C_word)C_eqp(t2,lf[15]);
if(C_truep(t5)){
t6=((C_word*)t0)[10];
t7=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t6,t7))){
/* pregexp.scm: 492  fk */
t8=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[7]);}
else{
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[5],a[3]=lf[155],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=lf[156],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 493  sub */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2855(t11,((C_word*)t0)[7],t8,((C_word*)t0)[10],((C_word*)t0)[6],t9,t10);}}
else{
t6=(C_word)C_eqp(t2,lf[9]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=lf[158],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_3165(t11,((C_word*)t0)[7],t7,((C_word*)t0)[10],((C_word*)t0)[6]);}
else{
t7=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=t10,a[7]=((C_word*)t0)[5],a[8]=lf[161],tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_3207(t12,((C_word*)t0)[7],t8);}
else{
t8=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 512  pregexp-list-ref */
f_2811(t9,((C_word*)t0)[6],t10);}
else{
t9=(C_word)C_eqp(t2,lf[137]);
if(C_truep(t9)){
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=t10,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_a_i_list(&a,1,t10);
/* pregexp.scm: 520  append */
t13=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,((C_word*)t0)[6],t12);}
else{
t10=(C_word)C_eqp(t2,lf[165]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_i_cadr(((C_word*)t0)[4]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=lf[166],tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 527  sub */
t14=((C_word*)((C_word*)t0)[2])[1];
f_2855(t14,t11,t12,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[167]+1),t13);}
else{
t11=(C_word)C_eqp(t2,lf[168]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[4]);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3371,a[2]=lf[169],tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 532  sub */
t15=((C_word*)((C_word*)t0)[2])[1];
f_2855(t15,t12,t13,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[167]+1),t14);}
else{
t12=(C_word)C_eqp(t2,lf[170]);
if(C_truep(t12)){
t13=((C_word*)((C_word*)t0)[3])[1];
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t13,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t16=(C_word)C_i_cadr(((C_word*)t0)[4]);
t17=(C_word)C_a_i_list(&a,4,lf[9],lf[171],t16,lf[12]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3398,a[2]=lf[172],tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 538  sub */
t19=((C_word*)((C_word*)t0)[2])[1];
f_2855(t19,t15,t17,C_fix(0),((C_word*)t0)[6],*((C_word*)lf[167]+1),t18);}
else{
t13=(C_word)C_eqp(t2,lf[173]);
if(C_truep(t13)){
t14=((C_word*)((C_word*)t0)[3])[1];
t15=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[10]);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=t14,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t17=(C_word)C_i_cadr(((C_word*)t0)[4]);
t18=(C_word)C_a_i_list(&a,4,lf[9],lf[174],t17,lf[12]);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=lf[175],tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 546  sub */
t20=((C_word*)((C_word*)t0)[2])[1];
f_2855(t20,t16,t18,C_fix(0),((C_word*)t0)[6],*((C_word*)lf[167]+1),t19);}
else{
t14=(C_word)C_eqp(t2,lf[176]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cadr(((C_word*)t0)[4]);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=lf[177],tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 552  sub */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2855(t18,t15,t16,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[167]+1),t17);}
else{
t15=(C_word)C_eqp(t2,lf[25]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t2,lf[26]));
if(C_truep(t16)){
t17=((C_word*)((C_word*)t0)[9])[1];
t18=(C_word)C_i_car(((C_word*)t0)[4]);
t19=(C_word)C_eqp(t18,lf[25]);
t20=C_mutate(((C_word *)((C_word*)t0)[9])+1,t19);
t21=(C_word)C_i_cadr(((C_word*)t0)[4]);
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=((C_word*)t0)[9],a[5]=lf[178],tmp=(C_word)a,a+=6,tmp);
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[5],a[3]=t17,a[4]=((C_word*)t0)[9],a[5]=lf[179],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 561  sub */
t24=((C_word*)((C_word*)t0)[2])[1];
f_2855(t24,((C_word*)t0)[7],t21,((C_word*)t0)[10],((C_word*)t0)[6],t22,t23);}
else{
t17=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(((C_word*)t0)[4]);
t19=(C_word)C_i_not(t18);
t20=(C_word)C_i_caddr(((C_word*)t0)[4]);
t21=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t22=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=t19,a[5]=((C_word*)t0)[8],a[6]=t21,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t23,a[10]=((C_word*)t0)[2],a[11]=t20,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t23))){
t25=(C_word)C_i_car(t23);
t26=t24;
f_3526(t26,(C_word)C_eqp(t25,lf[137]));}
else{
t25=t24;
f_3526(t25,C_SCHEME_FALSE);}}
else{
/* pregexp.scm: 601  pregexp-error */
t18=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,((C_word*)t0)[7],lf[152]);}}}}}}}}}}}}}}}
else{
t2=((C_word*)t0)[10];
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
/* pregexp.scm: 602  fk */
t4=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t4))(2,t4,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 603  pregexp-error */
t4=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[7],lf[152]);}}}}

/* k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3526,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=((C_word*)t0)[11],a[12]=lf[186],tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_3531(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2],lf[181]);}

/* loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3531,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[11]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=lf[180],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 575  sub */
t7=((C_word*)((C_word*)t0)[9])[1];
f_2855(t7,t1,((C_word*)t0)[8],t3,((C_word*)t0)[7],t6,((C_word*)t0)[6]);}
else{
t6=(C_truep(((C_word*)t0)[5])?(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[11]):C_SCHEME_FALSE);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3559,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=lf[185],tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_3559(t10,t1,C_fix(0),t3,t4);}}

/* loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3559,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[9],a[7]=lf[182],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t7=t2;
t8=t6;
f_3588(t8,(C_word)C_fixnum_greater_or_equal_p(t7,((C_word*)t0)[2]));}
else{
t7=t6;
f_3588(t7,C_SCHEME_FALSE);}}

/* k3586 in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3588,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 589  fk */
t2=((C_word*)t0)[10];
f_3561(2,t2,((C_word*)t0)[9]);}
else{
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=lf[183],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 591  sub */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2855(t3,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 596  fk */
t3=((C_word*)t0)[10];
f_3561(2,t3,t2);}}}

/* k3614 in k3586 in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[184],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 597  sub */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2855(t3,((C_word*)t0)[9],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a3623 in k3614 in k3586 in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3624,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 599  loup-q */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3559(t5,t1,t4,t2,t3);}

/* a3598 in k3586 in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3599,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 593  loup-q */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3559(t6,t4,t5,t2,t3);}

/* k3601 in a3598 in k3586 in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* pregexp.scm: 594  fk */
t2=((C_word*)t0)[2];
f_3561(2,t2,((C_word*)t0)[3]);}}

/* fk in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[181]);
if(C_truep(t3)){
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE);
/* pregexp.scm: 585  append */
t5=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[2],t4);}
else{
t4=t2;
f_3569(2,t4,((C_word*)t0)[2]);}}
else{
t4=t2;
f_3569(2,t4,((C_word*)t0)[4]);}}

/* k3567 in fk in loup-q in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 582  sk */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3542 in loup-p in k3524 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3543,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 577  loup-p */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3531(t5,t1,t4,t2,t3);}

/* a3495 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
/* pregexp.scm: 567  fk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a3488 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3489,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
/* pregexp.scm: 564  sk */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}

/* a3465 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3441 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
/* pregexp.scm: 555  sk */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}
else{
/* pregexp.scm: 556  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[3]);}}

/* a3428 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3411 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
if(C_truep(t1)){
/* pregexp.scm: 550  fk */
t3=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 550  sk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a3397 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3380 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
if(C_truep(t1)){
/* pregexp.scm: 542  sk */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 542  fk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[5]);}}

/* a3370 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3354 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 534  fk */
t2=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 534  sk */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a3345 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3329 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 529  sk */
t2=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 529  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[5]);}}

/* k3300 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=lf[164],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 521  sub */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2855(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* a3310 in k3300 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3311,4,t0,t1,t2,t3);}
t4=(C_word)C_i_set_cdr(((C_word*)t0)[3],t2);
/* pregexp.scm: 524  sk */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}

/* k3257 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_cdr(t1);
/* pregexp.scm: 515  substring */
t5=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[2],t3,t4);}
else{
/* pregexp.scm: 517  sk */
t2=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[7]);}}

/* k3267 in k3257 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[162],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)((C_word*)t0)[4])[1];
t6=((C_word*)t0)[3];
t7=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_fixnum_greaterp(t7,t5))){
/* pregexp.scm: 370  fk */
t8=t6;
((C_proc2)C_retrieve_proc(t8))(2,t8,t3);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2433,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=t5,a[7]=t2,a[8]=t7,a[9]=lf[163],tmp=(C_word)a,a+=10,tmp));
t11=((C_word*)t9)[1];
f_2433(t11,t3,C_fix(0),t4);}}

/* loop in k3267 in k3257 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2433,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[8]))){
/* pregexp.scm: 372  sk */
t5=((C_word*)t0)[7];
f_3271(t5,t1,t3);}
else{
t5=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,((C_word*)t0)[6]))){
/* pregexp.scm: 373  fk */
t6=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t6))(2,t6,t1);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 375  loop */
t12=t1;
t13=t9;
t14=t10;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
/* pregexp.scm: 376  fk */
t9=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t9))(2,t9,t1);}}}}

/* a3270 in k3267 in k3257 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3271,NULL,3,t0,t1,t2);}
/* pregexp.scm: 516  sk */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* loup-or in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3207,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 505  fk */
t3=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=lf[159],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[160],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 506  sub */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2855(t6,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2],t4,t5);}}

/* a3241 in loup-or in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* pregexp.scm: 510  loup-or */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3207(t3,t1,t2);}

/* a3225 in loup-or in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3226,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 508  sk */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k3228 in a3225 in loup-or in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* pregexp.scm: 509  loup-or */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3207(t3,((C_word*)t0)[4],t2);}}

/* loup-seq in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3165,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 498  sk */
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[157],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 499  sub */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2855(t7,t1,t5,t3,t4,t6,((C_word*)t0)[2]);}}

/* a3183 in loup-seq in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3184,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* pregexp.scm: 501  loup-seq */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3165(t5,t1,t4,t2,t3);}

/* a3141 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 495  sk */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3135 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3136,4,t0,t1,t2,t3);}
/* pregexp.scm: 494  fk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}

/* loup-one-of-chars in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3085,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 487  fk */
t3=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[153],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 488  sub */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2855(t5,t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}}

/* a3103 in loup-one-of-chars in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* pregexp.scm: 490  loup-one-of-chars */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3085(t3,t1,t2);}

/* k3021 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* pregexp.scm: 478  c< */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3010(2,t2,C_SCHEME_FALSE);}}

/* k3008 in k2996 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 479  sk */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 479  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k2976 in k2970 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 473  sk */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 473  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k2947 in k2941 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 469  sk */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 469  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k2929 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 464  fk */
t2=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 465  sk */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2911 in sub in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 460  sk */
t2=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 461  fk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[5]);}}

/* a2851 in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4478 in loop in k4460 in k4457 in pregexp-match-positions in k676 */
static void f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(t1));}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 771  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4470(t3,((C_word*)t0)[4],t2);}}

/* regexp? in k676 */
static void f_4439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4439,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[137],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pregexp in k676 */
static void f_4380(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4380r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4380r(t0,t1,t2,t3);}}

static void f_4380r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4388(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4394,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_car(t3))){
/* pregexp.scm: 744  string-append */
t6=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[142],t2,lf[143]);}
else{
t6=t5;
f_4394(2,t6,t2);}}}

/* k4392 in pregexp in k676 */
static void f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
f_4388(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_car(t2))){
/* pregexp.scm: 748  string-append */
t4=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[140],t1,lf[141]);}
else{
t4=t3;
f_4406(2,t4,t1);}}}

/* k4404 in k4392 in pregexp in k676 */
static void f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
/* pregexp.scm: 751  utf8-pattern->byte-pattern */
t5=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t1);}
else{
t5=((C_word*)t0)[2];
f_4388(2,t5,t1);}}

/* k4386 in pregexp in k676 */
static void f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 741  %pregexp */
t2=*((C_word*)lf[136]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* %pregexp in k676 */
static void f_4361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4361,3,t0,t1,t2);}
t3=C_set_block_item(lf[0],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4374,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_string_length(t2);
/* pregexp.scm: 738  pregexp-read-pattern */
f_711(t4,t2,C_fix(0),t5);}

/* k4372 in %pregexp in k676 */
static void f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[137],t2));}

/* utf8-pattern->byte-pattern in k676 */
static void f_3957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3957,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4091,a[2]=t2,a[3]=lf[129],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3963,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=lf[132],tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4203,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=t2,a[6]=t3,a[7]=lf[134],tmp=(C_word)a,a+=8,tmp));
/* pregexp.scm: 733  scan */
t11=((C_word*)t6)[1];
f_3963(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* class in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word *a;
loop:
a=C_alloc(40);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4203,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_eqp(t6,((C_word*)t0)[6]);
if(C_truep(t7)){
/* pregexp.scm: 715  ##sys#error */
t8=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[111],lf[133],((C_word*)t0)[5]);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
switch(t8){
case C_make_character(93):
if(C_truep(t4)){
t9=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_a_i_cons(&a,2,C_make_character(91),t5);
/* pregexp.scm: 720  append */
t12=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,t3,t11);}
else{
t9=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4255,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4263,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 721  class->group */
t13=((C_word*)t0)[3];
f_4091(t13,t12,t3);}
case C_make_character(92):
t9=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_i_string_ref(((C_word*)t0)[5],t9);
t11=(C_word)C_fix((C_word)C_character_code(t10));
if(C_truep((C_word)C_fixnum_lessp(t11,C_fix(128)))){
t12=(C_word)C_fixnum_plus(t2,C_fix(2));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t14=(C_word)C_a_i_cons(&a,2,t10,t13);
/* pregexp.scm: 725  class */
t30=t1;
t31=t12;
t32=t14;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t12=(C_word)C_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
/* pregexp.scm: 726  class */
t30=t1;
t31=t12;
t32=t13;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
default:
t9=(C_word)C_fix((C_word)C_character_code(t8));
if(C_truep((C_word)C_fixnum_lessp(t9,C_fix(128)))){
t10=(C_word)C_fixnum_plus(t2,C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t8,t3);
/* pregexp.scm: 729  class */
t30=t1;
t31=t10;
t32=t11;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=(C_word)C_fix((C_word)C_character_code(t8));
/* pregexp.scm: 730  utf8-start-byte->length */
t12=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}}}

/* k4346 in class in utf8-pattern->byte-pattern in k676 */
static void f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 731  string-ref-at-byte */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k4342 in k4346 in class in utf8-pattern->byte-pattern in k676 */
static void f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* pregexp.scm: 730  class */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4203(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4261 in class in utf8-pattern->byte-pattern in k676 */
static void f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  reverse */
t2=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4257 in class in utf8-pattern->byte-pattern in k676 */
static void f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  append */
t2=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4253 in class in utf8-pattern->byte-pattern in k676 */
static void f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4238 in class in utf8-pattern->byte-pattern in k676 */
static void f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(93),t1);
/* pregexp.scm: 720  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3963(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* scan in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_3963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3963,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,((C_word*)t0)[5]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 686  reverse */
t7=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
switch(t6){
case C_make_character(46):
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3992,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_lessp(t8,((C_word*)t0)[5]))){
t9=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_i_string_ref(((C_word*)t0)[4],t9);
t11=t7;
f_3992(t11,(C_word)C_eqp(C_make_character(42),t10));}
else{
t9=t7;
f_3992(t9,C_SCHEME_FALSE);}
case C_make_character(92):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t9=(C_word)C_i_string_ref(((C_word*)t0)[4],t8);
t10=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* pregexp.scm: 694  scan */
t21=t1;
t22=t7;
t23=t11;
t1=t21;
t2=t22;
t3=t23;
goto loop;
case C_make_character(91):
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 695  class */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4203(t8,t1,t7,C_SCHEME_END_OF_LIST,C_SCHEME_TRUE,t3);
default:
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* pregexp.scm: 696  scan */
t21=t1;
t22=t7;
t23=t8;
t1=t21;
t2=t22;
t3=t23;
goto loop;}}}

/* k3990 in scan in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_3992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3992,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(46),((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(42),t3);
/* pregexp.scm: 691  scan */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3963(t5,((C_word*)t0)[2],t2,t4);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4018,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 692  append */
t4=*((C_word*)lf[131]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[116],((C_word*)t0)[4]);}}

/* k4016 in k3990 in scan in utf8-pattern->byte-pattern in k676 */
static void f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 692  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3975 in scan in utf8-pattern->byte-pattern in k676 */
static void f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 686  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* class->group in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_4091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4091,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4097,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=lf[128],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4097(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in class->group in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4097,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4111,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 701  string-intersperse */
t6=*((C_word*)lf[121]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,lf[122]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4127,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_4127(t8,(C_word)C_eqp(C_make_character(45),t7));}
else{
t7=t6;
f_4127(t7,C_SCHEME_FALSE);}}}

/* k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_4127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4127,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[7]));
t4=(C_word)C_fixnum_greaterp(t3,C_fix(128));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4139,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_4139(t6,t4);}
else{
t6=(C_word)C_fix((C_word)C_character_code(t2));
t7=t5;
f_4139(t7,(C_word)C_fixnum_greaterp(t6,C_fix(128)));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4191,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 712  char->string */
t4=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[7]);}}

/* k4189 in k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 712  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4097(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4137 in k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void C_fcall f_4139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4139,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 707  ##sys#error */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[111],lf[123],((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 709  char->string */
t5=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4159 in k4137 in k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 710  char->string */
t3=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4163 in k4159 in k4137 in k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 709  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[124],((C_word*)t0)[2],lf[125],t1,lf[126]);}

/* k4155 in k4137 in k4125 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 708  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4097(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4113 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 701  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[119],t1,lf[120]);}

/* k4109 in loop in class->group in utf8-pattern->byte-pattern in k676 */
static void f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 700  string->list */
t2=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-ref-at-byte in k676 */
static void f_3868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3868,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3878,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 659  utf8-start-byte->length */
t7=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3876 in string-ref-at-byte in k676 */
static void f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,t4))){
/* pregexp.scm: 664  ##sys#error */
t5=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,((C_word*)t0)[5],lf[111],lf[112],((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3907,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_difference(C_fix(7),t1);
/* pregexp.scm: 665  extract-bit-field */
t8=*((C_word*)lf[105]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,C_fix(0),((C_word*)t0)[4]);}}}

/* k3905 in k3876 in string-ref-at-byte in k676 */
static void f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[113],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3909(t2,((C_word*)t0)[2],t1));}

/* loop in k3905 in k3876 in string-ref-at-byte in k676 */
static C_word C_fcall f_3909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
C_stack_check;
t3=t1;
t4=(C_word)C_eqp(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
return((C_word)C_make_character((C_word)C_unfix(t2)));}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_fixnum_shift_left(t2,C_fix(6));
t7=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t8=(C_word)C_fix((C_word)C_character_code(t7));
t9=(C_word)C_fixnum_and(C_fix(63),t8);
t10=(C_word)C_fixnum_or(t6,t9);
t12=t5;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* utf8-start-byte->length in k676 */
static void f_3862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3862,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(lf[108],t2));}

/* extract-bit-field in k676 */
static void f_3840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3840,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_fixnum_arithmetic_shift(C_fix(-1),t2);
t6=(C_word)C_fixnum_not(t5);
t7=(C_word)C_fixnum_negate(t3);
t8=(C_word)C_i_fixnum_arithmetic_shift(t4,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_and(t6,t8));}

/* pregexp-replace-aux in k676 */
static void C_fcall f_3708(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3708,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3714,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t3,a[6]=t4,a[7]=lf[102],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3714(t9,t1,C_fix(0),lf[103]);}

/* loop in pregexp-replace-aux in k676 */
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t7=(C_word)C_eqp(t6,C_make_character(92));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 611  pregexp-read-escaped-number */
f_1134(t8,((C_word*)t0)[5],t2,((C_word*)t0)[6]);}
else{
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=t3,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 629  string */
t11=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t6);}}}

/* k3836 in loop in pregexp-replace-aux in k676 */
static void f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 629  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3832 in loop in pregexp-replace-aux in k676 */
static void f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 629  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3714(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3731 in loop in pregexp-replace-aux in k676 */
static void f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_3736(t3,(C_word)C_i_car(t1));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t5=(C_word)C_eqp(t4,C_make_character(38));
t6=t2;
f_3736(t6,(C_truep(t5)?C_fix(0):C_SCHEME_FALSE));}}

/* k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void C_fcall f_3736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3736,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cadr(((C_word*)t0)[9]):(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2)):(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1))));
t3=t1;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 624  pregexp-list-ref */
f_2811(t4,((C_word*)t0)[3],t1);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t4,C_make_character(36));
if(C_truep(t7)){
t8=t6;
f_3759(2,t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 622  string */
t9=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}}

/* k3767 in k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 622  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3757 in k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 620  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3714(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3774 in k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t1);
t5=(C_word)C_i_cdr(t1);
/* pregexp.scm: 627  substring */
t6=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}
else{
t3=t2;
f_3779(2,t3,((C_word*)t0)[3]);}}

/* k3784 in k3774 in k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 626  string-append */
t2=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3777 in k3774 in k3734 in k3731 in loop in pregexp-replace-aux in k676 */
static void f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 623  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3714(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-list-ref in k676 */
static void C_fcall f_2811(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=t3,a[3]=lf[96],tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2817(t4,t2,C_fix(0)));}

/* loop in pregexp-list-ref in k676 */
static C_word C_fcall f_2817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=t2;
t4=((C_word*)t0)[2];
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
return((C_word)C_i_car(t1));}
else{
t6=(C_word)C_i_cdr(t1);
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* pregexp-check-if-in-char-class? in k676 */
static void C_fcall f_2546(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2546,NULL,3,t1,t2,t3);}
t4=(C_word)C_eqp(t3,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t2,C_make_character(10));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}
else{
t5=(C_word)C_eqp(t3,lf[81]);
if(C_truep(t5)){
t6=(C_word)C_u_i_char_alphabeticp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_u_i_char_numericp(t2)));}
else{
t6=(C_word)C_eqp(t3,lf[82]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_u_i_char_alphabeticp(t2));}
else{
t7=(C_word)C_eqp(t3,lf[83]);
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_character_code(t2));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_lessp(t8,C_fix(128)));}
else{
t8=(C_word)C_eqp(t3,lf[84]);
if(C_truep(t8)){
t9=(C_word)C_eqp(t2,C_make_character(32));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?t9:(C_word)C_eqp(t2,C_make_character(9))));}
else{
t9=(C_word)C_eqp(t3,lf[85]);
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t2));
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_fixnum_lessp(t10,C_fix(32)));}
else{
t10=(C_word)C_eqp(t3,lf[44]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_u_i_char_numericp(t2));}
else{
t11=(C_word)C_eqp(t3,lf[86]);
if(C_truep(t11)){
t12=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t12,C_fix(32)))){
t13=(C_word)C_u_i_char_whitespacep(t2);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_i_not(t13));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t3,lf[87]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_u_i_char_lower_casep(t2));}
else{
t13=(C_word)C_eqp(t3,lf[88]);
if(C_truep(t13)){
t14=(C_word)C_fix((C_word)C_character_code(t2));
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_fixnum_greater_or_equal_p(t14,C_fix(32)));}
else{
t14=(C_word)C_eqp(t3,lf[89]);
if(C_truep(t14)){
t15=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t15,C_fix(32)))){
if(C_truep((C_word)C_u_i_char_whitespacep(t2))){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t2))){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_u_i_char_numericp(t2);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_i_not(t16));}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_eqp(t3,lf[46]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_u_i_char_whitespacep(t2));}
else{
t16=(C_word)C_eqp(t3,lf[90]);
if(C_truep(t16)){
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_u_i_char_upper_casep(t2));}
else{
t17=(C_word)C_eqp(t3,lf[48]);
if(C_truep(t17)){
t18=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t18)){
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t19=(C_word)C_u_i_char_numericp(t2);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_truep(t19)?t19:(C_word)C_eqp(t2,C_make_character(95))));}}
else{
t18=(C_word)C_eqp(t3,lf[91]);
if(C_truep(t18)){
t19=(C_word)C_u_i_char_numericp(t2);
if(C_truep(t19)){
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 423  char-ci=? */
t21=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t21))(4,t21,t20,t2,C_make_character(97));}}
else{
/* pregexp.scm: 426  pregexp-error */
t19=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t1,lf[93]);}}}}}}}}}}}}}}}}

/* k2774 in pregexp-check-if-in-char-class? in k676 */
static void f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 423  char-ci=? */
t3=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(98));}}

/* k2780 in k2774 in pregexp-check-if-in-char-class? in k676 */
static void f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 424  char-ci=? */
t3=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(99));}}

/* k2786 in k2780 in k2774 in pregexp-check-if-in-char-class? in k676 */
static void f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 424  char-ci=? */
t3=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(100));}}

/* k2792 in k2786 in k2780 in k2774 in pregexp-check-if-in-char-class? in k676 */
static void f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 425  char-ci=? */
t3=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(101));}}

/* k2798 in k2792 in k2786 in k2780 in k2774 in pregexp-check-if-in-char-class? in k676 */
static void f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* pregexp.scm: 425  char-ci=? */
t2=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(102));}}

/* pregexp-at-word-boundary? in k676 */
static void C_fcall f_2500(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,4,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=t3;
t8=(C_word)C_fixnum_greater_or_equal_p(t7,t4);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_i_string_ref(t2,t3);
t10=(C_word)C_fixnum_difference(t3,C_fix(1));
t11=(C_word)C_i_string_ref(t2,t10);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 391  pregexp-check-if-in-char-class? */
f_2546(t12,t9,lf[48]);}}}

/* k2520 in pregexp-at-word-boundary? in k676 */
static void f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 393  pregexp-check-if-in-char-class? */
f_2546(t2,((C_word*)t0)[2],lf[48]);}

/* k2523 in k2520 in pregexp-at-word-boundary? in k676 */
static void f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t1));}}

/* pregexp-char-word? in k676 */
static void f_2482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2482,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(95))));}}

/* pregexp-read-char-list in k676 */
static void C_fcall f_2209(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2209,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2215,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=lf[74],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2215(t8,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in pregexp-read-char-list in k676 */
static void C_fcall f_2215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word *a;
loop:
a=C_alloc(122);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2215,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* pregexp.scm: 339  pregexp-error */
t6=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,lf[66],lf[67]);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
switch(t6){
case C_make_character(93):
if(C_truep((C_word)C_i_nullp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 344  loop */
t41=t1;
t42=t7;
t43=t8;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2266,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 345  pregexp-reverse! */
f_681(t7,t2);}
case C_make_character(92):
t7=f_1230(C_a_i(&a,72),((C_word*)t0)[3],t3,((C_word*)t0)[4]);
if(C_truep(t7)){
t8=(C_word)C_i_car(t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t2);
t10=(C_word)C_i_cadr(t7);
/* pregexp.scm: 349  loop */
t41=t1;
t42=t9;
t43=t10;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
/* pregexp.scm: 350  pregexp-error */
t8=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[66],lf[69]);}
case C_make_character(45):
t7=(C_word)C_i_car(t2);
if(C_truep((C_word)C_charp(t7))){
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_i_string_ref(((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_list(&a,3,lf[70],t7,t9);
t11=(C_word)C_i_cdr(t2);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_fixnum_plus(t3,C_fix(2));
/* pregexp.scm: 353  loop */
t41=t1;
t42=t12;
t43=t13;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
t8=(C_word)C_a_i_cons(&a,2,t6,t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 356  loop */
t41=t1;
t42=t8;
t43=t9;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
case C_make_character(91):
t7=(C_word)C_fixnum_plus(t3,C_fix(1));
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=(C_word)C_eqp(t8,C_make_character(58));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2364,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_fixnum_plus(t3,C_fix(2));
t12=((C_word*)t0)[3];
t13=((C_word*)t0)[4];
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(C_word)C_a_i_list(&a,1,C_make_character(58));
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1410,a[2]=t18,a[3]=t15,a[4]=t12,a[5]=t13,a[6]=lf[73],tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_1410(t20,t10,t11,t16);}
else{
t10=(C_word)C_a_i_cons(&a,2,t6,t2);
t11=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 362  loop */
t41=t1;
t42=t10;
t43=t11;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
default:
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 363  loop */
t41=t1;
t42=t7;
t43=t8;
t1=t41;
t2=t42;
t3=t43;
goto loop;}}}

/* loop in loop in pregexp-read-char-list in k676 */
static void C_fcall f_1410(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1410,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
/* pregexp.scm: 186  pregexp-error */
t5=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,lf[71]);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t6=(C_word)C_eqp(t5,C_make_character(94));
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 190  loop */
t19=t1;
t20=t8;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t5))){
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t5,t3);
/* pregexp.scm: 192  loop */
t19=t1;
t20=t7;
t21=t8;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t7=(C_word)C_eqp(t5,C_make_character(58));
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t9=(C_word)C_fixnum_greater_or_equal_p(t8,((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1469,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1469(t11,t9);}
else{
t11=(C_word)C_fixnum_plus(t2,C_fix(1));
t12=(C_word)C_i_string_ref(((C_word*)t0)[4],t11);
t13=(C_word)C_eqp(t12,C_make_character(93));
t14=t10;
f_1469(t14,(C_word)C_i_not(t13));}}
else{
/* pregexp.scm: 204  pregexp-error */
t8=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,lf[71]);}}}}}

/* k1467 in loop in loop in pregexp-read-char-list in k676 */
static void C_fcall f_1469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 196  pregexp-error */
t2=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[71]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 199  pregexp-reverse! */
f_681(t4,((C_word*)t0)[2]);}}

/* k1495 in k1467 in loop in loop in pregexp-read-char-list in k676 */
static void f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 199  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1491 in k1467 in loop in loop in pregexp-read-char-list in k676 */
static void f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 198  string->symbol */
t2=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1473 in k1467 in loop in loop in pregexp-read-char-list in k676 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(C_truep(((C_word*)((C_word*)t0)[4])[1])?(C_word)C_a_i_list(&a,2,lf[15],t1):t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2362 in loop in pregexp-read-char-list in k676 */
static void f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_i_cadr(t1);
/* pregexp.scm: 360  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2215(t5,((C_word*)t0)[2],t3,t4);}

/* k2264 in loop in pregexp-read-char-list in k676 */
static void f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* pregexp-invert-char-list in k676 */
static void f_2199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2199,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_set_car(t3,lf[64]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_1779(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1779,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1792,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=t2,a[6]=t4,a[7]=lf[61],tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_1792(t10,t1,t6);}

/* loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_1792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1792,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t3)[1];
t5=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[5]);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],((C_word*)t3)[1]);
t7=(C_word)C_u_i_char_whitespacep(t6);
t8=(C_truep(t7)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)t3)[1],C_fix(1));
/* pregexp.scm: 266  loop */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t9=(C_word)C_eqp(t6,C_make_character(42));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t9)){
t11=t10;
f_1824(t11,t9);}
else{
t11=(C_word)C_eqp(t6,C_make_character(43));
if(C_truep(t11)){
t12=t10;
f_1824(t12,t11);}
else{
t12=(C_word)C_eqp(t6,C_make_character(63));
t13=t10;
f_1824(t13,(C_truep(t12)?t12:(C_word)C_eqp(t6,C_make_character(123))));}}}}}

/* k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_1824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,5,lf[51],lf[52],lf[53],lf[54],((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,2,t2,lf[55]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
switch(((C_word*)t0)[3]){
case C_make_character(42):
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_i_set_car(t5,C_fix(0));
t7=(C_word)C_i_cdddr(t2);
t8=t4;
f_1833(t8,(C_word)C_i_set_car(t7,C_SCHEME_FALSE));
case C_make_character(43):
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_i_set_car(t5,C_fix(1));
t7=(C_word)C_i_cdddr(t2);
t8=t4;
f_1833(t8,(C_word)C_i_set_car(t7,C_SCHEME_FALSE));
case C_make_character(63):
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_i_set_car(t5,C_fix(0));
t7=(C_word)C_i_cdddr(t2);
t8=t4;
f_1833(t8,(C_word)C_i_set_car(t7,C_fix(1)));
case C_make_character(123):
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[6];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2057,a[2]=t8,a[3]=t10,a[4]=t7,a[5]=lf[60],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2057(t12,t5,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t6,C_fix(1));
default:
t5=t4;
f_1833(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2061,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t5,a[7]=t4,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t7,((C_word*)t0)[2]))){
/* pregexp.scm: 310  pregexp-error */
t8=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,lf[59]);}
else{
t8=t6;
f_2061(2,t8,C_SCHEME_UNDEFINED);}}

/* k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t3,C_fix(1));
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 314  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2057(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],t6,C_fix(1));}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 315  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2057(t7,((C_word*)t0)[3],((C_word*)t0)[5],t5,t6,C_fix(2));}}
else{
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 317  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2057(t6,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t6)){
t7=((C_word*)t0)[6];
t8=t5;
f_2117(t8,(C_word)C_eqp(t7,C_fix(1)));}
else{
t7=t5;
f_2117(t7,C_SCHEME_FALSE);}}}}

/* k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_2117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
/* pregexp.scm: 319  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2057(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],C_make_character(125));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 321  pregexp-reverse! */
f_681(t5,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k2177 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 321  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2173 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 321  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k2131 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2136,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2167,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2171,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 322  pregexp-reverse! */
f_681(t4,((C_word*)t0)[2]);}

/* k2169 in k2131 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 322  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2165 in k2131 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 322  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k2134 in k2131 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2142,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
if(C_truep(t3)){
t4=t2;
f_2142(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)t0)[3];
t5=t2;
f_2142(t5,(C_word)C_eqp(t4,C_fix(1)));}}

/* k2140 in k2134 in k2131 in k2115 in k2059 in loop in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_2142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2142,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,C_fix(0),C_SCHEME_FALSE,((C_word*)t0)[5]));}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_eqp(t2,C_fix(1));
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[5]):(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5])));}}

/* k1987 in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1992(2,t4,C_SCHEME_UNDEFINED);}
else{
/* pregexp.scm: 281  pregexp-error */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[57],lf[58]);}}

/* k1990 in k1987 in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_set_car(t2,t3);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t6=(C_word)C_i_cadr(((C_word*)t0)[4]);
t7=(C_word)C_i_set_car(t5,t6);
t8=(C_word)C_i_caddr(((C_word*)t0)[4]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=((C_word*)t0)[2];
f_1833(t10,t9);}

/* k1831 in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static void C_fcall f_1833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[56],tmp=(C_word)a,a+=7,tmp);
t4=f_1842(t3,t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* loop in k1831 in k1822 in loop in pregexp-wrap-quantifier-if-any in k676 */
static C_word C_fcall f_1842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_set_car(t4,C_SCHEME_FALSE);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
return((C_word)C_i_set_car(t6,t1));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t5=(C_word)C_u_i_char_whitespacep(t4);
t6=(C_truep(t5)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(t1,C_fix(1));
t20=t7;
t1=t20;
goto loop;}
else{
t7=(C_word)C_eqp(t4,C_make_character(63));
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
t9=(C_word)C_i_set_car(t8,C_SCHEME_TRUE);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_fixnum_plus(t1,C_fix(1));
return((C_word)C_i_set_car(t10,t11));}
else{
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
t9=(C_word)C_i_set_car(t8,C_SCHEME_FALSE);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
return((C_word)C_i_set_car(t10,t1));}}}}

/* pregexp-read-escaped-char in k676 */
static C_word C_fcall f_1230(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_stack_check;
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
t6=(C_word)C_i_string_ref(t1,t5);
switch(t6){
case C_make_character(98):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[42],t7));
case C_make_character(66):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[43],t7));
case C_make_character(100):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[44],t7));
case C_make_character(68):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[45],t7));
case C_make_character(110):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(10),t7));
case C_make_character(114):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(13),t7));
case C_make_character(115):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[46],t7));
case C_make_character(83):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[47],t7));
case C_make_character(116):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(9),t7));
case C_make_character(119):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[48],t7));
case C_make_character(87):
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[49],t7));
default:
t7=(C_word)C_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,t6,t7));}}
else{
return(C_SCHEME_FALSE);}}

/* pregexp-read-escaped-number in k676 */
static void C_fcall f_1134(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1134,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=t4;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
t7=(C_word)C_fixnum_plus(t3,C_fix(1));
t8=(C_word)C_i_string_ref(t2,t7);
if(C_truep((C_word)C_u_i_char_numericp(t8))){
t9=(C_word)C_fixnum_plus(t3,C_fix(2));
t10=(C_word)C_a_i_list(&a,1,t8);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1163,a[2]=t12,a[3]=t2,a[4]=t4,a[5]=lf[40],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_1163(t14,t1,t9,t10);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* loop in pregexp-read-escaped-number in k676 */
static void C_fcall f_1163(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(23);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1163,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 153  pregexp-reverse! */
f_681(t8,t3);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
if(C_truep((C_word)C_u_i_char_numericp(t6))){
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* pregexp.scm: 156  loop */
t16=t1;
t17=t7;
t18=t8;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 158  pregexp-reverse! */
f_681(t9,t3);}}}

/* k1218 in loop in pregexp-read-escaped-number in k676 */
static void f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 158  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1214 in loop in pregexp-read-escaped-number in k676 */
static void f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 157  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1210 in loop in pregexp-read-escaped-number in k676 */
static void f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k1183 in loop in pregexp-read-escaped-number in k676 */
static void f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 153  list->string */
t2=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1179 in loop in pregexp-read-escaped-number in k676 */
static void f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 152  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1175 in loop in pregexp-read-escaped-number in k676 */
static void f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1177,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* pregexp-read-pattern in k676 */
static void C_fcall f_711(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_711,NULL,4,t1,t2,t3,t4);}
t5=t3;
t6=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
t7=(C_word)C_a_i_list(&a,1,lf[9]);
t8=(C_word)C_a_i_list(&a,2,lf[10],t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,2,t8,t3));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_734,a[2]=t2,a[3]=t8,a[4]=t4,a[5]=lf[37],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_734(t10,t1,C_SCHEME_END_OF_LIST,t3);}}

/* loop in pregexp-read-pattern in k676 */
static void C_fcall f_734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_734,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[4];
t6=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_744(t8,t6);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t9=t7;
f_744(t9,(C_word)C_eqp(t8,C_make_character(41)));}}

/* k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_744,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 80   pregexp-reverse! */
f_681(t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,C_make_character(124));
t5=(C_truep(t4)?(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1)):((C_word*)t0)[6]);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_802,a[2]=t9,a[3]=t6,a[4]=t7,a[5]=lf[36],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_802(t11,t2,C_SCHEME_END_OF_LIST,t5);}}

/* loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[104],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_802,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[4]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_820,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 90   pregexp-reverse! */
f_681(t5,t2);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t6=(C_word)C_eqp(t5,C_make_character(124));
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,C_make_character(41)));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_843,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 94   pregexp-reverse! */
f_681(t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_846,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=t3;
t10=(C_word)C_i_string_ref(((C_word*)t0)[3],t9);
switch(t10){
case C_make_character(94):
t11=(C_word)C_fixnum_plus(t9,C_fix(1));
t12=t8;
f_846(2,t12,(C_word)C_a_i_list(&a,2,lf[11],t11));
case C_make_character(36):
t11=(C_word)C_fixnum_plus(t9,C_fix(1));
t12=t8;
f_846(2,t12,(C_word)C_a_i_list(&a,2,lf[12],t11));
case C_make_character(46):
t11=(C_word)C_fixnum_plus(t9,C_fix(1));
t12=(C_word)C_a_i_list(&a,2,lf[13],t11);
/* pregexp.scm: 104  pregexp-wrap-quantifier-if-any */
f_1779(t8,t12,((C_word*)t0)[3],((C_word*)t0)[4]);
case C_make_character(91):
t11=(C_word)C_fixnum_plus(t9,C_fix(1));
t12=(C_word)C_i_string_ref(((C_word*)t0)[3],t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_eqp(t12,C_make_character(94));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_fixnum_plus(t9,C_fix(2));
/* pregexp.scm: 109  pregexp-read-char-list */
f_2209(t15,((C_word*)t0)[3],t16,((C_word*)t0)[4]);}
else{
t15=(C_word)C_fixnum_plus(t9,C_fix(1));
/* pregexp.scm: 111  pregexp-read-char-list */
f_2209(t13,((C_word*)t0)[3],t15,((C_word*)t0)[4]);}
case C_make_character(40):
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_fixnum_plus(t9,C_fix(1));
t13=*((C_word*)lf[0]+1);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t11,a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t16=(C_word)C_eqp(t15,C_make_character(63));
if(C_truep(t16)){
t17=(C_word)C_fixnum_plus(t12,C_fix(1));
t18=(C_word)C_i_string_ref(((C_word*)t0)[3],t17);
switch(t18){
case C_make_character(58):
t19=(C_word)C_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1707(2,t20,(C_word)C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,t19));
case C_make_character(61):
t19=(C_word)C_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1707(2,t20,(C_word)C_a_i_list(&a,2,lf[19],t19));
case C_make_character(33):
t19=(C_word)C_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1707(2,t20,(C_word)C_a_i_list(&a,2,lf[20],t19));
case C_make_character(62):
t19=(C_word)C_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1707(2,t20,(C_word)C_a_i_list(&a,2,lf[21],t19));
case C_make_character(60):
t19=(C_word)C_fixnum_plus(t17,C_fix(1));
t20=(C_word)C_i_string_ref(((C_word*)t0)[3],t19);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1605,a[2]=t14,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
switch(t20){
case C_make_character(61):
t22=t21;
f_1605(2,t22,lf[22]);
case C_make_character(33):
t22=t21;
f_1605(2,t22,lf[23]);
default:
/* pregexp.scm: 222  pregexp-error */
t22=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[24]);}
default:
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1630,a[2]=t20,a[3]=((C_word*)t0)[3],a[4]=lf[27],tmp=(C_word)a,a+=5,tmp));
t22=((C_word*)t20)[1];
f_1630(t22,t14,t17,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}}
else{
t17=t14;
f_1707(2,t17,(C_word)C_a_i_list(&a,2,lf[28],t12));}
case C_make_character(92):
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_995,a[2]=t9,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 118  pregexp-read-escaped-number */
f_1134(t11,((C_word*)t0)[3],t9,((C_word*)t0)[4]);
default:
t11=*((C_word*)lf[0]+1);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t10,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t11)){
t13=t12;
f_1039(t13,t11);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t10))){
t13=t12;
f_1039(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(t10,C_make_character(35));
t14=t12;
f_1039(t14,(C_word)C_i_not(t13));}}}}}}

/* k1037 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_1039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t2);
/* pregexp.scm: 130  pregexp-wrap-quantifier-if-any */
f_1779(((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=lf[35],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1055(t5,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}

/* loop in k1037 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_1055(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1055,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[34],t2));}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_eqp(t5,C_make_character(10));
t8=(C_word)C_i_not(t7);
/* pregexp.scm: 136  loop */
t13=t1;
t14=t6;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t5))){
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 139  loop */
t13=t1;
t14=t6;
t15=C_SCHEME_FALSE;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t6=(C_word)C_eqp(t5,C_make_character(35));
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 141  loop */
t13=t1;
t14=t7;
t15=C_SCHEME_TRUE;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[34],t2));}}}}}

/* k993 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[95],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,lf[29],t3);
t5=(C_word)C_i_cadr(t1);
t6=t2;
f_998(2,t6,(C_word)C_a_i_list(&a,2,t4,t5));}
else{
t3=f_1230(C_a_i(&a,72),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cadr(t3);
t6=t2;
f_998(2,t6,(C_word)C_a_i_list(&a,2,t4,t5));}
else{
/* pregexp.scm: 124  pregexp-error */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[31],lf[32]);}}}

/* k996 in k993 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 117  pregexp-wrap-quantifier-if-any */
f_1779(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1630,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
switch(t5){
case C_make_character(45):
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 227  loop */
t14=t1;
t15=t6;
t16=t3;
t17=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(105):
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(C_truep(t4)?lf[25]:lf[26]);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* pregexp.scm: 228  loop */
t14=t1;
t15=t6;
t16=t8;
t17=C_SCHEME_FALSE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(120):
t6=C_mutate((C_word*)lf[0]+1,t4);
t7=(C_word)C_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 233  loop */
t14=t1;
t15=t7;
t16=t3;
t17=C_SCHEME_FALSE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(58):
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,t3,t6));
default:
/* pregexp.scm: 235  pregexp-error */
t6=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[24]);}}

/* k1603 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t3=((C_word*)t0)[2];
f_1707(2,t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k1705 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 244  pregexp-read-pattern */
f_711(t4,((C_word*)t0)[2],t3,((C_word*)t0)[3]);}

/* k1714 in k1705 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_cadr(t1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1729,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,((C_word*)t0)[3]))){
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t4);
t7=t5;
f_1729(t7,(C_word)C_eqp(t6,C_make_character(41)));}
else{
t6=t5;
f_1729(t6,C_SCHEME_FALSE);}}

/* k1727 in k1714 in k1705 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_1729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1729,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1742,a[2]=t4,a[3]=lf[17],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1742(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* pregexp.scm: 257  pregexp-error */
t2=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],lf[18]);}}

/* loop in k1727 in k1714 in k1705 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void C_fcall f_1742(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1742,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
/* pregexp.scm: 254  loop */
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* k1734 in k1727 in k1714 in k1705 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[2];
f_978(2,t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k976 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 114  pregexp-wrap-quantifier-if-any */
f_1779(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k933 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[15],t2);
t4=(C_word)C_i_cadr(t1);
t5=((C_word*)t0)[2];
f_929(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* k927 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 106  pregexp-wrap-quantifier-if-any */
f_1779(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k844 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_i_cadr(t1);
/* pregexp.scm: 96   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_802(t5,((C_word*)t0)[2],t3,t4);}

/* k841 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_843,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[9],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k818 in loop in k742 in loop in pregexp-read-pattern in k676 */
static void f_820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_820,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[9],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k756 in k742 in loop in pregexp-read-pattern in k676 */
static void f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_i_cadr(t1);
/* pregexp.scm: 84   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_734(t5,((C_word*)t0)[2],t3,t4);}

/* k753 in k742 in loop in pregexp-read-pattern in k676 */
static void f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_755,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[10],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* pregexp-error in k676 */
static void f_705(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_705r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_705r(t0,t1,t2);}}

static void f_705r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[5]+1),lf[6],t2);}

/* pregexp-reverse! in k676 */
static void C_fcall f_681(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_681,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_687,a[2]=lf[2],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_687(t2,C_SCHEME_END_OF_LIST));}

/* loop in pregexp-reverse! in k676 */
static C_word C_fcall f_687(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_set_cdr(t1,t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}
/* end of file */
