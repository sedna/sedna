/* Generated from utils.scm by the Chicken compiler
   2005-09-10 23:52
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file utils.c -explicit-use
   unit: utils
*/

#include "chicken.h"

C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[125];


C_externexport void C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_245(C_word c,C_word t0,C_word t1) C_noret;
static void f_248(C_word c,C_word t0,C_word t1) C_noret;
static void f_251(C_word c,C_word t0,C_word t1) C_noret;
static void f_1056(C_word c,C_word t0,C_word t1) C_noret;
static void f_288(C_word c,C_word t0,C_word t1) C_noret;
static void f_303(C_word c,C_word t0,C_word t1) C_noret;
static void f_306(C_word c,C_word t0,C_word t1) C_noret;
static void f_522(C_word c,C_word t0,C_word t1) C_noret;
static void f_1052(C_word c,C_word t0,C_word t1) C_noret;
static void f_525(C_word c,C_word t0,C_word t1) C_noret;
static void f_528(C_word c,C_word t0,C_word t1) C_noret;
static void f_531(C_word c,C_word t0,C_word t1) C_noret;
static void f_1022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1028(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1032(C_word c,C_word t0,C_word t1) C_noret;
static void f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1004(C_word t0,C_word t1) C_noret;
static void f_1008(C_word c,C_word t0,C_word t1) C_noret;
static void f_1017(C_word c,C_word t0,C_word t1) C_noret;
static void f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_920(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_920r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_924(C_word c,C_word t0,C_word t1) C_noret;
static void f_877(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_877r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_881(C_word c,C_word t0,C_word t1) C_noret;
static void f_887(C_word c,C_word t0,C_word t1) C_noret;
static void f_895(C_word c,C_word t0,C_word t1) C_noret;
static void f_832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_857(C_word c,C_word t0,C_word t1) C_noret;
static void f_871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_850(C_word c,C_word t0,C_word t1) C_noret;
static void f_796(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_796r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_803(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_808(C_word t0,C_word t1) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static void f_821(C_word c,C_word t0,C_word t1) C_noret;
static void f_731(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_731r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_735(C_word c,C_word t0,C_word t1) C_noret;
static void f_788(C_word c,C_word t0,C_word t1) C_noret;
static void f_738(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_749(C_word t0,C_word t1) C_noret;
static void f_779(C_word c,C_word t0,C_word t1) C_noret;
static void f_775(C_word c,C_word t0,C_word t1) C_noret;
static void f_756(C_word c,C_word t0,C_word t1) C_noret;
static void f_762(C_word c,C_word t0,C_word t1) C_noret;
static void f_770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_719(C_word c,C_word t0,C_word t1) C_noret;
static void f_695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_701(C_word c,C_word t0,C_word t1) C_noret;
static void f_677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_683(C_word c,C_word t0,C_word t1) C_noret;
static void f_659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_665(C_word c,C_word t0,C_word t1) C_noret;
static void f_641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_647(C_word c,C_word t0,C_word t1) C_noret;
static void f_626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_632(C_word c,C_word t0,C_word t1) C_noret;
static void f_611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_617(C_word c,C_word t0,C_word t1) C_noret;
static void f_596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_602(C_word c,C_word t0,C_word t1) C_noret;
static void f_532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_548(C_word c,C_word t0,C_word t1) C_noret;
static void f_573(C_word c,C_word t0,C_word t1) C_noret;
static void f_476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_476r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_484(C_word c,C_word t0,C_word t1) C_noret;
static void f_500(C_word c,C_word t0,C_word t1) C_noret;
static void f_490(C_word c,C_word t0,C_word t1) C_noret;
static void f_375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_375r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_379(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_385(C_word t0,C_word t1) C_noret;
static void f_398(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_405(C_word t0,C_word t1) C_noret;
static void C_fcall f_338(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_347(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_318(C_word t0,C_word t1) C_noret;
static void f_361(C_word c,C_word t0,C_word t1) C_noret;
static void f_365(C_word c,C_word t0,C_word t1) C_noret;
static void f_289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_300(C_word c,C_word t0,C_word t1) C_noret;
static void f_271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_278(C_word c,C_word t0,C_word t1) C_noret;
static void f_284(C_word c,C_word t0,C_word t1) C_noret;
static void f_253(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_253r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_257(C_word c,C_word t0,C_word t1) C_noret;
static void f_260(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_1028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1028(t0,t1,t2);}

static void C_fcall trf_1004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1004(t0,t1);}

static void C_fcall trf_808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_808(t0,t1);}

static void C_fcall trf_749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_749(t0,t1);}

static void C_fcall trf_385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_385(t0,t1);}

static void C_fcall trf_405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_405(t0,t1);}

static void C_fcall trf_338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_338(t0,t1,t2);}

static void C_fcall trf_347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_347(t0,t1,t2);}

static void C_fcall trf_318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_318(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(432)){
C_save(t1);
C_rereclaim2(432*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,125);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"sprintf");
lf[3]=C_h_intern(&lf[3],6,"system");
lf[4]=C_h_intern(&lf[4],7,"system*");
lf[5]=C_h_intern(&lf[5],9,"\003syserror");
lf[6]=C_static_string(C_heaptop,51,"shell invocation failed with non-zero return status");
lf[7]=C_static_lambda_info(C_heaptop,23,"(system* fstr4 . args5)");
lf[8]=C_h_intern(&lf[8],12,"file-exists\077");
lf[9]=C_h_intern(&lf[9],11,"delete-file");
lf[10]=C_h_intern(&lf[10],12,"delete-file*");
lf[11]=C_static_lambda_info(C_heaptop,21,"(delete-file* file10)");
lf[12]=C_h_intern(&lf[12],12,"string-match");
lf[13]=C_h_intern(&lf[13],18,"absolute-pathname\077");
lf[14]=C_static_lambda_info(C_heaptop,25,"(absolute-pathname\077 pn13)");
lf[15]=C_h_intern(&lf[15],13,"string-append");
lf[16]=C_h_intern(&lf[16],13,"make-pathname");
lf[17]=C_static_string(C_heaptop,0,"");
lf[18]=C_h_intern(&lf[18],13,"\003syssubstring");
lf[19]=C_h_intern(&lf[19],28,"pathname-directory-separator");
lf[20]=C_static_lambda_info(C_heaptop,13,"(loop strs26)");
lf[21]=C_static_lambda_info(C_heaptop,18,"(conc-dirs dirs24)");
lf[22]=C_static_string(C_heaptop,0,"");
lf[23]=C_static_string(C_heaptop,0,"");
lf[24]=C_h_intern(&lf[24],28,"pathname-extension-separator");
lf[25]=C_static_string(C_heaptop,0,"");
lf[26]=C_static_string(C_heaptop,0,"");
lf[27]=C_static_string(C_heaptop,0,"");
lf[28]=C_static_lambda_info(C_heaptop,37,"(_make-pathname dir29 file30 . ext31)");
lf[29]=C_h_intern(&lf[29],22,"make-absolute-pathname");
lf[30]=C_h_intern(&lf[30],17,"\003sysstring-append");
lf[31]=C_static_string(C_heaptop,0,"");
lf[32]=C_static_lambda_info(C_heaptop,45,"(make-absolute-pathname dir43 file44 . ext45)");
lf[33]=C_h_intern(&lf[33],18,"decompose-pathname");
lf[34]=C_h_intern(&lf[34],13,"string-search");
lf[35]=C_static_lambda_info(C_heaptop,25,"(decompose-pathname pn59)");
lf[36]=C_h_intern(&lf[36],18,"pathname-directory");
lf[37]=C_static_lambda_info(C_heaptop,6,"(a601)");
lf[38]=C_static_lambda_info(C_heaptop,31,"(a607 dir6568 file6669 ext6770)");
lf[39]=C_static_lambda_info(C_heaptop,25,"(pathname-directory pn64)");
lf[40]=C_h_intern(&lf[40],13,"pathname-file");
lf[41]=C_static_lambda_info(C_heaptop,6,"(a616)");
lf[42]=C_static_lambda_info(C_heaptop,31,"(a622 dir7578 file7679 ext7780)");
lf[43]=C_static_lambda_info(C_heaptop,20,"(pathname-file pn74)");
lf[44]=C_h_intern(&lf[44],18,"pathname-extension");
lf[45]=C_static_lambda_info(C_heaptop,6,"(a631)");
lf[46]=C_static_lambda_info(C_heaptop,31,"(a637 dir8588 file8689 ext8790)");
lf[47]=C_static_lambda_info(C_heaptop,25,"(pathname-extension pn84)");
lf[48]=C_h_intern(&lf[48],24,"pathname-strip-directory");
lf[49]=C_static_lambda_info(C_heaptop,6,"(a646)");
lf[50]=C_static_lambda_info(C_heaptop,32,"(a652 dir9598 file9699 ext97100)");
lf[51]=C_static_lambda_info(C_heaptop,31,"(pathname-strip-directory pn94)");
lf[52]=C_h_intern(&lf[52],24,"pathname-strip-extension");
lf[53]=C_static_lambda_info(C_heaptop,6,"(a664)");
lf[54]=C_static_lambda_info(C_heaptop,37,"(a670 dir105108 file106109 ext107110)");
lf[55]=C_static_lambda_info(C_heaptop,32,"(pathname-strip-extension pn104)");
lf[56]=C_h_intern(&lf[56],26,"pathname-replace-directory");
lf[57]=C_static_lambda_info(C_heaptop,6,"(a682)");
lf[58]=C_static_lambda_info(C_heaptop,35,"(a688 _116119 file117120 ext118121)");
lf[59]=C_static_lambda_info(C_heaptop,41,"(pathname-replace-directory pn114 dir115)");
lf[60]=C_h_intern(&lf[60],21,"pathname-replace-file");
lf[61]=C_static_lambda_info(C_heaptop,6,"(a700)");
lf[62]=C_static_lambda_info(C_heaptop,34,"(a706 dir127130 _128131 ext129132)");
lf[63]=C_static_lambda_info(C_heaptop,37,"(pathname-replace-file pn125 file126)");
lf[64]=C_h_intern(&lf[64],26,"pathname-replace-extension");
lf[65]=C_static_lambda_info(C_heaptop,6,"(a718)");
lf[66]=C_static_lambda_info(C_heaptop,35,"(a724 dir138141 file139142 _140143)");
lf[67]=C_static_lambda_info(C_heaptop,41,"(pathname-replace-extension pn136 ext137)");
lf[68]=C_h_intern(&lf[68],6,"getenv");
lf[69]=C_h_intern(&lf[69],21,"call-with-output-file");
lf[70]=C_h_intern(&lf[70],21,"create-temporary-file");
lf[71]=C_static_string(C_heaptop,3,"tmp");
lf[72]=C_static_lambda_info(C_heaptop,11,"(a769 p168)");
lf[73]=C_static_string(C_heaptop,1,"t");
lf[74]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[75]=C_static_string(C_heaptop,3,"TMP");
lf[76]=C_static_string(C_heaptop,4,"TEMP");
lf[77]=C_static_string(C_heaptop,6,"TMPDIR");
lf[78]=C_static_lambda_info(C_heaptop,32,"(create-temporary-file . ext158)");
lf[79]=C_h_intern(&lf[79],9,"read-line");
lf[80]=C_h_intern(&lf[80],13,"for-each-line");
lf[81]=C_h_intern(&lf[81],18,"\003sysstandard-input");
lf[82]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[83]=C_h_intern(&lf[83],14,"\003syscheck-port");
lf[84]=C_static_lambda_info(C_heaptop,33,"(for-each-line proc172 . port173)");
lf[85]=C_h_intern(&lf[85],18,"for-each-argv-line");
lf[86]=C_static_string(C_heaptop,1,"-");
lf[87]=C_static_lambda_info(C_heaptop,6,"(a849)");
lf[88]=C_h_intern(&lf[88],20,"with-input-from-file");
lf[89]=C_static_lambda_info(C_heaptop,13,"(a870 arg185)");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],22,"command-line-arguments");
lf[92]=C_static_lambda_info(C_heaptop,29,"(for-each-argv-line thunk180)");
lf[93]=C_h_intern(&lf[93],8,"read-all");
lf[94]=C_h_intern(&lf[94],11,"read-string");
lf[95]=C_static_lambda_info(C_heaptop,6,"(a894)");
lf[96]=C_h_intern(&lf[96],5,"port\077");
lf[97]=C_static_lambda_info(C_heaptop,20,"(read-all . file187)");
lf[98]=C_h_intern(&lf[98],6,"shift!");
lf[99]=C_static_lambda_info(C_heaptop,25,"(shift! lst193 . g192194)");
lf[100]=C_h_intern(&lf[100],8,"unshift!");
lf[101]=C_static_lambda_info(C_heaptop,22,"(unshift! x203 lst204)");
lf[102]=C_h_intern(&lf[102],13,"port-for-each");
lf[103]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[104]=C_static_lambda_info(C_heaptop,30,"(port-for-each fn208 thunk209)");
lf[105]=C_h_intern(&lf[105],7,"reverse");
lf[106]=C_h_intern(&lf[106],8,"port-map");
lf[107]=C_static_lambda_info(C_heaptop,12,"(loop xs218)");
lf[108]=C_static_lambda_info(C_heaptop,25,"(port-map fn215 thunk216)");
lf[109]=C_static_string(C_heaptop,5,"^(.*[");
lf[110]=C_static_string(C_heaptop,6,"])\077((\134");
lf[111]=C_static_string(C_heaptop,4,")\077[^");
lf[112]=C_static_string(C_heaptop,4,"]+)$");
lf[113]=C_static_string(C_heaptop,5,"^(.*[");
lf[114]=C_static_string(C_heaptop,6,"])\077([^");
lf[115]=C_static_string(C_heaptop,5,"]+)(\134");
lf[116]=C_static_string(C_heaptop,3,"([^");
lf[117]=C_static_string(C_heaptop,5,"]+))$");
lf[118]=C_static_string(C_heaptop,3,"\134/\134");
lf[119]=C_h_intern(&lf[119],6,"string");
lf[120]=C_static_string(C_heaptop,16,"([A-Za-z]:)\077[\134/\134");
lf[121]=C_static_string(C_heaptop,3,"].*");
lf[122]=C_h_intern(&lf[122],17,"register-feature!");
lf[123]=C_h_intern(&lf[123],5,"utils");
lf[124]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,125);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_245,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k243 */
static void f_245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_248,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k246 in k243 */
static void f_248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 64   register-feature! */
t3=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[123]);}

/* k249 in k246 in k243 */
static void f_251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_251,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_253,a[2]=t2,a[3]=t3,a[4]=lf[7],tmp=(C_word)a,a+=5,tmp));
t5=*((C_word*)lf[8]+1);
t6=*((C_word*)lf[9]+1);
t7=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_271,a[2]=t5,a[3]=t6,a[4]=lf[11],tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1056,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 91   string */
t10=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,*((C_word*)lf[19]+1));}

/* k1054 in k249 in k246 in k243 */
static void f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 91   string-append */
t2=*((C_word*)lf[15]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[120],t1,lf[121]);}

/* k286 in k249 in k246 in k243 */
static void f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_288,2,t0,t1);}
t2=*((C_word*)lf[12]+1);
t3=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_289,a[2]=t1,a[3]=t2,a[4]=lf[14],tmp=(C_word)a,a+=5,tmp));
t4=*((C_word*)lf[15]+1);
t5=*((C_word*)lf[13]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 99   string */
t7=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[19]+1));}

/* k301 in k286 in k249 in k246 in k243 */
static void f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 100  string */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[24]+1));}

/* k304 in k301 in k286 in k249 in k246 in k243 */
static void f_306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[21],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_375,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=lf[28],tmp=(C_word)a,a+=6,tmp);
t4=C_mutate((C_word*)lf[16]+1,t3);
t5=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_476,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=lf[32],tmp=(C_word)a,a+=7,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_522,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 148  string */
t7=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[24]+1));}

/* k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_525,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 149  string */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[19]+1));}

/* k1050 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 149  ##sys#string-append */
t2=*((C_word*)lf[30]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[118],t1);}

/* k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_528,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 150  string-append */
t3=*((C_word*)lf[15]+1);
((C_proc12)C_retrieve_proc(t3))(12,t3,t2,lf[113],t1,lf[114],t1,lf[115],((C_word*)t0)[2],lf[116],t1,((C_word*)t0)[2],lf[117]);}

/* k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  string-append */
t3=*((C_word*)lf[15]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[109],((C_word*)t0)[3],lf[110],((C_word*)t0)[2],lf[111],((C_word*)t0)[3],lf[112]);}

/* k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_531,2,t0,t1);}
t2=*((C_word*)lf[12]+1);
t3=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_532,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[35],tmp=(C_word)a,a+=5,tmp));
t4=*((C_word*)lf[33]+1);
t5=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_596,a[2]=t4,a[3]=lf[39],tmp=(C_word)a,a+=4,tmp));
t6=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_611,a[2]=t4,a[3]=lf[43],tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_626,a[2]=t4,a[3]=lf[47],tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_641,a[2]=t4,a[3]=lf[51],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=t4,a[3]=lf[55],tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_677,a[2]=t4,a[3]=lf[59],tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t4,a[3]=lf[63],tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_713,a[2]=t4,a[3]=lf[67],tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[68]+1);
t14=*((C_word*)lf[16]+1);
t15=*((C_word*)lf[8]+1);
t16=*((C_word*)lf[69]+1);
t17=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_731,a[2]=t13,a[3]=t14,a[4]=t15,a[5]=t16,a[6]=lf[78],tmp=(C_word)a,a+=7,tmp));
t18=*((C_word*)lf[79]+1);
t19=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_796,a[2]=t18,a[3]=lf[84],tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_832,a[2]=lf[92],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=lf[97],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_920,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=lf[101],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[105]+1);
t26=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=t25,a[3]=lf[108],tmp=(C_word)a,a+=4,tmp));
t27=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,C_SCHEME_UNDEFINED);}

/* port-map in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_1022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1022,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1028,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=lf[107],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1028(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_1028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1028,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 287  thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1030 in loop in port-map in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
/* utils.scm: 289  reverse */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* utils.scm: 290  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1028(t4,((C_word*)t0)[4],t3);}}

/* port-for-each in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_998,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1004,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=lf[103],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1004(t7,t1);}

/* loop in port-for-each in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_1004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1004,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 278  thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1006 in loop in port-for-each in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}}

/* k1015 in k1006 in loop in port-for-each in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 281  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1004(t2,((C_word*)t0)[2]);}

/* unshift! in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_974,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_pair_2(t3,lf[100]);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=(C_word)C_i_setslot(t3,C_fix(0),t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}

/* shift! in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_920(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_920r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_920r(t0,t1,t2,t3);}}

static void f_920r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_924,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_924(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_924(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k922 in shift! in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_check_pair_2(((C_word*)t0)[3],lf[98]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t5);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}}

/* read-all in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_877r(t0,t1,t2);}}

static void f_877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_881(2,t4,*((C_word*)lf[81]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_881(2,t5,(C_word)C_i_car(t2));}
else{
/* utils.scm: 248  ##sys#error */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k879 in read-all in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_887,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 249  port? */
t3=*((C_word*)lf[96]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k885 in k879 in read-all in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 250  read-string */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=lf[95],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 251  with-input-from-file */
t3=*((C_word*)lf[88]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a894 in k885 in k879 in read-all in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
/* read-string */
t2=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* for-each-argv-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_832,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_857,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 237  command-line-arguments */
t4=*((C_word*)lf[91]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k855 in for-each-argv-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 240  for-each-line */
t2=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[2],a[3]=lf[89],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a870 in k855 in for-each-argv-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_871,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[86]))){
/* utils.scm: 235  for-each-line */
t4=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_850,a[2]=t3,a[3]=lf[87],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 236  with-input-from-file */
t5=*((C_word*)lf[88]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a849 in a870 in k855 in for-each-argv-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_850,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_796(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_796r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_796r(t0,t1,t2,t3);}}

static void f_796r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[81]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_803,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 222  ##sys#check-port */
t7=*((C_word*)lf[83]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t5,lf[80]);}

/* k801 in for-each-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=lf[82],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_808(t5,((C_word*)t0)[2]);}

/* loop in k801 in for-each-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_808,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 224  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k810 in loop in k801 in for-each-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_821,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 226  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k819 in k810 in loop in k801 in for-each-line in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 227  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_808(t2,((C_word*)t0)[2]);}

/* create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_731(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_731r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_731r(t0,t1,t2);}}

static void f_731r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_735,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 205  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[77]);}

/* k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_738(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_788,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 205  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[76]);}}

/* k786 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_738(2,t2,t1);}
else{
/* utils.scm: 205  getenv */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[75]);}}

/* k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_738,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[71]);
t4=(C_word)C_i_check_string_2(t3,lf[70]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_749,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=lf[74],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_749(t8,((C_word*)t0)[2]);}

/* loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_749,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 210  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k777 in loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  ##sys#string-append */
t2=*((C_word*)lf[30]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[73],t1);}

/* k773 in loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k754 in loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 211  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k760 in k754 in loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 212  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_749(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[3],a[3]=lf[72],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a769 in k760 in k754 in loop in k736 in k733 in create-temporary-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_770,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_713,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_719,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[65],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_725,a[2]=t3,a[3]=lf[66],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a724 in pathname-replace-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_725,5,t0,t1,t2,t3,t4);}
/* utils.scm: 197  make-pathname */
t5=*((C_word*)lf[16]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a718 in pathname-replace-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
/* utils.scm: 196  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_695,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_701,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[61],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_707,a[2]=t3,a[3]=lf[62],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a706 in pathname-replace-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_707,5,t0,t1,t2,t3,t4);}
/* utils.scm: 193  make-pathname */
t5=*((C_word*)lf[16]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a700 in pathname-replace-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_701,2,t0,t1);}
/* utils.scm: 192  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_677,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_683,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[57],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_689,a[2]=t3,a[3]=lf[58],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a688 in pathname-replace-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_689,5,t0,t1,t2,t3,t4);}
/* utils.scm: 189  make-pathname */
t5=*((C_word*)lf[16]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a682 in pathname-replace-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_683,2,t0,t1);}
/* utils.scm: 188  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_665,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[53],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a670 in pathname-strip-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_671,5,t0,t1,t2,t3,t4);}
/* utils.scm: 185  make-pathname */
t5=*((C_word*)lf[16]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}

/* a664 in pathname-strip-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_665,2,t0,t1);}
/* utils.scm: 184  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_641,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_647,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[49],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_653,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a652 in pathname-strip-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_653,5,t0,t1,t2,t3,t4);}
/* utils.scm: 181  make-pathname */
t5=*((C_word*)lf[16]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a646 in pathname-strip-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_647,2,t0,t1);}
/* utils.scm: 180  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_626,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_632,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[45],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_638,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a637 in pathname-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_638,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a631 in pathname-extension in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_632,2,t0,t1);}
/* utils.scm: 176  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_617,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[41],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=lf[42],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a622 in pathname-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_623,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a616 in pathname-file in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_617,2,t0,t1);}
/* utils.scm: 172  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_596,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_602,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[37],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_608,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a607 in pathname-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_608,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a601 in pathname-directory in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_602,2,t0,t1);}
/* utils.scm: 168  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_532,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[33]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
/* utils.scm: 156  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_548,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 157  string-search */
t7=*((C_word*)lf[34]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k546 in decompose-pathname in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_548,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_caddr(t1);
t4=(C_word)C_i_cddddr(t1);
t5=(C_word)C_i_car(t4);
/* utils.scm: 159  values */
C_values(5,0,((C_word*)t0)[4],t2,t3,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 160  string-search */
t3=*((C_word*)lf[34]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k571 in k546 in decompose-pathname in k529 in k526 in k523 in k520 in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_caddr(t1);
/* utils.scm: 162  values */
C_values(5,0,((C_word*)t0)[3],t2,t3,C_SCHEME_FALSE);}
else{
/* utils.scm: 163  values */
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_476r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_476r(t0,t1,t2,t3,t4);}}

static void f_476r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_not(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_nullp(t2));
if(C_truep(t7)){
t8=t5;
f_484(2,t8,lf[31]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=t5;
f_484(2,t8,t2);}
else{
/* utils.scm: 139  conc-dirs */
t8=((C_word*)t0)[2];
f_338(t8,t5,t2);}}}

/* k482 in make-absolute-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_500,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 141  absolute-pathname? */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k498 in k482 in make-absolute-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_490(2,t2,((C_word*)t0)[3]);}
else{
/* utils.scm: 142  ##sys#string-append */
t2=*((C_word*)lf[30]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k488 in k482 in make-absolute-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_375r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_375r(t0,t1,t2,t3,t4);}}

static void f_375r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_379,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_not(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_nullp(t2));
if(C_truep(t7)){
t8=t5;
f_379(2,t8,lf[27]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 115  conc-dirs */
t9=((C_word*)t0)[2];
f_338(t9,t5,t8);}
else{
/* utils.scm: 116  conc-dirs */
t8=((C_word*)t0)[2];
f_338(t8,t5,t2);}}}

/* k377 in _make-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:lf[22]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_385,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t5=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t6=t4;
f_385(t6,(C_truep(t5)?t5:lf[25]));}
else{
t5=t4;
f_385(t5,lf[26]);}}

/* k383 in k377 in _make-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_385,NULL,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[16]);
t3=(C_word)C_i_check_string_2(t1,lf[16]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_398,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[6]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_eqp(*((C_word*)lf[19]+1),(C_word)C_subchar(((C_word*)t0)[6],C_fix(0))):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_block_size(((C_word*)t0)[6]);
/* utils.scm: 125  ##sys#substring */
t9=*((C_word*)lf[18]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,((C_word*)t0)[6],C_fix(1),t8);}
else{
t8=t4;
f_398(2,t8,((C_word*)t0)[6]);}}

/* k396 in k383 in k377 in _make-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_405,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),*((C_word*)lf[24]+1));
t5=t2;
f_405(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_405(t4,C_SCHEME_FALSE);}}

/* k403 in k396 in k383 in k377 in _make-pathname in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?((C_word*)t0)[7]:lf[23]);
/* utils.scm: 121  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* conc-dirs in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_338,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[16]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_347,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[20],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_347(t7,t1,t2);}

/* loop in conc-dirs in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_347,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[17]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_318,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t7=(C_word)C_fixnum_difference(t5,C_fix(1));
t8=(C_word)C_subchar(t4,t7);
t9=t6;
f_318(t9,(C_word)C_eqp(*((C_word*)lf[19]+1),t8));}
else{
t7=t6;
f_318(t7,C_SCHEME_FALSE);}}}

/* k316 in loop in conc-dirs in k304 in k301 in k286 in k249 in k246 in k243 */
static void C_fcall f_318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* utils.scm: 105  ##sys#substring */
t3=*((C_word*)lf[18]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_361(2,t2,((C_word*)t0)[2]);}}

/* k359 in loop in conc-dirs in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* utils.scm: 112  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_347(t4,t2,t3);}

/* k363 in k359 in loop in conc-dirs in k304 in k301 in k286 in k249 in k246 in k243 */
static void f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* absolute-pathname? in k286 in k249 in k246 in k243 */
static void f_289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_289,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[13]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 95   string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k298 in absolute-pathname? in k286 in k249 in k246 in k243 */
static void f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* delete-file* in k249 in k246 in k243 */
static void f_271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_278,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 85   file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k276 in delete-file* in k249 in k246 in k243 */
static void f_278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_278,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_284,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 85   delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k282 in k276 in delete-file* in k249 in k246 in k243 */
static void f_284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k249 in k246 in k243 */
static void f_253(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_253r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_253r(t0,t1,t2,t3);}}

static void f_253r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_257,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k255 in system* in k249 in k246 in k243 */
static void f_257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_260,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 74   system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k258 in k255 in system* in k249 in k246 in k243 */
static void f_260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 76   ##sys#error */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[6],((C_word*)t0)[2],t1);}}
/* end of file */
