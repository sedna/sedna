/* Generated from tcp.scm by the Chicken compiler
   2005-08-24 19:36
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file tcp.c -explicit-use
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# include <winsock2.h>
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# define SD_RECEIVE      0
# define SD_SEND         1
# define closesocket     close
# define INVALID_SOCKET  -1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[117];


/* from k1408 */
static C_word C_fcall stub280(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub280(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k1397 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub276(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub276(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_return:
#undef return

return C_r;}

/* from k831 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_return:
#undef return

return C_r;}

/* from k742 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_return:
#undef return

return C_r;}

/* from k628 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_return:
#undef return

return C_r;}

/* from k613 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_return:
#undef return

return C_r;}

/* from k606 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub113(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub113(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_return:
#undef return

return C_r;}

/* from k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub104(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub104(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(se->s_port);
C_return:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub100(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     return(1);
#endif
C_return:
#undef return

return C_r;}

/* from k568 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, &len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_return:
#undef return

return C_r;}

/* from k557 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub92(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_return:
#undef return

return C_r;}

/* from k550 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, &len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_return:
#undef return

return C_r;}

/* from k539 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub83(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub83(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_return:
#undef return

return C_r;}

/* from k529 */
static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k514 */
static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k500 */
static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k478 */
static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)send(t0,t1,t2,t3));
return C_r;}

/* from k459 */
static C_word C_fcall stub39(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub39(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k446 */
static C_word C_fcall stub29(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub29(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k431 */
static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k417 */
static C_word C_fcall stub13(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k402 */
static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_externexport void C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_383(C_word c,C_word t0,C_word t1) C_noret;
static void f_386(C_word c,C_word t0,C_word t1) C_noret;
static void f_389(C_word c,C_word t0,C_word t1) C_noret;
static void f_576(C_word c,C_word t0,C_word t1) C_noret;
static void f_1749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1) C_noret;
static void f_1703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1730(C_word c,C_word t0,C_word t1) C_noret;
static void f_1726(C_word c,C_word t0,C_word t1) C_noret;
static void f_1716(C_word c,C_word t0,C_word t1) C_noret;
static void f_1658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1662(C_word c,C_word t0,C_word t1) C_noret;
static void f_1669(C_word c,C_word t0,C_word t1) C_noret;
static void f_1701(C_word c,C_word t0,C_word t1) C_noret;
static void f_1697(C_word c,C_word t0,C_word t1) C_noret;
static void f_1672(C_word c,C_word t0,C_word t1) C_noret;
static void f_1676(C_word c,C_word t0,C_word t1) C_noret;
static void f_1690(C_word c,C_word t0,C_word t1) C_noret;
static void f_1686(C_word c,C_word t0,C_word t1) C_noret;
static void f_1679(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1640(C_word t0,C_word t1) C_noret;
static void f_1644(C_word c,C_word t0,C_word t1) C_noret;
static void f_1647(C_word c,C_word t0,C_word t1) C_noret;
static void f_1630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1638(C_word c,C_word t0,C_word t1) C_noret;
static void f_1412(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1412r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1416(C_word c,C_word t0,C_word t1) C_noret;
static void f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1600(C_word c,C_word t0,C_word t1) C_noret;
static void f_1592(C_word c,C_word t0,C_word t1) C_noret;
static void f_1422(C_word c,C_word t0,C_word t1) C_noret;
static void f_1428(C_word c,C_word t0,C_word t1) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1) C_noret;
static void f_1589(C_word c,C_word t0,C_word t1) C_noret;
static void f_1585(C_word c,C_word t0,C_word t1) C_noret;
static void f_1454(C_word c,C_word t0,C_word t1) C_noret;
static void f_1569(C_word c,C_word t0,C_word t1) C_noret;
static void f_1457(C_word c,C_word t0,C_word t1) C_noret;
static void f_1555(C_word c,C_word t0,C_word t1) C_noret;
static void f_1566(C_word c,C_word t0,C_word t1) C_noret;
static void f_1562(C_word c,C_word t0,C_word t1) C_noret;
static void f_1460(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1517(C_word t0,C_word t1) C_noret;
static void f_1524(C_word c,C_word t0,C_word t1) C_noret;
static void f_1533(C_word c,C_word t0,C_word t1) C_noret;
static void f_1463(C_word c,C_word t0,C_word t1) C_noret;
static void f_1503(C_word c,C_word t0,C_word t1) C_noret;
static void f_1499(C_word c,C_word t0,C_word t1) C_noret;
static void f_1486(C_word c,C_word t0,C_word t1) C_noret;
static void f_1482(C_word c,C_word t0,C_word t1) C_noret;
static void f_1469(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1433(C_word t0,C_word t1) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1) C_noret;
static void f_1447(C_word c,C_word t0,C_word t1) C_noret;
static void f_1358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1377(C_word c,C_word t0,C_word t1) C_noret;
static void f_1388(C_word c,C_word t0,C_word t1) C_noret;
static void f_1384(C_word c,C_word t0,C_word t1) C_noret;
static void f_1368(C_word c,C_word t0,C_word t1) C_noret;
static void f_1298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1310(C_word t0,C_word t1) C_noret;
static void f_1346(C_word c,C_word t0,C_word t1) C_noret;
static void f_1349(C_word c,C_word t0,C_word t1) C_noret;
static void f_1332(C_word c,C_word t0,C_word t1) C_noret;
static void f_1343(C_word c,C_word t0,C_word t1) C_noret;
static void f_1339(C_word c,C_word t0,C_word t1) C_noret;
static void f_1323(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_984(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1285(C_word c,C_word t0,C_word t1) C_noret;
static void f_1296(C_word c,C_word t0,C_word t1) C_noret;
static void f_1292(C_word c,C_word t0,C_word t1) C_noret;
static void f_988(C_word c,C_word t0,C_word t1) C_noret;
static void f_991(C_word c,C_word t0,C_word t1) C_noret;
static void f_1238(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1252(C_word t0,C_word t1) C_noret;
static void f_1255(C_word c,C_word t0,C_word t1) C_noret;
static void f_1266(C_word c,C_word t0,C_word t1) C_noret;
static void f_1262(C_word c,C_word t0,C_word t1) C_noret;
static void f_1203(C_word c,C_word t0,C_word t1) C_noret;
static void f_1225(C_word c,C_word t0,C_word t1) C_noret;
static void f_1236(C_word c,C_word t0,C_word t1) C_noret;
static void f_1232(C_word c,C_word t0,C_word t1) C_noret;
static void f_1216(C_word c,C_word t0,C_word t1) C_noret;
static void f_1138(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1162(C_word t0,C_word t1) C_noret;
static void f_1190(C_word c,C_word t0,C_word t1) C_noret;
static void f_1201(C_word c,C_word t0,C_word t1) C_noret;
static void f_1197(C_word c,C_word t0,C_word t1) C_noret;
static void f_1181(C_word c,C_word t0,C_word t1) C_noret;
static void f_1184(C_word c,C_word t0,C_word t1) C_noret;
static void f_1158(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1142(C_word t0,C_word t1) C_noret;
static void f_997(C_word c,C_word t0,C_word t1) C_noret;
static void f_1095(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1109(C_word t0,C_word t1) C_noret;
static void f_1112(C_word c,C_word t0,C_word t1) C_noret;
static void f_1123(C_word c,C_word t0,C_word t1) C_noret;
static void f_1119(C_word c,C_word t0,C_word t1) C_noret;
static void f_1031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1040(C_word t0,C_word t1) C_noret;
static void f_1086(C_word c,C_word t0,C_word t1) C_noret;
static void f_1065(C_word c,C_word t0,C_word t1) C_noret;
static void f_1076(C_word c,C_word t0,C_word t1) C_noret;
static void f_1072(C_word c,C_word t0,C_word t1) C_noret;
static void f_1059(C_word c,C_word t0,C_word t1) C_noret;
static void f_1000(C_word c,C_word t0,C_word t1) C_noret;
static void f_1029(C_word c,C_word t0,C_word t1) C_noret;
static void f_1025(C_word c,C_word t0,C_word t1) C_noret;
static void f_951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_967(C_word c,C_word t0,C_word t1) C_noret;
static void f_978(C_word c,C_word t0,C_word t1) C_noret;
static void f_974(C_word c,C_word t0,C_word t1) C_noret;
static void f_942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_844(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_844r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_894(C_word t0,C_word t1) C_noret;
static void C_fcall f_889(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_877(C_word c,C_word t0,C_word t1) C_noret;
static void f_888(C_word c,C_word t0,C_word t1) C_noret;
static void f_884(C_word c,C_word t0,C_word t1) C_noret;
static void f_868(C_word c,C_word t0,C_word t1) C_noret;
static void f_852(C_word c,C_word t0,C_word t1) C_noret;
static void f_839(C_word c,C_word t0,C_word t1) C_noret;
static void f_759(C_word c,C_word t0,C_word t1) C_noret;
static void f_828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_827(C_word c,C_word t0,C_word t1) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static void f_823(C_word c,C_word t0,C_word t1) C_noret;
static void f_819(C_word c,C_word t0,C_word t1) C_noret;
static void f_762(C_word c,C_word t0,C_word t1) C_noret;
static void f_765(C_word c,C_word t0,C_word t1) C_noret;
static void f_800(C_word c,C_word t0,C_word t1) C_noret;
static void f_768(C_word c,C_word t0,C_word t1) C_noret;
static void f_783(C_word c,C_word t0,C_word t1) C_noret;
static void f_794(C_word c,C_word t0,C_word t1) C_noret;
static void f_790(C_word c,C_word t0,C_word t1) C_noret;
static void f_774(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_672(C_word t0,C_word t1,C_word t2) C_noret;
static void f_695(C_word c,C_word t0,C_word t1) C_noret;
static void f_699(C_word c,C_word t0,C_word t1) C_noret;
static void f_583(C_word c,C_word t0,C_word t1) C_noret;
static void f_587(C_word c,C_word t0,C_word t1) C_noret;
static void f_711(C_word c,C_word t0,C_word t1) C_noret;
static void f_722(C_word c,C_word t0,C_word t1) C_noret;
static void f_718(C_word c,C_word t0,C_word t1) C_noret;
static void f_705(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_642(C_word t0) C_noret;
static void f_648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_657(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_617(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_626(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_603(C_word t0);
static C_word C_fcall f_536(C_word t0);
static C_word C_fcall f_507(C_word t0,C_word t1);
static C_word C_fcall f_456(C_word t0);
static C_word C_fcall f_391(C_word t0,C_word t1,C_word t2);

static void C_fcall trf_1640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1640(t0,t1);}

static void C_fcall trf_1517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1517(t0,t1);}

static void C_fcall trf_1433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1433(t0,t1);}

static void C_fcall trf_1310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1310(t0,t1);}

static void C_fcall trf_984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_984(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_984(t0,t1,t2);}

static void C_fcall trf_1252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1252(t0,t1);}

static void C_fcall trf_1162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1162(t0,t1);}

static void C_fcall trf_1142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1142(t0,t1);}

static void C_fcall trf_1109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1109(t0,t1);}

static void C_fcall trf_1040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1040(t0,t1);}

static void C_fcall trf_894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_894(t0,t1);}

static void C_fcall trf_889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_889(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_889(t0,t1,t2);}

static void C_fcall trf_846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_846(t0,t1,t2,t3);}

static void C_fcall trf_663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_663(t0,t1,t2,t3);}

static void C_fcall trf_672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_672(t0,t1,t2);}

static void C_fcall trf_642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_642(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_642(t0);}

static void C_fcall trf_617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_617(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_617(t0,t1,t2,t3);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(288)){
C_save(t1);
C_rereclaim2(288*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,117);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_lambda_info(C_heaptop,22,"(##net#socket a38 a29)");
lf[5]=C_static_lambda_info(C_heaptop,13,"(##net#close)");
lf[7]=C_static_lambda_info(C_heaptop,22,"(##net#shutdown a6671)");
lf[9]=C_static_lambda_info(C_heaptop,24,"(##net#make-nonblocking)");
lf[11]=C_static_lambda_info(C_heaptop,14,"(##net#select)");
lf[13]=C_h_intern(&lf[13],17,"\003sysmake-c-string");
lf[14]=C_static_lambda_info(C_heaptop,43,"(##net#gethostaddr a122127 a121128 a120129)");
lf[16]=C_h_intern(&lf[16],18,"\003syscurrent-thread");
lf[17]=C_static_lambda_info(C_heaptop,6,"(a656)");
lf[18]=C_h_intern(&lf[18],12,"\003sysschedule");
lf[19]=C_static_lambda_info(C_heaptop,16,"(a647 return132)");
lf[20]=C_static_lambda_info(C_heaptop,7,"(yield)");
lf[21]=C_h_intern(&lf[21],9,"substring");
lf[23]=C_h_intern(&lf[23],15,"\003syssignal-hook");
lf[24]=C_h_intern(&lf[24],14,"\000network-error");
lf[25]=C_h_intern(&lf[25],11,"tcp-connect");
lf[26]=C_h_intern(&lf[26],17,"\003sysstring-append");
lf[27]=C_static_string(C_heaptop,36,"can not compute port from service - ");
lf[28]=C_h_intern(&lf[28],17,"\003syspeek-c-string");
lf[29]=C_h_intern(&lf[29],16,"\003sysupdate-errno");
lf[30]=C_static_lambda_info(C_heaptop,11,"(loop i140)");
lf[31]=C_static_lambda_info(C_heaptop,35,"(##net#parse-host host136 proto137)");
lf[32]=C_h_intern(&lf[32],10,"tcp-listen");
lf[33]=C_static_string(C_heaptop,25,"can not bind to socket - ");
lf[34]=C_static_string(C_heaptop,34,"getting listener host IP failed - ");
lf[35]=C_h_intern(&lf[35],11,"make-string");
lf[36]=C_static_string(C_heaptop,32,"error while setting up socket - ");
lf[37]=C_static_lambda_info(C_heaptop,15,"(f_828 a160163)");
lf[38]=C_h_intern(&lf[38],9,"\003syserror");
lf[39]=C_static_string(C_heaptop,21,"can not create socket");
lf[40]=C_static_lambda_info(C_heaptop,6,"(a851)");
lf[41]=C_h_intern(&lf[41],12,"tcp-listener");
lf[42]=C_static_string(C_heaptop,27,"can not listen on socket - ");
lf[43]=C_static_lambda_info(C_heaptop,25,"(a857 s185187 addr186188)");
lf[44]=C_static_lambda_info(C_heaptop,22,"(body177 w183 host184)");
lf[45]=C_static_lambda_info(C_heaptop,22,"(def-host180 %w175196)");
lf[46]=C_static_lambda_info(C_heaptop,10,"(def-w179)");
lf[47]=C_static_lambda_info(C_heaptop,30,"(tcp-listen port173 . more174)");
lf[48]=C_h_intern(&lf[48],13,"tcp-listener\077");
lf[49]=C_static_lambda_info(C_heaptop,20,"(tcp-listener\077 x203)");
lf[50]=C_h_intern(&lf[50],9,"tcp-close");
lf[51]=C_static_string(C_heaptop,27,"can not close TCP socket - ");
lf[52]=C_static_lambda_info(C_heaptop,19,"(tcp-close tcpl204)");
lf[53]=C_h_intern(&lf[53],15,"make-input-port");
lf[54]=C_h_intern(&lf[54],16,"make-output-port");
lf[56]=C_static_string(C_heaptop,5,"(tcp)");
lf[57]=C_static_string(C_heaptop,5,"(tcp)");
lf[58]=C_h_intern(&lf[58],6,"socket");
lf[59]=C_h_intern(&lf[59],13,"\003sysport-data");
lf[60]=C_static_string(C_heaptop,26,"can not write to socket - ");
lf[61]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[62]=C_static_lambda_info(C_heaptop,12,"(a1030 s241)");
lf[63]=C_static_string(C_heaptop,35,"can not close socket output port - ");
lf[64]=C_static_lambda_info(C_heaptop,7,"(a1094)");
lf[65]=C_h_intern(&lf[65],25,"\003systhread-block-for-i/o!");
lf[66]=C_static_string(C_heaptop,27,"can not read from socket - ");
lf[67]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[68]=C_static_lambda_info(C_heaptop,7,"(a1137)");
lf[69]=C_static_string(C_heaptop,33,"can not check socket for input - ");
lf[70]=C_static_lambda_info(C_heaptop,7,"(a1202)");
lf[71]=C_static_string(C_heaptop,34,"can not close socket input port - ");
lf[72]=C_static_lambda_info(C_heaptop,7,"(a1237)");
lf[73]=C_static_string(C_heaptop,27,"can not create TCP ports - ");
lf[74]=C_static_lambda_info(C_heaptop,22,"(##net#io-ports fd212)");
lf[75]=C_h_intern(&lf[75],10,"tcp-accept");
lf[76]=C_static_string(C_heaptop,33,"could not accept from listener - ");
lf[77]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[78]=C_static_lambda_info(C_heaptop,20,"(tcp-accept tcpl260)");
lf[79]=C_h_intern(&lf[79],17,"tcp-accept-ready\077");
lf[80]=C_static_string(C_heaptop,33,"can not check socket for input - ");
lf[81]=C_static_lambda_info(C_heaptop,27,"(tcp-accept-ready\077 tcpl270)");
lf[82]=C_static_string(C_heaptop,28,"can not connect to socket - ");
lf[83]=C_static_lambda_info(C_heaptop,6,"(fail)");
lf[84]=C_static_string(C_heaptop,22,"getsockopt() failed - ");
lf[85]=C_static_string(C_heaptop,24,"can not create socket - ");
lf[86]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[87]=C_static_string(C_heaptop,17,"fcntl() failed - ");
lf[88]=C_static_string(C_heaptop,25,"can not find host address");
lf[89]=C_static_string(C_heaptop,24,"can not create socket - ");
lf[90]=C_static_string(C_heaptop,17,"no port specified");
lf[91]=C_static_string(C_heaptop,3,"tcp");
lf[92]=C_static_lambda_info(C_heaptop,7,"(a1599)");
lf[93]=C_static_lambda_info(C_heaptop,29,"(a1605 host289291 port290292)");
lf[94]=C_static_lambda_info(C_heaptop,31,"(tcp-connect host284 . more285)");
lf[95]=C_h_intern(&lf[95],20,"\003systcp-port->fileno");
lf[97]=C_static_lambda_info(C_heaptop,29,"(##sys#tcp-port->fileno p317)");
lf[98]=C_h_intern(&lf[98],11,"\000type-error");
lf[99]=C_static_string(C_heaptop,37,"bad argument type - not a TCP port - ");
lf[100]=C_h_intern(&lf[100],14,"\003syscheck-port");
lf[101]=C_static_lambda_info(C_heaptop,26,"(##sys#tcp-port-data p318)");
lf[102]=C_h_intern(&lf[102],13,"tcp-addresses");
lf[103]=C_static_string(C_heaptop,33,"can not compute remote address - ");
lf[104]=C_static_string(C_heaptop,32,"can not compute local address - ");
lf[105]=C_static_lambda_info(C_heaptop,20,"(tcp-addresses p321)");
lf[106]=C_h_intern(&lf[106],17,"tcp-listener-port");
lf[107]=C_static_string(C_heaptop,31,"can not obtain listener port - ");
lf[108]=C_static_lambda_info(C_heaptop,27,"(tcp-listener-port tcpl327)");
lf[109]=C_h_intern(&lf[109],16,"tcp-abandon-port");
lf[110]=C_static_lambda_info(C_heaptop,23,"(tcp-abandon-port p332)");
lf[111]=C_h_intern(&lf[111],19,"tcp-listener-fileno");
lf[112]=C_static_lambda_info(C_heaptop,26,"(tcp-listener-fileno l333)");
lf[113]=C_static_string(C_heaptop,26,"can not initialize Winsock");
lf[114]=C_h_intern(&lf[114],17,"register-feature!");
lf[115]=C_h_intern(&lf[115],3,"tcp");
lf[116]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,117);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k381 */
static void f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 */
static void f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[114]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[115]);}

/* k387 in k384 in k381 */
static void f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_456,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_507,a[2]=lf[7],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_536,a[2]=lf[9],tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub100(C_SCHEME_UNDEFINED))){
t7=t6;
f_576(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[24],lf[113]);}}

/* k574 in k387 in k384 in k381 */
static void f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[56],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
t2=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=lf[11],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_617,a[2]=lf[14],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_642,a[2]=lf[20],tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[21]+1);
t6=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_663,a[2]=t5,a[3]=lf[31],tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_844,a[2]=lf[47],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=lf[49],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t10=*((C_word*)lf[53]+1);
t11=*((C_word*)lf[54]+1);
t12=*((C_word*)lf[35]+1);
t13=*((C_word*)lf[21]+1);
t14=C_mutate(&lf[55],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_984,a[2]=t12,a[3]=t10,a[4]=t11,a[5]=t13,a[6]=lf[74],tmp=(C_word)a,a+=7,tmp));
t15=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=lf[81],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=lf[97],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[96],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=lf[101],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=lf[110],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k574 in k387 in k384 in k381 */
static void f_1749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1749,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[41],lf[111]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k574 in k387 in k384 in k381 */
static void f_1732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1740,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_1640(t3,t2);}

/* k1738 in tcp-abandon-port in k574 in k387 in k384 in k381 */
static void f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k574 in k387 in k384 in k381 */
static void f_1703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1703,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[41],lf[106]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=(C_word)stub92(C_SCHEME_UNDEFINED,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1726,a[2]=t4,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t9=t7;
f_1716(2,t9,C_SCHEME_UNDEFINED);}}

/* k1728 in tcp-listener-port in k574 in k387 in k384 in k381 */
static void f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[107],t1);}

/* k1724 in tcp-listener-port in k574 in k387 in k384 in k381 */
static void f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[106],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1714 in tcp-listener-port in k574 in k387 in k384 in k381 */
static void f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1658,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1662,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1669,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub87(t4,t5);
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1672(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1699 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[104],t1);}

/* k1695 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[102],t1,((C_word*)t0)[2]);}

/* k1670 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub96(t4,t5);
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k1674 in k1670 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_1679(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1690,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1688 in k1674 in k1670 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[103],t1);}

/* k1684 in k1674 in k1670 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[102],t1,((C_word*)t0)[2]);}

/* k1677 in k1674 in k1670 in k1667 in k1660 in tcp-addresses in k574 in k387 in k384 in k381 */
static void f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port-data in k574 in k387 in k384 in k381 */
static void C_fcall f_1640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1640,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[100]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1642 in ##sys#tcp-port-data in k574 in k387 in k384 in k381 */
static void f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[59]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1645 in k1642 in ##sys#tcp-port-data in k574 in k387 in k384 in k381 */
static void f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}
else{
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[98],lf[99],((C_word*)t0)[2]);}}

/* ##sys#tcp-port->fileno in k574 in k387 in k384 in k381 */
static void f_1630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1630,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1640(t3,t2);}

/* k1636 in ##sys#tcp-port->fileno in k574 in k387 in k384 in k381 */
static void f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k574 in k387 in k384 in k381 */
static void f_1412(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1412r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1412r(t0,t1,t2,t3);}}

static void f_1412r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1416(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1416(2,t7,(C_word)C_i_car(t3));}
else{
t7=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1416,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[3])[1]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t3)[1])){
t6=t5;
f_1422(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],a[3]=lf[92],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1606,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[93],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t6,t7,t8);}}

/* a1605 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1606,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a1599 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=lf[22];
f_663(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[91]);}

/* k1590 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1422(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[25],lf[90],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1422,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=f_391(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=lf[83],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1454(2,t6,C_SCHEME_UNDEFINED);}}

/* k1576 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1587 in k1576 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[89],t1);}

/* k1583 in k1576 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[25],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_617(t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1567 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1457(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[25],lf[88],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_536(((C_word*)t0)[5]);
if(C_truep(t3)){
t4=t2;
f_1460(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1553 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1564 in k1553 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k1560 in k1553 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[24],lf[25],t1);}

/* k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=(C_word)stub75(C_SCHEME_UNDEFINED,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t10)){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[5],a[5]=lf[86],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_1517(t14,t2);}
else{
t11=((C_word*)t0)[2];
f_1433(t11,t2);}}
else{
t10=t2;
f_1463(2,t10,C_SCHEME_UNDEFINED);}}

/* loop in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void C_fcall f_1517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1517,NULL,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=(C_word)stub117(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
f_1433(t6,t4);}
else{
t6=t4;
f_1524(2,t6,C_SCHEME_UNDEFINED);}}

/* k1522 in loop in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_642(t3);}}

/* k1531 in k1522 in loop in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1517(t2,((C_word*)t0)[2]);}

/* k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=(C_word)stub276(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1482,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1503,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)C_i_foreign_fixnum_argumentp(t3);
t10=(C_word)stub280(t8,t9);
t11=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_fix(0));}
else{
t6=t4;
f_1469(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1501 in k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k1497 in k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[24],lf[25],t1);}

/* k1484 in k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[84],t1);}

/* k1480 in k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[24],lf[25],t1);}

/* k1467 in k1461 in k1458 in k1455 in k1452 in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[55];
f_984(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void C_fcall f_1433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1433,NULL,2,t0,t1);}
t2=f_456(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1438 in fail in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1449 in k1438 in fail in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k1445 in k1438 in fail in k1426 in k1420 in k1414 in tcp-connect in k574 in k387 in k384 in k381 */
static void f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[25],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k574 in k387 in k384 in k381 */
static void f_1358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1358,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[41],lf[79]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_603(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1368,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1377,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1368(2,t8,C_SCHEME_UNDEFINED);}}

/* k1375 in tcp-accept-ready? in k574 in k387 in k384 in k381 */
static void f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1388,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1386 in k1375 in tcp-accept-ready? in k574 in k387 in k384 in k381 */
static void f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[80],t1);}

/* k1382 in k1375 in tcp-accept-ready? in k574 in k387 in k384 in k381 */
static void f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[79],t1,((C_word*)t0)[2]);}

/* k1366 in tcp-accept-ready? in k574 in k387 in k384 in k381 */
static void f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k574 in k387 in k384 in k381 */
static void f_1298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1298,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[41]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1310,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=lf[77],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1310(t8,t1);}

/* loop in tcp-accept in k574 in k387 in k384 in k381 */
static void C_fcall f_1310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1310,NULL,2,t0,t1);}
t2=f_603(((C_word*)t0)[4]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_word)stub29(C_SCHEME_UNDEFINED,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1323,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1323(2,t8,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1346,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[16]+1),((C_word*)t0)[4],C_SCHEME_TRUE);}}

/* k1344 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_642(t2);}

/* k1347 in k1344 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1310(t2,((C_word*)t0)[2]);}

/* k1330 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1341 in k1330 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[76],t1);}

/* k1337 in k1330 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[75],t1,((C_word*)t0)[2]);}

/* k1321 in loop in tcp-accept in k574 in k387 in k384 in k381 */
static void f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[55];
f_984(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_984(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_984,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_536(t2);
if(C_truep(t4)){
t5=t3;
f_988(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1283 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1294 in k1283 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[73],t1);}

/* k1290 in k1283 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[24],t1);}

/* k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t4,a[5]=t6,a[6]=lf[68],tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t6,a[5]=lf[70],tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1238,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t8,a[6]=lf[72],tmp=(C_word)a,a+=7,tmp);
t15=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,t12,t13,t14);}

/* a1237 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_507(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_456(((C_word*)t0)[3]);
t6=t4;
f_1252(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1252(t5,C_SCHEME_FALSE);}}}

/* k1250 in a1237 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_1252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1252,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1253 in k1250 in a1237 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1264 in k1253 in k1250 in a1237 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1260 in k1253 in k1250 in a1237 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[24],t1,((C_word*)t0)[2]);}

/* a1202 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_603(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1216,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1216(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1223 in a1202 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1234 in k1223 in a1202 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1230 in k1223 in a1202 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[24],t1,((C_word*)t0)[2]);}

/* k1214 in a1202 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1158,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1162,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=lf[67],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1162(t7,t3);}
else{
t3=t2;
f_1142(t3,C_SCHEME_UNDEFINED);}}

/* loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_1162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1162,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1024));
t7=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t8=(C_word)stub58(C_SCHEME_UNDEFINED,t4,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[16]+1),((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k1188 in loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1199 in k1188 in loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k1195 in k1188 in loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[24],t1,((C_word*)t0)[2]);}

/* k1179 in loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_642(t2);}

/* k1182 in k1179 in loop in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1162(t2,((C_word*)t0)[2]);}

/* k1156 in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
f_1142(t4,t3);}

/* k1140 in a1137 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_1142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=lf[62],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=lf[64],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}

/* a1094 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(2)))?C_SCHEME_UNDEFINED:f_507(((C_word*)t0)[3],C_fix((C_word)SD_SEND)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_456(((C_word*)t0)[3]);
t6=t4;
f_1109(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1109(t5,C_SCHEME_FALSE);}}}

/* k1107 in a1094 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_1109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1110 in k1107 in a1094 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1121 in k1110 in k1107 in a1094 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k1117 in k1110 in k1107 in a1094 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[24],t1,((C_word*)t0)[2]);}

/* a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1031,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_block_size(((C_word*)t3)[1]);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=lf[61],tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_1040(t10,t1);}

/* loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void C_fcall f_1040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1040,NULL,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)((C_word*)t0)[5])[1];
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t9=(C_word)stub46(C_SCHEME_UNDEFINED,t5,t6,t7,t8);
t10=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t10)){
t11=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1059,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_642(t12);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t9,((C_word*)((C_word*)t0)[4])[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1086,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t12=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,((C_word*)((C_word*)t0)[5])[1],t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* k1084 in loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)((C_word*)t0)[3])[1];
f_1040(t5,((C_word*)t0)[2]);}

/* k1063 in loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1074 in k1063 in loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[60],t1);}

/* k1070 in k1063 in loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[24],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1057 in loop in a1030 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1040(t2,((C_word*)t0)[2]);}

/* k998 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[56]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[57]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[58]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[58]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1029,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[59]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}

/* k1027 in k998 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(C_word)C_i_setslot(t1,C_fix(0),((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[59]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1023 in k1027 in k998 in k995 in k989 in k986 in ##net#io-ports in k574 in k387 in k384 in k381 */
static void f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),((C_word*)t0)[5]);
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* tcp-close in k574 in k387 in k384 in k381 */
static void f_951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_951,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[41]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_456(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k965 in tcp-close in k574 in k387 in k384 in k381 */
static void f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k976 in k965 in tcp-close in k574 in k387 in k384 in k381 */
static void f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k972 in k965 in tcp-close in k574 in k387 in k384 in k381 */
static void f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[50],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k574 in k387 in k384 in k381 */
static void f_942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_942,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[41]):C_SCHEME_FALSE));}

/* tcp-listen in k574 in k387 in k384 in k381 */
static void f_844(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_844r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_844r(t0,t1,t2,t3);}}

static void f_844r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_846,a[2]=t2,a[3]=lf[44],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_889,a[2]=t4,a[3]=lf[45],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_894,a[2]=t5,a[3]=lf[46],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_894(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_889(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t4;
f_846(t11,t1,t7,t9);}
else{
t11=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w179 in tcp-listen in k574 in k387 in k384 in k381 */
static void C_fcall f_894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_894,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_889(t2,t1,C_fix(10));}

/* def-host180 in tcp-listen in k574 in k387 in k384 in k381 */
static void C_fcall f_889(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_889,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_846(t3,t1,t2,C_SCHEME_FALSE);}

/* body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void C_fcall f_846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_846,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_852,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[40],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[43],tmp=(C_word)a,a+=5,tmp);
C_call_with_values(4,0,t1,t4,t5);}

/* a857 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_858,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_fixnum_argumentp(t6);
t9=(C_word)stub22(C_SCHEME_UNDEFINED,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_868,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t13=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=t10;
f_868(2,t12,C_SCHEME_UNDEFINED);}}

/* k875 in a857 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_888,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k886 in k875 in a857 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[42],t1);}

/* k882 in k875 in a857 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[32],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k866 in a857 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_868,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[41],((C_word*)t0)[2]));}

/* a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=f_391(C_fix((C_word)AF_INET),t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_759,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t10=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=t7;
f_759(2,t9,C_SCHEME_UNDEFINED);}}

/* k837 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[39]);}

/* k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=lf[37],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_828 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_828,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub161(C_SCHEME_UNDEFINED,t3));}

/* k825 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_827,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_762(2,t3,C_SCHEME_UNDEFINED);}}

/* k810 in k825 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k821 in k810 in k825 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[36],t1);}

/* k817 in k810 in k825 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[32],t1,((C_word*)t0)[2]);}

/* k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_617(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t6=t2;
f_768(2,t6,(C_word)stub149(C_SCHEME_UNDEFINED,t4,t5));}}

/* k798 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_768(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[32],lf[34],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k766 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)stub13(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t11=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_774(2,t10,C_SCHEME_UNDEFINED);}}

/* k781 in k766 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k792 in k781 in k766 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[33],t1);}

/* k788 in k781 in k766 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[32],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k772 in k766 in k763 in k760 in k757 in a851 in body177 in tcp-listen in k574 in k387 in k384 in k381 */
static void f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k574 in k387 in k384 in k381 */
static void C_fcall f_663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_663,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_672,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=lf[30],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_672(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void C_fcall f_672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_672,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_695,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_699,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_583,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
t6=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t5=t4;
f_583(2,t5,C_SCHEME_FALSE);}}

/* k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
t4=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t3=t2;
f_587(2,t3,C_SCHEME_FALSE);}}

/* k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_587,2,t0,t1);}
t2=(C_word)stub104(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_705,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_711,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_705(2,t5,C_SCHEME_UNDEFINED);}}

/* k709 in k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k720 in k709 in k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[27],t1);}

/* k716 in k709 in k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[24],lf[25],t1,((C_word*)t0)[2]);}

/* k703 in k585 in k581 in k697 in k693 in loop in ##net#parse-host in k574 in k387 in k384 in k381 */
static void f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k574 in k387 in k384 in k381 */
static void C_fcall f_642(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_642,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_648,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp);
C_call_cc(3,0,t1,t2);}

/* a647 in yield in k574 in k387 in k384 in k381 */
static void f_648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_648,3,t0,t1,t2);}
t3=*((C_word*)lf[16]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_657,a[2]=t2,a[3]=lf[17],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[18]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t1);}

/* a656 in a647 in yield in k574 in k387 in k384 in k381 */
static void f_657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_657,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k574 in k387 in k384 in k381 */
static void C_fcall f_617(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_617,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_626,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
t8=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t7=t6;
f_626(2,t7,C_SCHEME_FALSE);}}

/* k624 in ##net#gethostaddr in k574 in k387 in k384 in k381 */
static void f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub123(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select in k574 in k387 in k384 in k381 */
static C_word C_fcall f_603(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub113(C_SCHEME_UNDEFINED,t2));}

/* ##net#make-nonblocking in k387 in k384 in k381 */
static C_word C_fcall f_536(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub83(C_SCHEME_UNDEFINED,t2));}

/* ##net#shutdown in k387 in k384 in k381 */
static C_word C_fcall f_507(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub68(C_SCHEME_UNDEFINED,t3,t4));}

/* ##net#close in k387 in k384 in k381 */
static C_word C_fcall f_456(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub39(C_SCHEME_UNDEFINED,t2));}

/* ##net#socket in k387 in k384 in k381 */
static C_word C_fcall f_391(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub5(C_SCHEME_UNDEFINED,t4,t5,t6));}
/* end of file */
