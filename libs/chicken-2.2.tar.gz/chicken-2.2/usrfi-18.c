/* Generated from srfi-18.scm by the Chicken compiler
   2005-08-24 19:44
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-18.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file usrfi-18.c -explicit-use
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[103];


C_externexport void C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_227(C_word c,C_word t0,C_word t1) C_noret;
static void f_230(C_word c,C_word t0,C_word t1) C_noret;
static void f_445(C_word c,C_word t0,C_word t1) C_noret;
static void f_1437(C_word c,C_word t0,C_word t1) C_noret;
static void f_1411(C_word c,C_word t0,C_word t1) C_noret;
static void f_1421(C_word c,C_word t0,C_word t1) C_noret;
static void f_1424(C_word c,C_word t0,C_word t1) C_noret;
static void f_1427(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1406(C_word t0,C_word t1) C_noret;
static void f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1396(C_word c,C_word t0,C_word t1) C_noret;
static void f_1400(C_word c,C_word t0,C_word t1) C_noret;
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1348(C_word c,C_word t0,C_word t1) C_noret;
static void f_1304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1267(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1267r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1275(C_word c,C_word t0,C_word t1) C_noret;
static void f_1094(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1094r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1116(C_word c,C_word t0,C_word t1) C_noret;
static void f_1242(C_word c,C_word t0,C_word t1) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1) C_noret;
static void f_1202(C_word c,C_word t0,C_word t1) C_noret;
static void f_1213(C_word c,C_word t0,C_word t1) C_noret;
static void f_1131(C_word c,C_word t0,C_word t1) C_noret;
static void f_1134(C_word c,C_word t0,C_word t1) C_noret;
static void f_1234(C_word c,C_word t0,C_word t1) C_noret;
static void f_888(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_888r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_895(C_word c,C_word t0,C_word t1) C_noret;
static void f_912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_960(C_word t0,C_word t1) C_noret;
static void f_963(C_word c,C_word t0,C_word t1) C_noret;
static void f_1070(C_word c,C_word t0,C_word t1) C_noret;
static void f_1022(C_word c,C_word t0,C_word t1) C_noret;
static void f_1028(C_word c,C_word t0,C_word t1) C_noret;
static void f_1033(C_word c,C_word t0,C_word t1) C_noret;
static void f_1055(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_936(C_word t0,C_word t1) C_noret;
static void f_947(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_915(C_word t0,C_word t1) C_noret;
static void f_926(C_word c,C_word t0,C_word t1) C_noret;
static void f_867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_831(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_831r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_835(C_word c,C_word t0,C_word t1) C_noret;
static void f_825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_796(C_word c,C_word t0,C_word t1) C_noret;
static void f_801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_805(C_word c,C_word t0,C_word t1) C_noret;
static void f_811(C_word c,C_word t0,C_word t1) C_noret;
static void f_816(C_word c,C_word t0,C_word t1) C_noret;
static void f_773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_767(C_word c,C_word t0,C_word t1) C_noret;
static void f_706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_741(C_word c,C_word t0,C_word t1) C_noret;
static void f_710(C_word c,C_word t0,C_word t1) C_noret;
static void f_719(C_word c,C_word t0,C_word t1) C_noret;
static void f_590(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_590r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_594(C_word c,C_word t0,C_word t1) C_noret;
static void f_608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_612(C_word c,C_word t0,C_word t1) C_noret;
static void f_618(C_word c,C_word t0,C_word t1) C_noret;
static void f_623(C_word c,C_word t0,C_word t1) C_noret;
static void f_672(C_word c,C_word t0,C_word t1) C_noret;
static void f_653(C_word c,C_word t0,C_word t1) C_noret;
static void f_569(C_word c,C_word t0,C_word t1) C_noret;
static void f_575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_584(C_word c,C_word t0,C_word t1) C_noret;
static void f_537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_567(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_541(C_word t0,C_word t1) C_noret;
static void f_544(C_word c,C_word t0,C_word t1) C_noret;
static void f_550(C_word c,C_word t0,C_word t1) C_noret;
static void f_531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_494(C_word c,C_word t0,C_word t1) C_noret;
static void f_488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_447(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_447r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_473(C_word c,C_word t0,C_word t1) C_noret;
static void f_451(C_word c,C_word t0,C_word t1) C_noret;
static void f_456(C_word c,C_word t0,C_word t1) C_noret;
static void f_460(C_word c,C_word t0,C_word t1) C_noret;
static void f_466(C_word c,C_word t0,C_word t1) C_noret;
static void f_427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_324(C_word c,C_word t0,C_word t1) C_noret;
static void f_365(C_word c,C_word t0,C_word t1) C_noret;
static void f_361(C_word c,C_word t0,C_word t1) C_noret;
static void f_327(C_word c,C_word t0,C_word t1) C_noret;
static void f_345(C_word c,C_word t0,C_word t1) C_noret;
static void f_337(C_word c,C_word t0,C_word t1) C_noret;
static void f_302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_275(C_word c,C_word t0,C_word t1) C_noret;
static void f_287(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_232(C_word t0,C_word t1,C_word t2) C_noret;
static void f_266(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1406(t0,t1);}

static void C_fcall trf_960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_960(t0,t1);}

static void C_fcall trf_936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_936(t0,t1);}

static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_915(t0,t1);}

static void C_fcall trf_541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_541(t0,t1);}

static void C_fcall trf_232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_232(t0,t1,t2);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(903)){
C_save(t1);
C_rereclaim2(903*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,103);
lf[0]=C_h_intern(&lf[0],8,"truncate");
lf[2]=C_h_intern(&lf[2],4,"time");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_static_string(C_heaptop,24,"invalid timeout argument");
lf[6]=C_h_intern(&lf[6],12,"current-time");
lf[7]=C_h_intern(&lf[7],20,"srfi-18:current-time");
lf[8]=C_h_intern(&lf[8],13,"time->seconds");
lf[9]=C_h_intern(&lf[9],13,"seconds->time");
lf[10]=C_h_intern(&lf[10],19,"\003sysflonum-fraction");
lf[11]=C_h_intern(&lf[11],18,"\003sysexact->inexact");
lf[12]=C_h_intern(&lf[12],3,"max");
lf[13]=C_h_intern(&lf[13],5,"time\077");
lf[14]=C_h_intern(&lf[14],13,"srfi-18:time\077");
lf[15]=C_h_intern(&lf[15],5,"raise");
lf[16]=C_h_intern(&lf[16],10,"\003syssignal");
lf[17]=C_h_intern(&lf[17],23,"join-timeout-exception\077");
lf[18]=C_h_intern(&lf[18],9,"condition");
lf[19]=C_h_intern(&lf[19],22,"join-timeout-exception");
lf[20]=C_h_intern(&lf[20],26,"abandoned-mutex-exception\077");
lf[21]=C_h_intern(&lf[21],25,"abandoned-mutex-exception");
lf[22]=C_h_intern(&lf[22],28,"terminated-thread-exception\077");
lf[23]=C_h_intern(&lf[23],27,"terminated-thread-exception");
lf[24]=C_h_intern(&lf[24],19,"uncaught-exception\077");
lf[25]=C_h_intern(&lf[25],18,"uncaught-exception");
lf[26]=C_h_intern(&lf[26],25,"uncaught-exception-reason");
lf[27]=C_h_intern(&lf[27],6,"gensym");
lf[28]=C_h_intern(&lf[28],11,"make-thread");
lf[29]=C_h_intern(&lf[29],12,"\003sysschedule");
lf[30]=C_h_intern(&lf[30],16,"\003systhread-kill!");
lf[31]=C_h_intern(&lf[31],4,"dead");
lf[32]=C_h_intern(&lf[32],18,"\003syscurrent-thread");
lf[33]=C_h_intern(&lf[33],15,"\003sysmake-thread");
lf[34]=C_h_intern(&lf[34],7,"created");
lf[35]=C_h_intern(&lf[35],6,"thread");
lf[36]=C_h_intern(&lf[36],7,"thread\077");
lf[37]=C_h_intern(&lf[37],14,"current-thread");
lf[38]=C_h_intern(&lf[38],12,"thread-state");
lf[39]=C_h_intern(&lf[39],15,"thread-specific");
lf[40]=C_h_intern(&lf[40],20,"thread-specific-set!");
lf[41]=C_h_intern(&lf[41],14,"thread-quantum");
lf[42]=C_h_intern(&lf[42],19,"thread-quantum-set!");
lf[43]=C_h_intern(&lf[43],11,"thread-name");
lf[44]=C_h_intern(&lf[44],13,"thread-start!");
lf[45]=C_h_intern(&lf[45],5,"ready");
lf[46]=C_h_intern(&lf[46],22,"\003sysadd-to-ready-queue");
lf[47]=C_h_intern(&lf[47],9,"\003syserror");
lf[48]=C_static_string(C_heaptop,39,"thread can not be started a second time");
lf[49]=C_h_intern(&lf[49],13,"thread-yield!");
lf[50]=C_h_intern(&lf[50],12,"thread-join!");
lf[51]=C_h_intern(&lf[51],10,"terminated");
lf[52]=C_h_intern(&lf[52],6,"reason");
tmp=C_intern(C_heaptop,18,"uncaught-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[53]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,22,"join-timeout-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[54]=C_h_pair(C_restore,tmp);
lf[55]=C_h_intern(&lf[55],33,"\003systhread-block-for-termination!");
lf[56]=C_h_intern(&lf[56],29,"\003systhread-block-for-timeout!");
lf[57]=C_h_intern(&lf[57],17,"thread-terminate!");
tmp=C_intern(C_heaptop,27,"terminated-thread-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[58]=C_h_pair(C_restore,tmp);
lf[59]=C_h_intern(&lf[59],21,"\003sysprimordial-thread");
lf[60]=C_h_intern(&lf[60],16,"\003sysexit-handler");
lf[61]=C_h_intern(&lf[61],15,"thread-suspend!");
lf[62]=C_h_intern(&lf[62],9,"suspended");
lf[63]=C_h_intern(&lf[63],14,"thread-resume!");
lf[64]=C_h_intern(&lf[64],13,"thread-sleep!");
lf[65]=C_static_string(C_heaptop,24,"invalid timeout argument");
lf[66]=C_h_intern(&lf[66],6,"mutex\077");
lf[67]=C_h_intern(&lf[67],5,"mutex");
lf[68]=C_h_intern(&lf[68],10,"make-mutex");
lf[69]=C_h_intern(&lf[69],14,"\003sysmake-mutex");
lf[70]=C_h_intern(&lf[70],10,"mutex-name");
lf[71]=C_h_intern(&lf[71],14,"mutex-specific");
lf[72]=C_h_intern(&lf[72],19,"mutex-specific-set!");
lf[73]=C_h_intern(&lf[73],11,"mutex-state");
lf[74]=C_h_intern(&lf[74],9,"not-owned");
lf[75]=C_h_intern(&lf[75],9,"abandoned");
lf[76]=C_h_intern(&lf[76],13,"not-abandoned");
lf[77]=C_h_intern(&lf[77],11,"mutex-lock!");
lf[78]=C_h_intern(&lf[78],10,"\003sysappend");
tmp=C_intern(C_heaptop,25,"abandoned-mutex-exception");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[79]=C_h_pair(C_restore,tmp);
lf[80]=C_h_intern(&lf[80],8,"\003sysdelq");
lf[81]=C_h_intern(&lf[81],8,"sleeping");
lf[82]=C_h_intern(&lf[82],13,"mutex-unlock!");
lf[83]=C_h_intern(&lf[83],7,"blocked");
lf[84]=C_h_intern(&lf[84],23,"make-condition-variable");
lf[85]=C_h_intern(&lf[85],18,"condition-variable");
lf[86]=C_h_intern(&lf[86],19,"condition-variable\077");
lf[87]=C_h_intern(&lf[87],27,"condition-variable-specific");
lf[88]=C_h_intern(&lf[88],32,"condition-variable-specific-set!");
lf[89]=C_h_intern(&lf[89],26,"condition-variable-signal!");
lf[90]=C_h_intern(&lf[90],25,"\003systhread-basic-unblock!");
lf[91]=C_h_intern(&lf[91],29,"condition-variable-broadcast!");
lf[92]=C_h_intern(&lf[92],12,"\003sysfor-each");
lf[93]=C_h_intern(&lf[93],22,"thread-deliver-signal!");
lf[94]=C_h_intern(&lf[94],4,"msvc");
lf[95]=C_h_intern(&lf[95],20,"\003sysread-prompt-hook");
lf[96]=C_h_intern(&lf[96],25,"\003systhread-block-for-i/o!");
lf[97]=C_h_intern(&lf[97],13,"\003systty-port\077");
lf[98]=C_h_intern(&lf[98],18,"\003sysstandard-input");
lf[99]=C_h_intern(&lf[99],14,"build-platform");
lf[100]=C_h_intern(&lf[100],27,"condition-property-accessor");
lf[101]=C_h_intern(&lf[101],17,"register-feature!");
lf[102]=C_h_intern(&lf[102],7,"srfi-18");
C_register_lf(lf,103);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k225 */
static void f_227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_230,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[102]);}

/* k228 in k225 */
static void f_230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_230,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_232,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_275,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1,*((C_word*)lf[6]+1));
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_302,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_320,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_371,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1,*((C_word*)lf[13]+1));
t10=C_mutate((C_word*)lf[15]+1,*((C_word*)lf[16]+1));
t11=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_379,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_395,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_411,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_427,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,lf[25],lf[52]);}

/* k443 in k228 in k225 */
static void f_445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[72],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_445,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1,t1);
t3=*((C_word*)lf[27]+1);
t4=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_447,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_488,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_494,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_497,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_503,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_509,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_515,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_521,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_531,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[28]+1);
t14=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_569,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_590,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_743,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_773,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_792,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_825,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[27]+1);
t23=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_849,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_855,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_861,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_867,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_888,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1094,tmp=(C_word)a,a+=2,tmp));
t30=*((C_word*)lf[27]+1);
t31=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1267,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1286,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1292,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1298,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1304,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1344,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1378,tmp=(C_word)a,a+=2,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
t40=*((C_word*)lf[99]+1);
((C_proc2)(void*)(*((C_word*)t40+1)))(2,t40,t39);}

/* k1435 in k443 in k228 in k225 */
static void f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[94]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_1406(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[95]+1);
t4=*((C_word*)lf[49]+1);
t5=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t0)[2];
f_1406(t6,t5);}}

/* ##sys#read-prompt-hook in k1435 in k443 in k228 in k225 */
static void f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_1421(2,t4,t2);}
else{
t4=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[98]+1));}}

/* k1419 in ##sys#read-prompt-hook in k1435 in k443 in k228 in k225 */
static void f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1422 in k1419 in ##sys#read-prompt-hook in k1435 in k443 in k228 in k225 */
static void f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[32]+1),C_fix(0),C_SCHEME_TRUE);}

/* k1425 in k1422 in k1419 in ##sys#read-prompt-hook in k1435 in k443 in k228 in k225 */
static void f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1404 in k443 in k228 in k225 */
static void C_fcall f_1406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* thread-deliver-signal! in k443 in k228 in k225 */
static void f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1378,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,*((C_word*)lf[32]+1));
if(C_truep(t4)){
t5=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t3);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t2,C_fix(1),t6));}}

/* a1395 in thread-deliver-signal! in k443 in k228 in k225 */
static void f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1400,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1398 in a1395 in thread-deliver-signal! in k443 in k228 in k225 */
static void f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k443 in k228 in k225 */
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1344,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1348,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1353,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(2));
t6=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a1352 in condition-variable-broadcast! in k443 in k228 in k225 */
static void f_1353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1353,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[83]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[81]));
if(C_truep(t5)){
t6=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1346 in condition-variable-broadcast! in k443 in k228 in k225 */
static void f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k443 in k228 in k225 */
static void f_1304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1304,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(3));
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_i_setslot(t2,C_fix(2),t6);
t8=(C_word)C_eqp(t5,lf[83]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[81]));
if(C_truep(t9)){
t10=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t1,t4);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k443 in k228 in k225 */
static void f_1298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1298,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k443 in k228 in k225 */
static void f_1292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1292,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k443 in k228 in k225 */
static void f_1286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1286,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[85]));}

/* make-condition-variable in k443 in k228 in k225 */
static void f_1267(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1267r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1267r(t0,t1,t2);}}

static void f_1267r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1275(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[85]);}}

/* k1273 in make-condition-variable in k443 in k228 in k225 */
static void f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[85],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k443 in k228 in k225 */
static void f_1094(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1094r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1094r(t0,t1,t2,t3);}}

static void f_1094r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(6);
t4=*((C_word*)lf[32]+1);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t7,C_fix(1));
t9=(C_truep(t8)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_truep(t6)?C_SCHEME_UNDEFINED:C_SCHEME_UNDEFINED);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1109,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_call_cc(3,0,t1,t11);}

/* a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1109,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=lf[1];
f_232(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1116(2,t5,C_SCHEME_FALSE);}}

/* k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1116,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1242,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
t6=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1224,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t9=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1131(2,t6,C_SCHEME_UNDEFINED);}}

/* k1222 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1131(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[81]));}}

/* a1201 in k1222 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1213,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1211 in a1201 in k1222 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1129 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1134(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_eqp(t4,lf[83]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[81]));
if(C_truep(t8)){
t9=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t10=(C_word)C_slot(t3,C_fix(8));
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t10);
t12=(C_word)C_i_setslot(t3,C_fix(8),t11);
t13=(C_word)C_eqp(t4,lf[81]);
if(C_truep(t13)){
t14=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t2,t3);}
else{
t14=t2;
f_1134(2,t14,C_SCHEME_UNDEFINED);}}
else{
t9=t2;
f_1134(2,t9,C_SCHEME_UNDEFINED);}}}

/* k1132 in k1129 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1233 in k1240 in k1114 in a1108 in mutex-unlock! in k443 in k228 in k225 */
static void f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k443 in k228 in k225 */
static void f_888(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_888r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_888r(t0,t1,t2,t3);}}

static void f_888r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_895,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=(C_word)C_slot(t3,C_fix(0));
t7=lf[1];
f_232(t7,t5,t6);}
else{
t6=t5;
f_895(2,t6,C_SCHEME_FALSE);}}

/* k893 in mutex-lock! in k443 in k228 in k225 */
static void f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?C_SCHEME_UNDEFINED:C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_912,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_912,3,t0,t1,t2);}
t3=*((C_word*)lf[32]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_915,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_936,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=t5;
f_936(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[81]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=t4;
f_915(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_960,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_960(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[51],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[31],t9));
if(C_truep(t11)){
t12=t6;
f_960(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_960(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k958 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void C_fcall f_960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_960,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
f_936(t3,t2);}

/* k961 in k958 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1069 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* k1020 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k1026 in k1020 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_915(t2,((C_word*)t0)[2]);}

/* a1032 in k1020 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1055,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1053 in a1032 in k1020 in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=(C_word)C_slot(*((C_word*)lf[32]+1),C_fix(8));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_i_setslot(*((C_word*)lf[32]+1),C_fix(8),t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}

/* check in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void C_fcall f_936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_936,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_947,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[18],lf[79],C_SCHEME_END_OF_LIST);
t4=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k945 in check in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void C_fcall f_915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_915,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_926,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k924 in switch in a911 in k893 in mutex-lock! in k443 in k228 in k225 */
static void f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k443 in k228 in k225 */
static void f_867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_867,3,t0,t1,t2);}
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t3=(C_word)C_slot(t2,C_fix(2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:lf[74]));}
else{
t3=(C_word)C_slot(t2,C_fix(4));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?lf[75]:lf[76]));}}

/* mutex-specific-set! in k443 in k228 in k225 */
static void f_861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_861,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k443 in k228 in k225 */
static void f_855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_855,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k443 in k228 in k225 */
static void f_849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_849,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k443 in k228 in k225 */
static void f_831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_831r(t0,t1,t2);}}

static void f_831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_835(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[67]);}}

/* k833 in make-mutex in k443 in k228 in k225 */
static void f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[32]+1));}

/* mutex? in k443 in k228 in k225 */
static void f_825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_825,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* thread-sleep! in k443 in k228 in k225 */
static void f_792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_796,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_796(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[4],lf[64],lf[65],t2);}}

/* k794 in thread-sleep! in k443 in k228 in k225 */
static void f_796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t2);}

/* a800 in k794 in thread-sleep! in k443 in k228 in k225 */
static void f_801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_801,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_805,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[1];
f_232(t4,t3,((C_word*)t0)[2]);}

/* k803 in a800 in k794 in thread-sleep! in k443 in k228 in k225 */
static void f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
t2=*((C_word*)lf[32]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_816,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(t2,C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t1);}

/* k809 in k803 in a800 in k794 in thread-sleep! in k443 in k228 in k225 */
static void f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a815 in k803 in a800 in k794 in thread-sleep! in k443 in k228 in k225 */
static void f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_816,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k443 in k228 in k225 */
static void f_773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_773,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[62]);
if(C_truep(t4)){
t5=(C_word)C_i_setslot(t2,C_fix(3),lf[45]);
t6=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k443 in k228 in k225 */
static void f_743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_743,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[62]);
t4=(C_word)C_eqp(t2,*((C_word*)lf[32]+1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_call_cc(3,0,t1,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a757 in thread-suspend! in k443 in k228 in k225 */
static void f_758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_758,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
t5=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a766 in a757 in thread-suspend! in k443 in k228 in k225 */
static void f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_767,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k443 in k228 in k225 */
static void f_706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_706,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,*((C_word*)lf[59]+1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_741,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[60]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_710(2,t5,C_SCHEME_UNDEFINED);}}

/* k739 in thread-terminate! in k443 in k228 in k225 */
static void f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k708 in thread-terminate! in k443 in k228 in k225 */
static void f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_UNDEFINED);
t3=(C_word)C_a_i_record(&a,3,lf[18],lf[58],C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],lf[51]);}

/* k717 in k708 in thread-terminate! in k443 in k228 in k225 */
static void f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[32]+1));
if(C_truep(t2)){
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k443 in k228 in k225 */
static void f_590(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_590r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_590r(t0,t1,t2,t3);}}

static void f_590r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_594,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
t6=lf[1];
f_232(t6,t4,t5);}
else{
t5=t4;
f_594(2,t5,C_SCHEME_FALSE);}}

/* k592 in thread-join! in k443 in k228 in k225 */
static void f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_594,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_608,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_608,3,t0,t1,t2);}
t3=*((C_word*)lf[32]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_612,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_612(2,t5,C_SCHEME_UNDEFINED);}}

/* k610 in a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_623,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k616 in k610 in a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a622 in k610 in a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_623,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_eqp(t2,lf[31]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_653,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[52],t6);
t8=(C_word)C_a_i_record(&a,3,lf[18],lf[53],t7);
t9=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_672,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_672(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[18],lf[54],C_SCHEME_END_OF_LIST);
t7=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k670 in a622 in k610 in a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k651 in a622 in k610 in a607 in k592 in thread-join! in k443 in k228 in k225 */
static void f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* thread-yield! in k443 in k228 in k225 */
static void f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_575,tmp=(C_word)a,a+=2,tmp);
C_call_cc(3,0,t1,t2);}

/* a574 in thread-yield! in k443 in k228 in k225 */
static void f_575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_575,3,t0,t1,t2);}
t3=*((C_word*)lf[32]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_584,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a583 in a574 in thread-yield! in k443 in k228 in k225 */
static void f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_584,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-start! in k443 in k228 in k225 */
static void f_537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_537,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_541,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_567,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_541(t5,C_SCHEME_UNDEFINED);}}

/* k565 in thread-start! in k443 in k228 in k225 */
static void f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_541(t3,t2);}

/* k539 in thread-start! in k443 in k228 in k225 */
static void C_fcall f_541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_541,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[34],t3);
if(C_truep(t4)){
t5=t2;
f_544(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[44],lf[48],((C_word*)((C_word*)t0)[3])[1]);}}

/* k542 in k539 in thread-start! in k443 in k228 in k225 */
static void f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[45]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k548 in k542 in k539 in thread-start! in k443 in k228 in k225 */
static void f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k443 in k228 in k225 */
static void f_531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_531,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k443 in k228 in k225 */
static void f_521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_521,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_max(t3,C_fix(10));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_i_slot(t2,C_fix(9),t4));}

/* thread-quantum in k443 in k228 in k225 */
static void f_515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_515,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k443 in k228 in k225 */
static void f_509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_509,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k443 in k228 in k225 */
static void f_503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_503,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k443 in k228 in k225 */
static void f_497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_497,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k443 in k228 in k225 */
static void f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_494,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[32]+1));}

/* thread? in k443 in k228 in k225 */
static void f_488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_488,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[35]));}

/* make-thread in k443 in k228 in k225 */
static void f_447(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_447r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_447r(t0,t1,t2,t3);}}

static void f_447r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_451,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_473(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[35]);}}

/* k471 in make-thread in k443 in k228 in k225 */
static void f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[32]+1),C_fix(9));
t3=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[34],t1,t2);}

/* k449 in make-thread in k443 in k228 in k225 */
static void f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a455 in k449 in make-thread in k443 in k228 in k225 */
static void f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_460,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k458 in a455 in k449 in make-thread in k443 in k228 in k225 */
static void f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[31]);}

/* k464 in k458 in a455 in k449 in make-thread in k443 in k228 in k225 */
static void f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k228 in k225 */
static void f_427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_427,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[18]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k228 in k225 */
static void f_411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_411,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[18]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k228 in k225 */
static void f_395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_395,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[18]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[21],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k228 in k225 */
static void f_379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_379,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[18]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[19],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k228 in k225 */
static void f_371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_371,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[2]));}

/* seconds->time in k228 in k225 */
static void f_320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_324,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_fix(0),t4);}

/* k322 in seconds->time in k228 in k225 */
static void f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_327,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k363 in k322 in seconds->time in k228 in k225 */
static void f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k359 in k322 in seconds->time in k228 in k225 */
static void f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k325 in k322 in seconds->time in k228 in k225 */
static void f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k343 in k325 in k322 in seconds->time in k228 in k225 */
static void f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_345,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_337,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k335 in k343 in k325 in k322 in seconds->time in k228 in k225 */
static void f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],((C_word*)t0)[2],t1,t2));}

/* time->seconds in k228 in k225 */
static void f_302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_302,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_a_i_divide(&a,2,t4,C_fix(1000));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_plus(&a,2,t3,t5));}

/* current-time in k228 in k225 */
static void f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_275,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_287,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}

/* k285 in current-time in k228 in k225 */
static void f_287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_287,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k228 in k225 */
static void C_fcall f_232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_232,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_266,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[4],lf[5],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k264 in ##sys#compute-time-limit in k228 in k225 */
static void f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}
/* end of file */
