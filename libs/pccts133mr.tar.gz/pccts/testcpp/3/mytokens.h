enum ANTLRTokenType {
	IDENTIFIER=1,
	NUMBER=2,
	Eof=3
};
